// Backup and Import/Export Utilities for Distats

// Ensure JSZip is loaded
if (typeof JSZip === 'undefined') {
  console.error('JSZip library not loaded. Please include jszip.min.js before this script.');
}

const BACKUP_VERSION = '1.2.0';

/**
 * Get all storage keys that match a pattern for a specific analysis
 * @param {Object} allData - All data from storage
 * @param {string} analysisId - ID of the analysis
 * @returns {Object} - Object with all related keys
 */
function getAnalysisRelatedData(allData, analysisId) {
  const relatedData = {};
  
  // Timeline markers
  const timelineMarkersKey = `timelineMarkers_${analysisId}`;
  if (allData[timelineMarkersKey]) {
    relatedData[timelineMarkersKey] = allData[timelineMarkersKey];
  }
  
  // Timeline quick events
  const timelineQuickEventsKey = `timelineQuickEvents_${analysisId}`;
  if (allData[timelineQuickEventsKey]) {
    relatedData[timelineQuickEventsKey] = allData[timelineQuickEventsKey];
  }
  
  // Selected timeline teams
  const selectedTimelineTeamsKey = `selectedTimelineTeams_${analysisId}`;
  if (allData[selectedTimelineTeamsKey]) {
    relatedData[selectedTimelineTeamsKey] = allData[selectedTimelineTeamsKey];
  }
  
  return relatedData;
}

/**
 * Extract team IDs/names from a project
 * @param {Object} project - Project data
 * @returns {Set} - Set of team identifiers
 */
function extractProjectTeamIds(project) {
  const teamIds = new Set();
  
  // From project.teams array
  if (project.teams && Array.isArray(project.teams)) {
    project.teams.forEach(t => {
      if (t.id) teamIds.add(t.id);
      if (t.name) teamIds.add(t.name);
    });
  }
  
  // From project.userTeam
  if (project.userTeam) {
    teamIds.add(project.userTeam);
  }
  
  // From project.selectedTeam
  if (project.selectedTeam) {
    teamIds.add(project.selectedTeam);
  }
  
  // From notes - check for team references
  if (project.notes && Array.isArray(project.notes)) {
    project.notes.forEach(note => {
      if (note.team) teamIds.add(note.team);
      if (note.teams && Array.isArray(note.teams)) {
        note.teams.forEach(t => teamIds.add(t));
      }
      // From tactical scheme shapes (drawings) in notes
      if (note.images && Array.isArray(note.images)) {
        note.images.forEach(img => {
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            img.slidesData.forEach(slide => {
              if (slide.drawings && Array.isArray(slide.drawings)) {
                slide.drawings.forEach(drawing => {
                  if (drawing.team && drawing.team.trim() !== '') {
                    teamIds.add(drawing.team.trim());
                  }
                });
              }
            });
          }
        });
      }
    });
  }
  
  return teamIds;
}

/**
 * Extract player IDs from a project
 * @param {Object} project - Project data
 * @param {Array} allPlayers - All players in storage
 * @returns {Array} - Players associated with this project
 */
function extractProjectPlayers(project, allPlayers) {
  const projectTeamIds = extractProjectTeamIds(project);
  const playerIds = new Set();
  
  // Players from notes
  if (project.notes && Array.isArray(project.notes)) {
    project.notes.forEach(note => {
      if (note.players && Array.isArray(note.players)) {
        note.players.forEach(p => {
          if (typeof p === 'string') playerIds.add(p);
          else if (p.id) playerIds.add(p.id);
          else if (p.name) playerIds.add(p.name);
        });
      }
      // Players from tactical scheme shapes (drawings) in notes
      if (note.images && Array.isArray(note.images)) {
        note.images.forEach(img => {
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            img.slidesData.forEach(slide => {
              if (slide.drawings && Array.isArray(slide.drawings)) {
                slide.drawings.forEach(drawing => {
                  if (drawing.playerId) playerIds.add(drawing.playerId);
                  if (drawing.players && Array.isArray(drawing.players)) {
                    drawing.players.forEach(id => playerIds.add(id));
                  }
                });
              }
            });
          }
        });
      }
    });
  }
  
  // Get players that belong to project teams
  const associatedPlayers = (allPlayers || []).filter(p => {
    // Check if player is in project teams
    const playerTeam = p.teamId || p.team;
    if (playerTeam && projectTeamIds.has(playerTeam)) return true;
    
    // Check if player is referenced by ID or name
    if (p.id && playerIds.has(p.id)) return true;
    if (p.name && playerIds.has(p.name)) return true;
    
    return false;
  });
  
  return associatedPlayers;
}

/**
 * Export a single project to a .zip file
 * Includes: project data, notes with all images/schemes/animations, 
 * associated players, teams, timeline data, custom formations/events, squad configs
 * @param {string} analysisId - ID of the project to export
 * @returns {Promise<void>}
 */
async function exportProject(analysisId) {
  try {
    // Get all data from storage
    const result = await new Promise((resolve, reject) => {
      chrome.storage.local.get(null, (data) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(data);
        }
      });
    });

    const analyses = result.analyses || [];
    const project = analyses.find(a => a.id === analysisId);

    if (!project) {
      throw new Error('Project not found');
    }

    // Deep clone the project to avoid mutation
    const projectCopy = JSON.parse(JSON.stringify(project));

    // Get associated players
    const associatedPlayers = extractProjectPlayers(project, result.players || []);

    // Get associated teams (global teams that are used in this project)
    const projectTeamIds = extractProjectTeamIds(project);
    const globalTeams = result.teams || [];
    const associatedTeams = globalTeams.filter(t => {
      return projectTeamIds.has(t.id) || projectTeamIds.has(t.name);
    });

    // Get custom formations used by this project's teams
    const customFormations = result.customFormations || {};

    // Get custom events (include all as they might be referenced in notes)
    const customEvents = result.customEvents || [];

    // Get all analysis-related data (timeline markers, quick events, selected teams)
    const analysisRelatedData = getAnalysisRelatedData(result, analysisId);

    // Get squad configurations for this project's teams
    const allSquadConfigs = result.squadConfigurations || [];
    const associatedSquadConfigs = allSquadConfigs.filter(config => {
      return projectTeamIds.has(config.teamName) || projectTeamIds.has(config.teamId);
    });

    // Create project export data - comprehensive structure
    const projectData = {
      // Core project data (includes notes with all images, slidesData, animations, etc.)
      project: projectCopy,
      
      // Associated global data
      associatedPlayers: associatedPlayers,
      associatedTeams: associatedTeams,
      
      // Custom configurations
      customFormations: customFormations,
      customEvents: customEvents,
      squadConfigurations: associatedSquadConfigs,
      
      // Timeline data (stored per-analysis)
      timelineMarkers: analysisRelatedData[`timelineMarkers_${analysisId}`] || [],
      timelineQuickEvents: analysisRelatedData[`timelineQuickEvents_${analysisId}`] || ['Goal', 'Shot', 'Corner', 'Foul', 'Offside', 'Free kick'],
      selectedTimelineTeams: analysisRelatedData[`selectedTimelineTeams_${analysisId}`] || []
    };

    // Create metadata with detailed statistics
    const noteCount = projectCopy.notes ? projectCopy.notes.length : 0;
    let imageCount = 0;
    let schemeCount = 0;
    let animationCount = 0;

    if (projectCopy.notes) {
      projectCopy.notes.forEach(note => {
        if (note.images && Array.isArray(note.images)) {
          note.images.forEach(img => {
            if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
              schemeCount++;
              // Count animations in slides
              img.slidesData.forEach(slide => {
                if (slide.drawings && Array.isArray(slide.drawings)) {
                  slide.drawings.forEach(drawing => {
                    if (drawing.type === 'animpath' || drawing.animationType) {
                      animationCount++;
                    }
                  });
                }
              });
            } else {
              imageCount++;
            }
          });
        } else if (note.image) {
          imageCount++;
        }
      });
    }

    const metadata = {
      version: BACKUP_VERSION,
      type: 'project_export',
      timestamp: new Date().toISOString(),
      projectName: project.name,
      projectId: project.id,
      statistics: {
        noteCount: noteCount,
        imageCount: imageCount,
        schemeCount: schemeCount,
        animationCount: animationCount,
        playerCount: associatedPlayers.length,
        teamCount: associatedTeams.length,
        timelineMarkerCount: projectData.timelineMarkers.length,
        squadConfigCount: associatedSquadConfigs.length,
        videoCount: (project.videos || []).length
      },
      includesTimelineData: projectData.timelineMarkers.length > 0,
      includesSquadConfigurations: associatedSquadConfigs.length > 0,
      includesCustomFormations: Object.keys(customFormations).length > 0,
      includesCustomEvents: customEvents.length > 0
    };

    // Create zip file
    const zip = new JSZip();
    zip.file('project.json', JSON.stringify(projectData, null, 2));
    zip.file('metadata.json', JSON.stringify(metadata, null, 2));

    // Generate zip blob with compression
    const zipBlob = await zip.generateAsync({ 
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    // Trigger download
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `distats-project-${project.name.replace(/[^a-z0-9]/gi, '_')}-${Date.now()}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    console.log('Project exported successfully:', metadata);
    return { success: true, metadata: metadata };
  } catch (error) {
    console.error('Error exporting project:', error);
    throw error;
  }
}

/**
 * Export full system backup to a .zip file
 * Includes ALL data from storage (except temporary session-specific keys)
 * 
 * Backed up data includes:
 * - All projects/analyses with notes, images, schemes, animations
 * - All players and teams
 * - Custom formations and events
 * - Squad configurations
 * - Timeline data for all analyses
 * - User settings (API keys, language preferences, etc.)
 * - Current analysis ID
 * - Any other storage keys (future-proof)
 * 
 * Excluded (temporary keys):
 * - pendingEditor* keys (session-specific editor state)
 * - editorSavedPayload (temporary editor callback data)
 * 
 * @returns {Promise<void>}
 */
async function exportFullBackup() {
  try {
    // Get all data from storage
    const result = await new Promise((resolve, reject) => {
      chrome.storage.local.get(null, (data) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(data);
        }
      });
    });

    // List of temporary keys that should NOT be backed up (session-specific data)
    const temporaryKeys = [
      'pendingEditorImageSrc',
      'pendingEditorCallbackId',
      'pendingEditorCallbackContext',
      'pendingEditorSlidesData',
      'pendingEditorOriginalImageSrc',
      'pendingEditorAddToNote',
      'pendingAutocaptureScreenshots',
      'editorSavedPayload'
    ];

    // Start with all data from storage, then filter out temporary keys
    const backupData = {};
    
    // Copy all keys except temporary ones
    Object.keys(result).forEach(key => {
      if (!temporaryKeys.includes(key)) {
        backupData[key] = result[key];
      }
    });

    // Ensure core data exists (with defaults if missing)
    backupData.analyses = backupData.analyses || [];
    backupData.players = backupData.players || [];
    backupData.teams = backupData.teams || [];
    backupData.customFormations = backupData.customFormations || {};
    backupData.customEvents = backupData.customEvents || [];
    backupData.squadConfigurations = backupData.squadConfigurations || [];
    backupData.currentAnalysisId = backupData.currentAnalysisId || null;

    // Note: Timeline keys are already included above since we copy ALL keys from storage.
    // The loop below is defensive code to ensure timeline keys are included even if
    // they weren't copied in the initial pass (shouldn't happen, but extra safety).
    const analyses = backupData.analyses || [];
    analyses.forEach(analysis => {
      // Timeline markers
      const timelineMarkersKey = `timelineMarkers_${analysis.id}`;
      if (result[timelineMarkersKey] && !backupData[timelineMarkersKey]) {
        backupData[timelineMarkersKey] = result[timelineMarkersKey];
      }
      
      // Timeline quick events
      const timelineQuickEventsKey = `timelineQuickEvents_${analysis.id}`;
      if (result[timelineQuickEventsKey] && !backupData[timelineQuickEventsKey]) {
        backupData[timelineQuickEventsKey] = result[timelineQuickEventsKey];
      }
      
      // Selected timeline teams
      const selectedTimelineTeamsKey = `selectedTimelineTeams_${analysis.id}`;
      if (result[selectedTimelineTeamsKey] && !backupData[selectedTimelineTeamsKey]) {
        backupData[selectedTimelineTeamsKey] = result[selectedTimelineTeamsKey];
      }
    });

    // Calculate statistics
    let totalNotes = 0;
    let totalImages = 0;
    let totalSchemes = 0;
    let totalAnimations = 0;
    let totalTimelineMarkers = 0;

    analyses.forEach(analysis => {
      if (analysis.notes) {
        totalNotes += analysis.notes.length;
        analysis.notes.forEach(note => {
          if (note.images && Array.isArray(note.images)) {
            note.images.forEach(img => {
              if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
                totalSchemes++;
                img.slidesData.forEach(slide => {
                  if (slide.drawings && Array.isArray(slide.drawings)) {
                    slide.drawings.forEach(drawing => {
                      if (drawing.type === 'animpath' || drawing.animationType) {
                        totalAnimations++;
                      }
                    });
                  }
                });
              } else {
                totalImages++;
              }
            });
          } else if (note.image) {
            totalImages++;
          }
        });
      }
      
      const markersKey = `timelineMarkers_${analysis.id}`;
      if (backupData[markersKey]) {
        totalTimelineMarkers += backupData[markersKey].length;
      }
    });

    // Create metadata
    const metadata = {
      version: BACKUP_VERSION,
      type: 'full_backup',
      timestamp: new Date().toISOString(),
      statistics: {
        projectCount: backupData.analyses.length,
        playerCount: backupData.players.length,
        teamCount: (backupData.teams || []).length,
        squadConfigurationCount: (backupData.squadConfigurations || []).length,
        customFormationCount: Object.keys(backupData.customFormations || {}).length,
        customEventCount: (backupData.customEvents || []).length,
        totalNotes: totalNotes,
        totalImages: totalImages,
        totalSchemes: totalSchemes,
        totalAnimations: totalAnimations,
        totalTimelineMarkers: totalTimelineMarkers,
        totalKeysBackedUp: Object.keys(backupData).length
      },
      includesTimelineData: true,
      includesSquadConfigurations: true,
      includesTeams: true,
      includesPlayers: true,
      includesAllData: true, // Indicates that all storage keys are included (except temporary ones)
      backedUpKeys: Object.keys(backupData).sort() // List of all keys included in backup
    };

    // Create zip file
    const zip = new JSZip();
    zip.file('backup.json', JSON.stringify(backupData, null, 2));
    zip.file('metadata.json', JSON.stringify(metadata, null, 2));

    // Generate zip blob with compression
    const zipBlob = await zip.generateAsync({ 
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    // Trigger download
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `distats-backup-${new Date().toISOString().split('T')[0]}-${Date.now()}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    console.log('Full backup exported successfully:', metadata);
    return { success: true, metadata: metadata };
  } catch (error) {
    console.error('Error exporting backup:', error);
    throw error;
  }
}

/**
 * Validate note structure including images, schemes, animations
 * @param {Object} note - Note to validate
 * @returns {Object} - { valid: boolean, warnings: string[] }
 */
function validateNote(note) {
  const warnings = [];
  
  if (!note.timestamp && !note.createdAt) {
    warnings.push('Note missing timestamp');
  }
  
  if (note.images && Array.isArray(note.images)) {
    note.images.forEach((img, idx) => {
      if (typeof img === 'object') {
        if (img.slidesData && Array.isArray(img.slidesData)) {
          // Validate tactical scheme
          img.slidesData.forEach((slide, slideIdx) => {
            if (slide.drawings && !Array.isArray(slide.drawings)) {
              warnings.push(`Note image ${idx} slide ${slideIdx}: drawings is not an array`);
            }
          });
        } else if (!img.imageData) {
          warnings.push(`Note image ${idx}: missing imageData`);
        }
      } else if (typeof img !== 'string') {
        warnings.push(`Note image ${idx}: invalid format`);
      }
    });
  }
  
  return { valid: warnings.length === 0, warnings };
}

/**
 * Validate project data structure - comprehensive validation
 * @param {Object} data - Project data to validate
 * @returns {Object} - { valid: boolean, errors: string[], warnings: string[] }
 */
function validateProjectData(data) {
  const errors = [];
  const warnings = [];

  // Validate project structure
  if (!data.project) {
    errors.push('Missing project data');
  } else {
    if (!data.project.id) errors.push('Project missing id');
    if (!data.project.name) errors.push('Project missing name');
    
    // Validate notes array
    if (data.project.notes && !Array.isArray(data.project.notes)) {
      errors.push('Project notes must be an array');
    } else if (data.project.notes) {
      // Validate each note
      data.project.notes.forEach((note, idx) => {
        const noteValidation = validateNote(note);
        if (!noteValidation.valid) {
          noteValidation.warnings.forEach(w => warnings.push(`Note ${idx}: ${w}`));
        }
      });
    }
    
    // Validate videos array
    if (data.project.videos && !Array.isArray(data.project.videos)) {
      errors.push('Project videos must be an array');
    }
    
    // Validate teams array
    if (data.project.teams && !Array.isArray(data.project.teams)) {
      errors.push('Project teams must be an array');
    }
  }

  // Validate associated data
  if (data.associatedPlayers && !Array.isArray(data.associatedPlayers)) {
    errors.push('associatedPlayers must be an array');
  }

  if (data.associatedTeams && !Array.isArray(data.associatedTeams)) {
    errors.push('associatedTeams must be an array');
  }

  if (data.customFormations && typeof data.customFormations !== 'object') {
    errors.push('customFormations must be an object');
  }

  if (data.customEvents && !Array.isArray(data.customEvents)) {
    errors.push('customEvents must be an array');
  }

  if (data.timelineMarkers && !Array.isArray(data.timelineMarkers)) {
    errors.push('timelineMarkers must be an array');
  }

  if (data.timelineQuickEvents && !Array.isArray(data.timelineQuickEvents)) {
    errors.push('timelineQuickEvents must be an array');
  }

  if (data.selectedTimelineTeams && !Array.isArray(data.selectedTimelineTeams)) {
    errors.push('selectedTimelineTeams must be an array');
  }

  if (data.squadConfigurations && !Array.isArray(data.squadConfigurations)) {
    errors.push('squadConfigurations must be an array');
  }

  return {
    valid: errors.length === 0,
    errors: errors,
    warnings: warnings
  };
}

/**
 * Validate backup data structure - comprehensive validation
 * @param {Object} data - Backup data to validate
 * @returns {Object} - { valid: boolean, errors: string[], warnings: string[] }
 */
function validateBackupData(data) {
  const errors = [];
  const warnings = [];

  // Validate analyses array
  if (!Array.isArray(data.analyses)) {
    errors.push('analyses must be an array');
  } else {
    // Validate each analysis
    data.analyses.forEach((analysis, idx) => {
      if (!analysis.id) warnings.push(`Analysis ${idx}: missing id`);
      if (!analysis.name) warnings.push(`Analysis ${idx}: missing name`);
      
      if (analysis.notes && Array.isArray(analysis.notes)) {
        analysis.notes.forEach((note, noteIdx) => {
          const noteValidation = validateNote(note);
          if (!noteValidation.valid) {
            noteValidation.warnings.forEach(w => warnings.push(`Analysis ${idx} Note ${noteIdx}: ${w}`));
          }
        });
      }
    });
  }

  // Validate players array
  if (!Array.isArray(data.players)) {
    errors.push('players must be an array');
  }

  // Validate teams (if present)
  if (data.teams && !Array.isArray(data.teams)) {
    errors.push('teams must be an array');
  }

  // Validate custom data
  if (data.customFormations && typeof data.customFormations !== 'object') {
    errors.push('customFormations must be an object');
  }

  if (data.customEvents && !Array.isArray(data.customEvents)) {
    errors.push('customEvents must be an array');
  }

  if (data.squadConfigurations && !Array.isArray(data.squadConfigurations)) {
    errors.push('squadConfigurations must be an array');
  }

  // Validate timeline data for each analysis
  if (Array.isArray(data.analyses)) {
    data.analyses.forEach(analysis => {
      const timelineMarkersKey = `timelineMarkers_${analysis.id}`;
      const timelineQuickEventsKey = `timelineQuickEvents_${analysis.id}`;
      const selectedTimelineTeamsKey = `selectedTimelineTeams_${analysis.id}`;

      if (data[timelineMarkersKey] && !Array.isArray(data[timelineMarkersKey])) {
        errors.push(`${timelineMarkersKey} must be an array`);
      }

      if (data[timelineQuickEventsKey] && !Array.isArray(data[timelineQuickEventsKey])) {
        errors.push(`${timelineQuickEventsKey} must be an array`);
      }

      if (data[selectedTimelineTeamsKey] && !Array.isArray(data[selectedTimelineTeamsKey])) {
        errors.push(`${selectedTimelineTeamsKey} must be an array`);
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors: errors,
    warnings: warnings
  };
}

/**
 * Check for conflicts with existing projects
 * @param {Object} newProject - Project to check
 * @param {Array} existingAnalyses - Existing projects
 * @returns {Object} - { hasConflict: boolean, conflictType: string }
 */
function findConflicts(newProject, existingAnalyses) {
  const existing = existingAnalyses.find(a => a.id === newProject.id);
  if (existing) {
    return {
      hasConflict: true,
      conflictType: 'id',
      existing: existing
    };
  }
  return { hasConflict: false };
}

/**
 * Merge players, avoiding duplicates
 * @param {Array} newPlayers - New players to merge
 * @param {Array} existingPlayers - Existing players
 * @returns {Array} - Merged players array
 */
function mergePlayers(newPlayers, existingPlayers) {
  const existing = existingPlayers || [];
  const merged = [...existing];
  const existingIds = new Set(existing.map(p => p.id));
  const existingNames = new Set(existing.map(p => `${p.name}_${p.team || p.teamId}`));

  (newPlayers || []).forEach(newPlayer => {
    // Check by ID first
    if (newPlayer.id && existingIds.has(newPlayer.id)) {
      return; // Skip duplicate
    }
    
    // Check by name + team combination
    const nameKey = `${newPlayer.name}_${newPlayer.team || newPlayer.teamId}`;
    if (existingNames.has(nameKey)) {
      return; // Skip duplicate
    }
    
    merged.push(newPlayer);
    if (newPlayer.id) existingIds.add(newPlayer.id);
    existingNames.add(nameKey);
  });

  return merged;
}

/**
 * Merge teams, avoiding duplicates
 * @param {Array} newTeams - New teams to merge
 * @param {Array} existingTeams - Existing teams
 * @returns {Array} - Merged teams array
 */
function mergeTeams(newTeams, existingTeams) {
  const existing = existingTeams || [];
  const merged = [...existing];
  const existingIds = new Set(existing.map(t => t.id));
  const existingNames = new Set(existing.map(t => t.name));

  (newTeams || []).forEach(newTeam => {
    if (newTeam.id && existingIds.has(newTeam.id)) {
      return; // Skip duplicate
    }
    if (newTeam.name && existingNames.has(newTeam.name)) {
      return; // Skip duplicate
    }
    
    merged.push(newTeam);
    if (newTeam.id) existingIds.add(newTeam.id);
    if (newTeam.name) existingNames.add(newTeam.name);
  });

  return merged;
}

/**
 * Merge custom formations
 * @param {Object} newFormations - New formations
 * @param {Object} existingFormations - Existing formations
 * @returns {Object} - Merged formations
 */
function mergeCustomFormations(newFormations, existingFormations) {
  const existing = existingFormations || {};
  const merged = { ...existing };

  Object.keys(newFormations || {}).forEach(key => {
    if (!merged[key]) {
      merged[key] = newFormations[key];
    }
  });

  return merged;
}

/**
 * Merge custom events
 * @param {Array} newEvents - New events
 * @param {Array} existingEvents - Existing events
 * @returns {Array} - Merged events
 */
function mergeCustomEvents(newEvents, existingEvents) {
  const existing = existingEvents || [];
  const merged = [...existing];
  const existingNames = new Set(existing.map(e => {
    const name = typeof e === 'string' ? e : e.name;
    return name;
  }));

  (newEvents || []).forEach(newEvent => {
    const name = typeof newEvent === 'string' ? newEvent : newEvent.name;
    if (!existingNames.has(name)) {
      merged.push(newEvent);
      existingNames.add(name);
    }
  });

  return merged;
}

/**
 * Merge squad configurations
 * @param {Array} newConfigs - New squad configs
 * @param {Array} existingConfigs - Existing squad configs
 * @returns {Array} - Merged configs
 */
function mergeSquadConfigurations(newConfigs, existingConfigs) {
  const existing = existingConfigs || [];
  const merged = [...existing];
  const existingIds = new Set(existing.map(c => c.id));

  (newConfigs || []).forEach(newConfig => {
    const existingIndex = merged.findIndex(c => c.id === newConfig.id);
    if (existingIndex === -1) {
      merged.push(newConfig);
    } else {
      // Update existing config with imported data
      merged[existingIndex] = { ...merged[existingIndex], ...newConfig };
    }
  });

  return merged;
}

/**
 * Import a project from a .zip file
 * @param {File} zipFile - The .zip file to import
 * @param {Object} options - Import options { renameOnConflict: boolean }
 * @returns {Promise<Object>} - { success: boolean, project: Object, message: string }
 */
async function importProject(zipFile, options = {}) {
  try {
    // Read zip file
    const zip = new JSZip();
    const zipData = await zip.loadAsync(zipFile);

    // Check for required files
    if (!zipData.files['project.json']) {
      throw new Error('Invalid project file: missing project.json');
    }
    if (!zipData.files['metadata.json']) {
      throw new Error('Invalid project file: missing metadata.json');
    }

    // Parse JSON files
    const projectJson = await zipData.files['project.json'].async('string');
    const metadataJson = await zipData.files['metadata.json'].async('string');

    let projectData, metadata;
    try {
      projectData = JSON.parse(projectJson);
      metadata = JSON.parse(metadataJson);
    } catch (parseError) {
      throw new Error('Invalid JSON in project file: ' + parseError.message);
    }

    // Validate metadata
    if (metadata.type !== 'project_export') {
      throw new Error('Invalid file type: expected project_export');
    }

    // Validate project data
    const validation = validateProjectData(projectData);
    if (!validation.valid) {
      throw new Error('Invalid project data: ' + validation.errors.join(', '));
    }
    
    // Log warnings if any
    if (validation.warnings.length > 0) {
      console.warn('Import warnings:', validation.warnings);
    }

    // Get existing data
    const existingData = await new Promise((resolve, reject) => {
      chrome.storage.local.get(null, (data) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(data);
        }
      });
    });

    const existingAnalyses = existingData.analyses || [];
    const project = projectData.project;

    // Check for conflicts
    const conflict = findConflicts(project, existingAnalyses);
    if (conflict.hasConflict) {
      if (options.renameOnConflict) {
        // Generate new ID
        project.id = 'analysis_' + Date.now();
        project.name = project.name + ' (Imported)';
      } else {
        throw new Error(`Project with ID ${project.id} already exists. Use renameOnConflict option or choose a different project.`);
      }
    }

    // Merge all data types
    const mergedPlayers = mergePlayers(projectData.associatedPlayers || [], existingData.players || []);
    const mergedTeams = mergeTeams(projectData.associatedTeams || [], existingData.teams || []);
    const mergedFormations = mergeCustomFormations(projectData.customFormations || {}, existingData.customFormations || {});
    const mergedEvents = mergeCustomEvents(projectData.customEvents || [], existingData.customEvents || []);
    const mergedSquadConfigs = mergeSquadConfigurations(projectData.squadConfigurations || [], existingData.squadConfigurations || []);

    // Add project to analyses
    const updatedAnalyses = [...existingAnalyses, project];

    // Prepare data to save
    const dataToSave = {
      analyses: updatedAnalyses,
      players: mergedPlayers,
      teams: mergedTeams,
      customFormations: mergedFormations,
      customEvents: mergedEvents,
      squadConfigurations: mergedSquadConfigs
    };

    // Add timeline data for this project
    const timelineMarkersKey = `timelineMarkers_${project.id}`;
    const timelineQuickEventsKey = `timelineQuickEvents_${project.id}`;
    const selectedTimelineTeamsKey = `selectedTimelineTeams_${project.id}`;

    if (projectData.timelineMarkers && projectData.timelineMarkers.length > 0) {
      dataToSave[timelineMarkersKey] = projectData.timelineMarkers;
    }

    if (projectData.timelineQuickEvents && projectData.timelineQuickEvents.length > 0) {
      dataToSave[timelineQuickEventsKey] = projectData.timelineQuickEvents;
    }

    if (projectData.selectedTimelineTeams && projectData.selectedTimelineTeams.length > 0) {
      dataToSave[selectedTimelineTeamsKey] = projectData.selectedTimelineTeams;
    }

    // Save to storage
    await new Promise((resolve, reject) => {
      chrome.storage.local.set(dataToSave, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });

    console.log('Project imported successfully:', project.name);
    return {
      success: true,
      project: project,
      message: `Project "${project.name}" imported successfully`,
      statistics: metadata.statistics || {}
    };
  } catch (error) {
    console.error('Error importing project:', error);
    throw error;
  }
}

/**
 * Import/restore from a full backup .zip file
 * Restores ALL data from backup, including all storage keys to ensure nothing is lost
 * 
 * Restored data includes:
 * - All projects/analyses with complete data
 * - All players, teams, custom formations, events
 * - Squad configurations
 * - Timeline data for all analyses
 * - User settings (API keys, language preferences, etc.)
 * - Any other keys present in the backup
 * 
 * @param {File} zipFile - The .zip file to import
 * @param {Object} options - Import options { clearExisting: boolean }
 * @returns {Promise<Object>} - { success: boolean, message: string }
 */
async function importBackup(zipFile, options = { clearExisting: true }) {
  try {
    // Read zip file
    const zip = new JSZip();
    const zipData = await zip.loadAsync(zipFile);

    // Check for required files
    if (!zipData.files['backup.json']) {
      throw new Error('Invalid backup file: missing backup.json');
    }
    if (!zipData.files['metadata.json']) {
      throw new Error('Invalid backup file: missing metadata.json');
    }

    // Parse JSON files
    const backupJson = await zipData.files['backup.json'].async('string');
    const metadataJson = await zipData.files['metadata.json'].async('string');

    let backupData, metadata;
    try {
      backupData = JSON.parse(backupJson);
      metadata = JSON.parse(metadataJson);
    } catch (parseError) {
      throw new Error('Invalid JSON in backup file: ' + parseError.message);
    }

    // Validate metadata
    if (metadata.type !== 'full_backup') {
      throw new Error('Invalid file type: expected full_backup');
    }

    // Validate backup data
    const validation = validateBackupData(backupData);
    if (!validation.valid) {
      throw new Error('Invalid backup data: ' + validation.errors.join(', '));
    }

    // Log warnings if any
    if (validation.warnings.length > 0) {
      console.warn('Import warnings:', validation.warnings);
    }

    // Prepare data for storage - include ALL keys from backup to ensure nothing is lost
    // This includes settings like openai_api_key, ai_analysis_language, etc.
    const dataToStore = {};
    
    // Copy all keys from backupData to ensure complete restoration
    Object.keys(backupData).forEach(key => {
      dataToStore[key] = backupData[key];
    });

    // Ensure core data exists with defaults if missing
    dataToStore.analyses = dataToStore.analyses || [];
    dataToStore.players = dataToStore.players || [];
    dataToStore.teams = dataToStore.teams || [];
    dataToStore.customFormations = dataToStore.customFormations || {};
    dataToStore.customEvents = dataToStore.customEvents || [];
    dataToStore.squadConfigurations = dataToStore.squadConfigurations || [];
    dataToStore.currentAnalysisId = dataToStore.currentAnalysisId || null;

    // Save to storage
    if (options.clearExisting) {
      // Clear existing data first, then save new data
      await new Promise((resolve, reject) => {
        chrome.storage.local.clear(() => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            chrome.storage.local.set(dataToStore, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          }
        });
      });
    } else {
      // Just save (will merge with existing)
      await new Promise((resolve, reject) => {
        chrome.storage.local.set(dataToStore, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve();
          }
        });
      });
    }

    console.log('Backup restored successfully:', metadata);
    return {
      success: true,
      message: `Backup restored successfully. ${backupData.analyses.length} projects restored.`,
      statistics: metadata.statistics || {}
    };
  } catch (error) {
    console.error('Error importing backup:', error);
    throw error;
  }
}

/**
 * Get export preview - analyze what would be exported without actually exporting
 * @param {string} analysisId - ID of the project
 * @returns {Promise<Object>} - Statistics about what would be exported
 */
async function getExportPreview(analysisId) {
  try {
    const result = await new Promise((resolve, reject) => {
      chrome.storage.local.get(null, (data) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(data);
        }
      });
    });

    const analyses = result.analyses || [];
    const project = analyses.find(a => a.id === analysisId);

    if (!project) {
      throw new Error('Project not found');
    }

    const associatedPlayers = extractProjectPlayers(project, result.players || []);
    const projectTeamIds = extractProjectTeamIds(project);
    const globalTeams = result.teams || [];
    const associatedTeams = globalTeams.filter(t => projectTeamIds.has(t.id) || projectTeamIds.has(t.name));

    let noteCount = 0;
    let imageCount = 0;
    let schemeCount = 0;
    let animationCount = 0;

    if (project.notes) {
      noteCount = project.notes.length;
      project.notes.forEach(note => {
        if (note.images && Array.isArray(note.images)) {
          note.images.forEach(img => {
            if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
              schemeCount++;
              img.slidesData.forEach(slide => {
                if (slide.drawings && Array.isArray(slide.drawings)) {
                  slide.drawings.forEach(drawing => {
                    if (drawing.type === 'animpath' || drawing.animationType) {
                      animationCount++;
                    }
                  });
                }
              });
            } else {
              imageCount++;
            }
          });
        } else if (note.image) {
          imageCount++;
        }
      });
    }

    const timelineMarkersKey = `timelineMarkers_${analysisId}`;
    const timelineMarkers = result[timelineMarkersKey] || [];

    return {
      projectName: project.name,
      statistics: {
        noteCount,
        imageCount,
        schemeCount,
        animationCount,
        playerCount: associatedPlayers.length,
        teamCount: associatedTeams.length,
        timelineMarkerCount: timelineMarkers.length,
        videoCount: (project.videos || []).length
      }
    };
  } catch (error) {
    console.error('Error getting export preview:', error);
    throw error;
  }
}

// Export functions for use in other scripts
if (typeof window !== 'undefined') {
  window.backupUtils = {
    exportProject,
    exportFullBackup,
    importProject,
    importBackup,
    validateProjectData,
    validateBackupData,
    getExportPreview,
    BACKUP_VERSION
  };
}
