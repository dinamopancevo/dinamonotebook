// Internationalization (i18n) utility for Dinamo Notebook
// Supports multiple languages with auto-detection and manual selection

(function() {
  'use strict';

  let currentLanguage = 'en';
  let translations = {};
  let languageChangeCallbacks = [];

  // Supported languages
  const SUPPORTED_LANGUAGES = {
    'en': 'English',
    'sr': 'Serbian (Srpski)',
    'de': 'German (Deutsch)',
    'fr': 'French (Français)',
    'es': 'Spanish (Español)',
    'pt': 'Portuguese (Português)'
  };

  // Default language
  const DEFAULT_LANGUAGE = 'en';

  /**
   * Load translation file for a given language
   * @param {string} langCode - Language code (e.g., 'en', 'sr', 'de')
   * @returns {Promise<Object>} Translation object
   */
  async function loadLanguage(langCode) {
    try {
      const response = await fetch(chrome.runtime.getURL(`locales/${langCode}.json`));
      if (!response.ok) {
        throw new Error(`Failed to load language file: ${langCode}`);
      }
      return await response.json();
    } catch (error) {
      console.warn(`Failed to load language ${langCode}, falling back to English:`, error);
      // Fallback to English
      if (langCode !== DEFAULT_LANGUAGE) {
        return loadLanguage(DEFAULT_LANGUAGE);
      }
      // If English also fails, return empty object
      return {};
    }
  }

  /**
   * Get nested translation value by key path
   * @param {Object} obj - Object to search
   * @param {string} path - Dot-separated path (e.g., 'common.save')
   * @returns {string|undefined} Translation value or undefined
   */
  function getNestedValue(obj, path) {
    return path.split('.').reduce((current, key) => current && current[key], obj);
  }

  /**
   * Translation function
   * @param {string} key - Translation key (e.g., 'common.save' or 'sidebar.selectProject')
   * @param {Object} params - Optional parameters for string interpolation
   * @returns {string} Translated string
   */
  function t(key, params = {}) {
    if (!key) return '';
    
    // If translations not loaded yet, return key silently (don't warn during initialization)
    if (!translations || Object.keys(translations).length === 0) {
      return key;
    }
    
    let translation = getNestedValue(translations, key);
    
    // If still not found, return the key itself
    // Only warn if we have translations loaded but key is missing (not during initial load)
    if (!translation) {
      // Only warn if translations are actually loaded (not empty)
      if (Object.keys(translations).length > 0) {
        console.warn(`Translation missing for key: ${key}`);
      }
      return key;
    }

    // Simple parameter interpolation: {paramName}
    if (params && Object.keys(params).length > 0) {
      return translation.replace(/\{(\w+)\}/g, (match, paramName) => {
        return params[paramName] !== undefined ? params[paramName] : match;
      });
    }

    return translation;
  }

  /**
   * Get current language code
   * @returns {string} Current language code
   */
  function getCurrentLanguage() {
    return currentLanguage;
  }

  /**
   * Get supported languages
   * @returns {Object} Object mapping language codes to display names
   */
  function getSupportedLanguages() {
    return SUPPORTED_LANGUAGES;
  }

  /**
   * Detect browser language
   * @returns {string} Detected language code
   */
  function detectBrowserLanguage() {
    const browserLang = navigator.language || navigator.userLanguage;
    const langCode = browserLang.split('-')[0].toLowerCase();
    
    // Check if browser language is supported
    if (SUPPORTED_LANGUAGES[langCode]) {
      return langCode;
    }
    
    // Fallback to default
    return DEFAULT_LANGUAGE;
  }

  /**
   * Set language and reload translations
   * @param {string} langCode - Language code to set
   * @returns {Promise<void>}
   */
  async function setLanguage(langCode) {
    if (!SUPPORTED_LANGUAGES[langCode]) {
      console.warn(`Unsupported language: ${langCode}, falling back to ${DEFAULT_LANGUAGE}`);
      langCode = DEFAULT_LANGUAGE;
    }

    currentLanguage = langCode;
    
    // Load translations
    const loadedTranslations = await loadLanguage(langCode);
    
    // Only update if we got valid translations
    if (loadedTranslations && Object.keys(loadedTranslations).length > 0) {
      translations = loadedTranslations;
    } else {
      console.warn(`Failed to load translations for ${langCode}, using empty object`);
      translations = {};
    }

    // Save preference to Chrome storage
    try {
      await chrome.storage.local.set({ preferredLanguage: langCode });
    } catch (error) {
      console.warn('Failed to save language preference:', error);
    }

    // Notify all callbacks
    languageChangeCallbacks.forEach(callback => {
      try {
        callback(langCode);
      } catch (error) {
        console.error('Error in language change callback:', error);
      }
    });
    
    // Update all i18n elements after language change
    if (typeof document !== 'undefined' && document.readyState !== 'loading') {
      updateI18nElements();
    }
  }

  /**
   * Initialize i18n system
   * Loads language preference from storage or detects from browser
   * @returns {Promise<void>}
   */
  async function init() {
    try {
      // Try to load saved preference
      const result = await chrome.storage.local.get(['preferredLanguage']);
      let langCode = result.preferredLanguage;

      // If no preference saved, detect from browser
      if (!langCode) {
        langCode = detectBrowserLanguage();
      }

      // Load the language
      await setLanguage(langCode);
    } catch (error) {
      console.error('Failed to initialize i18n:', error);
      // Fallback to default
      await setLanguage(DEFAULT_LANGUAGE);
    }
  }

  /**
   * Register callback for language changes
   * @param {Function} callback - Callback function that receives (langCode)
   */
  function onLanguageChange(callback) {
    if (typeof callback === 'function') {
      languageChangeCallbacks.push(callback);
    }
  }

  /**
   * Update all elements with data-i18n attributes
   */
  function updateI18nElements() {
    // Update text content
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
      // Skip project button text - it's managed dynamically based on project state
      const isProjectButton = element.id === 'projectButtonText' || element.id === 'distatsProjectButtonText';
      if (isProjectButton) {
        return; // Don't overwrite - managed by updateDynamicI18nContent/updateProjectSelect
      }
      
      const key = element.getAttribute('data-i18n');
      const translation = t(key);
      
      // Update appropriate property based on element type
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        // For inputs/textarea, only update textContent if it's not a placeholder
        element.textContent = translation;
      } else if (element.tagName === 'IMG') {
        element.alt = translation;
      } else if (element.tagName === 'OPTION') {
        element.textContent = translation;
      } else {
        element.textContent = translation;
      }
    });

    // Update title attributes
    const titleElements = document.querySelectorAll('[data-i18n-title]');
    titleElements.forEach(element => {
      const key = element.getAttribute('data-i18n-title');
      element.title = t(key);
    });

    // Update placeholder attributes
    const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
    placeholderElements.forEach(element => {
      const key = element.getAttribute('data-i18n-placeholder');
      element.placeholder = t(key);
    });

    // Update alt attributes
    const altElements = document.querySelectorAll('[data-i18n-alt]');
    altElements.forEach(element => {
      const key = element.getAttribute('data-i18n-alt');
      element.alt = t(key);
    });

    // Update label attributes for optgroups
    const labelElements = document.querySelectorAll('[data-i18n-label]');
    labelElements.forEach(element => {
      const key = element.getAttribute('data-i18n-label');
      if (element.tagName === 'OPTGROUP') {
        element.label = t(key);
      }
    });
  }

  // Export public API
  window.i18n = {
    t,
    getCurrentLanguage,
    getSupportedLanguages,
    setLanguage,
    init,
    onLanguageChange,
    updateI18nElements,
    detectBrowserLanguage
  };

  // Auto-initialize when DOM is ready or immediately if already ready
  const initializeI18n = async () => {
    await init();
    // Update i18n elements after translations are loaded
    updateI18nElements();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeI18n);
  } else {
    initializeI18n();
  }

  // Update i18n elements when language changes
  onLanguageChange(() => {
    updateI18nElements();
  });

})();
