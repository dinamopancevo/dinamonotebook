// Tactical Drawing Editor

// Helper functions to translate event categories and events
function translateEventCategory(categoryName) {
  if (!window.i18n || !window.i18n.t) return categoryName;
  
  const categoryMap = {
    'Possession phases': 'events.categories.possessionPhases',
    'Ball progression events': 'events.categories.ballProgressionEvents',
    'Chance creation events': 'events.categories.chanceCreationEvents',
    'Defensive structure events': 'events.categories.defensiveStructureEvents',
    'Transition events': 'events.categories.transitionEvents',
    'Set-piece tactical events': 'events.categories.setPieceTacticalEvents',
    'Structural / off-ball tactical events': 'events.categories.structuralOffBallTacticalEvents',
    'Error / critical moment events': 'events.categories.errorCriticalMomentEvents',
    'Protocol recordings': 'events.categories.protocolRecordings',
    'Custom': 'modals.addCustomEvent'
  };
  
  const key = categoryMap[categoryName];
  if (key) {
    const translated = window.i18n.t(key);
    return translated !== key ? translated : categoryName;
  }
  return categoryName;
}

function translateEventName(eventName) {
  if (!window.i18n || !window.i18n.t) return eventName;
  
  // Map event names to translation keys
  const eventMap = {
    // Possession phases
    'Build-up': 'events.possessionPhases.buildUp',
    'Consolidation / Middle third possession': 'events.possessionPhases.consolidationMiddleThirdPossession',
    'Final third attack': 'events.possessionPhases.finalThirdAttack',
    'Counterattack': 'events.possessionPhases.counterattack',
    'Transition defense': 'events.possessionPhases.transitionDefense',
    'Set-piece attack': 'events.possessionPhases.setPieceAttack',
    'Set-piece defense': 'events.possessionPhases.setPieceDefense',
    
    // Ball progression events
    'Progressive pass': 'events.ballProgressionEvents.progressivePass',
    'Line-breaking pass': 'events.ballProgressionEvents.lineBreakingPass',
    'Third-man combination': 'events.ballProgressionEvents.thirdManCombination',
    'Switch of play': 'events.ballProgressionEvents.switchOfPlay',
    'Carry that bypasses a line': 'events.ballProgressionEvents.carryThatBypassesALine',
    'Successful dribble forward': 'events.ballProgressionEvents.successfulDribbleForward',
    'Inside-channel progression': 'events.ballProgressionEvents.insideChannelProgression',
    'Half-space entry': 'events.ballProgressionEvents.halfSpaceEntry',
    'Final third entry': 'events.ballProgressionEvents.finalThirdEntry',
    'Penalty box entry': 'events.ballProgressionEvents.penaltyBoxEntry',
    
    // Chance creation events
    'Shot': 'events.chanceCreationEvents.shot',
    'Shot on target': 'events.chanceCreationEvents.shotOnTarget',
    'Assist / key pass': 'events.chanceCreationEvents.assistKeyPass',
    'Cutback': 'events.chanceCreationEvents.cutback',
    'Through ball': 'events.chanceCreationEvents.throughBall',
    'Cross (successful)': 'events.chanceCreationEvents.crossSuccessful',
    'Cross (unsuccessful)': 'events.chanceCreationEvents.crossUnsuccessful',
    'Deep completion (dangerous pass inside 20m, no shot)': 'events.chanceCreationEvents.deepCompletion',
    '1v1 attacking win': 'events.chanceCreationEvents.oneVOneAttackingWin',
    '1v1 attacking loss': 'events.chanceCreationEvents.oneVOneAttackingLoss',
    
    // Defensive structure events
    'Pressing action': 'events.defensiveStructureEvents.pressingAction',
    'Pressing trap triggered': 'events.defensiveStructureEvents.pressingTrapTriggered',
    'Ball recovery (high)': 'events.defensiveStructureEvents.ballRecoveryHigh',
    'Ball recovery (mid)': 'events.defensiveStructureEvents.ballRecoveryMid',
    'Ball recovery (low)': 'events.defensiveStructureEvents.ballRecoveryLow',
    'Counterpress success': 'events.defensiveStructureEvents.counterpressSuccess',
    'Counterpress failure': 'events.defensiveStructureEvents.counterpressFailure',
    'Defensive line broken': 'events.defensiveStructureEvents.defensiveLineBroken',
    'Block shot': 'events.defensiveStructureEvents.blockShot',
    'Interception': 'events.defensiveStructureEvents.interception',
    'Tackle/Duel won': 'events.defensiveStructureEvents.tackleDuelWon',
    'Tackle/Duel lost': 'events.defensiveStructureEvents.tackleDuelLost',
    '1v1 defensive win': 'events.defensiveStructureEvents.oneVOneDefensiveWin',
    '1v1 defensive loss': 'events.defensiveStructureEvents.oneVOneDefensiveLoss',
    
    // Transition events
    'Positive transition (winning the ball)': 'events.transitionEvents.positiveTransitionWinningTheBall',
    'Negative transition (losing the ball)': 'events.transitionEvents.negativeTransitionLosingTheBall',
    'Counterattack start': 'events.transitionEvents.counterattackStart',
    'Dangerous turnover': 'events.transitionEvents.dangerousTurnover',
    'Turnover leading to chance': 'events.transitionEvents.turnoverLeadingToChance',
    'Recovery leading to chance': 'events.transitionEvents.recoveryLeadingToChance',
    
    // Set-piece tactical events
    'Corner attack': 'events.setPieceTacticalEvents.cornerAttack',
    'Corner defense': 'events.setPieceTacticalEvents.cornerDefense',
    'Free kick (crossing)': 'events.setPieceTacticalEvents.freeKickCrossing',
    'Free kick (shooting)': 'events.setPieceTacticalEvents.freeKickShooting',
    'Throw-in routine (only if structured, e.g., long throw)': 'events.setPieceTacticalEvents.throwInRoutine',
    'Second ball win': 'events.setPieceTacticalEvents.secondBallWin',
    'Second ball loss': 'events.setPieceTacticalEvents.secondBallLoss',
    'Set-piece chance created': 'events.setPieceTacticalEvents.setPieceChanceCreated',
    
    // Structural / off-ball tactical events
    'Overload created (right)': 'events.structuralOffBallTacticalEvents.overloadCreatedRight',
    'Overload created (left)': 'events.structuralOffBallTacticalEvents.overloadCreatedLeft',
    'Overload created (central)': 'events.structuralOffBallTacticalEvents.overloadCreatedCentral',
    'Overload lost': 'events.structuralOffBallTacticalEvents.overloadLost',
    'Bad spacing / poor distances': 'events.structuralOffBallTacticalEvents.badSpacingPoorDistances',
    'Line height shift (too high)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooHigh',
    'Line height shift (too low)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooLow',
    'Offside trap activated (successful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedSuccessful',
    'Offside trap activated (unsuccessful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedUnsuccessful',
    'Numerical superiority achieved': 'events.structuralOffBallTacticalEvents.numericalSuperiorityAchieved',
    'Numerical superiority lost': 'events.structuralOffBallTacticalEvents.numericalSuperiorityLost',
    
    // Error / critical moment events
    'Error leading to shot': 'events.errorCriticalMomentEvents.errorLeadingToShot',
    'Error leading to goal': 'events.errorCriticalMomentEvents.errorLeadingToGoal',
    'Poor clearance': 'events.errorCriticalMomentEvents.poorClearance',
    'Bad decision under pressure': 'events.errorCriticalMomentEvents.badDecisionUnderPressure',
    'Miscommunication': 'events.errorCriticalMomentEvents.miscommunication',
    'Failed press': 'events.errorCriticalMomentEvents.failedPress',
    
    // Protocol recordings
    'Goal': 'events.protocolRecordings.goal',
    'Assist': 'events.protocolRecordings.assist',
    'Substitution': 'events.protocolRecordings.substitution',
    'Penalty': 'events.protocolRecordings.penalty',
    'Red card': 'events.protocolRecordings.redCard',
    'Yellow card': 'events.protocolRecordings.yellowCard'
  };
  
  const key = eventMap[eventName];
  if (key) {
    const translated = window.i18n.t(key);
    return translated !== key ? translated : eventName;
  }
  return eventName;
}

// Event Categories (same as in video-sidebar.js)
const EVENT_CATEGORIES = [
  {
    name: 'Possession phases',
    events: [
      'Build-up',
      'Consolidation / Middle third possession',
      'Final third attack',
      'Counterattack',
      'Transition defense',
      'Set-piece attack',
      'Set-piece defense'
    ]
  },
  {
    name: 'Ball progression events',
    events: [
      'Progressive pass',
      'Line-breaking pass',
      'Third-man combination',
      'Switch of play',
      'Carry that bypasses a line',
      'Successful dribble forward',
      'Inside-channel progression',
      'Half-space entry',
      'Final third entry',
      'Penalty box entry'
    ]
  },
  {
    name: 'Chance creation events',
    events: [
      'Shot',
      'Shot on target',
      'Assist / key pass',
      'Cutback',
      'Through ball',
      'Cross (successful)',
      'Cross (unsuccessful)',
      'Deep completion (dangerous pass inside 20m, no shot)',
      '1v1 attacking win',
      '1v1 attacking loss'
    ]
  },
  {
    name: 'Defensive structure events',
    events: [
      'Pressing action',
      'Pressing trap triggered',
      'Ball recovery (high)',
      'Ball recovery (mid)',
      'Ball recovery (low)',
      'Counterpress success',
      'Counterpress failure',
      'Defensive line broken',
      'Block shot',
      'Interception',
      'Tackle/Duel won',
      'Tackle/Duel lost',
      '1v1 defensive win',
      '1v1 defensive loss'
    ]
  },
  {
    name: 'Transition events',
    events: [
      'Positive transition (winning the ball)',
      'Negative transition (losing the ball)',
      'Counterattack start',
      'Dangerous turnover',
      'Turnover leading to chance',
      'Recovery leading to chance'
    ]
  },
  {
    name: 'Set-piece tactical events',
    events: [
      'Corner attack',
      'Corner defense',
      'Free kick (crossing)',
      'Free kick (shooting)',
      'Throw-in routine (only if structured, e.g., long throw)',
      'Second ball win',
      'Second ball loss',
      'Set-piece chance created'
    ]
  },
  {
    name: 'Structural / off-ball tactical events',
    events: [
      'Overload created (right)',
      'Overload created (left)',
      'Overload created (central)',
      'Overload lost',
      'Bad spacing / poor distances',
      'Line height shift (too high)',
      'Line height shift (too low)',
      'Offside trap activated (successful)',
      'Offside trap activated (unsuccessful)',
      'Numerical superiority achieved',
      'Numerical superiority lost'
    ]
  },
  {
    name: 'Error / critical moment events',
    events: [
      'Error leading to shot',
      'Error leading to goal',
      'Poor clearance',
      'Bad decision under pressure',
      'Miscommunication',
      'Failed press'
    ]
  },
  {
    name: 'Protocol recordings',
    events: [
      'Goal',
      'Assist',
      'Substitution',
      'Penalty',
      'Red card',
      'Yellow card'
    ]
  }
];

// Notification System
function showNotification(message, type = 'info', duration = 3000) {
  const container = document.getElementById('editorNotificationContainer');
  if (!container) return;

  const notification = document.createElement('div');
  notification.className = `editor-notification ${type}`;
  
  // Icon based on type
  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ'
  };
  
  notification.innerHTML = `
    <div class="editor-notification-icon">${icons[type] || icons.info}</div>
    <div class="editor-notification-content">${message}</div>
    <button class="editor-notification-close" onclick="this.parentElement.remove()">×</button>
  `;
  
  container.appendChild(notification);
  
  // Auto-remove after duration
  if (duration > 0) {
    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => {
        if (notification.parentElement) {
          notification.remove();
        }
      }, 300);
    }, duration);
  }
  
  return notification;
}

// Custom confirm dialog
function showConfirm(message, onConfirm, onCancel) {
  const container = document.getElementById('editorNotificationContainer');
  if (!container) {
    // Fallback to native confirm
    if (confirm(message)) {
      onConfirm();
    } else if (onCancel) {
      onCancel();
    }
    return;
  }

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 10003; display: flex; align-items: center; justify-content: center;';
  
  const dialog = document.createElement('div');
  dialog.style.cssText = 'background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 24px; max-width: 400px; width: 90%; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);';
  
  dialog.innerHTML = `
    <div style="color: #c9d1d9; font-size: 14px; margin-bottom: 20px; line-height: 1.5;">${message}</div>
    <div style="display: flex; gap: 10px; justify-content: flex-end;">
      <button class="editor-cancel-btn" style="padding: 8px 16px;">Cancel</button>
      <button class="editor-save-btn" style="padding: 8px 16px;">Confirm</button>
    </div>
  `;
  
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);
  
  const cancelBtn = dialog.querySelector('.editor-cancel-btn');
  const confirmBtn = dialog.querySelector('.editor-save-btn');
  
  const close = () => {
    document.body.removeChild(overlay);
  };
  
  cancelBtn.addEventListener('click', () => {
    close();
    if (onCancel) onCancel();
  });
  
  confirmBtn.addEventListener('click', () => {
    close();
    onConfirm();
  });
  
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      close();
      if (onCancel) onCancel();
    }
  });
}

// Custom formations storage key
const CUSTOM_FORMATIONS_KEY = 'customFormations';

// Load custom formations from storage
let customFormations = {};
function loadCustomFormations() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([CUSTOM_FORMATIONS_KEY], (result) => {
      if (result[CUSTOM_FORMATIONS_KEY]) {
        customFormations = result[CUSTOM_FORMATIONS_KEY];
        updateFormationSelector();
      }
    });
  }
}

// Get all formations (built-in + custom)
function getAllFormations() {
  return { ...FORMATIONS, ...customFormations };
}

// Formation data - all positions are relative (0-100 scale, centered at 50,50)
// y: 0 = top (goalkeeper), 100 = bottom (forwards)
// x: 0 = left, 50 = center, 100 = right
const FORMATIONS = {
  '4-3-3': {
    name: '4-3-3',
    description: 'Balanced system with wide wingers, strong pressing, and stable midfield triangle.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},   // Goalkeeper
      {x: 20, y: 30, role: 'DEF', number: 2},  // Left back
      {x: 40, y: 30, role: 'DEF', number: 3},  // Left center back
      {x: 60, y: 30, role: 'DEF', number: 4},  // Right center back
      {x: 80, y: 30, role: 'DEF', number: 5},  // Right back
      {x: 30, y: 55, role: 'MID', number: 6},  // Left midfielder
      {x: 50, y: 55, role: 'MID', number: 8},  // Center midfielder
      {x: 70, y: 55, role: 'MID', number: 7},  // Right midfielder
      {x: 20, y: 80, role: 'FWD', number: 11}, // Left winger
      {x: 50, y: 80, role: 'FWD', number: 9},  // Center forward
      {x: 80, y: 80, role: 'FWD', number: 10}  // Right winger
    ]
  },
  '4-2-3-1': {
    name: '4-2-3-1',
    description: 'Modern standard. Double pivot gives control and stability, front four supports flexible attacking.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 40, y: 50, role: 'MID', number: 6},
      {x: 60, y: 50, role: 'MID', number: 8},
      {x: 30, y: 70, role: 'MID', number: 7},
      {x: 50, y: 70, role: 'MID', number: 10},
      {x: 70, y: 70, role: 'MID', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9}
    ]
  },
  '4-4-2': {
    name: '4-4-2 (Flat)',
    description: 'Simple structure, strong wide play, natural partnerships. Classic but still effective.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 20, y: 55, role: 'MID', number: 6},
      {x: 40, y: 55, role: 'MID', number: 8},
      {x: 60, y: 55, role: 'MID', number: 7},
      {x: 80, y: 55, role: 'MID', number: 11},
      {x: 40, y: 80, role: 'FWD', number: 9},
      {x: 60, y: 80, role: 'FWD', number: 10}
    ]
  },
  '4-1-2-1-2': {
    name: '4-1-2-1-2',
    description: 'Narrow midfield with full-backs providing width; strong central combinations.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 50, y: 45, role: 'MID', number: 6},
      {x: 40, y: 60, role: 'MID', number: 8},
      {x: 60, y: 60, role: 'MID', number: 7},
      {x: 50, y: 70, role: 'MID', number: 10},
      {x: 40, y: 85, role: 'FWD', number: 9},
      {x: 60, y: 85, role: 'FWD', number: 11}
    ]
  },
  '4-1-4-1': {
    name: '4-1-4-1',
    description: 'Good for compactness and counter-control; single striker supported by two advanced CMs.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 50, y: 48, role: 'MID', number: 6},
      {x: 20, y: 62, role: 'MID', number: 7},
      {x: 40, y: 62, role: 'MID', number: 8},
      {x: 60, y: 62, role: 'MID', number: 10},
      {x: 80, y: 62, role: 'MID', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9}
    ]
  },
  '4-5-1': {
    name: '4-5-1',
    description: 'Defensive midfield overload; striker isolated but transitions can be strong.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 20, y: 55, role: 'MID', number: 6},
      {x: 40, y: 55, role: 'MID', number: 8},
      {x: 50, y: 55, role: 'MID', number: 7},
      {x: 60, y: 55, role: 'MID', number: 10},
      {x: 80, y: 55, role: 'MID', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9}
    ]
  },
  '4-3-2-1': {
    name: '4-3-2-1',
    description: 'Central overload with two attacking mids behind a lone striker.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 30, y: 55, role: 'MID', number: 6},
      {x: 50, y: 55, role: 'MID', number: 8},
      {x: 70, y: 55, role: 'MID', number: 7},
      {x: 40, y: 75, role: 'MID', number: 10},
      {x: 60, y: 75, role: 'MID', number: 11},
      {x: 50, y: 90, role: 'FWD', number: 9}
    ]
  },
  '4-1-2-3': {
    name: '4-1-2-3',
    description: 'Single pivot, two advanced midfielders; dynamic and possession-friendly.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 50, y: 48, role: 'MID', number: 6},
      {x: 40, y: 65, role: 'MID', number: 8},
      {x: 60, y: 65, role: 'MID', number: 7},
      {x: 20, y: 85, role: 'FWD', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9},
      {x: 80, y: 85, role: 'FWD', number: 10}
    ]
  },
  '3-5-2': {
    name: '3-5-2',
    description: 'Wing-backs provide width, two strikers give constant threat. Strong midfield control.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 15, y: 55, role: 'MID', number: 5},
      {x: 35, y: 55, role: 'MID', number: 6},
      {x: 50, y: 55, role: 'MID', number: 8},
      {x: 65, y: 55, role: 'MID', number: 7},
      {x: 85, y: 55, role: 'MID', number: 11},
      {x: 40, y: 80, role: 'FWD', number: 9},
      {x: 60, y: 80, role: 'FWD', number: 10}
    ]
  },
  '3-4-3': {
    name: '3-4-3',
    description: 'Aggressive pressing system with high wing-backs and three forwards.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 20, y: 55, role: 'MID', number: 5},
      {x: 40, y: 55, role: 'MID', number: 6},
      {x: 60, y: 55, role: 'MID', number: 7},
      {x: 80, y: 55, role: 'MID', number: 8},
      {x: 20, y: 80, role: 'FWD', number: 11},
      {x: 50, y: 80, role: 'FWD', number: 9},
      {x: 80, y: 80, role: 'FWD', number: 10}
    ]
  },
  '3-4-1-2': {
    name: '3-4-1-2',
    description: 'Playmaker behind two strikers; similar to 3-5-2 but more attacking through the middle.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 20, y: 55, role: 'MID', number: 5},
      {x: 40, y: 55, role: 'MID', number: 6},
      {x: 60, y: 55, role: 'MID', number: 7},
      {x: 80, y: 55, role: 'MID', number: 8},
      {x: 50, y: 70, role: 'MID', number: 10},
      {x: 40, y: 85, role: 'FWD', number: 9},
      {x: 60, y: 85, role: 'FWD', number: 11}
    ]
  },
  '3-3-3-1': {
    name: '3-3-3-1',
    description: 'Ultra-aggressive, man-oriented, high-pressing vertical system.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 30, y: 50, role: 'MID', number: 5},
      {x: 50, y: 50, role: 'MID', number: 6},
      {x: 70, y: 50, role: 'MID', number: 7},
      {x: 30, y: 70, role: 'MID', number: 8},
      {x: 50, y: 70, role: 'MID', number: 10},
      {x: 70, y: 70, role: 'MID', number: 11},
      {x: 50, y: 90, role: 'FWD', number: 9}
    ]
  },
  '3-2-4-1': {
    name: '3-2-4-1',
    description: 'Two pivots + two attacking mids; complete control through central zones.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 40, y: 50, role: 'MID', number: 5},
      {x: 60, y: 50, role: 'MID', number: 6},
      {x: 20, y: 70, role: 'MID', number: 7},
      {x: 40, y: 70, role: 'MID', number: 8},
      {x: 60, y: 70, role: 'MID', number: 10},
      {x: 80, y: 70, role: 'MID', number: 11},
      {x: 50, y: 90, role: 'FWD', number: 9}
    ]
  },
  '5-3-2': {
    name: '5-3-2',
    description: 'Low block with two strikers for counterattacks.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 15, y: 30, role: 'DEF', number: 2},
      {x: 35, y: 30, role: 'DEF', number: 3},
      {x: 50, y: 30, role: 'DEF', number: 4},
      {x: 65, y: 30, role: 'DEF', number: 5},
      {x: 85, y: 30, role: 'DEF', number: 6},
      {x: 35, y: 60, role: 'MID', number: 7},
      {x: 50, y: 60, role: 'MID', number: 8},
      {x: 65, y: 60, role: 'MID', number: 10},
      {x: 40, y: 85, role: 'FWD', number: 9},
      {x: 60, y: 85, role: 'FWD', number: 11}
    ]
  },
  '5-4-1': {
    name: '5-4-1',
    description: 'Classic deep defensive block, compact, hard to break down.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 15, y: 30, role: 'DEF', number: 2},
      {x: 35, y: 30, role: 'DEF', number: 3},
      {x: 50, y: 30, role: 'DEF', number: 4},
      {x: 65, y: 30, role: 'DEF', number: 5},
      {x: 85, y: 30, role: 'DEF', number: 6},
      {x: 20, y: 60, role: 'MID', number: 7},
      {x: 40, y: 60, role: 'MID', number: 8},
      {x: 60, y: 60, role: 'MID', number: 10},
      {x: 80, y: 60, role: 'MID', number: 11},
      {x: 50, y: 90, role: 'FWD', number: 9}
    ]
  },
  '5-2-3': {
    name: '5-2-3',
    description: 'Strong defensive width with a fast front three for transitions.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 15, y: 30, role: 'DEF', number: 2},
      {x: 35, y: 30, role: 'DEF', number: 3},
      {x: 50, y: 30, role: 'DEF', number: 4},
      {x: 65, y: 30, role: 'DEF', number: 5},
      {x: 85, y: 30, role: 'DEF', number: 6},
      {x: 40, y: 55, role: 'MID', number: 7},
      {x: 60, y: 55, role: 'MID', number: 8},
      {x: 20, y: 85, role: 'FWD', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9},
      {x: 80, y: 85, role: 'FWD', number: 10}
    ]
  },
  '4-3-1-2': {
    name: '4-3-1-2',
    description: 'Narrow midfield diamond with a dedicated playmaker behind two forwards.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 30, y: 55, role: 'MID', number: 6},
      {x: 50, y: 55, role: 'MID', number: 8},
      {x: 70, y: 55, role: 'MID', number: 7},
      {x: 50, y: 70, role: 'MID', number: 10},
      {x: 40, y: 85, role: 'FWD', number: 9},
      {x: 60, y: 85, role: 'FWD', number: 11}
    ]
  },
  '4-2-1-3': {
    name: '4-2-1-3',
    description: 'Two pivots holding, one advanced CM, and a front three — great for vertical attacks.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 40, y: 50, role: 'MID', number: 6},
      {x: 60, y: 50, role: 'MID', number: 8},
      {x: 50, y: 65, role: 'MID', number: 7},
      {x: 20, y: 85, role: 'FWD', number: 11},
      {x: 50, y: 85, role: 'FWD', number: 9},
      {x: 80, y: 85, role: 'FWD', number: 10}
    ]
  },
  '4-6-0': {
    name: '4-6-0 (False 9)',
    description: 'No traditional striker; rotation and movement in the final third.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 20, y: 30, role: 'DEF', number: 2},
      {x: 40, y: 30, role: 'DEF', number: 3},
      {x: 60, y: 30, role: 'DEF', number: 4},
      {x: 80, y: 30, role: 'DEF', number: 5},
      {x: 20, y: 60, role: 'MID', number: 6},
      {x: 35, y: 60, role: 'MID', number: 7},
      {x: 50, y: 60, role: 'MID', number: 8},
      {x: 65, y: 60, role: 'MID', number: 10},
      {x: 80, y: 60, role: 'MID', number: 11},
      {x: 50, y: 80, role: 'MID', number: 9}  // False 9
    ]
  },
  '3-6-1': {
    name: '3-6-1',
    description: 'Strong midfield block controlling tempo; one striker supported by fluid central players.',
    positions: [
      {x: 50, y: 10, role: 'GK', number: 1},
      {x: 30, y: 30, role: 'DEF', number: 2},
      {x: 50, y: 30, role: 'DEF', number: 3},
      {x: 70, y: 30, role: 'DEF', number: 4},
      {x: 20, y: 55, role: 'MID', number: 5},
      {x: 35, y: 55, role: 'MID', number: 6},
      {x: 50, y: 55, role: 'MID', number: 8},
      {x: 65, y: 55, role: 'MID', number: 7},
      {x: 80, y: 55, role: 'MID', number: 10},
      {x: 50, y: 70, role: 'MID', number: 11},
      {x: 50, y: 90, role: 'FWD', number: 9}
    ]
  }
};

class TacticalEditor {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.image = null;
    this.originalImageData = null;
    this.trueOriginalImageData = null; // The very first background loaded, never merged
    this.callbackId = null;
    this.currentTool = 'select';
    this.currentColor = '#FF0000';
    this.isDrawing = false;
    this.startX = 0;
    this.startY = 0;
    this.currentX = 0;
    this.currentY = 0;
    this.drawings = []; // All drawings in a single array
    this.selectedDrawings = []; // Array of selected drawing indices
    
    // Reference canvas size for scaling objects (full field typical size)
    this.referenceCanvasWidth = 1000;
    this.referenceCanvasHeight = 600;
    
    // Slides/Phases system
    this.slides = []; // Array of slides, each slide has its own drawings
    this.currentSlideIndex = 0; // Current active slide
    this.isPlayingAllSlides = false; // Whether we're playing through all slides
    this.currentLoadedBackground = null; // Track which slide's background is currently loaded (slide index or 'default')
    this.dragOffsets = []; // Array of drag offsets for multiple selections
    this.lastMousePos = null; // Last mouse position for smooth dragging
    this.isDragging = false;
    this.selectionRect = null; // {startX, startY, endX, endY} for area selection
    this.curveIntensity = 1.0; // Curve intensity multiplier
    this.curveType = 'quadratic'; // 'quadratic' or 'cubic'
    this.curveDirection = 'auto'; // 'auto', 'left', or 'right'
    this.opacity = 1.0; // Line opacity (0.0 to 1.0)
    this.lineWidth = 2; // Line thickness in pixels
    this.curveControlPoints = []; // For cubic curves, array of control points
    this.fillColor = '#FFFFFF'; // Fill color for shapes
    this.fillOpacity = 0.0; // Fill opacity (0.0 to 1.0) - default transparent
    this.fillStyle = 'solid'; // Fill style: 'solid' or 'crosshatch'
    this.eventName = ''; // Event name for shapes
    this.lineStyle = 'solid'; // Line style: 'solid', 'dashed', or 'dotted'
    this.shapeAnimationType = null; // Shape animation type: null, 'fade', 'scale', 'spin', 'slideLeft', 'slideRight'

    // Highlight properties
    this.highlightEnabled = false; // Whether highlight is enabled
    this.highlightColor = null; // Custom highlight color (null means use shape's line color)
    this.highlightThickness = 3; // Highlight border thickness in pixels
    this.highlightStyle = 'solid'; // Highlight style: 'solid' or 'blurred'
    this.startCap = 'none'; // Start point style: 'none', 'line', 'triangle', 'reversed', 'circle', 'diamond', 'perpendicular'
    this.endCap = 'none'; // End point style: 'none', 'line', 'triangle', 'reversed', 'circle', 'diamond', 'perpendicular'
    this.fontWeight = 400; // Font weight for text: 100 (thin), 400 (normal), 700 (bold)
    this.tshirtNumber = 10; // Default t-shirt number
    this.tshirtSurname = ''; // Default t-shirt surname
    this.tshirtDesign = 'solid'; // Default t-shirt design
    this.tshirtSecondColor = '#000000'; // Default t-shirt secondary color
    this.ballNumber = null; // Ball number is optional
    this.currentFormation = '4-3-3'; // Default formation
    this.formationSide = 'right'; // Default side: 'left' or 'right'
    this.formationKit = 'home'; // Default kit: 'home' or 'away'
    this.formationColor = '#FFFFFF'; // Default formation t-shirt color
    this.formationTeam = null; // Selected team for formation
    this.currentAnalysisId = null; // Current analysis ID for loading teams
    this.history = [];
    this.historyIndex = -1;
    this.zoom = 1;
    this.textInput = null;
    this.polygonPoints = [];
    this.curveControlPoint = null;
    this.resizingHandle = null; // Which resize handle is being dragged: 'tl', 'tr', 'bl', 'br', 'rotate', 'move'
    this.resizeStartBounds = null; // Bounds when resize started
    this.resizeStartDrawing = null; // Drawing state when resize started
    this.rotationStartAngle = null; // Starting angle when rotation began
    this.rotationStartDrawingAngle = null; // Drawing's rotation when rotation began
    this.lastMoveHandlePos = null; // Last position when dragging move handle
    this.draggingControlPoint = null; // For curves: which control point is being dragged: 'cp0', 'cp1', or the control point index
    this.draggingControlPointDrawing = null; // The drawing whose control point is being dragged
    this.clipboard = []; // Clipboard for copy/paste operations
    this.showZoneOverlay = false; // Toggle for 18-zone overlay
    this.editingFormationName = null; // Name of formation being edited (null if creating new)
    
    // Animation properties
    this.animationSpeed = 1.0; // Animation speed multiplier
    this.animationLoop = false; // Whether to loop animations
    this.isAnimating = false; // Whether animation is currently playing
    this.animationStartTime = null; // When animation started
    this.animationPausedTime = null; // Time when paused (for resume)
    this.animatedObjects = []; // Objects currently being animated
    this.animatedShapes = []; // Shapes with animations currently playing
    this.animPathDuration = 2.0; // Default path duration in seconds
    this.animPathDelay = 0; // Default path delay in seconds
    this.animPathEasing = 'easeOut'; // Default easing function
    this.animPathSpeed = 1.0; // Default path speed multiplier
    this.draggingWaypoint = null; // Index of waypoint being dragged, or null
    this.draggingWaypointPath = null; // Index of animpath drawing containing the dragged waypoint
    this.selectedWaypoint = null; // {pathIndex, waypointIndex} of selected waypoint
    this.hoveredWaypoint = null; // {pathIndex, waypointIndex} of hovered waypoint
    this.pendingMovementTarget = null; // Object index waiting for movement path to be drawn
    
    // Image placement properties
    this.imagePlacementX = null;
    this.imagePlacementY = null;
    this.centerImageOnLoad = false;
    
    // Spray tool properties
    this.sprayRadius = 20; // Spray radius in pixels
    this.sprayDensity = 10; // Number of particles per spray event
    this.sprayParticleSize = 2; // Size of each spray particle
    
    // Heat map tool properties
    this.heatmapRadius = 20; // Heat map radius in pixels (same as spray)
    this.heatmapGridSize = 4; // Grid cell size in pixels for lightweight storage
    this.heatmapIntensityIncrement = 0.022; // How much intensity increases per frame while holding (15% faster than 0.02)
    this.heatmapMaxIntensity = 1.0; // Maximum intensity value
    this.heatmapLastUpdateTime = 0; // For throttling updates
    this.activeHeatmapIndices = []; // Indices of heat maps currently being modified (for merging)
    
    // SVG cache for preloaded SVG icons
    this.svgCache = {};
    
    // Grouping system
    this.nextGroupId = 1; // Auto-incrementing group ID
    
    // GIF export flag
    this.isExportingGif = false; // Flag to skip animation paths during GIF export
    
    // Canvas rotation (0, 90, 180, 270 degrees)
    this.canvasRotation = 0; // Current rotation angle in degrees
    this.originalCanvasWidth = null; // Original canvas width before rotation
    this.originalCanvasHeight = null; // Original canvas height before rotation
    
    this.init();
  }

  init() {
    this.canvas = document.getElementById('editorCanvas');
    if (!this.canvas) return;

    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    this.setupEventListeners();
    
    // Preload all SVG icons into cache
    this.preloadSvgIcons();
    
    // Run migration to move teams to global storage
    this.migrateTeamsToGlobalStorage();
    
    // Add window resize listener to maintain canvas proportions
    window.addEventListener('resize', () => {
      this.updateCanvasSize();
    });
    
    // Add ResizeObserver to watch canvas container for size changes
    // This handles toolbar toggles and other layout changes
    const canvasContainer = this.canvas.parentElement;
    if (canvasContainer && window.ResizeObserver) {
      this.resizeObserver = new ResizeObserver(() => {
        if (this.image) {
          this.updateCanvasSize();
        }
      });
      this.resizeObserver.observe(canvasContainer);
    }

    // Handle visibility changes - redraw when window becomes visible again
    // This prevents canvas content from disappearing when switching apps
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.image) {
        // Window became visible - ensure canvas is redrawn
        console.log('Editor: Window became visible, redrawing canvas');
        // Use requestAnimationFrame to ensure canvas is ready
        requestAnimationFrame(() => {
          this.redraw();
        });
      }
    });

    // Handle window focus - redraw when window regains focus
    window.addEventListener('focus', () => {
      if (this.image) {
        console.log('Editor: Window gained focus, redrawing canvas');
        requestAnimationFrame(() => {
          this.redraw();
        });
      }
    });

    // Handle canvas context loss (can happen when browser reclaims resources)
    this.canvas.addEventListener('contextlost', (e) => {
      console.warn('Editor: Canvas context lost, preventing default');
      e.preventDefault();
    });

    this.canvas.addEventListener('contextrestored', () => {
      console.log('Editor: Canvas context restored, redrawing');
      // Reload the image and redraw when context is restored
      if (this.originalImageData || this.trueOriginalImageData) {
        const imageToLoad = this.trueOriginalImageData || this.originalImageData;
        this.loadImage(imageToLoad).then(() => {
          this.redraw();
        }).catch(err => {
          console.error('Editor: Failed to reload image after context restoration:', err);
        });
      }
    });

    // Initialize with select tool
    this.selectTool('select');
    
    // Initialize button states
    this.updateButtonStates();
    
    // Initialize formation description
    this.updateFormationDescription();

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      // Ignore keyboard shortcuts when user is typing in an input field
      const activeElement = document.activeElement;
      const isInputFocused = activeElement && (
        activeElement.tagName === 'INPUT' || 
        activeElement.tagName === 'TEXTAREA' || 
        activeElement.tagName === 'SELECT' ||
        activeElement.isContentEditable
      );
      
      if ((e.key === 'Delete' || e.key === 'Backspace') && this.currentTool === 'select' && !isInputFocused) {
        // Delete selected waypoint if one is selected
        if (this.selectedWaypoint) {
          const drawing = this.drawings[this.selectedWaypoint.pathIndex];
          if (drawing && drawing.waypoints && drawing.waypoints[this.selectedWaypoint.waypointIndex]) {
            drawing.waypoints.splice(this.selectedWaypoint.waypointIndex, 1);
            this.selectedWaypoint = null;
            this.saveState();
            this.redraw();
            e.preventDefault();
            return;
          }
        }
        
        // Delete selected drawing if no waypoint is selected
        if (this.selectedDrawings.length > 0) {
          e.preventDefault();
          this.deleteSelectedDrawing();
        }
      }
      
      // Copy shortcut (Ctrl+C or Cmd+C)
      if ((e.ctrlKey || e.metaKey) && e.key === 'c' && this.selectedDrawings.length > 0 && this.currentTool === 'select' && !isInputFocused) {
        e.preventDefault();
        this.copy();
      }
      
      // Paste shortcut (Ctrl+V or Cmd+V)
      if ((e.ctrlKey || e.metaKey) && e.key === 'v' && this.clipboard.length > 0 && !isInputFocused) {
        e.preventDefault();
        this.paste();
      }
      
      // Undo shortcut (Ctrl+Z or Cmd+Z)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey && !isInputFocused) {
        e.preventDefault();
        this.undo();
      }
      
      // Redo shortcut (Ctrl+Shift+Z or Cmd+Shift+Z)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'z' && !isInputFocused) {
        e.preventDefault();
        this.redo();
      }
      
      // Cut/Delete shortcut (Ctrl+X or Cmd+X)
      if ((e.ctrlKey || e.metaKey) && e.key === 'x' && this.selectedDrawings.length > 0 && this.currentTool === 'select' && !isInputFocused) {
        e.preventDefault();
        this.copy(); // Copy first
        this.deleteSelectedDrawing(); // Then delete
      }
    });
  }


  setupEventListeners() {
    // Setup tool groups
    this.setupToolGroups();
    
    // Tool selection
    document.querySelectorAll('.editor-tool-btn[data-tool]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tool = e.currentTarget.dataset.tool;
        
        // Special handling for image tool - directly open file selection
        if (tool === 'image') {
          // Directly trigger file input - image will be centered after loading
          const imageInput = document.getElementById('editorImageInput');
          if (imageInput) {
            // Set flag to center image after loading
            this.centerImageOnLoad = true;
            imageInput.click();
          }
          
          // Don't change tool, stay on current tool
          return;
        }
        
        this.selectTool(tool);
        
        // Close any open tool groups after selecting a tool
        document.querySelectorAll('.editor-tool-group').forEach(g => {
          g.classList.remove('expanded');
        });
      });
    });

    // Canvas events
    this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
    this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
    this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e));
    this.canvas.addEventListener('mouseleave', (e) => {
      this.handleMouseUp(e);
      // Clear hover feedback when mouse leaves canvas
      if (this.hoveredWaypoint) {
        this.hoveredWaypoint = null;
        this.redraw();
      }
    });
    this.canvas.addEventListener('contextmenu', (e) => this.handleRightClick(e)); // Right-click for polygon cancel
    this.canvas.addEventListener('dblclick', (e) => this.handleDoubleClick(e));

    // Top bar buttons
    const colorPickerBtn = document.getElementById('editorColorPickerBtn');
    if (colorPickerBtn) {
      colorPickerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const picker = document.getElementById('editorColorPicker');
        if (picker) {
          picker.classList.toggle('hidden');
          console.log('Color picker toggled, hidden:', picker.classList.contains('hidden'));
        } else {
          console.error('Color picker element not found');
        }
      });
    } else {
      console.error('Color picker button not found');
    }

    document.getElementById('editorColorInput')?.addEventListener('input', (e) => {
      const newColor = e.target.value;
      this.currentColor = newColor;
      
      // Sync with line color input
      const lineColorInput = document.getElementById('editorLineColor');
      if (lineColorInput) {
        lineColorInput.value = newColor;
      }
      
      // Update selected drawings' color if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].color = newColor;
          }
        });
        this.saveState();
        this.redraw();
      }
      
      this.updateColorPresets();
    });
    
    document.getElementById('editorColorInput')?.addEventListener('change', (e) => {
      const newColor = e.target.value;
      this.currentColor = newColor;
      
      // Sync with line color input
      const lineColorInput = document.getElementById('editorLineColor');
      if (lineColorInput) {
        lineColorInput.value = newColor;
      }
      
      // Update selected drawings' color if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].color = newColor;
          }
        });
        this.saveState();
        this.redraw();
      }
      
      this.updateColorPresets();
    });

    document.querySelectorAll('.editor-color-preset').forEach(preset => {
      preset.addEventListener('click', (e) => {
        e.stopPropagation();
        const newColor = e.currentTarget.dataset.color;
        this.currentColor = newColor;
        const colorInput = document.getElementById('editorColorInput');
        const lineColorInput = document.getElementById('editorLineColor');
        if (colorInput) {
          colorInput.value = this.currentColor;
        }
        if (lineColorInput) {
          lineColorInput.value = this.currentColor;
        }
        
        // Update selected drawings' color if any are selected
        if (this.selectedDrawings.length > 0) {
          this.selectedDrawings.forEach(index => {
            if (this.drawings[index]) {
              this.drawings[index].color = newColor;
            }
          });
          this.saveState();
          this.redraw();
        }
        
        this.updateColorPresets();
        // Close picker after selection
        const picker = document.getElementById('editorColorPicker');
        if (picker) {
          picker.classList.add('hidden');
        }
      });
    });

    // Line color in style control panel (synced with main color picker)
    document.getElementById('editorLineColor')?.addEventListener('input', (e) => {
      const newColor = e.target.value;
      this.currentColor = newColor;
      
      // Sync with main color picker
      const mainColorInput = document.getElementById('editorColorInput');
      if (mainColorInput) {
        mainColorInput.value = newColor;
      }
      
      // Update selected drawings' color if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].color = newColor;
          }
        });
        this.saveState();
        this.redraw();
      }
      
      this.updateColorPresets();
    });

    // Event name dropdown - populate with all events
    this.populateEventNameDropdown();
    
    // Custom event name dropdown
    this.initCustomEventDropdown();
    
    // Custom event modal handlers
    this.initCustomEventModal();
    
    // Group/ungroup buttons
    document.getElementById('editorGroupBtn')?.addEventListener('click', () => this.groupSelected());
    document.getElementById('editorUngroupBtn')?.addEventListener('click', () => this.ungroupSelected());

    // Close buttons for control panels
    document.getElementById('editorStyleControlClose')?.addEventListener('click', () => {
      const styleToolbar = document.getElementById('editorStyleToolbar');
      if (styleToolbar) {
        styleToolbar.classList.add('hidden');
        // ResizeObserver will automatically handle canvas resize
      }
    });
    
    // Curve settings close button removed - now part of right toolbar
    
    document.getElementById('editorFontSizeControlClose')?.addEventListener('click', () => {
      const fontSizeControl = document.getElementById('editorFontSizeControl');
      if (fontSizeControl) {
        fontSizeControl.classList.add('hidden');
      }
    });
    
    
    // Color presets in style control (small inline presets)
    document.querySelectorAll('.editor-color-preset-small').forEach(preset => {
      preset.addEventListener('click', (e) => {
        e.stopPropagation();
        const newColor = e.currentTarget.dataset.color;
        this.currentColor = newColor;
        
        // Update all color inputs
        const colorInput = document.getElementById('editorColorInput');
        const lineColorInput = document.getElementById('editorLineColor');
        if (colorInput) {
          colorInput.value = this.currentColor;
        }
        if (lineColorInput) {
          lineColorInput.value = this.currentColor;
        }
        
        // Update selected drawings' color if any are selected
        if (this.selectedDrawings.length > 0) {
          this.selectedDrawings.forEach(index => {
            if (this.drawings[index]) {
              this.drawings[index].color = newColor;
            }
          });
          this.saveState();
          this.redraw();
        }
        
        this.updateColorPresets();
      });
    });

    // Formation selection dropdown
    document.getElementById('editorFormationSelect')?.addEventListener('change', (e) => {
      this.currentFormation = e.target.value;
      this.updateFormationDescription();
    });

    // Formation side radio buttons
    document.querySelectorAll('input[name="formationSide"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.formationSide = e.target.value;
        // Update visual state
        this.updateKitRadioStates();
      });
    });

    // Formation team selector
    document.getElementById('editorFormationTeamSelect')?.addEventListener('change', (e) => {
      const teamName = e.target.value;
      this.formationTeam = teamName || null;
      
      // Show/hide kit selector based on team selection
      const kitRow = document.getElementById('editorFormationKitRow');
      if (kitRow) {
        kitRow.style.display = teamName ? 'flex' : 'none';
      }
      
      // Sync player panel team selector
      const playerTeamSelect = document.getElementById('editorPlayerTeamSelect');
      if (playerTeamSelect && teamName) {
        playerTeamSelect.value = teamName;
        // Trigger change event to update UI
        playerTeamSelect.dispatchEvent(new Event('change'));
        this.loadPlayersForTeam(teamName);
        
        // Show squad section and load configs
        const configSection = document.getElementById('editorSquadConfigSection');
        if (configSection) {
          configSection.style.display = 'block';
          this.populateSquadConfigSelector(teamName);
          // Re-setup click handlers now that section is visible
          setTimeout(() => {
            this.setupSquadClickHandlers();
          }, 100);
        }
        
        // Update selected team display
        this.updateEditorSelectedTeamDisplay();
      }
      
      if (teamName) {
        // Load team colors and formation
        this.loadTeamColors(teamName);
        this.loadTeamFormation(teamName);
      } else {
        // Reset to custom color and solid design
        const colorInput = document.getElementById('editorFormationColor');
        if (colorInput) {
          this.formationColor = colorInput.value;
        }
        this.tshirtDesign = 'solid';
        this.tshirtSecondColor = '#000000';
        this.updateFormationTshirtPreview();
      }
    });

    // Formation kit selector (home/away)
    document.querySelectorAll('input[name="formationKit"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.formationKit = e.target.value;
        // Update team color if team is selected
        if (this.formationTeam) {
          this.loadTeamColors(this.formationTeam);
        }
        // Update visual state
        this.updateKitRadioStates();
      });
    });
    
    // Initial state for kit radios
    this.updateKitRadioStates();

    // Formation color picker (hidden, triggered by canvas click)
    const formationColorInput = document.getElementById('editorFormationColor');
    const formationTshirtContainer = document.getElementById('editorFormationTshirtContainer');
    const formationTshirtPreview = document.getElementById('editorFormationTshirtPreview');
    
    if (formationColorInput && formationTshirtContainer && formationTshirtPreview) {
      // Click on t-shirt preview to open color picker
      formationTshirtContainer.addEventListener('click', () => {
        formationColorInput.click();
      });
      
      // Add hover effects
      formationTshirtContainer.addEventListener('mouseenter', () => {
        formationTshirtContainer.style.borderColor = '#30363d';
        formationTshirtContainer.style.background = '#161b22';
      });
      formationTshirtContainer.addEventListener('mouseleave', () => {
        formationTshirtContainer.style.borderColor = '#21262d';
        formationTshirtContainer.style.background = '#0d1117';
      });
      
      // Update preview when color changes
      formationColorInput.addEventListener('input', (e) => {
        this.formationColor = e.target.value;
        this.updateFormationTshirtPreview();
      });
      
      formationColorInput.addEventListener('change', (e) => {
        this.formationColor = e.target.value;
        this.updateFormationTshirtPreview();
      });
      
      // Initial preview (delay to ensure canvas is ready)
      setTimeout(() => {
        this.updateFormationTshirtPreview();
      }, 100);
    }
    
    // Load teams when editor initializes (will be called after setupEventListeners completes)
    // Delay to ensure DOM is ready
    setTimeout(() => {
      this.loadTeams();
      this.initPlayerPanel();
    }, 100);

    document.getElementById('editorCopyBtn')?.addEventListener('click', () => this.copy());
    document.getElementById('editorPasteBtn')?.addEventListener('click', () => this.paste());
    document.getElementById('editorUndoBtn')?.addEventListener('click', () => this.undo());
    document.getElementById('editorRedoBtn')?.addEventListener('click', () => this.redo());
    document.getElementById('editorSaveBtn')?.addEventListener('click', () => this.save());
    document.getElementById('editorCancelBtn')?.addEventListener('click', () => this.cancel());
    
    // Save custom formation
    document.getElementById('editorSaveFormationBtn')?.addEventListener('click', () => this.openSaveFormationModal());
    document.getElementById('editorCloseSaveFormationModal')?.addEventListener('click', () => this.closeSaveFormationModal());
    document.getElementById('editorConfirmSaveFormationBtn')?.addEventListener('click', () => this.saveCustomFormation());
    document.getElementById('editorDeleteFormationBtn')?.addEventListener('click', () => this.deleteCustomFormation());
    const formationNameInput = document.getElementById('editorFormationNameInput');
    if (formationNameInput) {
      formationNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.saveCustomFormation();
        } else if (e.key === 'Escape') {
          this.closeSaveFormationModal();
        }
      });
    }
    
    // Zone overlay toggle
    document.getElementById('editorZoneOverlayBtn')?.addEventListener('click', () => {
      // Check if this is a goal image - zones are not applicable for goal schemes
      const isGoalImage = this.image && this.image.src && (this.image.src.includes('goal.svg') || this.image.src.includes('goal'));
      if (isGoalImage) {
        // Don't allow enabling zones for goal images
        this.showZoneOverlay = false;
        const btn = document.getElementById('editorZoneOverlayBtn');
        if (btn) {
          btn.classList.remove('active');
        }
        this.redraw();
        return;
      }
      
      this.showZoneOverlay = !this.showZoneOverlay;
      const btn = document.getElementById('editorZoneOverlayBtn');
      if (btn) {
        btn.classList.toggle('active', this.showZoneOverlay);
      }
      this.redraw();
    });
    
    // Animation controls
    document.getElementById('editorPlayBtn')?.addEventListener('click', () => this.playAnimation());
    document.getElementById('editorStopBtn')?.addEventListener('click', () => this.stopAnimation());
    document.getElementById('editorBackBtn')?.addEventListener('click', () => this.resetToOriginalPositions());
    
    // Slides controls
    document.getElementById('editorAddSlideBtn')?.addEventListener('click', () => this.addSlide());
    document.getElementById('editorPlayAllSlidesBtn')?.addEventListener('click', () => this.playAllSlides());
    document.getElementById('editorSlidesPanelToggle')?.addEventListener('click', () => this.toggleSlidesPanel());
    document.getElementById('editorPhaseBenchToggle')?.addEventListener('click', () => this.togglePhaseBenchPanel());
    document.querySelector('.editor-phase-bench-header')?.addEventListener('click', (e) => {
      // Only toggle if clicking on the header itself, not the toggle button (to avoid double toggle)
      if (e.target.closest('.editor-phase-bench-toggle')) return;
      this.togglePhaseBenchPanel();
    });
    document.getElementById('editorExportGifBtn')?.addEventListener('click', () => this.exportAsGif());
    
    // Phase comment input
    const phaseCommentInput = document.getElementById('editorPhaseComment');
    if (phaseCommentInput) {
      phaseCommentInput.addEventListener('input', () => {
        // Check character limit
        if (phaseCommentInput.value.length > 4000) {
          // Truncate to 4000 characters
          phaseCommentInput.value = phaseCommentInput.value.substring(0, 4000);
          // Show notification
          showNotification('Phase comment limit reached (4000 characters maximum)', 'warning', 3000);
        }
        
        // Save comment to current slide when user types
        if (this.slides[this.currentSlideIndex]) {
          this.slides[this.currentSlideIndex].comment = phaseCommentInput.value || '';
          this.saveState();
        }
      });
      
      // Handle paste events to catch text that exceeds limit
      phaseCommentInput.addEventListener('paste', (e) => {
        // Allow the paste to happen, then check in the next tick
        setTimeout(() => {
          if (phaseCommentInput.value.length > 4000) {
            phaseCommentInput.value = phaseCommentInput.value.substring(0, 4000);
            showNotification('Phase comment limit reached (4000 characters maximum)', 'warning', 3000);
          }
        }, 0);
      });
      
      phaseCommentInput.addEventListener('blur', () => {
        // Ensure comment is saved when user leaves the input
        this.saveCurrentSlide();
      });
    }
    
    // Bench player management
    // Bench removed from phase details - now handled in squad configuration
    
    
    document.getElementById('editorAnimLoop')?.addEventListener('change', (e) => {
      this.animationLoop = e.target.checked;
    });
    
    // Animation path properties
    document.getElementById('editorAnimDuration')?.addEventListener('input', (e) => {
      this.animPathDuration = parseFloat(e.target.value);
      const durationValue = document.getElementById('editorAnimDurationValue');
      if (durationValue) {
        durationValue.textContent = this.animPathDuration.toFixed(1) + 's';
      }
      this.updateSelectedAnimPath('duration', this.animPathDuration);
    });
    
    document.getElementById('editorAnimDelay')?.addEventListener('input', (e) => {
      this.animPathDelay = parseFloat(e.target.value);
      const delayValue = document.getElementById('editorAnimDelayValue');
      if (delayValue) {
        delayValue.textContent = this.animPathDelay.toFixed(2) + 's';
      }
      this.updateSelectedAnimPath('delay', this.animPathDelay);
    });
    
    document.getElementById('editorAnimEasing')?.addEventListener('change', (e) => {
      this.animPathEasing = e.target.value;
      this.updateSelectedAnimPath('easing', this.animPathEasing);
    });
    
    
    // Shape animation control
    document.getElementById('editorShapeAnimation')?.addEventListener('change', (e) => {
      const newAnimationType = e.target.value || null;
      this.shapeAnimationType = newAnimationType;
      
      // Update selected drawings' animation type if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].animationType = newAnimationType;
          }
        });
        this.saveState();
        this.redraw();
      }
    });
    
    // Add Movement buttons for ball and t-shirt
    document.getElementById('editorAddBallMovementBtn')?.addEventListener('click', () => this.startAddMovement());
    document.getElementById('editorAddTshirtMovementBtn')?.addEventListener('click', () => this.startAddMovement());
    
    // Movement hint cancel button
    document.getElementById('editorMovementHintCancel')?.addEventListener('click', () => {
      this.hideMovementHint();
      this.pendingMovementTarget = null;
      this.selectTool('select');
    });
    
    // Image file input
    const imageInput = document.getElementById('editorImageInput');
    if (imageInput) {
      imageInput.addEventListener('change', (e) => this.handleImageFileSelect(e));
    }

    // Autocapture button
    const autocaptureBtn = document.getElementById('editorAutocaptureBtn');
    if (autocaptureBtn) {
      autocaptureBtn.addEventListener('click', () => {
        // Request autocapture from sidebar
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'requestAutocapture' }, (response) => {
              if (chrome.runtime.lastError) {
                console.error('Could not request autocapture:', chrome.runtime.lastError);
                const videoPageText = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.pleaseOpenVideoPage')
                  : 'Please open a video page (YouTube, Dailymotion, or Twitch) to use autocapture.';
                alert(videoPageText);
              }
            });
          }
        });
      });
    }

    // Bottom bar
    document.getElementById('editorZoomIn')?.addEventListener('click', () => this.zoomIn());
    document.getElementById('editorZoomOut')?.addEventListener('click', () => this.zoomOut());
    document.getElementById('editorResetZoom')?.addEventListener('click', () => this.resetZoom());

    // Canvas rotation control - rotates +90 degrees each click
    document.getElementById('editorRotateBtn')?.addEventListener('click', () => this.rotateCanvas());

    // Layers panel
    document.getElementById('editorLayersPanelBtn')?.addEventListener('click', () => this.toggleLayersPanel());
    document.getElementById('editorLayersPanelClose')?.addEventListener('click', () => this.toggleLayersPanel(false));

    // Curve settings
    document.getElementById('editorCurveIntensity')?.addEventListener('input', (e) => {
      this.curveIntensity = parseFloat(e.target.value);
      document.getElementById('editorCurveIntensityValue').textContent = this.curveIntensity.toFixed(1);

      // Update selected curves with new intensity
      this.selectedDrawings.forEach(index => {
        if (this.drawings[index] && this.drawings[index].type === 'curve') {
          this.drawings[index].curveIntensity = this.curveIntensity;
          // Recalculate control points based on new intensity
          this.recalculateCurveControlPoints(this.drawings[index]);
        }
      });
      this.redraw();
    });

    document.getElementById('editorCurveType')?.addEventListener('change', (e) => {
      this.curveType = e.target.value;

      // Update selected curves with new type
      this.selectedDrawings.forEach(index => {
        if (this.drawings[index] && this.drawings[index].type === 'curve') {
          this.drawings[index].curveType = this.curveType;
          // Recalculate control points based on new type
          this.recalculateCurveControlPoints(this.drawings[index]);
        }
      });
      this.redraw();
    });

    // Curve direction
    document.querySelectorAll('input[name="curveDirection"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.curveDirection = e.target.value;

        // Update selected curves with new direction
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index] && this.drawings[index].type === 'curve') {
            this.drawings[index].curveDirection = this.curveDirection;
            // Recalculate control points based on new direction
            this.recalculateCurveControlPoints(this.drawings[index]);
          }
        });
        this.redraw();
      });
    });

    // Line thickness control
    document.getElementById('editorLineThickness')?.addEventListener('input', (e) => {
      const newThickness = parseInt(e.target.value);

      // Update selected drawings' lineWidth if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].lineWidth = newThickness;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global lineWidth for new drawings
        this.lineWidth = newThickness;
      }

      document.getElementById('editorLineThicknessValue').textContent = newThickness + 'px';
    });

    // Line opacity control
    document.getElementById('editorLineOpacity')?.addEventListener('input', (e) => {
      const newOpacity = parseFloat(e.target.value) / 100; // Convert 0-100 to 0-1

      // Update selected drawings' opacity if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index]) {
            this.drawings[index].opacity = newOpacity;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global opacity for new drawings
        this.opacity = newOpacity;
      }

      document.getElementById('editorLineOpacityValue').textContent = Math.round(newOpacity * 100) + '%';
    });

    // Font weight control (for text)
    document.getElementById('editorFontWeight')?.addEventListener('change', (e) => {
      const newFontWeight = parseInt(e.target.value);
      this.fontWeight = newFontWeight; // Update for new text drawings

      // Update selected text drawings' font weight if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index] && this.drawings[index].type === 'text') {
            this.drawings[index].fontWeight = newFontWeight;
          }
        });
        this.saveState();
        this.redraw();
      }
    });
    
    // Text opacity control
    document.getElementById('editorTextOpacity')?.addEventListener('input', (e) => {
      const newOpacity = parseFloat(e.target.value) / 100;

      // Update selected text drawings' opacity if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          if (this.drawings[index] && this.drawings[index].type === 'text') {
            this.drawings[index].opacity = newOpacity;
          }
        });
        this.saveState();
        this.redraw();
      }

      document.getElementById('editorTextOpacityValue').textContent = e.target.value + '%';
    });

    // Fill controls (for shapes, ball, t-shirt)
    document.getElementById('editorFillColor')?.addEventListener('input', (e) => {
      const newFillColor = e.target.value;
      this.fillColor = newFillColor;
      
      // Update selected drawings' color
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            if (['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'].includes(drawing.type)) {
              drawing.fillColor = newFillColor;
            } else if (drawing.type === 'ball' || drawing.type === 'tshirt') {
              // For ball and t-shirt, update the main color
              drawing.color = newFillColor;
              this.currentColor = newFillColor; // Also update current color
            }
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // If nothing selected, update current fill color for shape tools
        const shapeToolsWithFill = ['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'];
        if (shapeToolsWithFill.includes(this.currentTool)) {
          this.fillColor = newFillColor;
        } else if (this.currentTool === 'ball' || this.currentTool === 'tshirt') {
          this.currentColor = newFillColor;
        }
      }
    });

    document.getElementById('editorFillOpacity')?.addEventListener('input', (e) => {
      const newFillOpacity = parseFloat(e.target.value) / 100; // Convert 0-100 to 0-1
      this.fillOpacity = newFillOpacity;
      
      // Update selected drawings' opacity
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            if (drawing.type === 'image') {
              // For images, update opacity property
              drawing.opacity = newFillOpacity;
            } else if (['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'].includes(drawing.type)) {
              // For shapes, update fillOpacity property
              drawing.fillOpacity = newFillOpacity;
            }
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global fill opacity for new shapes
        this.fillOpacity = newFillOpacity;
      }
      
      document.getElementById('editorFillOpacityValue').textContent = Math.round(newFillOpacity * 100) + '%';
    });

    document.getElementById('editorFillStyle')?.addEventListener('change', (e) => {
      const newFillStyle = e.target.value;
      this.fillStyle = newFillStyle;
      
      // Update selected shapes' fill style if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && ['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'].includes(drawing.type)) {
            drawing.fillStyle = newFillStyle;
          }
        });
        this.saveState();
        this.redraw();
      }
    });

    // Line style control
    document.getElementById('editorLineStyle')?.addEventListener('change', (e) => {
      const newLineStyle = e.target.value;
      this.lineStyle = newLineStyle;

      // Update selected drawings' line style if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && ['line', 'curve', 'arrow', 'circle', 'oval', 'arc', 'polygon', 'cross', 'triangle', 'rectangle'].includes(drawing.type)) {
            drawing.lineStyle = newLineStyle;
          }
        });
        this.saveState();
        this.redraw();
      }
    });

    // Start cap control
    document.getElementById('editorStartCap')?.addEventListener('change', (e) => {
      const newStartCap = e.target.value;
      this.startCap = newStartCap;

      // Update selected drawings' start cap if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && ['line', 'curve', 'arrow'].includes(drawing.type)) {
            drawing.startCap = newStartCap;
          }
        });
        this.saveState();
        this.redraw();
      }
    });

    // End cap control
    document.getElementById('editorEndCap')?.addEventListener('change', (e) => {
      const newEndCap = e.target.value;
      this.endCap = newEndCap;

      // Update selected drawings' end cap if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && ['line', 'curve', 'arrow'].includes(drawing.type)) {
            drawing.endCap = newEndCap;
          }
        });
        this.saveState();
        this.redraw();
      }
    });

    // Highlight enabled control
    document.getElementById('editorHighlightEnabled')?.addEventListener('change', (e) => {
      const enabled = e.target.checked;

      // Update selected drawings' highlight enabled state if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            drawing.highlightEnabled = enabled;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global highlight enabled state for new drawings
        this.highlightEnabled = enabled;
      }
    });

    // Highlight color control
    document.getElementById('editorHighlightColor')?.addEventListener('input', (e) => {
      const newColor = e.target.value;

      // Update selected drawings' highlight color if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            drawing.highlightColor = newColor;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global highlight color for new drawings
        this.highlightColor = newColor;
      }
    });

    // Highlight thickness control
    document.getElementById('editorHighlightThickness')?.addEventListener('input', (e) => {
      const newThickness = parseInt(e.target.value);

      // Update selected drawings' highlight thickness if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            drawing.highlightThickness = newThickness;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global highlight thickness for new drawings
        this.highlightThickness = newThickness;
      }

      // Update display value
      document.getElementById('editorHighlightThicknessValue').textContent = newThickness + 'px';
    });

    // Highlight style control
    document.getElementById('editorHighlightStyle')?.addEventListener('change', (e) => {
      const newStyle = e.target.value;

      // Update selected drawings' highlight style if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing) {
            drawing.highlightStyle = newStyle;
          }
        });
        this.saveState();
        this.redraw();
      } else {
        // Otherwise update the global highlight style for new drawings
        this.highlightStyle = newStyle;
      }
    });
    
    // Events management
    const addEventBtn = document.getElementById('editorAddEventBtn');
    if (addEventBtn) {
      addEventBtn.addEventListener('click', () => {
        if (this.selectedDrawings.length > 0) {
          this.openEventAssignPopup(this.selectedDrawings[0]);
        }
      });
    }
    
    // Players management
    const addPlayerBtn = document.getElementById('editorAddPlayerBtn');
    if (addPlayerBtn) {
      addPlayerBtn.addEventListener('click', () => {
        if (this.selectedDrawings.length > 0) {
          this.openPlayerAttachPopup(this.selectedDrawings[0]);
        }
      });
    }
    
    // Update events display when selection changes
    this.updateEventsDisplay();
    // Update players display when selection changes
    this.updatePlayersDisplay();

    // T-shirt number control
    document.getElementById('editorTshirtNumber')?.addEventListener('input', (e) => {
      const newNumber = parseInt(e.target.value) || 10;
      
      // Update selected t-shirts' number if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && drawing.type === 'tshirt') {
            drawing.number = newNumber;
            // Clear player association when number is manually changed
            drawing.playerId = null;
          }
        });
        this.saveState();
        this.redraw();
        this.updateAssignPlayerButton();
      }
    });
    
    // T-shirt surname control
    document.getElementById('editorTshirtSurname')?.addEventListener('input', (e) => {
      const newSurname = e.target.value.toUpperCase().trim();
      
      // Update selected t-shirts' surname if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && drawing.type === 'tshirt') {
            drawing.surname = newSurname;
            // Clear player association when surname is manually changed
            drawing.playerId = null;
          }
        });
        this.saveState();
        this.redraw();
        this.updateAssignPlayerButton();
      }
    });
    
    // T-shirt design control
    document.getElementById('editorTshirtDesign')?.addEventListener('change', (e) => {
      const newDesign = e.target.value;
      this.tshirtDesign = newDesign;
      
      // Update selected t-shirts' design if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && drawing.type === 'tshirt') {
            drawing.design = newDesign;
          }
        });
        this.saveState();
        this.redraw();
      }
    });
    
    // T-shirt secondary color control
    document.getElementById('editorTshirtSecondColor')?.addEventListener('input', (e) => {
      const newColor = e.target.value;
      this.tshirtSecondColor = newColor;
      
      // Update selected t-shirts' secondary color if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && drawing.type === 'tshirt') {
            drawing.secondColor = newColor;
          }
        });
        this.saveState();
        this.redraw();
      }
    });
    
    // Assign player button - use event delegation to handle clicks even if button is dynamically shown/hidden
    document.addEventListener('click', (e) => {
      if (e.target.closest('#editorAssignPlayerBtn')) {
        e.preventDefault();
        e.stopPropagation();
        console.log('Assign player button clicked', {
          selectedDrawings: this.selectedDrawings.length,
          drawings: this.drawings.length
        });
        
        // Get the first selected t-shirt
        if (this.selectedDrawings.length > 0) {
          const firstTshirtIndex = this.selectedDrawings.find(index => {
            const drawing = this.drawings[index];
            return drawing && drawing.type === 'tshirt';
          });
          
          console.log('First t-shirt index:', firstTshirtIndex);
          
          if (firstTshirtIndex !== undefined) {
            console.log('Opening player assign popup for index:', firstTshirtIndex);
            this.openPlayerAssignPopup(firstTshirtIndex);
          } else {
            console.warn('No t-shirt found in selected drawings');
          }
        } else {
          console.warn('No drawings selected');
        }
      }
    });
    
    // Also try direct attachment as fallback
    const assignPlayerBtn = document.getElementById('editorAssignPlayerBtn');
    if (assignPlayerBtn) {
      assignPlayerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('Assign player button clicked (direct listener)', {
          selectedDrawings: this.selectedDrawings.length,
          drawings: this.drawings.length
        });
        
        // Get the first selected t-shirt
        if (this.selectedDrawings.length > 0) {
          const firstTshirtIndex = this.selectedDrawings.find(index => {
            const drawing = this.drawings[index];
            return drawing && drawing.type === 'tshirt';
          });
          
          if (firstTshirtIndex !== undefined) {
            this.openPlayerAssignPopup(firstTshirtIndex);
          }
        }
      });
      console.log('Assign player button event listener attached (direct)');
    } else {
      console.warn('editorAssignPlayerBtn not found in DOM at init time - using event delegation');
    }
    
    // Ball number control (optional - can be empty)
    document.getElementById('editorBallNumber')?.addEventListener('input', (e) => {
      const value = e.target.value.trim();
      const newNumber = value !== '' ? parseInt(value) : null;
      this.ballNumber = newNumber;
      
      // Update selected balls' number if any are selected
      if (this.selectedDrawings.length > 0) {
        this.selectedDrawings.forEach(index => {
          const drawing = this.drawings[index];
          if (drawing && drawing.type === 'ball') {
            drawing.number = newNumber;
          }
        });
        this.saveState();
        this.redraw();
      }
    });

    // Initialize opacity display
    document.getElementById('editorOpacity')?.dispatchEvent(new Event('input'));

    // Close color picker when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#editorColorPickerBtn') && !e.target.closest('#editorColorPicker')) {
        document.getElementById('editorColorPicker')?.classList.add('hidden');
      }
    });
  }

  selectTool(tool) {
    // Hide movement hint when switching tools (unless switching TO animpath)
    if (tool !== 'animpath') {
      this.hideMovementHint();
      this.pendingMovementTarget = null;
    }
    
    this.currentTool = tool;
    this.selectedDrawings = [];
    this.selectionRect = null;
    document.querySelectorAll('.editor-tool-btn[data-tool]').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`.editor-tool-btn[data-tool="${tool}"]`)?.classList.add('active');

    // Show/hide tool settings panels
    const curveSettings = document.getElementById('editorCurveSettings');
    const styleToolbar = document.getElementById('editorStyleToolbar');

    const fontSizeControl = document.getElementById('editorFontSizeControl');
    
    if (styleToolbar) {
      if (tool === 'select') {
        // For select tool, style toolbar will be shown when objects are selected
        styleToolbar.classList.add('hidden');
      } else {
        // Show style toolbar for supported drawing tools
        const styleTools = ['line', 'curve', 'arrow', 'circle', 'oval', 'arc', 'polygon', 'cross', 'triangle', 'rectangle', 'ball', 'tshirt', 'freehand', 'spray', 'heatmap', 'text', 'formation', 'barrier', 'biggoal', 'ladder', 'stick'];
        if (styleTools.includes(tool)) {
          styleToolbar.classList.remove('hidden');
          
          // Show/hide curve settings section within toolbar
          if (curveSettings) {
            if (tool === 'curve') {
              curveSettings.classList.remove('hidden');
            } else {
              curveSettings.classList.add('hidden');
            }
          }
          
          // Configure controls based on tool type
          const lineColorRow = document.getElementById('editorLineColorRow');
          const thicknessRow = document.getElementById('editorThicknessRow');
          const lineStyleRow = document.getElementById('editorLineStyleRow');
          const startCapRow = document.getElementById('editorStartCapRow');
          const endCapRow = document.getElementById('editorEndCapRow');
          const fillColorRow = document.getElementById('editorFillColorRow');
          const fillOpacityRow = document.getElementById('editorFillOpacityRow');
          const fillStyleRow = document.getElementById('editorFillStyleRow');
          const fillSectionHeaders = document.querySelectorAll('.editor-section-header');
          const colorPresetsInline = document.querySelector('.editor-color-presets-inline');
          const textPropertiesSection = document.getElementById('editorTextPropertiesSection');
          const tshirtPropertiesSection = document.getElementById('editorTshirtPropertiesSection');
          const ballPropertiesSection = document.getElementById('editorBallPropertiesSection');
          const formationPropertiesSection = document.getElementById('editorFormationPropertiesSection');
          const animPathPropertiesSection = document.getElementById('editorAnimPathPropertiesSection');
          const fillPropertiesSection = document.getElementById('editorFillPropertiesSection');
          // Get LINE PROPERTIES header (second header, index 1)
          const linePropertiesHeader = fillSectionHeaders[1];
          
          if (tool === 'text') {
            // Text: show color picker and text properties
            if (lineColorRow) lineColorRow.style.display = 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
            if (textPropertiesSection) textPropertiesSection.style.display = 'block';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (thicknessRow) thicknessRow.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none';
          } else if (tool === 'tshirt') {
            // T-shirt: show color picker and t-shirt number
            if (lineColorRow) lineColorRow.style.display = 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'block';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (thicknessRow) thicknessRow.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none';
            // Hide LINE PROPERTIES header for t-shirt
            // Hide movement row when using tool (only show for selected existing t-shirts)
            const tshirtMovementRow = document.getElementById('editorTshirtMovementRow');
            if (tshirtMovementRow) tshirtMovementRow.style.display = 'none';
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'none';
            // Hide player assignment row when using tool (not selecting existing t-shirt)
            const playerRow = document.getElementById('editorTshirtPlayerRow');
            if (playerRow) playerRow.style.display = 'none';
          } else if (tool === 'ball') {
            // Ball: show color picker and ball number
            if (lineColorRow) lineColorRow.style.display = 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'block';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (thicknessRow) thicknessRow.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none';
            // Show LINE PROPERTIES header
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'block';
            // Set ball color to white by default
            this.currentColor = '#FFFFFF';
            const lineColorInput = document.getElementById('editorLineColor');
            if (lineColorInput) lineColorInput.value = '#FFFFFF';
            // Clear ball number input (optional field)
            const ballNumberInput = document.getElementById('editorBallNumber');
            if (ballNumberInput) ballNumberInput.value = '';
            this.ballNumber = null;
            // Hide movement row when using tool (only show for selected existing balls)
            const ballMovementRow = document.getElementById('editorBallMovementRow');
            if (ballMovementRow) ballMovementRow.style.display = 'none';
          } else if (tool === 'animpath') {
            // Animation path: show animation path properties
            const animPathPropertiesSection = document.getElementById('editorAnimPathPropertiesSection');
            if (lineColorRow) lineColorRow.style.display = 'none';
            if (colorPresetsInline) colorPresetsInline.style.display = 'none';
            if (thicknessRow) thicknessRow.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'block';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            // Hide LINE PROPERTIES header
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'none';
            fillSectionHeaders.forEach((header, index) => {
              header.style.display = 'none';
            });
            // Initialize animation settings display values
            const animDurationInput = document.getElementById('editorAnimDuration');
            const animDurationValue = document.getElementById('editorAnimDurationValue');
            const animDelayInput = document.getElementById('editorAnimDelay');
            const animDelayValue = document.getElementById('editorAnimDelayValue');
            const animEasingSelect = document.getElementById('editorAnimEasing');
            if (animDurationInput && animDurationValue) {
              animDurationInput.value = this.animPathDuration || 2.0;
              animDurationValue.textContent = (this.animPathDuration || 2.0).toFixed(1) + 's';
            }
            if (animDelayInput && animDelayValue) {
              animDelayInput.value = this.animPathDelay || 0;
              animDelayValue.textContent = (this.animPathDelay || 0).toFixed(2) + 's';
            }
            if (animEasingSelect) {
              animEasingSelect.value = this.animPathEasing || 'easeOut';
            }
          } else if (tool === 'formation') {
            // Formation: show formation properties, hide LINE PROPERTIES
            if (lineColorRow) lineColorRow.style.display = 'none';
            if (colorPresetsInline) colorPresetsInline.style.display = 'none';
            if (thicknessRow) thicknessRow.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) {
              formationPropertiesSection.style.display = 'block';
              // Ensure it's visible
              formationPropertiesSection.style.visibility = 'visible';
            }
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            // Hide LINE PROPERTIES header
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'none';
            // Hide other section headers that might be visible
            fillSectionHeaders.forEach((header, index) => {
              if (index !== 1) { // Keep formation header (we'll show it separately)
                header.style.display = 'none';
              }
            });
            // Update formation description and sync controls
            this.updateFormationDescription();
            const formationSelect = document.getElementById('editorFormationSelect');
            if (formationSelect) formationSelect.value = this.currentFormation;
            const formationRadios = document.querySelectorAll('input[name="formationSide"]');
            formationRadios.forEach(r => {
              if (r.value === this.formationSide) r.checked = true;
            });
            const formationColorInput = document.getElementById('editorFormationColor');
            if (formationColorInput) formationColorInput.value = this.formationColor;
          } else if (tool === 'freehand' || tool === 'spray' || tool === 'heatmap') {
            // Freehand/Spray/Heatmap: show color and opacity (thickness for freehand only, no line style, no fill)
            const lineOpacityRow = document.getElementById('editorLineOpacityRow');
            const highlightPropertiesSection = document.getElementById('editorHighlightPropertiesSection');
            // Hide color picker for heatmap (uses automatic heat scale)
            if (lineColorRow) lineColorRow.style.display = tool === 'heatmap' ? 'none' : 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = tool === 'heatmap' ? 'none' : 'grid';
            // Show thickness only for freehand, not for spray or heatmap
            if (thicknessRow) thicknessRow.style.display = tool === 'freehand' ? 'flex' : 'none';
            if (lineOpacityRow) lineOpacityRow.style.display = 'flex';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (lineStyleRow) lineStyleRow.style.display = 'none';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            // Hide highlight properties for spray and heatmap
            if (highlightPropertiesSection) highlightPropertiesSection.style.display = (tool === 'spray' || tool === 'heatmap') ? 'none' : 'block';
            if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'block';
            // Show LINE PROPERTIES header
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'block';
            
            // Initialize color and opacity controls with current values
            const lineColorInput = document.getElementById('editorLineColor');
            const lineOpacityInput = document.getElementById('editorLineOpacity');
            const lineOpacityValue = document.getElementById('editorLineOpacityValue');
            
            if (lineColorInput) {
              lineColorInput.value = this.currentColor || '#FF0000';
            }
            
            if (lineOpacityInput && lineOpacityValue) {
              const opacity = this.opacity !== undefined ? this.opacity : 1.0;
              lineOpacityInput.value = Math.round(opacity * 100);
              lineOpacityValue.textContent = Math.round(opacity * 100) + '%';
            }
          } else if (tool === 'cross') {
            // Cross: show color, thickness, opacity, and line style (no fill, no endpoints)
            const lineOpacityRow = document.getElementById('editorLineOpacityRow');
            if (lineColorRow) lineColorRow.style.display = 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
            if (thicknessRow) thicknessRow.style.display = 'flex';
            if (lineOpacityRow) lineOpacityRow.style.display = 'flex';
            if (lineStyleRow) lineStyleRow.style.display = 'flex';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            if (startCapRow) startCapRow.style.display = 'none';
            if (endCapRow) endCapRow.style.display = 'none';
            if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
            if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'block';
            // Show LINE PROPERTIES header
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'block';
          } else {
            // Reset to show all controls for other tools
            const lineOnlyTools = ['line', 'curve', 'arrow'];
            const shapeToolsWithFill = ['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'];
            const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
            const needsFill = !lineOnlyTools.includes(tool);
            const isSvgTool = svgElements.includes(tool);
            
            const lineOpacityRow = document.getElementById('editorLineOpacityRow');
            if (lineColorRow) lineColorRow.style.display = 'flex';
            if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
            // Hide thickness and style for SVG elements
            if (thicknessRow) thicknessRow.style.display = isSvgTool ? 'none' : 'flex';
            if (lineOpacityRow) lineOpacityRow.style.display = isSvgTool ? 'none' : 'flex';
            if (lineStyleRow) lineStyleRow.style.display = isSvgTool ? 'none' : 'flex';
            if (textPropertiesSection) textPropertiesSection.style.display = 'none';
            if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
            if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
            if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
            if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
            
            // Show start/end cap controls for lines, curves, and arrows
            if (lineOnlyTools.includes(tool)) {
              if (startCapRow) startCapRow.style.display = 'flex';
              if (endCapRow) endCapRow.style.display = 'flex';
            } else {
              if (startCapRow) startCapRow.style.display = 'none';
              if (endCapRow) endCapRow.style.display = 'none';
            }
            
            // Show LINE PROPERTIES header for all tools (except formation and tshirt which handle it separately)
            if (linePropertiesHeader) linePropertiesHeader.style.display = 'block';
            
            // For shape tools with fill (circle, arc, polygon), ensure both sections are visible
            if (shapeToolsWithFill.includes(tool)) {
              // Show FILL PROPERTIES section with its header
              if (fillPropertiesSection) {
                fillPropertiesSection.style.display = 'block';
                // Ensure the FILL PROPERTIES header inside the section is visible
                const fillHeader = fillPropertiesSection.querySelector('.editor-section-header');
                if (fillHeader) fillHeader.style.display = 'block';
              }
              // Show all fill property rows for shape tools
              if (fillColorRow) {
                fillColorRow.classList.remove('hidden');
                fillColorRow.style.display = 'flex';
              }
              if (fillOpacityRow) {
                fillOpacityRow.classList.remove('hidden');
                fillOpacityRow.style.display = 'flex';
                // Ensure label is correct
                const label = fillOpacityRow.querySelector('label');
                if (label) {
                  const opacityText = (window.i18n && typeof window.i18n.t === 'function')
                    ? window.i18n.t('editor.opacity')
                    : 'Opacity:';
                  label.textContent = opacityText;
                }
              }
              if (fillStyleRow) {
                fillStyleRow.classList.remove('hidden');
                fillStyleRow.style.display = 'flex';
              }
              // Initialize fill property inputs with current values
              const fillColorInput = document.getElementById('editorFillColor');
              const fillOpacityInput = document.getElementById('editorFillOpacity');
              const fillOpacityValue = document.getElementById('editorFillOpacityValue');
              const fillStyleSelect = document.getElementById('editorFillStyle');
              if (fillColorInput) fillColorInput.value = this.fillColor || '#FFFFFF';
              if (fillOpacityInput && fillOpacityValue) {
                const opacity = this.fillOpacity !== undefined ? this.fillOpacity : 0.0;
                fillOpacityInput.value = Math.round(opacity * 100);
                fillOpacityValue.textContent = Math.round(opacity * 100) + '%';
              }
              if (fillStyleSelect) fillStyleSelect.value = this.fillStyle || 'solid';
            } else if (needsFill) {
              // For other tools that need fill
              if (fillPropertiesSection) fillPropertiesSection.style.display = 'block';
              // Show all fill property rows
              if (fillColorRow) {
                fillColorRow.classList.remove('hidden');
                fillColorRow.style.display = 'flex';
              }
              if (fillOpacityRow) {
                fillOpacityRow.classList.remove('hidden');
                fillOpacityRow.style.display = 'flex';
                const label = fillOpacityRow.querySelector('label');
                if (label) {
                  const opacityText = (window.i18n && typeof window.i18n.t === 'function')
                    ? window.i18n.t('editor.opacity')
                    : 'Opacity:';
                  label.textContent = opacityText;
                }
              }
              if (fillStyleRow) {
                fillStyleRow.classList.remove('hidden');
                fillStyleRow.style.display = 'flex';
              }
              // Initialize fill property inputs with current values
              const fillColorInput = document.getElementById('editorFillColor');
              const fillOpacityInput = document.getElementById('editorFillOpacity');
              const fillOpacityValue = document.getElementById('editorFillOpacityValue');
              const fillStyleSelect = document.getElementById('editorFillStyle');
              if (fillColorInput) fillColorInput.value = this.fillColor || '#FFFFFF';
              if (fillOpacityInput && fillOpacityValue) {
                const opacity = this.fillOpacity !== undefined ? this.fillOpacity : 0.0;
                fillOpacityInput.value = Math.round(opacity * 100);
                fillOpacityValue.textContent = Math.round(opacity * 100) + '%';
              }
              if (fillStyleSelect) fillStyleSelect.value = this.fillStyle || 'solid';
            } else {
              // Hide fill properties for line-only tools
              if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
              if (fillColorRow) {
                fillColorRow.classList.add('hidden');
                fillColorRow.style.display = 'none';
              }
              if (fillOpacityRow) {
                fillOpacityRow.classList.add('hidden');
                fillOpacityRow.style.display = 'none';
              }
              if (fillStyleRow) {
                fillStyleRow.classList.add('hidden');
                fillStyleRow.style.display = 'none';
              }
            }
          }
        } else {
          styleToolbar.classList.add('hidden');
        }
      }
    }
    
    // Hide font size control when switching tools (unless text is selected)
    if (fontSizeControl && tool !== 'select') {
      fontSizeControl.classList.add('hidden');
    }
    

    // Reset tool-specific state
    this.polygonPoints = [];
    this.curveControlPoint = null;
    this.curveControlPoints = [];
    this.isDrawing = false; // Reset drawing state when switching tools
    
    // Remove any existing text input
    if (this.textInput) {
      this.textInput.remove();
      this.textInput = null;
    }
    
    // Update cursor
    if (tool === 'select') {
      this.canvas.style.cursor = 'default';
    } else if (tool === 'text') {
      this.canvas.style.cursor = 'text';
    } else {
      this.canvas.style.cursor = 'crosshair';
    }
    
    // Update button states (copy/paste)
    this.updateButtonStates();
    
    this.redraw();
  }

  updateFormationDescription() {
    const allFormations = getAllFormations();
    const formation = allFormations[this.currentFormation];
    const descriptionEl = document.getElementById('editorFormationDescription');
    if (descriptionEl && formation) {
      const noDescriptionText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.noDescriptionAvailable')
        : 'No description available.';
      descriptionEl.textContent = formation.description || noDescriptionText;
    } else if (descriptionEl) {
      const selectFormationText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectFormationToSeeDescription')
        : 'Select a formation to see description';
      descriptionEl.textContent = selectFormationText;
    }
  }

  loadTeams() {
    // Try to get current analysis ID from storage or URL
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return;
    }
    
    chrome.storage.local.get(['currentAnalysisId', 'analyses'], (result) => {
      const analysisId = result.currentAnalysisId;
      this.currentAnalysisId = analysisId;
      
      if (analysisId && result.analyses) {
        const analysis = result.analyses.find(a => a.id === analysisId);
        if (analysis && analysis.teams) {
          this.populateTeamSelector(analysis.teams);
        }
      } else {
        // Try to get from the most recent analysis
        const analyses = result.analyses || [];
        if (analyses.length > 0) {
          const latestAnalysis = analyses[analyses.length - 1];
          this.currentAnalysisId = latestAnalysis.id;
          if (latestAnalysis.teams) {
            this.populateTeamSelector(latestAnalysis.teams);
          }
        }
      }
    });
  }

  populateTeamSelector(teams) {
    const teamSelect = document.getElementById('editorFormationTeamSelect');
    if (!teamSelect) return;

    // Clear existing options except the first one
    while (teamSelect.options.length > 1) {
      teamSelect.remove(1);
    }

    // Add teams to selector
    teams.forEach(team => {
      const teamName = getTeamName(team);
      const option = document.createElement('option');
      option.value = teamName;
      option.textContent = teamName;
      teamSelect.appendChild(option);
    });
  }

  loadTeamColors(teamName) {
    if (!this.currentAnalysisId || !teamName) return;

    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return;
    }

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === this.currentAnalysisId);
      
      if (analysis && analysis.teams) {
        const teamObj = getTeamObject(teamName, analysis.teams);
        if (teamObj) {
          const teamData = ensureTeamObject(teamObj);
          // Use selected kit color (home or away)
          const teamColor = this.formationKit === 'home' 
            ? (teamData.homeColor || '#FFFFFF')
            : (teamData.awayColor || '#000000');
          
          this.formationColor = teamColor;
          
          // Use selected kit design and second color
          this.tshirtDesign = this.formationKit === 'home'
            ? (teamData.homeDesign || 'solid')
            : (teamData.awayDesign || 'solid');
          this.tshirtSecondColor = this.formationKit === 'home'
            ? (teamData.homeSecondColor || '#000000')
            : (teamData.awaySecondColor || '#FFFFFF');
          
          // Update color input and preview
          const colorInput = document.getElementById('editorFormationColor');
          if (colorInput) {
            colorInput.value = teamColor;
          }
          this.updateFormationTshirtPreview();
        }
      }
    });
  }

  updateFormationTshirtPreview() {
    const preview = document.getElementById('editorFormationTshirtPreview');
    const colorInput = document.getElementById('editorFormationColor');
    if (!preview || !colorInput) return;
    
    const ctx = preview.getContext('2d');
    const width = preview.width;
    const height = preview.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Get colors and design - use team's actual design if team is selected
    const primaryColor = colorInput.value || '#FFFFFF';
    const secondColor = this.tshirtSecondColor || '#000000';
    const design = this.tshirtDesign || 'solid';
    
    // Draw t-shirt using the same logic as drawTshirt
    const centerX = width / 2;
    const centerY = height / 2;
    const shirtWidth = width * 0.7;
    const shirtHeight = height * 0.8;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;
    
    // Improved t-shirt proportions (matching drawTshirt)
    const collarWidth = shirtWidth * 0.35;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;
    const sleeveLength = shirtWidth * 0.18;
    
    // Helper function to create t-shirt path (matching drawTshirt)
    const createTshirtPath = () => {
      ctx.beginPath();
      
      // Start at left shoulder
      ctx.moveTo(startX, startY + shirtHeight * 0.08);
      
      // Left shoulder curve to collar
      ctx.quadraticCurveTo(
        startX + shoulderWidth * 0.5, 
        startY, 
        startX + shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Neck cutout
      ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight * 0.15, 
        startX + shirtWidth - shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Right shoulder curve
      ctx.quadraticCurveTo(
        startX + shirtWidth - shoulderWidth * 0.5, 
        startY, 
        startX + shirtWidth, 
        startY + shirtHeight * 0.08
      );
      
      // Right sleeve
      ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
      ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
      ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
      
      // Right side
      const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
      ctx.lineTo(rightBottomX, startY + shirtHeight);
      
      // Bottom hem
      ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight + shirtHeight * 0.02, 
        startX + shirtWidth * 0.03, 
        startY + shirtHeight
      );
      
      // Left side
      ctx.lineTo(startX, startY + shirtHeight * 0.38);
      
      // Left sleeve
      ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
      ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
      
      ctx.closePath();
    };
    
    ctx.save();
    
    // Draw the base fill first
    createTshirtPath();
    ctx.fillStyle = primaryColor;
    ctx.fill();
    
    // Apply design pattern (matching drawTshirt logic)
    ctx.save();
    createTshirtPath();
    ctx.clip();
    
    const extLeft = startX - sleeveLength;
    const extRight = startX + shirtWidth + sleeveLength;
    const extTop = startY;
    const extBottom = startY + shirtHeight;
    const extWidth = extRight - extLeft;
    const extHeight = extBottom - extTop;
    
    switch (design) {
      case 'sleeves':
        // Colored sleeves
        ctx.fillStyle = secondColor;
        ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        break;
        
      case 'horiz-stripes':
        // Horizontal stripes
        const hStripeHeight = extHeight / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
        }
        break;
        
      case 'vert-stripes':
        // Vertical stripes
        const vStripeWidth = extWidth / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
        }
        break;
        
      case 'diagonal-sash':
        // Diagonal sash
        ctx.fillStyle = secondColor;
        ctx.beginPath();
        const sashWidth = extWidth * 0.25;
        ctx.moveTo(extLeft, extTop);
        ctx.lineTo(extLeft + sashWidth, extTop);
        ctx.lineTo(extRight, extBottom - sashWidth * 0.8);
        ctx.lineTo(extRight, extBottom);
        ctx.lineTo(extRight - sashWidth, extBottom);
        ctx.lineTo(extLeft, extTop + sashWidth * 0.8);
        ctx.closePath();
        ctx.fill();
        break;
        
      case 'vert-sash':
        // Vertical sash
        ctx.fillStyle = secondColor;
        const vSashWidth = extWidth * 0.25;
        const vSashX = extLeft + (extWidth - vSashWidth) / 2;
        ctx.fillRect(vSashX, extTop, vSashWidth, extHeight);
        break;
        
      case 'horiz-sash':
        // Horizontal sash
        ctx.fillStyle = secondColor;
        const hSashHeight = extHeight * 0.25;
        const hSashY = extTop + (extHeight - hSashHeight) / 2;
        ctx.fillRect(extLeft, hSashY, extWidth, hSashHeight);
        break;
        
      case 'checkered':
        // Checkered pattern
        const squareSize = Math.min(extWidth, extHeight) / 4;
        ctx.fillStyle = secondColor;
        for (let row = 0; row < Math.ceil(extHeight / squareSize); row++) {
          for (let col = 0; col < Math.ceil(extWidth / squareSize); col++) {
            if ((row + col) % 2 === 1) {
              ctx.fillRect(
                extLeft + col * squareSize,
                extTop + row * squareSize,
                squareSize,
                squareSize
              );
            }
          }
        }
        break;
        
      case 'solid':
      default:
        // Solid - no additional pattern needed
        break;
    }
    
    ctx.restore();
    
    // Draw the outline
    createTshirtPath();
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    
    // Draw number
    const hex = primaryColor.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
    
    ctx.fillStyle = textColor;
    ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const shirtCenterX = startX + shirtWidth / 2;
    const shirtCenterY = startY + shirtHeight / 2;
    ctx.fillText('10', shirtCenterX, shirtCenterY + shirtHeight * 0.1);
    
    ctx.restore();
  }
  
  // Update team kit previews
  updateTeamKitPreview(kitType) {
    const previewId = kitType === 'home' ? 'editorTeamHomePreview' : 'editorTeamAwayPreview';
    const colorInputId = kitType === 'home' ? 'editorTeamHomeColor' : 'editorTeamAwayColor';
    const designSelectId = kitType === 'home' ? 'editorTeamHomeDesign' : 'editorTeamAwayDesign';
    const secondColorInputId = kitType === 'home' ? 'editorTeamHomeSecondColor' : 'editorTeamAwaySecondColor';
    
    const preview = document.getElementById(previewId);
    const colorInput = document.getElementById(colorInputId);
    const designSelect = document.getElementById(designSelectId);
    const secondColorInput = document.getElementById(secondColorInputId);
    
    if (!preview || !colorInput || !designSelect || !secondColorInput) return;
    
    const ctx = preview.getContext('2d');
    const width = preview.width;
    const height = preview.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Get colors and design
    const primaryColor = colorInput.value || (kitType === 'home' ? '#FFFFFF' : '#000000');
    const secondColor = secondColorInput.value || (kitType === 'home' ? '#000000' : '#FFFFFF');
    const design = designSelect.value || 'solid';
    
    // Draw t-shirt using the same logic as drawTshirt
    const centerX = width / 2;
    const centerY = height / 2;
    const shirtWidth = width * 0.7;
    const shirtHeight = height * 0.8;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;
    
    // Improved t-shirt proportions (matching drawTshirt)
    const collarWidth = shirtWidth * 0.35;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;
    const sleeveLength = shirtWidth * 0.18;
    
    // Helper function to create t-shirt path (matching drawTshirt)
    const createTshirtPath = () => {
      ctx.beginPath();
      
      // Start at left shoulder
      ctx.moveTo(startX, startY + shirtHeight * 0.08);
      
      // Left shoulder curve to collar
      ctx.quadraticCurveTo(
        startX + shoulderWidth * 0.5, 
        startY, 
        startX + shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Neck cutout
      ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight * 0.15, 
        startX + shirtWidth - shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Right shoulder curve
      ctx.quadraticCurveTo(
        startX + shirtWidth - shoulderWidth * 0.5, 
        startY, 
        startX + shirtWidth, 
        startY + shirtHeight * 0.08
      );
      
      // Right sleeve
      ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
      ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
      ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
      
      // Right side
      const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
      ctx.lineTo(rightBottomX, startY + shirtHeight);
      
      // Bottom hem
      ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight + shirtHeight * 0.02, 
        startX + shirtWidth * 0.03, 
        startY + shirtHeight
      );
      
      // Left side
      ctx.lineTo(startX, startY + shirtHeight * 0.38);
      
      // Left sleeve
      ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
      ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
      
      ctx.closePath();
    };
    
    ctx.save();
    
    // Draw the base fill first
    createTshirtPath();
    ctx.fillStyle = primaryColor;
    ctx.fill();
    
    // Apply design pattern (matching drawTshirt logic)
    ctx.save();
    createTshirtPath();
    ctx.clip();
    
    const extLeft = startX - sleeveLength;
    const extRight = startX + shirtWidth + sleeveLength;
    const extTop = startY;
    const extBottom = startY + shirtHeight;
    const extWidth = extRight - extLeft;
    const extHeight = extBottom - extTop;
    
    switch (design) {
      case 'sleeves':
        // Colored sleeves
        ctx.fillStyle = secondColor;
        ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        break;
        
      case 'horiz-stripes':
        // Horizontal stripes
        const hStripeHeight = extHeight / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
        }
        break;
        
      case 'vert-stripes':
        // Vertical stripes
        const vStripeWidth = extWidth / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
        }
        break;
        
      case 'diagonal-sash':
        // Diagonal sash
        ctx.fillStyle = secondColor;
        ctx.beginPath();
        const sashWidth = extWidth * 0.25;
        ctx.moveTo(extLeft, extTop);
        ctx.lineTo(extLeft + sashWidth, extTop);
        ctx.lineTo(extRight, extBottom - sashWidth * 0.8);
        ctx.lineTo(extRight, extBottom);
        ctx.lineTo(extRight - sashWidth, extBottom);
        ctx.lineTo(extLeft, extTop + sashWidth * 0.8);
        ctx.closePath();
        ctx.fill();
        break;
        
      case 'vert-sash':
        // Vertical sash
        ctx.fillStyle = secondColor;
        const vSashWidth = extWidth * 0.25;
        const vSashX = extLeft + (extWidth - vSashWidth) / 2;
        ctx.fillRect(vSashX, extTop, vSashWidth, extHeight);
        break;
        
      case 'horiz-sash':
        // Horizontal sash
        ctx.fillStyle = secondColor;
        const hSashHeight = extHeight * 0.25;
        const hSashY = extTop + (extHeight - hSashHeight) / 2;
        ctx.fillRect(extLeft, hSashY, extWidth, hSashHeight);
        break;
        
      case 'checkered':
        // Checkered pattern
        const squareSize = Math.min(extWidth, extHeight) / 4;
        ctx.fillStyle = secondColor;
        for (let row = 0; row < Math.ceil(extHeight / squareSize); row++) {
          for (let col = 0; col < Math.ceil(extWidth / squareSize); col++) {
            if ((row + col) % 2 === 1) {
              ctx.fillRect(
                extLeft + col * squareSize,
                extTop + row * squareSize,
                squareSize,
                squareSize
              );
            }
          }
        }
        break;
        
      case 'solid':
      default:
        // Solid - no additional pattern needed
        break;
    }
    
    ctx.restore();
    
    // Draw the outline
    createTshirtPath();
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    
    // Draw number
    const hex = primaryColor.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
    
    ctx.fillStyle = textColor;
    ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const shirtCenterX = startX + shirtWidth / 2;
    const shirtCenterY = startY + shirtHeight / 2;
    ctx.fillText('10', shirtCenterX, shirtCenterY + shirtHeight * 0.1);
    
    ctx.restore();
  }

  updateKitRadioStates() {
    // Update visual state of kit radio buttons
    document.querySelectorAll('input[name="formationKit"]').forEach(radio => {
      const label = radio.closest('label');
      if (label) {
        if (radio.checked) {
          label.style.background = '#161b22';
          label.style.borderColor = '#1f6feb';
          const span = label.querySelector('span');
          if (span) {
            span.style.color = '#1f6feb';
            span.style.fontWeight = '500';
          }
        } else {
          label.style.background = '#0d1117';
          label.style.borderColor = '#21262d';
          const span = label.querySelector('span');
          if (span) {
            span.style.color = '#c9d1d9';
            span.style.fontWeight = '400';
          }
        }
      }
    });
    
    // Update visual state of side radio buttons
    document.querySelectorAll('input[name="formationSide"]').forEach(radio => {
      const label = radio.closest('label');
      if (label) {
        if (radio.checked) {
          label.style.background = '#161b22';
          label.style.borderColor = '#1f6feb';
          const span = label.querySelector('span');
          if (span) {
            span.style.color = '#1f6feb';
            span.style.fontWeight = '500';
          }
        } else {
          label.style.background = '#0d1117';
          label.style.borderColor = '#21262d';
          const span = label.querySelector('span');
          if (span) {
            span.style.color = '#c9d1d9';
            span.style.fontWeight = '400';
          }
        }
      }
    });
  }

  loadTeamFormation(teamName) {
    if (!this.currentAnalysisId || !teamName) return;

    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return;
    }

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === this.currentAnalysisId);
      
      if (analysis && analysis.teams) {
        const teamObj = getTeamObject(teamName, analysis.teams);
        if (teamObj) {
          const teamData = ensureTeamObject(teamObj);
          // If team has a formation, use it
          if (teamData.formation) {
            // Ensure formation selector is populated with custom formations
            updateFormationSelector();
            
            // Set the formation
            this.currentFormation = teamData.formation;
            
            // Update formation selector - use setTimeout to ensure DOM is ready
            setTimeout(() => {
              const formationSelect = document.getElementById('editorFormationSelect');
              if (formationSelect) {
                // Check if the option exists
                const optionExists = Array.from(formationSelect.options).some(
                  opt => opt.value === teamData.formation
                );
                
                if (optionExists) {
                  formationSelect.value = teamData.formation;
                  // Trigger change event to ensure all handlers are called
                  formationSelect.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                  // If formation doesn't exist in selector, just update the internal state
                  console.warn('Formation not found in selector:', teamData.formation);
                }
              }
              
              // Update formation description
              this.updateFormationDescription();
            }, 0);
          } else {
            // If team doesn't have a formation, keep current formation visible
            const formationSelect = document.getElementById('editorFormationSelect');
            if (formationSelect && formationSelect.value) {
              this.currentFormation = formationSelect.value;
            }
          }
        }
      }
    });
  }

  setLineStyle(style) {
    switch (style) {
      case 'solid':
        this.ctx.setLineDash([]);
        break;
      case 'dashed':
        this.ctx.setLineDash([8, 4]);
        break;
      case 'dotted':
        this.ctx.setLineDash([2, 2]);
        break;
      default:
        this.ctx.setLineDash([]);
    }
  }

  clearWaypointSelection() {
    this.selectedWaypoint = null;
    this.hoveredWaypoint = null;
  }

  updateSelectionControls() {
    const curveSettings = document.getElementById('editorCurveSettings');
    const styleToolbar = document.getElementById('editorStyleToolbar');

    if (this.selectedDrawings.length === 0) {
      // Hide all controls when nothing is selected
      if (curveSettings) curveSettings.classList.add('hidden');
      if (styleToolbar) {
        styleToolbar.classList.add('hidden');
        // ResizeObserver will automatically handle canvas resize
      }
      return;
    }

    // Show controls based on selected shapes
    const selectedDrawing = this.drawings[this.selectedDrawings[0]];
    if (!selectedDrawing) return;

    // Show style toolbar for supported shapes
    const styleSupportedTypes = ['line', 'curve', 'arrow', 'circle', 'oval', 'arc', 'polygon', 'ball', 'tshirt', 'freehand', 'spray', 'heatmap', 'text', 'cross', 'triangle', 'rectangle', 'barrier', 'biggoal', 'ladder', 'stick', 'animpath'];
    if (styleToolbar && styleSupportedTypes.includes(selectedDrawing.type)) {
      styleToolbar.classList.remove('hidden');
      // ResizeObserver will automatically handle canvas resize
      
      // Show/hide curve settings section within toolbar
      if (curveSettings) {
        if (selectedDrawing.type === 'curve') {
          curveSettings.classList.remove('hidden');
          // Update curve controls to match selected curve
          if (selectedDrawing.curveIntensity !== undefined) {
            const intensityInput = document.getElementById('editorCurveIntensity');
            const intensityValue = document.getElementById('editorCurveIntensityValue');
            if (intensityInput) intensityInput.value = selectedDrawing.curveIntensity;
            if (intensityValue) intensityValue.textContent = selectedDrawing.curveIntensity.toFixed(1);
            this.curveIntensity = selectedDrawing.curveIntensity;
          }
          if (selectedDrawing.curveDirection) {
            const directionRadio = document.querySelector(`input[name="curveDirection"][value="${selectedDrawing.curveDirection}"]`);
            if (directionRadio) directionRadio.checked = true;
            this.curveDirection = selectedDrawing.curveDirection;
          }
          if (selectedDrawing.curveType) {
            const typeSelect = document.getElementById('editorCurveType');
            if (typeSelect) typeSelect.value = selectedDrawing.curveType;
            this.curveType = selectedDrawing.curveType;
          }
        } else {
          curveSettings.classList.add('hidden');
        }
      }

      // Update color inputs to match selected shape
      const colorInput = document.getElementById('editorColorInput');
      const lineColorInput = document.getElementById('editorLineColor');
      const drawingColor = selectedDrawing.color || this.currentColor || '#FF0000';
      if (colorInput) {
        colorInput.value = drawingColor;
        this.currentColor = drawingColor;
      }
      if (lineColorInput) {
        lineColorInput.value = drawingColor;
      }

      // Get all control elements
      const lineColorRow = document.getElementById('editorLineColorRow');
      const thicknessRow = document.getElementById('editorThicknessRow');
      const lineStyleRow = document.getElementById('editorLineStyleRow');
      const startCapRow = document.getElementById('editorStartCapRow');
      const endCapRow = document.getElementById('editorEndCapRow');
      const fillColorRow = document.getElementById('editorFillColorRow');
      const fillOpacityRow = document.getElementById('editorFillOpacityRow');
      const fillStyleRow = document.getElementById('editorFillStyleRow');
      const fillSectionHeaders = document.querySelectorAll('.editor-section-header');
      const linePropertiesHeader = fillSectionHeaders[1]; // LINE PROPERTIES header
      const colorPresetsInline = document.querySelector('.editor-color-presets-inline');
      const textPropertiesSection = document.getElementById('editorTextPropertiesSection');
      const tshirtPropertiesSection = document.getElementById('editorTshirtPropertiesSection');
      const ballPropertiesSection = document.getElementById('editorBallPropertiesSection');
      const formationPropertiesSection = document.getElementById('editorFormationPropertiesSection');
      const animPathPropertiesSection = document.getElementById('editorAnimPathPropertiesSection');
      const fillPropertiesSection = document.getElementById('editorFillPropertiesSection');
      
      // Configure controls based on selected drawing type
      if (selectedDrawing.type === 'text') {
        // Text: show color picker and text properties (opacity, font weight)
        if (lineColorRow) lineColorRow.style.display = 'flex';
        if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
        if (textPropertiesSection) textPropertiesSection.style.display = 'block';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
        // Hide line properties and fill properties
        if (thicknessRow) thicknessRow.style.display = 'none';
        if (lineStyleRow) lineStyleRow.style.display = 'none';
        if (startCapRow) startCapRow.style.display = 'none';
        if (endCapRow) endCapRow.style.display = 'none';
        if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
        if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none'; // LINE PROPERTIES
        
        // Update text property controls
        if (selectedDrawing.fontWeight) {
          const fontWeightSelect = document.getElementById('editorFontWeight');
          if (fontWeightSelect) fontWeightSelect.value = selectedDrawing.fontWeight;
        }
        if (selectedDrawing.opacity !== undefined) {
          const textOpacityInput = document.getElementById('editorTextOpacity');
          const textOpacityValue = document.getElementById('editorTextOpacityValue');
          if (textOpacityInput) textOpacityInput.value = Math.round(selectedDrawing.opacity * 100);
          if (textOpacityValue) textOpacityValue.textContent = Math.round(selectedDrawing.opacity * 100) + '%';
        }
      } else if (selectedDrawing.type === 'tshirt') {
        // T-shirt: show color picker and t-shirt number
        if (lineColorRow) lineColorRow.style.display = 'flex';
        if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'block';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
        if (textPropertiesSection) textPropertiesSection.style.display = 'none';
        if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
        if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
        // Hide everything else
        if (thicknessRow) thicknessRow.style.display = 'none';
        if (lineStyleRow) lineStyleRow.style.display = 'none';
        if (startCapRow) startCapRow.style.display = 'none';
        if (endCapRow) endCapRow.style.display = 'none';
        if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
        // Hide both section headers
        if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none'; // LINE PROPERTIES
        if (linePropertiesHeader) linePropertiesHeader.style.display = 'none';
        
        // Update t-shirt number, surname, design, and secondary color controls
        if (selectedDrawing.number !== undefined) {
          const tshirtNumberInput = document.getElementById('editorTshirtNumber');
          if (tshirtNumberInput) tshirtNumberInput.value = selectedDrawing.number;
        }
        const tshirtSurnameInput = document.getElementById('editorTshirtSurname');
        if (tshirtSurnameInput) {
          tshirtSurnameInput.value = selectedDrawing.surname || '';
        }
        const tshirtDesignSelect = document.getElementById('editorTshirtDesign');
        if (tshirtDesignSelect) {
          tshirtDesignSelect.value = selectedDrawing.design || 'solid';
        }
        const tshirtSecondColorInput = document.getElementById('editorTshirtSecondColor');
        if (tshirtSecondColorInput) {
          tshirtSecondColorInput.value = selectedDrawing.secondColor || '#000000';
        }
        
        // Show player assignment row only when exactly 1 t-shirt is selected
        const playerRow = document.getElementById('editorTshirtPlayerRow');
        if (playerRow) {
          playerRow.style.display = this.selectedDrawings.length === 1 ? 'flex' : 'none';
        }
        
        // Show movement row when at least one t-shirt is selected
        // If it's part of a group, the animation system will move the whole group
        const tshirtMovementRow = document.getElementById('editorTshirtMovementRow');
        if (tshirtMovementRow) {
          // Always show if we're in the t-shirt properties section (meaning a t-shirt is selected)
          tshirtMovementRow.style.display = 'flex';
        }
        
        // Update assign player button (only if single selection)
        if (this.selectedDrawings.length === 1) {
          this.updateAssignPlayerButton();
        }
        
        // Show events section for tshirts
        const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
        if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'block';
        // Show players section for tshirts
        const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
        if (playersPropertiesSection) playersPropertiesSection.style.display = 'block';
      } else if (selectedDrawing.type === 'animpath') {
        // Animation path: show only animation path properties, hide everything else
        if (lineColorRow) lineColorRow.style.display = 'none';
        if (colorPresetsInline) colorPresetsInline.style.display = 'none';
        if (thicknessRow) thicknessRow.style.display = 'none';
        if (lineStyleRow) lineStyleRow.style.display = 'none';
        if (textPropertiesSection) textPropertiesSection.style.display = 'none';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
        if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
        if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'block';
        if (startCapRow) startCapRow.style.display = 'none';
        if (endCapRow) endCapRow.style.display = 'none';
        if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
        // Hide opacity, enable, color, thickness, style, and other unnecessary properties
        const lineOpacityRow = document.getElementById('editorLineOpacityRow');
        if (lineOpacityRow) lineOpacityRow.style.display = 'none';
        const highlightPropertiesSection = document.getElementById('editorHighlightPropertiesSection');
        if (highlightPropertiesSection) highlightPropertiesSection.style.display = 'none';
        const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
        if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'none';
        const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
        if (playersPropertiesSection) playersPropertiesSection.style.display = 'none';
        // Hide shape animation row for animpaths
        const shapeAnimationRow = document.getElementById('editorShapeAnimationRow');
        if (shapeAnimationRow) shapeAnimationRow.style.display = 'none';
        // Hide event name row for animpaths
        const eventNameRow = document.getElementById('editorEventNameRow');
        if (eventNameRow) eventNameRow.style.display = 'none';
        // Hide LINE PROPERTIES header
        if (linePropertiesHeader) linePropertiesHeader.style.display = 'none';
        fillSectionHeaders.forEach((header, index) => {
          header.style.display = 'none';
        });
      } else if (selectedDrawing.type === 'ball') {
        // Ball: show color picker and ball number
        if (lineColorRow) lineColorRow.style.display = 'flex';
        if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'block';
        if (textPropertiesSection) textPropertiesSection.style.display = 'none';
        if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
        if (animPathPropertiesSection) animPathPropertiesSection.style.display = 'none';
        // Hide everything else
        if (thicknessRow) thicknessRow.style.display = 'none';
        if (lineStyleRow) lineStyleRow.style.display = 'none';
        if (startCapRow) startCapRow.style.display = 'none';
        if (endCapRow) endCapRow.style.display = 'none';
        if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
        // Hide both section headers
        if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'none'; // LINE PROPERTIES
        
        // Update ball number control (show empty if null/undefined)
        const ballNumberInput = document.getElementById('editorBallNumber');
        if (ballNumberInput) {
          ballNumberInput.value = (selectedDrawing.number !== undefined && selectedDrawing.number !== null) ? selectedDrawing.number : '';
        }
        
        // Show movement row when at least one ball is selected
        // If it's part of a group, the animation system will move the whole group
        const ballMovementRow = document.getElementById('editorBallMovementRow');
        if (ballMovementRow) {
          // Always show if we're in the ball properties section (meaning a ball is selected)
          ballMovementRow.style.display = 'flex';
        }
        
        // Show events section for balls
        const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
        if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'block';
        // Show players section for balls
        const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
        if (playersPropertiesSection) playersPropertiesSection.style.display = 'block';
      } else if (selectedDrawing.type === 'freehand' || selectedDrawing.type === 'spray' || selectedDrawing.type === 'heatmap') {
        // Freehand/Spray/Heatmap: show color and opacity (thickness for freehand only, no line style, no fill)
        const lineOpacityRow = document.getElementById('editorLineOpacityRow');
        const highlightPropertiesSection = document.getElementById('editorHighlightPropertiesSection');
        // Hide color picker for heatmap (uses automatic heat scale)
        if (lineColorRow) lineColorRow.style.display = selectedDrawing.type === 'heatmap' ? 'none' : 'flex';
        if (colorPresetsInline) colorPresetsInline.style.display = selectedDrawing.type === 'heatmap' ? 'none' : 'grid';
        // Show thickness only for freehand, not for spray or heatmap
        if (thicknessRow) thicknessRow.style.display = selectedDrawing.type === 'freehand' ? 'flex' : 'none';
        if (lineOpacityRow) lineOpacityRow.style.display = 'flex';
        if (lineStyleRow) lineStyleRow.style.display = 'none';
        if (startCapRow) startCapRow.style.display = 'none';
        if (endCapRow) endCapRow.style.display = 'none';
        if (textPropertiesSection) textPropertiesSection.style.display = 'none';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
        if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
        if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
        // Show events section for all objects
        const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
        if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'block';
        // Show players section for all objects
        const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
        if (playersPropertiesSection) playersPropertiesSection.style.display = 'block';
        // Hide highlight properties for spray and heatmap
        if (highlightPropertiesSection) highlightPropertiesSection.style.display = (selectedDrawing.type === 'spray' || selectedDrawing.type === 'heatmap') ? 'none' : 'block';
        if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'block'; // LINE PROPERTIES
        
        // Initialize color and opacity for spray/freehand
        const lineColorInput = document.getElementById('editorLineColor');
        const lineOpacityInput = document.getElementById('editorLineOpacity');
        const lineOpacityValue = document.getElementById('editorLineOpacityValue');
        
        if (lineColorInput) {
          lineColorInput.value = selectedDrawing.color || this.currentColor || '#FF0000';
        }
        
        if (lineOpacityInput && lineOpacityValue) {
          const opacity = selectedDrawing.opacity !== undefined ? selectedDrawing.opacity : (this.opacity || 1.0);
          lineOpacityInput.value = Math.round(opacity * 100);
          lineOpacityValue.textContent = Math.round(opacity * 100) + '%';
        }
      } else {
        // Normal shapes: show appropriate controls
        const lineOnlyShapes = ['line', 'curve', 'arrow', 'cross', 'barrier', 'biggoal', 'ladder', 'stick'];
        const endpointShapes = ['line', 'curve', 'arrow']; // Only these have start/end cap controls
        const needsFill = !lineOnlyShapes.includes(selectedDrawing.type);
        
        // Show line controls
        const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
        const isSvgElement = svgElements.includes(selectedDrawing.type);
        const lineOpacityRow = document.getElementById('editorLineOpacityRow');
        
        if (lineColorRow) lineColorRow.style.display = 'flex';
        if (colorPresetsInline) colorPresetsInline.style.display = 'grid';
        // Hide thickness and style for SVG elements
        if (thicknessRow) thicknessRow.style.display = isSvgElement ? 'none' : 'flex';
        if (lineOpacityRow) lineOpacityRow.style.display = isSvgElement ? 'none' : 'flex';
        if (lineStyleRow) lineStyleRow.style.display = isSvgElement ? 'none' : 'flex';
        if (textPropertiesSection) textPropertiesSection.style.display = 'none';
        if (tshirtPropertiesSection) tshirtPropertiesSection.style.display = 'none';
        if (ballPropertiesSection) ballPropertiesSection.style.display = 'none';
        if (formationPropertiesSection) formationPropertiesSection.style.display = 'none';
        if (fillSectionHeaders[0]) fillSectionHeaders[0].style.display = 'block'; // LINE PROPERTIES
        
        // Show start/end cap controls only for lines, curves, and arrows (not cross)
        if (endpointShapes.includes(selectedDrawing.type)) {
          if (startCapRow) startCapRow.style.display = 'flex';
          if (endCapRow) endCapRow.style.display = 'flex';
        } else {
          if (startCapRow) startCapRow.style.display = 'none';
          if (endCapRow) endCapRow.style.display = 'none';
        }
        
        // Show/hide fill properties
        if (needsFill) {
          if (fillPropertiesSection) fillPropertiesSection.style.display = 'block';
          // Explicitly show all fill property rows
          if (fillColorRow) {
            fillColorRow.classList.remove('hidden');
            fillColorRow.style.display = 'flex';
          }
          if (fillOpacityRow) {
            fillOpacityRow.classList.remove('hidden');
            fillOpacityRow.style.display = 'flex';
          }
          if (fillStyleRow) {
            fillStyleRow.classList.remove('hidden');
            fillStyleRow.style.display = 'flex';
          }
        } else {
          if (fillPropertiesSection) fillPropertiesSection.style.display = 'none';
          // Hide fill property rows
          if (fillColorRow) {
            fillColorRow.classList.add('hidden');
            fillColorRow.style.display = 'none';
          }
          if (fillOpacityRow) {
            fillOpacityRow.classList.add('hidden');
            fillOpacityRow.style.display = 'none';
          }
          if (fillStyleRow) {
            fillStyleRow.classList.add('hidden');
            fillStyleRow.style.display = 'none';
          }
        }
        
        // Show events section for all normal shapes (line, arrow, curve, etc.)
        const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
        if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'block';
        // Show players section for all normal shapes
        const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
        if (playersPropertiesSection) playersPropertiesSection.style.display = 'block';
      }

      // Update style controls to match selected shape
      // Update line thickness and opacity controls
      const lineThicknessInput = document.getElementById('editorLineThickness');
      const lineThicknessValue = document.getElementById('editorLineThicknessValue');
      const lineOpacityInput = document.getElementById('editorLineOpacity');
      const lineOpacityValue = document.getElementById('editorLineOpacityValue');
      
      if (lineThicknessInput && lineThicknessValue) {
        const thickness = selectedDrawing.lineWidth || this.lineWidth || 2;
        lineThicknessInput.value = thickness;
        lineThicknessValue.textContent = thickness + 'px';
      }
      
      if (lineOpacityInput && lineOpacityValue) {
        const opacity = selectedDrawing.opacity !== undefined ? selectedDrawing.opacity : (this.opacity || 1.0);
        lineOpacityInput.value = Math.round(opacity * 100);
        lineOpacityValue.textContent = Math.round(opacity * 100) + '%';
      }
      // Handle fillColor - initialize if not set
      const fillColorInput = document.getElementById('editorFillColor');
      if (fillColorInput) {
        if (selectedDrawing.fillColor) {
          fillColorInput.value = selectedDrawing.fillColor;
        } else {
          // Initialize with default white if not set
          fillColorInput.value = '#FFFFFF';
        }
      }
      // Handle fillOpacity - it might be stored as 0-1 or 0-100, normalize to 0-1
      if (selectedDrawing.fillOpacity !== undefined) {
        const fillOpacityInput = document.getElementById('editorFillOpacity');
        const fillOpacityValue = document.getElementById('editorFillOpacityValue');
        if (fillOpacityInput && fillOpacityValue) {
          // Normalize: if > 1, assume it's 0-100, otherwise assume 0-1
          const normalizedOpacity = selectedDrawing.fillOpacity > 1 ? selectedDrawing.fillOpacity / 100 : selectedDrawing.fillOpacity;
          fillOpacityInput.value = Math.round(normalizedOpacity * 100);
          fillOpacityValue.textContent = Math.round(normalizedOpacity * 100) + '%';
        }
      } else {
        // If fillOpacity is not set, initialize it to 0
        const fillOpacityInput = document.getElementById('editorFillOpacity');
        const fillOpacityValue = document.getElementById('editorFillOpacityValue');
        if (fillOpacityInput && fillOpacityValue) {
          fillOpacityInput.value = 0;
          fillOpacityValue.textContent = '0%';
        }
      }
      // Handle fillStyle - initialize if not set
      const fillStyleSelect = document.getElementById('editorFillStyle');
      if (fillStyleSelect) {
        if (selectedDrawing.fillStyle) {
          fillStyleSelect.value = selectedDrawing.fillStyle;
        } else {
          // Initialize with default solid if not set
          fillStyleSelect.value = 'solid';
        }
      }
      if (selectedDrawing.lineStyle) {
        const lineStyleSelect = document.getElementById('editorLineStyle');
        if (lineStyleSelect) lineStyleSelect.value = selectedDrawing.lineStyle;
      }
      if (selectedDrawing.startCap !== undefined) {
        const startCapSelect = document.getElementById('editorStartCap');
        if (startCapSelect) startCapSelect.value = selectedDrawing.startCap;
      }
      if (selectedDrawing.endCap !== undefined) {
        const endCapSelect = document.getElementById('editorEndCap');
        if (endCapSelect) endCapSelect.value = selectedDrawing.endCap;
      }

      // Update highlight controls (not available for t-shirts, balls, animpaths, etc.)
      const highlightPropertiesSection = document.getElementById('editorHighlightPropertiesSection');
      if (highlightPropertiesSection) {
        // Hide highlight section for t-shirts, balls, animpaths, spray, heatmap, formations, and SVG elements
        const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
        const highlightNotAvailable = selectedDrawing.type === 'tshirt' || selectedDrawing.type === 'ball' || selectedDrawing.type === 'animpath' || selectedDrawing.type === 'spray' || selectedDrawing.type === 'heatmap' || selectedDrawing.type === 'formation' || svgElements.includes(selectedDrawing.type);
        highlightPropertiesSection.style.display = highlightNotAvailable ? 'none' : 'block';

        if (!highlightNotAvailable) {
          // Update highlight enabled checkbox
          const highlightEnabledInput = document.getElementById('editorHighlightEnabled');
          if (highlightEnabledInput) {
            highlightEnabledInput.checked = selectedDrawing.highlightEnabled || false;
          }

          // Update highlight color
          const highlightColorInput = document.getElementById('editorHighlightColor');
          if (highlightColorInput) {
            // If the drawing has a custom highlight color, use it; otherwise use the shape's color
            highlightColorInput.value = selectedDrawing.highlightColor || selectedDrawing.color || '#FF0000';
          }

          // Update highlight thickness
          const highlightThicknessInput = document.getElementById('editorHighlightThickness');
          const highlightThicknessValue = document.getElementById('editorHighlightThicknessValue');
          if (highlightThicknessInput) {
            highlightThicknessInput.value = selectedDrawing.highlightThickness || 3;
          }
          if (highlightThicknessValue) {
            highlightThicknessValue.textContent = (selectedDrawing.highlightThickness || 3) + 'px';
          }

          // Update highlight style
          const highlightStyleSelect = document.getElementById('editorHighlightStyle');
          if (highlightStyleSelect) {
            highlightStyleSelect.value = selectedDrawing.highlightStyle || 'solid';
          }
        }
      }
      
      // Hide event name dropdown (duplicate - events are managed in EVENTS section at bottom)
      const eventNameRow = document.getElementById('editorEventNameRow');
      if (eventNameRow) {
        eventNameRow.style.display = 'none';
      }
      
      // Update shape animation dropdown (available for all shapes except animpaths)
      const shapeAnimationRow = document.getElementById('editorShapeAnimationRow');
      const shapeAnimationSelect = document.getElementById('editorShapeAnimation');
      if (shapeAnimationRow && shapeAnimationSelect) {
        // Show animation controls for all shapes except animpaths
        if (selectedDrawing.type === 'animpath') {
          shapeAnimationRow.style.display = 'none';
        } else {
          shapeAnimationRow.style.display = 'flex';
        }
        
        // Set the value based on selected drawing(s)
        // If multiple shapes selected, show empty if they have different animation types
        let animationTypeToShow = '';
        if (this.selectedDrawings.length > 1) {
          const animationTypes = this.selectedDrawings.map(idx => {
            const d = this.drawings[idx];
            return d ? (d.animationType || null) : null;
          });
          const allSame = animationTypes.every(type => type === animationTypes[0]);
          animationTypeToShow = allSame ? (animationTypes[0] || '') : '';
        } else {
          animationTypeToShow = selectedDrawing.animationType || '';
        }
        
        this.shapeAnimationType = animationTypeToShow || null;
        shapeAnimationSelect.value = animationTypeToShow || '';
      }
      
      // Update group actions visibility - show when multiple elements are selected
      const groupActionsRow = document.getElementById('editorGroupActionsRow');
      const groupBtn = document.getElementById('editorGroupBtn');
      const ungroupBtn = document.getElementById('editorUngroupBtn');
      
      if (groupActionsRow && groupBtn && ungroupBtn) {
        if (this.selectedDrawings.length >= 2) {
          // 2+ elements selected - show group buttons
          groupActionsRow.style.display = 'flex';
          
          // Check if all selected are in the same group
          const groupIds = new Set();
          let allGrouped = true;
          let allUngrouped = true;
          
          this.selectedDrawings.forEach(idx => {
            const d = this.drawings[idx];
            if (d) {
              if (d.groupId !== undefined) {
                groupIds.add(d.groupId);
                allUngrouped = false;
              } else {
                allGrouped = false;
              }
            }
          });
          
          // Enable Group button if not all are in the same group
          groupBtn.disabled = groupIds.size === 1 && allGrouped;
          
          // Enable Ungroup button if all selected are in the same group
          ungroupBtn.disabled = !(groupIds.size === 1 && allGrouped);
        } else if (this.selectedDrawings.length === 1) {
          // Single element selected - show buttons if it's in a group
          const selectedDrawing = this.drawings[this.selectedDrawings[0]];
          if (selectedDrawing && selectedDrawing.groupId !== undefined) {
            groupActionsRow.style.display = 'flex';
            groupBtn.disabled = true;
            ungroupBtn.disabled = false;
          } else {
            groupActionsRow.style.display = 'none';
          }
        } else {
          // No selection - hide group buttons
          groupActionsRow.style.display = 'none';
        }
      }
      
      // Update animation path properties if animpath is selected
      if (selectedDrawing.type === 'animpath') {
        const animDurationInput = document.getElementById('editorAnimDuration');
        const animDurationValue = document.getElementById('editorAnimDurationValue');
        const animDelayInput = document.getElementById('editorAnimDelay');
        const animDelayValue = document.getElementById('editorAnimDelayValue');
        const animEasingSelect = document.getElementById('editorAnimEasing');
        
        if (animDurationInput && animDurationValue) {
          const duration = selectedDrawing.duration !== undefined ? selectedDrawing.duration : (this.animPathDuration || 2.0);
          animDurationInput.value = duration;
          animDurationValue.textContent = duration.toFixed(1) + 's';
          this.animPathDuration = duration;
        }
        
        if (animDelayInput && animDelayValue) {
          const delay = selectedDrawing.delay !== undefined ? selectedDrawing.delay : (this.animPathDelay || 0);
          animDelayInput.value = delay;
          animDelayValue.textContent = delay.toFixed(2) + 's';
          this.animPathDelay = delay;
        }
        
        if (animEasingSelect) {
          const easing = selectedDrawing.easing || this.animPathEasing || 'easeOut';
          animEasingSelect.value = easing;
          this.animPathEasing = easing;
        }
      }
      
      // Update events display
      this.updateEventsDisplay();
      // Update players display
      this.updatePlayersDisplay();
    } else if (styleToolbar) {
      styleToolbar.classList.add('hidden');
      // Hide events section when nothing is selected
      const eventsPropertiesSection = document.getElementById('editorEventsPropertiesSection');
      if (eventsPropertiesSection) eventsPropertiesSection.style.display = 'none';
      // Hide players section when nothing is selected
      const playersPropertiesSection = document.getElementById('editorPlayersPropertiesSection');
      if (playersPropertiesSection) playersPropertiesSection.style.display = 'none';
    }
    
    // Update button states (copy/paste)
    this.updateButtonStates();
  }

  updateCanvasSize() {
    if (!this.canvas || !this.image) return;
    
    // Use requestAnimationFrame to ensure layout is ready
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const container = this.canvas.parentElement; // This should be .editor-canvas-container
        if (!container) return;
        
        // Get the actual available space in the container
        // The container should already account for toolbars due to flex layout
        const containerRect = container.getBoundingClientRect();
        let containerWidth = containerRect.width;
        let containerHeight = containerRect.height;
        
        // If container dimensions are invalid, calculate from main area minus toolbars
        if (containerWidth <= 0 || containerHeight <= 0) {
          const mainArea = document.querySelector('.editor-main');
          if (mainArea) {
            const mainRect = mainArea.getBoundingClientRect();
            containerWidth = mainRect.width;
            containerHeight = mainRect.height;
            
            // Subtract toolbar widths
            const leftToolbar = document.querySelector('.editor-toolbar');
            if (leftToolbar) {
              containerWidth -= leftToolbar.getBoundingClientRect().width;
            }
            
            const rightToolbar = document.querySelector('.editor-style-toolbar');
            if (rightToolbar && !rightToolbar.classList.contains('hidden')) {
              containerWidth -= rightToolbar.getBoundingClientRect().width;
            }
          }
        }
        
        // Add some padding to prevent edge clipping
        const padding = 20;
        containerWidth = Math.max(containerWidth - padding, 100);
        containerHeight = Math.max(containerHeight - padding, 100);
        
        // Get the original image dimensions
        const origWidth = this.originalCanvasWidth || this.image.width;
        const origHeight = this.originalCanvasHeight || this.image.height;
        
        // Determine canvas dimensions based on rotation
        // For 90° and 270° rotations, swap width and height
        let canvasWidth, canvasHeight;
        if (this.canvasRotation === 90 || this.canvasRotation === 270) {
          canvasWidth = origHeight;
          canvasHeight = origWidth;
        } else {
          canvasWidth = origWidth;
          canvasHeight = origHeight;
        }
        
        // Calculate scale to fit container while maintaining aspect ratio
        // Use the rotated dimensions for aspect ratio calculation
        const imageAspectRatio = canvasWidth / canvasHeight;
        const containerAspectRatio = containerWidth / containerHeight;
        
        let displayWidth, displayHeight;
        
        if (imageAspectRatio > containerAspectRatio) {
          // Image is wider - fit to width
          displayWidth = containerWidth;
          displayHeight = containerWidth / imageAspectRatio;
        } else {
          // Image is taller - fit to height
          displayHeight = containerHeight;
          displayWidth = containerHeight * imageAspectRatio;
        }
        
        // Set canvas display size (visual size)
        this.canvas.style.width = displayWidth + 'px';
        this.canvas.style.height = displayHeight + 'px';
        
        // Canvas internal size (coordinate system) should reflect rotation
        // For 90° and 270° rotations, swap the canvas dimensions
        this.canvas.width = canvasWidth;
        this.canvas.height = canvasHeight;
        
        // Set transform origin to center for proper zoom
        this.canvas.style.transformOrigin = 'center center';
        
        // Reapply zoom if it was set
        if (this.zoom && this.zoom !== 1) {
          this.canvas.style.transform = `scale(${this.zoom})`;
        } else {
          this.canvas.style.transform = 'scale(1)';
        }
        
        // Redraw to update display
        this.redraw();
      });
    });
  }

  loadImage(imageSrc, skipInitializeSlides = false, isSlideSpecific = false) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        this.image = img;
        
        // Only update originalImageData if this is not a slide-specific background change
        // This preserves the default background reference
        if (!isSlideSpecific) {
          this.originalImageData = imageSrc;
        }
        
        // Store the true original background only on first load (when trueOriginalImageData is null)
        // This ensures we always have a reference to the unmerged background
        if (this.trueOriginalImageData === null) {
          this.trueOriginalImageData = imageSrc;
        }
        
        // Set canvas internal size to match image (coordinate system)
        this.canvas.width = img.width;
        this.canvas.height = img.height;
        
        // Wait for layout to be ready, then update canvas size
        // Use double requestAnimationFrame to ensure layout is complete
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            // Update canvas display size to fit container while maintaining aspect ratio
            this.updateCanvasSize();
            
            // Reset transform and origin
            this.canvas.style.transform = 'scale(1)';
            this.canvas.style.transformOrigin = 'center center';
            
            // Draw image
            this.redraw();
            this.saveState();
            
            // Initialize slides system only on first load, not when changing backgrounds
            if (!skipInitializeSlides && this.slides.length === 0) {
              this.initializeSlides();
            }
            
            resolve();
          });
        });
      };
      img.onerror = reject;
      img.src = imageSrc;
    });
  }

  redraw() {
    if (!this.canvas) {
      console.warn('redraw: Canvas not available');
      return;
    }
    
    console.log('redraw: Drawing', this.drawings.length, 'drawings');
    
    // Check if context is lost - try to restore it
    if (!this.ctx) {
      console.warn('Editor: Canvas context is null, attempting to restore');
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
      if (!this.ctx) {
        console.error('Editor: Failed to restore canvas context');
        return;
      }
    }
    
    // Check if context is actually lost (some browsers set ctx but it's invalid)
    try {
      // Test if context is valid by checking a property
      const test = this.ctx.canvas;
      if (!test) {
        throw new Error('Context is invalid');
      }
    } catch (e) {
      console.warn('Editor: Canvas context is invalid, attempting to restore');
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
      if (!this.ctx) {
        console.error('Editor: Failed to restore canvas context');
        return;
      }
    }
    
    if (!this.image) {
      // This is normal during initialization - image hasn't been loaded yet
      // Only log if we've previously had an image (indicating a problem)
      if (this.originalImageData || this.trueOriginalImageData) {
        console.warn('Editor: Image was loaded but is now missing, cannot redraw');
      }
      return;
    }
    
    // Ensure image is loaded before drawing
    if (!this.image.complete || this.image.naturalWidth === 0) {
      console.warn('Editor: Image not fully loaded, waiting...');
      if (this.image.onload) {
        // Already has a handler, just return
        return;
      }
      this.image.onload = () => {
        this.redraw();
        this.image.onload = null; // Remove handler after use
      };
      return;
    }
    
    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Apply rotation transformation if needed
    this.ctx.save();
    this.applyCanvasRotation();
    
    // Draw image
    try {
      this.ctx.drawImage(this.image, 0, 0);
    } catch (e) {
      console.error('Editor: Error drawing image:', e);
      this.ctx.restore();
      // Try to reload the image
      if (this.originalImageData || this.trueOriginalImageData) {
        const imageToLoad = this.trueOriginalImageData || this.originalImageData;
        this.loadImage(imageToLoad).then(() => {
          this.redraw();
        }).catch(err => {
          console.error('Editor: Failed to reload image:', err);
        });
      }
      return;
    }
    
    // Draw zone overlay if enabled
    if (this.showZoneOverlay) {
      this.drawZoneOverlay();
    }
    
    // Draw all drawings
    console.log('redraw: About to draw', this.drawings.length, 'drawings');
    this.drawings.forEach((drawing, index) => {
      if (!drawing) {
        console.warn('redraw: Drawing at index', index, 'is null/undefined');
        return;
      }
      if (!drawing.type) {
        console.warn('redraw: Drawing at index', index, 'has no type:', drawing);
        return;
      }
      // Skip animation paths when exporting GIF
      if (this.isExportingGif && drawing.type === 'animpath') {
        return;
      }
      console.log(`redraw: Drawing element ${index}: type=${drawing.type}, startX=${drawing.startX}, startY=${drawing.startY}, endX=${drawing.endX}, endY=${drawing.endY}, svgUrl=${drawing.svgUrl || 'none'}, hasSvgElement=${!!drawing.svgElement}`);
      this.drawSingleDrawing(drawing, this.selectedDrawings.includes(index));
    });
    console.log('redraw: Finished drawing all drawings');
    
    // Restore context after rotation
    this.ctx.restore();
    
    // Draw current tool preview (not affected by rotation)
    this.ctx.save();
    this.applyCanvasRotation();
    this.drawToolPreview();
    this.ctx.restore();

    // Draw selection rectangle if active (not affected by rotation)
    this.ctx.save();
    this.applyCanvasRotation();
    this.drawSelectionRect();
    this.ctx.restore();
    
    // Update layers panel if visible
    this.updateLayersPanelIfVisible();
  }
  
  updateLayersPanelIfVisible() {
    const panel = document.getElementById('editorLayersPanel');
    if (panel && panel.classList.contains('visible')) {
      // Debounce to avoid too many updates
      if (this._layersUpdateTimeout) {
        clearTimeout(this._layersUpdateTimeout);
      }
      this._layersUpdateTimeout = setTimeout(() => {
        this.updateLayersList();
      }, 100);
    }
  }
  
  drawSingleDrawing(drawing, isSelected = false) {
    this.ctx.save();

    // Apply shape animations if present
    let animationProgress = drawing._animationProgress;
    const animationType = drawing._animationType;
    const bounds = this.getDrawingBoundsForRotation(drawing);
    
    if (animationProgress !== undefined && animationType && bounds) {
      const centerX = (bounds.minX + bounds.maxX) / 2;
      const centerY = (bounds.minY + bounds.maxY) / 2;
      const width = bounds.maxX - bounds.minX;
      const height = bounds.maxY - bounds.minY;
      
      // Translate to center for transformations
      this.ctx.translate(centerX, centerY);
      
      // Apply animation transforms
      switch (animationType) {
        case 'fade':
          // Opacity handled below in globalAlpha
          break;
        case 'scale':
          // Scale from 0 to 1
          const scale = animationProgress;
          this.ctx.scale(scale, scale);
          break;
        case 'spin':
          // Rotate 360 degrees
          const rotation = animationProgress * Math.PI * 2;
          this.ctx.rotate(rotation);
          break;
        case 'slideLeft':
          // Slide from left (negative X offset)
          const slideLeftOffset = (1 - animationProgress) * (this.canvas.width + width);
          this.ctx.translate(-slideLeftOffset, 0);
          break;
        case 'slideRight':
          // Slide from right (positive X offset)
          const slideRightOffset = (1 - animationProgress) * (this.canvas.width + width);
          this.ctx.translate(slideRightOffset, 0);
          break;
        case 'light':
          // Light animation doesn't transform the shape, just draws a light effect
          // The light effect will be drawn after the shape
          break;
      }
      
      // Translate back from center
      this.ctx.translate(-centerX, -centerY);
    }

    // Set opacity and thickness
    let opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    
    // Apply fade animation to opacity
    if (animationType === 'fade' && animationProgress !== undefined) {
      opacity = opacity * animationProgress;
    }
    
    this.ctx.globalAlpha = Math.min(opacity, 1.0); // Cap alpha at 1.0 for transparency

    if (isSelected) {
      // Draw selection glow effect
      this.ctx.shadowColor = '#1f6feb';
      this.ctx.shadowBlur = 8;
      this.ctx.shadowOffsetX = 0;
      this.ctx.shadowOffsetY = 0;
    }

    this.ctx.strokeStyle = drawing.color;
    this.ctx.fillStyle = drawing.color;
    // Scale line width based on opacity (for opacity > 1.0, make lines thicker)
    // If opacity is 0, line width is 0 (line disappears)
    const baseLineWidth = drawing.lineWidth || 2;
    this.ctx.lineWidth = opacity > 0 ? baseLineWidth * Math.max(opacity, 1.0) : 0;
    
    // Set line style
    this.setLineStyle(drawing.lineStyle || 'solid');
    
    // Apply rotation if present (for shapes, not lines)
    const rotatableTypes = ['circle', 'arc', 'polygon', 'triangle', 'rectangle', 'cross', 'tshirt', 'ball', 'curve', 'barrier', 'biggoal', 'ladder', 'stick'];
    // T-shirts and balls should always stay upright (not rotate with canvas)
    const alwaysUprightTypes = ['tshirt', 'ball'];
    const canvasRotationRadians = (this.canvasRotation || 0) * Math.PI / 180;
    const elementRotation = drawing.rotation || 0;
    
    // For upright elements, counter-rotate to cancel out canvas rotation so they stay vertical
    // For other elements, just use their own rotation
    let totalRotation;
    if (alwaysUprightTypes.includes(drawing.type)) {
      // Counter-rotate to stay upright: element rotation minus canvas rotation
      totalRotation = elementRotation - canvasRotationRadians;
    } else {
      totalRotation = elementRotation;
    }
    
    if (totalRotation !== 0 && rotatableTypes.includes(drawing.type)) {
      // Calculate center of the drawing
      const rotationBounds = this.getDrawingBoundsForRotation(drawing);
      if (rotationBounds) {
        const centerX = (rotationBounds.minX + rotationBounds.maxX) / 2;
        const centerY = (rotationBounds.minY + rotationBounds.maxY) / 2;
        
        // Translate to center, rotate, translate back
        this.ctx.translate(centerX, centerY);
        this.ctx.rotate(totalRotation);
        this.ctx.translate(-centerX, -centerY);
      }
    }
    
    switch (drawing.type) {
      case 'line':
        this.drawLine(drawing);
        break;
      case 'curve':
        this.drawCurve(drawing);
        break;
      case 'arrow':
        this.drawArrow(drawing);
        break;
      case 'circle':
        this.drawCircle(drawing);
        break;
      case 'oval':
        this.drawOval(drawing);
        break;
      case 'arc':
        this.drawArc(drawing);
        break;
      case 'polygon':
        this.drawPolygon(drawing);
        break;
      case 'freehand':
        this.drawFreehand(drawing);
        break;
      case 'spray':
        this.drawSpray(drawing);
        break;
      case 'heatmap':
        this.drawHeatmap(drawing);
        break;
      case 'text':
        this.drawText(drawing);
        break;
      case 'image':
        this.drawImageDrawing(drawing);
        break;
      case 'ball':
        this.drawBall(drawing);
        break;
      case 'tshirt':
        this.drawTshirt(drawing);
        break;
      case 'barrier':
        this.drawBarrier(drawing);
        break;
      case 'biggoal':
        this.drawBigGoal(drawing);
        break;
      case 'ladder':
        this.drawLadder(drawing);
        break;
      case 'stick':
        this.drawStick(drawing);
        break;
      case 'animpath':
        this.drawAnimPath(drawing);
        break;
      case 'cross':
        this.drawCross(drawing);
        break;
      case 'triangle':
        this.drawTriangle(drawing);
        break;
      case 'rectangle':
        this.drawRectangle(drawing);
        break;
    }

    // Draw persistent highlight around the object if enabled
    if (drawing.highlightEnabled) {
      this.ctx.restore();
      this.drawObjectHighlight(drawing);
      this.ctx.save(); // Re-save for selection handling
    }
    
    // Draw light animation effect if present (after shape, before highlights)
    if (drawing._animationType === 'light' && drawing._animationProgress !== undefined) {
      // Restore to base state (remove any transforms from shape drawing)
      // We're still inside the save() from the start of drawSingleDrawing
      this.ctx.restore();
      this.drawLightAnimation(drawing, drawing._animationProgress);
      this.ctx.save(); // Re-save for selection handling
    }
    
    // Draw group indicator (border around grouped elements)
    if (drawing.groupId !== undefined) {
      this.ctx.restore();
      this.drawGroupIndicator(drawing);
      this.ctx.save();
    }

    // Draw selection highlight after the drawing
    if (isSelected) {
      this.ctx.restore(); // Restore to remove glow effect
      this.drawSelectionBox(drawing);
      // Draw control points for curves
      if (drawing.type === 'curve') {
        this.drawCurveControlPoints(drawing);
      }
    } else {
      this.ctx.restore();
    }
  }
  
  // Get points along the perimeter of a shape
  getPerimeterPoints(drawing) {
    const points = [];
    
    switch (drawing.type) {
      case 'line':
      case 'arrow':
        points.push({ x: drawing.startX, y: drawing.startY });
        points.push({ x: drawing.endX, y: drawing.endY });
        break;
        
      case 'curve':
        // Sample points along the bezier curve
        const numSamples = 50;
        for (let i = 0; i <= numSamples; i++) {
          const t = i / numSamples;
          const point = this.getPointOnBezier(drawing, t);
          points.push(point);
        }
        break;
        
      case 'circle':
      case 'arc':
        const centerX = (drawing.startX + drawing.endX) / 2;
        const centerY = (drawing.startY + drawing.endY) / 2;
        const radiusX = Math.abs(drawing.endX - drawing.startX) / 2;
        const radiusY = Math.abs(drawing.endY - drawing.startY) / 2;
        const radius = Math.max(radiusX, radiusY);
        
        const numPoints = 64; // Smooth circle
        const startAngle = drawing.type === 'arc' ? 0 : 0;
        const endAngle = drawing.type === 'arc' ? Math.PI : Math.PI * 2;
        
        for (let i = 0; i <= numPoints; i++) {
          const angle = startAngle + (endAngle - startAngle) * (i / numPoints);
          points.push({
            x: centerX + radius * Math.cos(angle),
            y: centerY + radius * Math.sin(angle)
          });
        }
        break;
        
      case 'rectangle':
        const rectMinX = Math.min(drawing.startX, drawing.endX);
        const rectMinY = Math.min(drawing.startY, drawing.endY);
        const rectMaxX = Math.max(drawing.startX, drawing.endX);
        const rectMaxY = Math.max(drawing.startY, drawing.endY);
        
        // Top edge
        for (let x = rectMinX; x <= rectMaxX; x += 2) {
          points.push({ x, y: rectMinY });
        }
        // Right edge
        for (let y = rectMinY; y <= rectMaxY; y += 2) {
          points.push({ x: rectMaxX, y });
        }
        // Bottom edge (reverse)
        for (let x = rectMaxX; x >= rectMinX; x -= 2) {
          points.push({ x, y: rectMaxY });
        }
        // Left edge (reverse)
        for (let y = rectMaxY; y >= rectMinY; y -= 2) {
          points.push({ x: rectMinX, y });
        }
        break;
        
      case 'oval':
        const ovalCenterX = (drawing.startX + drawing.endX) / 2;
        const ovalCenterY = (drawing.startY + drawing.endY) / 2;
        const ovalRadiusX = Math.abs(drawing.endX - drawing.startX) / 2;
        const ovalRadiusY = Math.abs(drawing.endY - drawing.startY) / 2;
        
        const ovalNumPoints = 64;
        for (let i = 0; i <= ovalNumPoints; i++) {
          const angle = (i / ovalNumPoints) * Math.PI * 2;
          points.push({
            x: ovalCenterX + ovalRadiusX * Math.cos(angle),
            y: ovalCenterY + ovalRadiusY * Math.sin(angle)
          });
        }
        break;
        
      case 'triangle':
        const triMinX = Math.min(drawing.startX, drawing.endX);
        const triMinY = Math.min(drawing.startY, drawing.endY);
        const triMaxX = Math.max(drawing.startX, drawing.endX);
        const triMaxY = Math.max(drawing.startY, drawing.endY);
        const triMidX = (triMinX + triMaxX) / 2;
        
        // Top point to right point
        for (let i = 0; i <= 20; i++) {
          const t = i / 20;
          points.push({
            x: triMidX + (triMaxX - triMidX) * t,
            y: triMinY + (triMaxY - triMinY) * t
          });
        }
        // Right point to left point
        for (let i = 0; i <= 20; i++) {
          const t = i / 20;
          points.push({
            x: triMaxX + (triMinX - triMaxX) * t,
            y: triMaxY
          });
        }
        // Left point back to top
        for (let i = 0; i <= 20; i++) {
          const t = i / 20;
          points.push({
            x: triMinX + (triMidX - triMinX) * t,
            y: triMaxY + (triMinY - triMaxY) * t
          });
        }
        break;
        
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          // Add all polygon points
          drawing.points.forEach(point => {
            points.push({ x: point.x, y: point.y });
          });
          // Close the polygon
          if (drawing.points.length > 0) {
            points.push({ x: drawing.points[0].x, y: drawing.points[0].y });
          }
        }
        break;
        
      default:
        // For other shapes, use bounding box
        const minX = Math.min(drawing.startX, drawing.endX);
        const minY = Math.min(drawing.startY, drawing.endY);
        const maxX = Math.max(drawing.startX, drawing.endX);
        const maxY = Math.max(drawing.startY, drawing.endY);
        points.push({ x: minX, y: minY });
        points.push({ x: maxX, y: minY });
        points.push({ x: maxX, y: maxY });
        points.push({ x: minX, y: maxY });
        points.push({ x: minX, y: minY }); // Close
        break;
    }
    
    return points;
  }
  
  // Draw light animation effect along perimeter
  drawLightAnimation(drawing, progress) {
    if (!this.ctx) return;
    
    const perimeterPoints = this.getPerimeterPoints(drawing);
    if (perimeterPoints.length < 2) {
      return;
    }
    
    // Get position along perimeter
    const lightPosition = this.getPositionAlongPath(perimeterPoints, progress);
    
    if (!lightPosition || isNaN(lightPosition.x) || isNaN(lightPosition.y)) {
      return;
    }
    
    // Draw glowing light effect
    this.ctx.save();
    
    // Reset any transforms and set global alpha
    this.ctx.globalAlpha = 1.0;
    this.ctx.setLineDash([]);
    
    // Create radial gradient for glow effect - make it larger and brighter
    const glowRadius = 20; // Increased from 15
    const gradient = this.ctx.createRadialGradient(
      lightPosition.x, lightPosition.y, 0,
      lightPosition.x, lightPosition.y, glowRadius
    );
    
    // Use bright white/yellow for visibility, or brighten the shape's color
    const lightColor = drawing.color || '#FFFF00';
    const rgb = this.hexToRgb(lightColor);
    
    // Make it brighter - add white to the color
    let brightR, brightG, brightB;
    if (rgb) {
      brightR = Math.min(255, rgb.r + 100);
      brightG = Math.min(255, rgb.g + 100);
      brightB = Math.min(255, rgb.b + 100);
    } else {
      brightR = 255;
      brightG = 255;
      brightB = 0;
    }
    
    const glowColor = `rgba(${brightR}, ${brightG}, ${brightB}, 1)`;
    const fadeColor = `rgba(${brightR}, ${brightG}, ${brightB}, 0)`;
    
    gradient.addColorStop(0, glowColor);
    gradient.addColorStop(0.3, `rgba(${brightR}, ${brightG}, ${brightB}, 0.8)`);
    gradient.addColorStop(0.6, fadeColor);
    gradient.addColorStop(1, fadeColor);
    
    // Draw outer glow
    this.ctx.fillStyle = gradient;
    this.ctx.beginPath();
    this.ctx.arc(lightPosition.x, lightPosition.y, glowRadius, 0, Math.PI * 2);
    this.ctx.fill();
    
    // Draw bright center dot - larger and brighter
    this.ctx.fillStyle = glowColor;
    this.ctx.beginPath();
    this.ctx.arc(lightPosition.x, lightPosition.y, 6, 0, Math.PI * 2); // Increased from 4
    this.ctx.fill();
    
    // Draw even brighter inner core
    this.ctx.fillStyle = '#FFFFFF';
    this.ctx.beginPath();
    this.ctx.arc(lightPosition.x, lightPosition.y, 3, 0, Math.PI * 2);
    this.ctx.fill();
    
    this.ctx.restore();
  }
  
  // Helper to convert hex color to RGB
  hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }
  
  drawZoneOverlay() {
    if (!this.ctx || !this.image) return;
    
    // Don't draw zones for goal images - zones are not applicable for goal schemes
    const isGoalImage = this.image.src && (this.image.src.includes('goal.svg') || this.image.src.includes('goal'));
    if (isGoalImage) return;
    
    this.ctx.save();
    
    const canvasWidth = this.canvas.width;
    const canvasHeight = this.canvas.height;
    
    // 18 zones in a 3x6 grid (3 rows, 6 columns)
    const rows = 3;
    const cols = 6;
    const zoneWidth = canvasWidth / cols;
    const zoneHeight = canvasHeight / rows;
    
    // Zone numbering pattern from the image:
    // Top row: 1, 4, 7, 10, 13, 16
    // Middle row: 2, 5, 8, 11, 14, 17
    // Bottom row: 3, 6, 9, 12, 15, 18
    const zoneNumbers = [
      [1, 4, 7, 10, 13, 16],  // Row 1 (top)
      [2, 5, 8, 11, 14, 17],  // Row 2 (middle)
      [3, 6, 9, 12, 15, 18]   // Row 3 (bottom)
    ];
    
    // Draw zone rectangles (only borders and numbers, no fill to preserve field color)
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const x = col * zoneWidth;
        const y = row * zoneHeight;
        const zoneNumber = zoneNumbers[row][col];
        
        // Draw rectangle border (75% transparent = 25% opacity)
        this.ctx.globalAlpha = 0.25;
        this.ctx.strokeStyle = '#000000';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, zoneWidth, zoneHeight);
        
        // Draw zone number in the center (75% transparent = 25% opacity)
        this.ctx.globalAlpha = 0.25;
        this.ctx.fillStyle = '#000000';
        this.ctx.font = 'bold ' + Math.max(16, Math.min(zoneWidth, zoneHeight) * 0.15) + 'px sans-serif';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(zoneNumber.toString(), x + zoneWidth / 2, y + zoneHeight / 2);
      }
    }
    
    this.ctx.restore();
  }
  
  drawSelectionBox(drawing) {
    // Draw bounding box for selected element
    let minX, minY, maxX, maxY;
    
    switch (drawing.type) {
      case 'line':
      case 'arrow':
        minX = Math.min(drawing.startX, drawing.endX) - 5;
        minY = Math.min(drawing.startY, drawing.endY) - 5;
        maxX = Math.max(drawing.startX, drawing.endX) + 5;
        maxY = Math.max(drawing.startY, drawing.endY) + 5;
        break;
      case 'curve':
      case 'animpath':
        if (drawing.controlPoint) {
          const points = [
            {x: drawing.startX, y: drawing.startY},
            {x: drawing.controlPoint.x, y: drawing.controlPoint.y},
            {x: drawing.endX, y: drawing.endY}
          ];
          minX = Math.min(...points.map(p => p.x)) - 5;
          minY = Math.min(...points.map(p => p.y)) - 5;
          maxX = Math.max(...points.map(p => p.x)) + 5;
          maxY = Math.max(...points.map(p => p.y)) + 5;
        } else {
          minX = Math.min(drawing.startX, drawing.endX) - 5;
          minY = Math.min(drawing.startY, drawing.endY) - 5;
          maxX = Math.max(drawing.startX, drawing.endX) + 5;
          maxY = Math.max(drawing.startY, drawing.endY) + 5;
        }
        break;
      case 'circle':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        const circleRadius = Math.max(circleWidth, circleHeight) / 2;
        const circleCenterX = circleLeft + circleWidth / 2;
        const circleCenterY = circleTop + circleHeight / 2;
        minX = circleCenterX - circleRadius - 5;
        minY = circleCenterY - circleRadius - 5;
        maxX = circleCenterX + circleRadius + 5;
        maxY = circleCenterY + circleRadius + 5;
        break;
      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        minX = ovalLeft - 5;
        minY = ovalTop - 5;
        maxX = ovalLeft + ovalWidth + 5;
        maxY = ovalTop + ovalHeight + 5;
        break;
      case 'text':
        this.ctx.font = `${drawing.fontSize || 16}px sans-serif`;
        const metrics = this.ctx.measureText(drawing.text);
        minX = drawing.x - 5;
        minY = drawing.y - (drawing.fontSize || 16) - 5;
        maxX = drawing.x + metrics.width + 5;
        maxY = drawing.y + 5;
        break;
      case 'image':
        const imgWidth = drawing.width || drawing.originalWidth || 100;
        const imgHeight = drawing.height || drawing.originalHeight || 100;
        minX = drawing.x - 5;
        minY = drawing.y - 5;
        maxX = drawing.x + imgWidth + 5;
        maxY = drawing.y + imgHeight + 5;
        break;
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          minX = Math.min(...drawing.points.map(p => p.x)) - 5;
          minY = Math.min(...drawing.points.map(p => p.y)) - 5;
          maxX = Math.max(...drawing.points.map(p => p.x)) + 5;
          maxY = Math.max(...drawing.points.map(p => p.y)) + 5;
        } else {
          return;
        }
        break;
      case 'freehand':
        if (drawing.points && drawing.points.length > 0) {
          minX = Math.min(...drawing.points.map(p => p.x)) - 5;
          minY = Math.min(...drawing.points.map(p => p.y)) - 5;
          maxX = Math.max(...drawing.points.map(p => p.x)) + 5;
          maxY = Math.max(...drawing.points.map(p => p.y)) + 5;
        } else {
          return;
        }
        break;
      case 'spray':
        if (drawing.particles && drawing.particles.length > 0) {
          const particleSize = drawing.particleSize || this.sprayParticleSize;
          minX = Math.min(...drawing.particles.map(p => p.x)) - particleSize;
          minY = Math.min(...drawing.particles.map(p => p.y)) - particleSize;
          maxX = Math.max(...drawing.particles.map(p => p.x)) + particleSize;
          maxY = Math.max(...drawing.particles.map(p => p.y)) + particleSize;
        } else {
          return;
        }
        break;
      case 'heatmap':
        if (drawing.heatGrid && Object.keys(drawing.heatGrid).length > 0) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          let minGridX = Infinity, minGridY = Infinity, maxGridX = -Infinity, maxGridY = -Infinity;
          Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            minGridX = Math.min(minGridX, gridX);
            minGridY = Math.min(minGridY, gridY);
            maxGridX = Math.max(maxGridX, gridX);
            maxGridY = Math.max(maxGridY, gridY);
          });
          minX = minGridX * gridSize;
          minY = minGridY * gridSize;
          maxX = (maxGridX + 1) * gridSize;
          maxY = (maxGridY + 1) * gridSize;
        } else {
          return;
        }
        break;
      case 'arc':
        const arcLeft = Math.min(drawing.startX, drawing.endX);
        const arcTop = Math.min(drawing.startY, drawing.endY);
        const arcWidth = Math.abs(drawing.endX - drawing.startX);
        const arcHeight = Math.abs(drawing.endY - drawing.startY);
        const arcRadius = Math.max(arcWidth, arcHeight) / 2;
        const arcCenterX = arcLeft + arcWidth / 2;
        const arcCenterY = arcTop + arcHeight / 2;
        minX = arcCenterX - arcRadius - 5;
        minY = arcCenterY - arcRadius - 5;
        maxX = arcCenterX + arcRadius + 5;
        maxY = arcCenterY + arcRadius + 5;
        break;
      case 'triangle':
        const triangleLeft = Math.min(drawing.startX, drawing.endX);
        const triangleTop = Math.min(drawing.startY, drawing.endY);
        const triangleWidth = Math.abs(drawing.endX - drawing.startX);
        const triangleHeight = Math.abs(drawing.endY - drawing.startY);
        minX = triangleLeft - 5;
        minY = triangleTop - 5;
        maxX = triangleLeft + triangleWidth + 5;
        maxY = triangleTop + triangleHeight + 5;
        break;
      case 'rectangle':
        const rectLeft = Math.min(drawing.startX, drawing.endX);
        const rectTop = Math.min(drawing.startY, drawing.endY);
        const rectWidth = Math.abs(drawing.endX - drawing.startX);
        const rectHeight = Math.abs(drawing.endY - drawing.startY);
        minX = rectLeft - 5;
        minY = rectTop - 5;
        maxX = rectLeft + rectWidth + 5;
        maxY = rectTop + rectHeight + 5;
        break;
      case 'ball':
        // Normalize ball bounds first to ensure it's square
        this.normalizeBallBounds(drawing);
        // Ball is round (width = height)
        const ballLeft = Math.min(drawing.startX, drawing.endX);
        const ballTop = Math.min(drawing.startY, drawing.endY);
        const ballRight = Math.max(drawing.startX, drawing.endX);
        const ballBottom = Math.max(drawing.startY, drawing.endY);
        // Ball is round, so use the actual stored coordinates
        minX = ballLeft - 5;
        minY = ballTop - 5;
        maxX = ballRight + 5;
        maxY = ballBottom + 5;
        break;
      case 'tshirt':
        // T-shirt maintains 3:4 aspect ratio (width:height)
        const tshirtLeft = Math.min(drawing.startX, drawing.endX);
        const tshirtTop = Math.min(drawing.startY, drawing.endY);
        const tshirtWidth = Math.abs(drawing.endX - drawing.startX);
        const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
        minX = tshirtLeft - 5;
        minY = tshirtTop - 5;
        maxX = tshirtLeft + tshirtWidth + 5;
        maxY = tshirtTop + tshirtHeight + 5;
        break;
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - use bounding box
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        minX = svgLeft - 5;
        minY = svgTop - 5;
        maxX = svgLeft + svgWidth + 5;
        maxY = svgTop + svgHeight + 5;
        break;
      case 'cross':
        minX = Math.min(drawing.startX, drawing.endX) - 5;
        minY = Math.min(drawing.startY, drawing.endY) - 5;
        maxX = Math.max(drawing.startX, drawing.endX) + 5;
        maxY = Math.max(drawing.startY, drawing.endY) + 5;
        break;
      default:
        return;
    }
    
    // For t-shirt with surname, calculate extended visual bounds but keep resize handles at shirt corners
    let visualMaxY = maxY;
    if (drawing.type === 'tshirt' && drawing.surname) {
      const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
      const surnameHeight = Math.max(tshirtHeight * 0.15, 10);
      visualMaxY = maxY + surnameHeight + 8;
    }
    
    // Draw selection box
    this.ctx.save();
    this.ctx.strokeStyle = '#1f6feb';
    this.ctx.fillStyle = 'rgba(31, 111, 235, 0.1)';
    this.ctx.lineWidth = 2;
    this.ctx.setLineDash([5, 5]);

    // Draw semi-transparent background (extended for surname if present)
    this.ctx.fillRect(minX, minY, maxX - minX, visualMaxY - minY);

    // Draw dashed border (extended for surname if present)
    this.ctx.strokeRect(minX, minY, maxX - minX, visualMaxY - minY);

    const handleSize = 6;
    this.ctx.fillStyle = '#1f6feb';
    this.ctx.setLineDash([]);
    
    // For lines and arrows, draw endpoint handles instead of corner handles
    if (drawing.type === 'line' || drawing.type === 'arrow') {
      // Draw circular handles at start and end points
      this.ctx.beginPath();
      this.ctx.arc(drawing.startX, drawing.startY, handleSize, 0, Math.PI * 2);
      this.ctx.fill();
      
      this.ctx.beginPath();
      this.ctx.arc(drawing.endX, drawing.endY, handleSize, 0, Math.PI * 2);
      this.ctx.fill();
    } else if (drawing.type === 'animpath') {
      // For animation paths, only draw handle at end point (start is fixed to object)
      this.ctx.beginPath();
      this.ctx.arc(drawing.endX, drawing.endY, handleSize, 0, Math.PI * 2);
      this.ctx.fill();
      
      // Draw a small indicator at start point (not draggable)
      this.ctx.fillStyle = '#3fb950';
      this.ctx.beginPath();
      this.ctx.arc(drawing.startX, drawing.startY, 4, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.fillStyle = '#1f6feb';
    } else {
      // Draw corner handles for other shapes
      // Top-left
      this.ctx.fillRect(minX - handleSize/2, minY - handleSize/2, handleSize, handleSize);
      // Top-right
      this.ctx.fillRect(maxX - handleSize/2, minY - handleSize/2, handleSize, handleSize);
      // Bottom-left
      this.ctx.fillRect(minX - handleSize/2, maxY - handleSize/2, handleSize, handleSize);
      // Bottom-right
      this.ctx.fillRect(maxX - handleSize/2, maxY - handleSize/2, handleSize, handleSize);
      
      // Draw rotation handle for rotatable shapes
      const rotatableTypes = ['circle', 'arc', 'polygon', 'triangle', 'rectangle', 'cross', 'tshirt', 'ball', 'curve', 'barrier', 'biggoal', 'ladder', 'stick'];
      if (rotatableTypes.includes(drawing.type)) {
        const centerX = (minX + maxX) / 2;
        const rotateHandleY = minY - 30;
        
        // Draw line from top center to rotation handle
        this.ctx.strokeStyle = '#1f6feb';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, minY);
        this.ctx.lineTo(centerX, rotateHandleY);
        this.ctx.stroke();
        
        // Draw rotation handle (circle)
        this.ctx.fillStyle = '#1f6feb';
        this.ctx.beginPath();
        this.ctx.arc(centerX, rotateHandleY, handleSize, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Draw rotation icon inside
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1.5;
        this.ctx.beginPath();
        this.ctx.arc(centerX, rotateHandleY, 3, -Math.PI * 0.7, Math.PI * 0.5);
        this.ctx.stroke();
        
        // Draw move handle for balls, t-shirts, and SVG elements (to the right of rotation handle)
        const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
        if (drawing.type === 'ball' || drawing.type === 'tshirt' || svgElements.includes(drawing.type)) {
          const moveHandleX = centerX + 25;
          const moveHandleY = rotateHandleY;
          
          // Draw line from rotation handle to move handle
          this.ctx.strokeStyle = '#1f6feb';
          this.ctx.lineWidth = 1;
          this.ctx.beginPath();
          this.ctx.moveTo(centerX + handleSize, rotateHandleY);
          this.ctx.lineTo(moveHandleX - handleSize, moveHandleY);
          this.ctx.stroke();
          
          // Draw move handle (circle)
          this.ctx.fillStyle = '#3fb950'; // Green color for move handle
          this.ctx.beginPath();
          this.ctx.arc(moveHandleX, moveHandleY, handleSize, 0, Math.PI * 2);
          this.ctx.fill();
          
          // Draw move icon inside (4 arrows pointing outward)
          this.ctx.strokeStyle = '#ffffff';
          this.ctx.lineWidth = 1;
          const arrowLen = 2.5;
          const arrowHead = 1.2;
          
          // Up arrow
          this.ctx.beginPath();
          this.ctx.moveTo(moveHandleX, moveHandleY - arrowLen);
          this.ctx.lineTo(moveHandleX - arrowHead, moveHandleY - arrowLen + arrowHead);
          this.ctx.moveTo(moveHandleX, moveHandleY - arrowLen);
          this.ctx.lineTo(moveHandleX + arrowHead, moveHandleY - arrowLen + arrowHead);
          this.ctx.stroke();
          
          // Down arrow
          this.ctx.beginPath();
          this.ctx.moveTo(moveHandleX, moveHandleY + arrowLen);
          this.ctx.lineTo(moveHandleX - arrowHead, moveHandleY + arrowLen - arrowHead);
          this.ctx.moveTo(moveHandleX, moveHandleY + arrowLen);
          this.ctx.lineTo(moveHandleX + arrowHead, moveHandleY + arrowLen - arrowHead);
          this.ctx.stroke();
          
          // Left arrow
          this.ctx.beginPath();
          this.ctx.moveTo(moveHandleX - arrowLen, moveHandleY);
          this.ctx.lineTo(moveHandleX - arrowLen + arrowHead, moveHandleY - arrowHead);
          this.ctx.moveTo(moveHandleX - arrowLen, moveHandleY);
          this.ctx.lineTo(moveHandleX - arrowLen + arrowHead, moveHandleY + arrowHead);
          this.ctx.stroke();
          
          // Right arrow
          this.ctx.beginPath();
          this.ctx.moveTo(moveHandleX + arrowLen, moveHandleY);
          this.ctx.lineTo(moveHandleX + arrowLen - arrowHead, moveHandleY - arrowHead);
          this.ctx.moveTo(moveHandleX + arrowLen, moveHandleY);
          this.ctx.lineTo(moveHandleX + arrowLen - arrowHead, moveHandleY + arrowHead);
          this.ctx.stroke();
        }
      }
    }

    this.ctx.restore();
    
    // Store selection box bounds for resize detection (NOT extended - actual shape corners)
    this.selectionBounds = { minX, minY, maxX, maxY };
  }

  drawObjectHighlight(drawing) {
    // Highlights are not available for t-shirts and balls
    if (drawing.type === 'tshirt' || drawing.type === 'ball') {
      return;
    }

    // Use custom highlight color if set, otherwise use the shape's line color
    const highlightColor = drawing.highlightColor || drawing.color || '#FF0000';
    
    const highlightThickness = drawing.highlightThickness || 3;
    const highlightStyle = drawing.highlightStyle || 'solid';
    const offset = highlightThickness / 2; // Offset to create outline around shape

    this.ctx.save();
    this.ctx.strokeStyle = highlightColor;
    this.ctx.lineWidth = highlightThickness;
    this.ctx.setLineDash([]); // No dashes for shape contours
    this.ctx.globalAlpha = 1.0;

    // Apply blur effect for blurred style
    if (highlightStyle === 'blurred') {
      this.ctx.shadowBlur = highlightThickness * 2;
      this.ctx.shadowColor = highlightColor;
      this.ctx.shadowOffsetX = 0;
      this.ctx.shadowOffsetY = 0;
    }

    // Draw the actual shape contour with offset
    switch (drawing.type) {
      case 'line':
      case 'arrow':
        this.ctx.beginPath();
        this.ctx.moveTo(drawing.startX, drawing.startY);
        this.ctx.lineTo(drawing.endX, drawing.endY);
        this.ctx.stroke();
        break;

      case 'curve':
      case 'animpath':
        this.ctx.beginPath();
        if (drawing.controlPoint) {
          this.ctx.moveTo(drawing.startX, drawing.startY);
          this.ctx.quadraticCurveTo(drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY);
        } else if (drawing.controlPoints && drawing.controlPoints.length >= 2) {
          this.ctx.moveTo(drawing.startX, drawing.startY);
          this.ctx.bezierCurveTo(
            drawing.controlPoints[0].x, drawing.controlPoints[0].y,
            drawing.controlPoints[1].x, drawing.controlPoints[1].y,
            drawing.endX, drawing.endY
          );
        } else {
          this.ctx.moveTo(drawing.startX, drawing.startY);
          this.ctx.lineTo(drawing.endX, drawing.endY);
        }
        this.ctx.stroke();
        break;

      case 'circle':
      case 'ball':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        const circleRadius = Math.max(circleWidth, circleHeight) / 2;
        const circleCenterX = circleLeft + circleWidth / 2;
        const circleCenterY = circleTop + circleHeight / 2;
        this.ctx.beginPath();
        this.ctx.arc(circleCenterX, circleCenterY, circleRadius + offset, 0, Math.PI * 2);
        this.ctx.stroke();
        break;

      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        const ovalRadiusX = ovalWidth / 2;
        const ovalRadiusY = ovalHeight / 2;
        const ovalCenterX = ovalLeft + ovalWidth / 2;
        const ovalCenterY = ovalTop + ovalHeight / 2;
        this.ctx.beginPath();
        this.ctx.ellipse(ovalCenterX, ovalCenterY, ovalRadiusX + offset, ovalRadiusY + offset, 0, 0, Math.PI * 2);
        this.ctx.stroke();
        break;

      case 'arc':
        const arcLeft = Math.min(drawing.startX, drawing.endX);
        const arcTop = Math.min(drawing.startY, drawing.endY);
        const arcWidth = Math.abs(drawing.endX - drawing.startX);
        const arcHeight = Math.abs(drawing.endY - drawing.startY);
        const arcRadius = Math.max(arcWidth, arcHeight) / 2;
        const arcCenterX = arcLeft + arcWidth / 2;
        const arcCenterY = arcTop + arcHeight / 2;
        this.ctx.beginPath();
        this.ctx.arc(arcCenterX, arcCenterY, arcRadius + offset, 0, Math.PI);
        this.ctx.stroke();
        break;

      case 'rectangle':
        const rectLeft = Math.min(drawing.startX, drawing.endX);
        const rectTop = Math.min(drawing.startY, drawing.endY);
        const rectWidth = Math.abs(drawing.endX - drawing.startX);
        const rectHeight = Math.abs(drawing.endY - drawing.startY);
        this.ctx.beginPath();
        this.ctx.rect(rectLeft - offset, rectTop - offset, rectWidth + offset * 2, rectHeight + offset * 2);
        this.ctx.stroke();
        break;

      case 'triangle':
        const triangleLeft = Math.min(drawing.startX, drawing.endX);
        const triangleTop = Math.min(drawing.startY, drawing.endY);
        const triangleWidth = Math.abs(drawing.endX - drawing.startX);
        const triangleHeight = Math.abs(drawing.endY - drawing.startY);
        this.ctx.beginPath();
        this.ctx.moveTo(triangleLeft + triangleWidth / 2, triangleTop - offset);
        this.ctx.lineTo(triangleLeft + triangleWidth + offset, triangleTop + triangleHeight + offset);
        this.ctx.lineTo(triangleLeft - offset, triangleTop + triangleHeight + offset);
        this.ctx.closePath();
        this.ctx.stroke();
        break;

      case 'polygon':
        if (drawing.points && drawing.points.length >= 3) {
          this.ctx.beginPath();
          // Calculate offset direction for each point (outward normal)
          for (let i = 0; i < drawing.points.length; i++) {
            const prev = drawing.points[(i - 1 + drawing.points.length) % drawing.points.length];
            const curr = drawing.points[i];
            const next = drawing.points[(i + 1) % drawing.points.length];
            
            // Calculate normal vector (perpendicular to edge)
            const dx1 = curr.x - prev.x;
            const dy1 = curr.y - prev.y;
            const dx2 = next.x - curr.x;
            const dy2 = next.y - curr.y;
            
            // Average of two edge normals
            const len1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
            const len2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
            
            const nx1 = -dy1 / len1;
            const ny1 = dx1 / len1;
            const nx2 = -dy2 / len2;
            const ny2 = dx2 / len2;
            
            const nx = (nx1 + nx2) / 2;
            const ny = (ny1 + ny2) / 2;
            const len = Math.sqrt(nx * nx + ny * ny);
            
            const offsetX = (nx / len) * offset;
            const offsetY = (ny / len) * offset;
            
            if (i === 0) {
              this.ctx.moveTo(curr.x + offsetX, curr.y + offsetY);
            } else {
              this.ctx.lineTo(curr.x + offsetX, curr.y + offsetY);
            }
          }
          this.ctx.closePath();
          this.ctx.stroke();
        }
        break;

      case 'freehand':
        if (drawing.points && drawing.points.length >= 2) {
          this.ctx.beginPath();
          this.ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
          for (let i = 1; i < drawing.points.length; i++) {
            this.ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
          }
          this.ctx.stroke();
        }
        break;

      case 'cross':
        // Draw X shape (two diagonal lines) - same as the actual cross
        this.ctx.beginPath();
        // First diagonal: top-left to bottom-right
        this.ctx.moveTo(drawing.startX, drawing.startY);
        this.ctx.lineTo(drawing.endX, drawing.endY);
        // Second diagonal: top-right to bottom-left
        this.ctx.moveTo(drawing.endX, drawing.startY);
        this.ctx.lineTo(drawing.startX, drawing.endY);
        this.ctx.stroke();
        break;

      case 'tshirt':
        // For t-shirt, draw a rectangle outline around it
        const tshirtLeft = Math.min(drawing.startX, drawing.endX);
        const tshirtTop = Math.min(drawing.startY, drawing.endY);
        const tshirtWidth = Math.abs(drawing.endX - drawing.startX);
        const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
        this.ctx.beginPath();
        this.ctx.rect(tshirtLeft - offset, tshirtTop - offset, tshirtWidth + offset * 2, tshirtHeight + offset * 2);
        this.ctx.stroke();
        break;

      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // For SVG elements, draw a rectangle outline around them
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        this.ctx.beginPath();
        this.ctx.rect(svgLeft - offset, svgTop - offset, svgWidth + offset * 2, svgHeight + offset * 2);
        this.ctx.stroke();
        break;

      case 'text':
        // For text, draw a rectangle around the text bounds
        if (drawing.text && drawing.fontSize) {
          const textWidth = drawing.text.length * drawing.fontSize * 0.6;
          const textHeight = drawing.fontSize * 1.2;
          this.ctx.beginPath();
          this.ctx.rect(drawing.x - offset, drawing.y - textHeight - offset, textWidth + offset * 2, textHeight + offset * 2);
          this.ctx.stroke();
        }
        break;

      case 'image':
        if (drawing.imageElement && drawing.imageElement.width && drawing.imageElement.height) {
          const imgWidth = drawing.endX - drawing.startX;
          const imgHeight = drawing.endY - drawing.startY;
          this.ctx.beginPath();
          this.ctx.rect(drawing.startX - offset, drawing.startY - offset, imgWidth + offset * 2, imgHeight + offset * 2);
          this.ctx.stroke();
        }
        break;

      default:
        this.ctx.restore();
        return; // Skip unknown types
    }

    this.ctx.restore();
  }
  
  drawGroupIndicator(drawing) {
    // Draw a dashed border around grouped elements
    this.ctx.save();
    this.ctx.strokeStyle = '#58a6ff';
    this.ctx.lineWidth = 2;
    this.ctx.setLineDash([4, 4]);
    this.ctx.globalAlpha = 0.7;
    
    const offset = 4; // Offset from the element
    
    switch (drawing.type) {
      case 'ball':
      case 'circle':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        const circleRadius = Math.max(circleWidth, circleHeight) / 2;
        const circleCenterX = circleLeft + circleWidth / 2;
        const circleCenterY = circleTop + circleHeight / 2;
        this.ctx.beginPath();
        this.ctx.arc(circleCenterX, circleCenterY, circleRadius + offset, 0, Math.PI * 2);
        this.ctx.stroke();
        break;
        
      case 'tshirt':
      case 'rectangle':
        const rectLeft = Math.min(drawing.startX, drawing.endX);
        const rectTop = Math.min(drawing.startY, drawing.endY);
        const rectWidth = Math.abs(drawing.endX - drawing.startX);
        const rectHeight = Math.abs(drawing.endY - drawing.startY);
        this.ctx.beginPath();
        this.ctx.rect(rectLeft - offset, rectTop - offset, rectWidth + offset * 2, rectHeight + offset * 2);
        this.ctx.stroke();
        break;
        
      default:
        // For other types, use a simple bounding box
        const minX = Math.min(drawing.startX, drawing.endX) - offset;
        const minY = Math.min(drawing.startY, drawing.endY) - offset;
        const maxX = Math.max(drawing.startX, drawing.endX) + offset;
        const maxY = Math.max(drawing.startY, drawing.endY) + offset;
        this.ctx.beginPath();
        this.ctx.rect(minX, minY, maxX - minX, maxY - minY);
        this.ctx.stroke();
        break;
    }

    this.ctx.restore();
  }

  getDrawingBoundsForRotation(drawing) {
    // Get simple bounding box for rotation center calculation
    let minX, minY, maxX, maxY;
    
    switch (drawing.type) {
      case 'circle':
      case 'arc':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        minX = circleLeft;
        minY = circleTop;
        maxX = circleLeft + Math.max(circleWidth, circleHeight);
        maxY = circleTop + Math.max(circleWidth, circleHeight);
        break;
      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        minX = ovalLeft;
        minY = ovalTop;
        maxX = ovalLeft + ovalWidth;
        maxY = ovalTop + ovalHeight;
        break;
      case 'line':
      case 'arrow':
        minX = Math.min(drawing.startX, drawing.endX);
        minY = Math.min(drawing.startY, drawing.endY);
        maxX = Math.max(drawing.startX, drawing.endX);
        maxY = Math.max(drawing.startY, drawing.endY);
        break;
      case 'triangle':
      case 'rectangle':
      case 'cross':
      case 'tshirt':
      case 'ball':
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        minX = Math.min(drawing.startX, drawing.endX);
        minY = Math.min(drawing.startY, drawing.endY);
        maxX = Math.max(drawing.startX, drawing.endX);
        maxY = Math.max(drawing.startY, drawing.endY);
        break;
      case 'curve':
        minX = Math.min(drawing.startX, drawing.endX);
        minY = Math.min(drawing.startY, drawing.endY);
        maxX = Math.max(drawing.startX, drawing.endX);
        maxY = Math.max(drawing.startY, drawing.endY);
        if (drawing.controlPoint) {
          minX = Math.min(minX, drawing.controlPoint.x);
          minY = Math.min(minY, drawing.controlPoint.y);
          maxX = Math.max(maxX, drawing.controlPoint.x);
          maxY = Math.max(maxY, drawing.controlPoint.y);
        }
        if (drawing.controlPoints && drawing.controlPoints.length > 0) {
          drawing.controlPoints.forEach(cp => {
            minX = Math.min(minX, cp.x);
            minY = Math.min(minY, cp.y);
            maxX = Math.max(maxX, cp.x);
            maxY = Math.max(maxY, cp.y);
          });
        }
        break;
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          minX = Math.min(...drawing.points.map(p => p.x));
          minY = Math.min(...drawing.points.map(p => p.y));
          maxX = Math.max(...drawing.points.map(p => p.x));
          maxY = Math.max(...drawing.points.map(p => p.y));
        } else {
          return null;
        }
        break;
      default:
        return null;
    }
    
    return { minX, minY, maxX, maxY };
  }

  getSelectionBounds(drawing) {
    let minX, minY, maxX, maxY;
    
    switch (drawing.type) {
      case 'line':
      case 'arrow':
      case 'cross':
      case 'animpath':
        minX = Math.min(drawing.startX, drawing.endX);
        minY = Math.min(drawing.startY, drawing.endY);
        maxX = Math.max(drawing.startX, drawing.endX);
        maxY = Math.max(drawing.startY, drawing.endY);
        break;
      case 'curve':
        // For curves, include control points in bounds calculation
        minX = Math.min(drawing.startX, drawing.endX);
        minY = Math.min(drawing.startY, drawing.endY);
        maxX = Math.max(drawing.startX, drawing.endX);
        maxY = Math.max(drawing.startY, drawing.endY);

        // Include control points in bounds
        if (drawing.controlPoint) {
          minX = Math.min(minX, drawing.controlPoint.x);
          minY = Math.min(minY, drawing.controlPoint.y);
          maxX = Math.max(maxX, drawing.controlPoint.x);
          maxY = Math.max(maxY, drawing.controlPoint.y);
        }
        if (drawing.controlPoints && drawing.controlPoints.length > 0) {
          drawing.controlPoints.forEach(cp => {
            minX = Math.min(minX, cp.x);
            minY = Math.min(minY, cp.y);
            maxX = Math.max(maxX, cp.x);
            maxY = Math.max(maxY, cp.y);
          });
        }

        // Add some padding for better handle accessibility
        const padding = 10;
        minX -= padding;
        minY -= padding;
        maxX += padding;
        maxY += padding;
        break;
      case 'circle':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        const circleRadius = Math.max(circleWidth, circleHeight) / 2;
        const circleCenterX = circleLeft + circleWidth / 2;
        const circleCenterY = circleTop + circleHeight / 2;
        minX = circleCenterX - circleRadius;
        minY = circleCenterY - circleRadius;
        maxX = circleCenterX + circleRadius;
        maxY = circleCenterY + circleRadius;
        break;
      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        minX = ovalLeft;
        minY = ovalTop;
        maxX = ovalLeft + ovalWidth;
        maxY = ovalTop + ovalHeight;
        break;
      case 'arc':
        const arcLeft = Math.min(drawing.startX, drawing.endX);
        const arcTop = Math.min(drawing.startY, drawing.endY);
        const arcWidth = Math.abs(drawing.endX - drawing.startX);
        const arcHeight = Math.abs(drawing.endY - drawing.startY);
        const arcRadius = Math.max(arcWidth, arcHeight) / 2;
        const arcCenterX = arcLeft + arcWidth / 2;
        const arcCenterY = arcTop + arcHeight / 2;
        minX = arcCenterX - arcRadius;
        minY = arcCenterY - arcRadius;
        maxX = arcCenterX + arcRadius;
        maxY = arcCenterY + arcRadius;
        break;
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          minX = Math.min(...drawing.points.map(p => p.x));
          minY = Math.min(...drawing.points.map(p => p.y));
          maxX = Math.max(...drawing.points.map(p => p.x));
          maxY = Math.max(...drawing.points.map(p => p.y));
        } else {
          return null;
        }
        break;
      case 'triangle':
        const triangleLeft = Math.min(drawing.startX, drawing.endX);
        const triangleTop = Math.min(drawing.startY, drawing.endY);
        const triangleWidth = Math.abs(drawing.endX - drawing.startX);
        const triangleHeight = Math.abs(drawing.endY - drawing.startY);
        minX = triangleLeft;
        minY = triangleTop;
        maxX = triangleLeft + triangleWidth;
        maxY = triangleTop + triangleHeight;
        break;
      case 'rectangle':
        const rectLeft = Math.min(drawing.startX, drawing.endX);
        const rectTop = Math.min(drawing.startY, drawing.endY);
        const rectWidth = Math.abs(drawing.endX - drawing.startX);
        const rectHeight = Math.abs(drawing.endY - drawing.startY);
        minX = rectLeft;
        minY = rectTop;
        maxX = rectLeft + rectWidth;
        maxY = rectTop + rectHeight;
        break;
      case 'freehand':
        if (drawing.points && drawing.points.length > 0) {
          minX = Math.min(...drawing.points.map(p => p.x));
          minY = Math.min(...drawing.points.map(p => p.y));
          maxX = Math.max(...drawing.points.map(p => p.x));
          maxY = Math.max(...drawing.points.map(p => p.y));
        } else {
          return null;
        }
        break;
      case 'spray':
        if (drawing.particles && drawing.particles.length > 0) {
          const particleSize = drawing.particleSize || this.sprayParticleSize;
          minX = Math.min(...drawing.particles.map(p => p.x)) - particleSize;
          minY = Math.min(...drawing.particles.map(p => p.y)) - particleSize;
          maxX = Math.max(...drawing.particles.map(p => p.x)) + particleSize;
          maxY = Math.max(...drawing.particles.map(p => p.y)) + particleSize;
        } else {
          return null;
        }
        break;
      case 'heatmap':
        if (drawing.heatGrid && drawing.heatGrid.size > 0) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          let minGridX = Infinity, minGridY = Infinity, maxGridX = -Infinity, maxGridY = -Infinity;
          drawing.heatGrid.forEach((intensity, gridKey) => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            minGridX = Math.min(minGridX, gridX);
            minGridY = Math.min(minGridY, gridY);
            maxGridX = Math.max(maxGridX, gridX);
            maxGridY = Math.max(maxGridY, gridY);
          });
          minX = minGridX * gridSize;
          minY = minGridY * gridSize;
          maxX = (maxGridX + 1) * gridSize;
          maxY = (maxGridY + 1) * gridSize;
        } else {
          return null;
        }
        break;
      case 'text':
        const textFontWeight = drawing.fontWeight || 400;
        const textFontSize = drawing.fontSize || 16;
        this.ctx.font = `${textFontWeight} ${textFontSize}px sans-serif`;
        const metrics = this.ctx.measureText(drawing.text);
        minX = drawing.x;
        minY = drawing.y - textFontSize;
        maxX = drawing.x + metrics.width;
        maxY = drawing.y;
        break;
      case 'image':
        const imgWidth = drawing.width || drawing.originalWidth || 100;
        const imgHeight = drawing.height || drawing.originalHeight || 100;
        minX = drawing.x;
        minY = drawing.y;
        maxX = drawing.x + imgWidth;
        maxY = drawing.y + imgHeight;
        break;
      case 'ball':
        // Normalize ball bounds first to ensure it's square
        this.normalizeBallBounds(drawing);
        // Ball is round (width = height)
        const ballLeft = Math.min(drawing.startX, drawing.endX);
        const ballTop = Math.min(drawing.startY, drawing.endY);
        const ballRight = Math.max(drawing.startX, drawing.endX);
        const ballBottom = Math.max(drawing.startY, drawing.endY);
        minX = ballLeft;
        minY = ballTop;
        maxX = ballRight;
        maxY = ballBottom;
        break;
      case 'tshirt':
        // T-shirt maintains 3:4 aspect ratio (width:height)
        // Note: We don't extend bounds for surname - resize handles should be on t-shirt corners
        const tshirtLeft = Math.min(drawing.startX, drawing.endX);
        const tshirtTop = Math.min(drawing.startY, drawing.endY);
        const tshirtWidth = Math.abs(drawing.endX - drawing.startX);
        const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
        minX = tshirtLeft;
        minY = tshirtTop;
        maxX = tshirtLeft + tshirtWidth;
        maxY = tshirtTop + tshirtHeight;
        break;
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - use bounding box
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        minX = svgLeft;
        minY = svgTop;
        maxX = svgLeft + svgWidth;
        maxY = svgTop + svgHeight;
        break;
      default:
        return null;
    }
    
    return { minX, minY, maxX, maxY };
  }

  getResizeHandle(x, y, bounds, drawing = null) {
    if (!bounds) return null;
    
    const handleSize = 6;
    const threshold = handleSize + 4; // Slightly larger hit area
    
    // For lines, arrows, and animation paths, check endpoint handles
    if (drawing && (drawing.type === 'line' || drawing.type === 'arrow' || drawing.type === 'animpath')) {
      // For animpath, only allow dragging the end point (start is fixed to object)
      if (drawing.type === 'animpath') {
        const endDist = Math.sqrt(Math.pow(x - drawing.endX, 2) + Math.pow(y - drawing.endY, 2));
        if (endDist <= threshold) {
          return 'end';
        }
        return null;
      }
      
      const startDist = Math.sqrt(Math.pow(x - drawing.startX, 2) + Math.pow(y - drawing.startY, 2));
      if (startDist <= threshold) {
        return 'start';
      }
      
      const endDist = Math.sqrt(Math.pow(x - drawing.endX, 2) + Math.pow(y - drawing.endY, 2));
      if (endDist <= threshold) {
        return 'end';
      }
      
      return null;
    }
    
    // Check rotation handle for rotatable shapes
    const rotatableTypes = ['circle', 'arc', 'polygon', 'triangle', 'rectangle', 'cross', 'tshirt', 'ball', 'curve', 'barrier', 'biggoal', 'ladder', 'stick'];
    if (drawing && rotatableTypes.includes(drawing.type)) {
      const centerX = (bounds.minX + bounds.maxX) / 2;
      const rotateHandleY = bounds.minY - 30;
      const rotateDist = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - rotateHandleY, 2));
      if (rotateDist <= threshold) {
        return 'rotate';
      }
      
      // Check move handle for balls, t-shirts, and SVG elements
      const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
      if (drawing.type === 'ball' || drawing.type === 'tshirt' || svgElements.includes(drawing.type)) {
        const moveHandleX = centerX + 25;
        const moveHandleY = rotateHandleY;
        const moveDist = Math.sqrt(Math.pow(x - moveHandleX, 2) + Math.pow(y - moveHandleY, 2));
        if (moveDist <= threshold) {
          return 'move';
        }
      }
    }
    
    // Check each corner for other shapes
    const handles = {
      'tl': { x: bounds.minX, y: bounds.minY },
      'tr': { x: bounds.maxX, y: bounds.minY },
      'bl': { x: bounds.minX, y: bounds.maxY },
      'br': { x: bounds.maxX, y: bounds.maxY }
    };
    
    for (const [handle, pos] of Object.entries(handles)) {
      const dist = Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2));
      if (dist <= threshold) {
        return handle;
      }
    }
    
    return null;
  }

  updateDrawingForResize(drawing, handle, newBounds, oldBounds) {
    const scaleX = (newBounds.maxX - newBounds.minX) / (oldBounds.maxX - oldBounds.minX);
    const scaleY = (newBounds.maxY - newBounds.minY) / (oldBounds.maxY - oldBounds.minY);
    
    switch (drawing.type) {
      case 'line':
      case 'arrow':
      case 'cross':
        // Get original line coordinates from the saved drawing
        const origStartX = this.resizeStartDrawing.startX;
        const origStartY = this.resizeStartDrawing.startY;
        const origEndX = this.resizeStartDrawing.endX;
        const origEndY = this.resizeStartDrawing.endY;
        
        // Calculate original line bounds
        const origLineMinX = Math.min(origStartX, origEndX);
        const origLineMinY = Math.min(origStartY, origEndY);
        const origLineMaxX = Math.max(origStartX, origEndX);
        const origLineMaxY = Math.max(origStartY, origEndY);
        
        // Scale the line endpoints relative to the bounds
        const newStartX = newBounds.minX + (origStartX - origLineMinX) * scaleX;
        const newStartY = newBounds.minY + (origStartY - origLineMinY) * scaleY;
        const newEndX = newBounds.minX + (origEndX - origLineMinX) * scaleX;
        const newEndY = newBounds.minY + (origEndY - origLineMinY) * scaleY;
        
        drawing.startX = newStartX;
        drawing.startY = newStartY;
        drawing.endX = newEndX;
        drawing.endY = newEndY;
        break;
        
      case 'circle':
      case 'arc':
        // For circles/arcs, bounds are calculated from center and radius
        // We need to convert the new bounds back to a bounding box
        const newWidth = newBounds.maxX - newBounds.minX;
        const newHeight = newBounds.maxY - newBounds.minY;
        const newRadius = Math.max(newWidth, newHeight) / 2;
        const newCenterX = newBounds.minX + newWidth / 2;
        const newCenterY = newBounds.minY + newHeight / 2;
        
        // Update the bounding box coordinates (startX/startY to endX/endY)
        drawing.startX = newCenterX - newRadius;
        drawing.startY = newCenterY - newRadius;
        drawing.endX = newCenterX + newRadius;
        drawing.endY = newCenterY + newRadius;
        break;
      case 'oval':
        // For ovals, directly update the bounding box
        drawing.startX = newBounds.minX;
        drawing.startY = newBounds.minY;
        drawing.endX = newBounds.maxX;
        drawing.endY = newBounds.maxY;
        break;
        
      case 'triangle':
      case 'rectangle':
        // For triangle and rectangle, directly update the bounding box
        drawing.startX = newBounds.minX;
        drawing.startY = newBounds.minY;
        drawing.endX = newBounds.maxX;
        drawing.endY = newBounds.maxY;
        break;
        
      case 'polygon':
        if (drawing.points && this.resizeStartDrawing.points) {
          // Scale polygon points relative to old bounds using original points
          drawing.points = this.resizeStartDrawing.points.map(point => ({
            x: newBounds.minX + (point.x - oldBounds.minX) * scaleX,
            y: newBounds.minY + (point.y - oldBounds.minY) * scaleY
          }));
        }
        break;
        
      case 'freehand':
        if (drawing.points && this.resizeStartDrawing.points) {
          // Scale freehand points relative to old bounds using original points
          drawing.points = this.resizeStartDrawing.points.map(point => ({
            x: newBounds.minX + (point.x - oldBounds.minX) * scaleX,
            y: newBounds.minY + (point.y - oldBounds.minY) * scaleY
          }));
        }
        break;
      case 'spray':
        if (drawing.particles && this.resizeStartDrawing.particles) {
          // Scale spray particles relative to old bounds
          drawing.particles = this.resizeStartDrawing.particles.map(particle => ({
            x: newBounds.minX + (particle.x - oldBounds.minX) * scaleX,
            y: newBounds.minY + (particle.y - oldBounds.minY) * scaleY
          }));
        }
        break;
      case 'heatmap':
        if (drawing.heatGrid && this.resizeStartDrawing.heatGrid) {
          // Scale heatmap grid relative to old bounds
          const newHeatGrid = {};
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          Object.entries(this.resizeStartDrawing.heatGrid).forEach(([gridKey, intensity]) => {
            const [oldGridX, oldGridY] = gridKey.split(',').map(Number);
            const oldPixelX = oldGridX * gridSize;
            const oldPixelY = oldGridY * gridSize;
            const newPixelX = newBounds.minX + (oldPixelX - oldBounds.minX) * scaleX;
            const newPixelY = newBounds.minY + (oldPixelY - oldBounds.minY) * scaleY;
            const newGridX = Math.floor(newPixelX / gridSize);
            const newGridY = Math.floor(newPixelY / gridSize);
            const newGridKey = `${newGridX},${newGridY}`;
            newHeatGrid[newGridKey] = intensity;
          });
          drawing.heatGrid = newHeatGrid;
        }
        break;
        
      case 'image':
        // Update image position and size based on new bounds
        drawing.x = newBounds.minX;
        drawing.y = newBounds.minY;
        drawing.width = newBounds.maxX - newBounds.minX;
        drawing.height = newBounds.maxY - newBounds.minY;
        break;
        
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - maintain aspect ratio when resizing
        if (drawing.aspectRatio) {
          const newWidth = newBounds.maxX - newBounds.minX;
          const newHeight = newBounds.maxY - newBounds.minY;
          const svgAspectRatio = drawing.aspectRatio;
          
          let finalWidth = newWidth;
          let finalHeight = newHeight;
          
          // Adjust to maintain aspect ratio (similar to t-shirt logic)
          if (newWidth / newHeight > svgAspectRatio) {
            // Width is too large relative to height - adjust height
            finalHeight = newWidth / svgAspectRatio;
          } else {
            // Height is too large relative to width - adjust width
            finalWidth = newHeight * svgAspectRatio;
          }
          
          // Apply minimum size AFTER aspect ratio calculation (use smaller dimension as base)
          // Very small minimum (0.5px) to allow elements to get very small while preventing canvas errors
          const minSize = 0.5;
          const minDimension = Math.min(finalWidth, finalHeight);
          if (minDimension < minSize) {
            // Scale up proportionally to meet minimum
            const scale = minSize / minDimension;
            finalWidth *= scale;
            finalHeight *= scale;
          }
          
          const centerX = (newBounds.minX + newBounds.maxX) / 2;
          const centerY = (newBounds.minY + newBounds.maxY) / 2;
          
          drawing.startX = centerX - finalWidth / 2;
          drawing.startY = centerY - finalHeight / 2;
          drawing.endX = centerX + finalWidth / 2;
          drawing.endY = centerY + finalHeight / 2;
        } else {
          // No aspect ratio stored - update bounds directly
          drawing.startX = newBounds.minX;
          drawing.startY = newBounds.minY;
          drawing.endX = newBounds.maxX;
          drawing.endY = newBounds.maxY;
        }
        break;
        
      case 'text':
        // Scale text font size proportionally
        const textScale = Math.max(scaleX, scaleY); // Use larger scale to keep text readable
        const originalFontSize = this.resizeStartDrawing.fontSize || 16;
        drawing.fontSize = Math.max(8, Math.round(originalFontSize * textScale)); // Min font size of 8
        // Keep same position (top-left corner of text bounds)
        drawing.x = newBounds.minX;
        drawing.y = newBounds.maxY; // Text baseline is at bottom of bounds
        break;
        
      case 'ball':
        // Ball must be perfectly round - use the larger dimension
        const ballNewWidth = newBounds.maxX - newBounds.minX;
        const ballNewHeight = newBounds.maxY - newBounds.minY;
        
        // Use the larger dimension to ensure perfect roundness
        const ballSize = Math.max(ballNewWidth, ballNewHeight);
        
        const ballCenterX = (newBounds.minX + newBounds.maxX) / 2;
        const ballCenterY = (newBounds.minY + newBounds.maxY) / 2;
        
        // Create perfect square
        const ballHalfSize = ballSize / 2;
        drawing.startX = ballCenterX - ballHalfSize;
        drawing.startY = ballCenterY - ballHalfSize;
        drawing.endX = ballCenterX + ballHalfSize;
        drawing.endY = ballCenterY + ballHalfSize;
        
        // Store dimensions (guaranteed to be round)
        drawing.originalWidth = ballSize;
        drawing.originalHeight = ballSize;
        drawing.aspectRatio = 1;
        
        // Normalize to ensure perfect roundness
        this.normalizeBallBounds(drawing);
        break;
      case 'tshirt':
        // T-shirt maintains 3:4 aspect ratio (width:height)
        const tshirtNewWidth = newBounds.maxX - newBounds.minX;
        const tshirtNewHeight = newBounds.maxY - newBounds.minY;
        const tshirtAspectRatio = 3 / 4; // width:height
        
        let tshirtFinalWidth = tshirtNewWidth;
        let tshirtFinalHeight = tshirtNewHeight;
        
        // Adjust to maintain 3:4 aspect ratio
        if (tshirtNewWidth / tshirtNewHeight > tshirtAspectRatio) {
          tshirtFinalHeight = tshirtNewWidth / tshirtAspectRatio;
        } else {
          tshirtFinalWidth = tshirtNewHeight * tshirtAspectRatio;
        }
        
        const tshirtCenterX = (newBounds.minX + newBounds.maxX) / 2;
        const tshirtCenterY = (newBounds.minY + newBounds.maxY) / 2;
        
        drawing.startX = tshirtCenterX - tshirtFinalWidth / 2;
        drawing.startY = tshirtCenterY - tshirtFinalHeight / 2;
        drawing.endX = tshirtCenterX + tshirtFinalWidth / 2;
        drawing.endY = tshirtCenterY + tshirtFinalHeight / 2;
        break;
        
      case 'curve':
        // Scale curve endpoints and control points proportionally
        const curveOrigStartX = this.resizeStartDrawing.startX;
        const curveOrigStartY = this.resizeStartDrawing.startY;
        const curveOrigEndX = this.resizeStartDrawing.endX;
        const curveOrigEndY = this.resizeStartDrawing.endY;
        
        // Scale the curve endpoints relative to the bounds
        const curveNewStartX = newBounds.minX + (curveOrigStartX - oldBounds.minX) * scaleX;
        const curveNewStartY = newBounds.minY + (curveOrigStartY - oldBounds.minY) * scaleY;
        const curveNewEndX = newBounds.minX + (curveOrigEndX - oldBounds.minX) * scaleX;
        const curveNewEndY = newBounds.minY + (curveOrigEndY - oldBounds.minY) * scaleY;
        
        drawing.startX = curveNewStartX;
        drawing.startY = curveNewStartY;
        drawing.endX = curveNewEndX;
        drawing.endY = curveNewEndY;
        
        // Scale control points
        const curveType = drawing.curveType || 'quadratic';
        if (curveType === 'quadratic' && this.resizeStartDrawing.controlPoint) {
          const origCP = this.resizeStartDrawing.controlPoint;
          drawing.controlPoint = {
            x: newBounds.minX + (origCP.x - oldBounds.minX) * scaleX,
            y: newBounds.minY + (origCP.y - oldBounds.minY) * scaleY
          };
        } else if (curveType === 'cubic' && this.resizeStartDrawing.controlPoints) {
          drawing.controlPoints = this.resizeStartDrawing.controlPoints.map(cp => ({
            x: newBounds.minX + (cp.x - oldBounds.minX) * scaleX,
            y: newBounds.minY + (cp.y - oldBounds.minY) * scaleY
          }));
        }

        // After resizing, recalculate control points to maintain proper curve intensity and direction
        this.recalculateCurveControlPoints(drawing);
        break;
        
      case 'text':
        // Scale text position and font size
        const origTextX = this.resizeStartDrawing.x;
        const origTextY = this.resizeStartDrawing.y;
        const origFontSize = this.resizeStartDrawing.fontSize || 16;
        
        drawing.x = newBounds.minX + (origTextX - oldBounds.minX) * scaleX;
        drawing.y = newBounds.minY + (origTextY - oldBounds.minY) * scaleY;
        drawing.fontSize = Math.max(8, origFontSize * Math.min(scaleX, scaleY));
        break;
    }
  }

  drawToolPreview() {
    if (!this.isDrawing) return;
    
    this.ctx.save();
    this.ctx.strokeStyle = this.currentColor;
    this.ctx.fillStyle = this.currentColor;
    this.ctx.lineWidth = 2;
    this.ctx.setLineDash([5, 5]);
    
    const x = this.currentX;
    const y = this.currentY;
    const startX = this.startX;
    const startY = this.startY;
    
    switch (this.currentTool) {
      case 'line':
        this.ctx.beginPath();
        this.ctx.moveTo(startX, startY);
        this.ctx.lineTo(x, y);
        this.ctx.stroke();
        
        // Draw endpoints using current settings
        const lineAngle = Math.atan2(y - startY, x - startX);
        this.drawEndpoint(startX, startY, lineAngle, this.startCap, true);
        this.drawEndpoint(x, y, lineAngle, this.endCap, false);
        break;
      case 'arrow':
        this.drawArrowPreview(startX, startY, x, y);
        break;
      case 'circle':
        // Rectangle-based circle: click and drag to define bounding box
        const left = Math.min(startX, x);
        const top = Math.min(startY, y);
        const width = Math.abs(x - startX);
        const height = Math.abs(y - startY);

        // Use the larger dimension for radius to make it fit the rectangle
        const radius = Math.max(width, height) / 2;
        const centerX = left + width / 2;
        const centerY = top + height / 2;

        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        this.ctx.stroke();
        break;
      case 'oval':
        // Rectangle-based oval: click and drag to define bounding box
        const ovalLeft = Math.min(startX, x);
        const ovalTop = Math.min(startY, y);
        const ovalWidth = Math.abs(x - startX);
        const ovalHeight = Math.abs(y - startY);

        // Use separate radiusX and radiusY for oval
        const ovalRadiusX = ovalWidth / 2;
        const ovalRadiusY = ovalHeight / 2;
        const ovalCenterX = ovalLeft + ovalWidth / 2;
        const ovalCenterY = ovalTop + ovalHeight / 2;

        this.ctx.beginPath();
        this.ctx.ellipse(ovalCenterX, ovalCenterY, ovalRadiusX, ovalRadiusY, 0, 0, Math.PI * 2);
        this.ctx.stroke();
        break;
      case 'ball':
        // Preview ball - always perfectly round
        const dx = x - startX;
        const dy = y - startY;
        // Use the larger dimension to make it round
        const ballPreviewSize = Math.max(Math.abs(dx), Math.abs(dy));
        const defaultSize = 25; // Smaller default ball size
        // Use default if too small
        const finalPreviewSize = ballPreviewSize < 10 ? defaultSize : ballPreviewSize;
        // Calculate center directly from start and current positions
        const ballPreviewCenterX = startX + (dx >= 0 ? finalPreviewSize / 2 : -finalPreviewSize / 2);
        const ballPreviewCenterY = startY + (dy >= 0 ? finalPreviewSize / 2 : -finalPreviewSize / 2);
        const ballPreviewRadius = finalPreviewSize / 2;
        
        this.ctx.beginPath();
        this.ctx.arc(ballPreviewCenterX, ballPreviewCenterY, ballPreviewRadius, 0, Math.PI * 2);
        this.ctx.stroke();
        break;
      case 'tshirt':
        // Preview t-shirt (3:4 ratio)
        const tshirtPreviewLeft = Math.min(startX, x);
        const tshirtPreviewTop = Math.min(startY, y);
        const tshirtPreviewWidth = Math.abs(x - startX);
        const tshirtPreviewHeight = Math.abs(y - startY);
        const tshirtPreviewAspectRatio = 3 / 4;
        
        let tshirtPreviewFinalWidth = tshirtPreviewWidth;
        let tshirtPreviewFinalHeight = tshirtPreviewHeight;
        if (tshirtPreviewWidth / tshirtPreviewHeight > tshirtPreviewAspectRatio) {
          tshirtPreviewFinalHeight = tshirtPreviewWidth / tshirtPreviewAspectRatio;
        } else {
          tshirtPreviewFinalWidth = tshirtPreviewHeight * tshirtPreviewAspectRatio;
        }
        
        const tshirtPreviewCenterX = tshirtPreviewLeft + tshirtPreviewWidth / 2;
        const tshirtPreviewCenterY = tshirtPreviewTop + tshirtPreviewHeight / 2;
        
        this.ctx.beginPath();
        this.ctx.rect(
          tshirtPreviewCenterX - tshirtPreviewFinalWidth / 2,
          tshirtPreviewCenterY - tshirtPreviewFinalHeight / 2,
          tshirtPreviewFinalWidth,
          tshirtPreviewFinalHeight
        );
        this.ctx.stroke();
        break;
      case 'polygon':
        // Draw polygon preview
        if (this.polygonPoints.length > 0) {
          this.ctx.setLineDash([2, 2]); // Dashed line for preview

          // Draw lines between existing points
          this.ctx.beginPath();
          this.ctx.moveTo(this.polygonPoints[0].x, this.polygonPoints[0].y);
          for (let i = 1; i < this.polygonPoints.length; i++) {
            this.ctx.lineTo(this.polygonPoints[i].x, this.polygonPoints[i].y);
          }

          // Draw line to current mouse position
          if (this.polygonPoints.length >= 2) {
            this.ctx.lineTo(x, y);
          }

          // If hovering near first point, draw closing line
          if (this.polygonPoints.length >= 3) {
            const firstPoint = this.polygonPoints[0];
            const distance = Math.sqrt(
              Math.pow(x - firstPoint.x, 2) +
              Math.pow(y - firstPoint.y, 2)
            );

            if (distance < 10) {
              this.ctx.setLineDash([]); // Solid line for closing
              this.ctx.lineTo(firstPoint.x, firstPoint.y);
            }
          }

          this.ctx.stroke();
          this.ctx.setLineDash([]); // Reset dash

          // Draw points
          this.polygonPoints.forEach((point, index) => {
            this.ctx.fillStyle = (index === 0 && this.polygonPoints.length >= 3) ? '#ff6b6b' : '#1f6feb';
            this.ctx.beginPath();
            this.ctx.arc(point.x, point.y, 4, 0, Math.PI * 2);
            this.ctx.fill();
          });
        }
        break;
      case 'arc':
        // Rectangle-based arc: click and drag to define bounding box
        const arcLeft = Math.min(startX, x);
        const arcTop = Math.min(startY, y);
        const arcWidth = Math.abs(x - startX);
        const arcHeight = Math.abs(y - startY);

        // Use the larger dimension for radius to make it fit the rectangle
        const arcRadius = Math.max(arcWidth, arcHeight) / 2;
        const arcCenterX = arcLeft + arcWidth / 2;
        const arcCenterY = arcTop + arcHeight / 2;

        const startAngle = 0;
        const endAngle = Math.PI;
        this.ctx.beginPath();
        this.ctx.arc(arcCenterX, arcCenterY, arcRadius, startAngle, endAngle);
        this.ctx.stroke();
        break;
      case 'curve':
        if (this.curveType === 'quadratic') {
          if (this.curveControlPoint) {
            this.ctx.beginPath();
            this.ctx.moveTo(startX, startY);
            this.ctx.quadraticCurveTo(this.curveControlPoint.x, this.curveControlPoint.y, x, y);
            this.ctx.stroke();
          } else {
            // Preview with midpoint as control
            const midX = (startX + x) / 2;
            const midY = (startY + y) / 2;
            const dx = x - startX;
            const dy = y - startY;
            const dist = Math.sqrt(dx * dx + dy * dy);

            let directionMultiplier = 0;
            if (this.curveDirection === 'left') {
              directionMultiplier = 1;
            } else if (this.curveDirection === 'right') {
              directionMultiplier = -1;
            } else { // 'auto' - use current behavior
              directionMultiplier = 1;
            }

            const offset = 30 * this.curveIntensity;
            const perpX = -dy / dist * offset * directionMultiplier;
            const perpY = dx / dist * offset * directionMultiplier;

            this.ctx.beginPath();
            this.ctx.moveTo(startX, startY);
            this.ctx.quadraticCurveTo(midX + perpX, midY + perpY, x, y);
            this.ctx.stroke();
          }
        } else if (this.curveType === 'cubic') {
          if (this.curveControlPoints.length >= 2) {
            this.ctx.beginPath();
            this.ctx.moveTo(startX, startY);
            this.ctx.bezierCurveTo(
              this.curveControlPoints[0].x, this.curveControlPoints[0].y,
              this.curveControlPoints[1].x, this.curveControlPoints[1].y,
              x, y
            );
            this.ctx.stroke();
          } else {
            // Preview with calculated control points
            const dx = x - startX;
            const dy = y - startY;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist > 0) {
              // First control point: perpendicular offset
              const offset1 = Math.min(dist * 0.4 * this.curveIntensity, 80 * this.curveIntensity);
              const perpX1 = -dy / dist * offset1;
              const perpY1 = dx / dist * offset1;

              // Second control point: opposite direction and different magnitude
              const offset2 = Math.min(dist * 0.6 * this.curveIntensity, 120 * this.curveIntensity);
              const perpX2 = dy / dist * offset2;  // Opposite direction
              const perpY2 = -dx / dist * offset2; // Opposite direction

              this.ctx.beginPath();
              this.ctx.moveTo(startX, startY);
              this.ctx.bezierCurveTo(
                startX + (x - startX) * 0.3 + perpX1, startY + (y - startY) * 0.3 + perpY1,
                startX + (x - startX) * 0.7 + perpX2, startY + (y - startY) * 0.7 + perpY2,
                x, y
              );
              this.ctx.stroke();
            } else {
              this.drawLine({ startX, startY, endX: x, endY: y });
            }
          }
        }
        
        // Draw endpoints for curve preview
        const curveAngle = Math.atan2(y - startY, x - startX);
        this.drawEndpoint(startX, startY, curveAngle, this.startCap, true);
        this.drawEndpoint(x, y, curveAngle, this.endCap, false);
        break;
      case 'cross':
        // Draw X shape preview (square aspect ratio)
        const crossPreviewWidth = Math.abs(x - startX);
        const crossPreviewHeight = Math.abs(y - startY);
        const crossPreviewSize = Math.max(crossPreviewWidth, crossPreviewHeight);
        
        const crossPreviewCenterX = (startX + x) / 2;
        const crossPreviewCenterY = (startY + y) / 2;
        
        const crossLeft = crossPreviewCenterX - crossPreviewSize / 2;
        const crossTop = crossPreviewCenterY - crossPreviewSize / 2;
        const crossRight = crossPreviewCenterX + crossPreviewSize / 2;
        const crossBottom = crossPreviewCenterY + crossPreviewSize / 2;
        
        this.ctx.beginPath();
        this.ctx.moveTo(crossLeft, crossTop);
        this.ctx.lineTo(crossRight, crossBottom);
        this.ctx.moveTo(crossRight, crossTop);
        this.ctx.lineTo(crossLeft, crossBottom);
        this.ctx.stroke();
        break;
      case 'triangle':
        // Triangle: click and drag to define bounding box
        const triLeft = Math.min(startX, x);
        const triTop = Math.min(startY, y);
        const triWidth = Math.abs(x - startX);
        const triHeight = Math.abs(y - startY);
        
        this.ctx.beginPath();
        // Top point (center of top edge)
        this.ctx.moveTo(triLeft + triWidth / 2, triTop);
        // Bottom right point
        this.ctx.lineTo(triLeft + triWidth, triTop + triHeight);
        // Bottom left point
        this.ctx.lineTo(triLeft, triTop + triHeight);
        // Close triangle
        this.ctx.closePath();
        this.ctx.stroke();
        break;
      case 'rectangle':
        // Rectangle: click and drag to define bounding box
        const rectLeft = Math.min(startX, x);
        const rectTop = Math.min(startY, y);
        const rectWidth = Math.abs(x - startX);
        const rectHeight = Math.abs(y - startY);
        
        this.ctx.beginPath();
        this.ctx.rect(rectLeft, rectTop, rectWidth, rectHeight);
        this.ctx.stroke();
        break;
      case 'animpath':
        // Animation path preview - dashed line with arrow
        // Use the actual startX/startY which may be set to object center
        const animStartX = this.startX;
        const animStartY = this.startY;
        
        this.ctx.strokeStyle = '#1f6feb';
        this.ctx.setLineDash([8, 4]);
        
        // Draw straight line from object to cursor
        this.ctx.beginPath();
        this.ctx.moveTo(animStartX, animStartY);
        this.ctx.lineTo(x, y);
        this.ctx.stroke();
        this.ctx.setLineDash([]);
        
        // Draw start point (circle at object)
        this.ctx.beginPath();
        this.ctx.arc(animStartX, animStartY, 5, 0, Math.PI * 2);
        this.ctx.fillStyle = '#1f6feb';
        this.ctx.fill();
        
        // Draw end point (arrow)
        const animAngle = Math.atan2(y - animStartY, x - animStartX);
        this.drawEndpoint(x, y, animAngle, 'triangle', false);
        break;
    }
    
    this.ctx.restore();
  }

  drawSelectionRect() {
    if (!this.selectionRect) return;

    const rect = this.selectionRect;
    const x = Math.min(rect.startX, rect.endX);
    const y = Math.min(rect.startY, rect.endY);
    const width = Math.abs(rect.endX - rect.startX);
    const height = Math.abs(rect.endY - rect.startY);

    this.ctx.save();
    this.ctx.strokeStyle = '#1f6feb';
    this.ctx.fillStyle = 'rgba(31, 111, 235, 0.1)';
    this.ctx.lineWidth = 1;
    this.ctx.setLineDash([5, 5]);

    this.ctx.fillRect(x, y, width, height);
    this.ctx.strokeRect(x, y, width, height);

    this.ctx.setLineDash([]);
    this.ctx.restore();
  }

  drawCurveControlPoints(drawing) {
    this.ctx.save();
    this.ctx.strokeStyle = '#ff6b6b';
    this.ctx.fillStyle = '#ff6b6b';
    this.ctx.lineWidth = 1;

    const curveType = drawing.curveType || 'quadratic';
    const controlPointSize = 6; // Larger for easier clicking

    if (curveType === 'quadratic' && drawing.controlPoint) {
      // Draw single control point for quadratic curves
      this.ctx.beginPath();
      this.ctx.arc(drawing.controlPoint.x, drawing.controlPoint.y, controlPointSize, 0, Math.PI * 2);
      this.ctx.fill();
      
      // Draw outline for better visibility
      this.ctx.strokeStyle = '#ffffff';
      this.ctx.lineWidth = 1;
      this.ctx.stroke();

      // Draw line from start to control point
      this.ctx.setLineDash([2, 2]);
      this.ctx.strokeStyle = '#ff6b6b';
      this.ctx.beginPath();
      this.ctx.moveTo(drawing.startX, drawing.startY);
      this.ctx.lineTo(drawing.controlPoint.x, drawing.controlPoint.y);
      this.ctx.stroke();

    } else if (curveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
      // Draw two control points for cubic curves
      drawing.controlPoints.forEach((cp, index) => {
        const color = index === 0 ? '#ff6b6b' : '#4ec9b0';
        this.ctx.fillStyle = color;
        this.ctx.beginPath();
        this.ctx.arc(cp.x, cp.y, controlPointSize, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Draw outline for better visibility
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1;
        this.ctx.stroke();
      });

      // Draw lines from start/end points to control points
      this.ctx.setLineDash([2, 2]);
      this.ctx.strokeStyle = '#ff6b6b';
      this.ctx.beginPath();
      this.ctx.moveTo(drawing.startX, drawing.startY);
      this.ctx.lineTo(drawing.controlPoints[0].x, drawing.controlPoints[0].y);
      this.ctx.stroke();

      this.ctx.strokeStyle = '#4ec9b0';
      this.ctx.beginPath();
      this.ctx.moveTo(drawing.endX, drawing.endY);
      this.ctx.lineTo(drawing.controlPoints[1].x, drawing.controlPoints[1].y);
      this.ctx.stroke();
    }

    this.ctx.restore();
  }
  
  getCurveControlPointAt(x, y, drawing) {
    if (!drawing || drawing.type !== 'curve') return null;
    
    const threshold = 8; // Click tolerance for control points
    const curveType = drawing.curveType || 'quadratic';
    
    if (curveType === 'quadratic' && drawing.controlPoint) {
      const dist = Math.sqrt(
        Math.pow(x - drawing.controlPoint.x, 2) + 
        Math.pow(y - drawing.controlPoint.y, 2)
      );
      if (dist <= threshold) {
        return 0; // Return index 0 for quadratic control point
      }
    } else if (curveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
      for (let i = 0; i < drawing.controlPoints.length; i++) {
        const cp = drawing.controlPoints[i];
        const dist = Math.sqrt(
          Math.pow(x - cp.x, 2) + 
          Math.pow(y - cp.y, 2)
        );
        if (dist <= threshold) {
          return i; // Return the index of the clicked control point
        }
      }
    }
    
    return null;
  }

  getCanvasCoordinates(e) {
    const rect = this.canvas.getBoundingClientRect();

    // Standard canvas coordinate calculation accounting for scaling
    // rect.width/height are the scaled visual dimensions
    // canvas.width/height are the actual canvas dimensions
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    let x = (e.clientX - rect.left) * scaleX;
    let y = (e.clientY - rect.top) * scaleY;

    // Transform coordinates based on canvas rotation
    // We need to map visual coordinates back to the original coordinate space
    if (this.canvasRotation && this.canvasRotation !== 0) {
      const origWidth = this.originalCanvasWidth || this.image?.width || this.canvas.width;
      const origHeight = this.originalCanvasHeight || this.image?.height || this.canvas.height;
      
      switch (this.canvasRotation) {
        case 90:
          // Visual (x, y) maps to original (y, origHeight - x)
          // When rotated 90°, visual x becomes original y
          // and visual y becomes (origWidth - original x), so original x = origWidth - visual y
          // But since canvas dimensions are swapped, we use origHeight for visual x mapping
          const temp90 = x;
          x = y;
          y = origHeight - temp90;
          break;
        case 180:
          // Visual (x, y) maps to original (origWidth - x, origHeight - y)
          x = origWidth - x;
          y = origHeight - y;
          break;
        case 270:
          // Visual (x, y) maps to original (origHeight - y, x)
          const temp270 = x;
          x = origWidth - y;
          y = temp270;
          break;
      }
    }

    return { x, y };
  }

  // Check if a point is on an animation path line (for adding waypoints)
  isPointOnPath(drawing, x, y, threshold = 10) {
    if (drawing.type !== 'animpath') return false;
    
    const pathPoints = this.getPathPoints(drawing);
    if (pathPoints.length < 2) return false;
    
    // Check each segment of the path
    for (let i = 0; i < pathPoints.length - 1; i++) {
      const p1 = pathPoints[i];
      const p2 = pathPoints[i + 1];
      
      // Calculate distance from point to line segment
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;
      const length = Math.sqrt(dx * dx + dy * dy);
      
      if (length === 0) continue;
      
      // Project point onto line segment
      const t = Math.max(0, Math.min(1, ((x - p1.x) * dx + (y - p1.y) * dy) / (length * length)));
      const projX = p1.x + t * dx;
      const projY = p1.y + t * dy;
      
      // Calculate distance from point to projected point
      const dist = Math.sqrt((x - projX) * (x - projX) + (y - projY) * (y - projY));
      
      if (dist <= threshold) {
        return true;
      }
    }
    
    return false;
  }

  // Get waypoint at a given position (returns {pathIndex, waypointIndex} or null)
  getWaypointAtPosition(x, y, threshold = 8) {
    for (let i = 0; i < this.drawings.length; i++) {
      const drawing = this.drawings[i];
      if (drawing.type === 'animpath' && drawing.waypoints && drawing.waypoints.length > 0) {
        // Only check waypoints if the path is selected
        if (this.selectedDrawings.includes(i)) {
          for (let j = 0; j < drawing.waypoints.length; j++) {
            const waypoint = drawing.waypoints[j];
            const dist = Math.sqrt((x - waypoint.x) * (x - waypoint.x) + (y - waypoint.y) * (y - waypoint.y));
            if (dist <= threshold) {
              return { pathIndex: i, waypointIndex: j };
            }
          }
        }
      }
    }
    return null;
  }

  handleMouseDown(e) {
    const coords = this.getCanvasCoordinates(e);
    
    if (this.currentTool === 'select') {
      // Hide style toolbar when starting selection (will show again when shape is selected)
      const styleToolbar = document.getElementById('editorStyleToolbar');
      const fontSizeControl = document.getElementById('editorFontSizeControl');
      // Don't hide style toolbar here - let updateSelectionControls handle it
      if (fontSizeControl) {
        fontSizeControl.classList.add('hidden');
      }

      // First check if clicking on a resize handle
      if (this.selectedDrawings.length === 1) {
        const selectedDrawing = this.drawings[this.selectedDrawings[0]];
        
        // Check if clicking on a waypoint (for animpaths only)
        if (selectedDrawing.type === 'animpath') {
          const waypointAtPos = this.getWaypointAtPosition(coords.x, coords.y);
          if (waypointAtPos && waypointAtPos.pathIndex === this.selectedDrawings[0]) {
            // Start dragging waypoint
            this.draggingWaypoint = waypointAtPos.waypointIndex;
            this.draggingWaypointPath = waypointAtPos.pathIndex;
            this.selectedWaypoint = waypointAtPos;
            this.isDragging = true;
            this.lastMousePos = { x: coords.x, y: coords.y };
            this.redraw();
            return;
          }
          
          // Don't add waypoint on single click - only on double click
          // Allow normal selection/dragging behavior
        }
        
        // Check if clicking on a curve control point (for curves only)
        if (selectedDrawing.type === 'curve') {
          const controlPointIndex = this.getCurveControlPointAt(coords.x, coords.y, selectedDrawing);
          if (controlPointIndex !== null) {
            // Start dragging control point
            this.draggingControlPoint = controlPointIndex;
            this.draggingControlPointDrawing = this.selectedDrawings[0];
            this.isDragging = true;
            return;
          }
        }
        
        const bounds = this.getSelectionBounds(selectedDrawing);
        if (bounds) {
          const handle = this.getResizeHandle(coords.x, coords.y, bounds, selectedDrawing);
          if (handle) {
            // Start resizing or rotating
            this.resizingHandle = handle;
            this.resizeStartBounds = { ...bounds };
            this.resizeStartDrawing = JSON.parse(JSON.stringify(selectedDrawing));
            this.isDragging = true;
            
            // If rotating, store initial angle
            if (handle === 'rotate') {
              const centerX = (bounds.minX + bounds.maxX) / 2;
              const centerY = (bounds.minY + bounds.maxY) / 2;
              this.rotationStartAngle = Math.atan2(coords.y - centerY, coords.x - centerX);
              this.rotationStartDrawingAngle = selectedDrawing.rotation || 0;
            }
            
            // If move handle, store initial position
            if (handle === 'move') {
              this.lastMoveHandlePos = { x: coords.x, y: coords.y };
            }
            
            return;
          }
        }
        
        // If clicking on an already-selected drawing but not on a handle,
        // check if we're clicking on the drawing itself to start dragging
        if (this.isPointInDrawing(selectedDrawing, coords.x, coords.y)) {
          // Start dragging the already-selected drawing
          this.lastMousePos = { x: coords.x, y: coords.y };
          this.isDragging = true;
          this.selectionRect = null;
          this.resizingHandle = null;
          this.lastMoveHandlePos = null;
          this.redraw();
          return;
        }
      }

      // For polygon tool, skip selection/dragging - clicks should add points
      if (this.currentTool !== 'polygon') {
        // Check if clicking on a waypoint of any animpath (even if not selected)
        const waypointAtPos = this.getWaypointAtPosition(coords.x, coords.y);
        if (waypointAtPos) {
          // Select the path if not already selected
          if (!this.selectedDrawings.includes(waypointAtPos.pathIndex)) {
            if (!e.shiftKey) {
              this.selectedDrawings = [waypointAtPos.pathIndex];
            } else {
              if (!this.selectedDrawings.includes(waypointAtPos.pathIndex)) {
                this.selectedDrawings.push(waypointAtPos.pathIndex);
              }
            }
            this.updateSelectionControls();
          }
          // Start dragging waypoint
          this.draggingWaypoint = waypointAtPos.waypointIndex;
          this.draggingWaypointPath = waypointAtPos.pathIndex;
          this.selectedWaypoint = waypointAtPos;
          this.isDragging = true;
          this.lastMousePos = { x: coords.x, y: coords.y };
          this.redraw();
          return;
        }
        
        // Check if clicking on an animpath line to select it
        for (let i = 0; i < this.drawings.length; i++) {
          const drawing = this.drawings[i];
          if (drawing.type === 'animpath' && this.isPointOnPath(drawing, coords.x, coords.y)) {
            // Select the path if not already selected
            if (!this.selectedDrawings.includes(i)) {
              if (!e.shiftKey) {
                this.selectedDrawings = [i];
              } else {
                if (!this.selectedDrawings.includes(i)) {
                  this.selectedDrawings.push(i);
                }
              }
              this.updateSelectionControls();
              this.redraw();
              return; // Just select, don't add waypoint
            }
            // If already selected, allow normal selection/dragging behavior
            return;
          }
        }
        
        // Check if clicking on an existing drawing
        const clickedDrawing = this.getDrawingAtPoint(coords.x, coords.y);
        if (clickedDrawing !== null) {
          // Handle selection with Shift key for multiple selection
          if (e.shiftKey) {
            // Shift-click: toggle selection
            if (this.selectedDrawings.includes(clickedDrawing)) {
              // Deselect if already selected
              this.selectedDrawings = this.selectedDrawings.filter(idx => idx !== clickedDrawing);
            } else {
              // Add to selection
              this.selectedDrawings.push(clickedDrawing);
            }
          } else {
            // Normal click: replace selection
          if (!this.selectedDrawings.includes(clickedDrawing)) {
            this.selectedDrawings = [clickedDrawing];
            }
            // If already selected, keep selection for dragging
          }
          
            // Show opacity control and set its value for the selected drawing
            this.updateOpacityControlForSelection();
            // Update all selection controls (curve, style, etc.)
            this.updateSelectionControls();
          
          // Start dragging - store initial mouse position
          this.lastMousePos = { x: coords.x, y: coords.y };
          this.isDragging = true;
          this.selectionRect = null; // Cancel any selection rectangle
          // Clear any resize handle state to allow normal dragging
          this.resizingHandle = null;
          this.lastMoveHandlePos = null; // Clear move handle position
        } else {
          // Clicked on empty space - always start selection rectangle
          // Clear lastMousePos to prevent dragging selected items
          this.lastMousePos = null;
          
          if (!e.shiftKey) {
            // Only clear selection if not holding Shift
          this.selectedDrawings = [];
          // Update controls (will hide them when nothing is selected)
          this.updateSelectionControls();
          }
          // Start selection rectangle
          this.selectionRect = {
            startX: coords.x,
            startY: coords.y,
            endX: coords.x,
            endY: coords.y
          };
          this.isDragging = true;
          // Clear any resize handle state
          this.resizingHandle = null;
          this.lastMoveHandlePos = null;
        }
        this.redraw();
        return;
      }
    }
    
    // Opacity control will be shown during mousemove when actively drawing

    // Opacity control is already visible when tool is selected
    this.startX = coords.x;
    this.startY = coords.y;
    this.currentX = coords.x;
    this.currentY = coords.y;
    
    if (this.currentTool === 'ball' || this.currentTool === 'tshirt') {
      const deltaX = coords.x - this.startX;
      const deltaY = coords.y - this.startY;
      const size = Math.max(Math.abs(deltaX), Math.abs(deltaY));
      const signX = deltaX >= 0 ? 1 : -1;
      const signY = deltaY >= 0 ? 1 : -1;
      this.currentX = this.startX + size * signX;
      this.currentY = this.startY + size * signY;
    }
    this.isDrawing = true;
    
    if (this.currentTool === 'polygon') {
      // Check if clicking near the first point to close the polygon
      if (this.polygonPoints.length >= 3) {
        const firstPoint = this.polygonPoints[0];
        const distance = Math.sqrt(
          Math.pow(coords.x - firstPoint.x, 2) +
          Math.pow(coords.y - firstPoint.y, 2)
        );

        if (distance < 10) { // Within 10 pixels of first point
          this.finishPolygon();
          return;
        }
      }

      this.polygonPoints.push({ x: coords.x, y: coords.y });
      this.redraw();
    } else if (this.currentTool === 'text') {
      e.preventDefault(); // Prevent any default behavior
      console.log('Text tool activated, calling createTextInput with coords:', coords.x, coords.y);
      // Use setTimeout to ensure text input is created after mousedown event completes
      setTimeout(() => {
        this.createTextInput(coords.x, coords.y, e);
      }, 10);
    } else if (this.currentTool === 'image') {
      // Image tool now opens file selection directly on button click
      // No need to handle canvas clicks for image tool
      e.preventDefault();
    } else if (this.currentTool === 'ball' || this.currentTool === 'tshirt' || 
               this.currentTool === 'barrier' || this.currentTool === 'biggoal' || 
               this.currentTool === 'ladder' || this.currentTool === 'stick') {
      // Start drawing ball, t-shirt, or SVG elements
      this.isDrawing = true;
      this.startX = coords.x;
      this.startY = coords.y;
      this.currentX = coords.x;
      this.currentY = coords.y;
    } else if (this.currentTool === 'freehand') {
      this.drawings.push({
        type: 'freehand',
        color: this.currentColor,
        lineWidth: this.lineWidth || 2,
        opacity: this.opacity,
        points: [{ x: coords.x, y: coords.y }],
        highlightEnabled: this.highlightEnabled,
        highlightColor: this.highlightColor,
        highlightThickness: this.highlightThickness,
        highlightStyle: this.highlightStyle,
        eventName: this.eventName || ''
      });
    } else if (this.currentTool === 'spray') {
      this.isDrawing = true;
      this.drawings.push({
        type: 'spray',
        color: this.currentColor,
        opacity: this.opacity,
        particles: [], // Array of {x, y} positions
        radius: this.sprayRadius,
        density: this.sprayDensity,
        particleSize: this.sprayParticleSize,
        highlightEnabled: this.highlightEnabled,
        highlightColor: this.highlightColor,
        highlightThickness: this.highlightThickness,
        highlightStyle: this.highlightStyle,
        eventName: this.eventName || ''
      });
      // Generate initial spray particles
      this.addSprayParticles(coords.x, coords.y);
      this.redraw();
    } else if (this.currentTool === 'heatmap') {
      this.isDrawing = true;
      this.heatmapLastUpdateTime = Date.now();
      
      // Check for overlapping heat maps
      const overlappingIndices = this.getOverlappingHeatmaps(coords.x, coords.y, this.heatmapRadius);
      
      if (overlappingIndices.length > 0) {
        // Merge with existing heat maps
        this.activeHeatmapIndices = overlappingIndices;
        // Add initial heat to overlapping heat maps
        this.addHeatAtPosition(coords.x, coords.y, this.activeHeatmapIndices);
      } else {
        // Create new heat map
        this.drawings.push({
          type: 'heatmap',
          color: this.currentColor,
          opacity: this.opacity,
          heatGrid: {}, // Grid-based heat storage: key="x,y", value=intensity (plain object for JSON serialization)
          radius: this.heatmapRadius,
          gridSize: this.heatmapGridSize,
          highlightEnabled: this.highlightEnabled,
          highlightColor: this.highlightColor,
          highlightThickness: this.highlightThickness,
          highlightStyle: this.highlightStyle,
          eventName: this.eventName || ''
        });
        // Track the new heat map index
        this.activeHeatmapIndices = [this.drawings.length - 1];
        // Add initial heat at position
        this.addHeatAtPosition(coords.x, coords.y, this.activeHeatmapIndices);
      }
      
      this.redraw();
    } else if (this.currentTool === 'curve') {
      // Store midpoint as control point
      this.curveControlPoint = null;
    } else if (this.currentTool === 'animpath') {
      // Animation paths can only be created through "Add Movement" button
      if (this.pendingMovementTarget === null) {
        showNotification('Select a ball or t-shirt and click "Add Movement" first', 'warning');
        this.selectTool('select');
        return;
      }
      
      const targetDrawing = this.drawings[this.pendingMovementTarget];
      if (targetDrawing) {
        // Get center of the target object - this is the FIXED start point
        const centerX = (targetDrawing.startX + targetDrawing.endX) / 2;
        const centerY = (targetDrawing.startY + targetDrawing.endY) / 2;
        this.startX = centerX;
        this.startY = centerY;
        // The end point follows the mouse click position
        this.currentX = coords.x;
        this.currentY = coords.y;
      }
      this.isDrawing = true;
      // Hide the movement hint when user starts drawing
      this.hideMovementHint();
    } else if (this.currentTool === 'formation') {
      // Place formation at click position
      this.placeFormation(coords.x, coords.y);
    }
  }

  handleMouseMove(e) {
    const coords = this.getCanvasCoordinates(e);
    
    // Update hovered waypoint for visual feedback
    if (this.currentTool === 'select' && !this.isDragging) {
      const waypointAtPos = this.getWaypointAtPosition(coords.x, coords.y);
      if (waypointAtPos !== this.hoveredWaypoint) {
        this.hoveredWaypoint = waypointAtPos;
        this.redraw();
      }
    }
    
    // Handle waypoint dragging
    if (this.draggingWaypoint !== null && this.draggingWaypointPath !== null) {
      const drawing = this.drawings[this.draggingWaypointPath];
      if (drawing && drawing.waypoints && drawing.waypoints[this.draggingWaypoint]) {
        // Update waypoint position
        drawing.waypoints[this.draggingWaypoint].x = coords.x;
        drawing.waypoints[this.draggingWaypoint].y = coords.y;
        this.redraw();
        return;
      }
    }
    
    // If drawing ball, force perfect round shape while dragging
    if (this.isDrawing && this.currentTool === 'ball') {
      // Ball must be perfectly round - use the larger dimension
      const dx = coords.x - this.startX;
      const dy = coords.y - this.startY;
      
      // Use the larger dimension to ensure perfect roundness
      const size = Math.max(Math.abs(dx), Math.abs(dy));
      
      // Use default if too small
      // Scale default size based on original canvas dimensions (not rotated)
      const canvasWidth = this.originalCanvasWidth || this.canvas.width || this.referenceCanvasWidth;
      const canvasHeight = this.originalCanvasHeight || this.canvas.height || this.referenceCanvasHeight;
      const scaleFactor = Math.min(
        canvasWidth / this.referenceCanvasWidth,
        canvasHeight / this.referenceCanvasHeight
      );
      const defaultSize = 25 * scaleFactor; // Scaled default ball size
      const finalSize = size < (10 * scaleFactor) ? defaultSize : size;
      
      // Update current position maintaining perfect square
      this.currentX = this.startX + (dx >= 0 ? finalSize : -finalSize);
      this.currentY = this.startY + (dy >= 0 ? finalSize : -finalSize);
    } else if (this.isDrawing && this.currentTool === 'tshirt') {
      // T-shirt maintains 3:4 aspect ratio (width:height)
      const dx = coords.x - this.startX;
      const dy = coords.y - this.startY;
      const tshirtAspectRatio = 3 / 4;
      
      let finalWidth = Math.abs(dx);
      let finalHeight = Math.abs(dy);
      
      // Adjust to maintain 3:4 ratio
      if (Math.abs(dx) / Math.abs(dy) > tshirtAspectRatio) {
        finalHeight = Math.abs(dx) / tshirtAspectRatio;
      } else {
        finalWidth = Math.abs(dy) * tshirtAspectRatio;
      }
      
      this.currentX = this.startX + (dx >= 0 ? finalWidth : -finalWidth);
      this.currentY = this.startY + (dy >= 0 ? finalHeight : -finalHeight);
    } else {
      this.currentX = coords.x;
      this.currentY = coords.y;
    }

    // Opacity control visibility is handled by selectTool() - no need to change during drawing
    
    // Update cursor when hovering over resize handles
    if (this.currentTool === 'select' && !this.isDragging && this.selectedDrawings.length === 1) {
      const selectedDrawing = this.drawings[this.selectedDrawings[0]];
      const bounds = this.getSelectionBounds(selectedDrawing);
      if (bounds) {
        const handle = this.getResizeHandle(coords.x, coords.y, bounds, selectedDrawing);
        if (handle) {
          // Set appropriate cursor based on handle
          const cursors = {
            'tl': 'nwse-resize',
            'tr': 'nesw-resize',
            'bl': 'nesw-resize',
            'br': 'nwse-resize',
            'start': 'crosshair',
            'end': 'crosshair',
            'rotate': 'grab',
            'move': 'move'
          };
          this.canvas.style.cursor = cursors[handle] || 'default';
          return;
        } else {
          this.canvas.style.cursor = 'default';
        }
      }
    }
    
    if (this.currentTool === 'select' && this.isDragging) {
      // Handle resizing
      if (this.resizingHandle && this.selectedDrawings.length === 1) {
        const drawing = this.drawings[this.selectedDrawings[0]];
        const oldBounds = this.resizeStartBounds;
        
        // Handle rotation
        if (this.resizingHandle === 'rotate') {
          const centerX = (oldBounds.minX + oldBounds.maxX) / 2;
          const centerY = (oldBounds.minY + oldBounds.maxY) / 2;
          
          // Calculate angle from center to current mouse position
          const currentAngle = Math.atan2(coords.y - centerY, coords.x - centerX);
          
          // Calculate rotation delta from start angle
          const deltaAngle = currentAngle - this.rotationStartAngle;
          
          // Apply rotation
          drawing.rotation = (this.rotationStartDrawingAngle || 0) + deltaAngle;
          
          this.redraw();
          return;
        }
        
        // Handle move handle (for balls, t-shirts, and SVG elements)
        if (this.resizingHandle === 'move') {
          if (!this.lastMoveHandlePos) {
            this.lastMoveHandlePos = { x: coords.x, y: coords.y };
          }
          const deltaX = coords.x - this.lastMoveHandlePos.x;
          const deltaY = coords.y - this.lastMoveHandlePos.y;
          this.moveDrawing(drawing, deltaX, deltaY);
          this.lastMoveHandlePos = { x: coords.x, y: coords.y };
          this.redraw();
          return;
        }
        
        // Handle line/arrow endpoint dragging
        if (this.resizingHandle === 'start' || this.resizingHandle === 'end') {
          // For animation paths, only allow changing the end point (start is fixed to object center)
          if (drawing.type === 'animpath' && this.resizingHandle === 'start') {
            return; // Don't allow moving the start point of animation paths
          }
          
          if (this.resizingHandle === 'start') {
            drawing.startX = coords.x;
            drawing.startY = coords.y;
          } else {
            drawing.endX = coords.x;
            drawing.endY = coords.y;
          }
          this.redraw();
          return;
        }
        
        // Calculate new bounds based on which handle is being dragged
        let newBounds = { ...oldBounds };
        
        switch (this.resizingHandle) {
          case 'tl': // Top-left
            newBounds.minX = coords.x;
            newBounds.minY = coords.y;
            break;
          case 'tr': // Top-right
            newBounds.maxX = coords.x;
            newBounds.minY = coords.y;
            break;
          case 'bl': // Bottom-left
            newBounds.minX = coords.x;
            newBounds.maxY = coords.y;
            break;
          case 'br': // Bottom-right
            newBounds.maxX = coords.x;
            newBounds.maxY = coords.y;
            break;
        }
        
        // Ensure minimum size (but skip for SVG elements - they handle it in updateDrawingForResize)
        const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
        if (!svgElements.includes(drawing.type)) {
          const minSize = 10;
          if (newBounds.maxX - newBounds.minX < minSize) {
            if (this.resizingHandle === 'tl' || this.resizingHandle === 'bl') {
              newBounds.minX = newBounds.maxX - minSize;
            } else {
              newBounds.maxX = newBounds.minX + minSize;
            }
          }
          if (newBounds.maxY - newBounds.minY < minSize) {
            if (this.resizingHandle === 'tl' || this.resizingHandle === 'tr') {
              newBounds.minY = newBounds.maxY - minSize;
            } else {
              newBounds.maxY = newBounds.minY + minSize;
            }
          }
        }
        
        // Update drawing coordinates directly from new bounds (don't restore first)
        this.updateDrawingForResize(drawing, this.resizingHandle, newBounds, oldBounds);
        this.redraw();
        return;
      }
      
      if (this.selectedDrawings.length > 0 && this.lastMousePos) {
        // Calculate mouse movement delta
        const deltaX = coords.x - this.lastMousePos.x;
        const deltaY = coords.y - this.lastMousePos.y;

        // Collect all drawings to move (selected + their group members)
        const drawingsToMove = new Set();
        
        this.selectedDrawings.forEach(drawingIndex => {
          const drawing = this.drawings[drawingIndex];
          if (drawing) {
            drawingsToMove.add(drawingIndex);
            
            // If this drawing is in a group, add all group members
            if (drawing.groupId !== undefined) {
              const groupMembers = this.getGroupMembers(drawingIndex);
              groupMembers.forEach(memberIndex => {
                drawingsToMove.add(memberIndex);
              });
            }
          }
        });

        // Move all drawings (selected + group members) by the mouse delta
        drawingsToMove.forEach(drawingIndex => {
          const drawing = this.drawings[drawingIndex];
          if (drawing) {
          this.moveDrawing(drawing, deltaX, deltaY);
          }
        });

        // Update last mouse position
        this.lastMousePos = { x: coords.x, y: coords.y };

        this.redraw();
        return;
      } else if (this.selectionRect) {
        // Update selection rectangle
        this.selectionRect.endX = coords.x;
        this.selectionRect.endY = coords.y;
        this.redraw();
        return;
      }
    }
    
    if (this.isDrawing) {
      if (this.currentTool === 'freehand') {
        const drawing = this.drawings[this.drawings.length - 1];
        if (drawing) {
          drawing.points.push({ x: coords.x, y: coords.y });
          this.redraw();
        }
      } else if (this.currentTool === 'spray') {
        // Add spray particles at current mouse position
        this.addSprayParticles(coords.x, coords.y);
        this.redraw();
      } else if (this.currentTool === 'heatmap') {
        // Throttle heat updates for performance (every ~16ms for ~60fps)
        const now = Date.now();
        if (now - this.heatmapLastUpdateTime >= 16) {
          // Use active heat map indices if available (for merging), otherwise use last drawing
          if (this.activeHeatmapIndices && this.activeHeatmapIndices.length > 0) {
            this.addHeatAtPosition(coords.x, coords.y, this.activeHeatmapIndices);
          } else {
            this.addHeatAtPosition(coords.x, coords.y);
          }
          this.heatmapLastUpdateTime = now;
          this.redraw();
        }
      } else if (this.currentTool === 'curve') {
        // Update control points for curve preview
        const midX = (this.startX + coords.x) / 2;
        const midY = (this.startY + coords.y) / 2;
        // Calculate perpendicular offset for curve with intensity
        const dx = coords.x - this.startX;
        const dy = coords.y - this.startY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (this.curveType === 'quadratic') {
          if (dist > 0) {
            const offset = Math.min(dist * 0.5 * this.curveIntensity, 100 * this.curveIntensity);
            // Calculate direction multiplier: 1 for left/clockwise, -1 for right/counterclockwise, 0 for straight
            let directionMultiplier = 0;
            if (this.curveDirection === 'left') {
              directionMultiplier = 1;
            } else if (this.curveDirection === 'right') {
              directionMultiplier = -1;
            } else { // 'auto' - use current behavior
              directionMultiplier = 1;
            }

            const perpX = -dy / dist * offset * directionMultiplier;
            const perpY = dx / dist * offset * directionMultiplier;
            this.curveControlPoint = { x: midX + perpX, y: midY + perpY };
          } else {
            this.curveControlPoint = { x: midX, y: midY };
          }
        } else if (this.curveType === 'cubic') {
          // For cubic curves, create two control points with different behaviors
          if (dist > 0) {
            // Calculate direction multiplier: 1 for left/clockwise, -1 for right/counterclockwise, 0 for straight
            let directionMultiplier = 0;
            if (this.curveDirection === 'left') {
              directionMultiplier = 1;
            } else if (this.curveDirection === 'right') {
              directionMultiplier = -1;
            } else { // 'auto' - use current behavior
              directionMultiplier = 1;
            }

            // First control point: perpendicular offset
            const offset1 = Math.min(dist * 0.4 * this.curveIntensity, 80 * this.curveIntensity);
            const perpX1 = -dy / dist * offset1 * directionMultiplier;
            const perpY1 = dx / dist * offset1 * directionMultiplier;

            // Second control point: opposite direction and different magnitude
            const offset2 = Math.min(dist * 0.6 * this.curveIntensity, 120 * this.curveIntensity);
            const perpX2 = dy / dist * offset2 * directionMultiplier;  // Opposite direction
            const perpY2 = -dx / dist * offset2 * directionMultiplier; // Opposite direction

            this.curveControlPoints = [
              { x: this.startX + (coords.x - this.startX) * 0.3 + perpX1, y: this.startY + (coords.y - this.startY) * 0.3 + perpY1 },
              { x: this.startX + (coords.x - this.startX) * 0.7 + perpX2, y: this.startY + (coords.y - this.startY) * 0.7 + perpY2 }
            ];
          } else {
            this.curveControlPoints = [
              { x: this.startX + (coords.x - this.startX) * 0.3, y: this.startY + (coords.y - this.startY) * 0.3 },
              { x: this.startX + (coords.x - this.startX) * 0.7, y: this.startY + (coords.y - this.startY) * 0.7 }
            ];
          }
        }
        this.redraw();
      } else {
        this.redraw();
      }
    }
  }

  handleMouseUp(e) {
    if (this.currentTool === 'select' && this.isDragging) {
      // Finish dragging waypoint
      if (this.draggingWaypoint !== null && this.draggingWaypointPath !== null) {
        this.draggingWaypoint = null;
        this.draggingWaypointPath = null;
        this.isDragging = false;
        this.saveState();
        this.redraw();
        return;
      }
      
      // Finish dragging control point
      if (this.draggingControlPoint !== null) {
        this.draggingControlPoint = null;
        this.draggingControlPointDrawing = null;
        this.isDragging = false;
        this.saveState();
        this.redraw();
        return;
      }
      
      // Finish resizing
      if (this.resizingHandle) {
        this.resizingHandle = null;
        this.resizeStartBounds = null;
        this.resizeStartDrawing = null;
        this.lastMoveHandlePos = null; // Reset move handle position
        this.isDragging = false;
        this.saveState();
        this.redraw();
        return;
      }
      
      if (this.selectionRect) {
        // Complete area selection
        // Only select if rectangle has meaningful size (at least 5px in each dimension)
        const rectWidth = Math.abs(this.selectionRect.endX - this.selectionRect.startX);
        const rectHeight = Math.abs(this.selectionRect.endY - this.selectionRect.startY);
        
        if (rectWidth >= 5 && rectHeight >= 5) {
          const newSelections = this.getDrawingsInSelectionRect();
          if (e.shiftKey) {
            // Shift+drag: add to selection
            newSelections.forEach(idx => {
              if (!this.selectedDrawings.includes(idx)) {
                this.selectedDrawings.push(idx);
              }
            });
          } else {
            // Normal drag: replace selection
            this.selectedDrawings = newSelections;
          }
        } else {
          // Rectangle too small - treat as click, clear selection if not holding Shift
          if (!e.shiftKey) {
            this.selectedDrawings = [];
          }
        }
        this.selectionRect = null;
        // Update opacity control for multiple selections
        this.updateOpacityControlForSelection();
        // Update all selection controls
        this.updateSelectionControls();
      }
      this.isDragging = false;
      this.lastMousePos = null; // Reset mouse position
      this.saveState();
      this.redraw();
      return;
    }
    
    if (!this.isDrawing) return;
    
    const coords = this.getCanvasCoordinates(e);
    this.currentX = coords.x;
    this.currentY = coords.y;
    
    if (this.currentTool === 'polygon') {
      // Update preview for polygon
      // Don't set isDrawing = false for polygon - it stays true until polygon is finished
      this.redraw();
      return;
    }
    
    if (this.currentTool === 'curve') {
      // Use the control points calculated during mouse move
      if (this.curveType === 'quadratic') {
        if (!this.curveControlPoint) {
          const midX = (this.startX + coords.x) / 2;
          const midY = (this.startY + coords.y) / 2;
          const dx = coords.x - this.startX;
          const dy = coords.y - this.startY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > 0) {
            const offset = Math.min(dist * 0.5 * this.curveIntensity, 100 * this.curveIntensity);

            let directionMultiplier = 0;
            if (this.curveDirection === 'left') {
              directionMultiplier = 1;
            } else if (this.curveDirection === 'right') {
              directionMultiplier = -1;
            } else { // 'auto' - use current behavior
              directionMultiplier = 1;
            }

            const perpX = -dy / dist * offset * directionMultiplier;
            const perpY = dx / dist * offset * directionMultiplier;
            this.curveControlPoint = { x: midX + perpX, y: midY + perpY };
          } else {
            this.curveControlPoint = { x: midX, y: midY };
          }
        }
      } else if (this.curveType === 'cubic') {
        if (this.curveControlPoints.length === 0) {
          const dx = coords.x - this.startX;
          const dy = coords.y - this.startY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > 0) {
            let directionMultiplier = 0;
            if (this.curveDirection === 'left') {
              directionMultiplier = 1;
            } else if (this.curveDirection === 'right') {
              directionMultiplier = -1;
            } else { // 'auto' - use current behavior
              directionMultiplier = 1;
            }

            // First control point: perpendicular offset
            const offset1 = Math.min(dist * 0.4 * this.curveIntensity, 80 * this.curveIntensity);
            const perpX1 = -dy / dist * offset1 * directionMultiplier;
            const perpY1 = dx / dist * offset1 * directionMultiplier;

            // Second control point: opposite direction and different magnitude
            const offset2 = Math.min(dist * 0.6 * this.curveIntensity, 120 * this.curveIntensity);
            const perpX2 = dy / dist * offset2 * directionMultiplier;  // Opposite direction
            const perpY2 = -dx / dist * offset2 * directionMultiplier; // Opposite direction

            this.curveControlPoints = [
              { x: this.startX + (coords.x - this.startX) * 0.3 + perpX1, y: this.startY + (coords.y - this.startY) * 0.3 + perpY1 },
              { x: this.startX + (coords.x - this.startX) * 0.7 + perpX2, y: this.startY + (coords.y - this.startY) * 0.7 + perpY2 }
            ];
          } else {
            this.curveControlPoints = [
              { x: this.startX + (coords.x - this.startX) * 0.3, y: this.startY + (coords.y - this.startY) * 0.3 },
              { x: this.startX + (coords.x - this.startX) * 0.7, y: this.startY + (coords.y - this.startY) * 0.7 }
            ];
          }
        }
      }
      this.finishDrawing();
    } else if (this.currentTool !== 'freehand' && this.currentTool !== 'spray' && this.currentTool !== 'heatmap' && this.currentTool !== 'text') {
      this.finishDrawing();
    } else if (this.currentTool === 'freehand' || this.currentTool === 'spray' || this.currentTool === 'heatmap') {
      // Freehand/Spray drawing is complete, auto-select it
      const newDrawingIndex = this.drawings.length - 1;
      // For heatmap, select the first active heat map if merging, otherwise the new one
      if (this.currentTool === 'heatmap' && this.activeHeatmapIndices && this.activeHeatmapIndices.length > 0) {
        this.selectedDrawings = [this.activeHeatmapIndices[0]];
        this.activeHeatmapIndices = []; // Clear active indices
      } else {
        this.selectedDrawings = [newDrawingIndex];
      }
      this.selectTool('select');
      this.updateSelectionControls();
      this.saveState();
    }
    
    this.isDrawing = false;
    // Clear active heat map indices when drawing ends
    if (this.currentTool === 'heatmap') {
      this.activeHeatmapIndices = [];
    }
    // Opacity control stays visible until tool is changed
    this.redraw();
  }

  handleRightClick(e) {
    e.preventDefault(); // Prevent context menu

    if (this.currentTool === 'polygon') {
      // Cancel polygon drawing
      this.polygonPoints = [];
      this.isDrawing = false;
      this.redraw();
    } else if (this.currentTool === 'select') {
      // Delete waypoint on right-click
      const coords = this.getCanvasCoordinates(e);
      const waypointAtPos = this.getWaypointAtPosition(coords.x, coords.y);
      if (waypointAtPos) {
        const drawing = this.drawings[waypointAtPos.pathIndex];
        if (drawing && drawing.waypoints && drawing.waypoints[waypointAtPos.waypointIndex]) {
          drawing.waypoints.splice(waypointAtPos.waypointIndex, 1);
          if (this.selectedWaypoint && 
              this.selectedWaypoint.pathIndex === waypointAtPos.pathIndex && 
              this.selectedWaypoint.waypointIndex === waypointAtPos.waypointIndex) {
            this.selectedWaypoint = null;
          }
          this.saveState();
          this.redraw();
        }
      }
    }
  }

  handleDoubleClick(e) {
    if (this.currentTool === 'polygon' && this.polygonPoints.length >= 3) {
      this.finishPolygon();
      return;
    }
    
    // Double-click to edit text, assign player to t-shirt, or add waypoint to animation path
    if (this.currentTool === 'select') {
      const coords = this.getCanvasCoordinates(e);
      
      // Check if double-clicking on an animation path to add waypoint
      for (let i = 0; i < this.drawings.length; i++) {
        const drawing = this.drawings[i];
        if (drawing.type === 'animpath' && this.isPointOnPath(drawing, coords.x, coords.y)) {
          // Add waypoint at double-clicked position
          if (!drawing.waypoints) {
            drawing.waypoints = [];
          }
          drawing.waypoints.push({ x: coords.x, y: coords.y });
          this.saveState();
          this.redraw();
          return;
        }
      }
      
      const clickedDrawing = this.getDrawingAtPoint(coords.x, coords.y);
      
      if (clickedDrawing !== null) {
        const drawing = this.drawings[clickedDrawing];
        if (drawing.type === 'text') {
          // Edit the text
          this.editText(clickedDrawing, e);
        } else if (drawing.type === 'tshirt' && drawing.team) {
          // Open player assignment popup for t-shirt with a team
          this.openPlayerAssignPopup(clickedDrawing);
        }
      }
    }
  }

  finishDrawing() {
    const drawing = {
      type: this.currentTool,
      color: this.currentColor,
      lineWidth: this.lineWidth || 2,
      opacity: this.opacity,
      lineStyle: this.lineStyle || 'solid', // Default to solid
      startX: this.startX,
      startY: this.startY,
      endX: this.currentX,
      endY: this.currentY,
      eventName: this.eventName || '', // Event name for the shape
      animationType: this.shapeAnimationType || null // Shape animation type
    };
    
    // Add start/end cap for lines, curves, arrows, and animation paths
    if (['line', 'curve', 'arrow', 'animpath'].includes(this.currentTool)) {
      drawing.startCap = this.startCap || 'none';
      drawing.endCap = this.endCap || (this.currentTool === 'arrow' ? 'line' : (this.currentTool === 'animpath' ? 'triangle' : 'none'));
    }
    
    // Animation path properties
    if (this.currentTool === 'animpath') {
      drawing.duration = this.animPathDuration;
      drawing.delay = this.animPathDelay;
      drawing.easing = this.animPathEasing;
      drawing.speed = 1.0; // Default speed multiplier
      drawing.lineStyle = 'dashed'; // Animation paths are dashed by default
      drawing.color = '#1f6feb'; // Blue color for animation paths
      drawing.waypoints = []; // Initialize waypoints array
      
      // Hide movement hint
      this.hideMovementHint();
      
      // Auto-link to pending movement target
      if (this.pendingMovementTarget !== null) {
        drawing.targetIndex = this.pendingMovementTarget;
        this.pendingMovementTarget = null; // Clear after linking
      } else {
        drawing.targetIndex = undefined;
      }
    }
    
    // Add fill properties for shapes that can be filled
    const fillableShapes = ['circle', 'oval', 'arc', 'polygon', 'triangle', 'rectangle'];
    if (fillableShapes.includes(this.currentTool)) {
      drawing.fillColor = this.fillColor;
      drawing.fillOpacity = this.fillOpacity !== undefined ? this.fillOpacity : 0.0; // Default transparent
      drawing.fillStyle = this.fillStyle;
    }
    
    // Add control points for curves
    if (this.currentTool === 'curve') {
      drawing.curveType = this.curveType;
      drawing.curveIntensity = this.curveIntensity;
      drawing.curveDirection = this.curveDirection;
      if (this.curveType === 'quadratic' && this.curveControlPoint) {
        drawing.controlPoint = { ...this.curveControlPoint };
      } else if (this.curveType === 'cubic' && this.curveControlPoints.length >= 2) {
        drawing.controlPoints = this.curveControlPoints.map(cp => ({ ...cp }));
      }
    }
    
    // Add number for t-shirt
    if (this.currentTool === 'tshirt') {
      const numberInput = document.getElementById('editorTshirtNumber');
      drawing.number = numberInput ? parseInt(numberInput.value) || 10 : 10;
    }
    
    // Add number for ball (optional - can be empty)
    if (this.currentTool === 'ball') {
      const numberInput = document.getElementById('editorBallNumber');
      const numberValue = numberInput ? numberInput.value.trim() : '';
      drawing.number = numberValue !== '' ? parseInt(numberValue) : null;
    }
    
    // Store original size for proportional resizing
    if (this.currentTool === 'ball') {
      // Ball must be perfectly round - calculate from drag
      const width = Math.abs(this.currentX - this.startX);
      const height = Math.abs(this.currentY - this.startY);
      
      // Default size: smaller round ball
      const defaultSize = 25;
      
      // Use the larger dimension to ensure perfect roundness
      const size = Math.max(width, height);
      const finalSize = size < 10 ? defaultSize : size;
      
      // Calculate center point
      const centerX = (this.startX + this.currentX) / 2;
      const centerY = (this.startY + this.currentY) / 2;
      
      // Create perfectly round ball (width = height, always square)
      const halfSize = finalSize / 2;
      drawing.startX = centerX - halfSize;
      drawing.startY = centerY - halfSize;
      drawing.endX = centerX + halfSize;
      drawing.endY = centerY + halfSize;
      
      // Store dimensions (guaranteed to be round)
      drawing.originalWidth = finalSize;
      drawing.originalHeight = finalSize;
      drawing.aspectRatio = 1; // Always 1:1 for round ball
      
      // Normalize to ensure perfect roundness
      this.normalizeBallBounds(drawing);
    } else if (this.currentTool === 'tshirt') {
      // T-shirt maintains 3:4 aspect ratio (width:height)
      const left = Math.min(this.startX, this.currentX);
      const top = Math.min(this.startY, this.currentY);
      const width = Math.abs(this.currentX - this.startX);
      const height = Math.abs(this.currentY - this.startY);
      const tshirtAspectRatio = 3 / 4; // width:height
      
      // Scale default size based on original canvas dimensions (not rotated)
      // Use original dimensions to ensure consistent size regardless of rotation
      const canvasWidth = this.originalCanvasWidth || this.canvas.width || this.referenceCanvasWidth;
      const canvasHeight = this.originalCanvasHeight || this.canvas.height || this.referenceCanvasHeight;
      const scaleFactor = Math.min(
        canvasWidth / this.referenceCanvasWidth,
        canvasHeight / this.referenceCanvasHeight
      );
      const defaultTshirtWidth = 35 * scaleFactor; // Default size: 35x47 scaled
      const defaultTshirtHeight = 47 * scaleFactor;
      
      let finalWidth = Math.max(width, defaultTshirtWidth);
      let finalHeight = Math.max(height, defaultTshirtHeight);
      
      // Adjust to maintain 3:4 ratio
      if (finalWidth / finalHeight > tshirtAspectRatio) {
        finalHeight = finalWidth / tshirtAspectRatio;
      } else {
        finalWidth = finalHeight * tshirtAspectRatio;
      }
      
      const centerX = left + width / 2;
      const centerY = top + height / 2;
      
      drawing.startX = centerX - finalWidth / 2;
      drawing.startY = centerY - finalHeight / 2;
      drawing.endX = centerX + finalWidth / 2;
      drawing.endY = centerY + finalHeight / 2;
      drawing.originalWidth = finalWidth;
      drawing.originalHeight = finalHeight;
      drawing.aspectRatio = 3 / 4; // T-shirt is 3:4 ratio (width:height)
      
      // Set default t-shirt number, surname, design, and secondary color
      const tshirtNumberInput = document.getElementById('editorTshirtNumber');
      const tshirtSurnameInput = document.getElementById('editorTshirtSurname');
      const tshirtDesignSelect = document.getElementById('editorTshirtDesign');
      const tshirtSecondColorInput = document.getElementById('editorTshirtSecondColor');
      drawing.number = tshirtNumberInput ? parseInt(tshirtNumberInput.value) || 10 : 10;
      drawing.surname = tshirtSurnameInput ? tshirtSurnameInput.value.toUpperCase().trim() : '';
      drawing.design = tshirtDesignSelect ? tshirtDesignSelect.value : 'solid';
      drawing.secondColor = tshirtSecondColorInput ? tshirtSecondColorInput.value : '#000000';
    } else if (['barrier', 'biggoal', 'ladder', 'stick'].includes(this.currentTool)) {
      // SVG elements - set default size and load SVG with original proportions
      // Map tool names to SVG file names and their aspect ratios
      const svgMap = {
        'barrier': { file: 'Barrier.svg', width: 23, height: 13 }, // ~1.77:1
        'biggoal': { file: 'Big goal.svg', width: 210, height: 104 }, // ~2.02:1
        'ladder': { file: 'Ladder.svg', width: 13, height: 51 }, // ~0.255:1
        'stick': { file: 'Stick.svg', width: 6, height: 39 } // ~0.154:1
      };
      
      const svgInfo = svgMap[this.currentTool];
      if (svgInfo) {
        // Calculate aspect ratio from SVG dimensions
        const svgAspectRatio = svgInfo.width / svgInfo.height;
        
        // Get user's drag dimensions
        const width = Math.abs(this.currentX - this.startX);
        const height = Math.abs(this.currentY - this.startY);
        
        // Default size based on the larger dimension
        const defaultSize = 60;
        
        // Determine which dimension to use as base
        let finalWidth, finalHeight;
        if (width > 10 || height > 10) {
          // User dragged - use the larger dimension and maintain aspect ratio
          if (width > height) {
            finalWidth = Math.max(width, defaultSize);
            finalHeight = finalWidth / svgAspectRatio;
          } else {
            finalHeight = Math.max(height, defaultSize);
            finalWidth = finalHeight * svgAspectRatio;
          }
        } else {
          // No drag - use default size maintaining aspect ratio
          if (svgAspectRatio > 1) {
            // Wider than tall
            finalWidth = defaultSize;
            finalHeight = defaultSize / svgAspectRatio;
          } else {
            // Taller than wide
            finalHeight = defaultSize;
            finalWidth = defaultSize * svgAspectRatio;
          }
        }
        
        const centerX = (this.startX + this.currentX) / 2;
        const centerY = (this.startY + this.currentY) / 2;
        
        drawing.startX = centerX - finalWidth / 2;
        drawing.startY = centerY - finalHeight / 2;
        drawing.endX = centerX + finalWidth / 2;
        drawing.endY = centerY + finalHeight / 2;
        drawing.originalWidth = finalWidth;
        drawing.originalHeight = finalHeight;
        drawing.aspectRatio = svgAspectRatio; // Store aspect ratio for resizing
        
        drawing.svgUrl = chrome.runtime.getURL(`icons/${svgInfo.file}`);
        console.log('finishDrawing: Setting svgUrl for', this.currentTool, ':', drawing.svgUrl);
        // Set default color to white
        drawing.color = '#FFFFFF';
        
        // Try to use cached SVG first (from preloading)
        if (this.svgCache[this.currentTool]) {
          drawing.svgElement = this.svgCache[this.currentTool];
          console.log('finishDrawing: Using cached SVG for', this.currentTool);
        } else {
          // Fallback: Initialize svgElement as null - will be loaded asynchronously
        drawing.svgElement = null;
        
          // Load SVG asynchronously - update the drawing directly via closure reference
          console.log('finishDrawing: Cache miss, loading SVG for', this.currentTool, 'URL:', drawing.svgUrl);
        const svgUrl = drawing.svgUrl; // Store URL before pushing
          const drawingType = this.currentTool; // Store the type before async call
          const targetDrawing = drawing; // Store direct reference to the drawing object
        
        // Start loading immediately, but don't wait for it
        this.loadSvgElement(svgUrl).then(img => {
          if (!img) {
              console.error('finishDrawing: loadSvgElement returned null for', drawingType);
            return;
          }
            // Update the drawing directly via closure reference
            if (targetDrawing && targetDrawing.type === drawingType) {
            targetDrawing.svgElement = img;
              // Also cache for future use
              this.svgCache[drawingType] = img;
              console.log('finishDrawing: Successfully loaded SVG for', drawingType, 'img.complete:', img.complete, 'img.naturalWidth:', img.naturalWidth, 'img.naturalHeight:', img.naturalHeight);
            // Force a redraw to show the loaded SVG
            this.redraw();
          } else {
              console.error('finishDrawing: Drawing type mismatch, expected:', drawingType, 'found:', targetDrawing ? targetDrawing.type : 'null');
          }
        }).catch(err => {
          console.error(`finishDrawing: Failed to load SVG ${svgInfo.file}:`, err, 'URL:', svgUrl);
          console.error('finishDrawing: Error details:', err.message, err.stack);
          // Redraw anyway to show placeholder
          this.redraw();
        });
        }
      }
    } else if (this.currentTool === 'cross') {
      // Cross default size: 30x30
      const width = Math.abs(this.currentX - this.startX);
      const height = Math.abs(this.currentY - this.startY);
      const defaultSize = 30;
      
      let finalSize = Math.max(Math.max(width, height), defaultSize);
      
      // If user didn't drag much, use default
      if (width < 10 && height < 10) {
        finalSize = defaultSize;
      }
      
      // Calculate center of the drag point
      const centerX = (this.startX + this.currentX) / 2;
      const centerY = (this.startY + this.currentY) / 2;
      
      // Create square cross (30x30)
      drawing.startX = centerX - finalSize / 2;
      drawing.startY = centerY - finalSize / 2;
      drawing.endX = centerX + finalSize / 2;
      drawing.endY = centerY + finalSize / 2;
      
      // Line style for cross (lineWidth is already set in base drawing object)
      // The opacity slider will control the boldness via the standard lineWidth * opacity calculation
    }
    
    this.drawings.push(drawing);
    this.curveControlPoint = null;
    this.curveControlPoints = [];
    this.saveState();
    
    // Automatically switch to select tool and select the newly drawn shape
    const newDrawingIndex = this.drawings.length - 1;
    this.selectTool('select');
    this.selectedDrawings = [newDrawingIndex];
    this.updateSelectionControls();
    
    // For SVG elements, redraw will be called again when the SVG loads
    // But we redraw now to show the placeholder immediately
    this.redraw();
  }

  finishPolygon() {
    if (this.polygonPoints.length < 3) return;
    
    this.drawings.push({
      type: 'polygon',
      color: this.currentColor,
      lineWidth: 2,
      opacity: this.opacity,
      lineStyle: this.lineStyle || 'solid',
      fillColor: this.fillColor,
      fillOpacity: this.fillOpacity !== undefined ? this.fillOpacity : 0.0, // Default transparent
      fillStyle: this.fillStyle,
      points: [...this.polygonPoints],
      highlightEnabled: this.highlightEnabled,
      highlightThickness: this.highlightThickness,
      highlightStyle: this.highlightStyle,
      animationType: this.shapeAnimationType || null // Shape animation type
    });
    
    this.polygonPoints = [];
    this.saveState();
    
    // Automatically switch to select tool and select the newly drawn polygon
    const newDrawingIndex = this.drawings.length - 1;
    this.selectTool('select');
    this.selectedDrawings = [newDrawingIndex];
    this.updateSelectionControls();
    this.redraw();
  }

  getDrawingAtPoint(x, y) {
    // Check drawings in reverse order (top to bottom)
    for (let i = this.drawings.length - 1; i >= 0; i--) {
      const drawing = this.drawings[i];
      if (this.isPointInDrawing(drawing, x, y)) {
        return i;
      }
    }
    return null;
  }

  getDrawingsInSelectionRect() {
    if (!this.selectionRect) return [];

    const rect = this.selectionRect;
    const minX = Math.min(rect.startX, rect.endX);
    const maxX = Math.max(rect.startX, rect.endX);
    const minY = Math.min(rect.startY, rect.endY);
    const maxY = Math.max(rect.startY, rect.endY);

    const selectedIndices = [];

    this.drawings.forEach((drawing, index) => {
      if (this.doesDrawingIntersectRect(drawing, minX, minY, maxX, maxY)) {
        selectedIndices.push(index);
      }
    });

    return selectedIndices;
  }

  isPointInDrawing(drawing, x, y) {
    const threshold = Math.max(8 / this.zoom, 3); // Click tolerance scales with zoom, minimum 3px

    // If drawing is rotated, transform the point by inverse rotation
    let checkX = x;
    let checkY = y;
    const rotatableTypes = ['circle', 'arc', 'polygon', 'triangle', 'rectangle', 'cross', 'tshirt', 'ball', 'curve'];
    if (drawing.rotation && rotatableTypes.includes(drawing.type)) {
      const bounds = this.getDrawingBoundsForRotation(drawing);
      if (bounds) {
        const centerX = (bounds.minX + bounds.maxX) / 2;
        const centerY = (bounds.minY + bounds.maxY) / 2;
        
        // Rotate point by negative rotation around center
        const cos = Math.cos(-drawing.rotation);
        const sin = Math.sin(-drawing.rotation);
        const dx = x - centerX;
        const dy = y - centerY;
        checkX = centerX + dx * cos - dy * sin;
        checkY = centerY + dx * sin + dy * cos;
      }
    }

    switch (drawing.type) {
      case 'line':
      case 'arrow':
        return this.isPointNearLine(checkX, checkY, drawing.startX, drawing.startY, drawing.endX, drawing.endY, threshold);
      case 'cross':
        // Check if point is near either diagonal line of the X
        const nearFirstDiagonal = this.isPointNearLine(checkX, checkY, drawing.startX, drawing.startY, drawing.endX, drawing.endY, threshold);
        const nearSecondDiagonal = this.isPointNearLine(checkX, checkY, drawing.endX, drawing.startY, drawing.startX, drawing.endY, threshold);
        return nearFirstDiagonal || nearSecondDiagonal;
      case 'curve':
      case 'animpath':
        const curveType = drawing.curveType || 'quadratic';
        if (drawing.controlPoint) {
          return this.isPointNearCurve(checkX, checkY, drawing.startX, drawing.startY, drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY, threshold);
        } else if (curveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
          return this.isPointNearCubicCurve(checkX, checkY, drawing.startX, drawing.startY,
            drawing.controlPoints[0].x, drawing.controlPoints[0].y,
            drawing.controlPoints[1].x, drawing.controlPoints[1].y,
            drawing.endX, drawing.endY, threshold);
        }
        return this.isPointNearLine(checkX, checkY, drawing.startX, drawing.startY, drawing.endX, drawing.endY, threshold);
      case 'circle':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        const circleRadius = Math.max(circleWidth, circleHeight) / 2;
        const circleCenterX = circleLeft + circleWidth / 2;
        const circleCenterY = circleTop + circleHeight / 2;
        const circleDist = Math.sqrt(Math.pow(checkX - circleCenterX, 2) + Math.pow(checkY - circleCenterY, 2));
        return circleDist <= circleRadius + threshold; // Click anywhere inside or near the circle
      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        const ovalRadiusX = ovalWidth / 2;
        const ovalRadiusY = ovalHeight / 2;
        const ovalCenterX = ovalLeft + ovalWidth / 2;
        const ovalCenterY = ovalTop + ovalHeight / 2;
        // Check if point is inside or near the ellipse
        const dx = (checkX - ovalCenterX) / ovalRadiusX;
        const dy = (checkY - ovalCenterY) / ovalRadiusY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const thresholdScaled = threshold / Math.min(ovalRadiusX, ovalRadiusY);
        return dist <= 1 + thresholdScaled;
      case 'ball':
        // Normalize ball bounds first to ensure it's square
        this.normalizeBallBounds(drawing);
        const ballLeft = Math.min(drawing.startX, drawing.endX);
        const ballTop = Math.min(drawing.startY, drawing.endY);
        const ballSize = Math.abs(drawing.endX - drawing.startX);
        const ballCenterX = (drawing.startX + drawing.endX) / 2;
        const ballCenterY = (drawing.startY + drawing.endY) / 2;
        const ballRadius = ballSize / 2;
        const ballDist = Math.sqrt(Math.pow(checkX - ballCenterX, 2) + Math.pow(checkY - ballCenterY, 2));
        return ballDist <= ballRadius + threshold;
      case 'tshirt':
        const tshirtLeft = Math.min(drawing.startX, drawing.endX);
        const tshirtTop = Math.min(drawing.startY, drawing.endY);
        const tshirtWidth = Math.abs(drawing.endX - drawing.startX);
        const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
        const tshirtSize = Math.max(tshirtWidth, tshirtHeight);
        const tshirtCenterX = tshirtLeft + tshirtWidth / 2;
        const tshirtCenterY = tshirtTop + tshirtHeight / 2;
        const tshirtRadius = tshirtSize / 2;
        const tshirtDist = Math.sqrt(Math.pow(checkX - tshirtCenterX, 2) + Math.pow(checkY - tshirtCenterY, 2));
        return tshirtDist <= tshirtRadius + threshold;
      case 'text':
        this.ctx.font = `${drawing.fontSize || 16}px sans-serif`;
        const metrics = this.ctx.measureText(drawing.text);
        return checkX >= drawing.x && checkX <= drawing.x + metrics.width &&
               checkY >= drawing.y - (drawing.fontSize || 16) && checkY <= drawing.y;
      case 'image':
        const imgWidth = drawing.width || drawing.originalWidth || 100;
        const imgHeight = drawing.height || drawing.originalHeight || 100;
        return checkX >= drawing.x && checkX <= drawing.x + imgWidth &&
               checkY >= drawing.y && checkY <= drawing.y + imgHeight;
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - check bounding box
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        return checkX >= svgLeft && checkX <= svgLeft + svgWidth &&
               checkY >= svgTop && checkY <= svgTop + svgHeight;
      case 'triangle':
        const triLeft = Math.min(drawing.startX, drawing.endX);
        const triTop = Math.min(drawing.startY, drawing.endY);
        const triWidth = Math.abs(drawing.endX - drawing.startX);
        const triHeight = Math.abs(drawing.endY - drawing.startY);
        // Check if point is inside triangle bounding box first
        if (checkX < triLeft || checkX > triLeft + triWidth || checkY < triTop || checkY > triTop + triHeight) {
          return false;
        }
        // Check if point is inside triangle using barycentric coordinates
        const v0x = triLeft + triWidth / 2 - triLeft;
        const v0y = triTop - (triTop + triHeight);
        const v1x = triLeft + triWidth - triLeft;
        const v1y = triTop + triHeight - (triTop + triHeight);
        const v2x = checkX - triLeft;
        const v2y = checkY - (triTop + triHeight);
        const dot00 = v0x * v0x + v0y * v0y;
        const dot01 = v0x * v1x + v0y * v1y;
        const dot02 = v0x * v2x + v0y * v2y;
        const dot11 = v1x * v1x + v1y * v1y;
        const dot12 = v1x * v2x + v1y * v2y;
        const invDenom = 1 / (dot00 * dot11 - dot01 * dot01);
        const u = (dot11 * dot02 - dot01 * dot12) * invDenom;
        const v = (dot00 * dot12 - dot01 * dot02) * invDenom;
        return (u >= 0) && (v >= 0) && (u + v <= 1);
      case 'rectangle':
        const rectLeft = Math.min(drawing.startX, drawing.endX);
        const rectTop = Math.min(drawing.startY, drawing.endY);
        const rectWidth = Math.abs(drawing.endX - drawing.startX);
        const rectHeight = Math.abs(drawing.endY - drawing.startY);
        return checkX >= rectLeft && checkX <= rectLeft + rectWidth &&
               checkY >= rectTop && checkY <= rectTop + rectHeight;
      case 'polygon':
        if (drawing.points && drawing.points.length >= 3) {
          return this.isPointInPolygon(checkX, checkY, drawing.points);
        }
        return false;
      case 'polygon-preview':
        // For polygon preview points
        return this.polygonPoints.some(point => {
          const distance = Math.sqrt(Math.pow(checkX - point.x, 2) + Math.pow(checkY - point.y, 2));
          return distance < threshold;
        });
      case 'freehand':
        if (drawing.points && drawing.points.length > 0) {
          for (let i = 0; i < drawing.points.length - 1; i++) {
            const p1 = drawing.points[i];
            const p2 = drawing.points[i + 1];
            if (this.isPointNearLine(checkX, checkY, p1.x, p1.y, p2.x, p2.y, threshold)) {
              return true;
            }
          }
        }
        return false;
      case 'spray':
        // Check if point is within the bounding box of spray particles
        if (drawing.particles && drawing.particles.length > 0) {
          const particleSize = drawing.particleSize || this.sprayParticleSize;
          const minX = Math.min(...drawing.particles.map(p => p.x)) - particleSize;
          const minY = Math.min(...drawing.particles.map(p => p.y)) - particleSize;
          const maxX = Math.max(...drawing.particles.map(p => p.x)) + particleSize;
          const maxY = Math.max(...drawing.particles.map(p => p.y)) + particleSize;
          
          // Check if point is within bounding box
          if (checkX >= minX && checkX <= maxX && checkY >= minY && checkY <= maxY) {
            // Also check if point is near any particle (within particle size + threshold)
            for (const particle of drawing.particles) {
              const dist = Math.sqrt((checkX - particle.x) ** 2 + (checkY - particle.y) ** 2);
              if (dist <= particleSize + threshold) {
                return true;
              }
            }
          }
        }
        return false;
      case 'heatmap':
        // Check if point is within the bounding box of heat map
        if (drawing.heatGrid && Object.keys(drawing.heatGrid).length > 0) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          // Calculate bounding box from heat grid
          let minGridX = Infinity, minGridY = Infinity, maxGridX = -Infinity, maxGridY = -Infinity;
          Object.keys(drawing.heatGrid).forEach(gridKey => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            minGridX = Math.min(minGridX, gridX);
            minGridY = Math.min(minGridY, gridY);
            maxGridX = Math.max(maxGridX, gridX);
            maxGridY = Math.max(maxGridY, gridY);
          });
          
          const minX = minGridX * gridSize;
          const minY = minGridY * gridSize;
          const maxX = (maxGridX + 1) * gridSize;
          const maxY = (maxGridY + 1) * gridSize;
          
          // Check if point is within bounding box (with some threshold for easier selection)
          if (checkX >= minX - threshold && checkX <= maxX + threshold &&
              checkY >= minY - threshold && checkY <= maxY + threshold) {
                return true;
          }
        }
        return false;
      case 'arc':
        const arcLeft = Math.min(drawing.startX, drawing.endX);
        const arcTop = Math.min(drawing.startY, drawing.endY);
        const arcWidth = Math.abs(drawing.endX - drawing.startX);
        const arcHeight = Math.abs(drawing.endY - drawing.startY);
        const arcRadius = Math.max(arcWidth, arcHeight) / 2;
        const arcCenterX = arcLeft + arcWidth / 2;
        const arcCenterY = arcTop + arcHeight / 2;
        const arcDist = Math.sqrt(Math.pow(checkX - arcCenterX, 2) + Math.pow(checkY - arcCenterY, 2));
        // Check if point is within the circular area
        if (arcDist > arcRadius + threshold) return false;
        // Check if point is in the upper semicircle (angle between 0 and PI)
        const angle = Math.atan2(checkY - arcCenterY, checkX - arcCenterX);
        return angle >= -threshold / arcRadius && angle <= Math.PI + threshold / arcRadius;
      default:
        return false;
    }
  }

  isPointNearLine(px, py, x1, y1, x2, y2, threshold) {
    const A = px - x1;
    const B = py - y1;
    const C = x2 - x1;
    const D = y2 - y1;
    const dot = A * C + B * D;
    const lenSq = C * C + D * D;
    let param = -1;
    if (lenSq !== 0) param = dot / lenSq;

    let xx, yy;
    if (param < 0) {
      xx = x1;
      yy = y1;
    } else if (param > 1) {
      xx = x2;
      yy = y2;
    } else {
      xx = x1 + param * C;
      yy = y1 + param * D;
    }

    const dx = px - xx;
    const dy = py - yy;
    return Math.sqrt(dx * dx + dy * dy) < threshold;
  }

  isPointNearCurve(px, py, x1, y1, cx, cy, x2, y2, threshold) {
    // Sample points along the quadratic Bezier curve
    const segments = 20; // Number of segments to sample
    for (let i = 0; i <= segments; i++) {
      const t = i / segments;
      // Quadratic Bezier formula: B(t) = (1-t)^2*P0 + 2*(1-t)*t*P1 + t^2*P2
      const u = 1 - t;
      const tt = t * t;
      const uu = u * u;
      const x = uu * x1 + 2 * u * t * cx + tt * x2;
      const y = uu * y1 + 2 * u * t * cy + tt * y2;

      // Check distance to this point on the curve
      const dx = px - x;
      const dy = py - y;
      if (Math.sqrt(dx * dx + dy * dy) < threshold) {
        return true;
      }
    }
    return false;
  }

  isPointNearCubicCurve(px, py, x1, y1, c1x, c1y, c2x, c2y, x2, y2, threshold) {
    // Sample points along the cubic Bezier curve
    const segments = 25; // Number of segments to sample (more for cubic curves)
    for (let i = 0; i <= segments; i++) {
      const t = i / segments;
      // Cubic Bezier formula: B(t) = (1-t)^3*P0 + 3*(1-t)^2*t*P1 + 3*(1-t)*t^2*P2 + t^3*P3
      const u = 1 - t;
      const tt = t * t;
      const ttt = tt * t;
      const uu = u * u;
      const uuu = uu * u;

      const x = uuu * x1 + 3 * uu * t * c1x + 3 * u * tt * c2x + ttt * x2;
      const y = uuu * y1 + 3 * uu * t * c1y + 3 * u * tt * c2y + ttt * y2;

      // Check distance to this point on the curve
      const dx = px - x;
      const dy = py - y;
      if (Math.sqrt(dx * dx + dy * dy) < threshold) {
        return true;
      }
    }
    return false;
  }

  isPointInPolygon(x, y, points) {
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
      const xi = points[i].x, yi = points[i].y;
      const xj = points[j].x, yj = points[j].y;
      const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  doesDrawingIntersectRect(drawing, rectMinX, rectMinY, rectMaxX, rectMaxY) {
    // Get the bounding box of the drawing
    let drawingMinX, drawingMinY, drawingMaxX, drawingMaxY;

    switch (drawing.type) {
      case 'line':
      case 'arrow':
      case 'cross':
        drawingMinX = Math.min(drawing.startX, drawing.endX) - 5;
        drawingMinY = Math.min(drawing.startY, drawing.endY) - 5;
        drawingMaxX = Math.max(drawing.startX, drawing.endX) + 5;
        drawingMaxY = Math.max(drawing.startY, drawing.endY) + 5;
        break;
      case 'curve':
        const curveType = drawing.curveType || 'quadratic';
        if (curveType === 'quadratic' && drawing.controlPoint) {
          const points = [
            {x: drawing.startX, y: drawing.startY},
            {x: drawing.controlPoint.x, y: drawing.controlPoint.y},
            {x: drawing.endX, y: drawing.endY}
          ];
          drawingMinX = Math.min(...points.map(p => p.x)) - 5;
          drawingMinY = Math.min(...points.map(p => p.y)) - 5;
          drawingMaxX = Math.max(...points.map(p => p.x)) + 5;
          drawingMaxY = Math.max(...points.map(p => p.y)) + 5;
        } else if (curveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
          const points = [
            {x: drawing.startX, y: drawing.startY},
            ...drawing.controlPoints,
            {x: drawing.endX, y: drawing.endY}
          ];
          drawingMinX = Math.min(...points.map(p => p.x)) - 5;
          drawingMinY = Math.min(...points.map(p => p.y)) - 5;
          drawingMaxX = Math.max(...points.map(p => p.x)) + 5;
          drawingMaxY = Math.max(...points.map(p => p.y)) + 5;
        } else {
          drawingMinX = Math.min(drawing.startX, drawing.endX) - 5;
          drawingMinY = Math.min(drawing.startY, drawing.endY) - 5;
          drawingMaxX = Math.max(drawing.startX, drawing.endX) + 5;
          drawingMaxY = Math.max(drawing.startY, drawing.endY) + 5;
        }
        break;
      case 'circle':
        const radius = Math.sqrt(
          Math.pow(drawing.endX - drawing.startX, 2) +
          Math.pow(drawing.endY - drawing.startY, 2)
        );
        drawingMinX = drawing.startX - radius - 5;
        drawingMinY = drawing.startY - radius - 5;
        drawingMaxX = drawing.startX + radius + 5;
        drawingMaxY = drawing.startY + radius + 5;
        break;
      case 'text':
        this.ctx.font = `${drawing.fontSize || 16}px sans-serif`;
        const metrics = this.ctx.measureText(drawing.text);
        drawingMinX = drawing.x - 5;
        drawingMinY = drawing.y - (drawing.fontSize || 16) - 5;
        drawingMaxX = drawing.x + metrics.width + 5;
        drawingMaxY = drawing.y + 5;
        break;
      case 'image':
        const imgWidth = drawing.width || drawing.originalWidth || 100;
        const imgHeight = drawing.height || drawing.originalHeight || 100;
        drawingMinX = drawing.x - 5;
        drawingMinY = drawing.y - 5;
        drawingMaxX = drawing.x + imgWidth + 5;
        drawingMaxY = drawing.y + imgHeight + 5;
        break;
      case 'ball':
        // Normalize ball bounds first to ensure it's square
        this.normalizeBallBounds(drawing);
        // Ball is round (width = height)
        const ballLeft = Math.min(drawing.startX, drawing.endX);
        const ballTop = Math.min(drawing.startY, drawing.endY);
        const ballRight = Math.max(drawing.startX, drawing.endX);
        const ballBottom = Math.max(drawing.startY, drawing.endY);
        drawingMinX = ballLeft - 5;
        drawingMinY = ballTop - 5;
        drawingMaxX = ballRight + 5;
        drawingMaxY = ballBottom + 5;
        break;
      case 'tshirt':
        // T-shirt maintains 3:4 aspect ratio (width:height)
        const tshirtLeft = Math.min(drawing.startX, drawing.endX);
        const tshirtTop = Math.min(drawing.startY, drawing.endY);
        const tshirtWidth = Math.abs(drawing.endX - drawing.startX);
        const tshirtHeight = Math.abs(drawing.endY - drawing.startY);
        drawingMinX = tshirtLeft - 5;
        drawingMinY = tshirtTop - 5;
        drawingMaxX = tshirtLeft + tshirtWidth + 5;
        drawingMaxY = tshirtTop + tshirtHeight + 5;
        
        // Include surname in hit detection area
        if (drawing.surname) {
          const surnameHeight = Math.max(tshirtHeight * 0.15, 10);
          drawingMaxY += surnameHeight + 8;
        }
        break;
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          drawingMinX = Math.min(...drawing.points.map(p => p.x)) - 5;
          drawingMinY = Math.min(...drawing.points.map(p => p.y)) - 5;
          drawingMaxX = Math.max(...drawing.points.map(p => p.x)) + 5;
          drawingMaxY = Math.max(...drawing.points.map(p => p.y)) + 5;
        } else {
          return false;
        }
        break;
      case 'spray':
        if (drawing.particles && drawing.particles.length > 0) {
          const particleSize = drawing.particleSize || this.sprayParticleSize;
          drawingMinX = Math.min(...drawing.particles.map(p => p.x)) - particleSize;
          drawingMinY = Math.min(...drawing.particles.map(p => p.y)) - particleSize;
          drawingMaxX = Math.max(...drawing.particles.map(p => p.x)) + particleSize;
          drawingMaxY = Math.max(...drawing.particles.map(p => p.y)) + particleSize;
        } else {
          return false;
        }
        break;
      case 'heatmap':
        if (drawing.heatGrid && drawing.heatGrid.size > 0) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          let minGridX = Infinity, minGridY = Infinity, maxGridX = -Infinity, maxGridY = -Infinity;
          drawing.heatGrid.forEach((intensity, gridKey) => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            minGridX = Math.min(minGridX, gridX);
            minGridY = Math.min(minGridY, gridY);
            maxGridX = Math.max(maxGridX, gridX);
            maxGridY = Math.max(maxGridY, gridY);
          });
          drawingMinX = minGridX * gridSize;
          drawingMinY = minGridY * gridSize;
          drawingMaxX = (maxGridX + 1) * gridSize;
          drawingMaxY = (maxGridY + 1) * gridSize;
        } else {
          return false;
        }
        break;
      case 'freehand':
        if (drawing.points && drawing.points.length > 0) {
          drawingMinX = Math.min(...drawing.points.map(p => p.x)) - 5;
          drawingMinY = Math.min(...drawing.points.map(p => p.y)) - 5;
          drawingMaxX = Math.max(...drawing.points.map(p => p.x)) + 5;
          drawingMaxY = Math.max(...drawing.points.map(p => p.y)) + 5;
        } else {
          return false;
        }
        break;
      case 'arc':
        const arcRadius = Math.sqrt(
          Math.pow(drawing.endX - drawing.startX, 2) +
          Math.pow(drawing.endY - drawing.startY, 2)
        );
        drawingMinX = drawing.startX - arcRadius - 5;
        drawingMinY = drawing.startY - arcRadius - 5;
        drawingMaxX = drawing.startX + arcRadius + 5;
        drawingMaxY = drawing.startY + arcRadius + 5;
        break;
      case 'rectangle':
      case 'triangle':
      case 'oval':
        const shapeLeft = Math.min(drawing.startX, drawing.endX);
        const shapeTop = Math.min(drawing.startY, drawing.endY);
        const shapeWidth = Math.abs(drawing.endX - drawing.startX);
        const shapeHeight = Math.abs(drawing.endY - drawing.startY);
        drawingMinX = shapeLeft - 5;
        drawingMinY = shapeTop - 5;
        drawingMaxX = shapeLeft + shapeWidth + 5;
        drawingMaxY = shapeTop + shapeHeight + 5;
        break;
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - use bounding box
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        drawingMinX = svgLeft - 5;
        drawingMinY = svgTop - 5;
        drawingMaxX = svgLeft + svgWidth + 5;
        drawingMaxY = svgTop + svgHeight + 5;
        break;
      case 'animpath':
        // Animation paths - use line bounds
        drawingMinX = Math.min(drawing.startX, drawing.endX) - 5;
        drawingMinY = Math.min(drawing.startY, drawing.endY) - 5;
        drawingMaxX = Math.max(drawing.startX, drawing.endX) + 5;
        drawingMaxY = Math.max(drawing.startY, drawing.endY) + 5;
        break;
      default:
        return false;
    }

    // Check if the drawing's bounding box intersects with the selection rectangle
    return !(drawingMaxX < rectMinX || drawingMinX > rectMaxX ||
             drawingMaxY < rectMinY || drawingMinY > rectMaxY);
  }

  getDrawingCenter(drawing) {
    switch (drawing.type) {
      case 'line':
      case 'arrow':
      case 'cross':
        return {
          x: (drawing.startX + drawing.endX) / 2,
          y: (drawing.startY + drawing.endY) / 2
        };
      case 'circle':
        const circleLeft = Math.min(drawing.startX, drawing.endX);
        const circleTop = Math.min(drawing.startY, drawing.endY);
        const circleWidth = Math.abs(drawing.endX - drawing.startX);
        const circleHeight = Math.abs(drawing.endY - drawing.startY);
        return {
          x: circleLeft + circleWidth / 2,
          y: circleTop + circleHeight / 2
        };
      case 'oval':
        const ovalLeft = Math.min(drawing.startX, drawing.endX);
        const ovalTop = Math.min(drawing.startY, drawing.endY);
        const ovalWidth = Math.abs(drawing.endX - drawing.startX);
        const ovalHeight = Math.abs(drawing.endY - drawing.startY);
        return {
          x: ovalLeft + ovalWidth / 2,
          y: ovalTop + ovalHeight / 2
        };
      case 'text':
        this.ctx.font = `${drawing.fontSize || 16}px sans-serif`;
        const metrics = this.ctx.measureText(drawing.text);
        return {
          x: drawing.x + metrics.width / 2,
          y: drawing.y - (drawing.fontSize || 16) / 2
        };
      case 'image':
        const imgWidth = drawing.width || drawing.originalWidth || 100;
        const imgHeight = drawing.height || drawing.originalHeight || 100;
        return {
          x: drawing.x + imgWidth / 2,
          y: drawing.y + imgHeight / 2
        };
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - return center of bounding box
        const svgLeft = Math.min(drawing.startX, drawing.endX);
        const svgTop = Math.min(drawing.startY, drawing.endY);
        const svgWidth = Math.abs(drawing.endX - drawing.startX);
        const svgHeight = Math.abs(drawing.endY - drawing.startY);
        return {
          x: svgLeft + svgWidth / 2,
          y: svgTop + svgHeight / 2
        };
      case 'polygon':
        if (drawing.points && drawing.points.length > 0) {
          const sum = drawing.points.reduce((acc, p) => ({ x: acc.x + p.x, y: acc.y + p.y }), { x: 0, y: 0 });
          return { x: sum.x / drawing.points.length, y: sum.y / drawing.points.length };
        }
        return { x: 0, y: 0 };
      case 'freehand':
        if (drawing.points && drawing.points.length > 0) {
          const sum = drawing.points.reduce((acc, p) => ({ x: acc.x + p.x, y: acc.y + p.y }), { x: 0, y: 0 });
          return { x: sum.x / drawing.points.length, y: sum.y / drawing.points.length };
        }
        return { x: 0, y: 0 };
      case 'spray':
        if (drawing.particles && drawing.particles.length > 0) {
          const sum = drawing.particles.reduce((acc, p) => ({ x: acc.x + p.x, y: acc.y + p.y }), { x: 0, y: 0 });
          return { x: sum.x / drawing.particles.length, y: sum.y / drawing.particles.length };
        }
        return { x: 0, y: 0 };
      case 'heatmap':
        if (drawing.heatGrid && Object.keys(drawing.heatGrid).length > 0) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          let sumX = 0, sumY = 0, count = 0;
          Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            const pixelX = gridX * gridSize + gridSize / 2;
            const pixelY = gridY * gridSize + gridSize / 2;
            sumX += pixelX;
            sumY += pixelY;
            count++;
          });
          return count > 0 ? { x: sumX / count, y: sumY / count } : { x: 0, y: 0 };
        }
        return { x: 0, y: 0 };
      case 'arc':
        const arcLeft = Math.min(drawing.startX, drawing.endX);
        const arcTop = Math.min(drawing.startY, drawing.endY);
        const arcWidth = Math.abs(drawing.endX - drawing.startX);
        const arcHeight = Math.abs(drawing.endY - drawing.startY);
        return {
          x: arcLeft + arcWidth / 2,
          y: arcTop + arcHeight / 2
        };
      default:
        return { x: 0, y: 0 };
    }
  }

  moveDrawing(drawing, deltaX, deltaY) {
    switch (drawing.type) {
      case 'line':
      case 'arrow':
      case 'cross':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        break;
      case 'circle':
      case 'oval':
      case 'arc':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        break;
      case 'triangle':
      case 'rectangle':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        break;
      case 'text':
        drawing.x += deltaX;
        drawing.y += deltaY;
        break;
      case 'image':
        drawing.x += deltaX;
        drawing.y += deltaY;
        break;
      case 'barrier':
      case 'biggoal':
      case 'ladder':
      case 'stick':
        // SVG elements - move by updating bounds
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        break;
      case 'ball':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        // Normalize to ensure perfect square after moving
        this.normalizeBallBounds(drawing);
        // Update linked animation paths
        this.updateLinkedAnimPaths(drawing, deltaX, deltaY);
        break;
      case 'animpath':
        // Animation paths should NOT be moved directly - they are linked to objects
        // The start point is fixed to the object, only end point can be changed via resize handle
        // Do nothing here - don't allow moving animpath
        break;
      case 'tshirt':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        // Update linked animation paths
        this.updateLinkedAnimPaths(drawing, deltaX, deltaY);
        break;
      case 'polygon':
        if (drawing.points) {
          drawing.points.forEach(p => {
            p.x += deltaX;
            p.y += deltaY;
          });
        }
        break;
      case 'freehand':
        if (drawing.points) {
          drawing.points.forEach(p => {
            p.x += deltaX;
            p.y += deltaY;
          });
        }
        break;
      case 'spray':
        if (drawing.particles) {
          drawing.particles.forEach(p => {
            p.x += deltaX;
            p.y += deltaY;
          });
        }
        break;
      case 'heatmap':
        if (drawing.heatGrid) {
          const gridSize = drawing.gridSize || this.heatmapGridSize;
          const newHeatGrid = {};
          Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
            const [gridX, gridY] = gridKey.split(',').map(Number);
            const oldPixelX = gridX * gridSize;
            const oldPixelY = gridY * gridSize;
            const newPixelX = oldPixelX + deltaX;
            const newPixelY = oldPixelY + deltaY;
            const newGridX = Math.floor(newPixelX / gridSize);
            const newGridY = Math.floor(newPixelY / gridSize);
            const newGridKey = `${newGridX},${newGridY}`;
            newHeatGrid[newGridKey] = intensity;
          });
          drawing.heatGrid = newHeatGrid;
        }
        break;
      case 'curve':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        if (drawing.controlPoint) {
          drawing.controlPoint.x += deltaX;
          drawing.controlPoint.y += deltaY;
        }
        if (drawing.controlPoints) {
          drawing.controlPoints.forEach(cp => {
            cp.x += deltaX;
            cp.y += deltaY;
          });
        }
        break;
      case 'arc':
        drawing.startX += deltaX;
        drawing.startY += deltaY;
        drawing.endX += deltaX;
        drawing.endY += deltaY;
        break;
    }
  }

  deleteSelectedDrawing() {
    if (this.selectedDrawings.length > 0) {
      // Sort in descending order to avoid index shifting issues
      const sortedIndices = [...this.selectedDrawings].sort((a, b) => b - a);
      sortedIndices.forEach(index => {
        const drawingToDelete = this.drawings[index];
        
        // If deleting an animation path (movement line), reset the target object to starting position
        if (drawingToDelete && drawingToDelete.type === 'animpath' && drawingToDelete.targetIndex !== undefined && drawingToDelete.targetIndex !== null) {
          const targetIndex = drawingToDelete.targetIndex;
          const targetDrawing = this.drawings[targetIndex];
          
          if (targetDrawing && ['ball', 'tshirt'].includes(targetDrawing.type)) {
            // Get the object's current size
            const width = targetDrawing.endX - targetDrawing.startX;
            const height = targetDrawing.endY - targetDrawing.startY;
            
            // Reset object to starting position (at the start of the animation path)
            targetDrawing.startX = drawingToDelete.startX - width / 2;
            targetDrawing.startY = drawingToDelete.startY - height / 2;
            targetDrawing.endX = drawingToDelete.startX + width / 2;
            targetDrawing.endY = drawingToDelete.startY + height / 2;
          }
        }
        
        this.drawings.splice(index, 1);
      });
      
      // Update animation path references after deletion (indices shift)
      this.drawings.forEach((drawing) => {
        if (drawing.type === 'animpath' && drawing.targetIndex !== undefined && drawing.targetIndex !== null) {
          // Check if the target itself was deleted
          if (sortedIndices.includes(drawing.targetIndex)) {
            // Target was deleted, clear the reference
            drawing.targetIndex = undefined;
          } else {
            // Count how many deleted indices were before this targetIndex
            let shift = 0;
            sortedIndices.forEach(deletedIndex => {
              if (deletedIndex < drawing.targetIndex) {
                shift++;
              }
            });
            drawing.targetIndex = drawing.targetIndex - shift;
            
            // If targetIndex is now out of bounds, clear it
            if (drawing.targetIndex < 0 || drawing.targetIndex >= this.drawings.length) {
              drawing.targetIndex = undefined;
            }
          }
        }
      });
      
      // Update animation path references to find new targets if needed
      this.updateAnimPathReferences();
      
      this.selectedDrawings = [];
      // Hide style control when all drawings are deleted
      const styleToolbar = document.getElementById('editorStyleToolbar');
      const fontSizeControl = document.getElementById('editorFontSizeControl');
      if (styleToolbar) {
        styleToolbar.classList.add('hidden');
      }
      if (fontSizeControl) {
        fontSizeControl.classList.add('hidden');
      }
      this.saveState();
      this.redraw();
    }
  }

  copy() {
    if (this.selectedDrawings.length === 0) return;
    
    // Deep copy selected drawings to clipboard
    // Filter out any invalid indices or undefined drawings
    this.clipboard = this.selectedDrawings
      .map(index => {
        // Validate index is within bounds
        if (index < 0 || index >= this.drawings.length) {
          console.warn('Copy: Invalid drawing index:', index, 'drawings array length:', this.drawings.length);
          return null;
        }
        
        const drawing = this.drawings[index];
        
        // Validate drawing exists and has required properties
        if (!drawing) {
          console.warn('Copy: Drawing is null/undefined at index', index);
          return null;
        }
        
        if (!drawing.type) {
          console.warn('Copy: Drawing missing type at index', index, drawing);
          return null;
        }
        
        // Ensure drawing has basic coordinate properties for non-text shapes
        if (drawing.type !== 'text' && drawing.type !== 'freehand' && drawing.type !== 'spray' && drawing.type !== 'polygon') {
          if (drawing.startX === undefined && drawing.startY === undefined && 
              drawing.endX === undefined && drawing.endY === undefined &&
              (!drawing.points || drawing.points.length === 0)) {
            console.warn('Copy: Drawing missing coordinates at index', index, drawing);
            return null;
          }
        }
        
        try {
          const copied = JSON.parse(JSON.stringify(drawing));
          // Log SVG-related properties for debugging
          if (['barrier', 'biggoal', 'ladder', 'stick'].includes(drawing.type)) {
            console.log('Copy: SVG drawing', drawing.type, {
              hasSvgUrl: !!copied.svgUrl,
              svgUrl: copied.svgUrl,
              hasSvgElement: !!drawing.svgElement, // Original has it, but copied won't
              hasStartX: copied.startX !== undefined,
              hasEndX: copied.endX !== undefined
            });
          }
          return copied;
        } catch (error) {
          console.error('Copy: Failed to serialize drawing at index', index, error, drawing);
          return null;
        }
      })
      .filter(drawing => drawing !== null);
    
    console.log('Copy: Clipboard now has', this.clipboard.length, 'drawings');
    
    // Update paste button state
    this.updateButtonStates();
  }

  paste() {
    if (this.clipboard.length === 0) return;
    
    // Calculate offset to place pasted drawings slightly offset from originals
    const offsetX = 20;
    const offsetY = 20;
    
    // Find the bounding box of the clipboard drawings to center the offset
    let minX = Infinity, minY = Infinity;
    this.clipboard.forEach(drawing => {
      if (drawing.type === 'text') {
        minX = Math.min(minX, drawing.x || 0);
        minY = Math.min(minY, drawing.y || 0);
      } else if (drawing.points && drawing.points.length > 0) {
        // Polygon or freehand
        drawing.points.forEach(p => {
          minX = Math.min(minX, p.x);
          minY = Math.min(minY, p.y);
        });
      } else {
        minX = Math.min(minX, drawing.startX || 0, drawing.endX || 0);
        minY = Math.min(minY, drawing.startY || 0, drawing.endY || 0);
      }
    });
    
    // Paste each drawing with offset
    const newIndices = [];
    const svgElements = ['barrier', 'biggoal', 'ladder', 'stick'];
    const svgMap = {
      'barrier': 'Barrier.svg',
      'biggoal': 'Big goal.svg',
      'ladder': 'Ladder.svg',
      'stick': 'Stick.svg'
    };
    
    this.clipboard.forEach(drawing => {
      // Use the drawing from clipboard directly (it's already a deep copy from copy())
      const copiedDrawing = JSON.parse(JSON.stringify(drawing));
      
      // For SVG elements, ensure svgUrl is set before processing
      if (svgElements.includes(copiedDrawing.type)) {
        if (!copiedDrawing.svgUrl && svgMap[copiedDrawing.type]) {
          copiedDrawing.svgUrl = chrome.runtime.getURL(`icons/${svgMap[copiedDrawing.type]}`);
          console.log('Paste: Set svgUrl for', copiedDrawing.type, ':', copiedDrawing.svgUrl);
        }
        // Try to use cached SVG first, otherwise it will be loaded async
        if (this.svgCache[copiedDrawing.type]) {
          copiedDrawing.svgElement = this.svgCache[copiedDrawing.type];
          console.log('Paste: Using cached SVG for', copiedDrawing.type);
        } else {
        // Clear svgElement as it won't be valid after serialization
        copiedDrawing.svgElement = null;
        }
      }
      
      // Apply offset based on drawing type
      if (copiedDrawing.type === 'text') {
        copiedDrawing.x = (copiedDrawing.x || 0) - minX + offsetX;
        copiedDrawing.y = (copiedDrawing.y || 0) - minY + offsetY;
      } else if (copiedDrawing.points && copiedDrawing.points.length > 0) {
        // Polygon or freehand - offset all points
        copiedDrawing.points = copiedDrawing.points.map(p => ({
          x: p.x - minX + offsetX,
          y: p.y - minY + offsetY
        }));
      } else {
        // Regular shapes - offset start and end coordinates
        copiedDrawing.startX = (copiedDrawing.startX || 0) - minX + offsetX;
        copiedDrawing.startY = (copiedDrawing.startY || 0) - minY + offsetY;
        copiedDrawing.endX = (copiedDrawing.endX || 0) - minX + offsetX;
        copiedDrawing.endY = (copiedDrawing.endY || 0) - minY + offsetY;
      }
      
      // Offset curve control points if present
      if (copiedDrawing.controlPoint) {
        copiedDrawing.controlPoint.x = copiedDrawing.controlPoint.x - minX + offsetX;
        copiedDrawing.controlPoint.y = copiedDrawing.controlPoint.y - minY + offsetY;
      }
      if (copiedDrawing.controlPoints && copiedDrawing.controlPoints.length > 0) {
        copiedDrawing.controlPoints = copiedDrawing.controlPoints.map(cp => ({
          x: cp.x - minX + offsetX,
          y: cp.y - minY + offsetY
        }));
      }
      
      this.drawings.push(copiedDrawing);
      newIndices.push(this.drawings.length - 1);
    });
    
    // Reload SVG elements for pasted drawings that need them
    // This is necessary because svgElement (Image object) doesn't serialize with JSON
    const svgLoadPromises = [];
    
    newIndices.forEach(index => {
      const drawing = this.drawings[index];
      if (!drawing) {
        console.warn('Paste: Drawing is null at index', index);
        return;
      }
      
      if (svgElements.includes(drawing.type)) {
        // svgUrl should already be set from above, but double-check
        if (!drawing.svgUrl && svgMap[drawing.type]) {
          drawing.svgUrl = chrome.runtime.getURL(`icons/${svgMap[drawing.type]}`);
          console.log('Paste: Reconstructed svgUrl for', drawing.type, ':', drawing.svgUrl);
        }
        
        // If already has svgElement from cache, skip loading
        if (drawing.svgElement && drawing.svgElement.complete && drawing.svgElement.naturalWidth > 0) {
          console.log('Paste: SVG already loaded for', drawing.type, '(from cache)');
          return;
        }
        
        // Try cache again in case it was loaded after initial paste setup
        if (this.svgCache[drawing.type]) {
          drawing.svgElement = this.svgCache[drawing.type];
          console.log('Paste: Using cached SVG for', drawing.type, 'at index', index);
          return;
        }
        
        // Only load if not in cache
        if (drawing.svgUrl) {
          console.log('Paste: Loading SVG for', drawing.type, 'from URL:', drawing.svgUrl);
          const loadPromise = this.loadSvgElement(drawing.svgUrl).then(img => {
            if (!img) {
              console.error('Paste: loadSvgElement returned null for', drawing.type);
              return;
            }
            drawing.svgElement = img;
            this.svgCache[drawing.type] = img; // Cache for future use
            console.log('Paste: Successfully loaded SVG for', drawing.type, 'at index', index, 'img.complete:', img.complete, 'img.naturalWidth:', img.naturalWidth);
            // Redraw after each SVG loads to show progress
            this.redraw();
          }).catch(err => {
            console.error('Paste: Failed to reload SVG for', drawing.type, ':', err, 'URL:', drawing.svgUrl);
            // Draw placeholder on error
            this.redraw();
          });
          svgLoadPromises.push(loadPromise);
        } else {
          console.error('Paste: No svgUrl for', drawing.type, 'at index', index, 'drawing:', drawing);
        }
      }
    });
    
    // Wait for all SVG elements to load before final redraw
    Promise.all(svgLoadPromises).then(() => {
      console.log('Paste: All SVG elements loaded, performing final redraw');
      // Select the newly pasted drawings
      this.selectedDrawings = newIndices;
      this.saveState();
      this.updateButtonStates();
      this.redraw();
    }).catch((err) => {
      console.error('Paste: One or more SVGs failed to load:', err);
      // Even if some SVGs fail to load, still update UI
      this.selectedDrawings = newIndices;
      this.saveState();
      this.updateButtonStates();
      this.redraw();
    });
    
    // If no SVG elements to load, update immediately
    if (svgLoadPromises.length === 0) {
      console.log('Paste: No SVG elements to load, updating immediately');
      this.selectedDrawings = newIndices;
      this.saveState();
      this.updateButtonStates();
      this.redraw();
    } else {
      // Draw non-SVG elements immediately while SVGs load
      console.log('Paste: Drawing non-SVG elements immediately, waiting for', svgLoadPromises.length, 'SVGs to load');
      this.redraw();
    }
  }

  updateButtonStates() {
    // Update copy button state based on selection
    const copyBtn = document.getElementById('editorCopyBtn');
    if (copyBtn) {
      const hasSelection = this.selectedDrawings.length > 0 && this.currentTool === 'select';
      copyBtn.disabled = !hasSelection;
      copyBtn.style.opacity = hasSelection ? '1' : '0.5';
      copyBtn.style.cursor = hasSelection ? 'pointer' : 'not-allowed';
    }
    
    // Update paste button state based on clipboard
    const pasteBtn = document.getElementById('editorPasteBtn');
    if (pasteBtn) {
      pasteBtn.disabled = this.clipboard.length === 0;
      pasteBtn.style.opacity = this.clipboard.length === 0 ? '0.5' : '1';
      pasteBtn.style.cursor = this.clipboard.length === 0 ? 'not-allowed' : 'pointer';
    }
    
    // Update zone overlay button state
    const zoneOverlayBtn = document.getElementById('editorZoneOverlayBtn');
    if (zoneOverlayBtn) {
      zoneOverlayBtn.classList.toggle('active', this.showZoneOverlay);
    }
  }

  createTextInput(canvasX, canvasY, mouseEvent) {
    // Remove existing text input
    if (this.textInput) {
      this.textInput.remove();
      this.textInput = null;
    }

    console.log('Creating text input at canvas coords:', canvasX, canvasY);

    // Get the canvas and container rectangles
    const canvasRect = this.canvas.getBoundingClientRect();
    const container = this.canvas.parentElement;
    const containerRect = container.getBoundingClientRect();
    
    // Convert canvas coordinates to screen coordinates within the container
    const scaleX = canvasRect.width / this.canvas.width;
    const scaleY = canvasRect.height / this.canvas.height;
    
    // Calculate position relative to canvas
    const screenXOnCanvas = canvasX * scaleX;
    const screenYOnCanvas = canvasY * scaleY;
    
    // Calculate canvas offset within container (accounting for centering)
    const canvasOffsetX = canvasRect.left - containerRect.left;
    const canvasOffsetY = canvasRect.top - containerRect.top;
    
    // Final position relative to container
    const screenX = screenXOnCanvas + canvasOffsetX;
    const screenY = screenYOnCanvas + canvasOffsetY;
    
    console.log('Screen position relative to container:', screenX, screenY);

    // Create a simple text input
    const textInput = document.createElement('input');
    textInput.type = 'text';
    textInput.id = 'tactical-editor-text-input';
    textInput.name = 'text-input';
    textInput.value = '';
    textInput.placeholder = 'Type text and press Enter...';
    textInput.style.cssText = `
      position: absolute;
      left: ${screenX}px;
      top: ${screenY}px;
      z-index: 10000;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      border: 2px solid #1f6feb;
      padding: 8px 12px;
      font-size: 16px;
      font-family: Arial, sans-serif;
      outline: none;
      min-width: 200px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;

    console.log('Text input created with screen coordinates');

    // Append to the canvas container (not body) for proper positioning
    console.log('Canvas container:', container);
    if (container.style.position !== 'relative') {
      container.style.position = 'relative';
    }
    container.appendChild(textInput);
    console.log('Text input appended to DOM');

    // Use requestAnimationFrame to ensure focus happens after DOM update
    requestAnimationFrame(() => {
      textInput.focus();
      textInput.select(); // Select all text for easy replacement
      console.log('Text input focused and selected');
    });

    const finishText = () => {
      const text = textInput.value.trim();
      if (text) {
        // Add text to drawings - use current color
        this.drawings.push({
          type: 'text',
          color: this.currentColor,
          opacity: this.opacity,
          x: canvasX,
          y: canvasY,
          text: text,
          fontSize: 16,
          fontWeight: this.fontWeight, // Use current font weight setting
          highlightEnabled: this.highlightEnabled,
          highlightThickness: this.highlightThickness,
          highlightStyle: this.highlightStyle,
          eventName: this.eventName || ''
        });
        this.saveState();
        
        // Automatically switch to select tool and select the newly created text
        const newDrawingIndex = this.drawings.length - 1;
        this.selectTool('select');
        this.selectedDrawings = [newDrawingIndex];
        this.updateSelectionControls();
        this.redraw();
      }

      // Clean up
      if (textInput.parentNode) {
        textInput.remove();
      }
      this.textInput = null;
    };

    const cancelText = () => {
      if (textInput.parentNode) {
        textInput.remove();
      }
      this.textInput = null;
    };

    // Event listeners
    textInput.addEventListener('keydown', (e) => {
      e.stopPropagation(); // Prevent event from reaching canvas
      if (e.key === 'Enter') {
        e.preventDefault();
        finishText();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        cancelText();
      }
    });

    textInput.addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent clicks from reaching canvas
    });

    textInput.addEventListener('mousedown', (e) => {
      e.stopPropagation(); // Prevent mousedown from reaching canvas
    });

    textInput.addEventListener('blur', () => {
      // Small delay to allow clicking on other elements
      setTimeout(() => {
        if (textInput.parentNode) {
          finishText();
        }
      }, 100);
    });

    this.textInput = textInput;
  }

  editText(drawingIndex, mouseEvent) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing || drawing.type !== 'text') return;

    // Remove existing text input
    if (this.textInput) {
      this.textInput.remove();
      this.textInput = null;
    }

    console.log('Editing text at index:', drawingIndex);

    // Get the canvas and container rectangles
    const canvasRect = this.canvas.getBoundingClientRect();
    const container = this.canvas.parentElement;
    const containerRect = container.getBoundingClientRect();
    
    // Convert canvas coordinates to screen coordinates within the container
    const scaleX = canvasRect.width / this.canvas.width;
    const scaleY = canvasRect.height / this.canvas.height;
    
    // Calculate position relative to canvas
    const screenXOnCanvas = drawing.x * scaleX;
    const screenYOnCanvas = drawing.y * scaleY;
    
    // Calculate canvas offset within container (accounting for centering)
    const canvasOffsetX = canvasRect.left - containerRect.left;
    const canvasOffsetY = canvasRect.top - containerRect.top;
    
    // Final position relative to container
    const screenX = screenXOnCanvas + canvasOffsetX;
    const screenY = screenYOnCanvas + canvasOffsetY;
    
    console.log('Screen position relative to container:', screenX, screenY);

    // Create a simple text input
    const textInput = document.createElement('input');
    textInput.type = 'text';
    textInput.id = 'tactical-editor-text-input';
    textInput.name = 'text-input';
    textInput.value = drawing.text || '';
    textInput.placeholder = 'Type text and press Enter...';
    textInput.style.cssText = `
      position: absolute;
      left: ${screenX}px;
      top: ${screenY}px;
      z-index: 10000;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      border: 2px solid #1f6feb;
      padding: 8px 12px;
      font-size: 16px;
      font-family: Arial, sans-serif;
      outline: none;
      min-width: 200px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;

    console.log('Text input created for editing');

    // Append to the canvas container (not body) for proper positioning
    if (container.style.position !== 'relative') {
      container.style.position = 'relative';
    }
    container.appendChild(textInput);

    // Use requestAnimationFrame to ensure focus happens after DOM update
    requestAnimationFrame(() => {
      textInput.focus();
      textInput.select(); // Select all text for easy replacement
      console.log('Text input focused and selected');
    });

    const finishText = () => {
      const text = textInput.value.trim();
      if (text) {
        // Update the existing text drawing
        drawing.text = text;
        this.saveState();
        this.redraw();
      } else {
        // If text is empty, remove the drawing
        this.drawings.splice(drawingIndex, 1);
        this.saveState();
        this.redraw();
      }

      // Clean up
      if (textInput.parentNode) {
        textInput.remove();
      }
      this.textInput = null;
    };

    const cancelText = () => {
      if (textInput.parentNode) {
        textInput.remove();
      }
      this.textInput = null;
    };

    // Event listeners
    textInput.addEventListener('keydown', (e) => {
      e.stopPropagation(); // Prevent event from reaching canvas
      if (e.key === 'Enter') {
        e.preventDefault();
        finishText();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        cancelText();
      }
    });

    textInput.addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent clicks from reaching canvas
    });

    textInput.addEventListener('mousedown', (e) => {
      e.stopPropagation(); // Prevent mousedown from reaching canvas
    });

    textInput.addEventListener('blur', () => {
      // Small delay to allow clicking on other elements
      setTimeout(() => {
        if (textInput.parentNode) {
          finishText();
        }
      }, 100);
    });

    this.textInput = textInput;
  }

  // Drawing methods
  drawLine(drawing) {
    this.ctx.beginPath();
    this.ctx.moveTo(drawing.startX, drawing.startY);
    this.ctx.lineTo(drawing.endX, drawing.endY);
    this.ctx.stroke();
    
    // Draw endpoints
    const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
    const startCap = drawing.startCap || 'none';
    const endCap = drawing.endCap || 'none';
    this.drawEndpoint(drawing.startX, drawing.startY, angle, startCap, true);
    this.drawEndpoint(drawing.endX, drawing.endY, angle, endCap, false);
  }

  drawCurve(drawing) {
    const curveType = drawing.curveType || 'quadratic'; // Backward compatibility

    // Recalculate control points based on current curveIntensity if it exists
    if (drawing.curveIntensity !== undefined) {
      this.recalculateCurveControlPoints(drawing);
    }

    if (curveType === 'quadratic' && drawing.controlPoint) {
      this.ctx.beginPath();
      this.ctx.moveTo(drawing.startX, drawing.startY);
      this.ctx.quadraticCurveTo(drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY);
      this.ctx.stroke();
    } else if (curveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
      this.ctx.beginPath();
      this.ctx.moveTo(drawing.startX, drawing.startY);
      this.ctx.bezierCurveTo(
        drawing.controlPoints[0].x, drawing.controlPoints[0].y,
        drawing.controlPoints[1].x, drawing.controlPoints[1].y,
        drawing.endX, drawing.endY
      );
      this.ctx.stroke();
    } else {
      // Fallback to straight line
      this.drawLine(drawing);
      return; // drawLine already handles endpoints
    }
    
    // Draw endpoints for curves
    const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
    const startCap = drawing.startCap || 'none';
    const endCap = drawing.endCap || 'none';
    this.drawEndpoint(drawing.startX, drawing.startY, angle, startCap, true);
    this.drawEndpoint(drawing.endX, drawing.endY, angle, endCap, false);
  }

  recalculateCurveControlPoints(drawing) {
    const curveType = drawing.curveType || 'quadratic';
    const curveIntensity = drawing.curveIntensity || 1.0;
    const curveDirection = drawing.curveDirection || 'auto';

    const dx = drawing.endX - drawing.startX;
    const dy = drawing.endY - drawing.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist === 0) return;

    let directionMultiplier = 0;
    if (curveDirection === 'left') {
      directionMultiplier = 1;
    } else if (curveDirection === 'right') {
      directionMultiplier = -1;
    } else { // 'auto' - use current behavior
      directionMultiplier = 1;
    }

    if (curveType === 'quadratic') {
      const offset = Math.min(dist * 0.5 * curveIntensity, 100 * curveIntensity);
      const perpX = -dy / dist * offset * directionMultiplier;
      const perpY = dx / dist * offset * directionMultiplier;
      const midX = (drawing.startX + drawing.endX) / 2;
      const midY = (drawing.startY + drawing.endY) / 2;

      drawing.controlPoint = {
        x: midX + perpX,
        y: midY + perpY
      };
    } else if (curveType === 'cubic') {
      // First control point: perpendicular offset
      const offset1 = Math.min(dist * 0.4 * curveIntensity, 80 * curveIntensity);
      const perpX1 = -dy / dist * offset1 * directionMultiplier;
      const perpY1 = dx / dist * offset1 * directionMultiplier;

      // Second control point: opposite direction and different magnitude
      const offset2 = Math.min(dist * 0.6 * curveIntensity, 120 * curveIntensity);
      const perpX2 = dy / dist * offset2 * directionMultiplier;  // Opposite direction
      const perpY2 = -dx / dist * offset2 * directionMultiplier; // Opposite direction

      drawing.controlPoints = [
        {
          x: drawing.startX + (drawing.endX - drawing.startX) * 0.3 + perpX1,
          y: drawing.startY + (drawing.endY - drawing.startY) * 0.3 + perpY1
        },
        {
          x: drawing.startX + (drawing.endX - drawing.startX) * 0.7 + perpX2,
          y: drawing.startY + (drawing.endY - drawing.startY) * 0.7 + perpY2
        }
      ];
    }
  }

  drawEndpointOnContext(ctx, x, y, angle, style, isStart = false) {
    if (!style || style === 'none') return;
    
    const length = 12;
    const width = 8;
    const pointAngle = Math.PI / 6;
    
    // If it's the start point, reverse the angle
    const drawAngle = isStart ? angle + Math.PI : angle;
    
    ctx.save();
    
    switch (style) {
      case 'line':
        // Simple V-shaped arrow - draw as connected path for better appearance
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(
          x - length * Math.cos(drawAngle - pointAngle),
          y - length * Math.sin(drawAngle - pointAngle)
        );
        ctx.moveTo(x, y);
        ctx.lineTo(
          x - length * Math.cos(drawAngle + pointAngle),
          y - length * Math.sin(drawAngle + pointAngle)
        );
        // Connect the two sides at the base for a cleaner look
        ctx.lineTo(
          x - length * Math.cos(drawAngle - pointAngle),
          y - length * Math.sin(drawAngle - pointAngle)
        );
        ctx.stroke();
        break;
        
      case 'triangle':
        // Filled triangle arrow - tip at endpoint, base slightly back
        const arrowBaseDist = length * 0.9; // Distance from tip to base
        const baseX = x - arrowBaseDist * Math.cos(drawAngle);
        const baseY = y - arrowBaseDist * Math.sin(drawAngle);
        const baseWidth = length * 0.6; // Width of arrow base
        
        ctx.beginPath();
        ctx.moveTo(x, y); // Tip at endpoint
        ctx.lineTo(
          baseX - baseWidth * Math.sin(drawAngle),
          baseY + baseWidth * Math.cos(drawAngle)
        );
        ctx.lineTo(
          baseX + baseWidth * Math.sin(drawAngle),
          baseY - baseWidth * Math.cos(drawAngle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'reversed':
        const backOffset = length * 0.7;
        ctx.beginPath();
        ctx.moveTo(
          x - backOffset * Math.cos(drawAngle),
          y - backOffset * Math.sin(drawAngle)
        );
        ctx.lineTo(
          x - backOffset * Math.cos(drawAngle) + length * Math.cos(drawAngle - pointAngle),
          y - backOffset * Math.sin(drawAngle) + length * Math.sin(drawAngle - pointAngle)
        );
        ctx.lineTo(
          x - backOffset * Math.cos(drawAngle) + length * Math.cos(drawAngle + pointAngle),
          y - backOffset * Math.sin(drawAngle) + length * Math.sin(drawAngle + pointAngle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'circle':
        const circleRadius = width / 2;
        ctx.beginPath();
        ctx.arc(x, y, circleRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'diamond':
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(
          x - length * 0.5 * Math.cos(drawAngle) - width * 0.5 * Math.sin(drawAngle),
          y - length * 0.5 * Math.sin(drawAngle) + width * 0.5 * Math.cos(drawAngle)
        );
        ctx.lineTo(
          x - length * Math.cos(drawAngle),
          y - length * Math.sin(drawAngle)
        );
        ctx.lineTo(
          x - length * 0.5 * Math.cos(drawAngle) + width * 0.5 * Math.sin(drawAngle),
          y - length * 0.5 * Math.sin(drawAngle) - width * 0.5 * Math.cos(drawAngle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'perpendicular':
        // Perpendicular line at the endpoint
        const perpLength = length;
        // Perpendicular angle is 90 degrees (PI/2) from the line angle
        ctx.beginPath();
        ctx.moveTo(
          x - perpLength * Math.sin(angle),
          y + perpLength * Math.cos(angle)
        );
        ctx.lineTo(
          x + perpLength * Math.sin(angle),
          y - perpLength * Math.cos(angle)
        );
        ctx.stroke();
        break;
    }
    
    ctx.restore();
  }

  drawEndpoint(x, y, angle, style, isStart = false) {
    if (!style || style === 'none') return;
    
    const length = 12;
    const width = 8;
    const pointAngle = Math.PI / 6;
    
    // If it's the start point, reverse the angle
    const drawAngle = isStart ? angle + Math.PI : angle;
    
    this.ctx.save();
    
    switch (style) {
      case 'line':
        // Simple V-shaped arrow - draw as connected path for better appearance
        this.ctx.beginPath();
        this.ctx.moveTo(x, y);
        this.ctx.lineTo(
          x - length * Math.cos(drawAngle - pointAngle),
          y - length * Math.sin(drawAngle - pointAngle)
        );
        this.ctx.moveTo(x, y);
        this.ctx.lineTo(
          x - length * Math.cos(drawAngle + pointAngle),
          y - length * Math.sin(drawAngle + pointAngle)
        );
        // Connect the two sides at the base for a cleaner look
        this.ctx.lineTo(
          x - length * Math.cos(drawAngle - pointAngle),
          y - length * Math.sin(drawAngle - pointAngle)
        );
        this.ctx.stroke();
        break;
        
      case 'triangle':
        // Filled triangle arrow - tip at endpoint, base slightly back
        const arrowBaseDist = length * 0.9; // Distance from tip to base
        const baseX = x - arrowBaseDist * Math.cos(drawAngle);
        const baseY = y - arrowBaseDist * Math.sin(drawAngle);
        const baseWidth = length * 0.6; // Width of arrow base
        
        this.ctx.beginPath();
        this.ctx.moveTo(x, y); // Tip at endpoint
        this.ctx.lineTo(
          baseX - baseWidth * Math.sin(drawAngle),
          baseY + baseWidth * Math.cos(drawAngle)
        );
        this.ctx.lineTo(
          baseX + baseWidth * Math.sin(drawAngle),
          baseY - baseWidth * Math.cos(drawAngle)
        );
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.stroke();
        break;
        
      case 'reversed':
        // Reversed triangle (pointing backwards)
        const backOffset = length * 0.7;
        this.ctx.beginPath();
        this.ctx.moveTo(
          x - backOffset * Math.cos(drawAngle),
          y - backOffset * Math.sin(drawAngle)
        );
        this.ctx.lineTo(
          x - backOffset * Math.cos(drawAngle) + length * Math.cos(drawAngle - pointAngle),
          y - backOffset * Math.sin(drawAngle) + length * Math.sin(drawAngle - pointAngle)
        );
        this.ctx.lineTo(
          x - backOffset * Math.cos(drawAngle) + length * Math.cos(drawAngle + pointAngle),
          y - backOffset * Math.sin(drawAngle) + length * Math.sin(drawAngle + pointAngle)
        );
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.stroke();
        break;
        
      case 'circle':
        // Circle endpoint
        const circleRadius = width / 2;
        this.ctx.beginPath();
        this.ctx.arc(x, y, circleRadius, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.stroke();
        break;
        
      case 'diamond':
        // Diamond endpoint
        this.ctx.beginPath();
        // Tip of diamond
        this.ctx.moveTo(x, y);
        // Top point
        this.ctx.lineTo(
          x - length * 0.5 * Math.cos(drawAngle) - width * 0.5 * Math.sin(drawAngle),
          y - length * 0.5 * Math.sin(drawAngle) + width * 0.5 * Math.cos(drawAngle)
        );
        // Back point
        this.ctx.lineTo(
          x - length * Math.cos(drawAngle),
          y - length * Math.sin(drawAngle)
        );
        // Bottom point
        this.ctx.lineTo(
          x - length * 0.5 * Math.cos(drawAngle) + width * 0.5 * Math.sin(drawAngle),
          y - length * 0.5 * Math.sin(drawAngle) - width * 0.5 * Math.cos(drawAngle)
        );
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.stroke();
        break;
        
      case 'perpendicular':
        // Perpendicular line at the endpoint
        const perpLength = length;
        // Perpendicular angle is 90 degrees (PI/2) from the line angle
        this.ctx.beginPath();
        this.ctx.moveTo(
          x - perpLength * Math.sin(angle),
          y + perpLength * Math.cos(angle)
        );
        this.ctx.lineTo(
          x + perpLength * Math.sin(angle),
          y - perpLength * Math.cos(angle)
        );
        this.ctx.stroke();
        break;
    }
    
    this.ctx.restore();
  }

  drawArrow(drawing) {
    // Calculate angle
    const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
    
    // Get endpoint styles
    const startCap = drawing.startCap || 'none';
    const endCap = drawing.endCap || 'line';
    
    // Calculate line endpoints, accounting for arrowheads
    let lineStartX = drawing.startX;
    let lineStartY = drawing.startY;
    let lineEndX = drawing.endX;
    let lineEndY = drawing.endY;
    
    // If there's an end arrowhead, shorten the line to avoid overlap
    if (endCap !== 'none') {
      const arrowBaseOffset = 12; // Distance from endpoint to arrow base
      lineEndX = drawing.endX - arrowBaseOffset * Math.cos(angle);
      lineEndY = drawing.endY - arrowBaseOffset * Math.sin(angle);
    }
    
    // If there's a start arrowhead, shorten the line to avoid overlap
    if (startCap !== 'none') {
      const arrowBaseOffset = 12;
      lineStartX = drawing.startX + arrowBaseOffset * Math.cos(angle);
      lineStartY = drawing.startY + arrowBaseOffset * Math.sin(angle);
    }
    
    // Draw the main line
    this.ctx.beginPath();
    this.ctx.moveTo(lineStartX, lineStartY);
    this.ctx.lineTo(lineEndX, lineEndY);
    this.ctx.stroke();
    
    // Draw start endpoint
    this.drawEndpoint(drawing.startX, drawing.startY, angle, startCap, true);
    
    // Draw end endpoint
    this.drawEndpoint(drawing.endX, drawing.endY, angle, endCap, false);
  }

  drawArrowPreview(startX, startY, endX, endY) {
    // Calculate angle
    const angle = Math.atan2(endY - startY, endX - startX);
    
    // Get endpoint styles
    const startCap = this.startCap || 'none';
    const endCap = this.endCap || 'line';
    
    // Calculate line endpoints, accounting for arrowheads
    let lineStartX = startX;
    let lineStartY = startY;
    let lineEndX = endX;
    let lineEndY = endY;
    
    // If there's an end arrowhead, shorten the line to avoid overlap
    if (endCap !== 'none') {
      const arrowBaseOffset = 12; // Distance from endpoint to arrow base
      lineEndX = endX - arrowBaseOffset * Math.cos(angle);
      lineEndY = endY - arrowBaseOffset * Math.sin(angle);
    }
    
    // If there's a start arrowhead, shorten the line to avoid overlap
    if (startCap !== 'none') {
      const arrowBaseOffset = 12;
      lineStartX = startX + arrowBaseOffset * Math.cos(angle);
      lineStartY = startY + arrowBaseOffset * Math.sin(angle);
    }
    
    // Draw the main line
    this.ctx.beginPath();
    this.ctx.moveTo(lineStartX, lineStartY);
    this.ctx.lineTo(lineEndX, lineEndY);
    this.ctx.stroke();
    
    // Draw endpoints using current settings
    this.drawEndpoint(startX, startY, angle, startCap, true);
    this.drawEndpoint(endX, endY, angle, endCap, false);
  }

  drawCircle(drawing) {
    // Rectangle-based circle: startX/startY to endX/endY defines bounding box
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);

    // Use the larger dimension for radius to make it fit the rectangle
    const radius = Math.max(width, height) / 2;
    const centerX = left + width / 2;
    const centerY = top + height / 2;

    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    
    // Draw fill if specified (fill is independent of line style)
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      if (drawing.fillStyle === 'crosshatch') {
        this.drawCrosshatchFill(centerX, centerY, radius, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch (which clears the path)
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawOval(drawing) {
    // Rectangle-based oval: startX/startY to endX/endY defines bounding box
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);

    // Use separate radiusX and radiusY for oval (half of width and height)
    const radiusX = width / 2;
    const radiusY = height / 2;
    const centerX = left + width / 2;
    const centerY = top + height / 2;

    this.ctx.beginPath();
    this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
    
    // Draw fill if specified (fill is independent of line style)
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      if (drawing.fillStyle === 'crosshatch') {
        this.drawCrosshatchFillOval(centerX, centerY, radiusX, radiusY, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch (which clears the path)
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawArc(drawing) {
    // Rectangle-based arc: startX/startY to endX/endY defines bounding box
    const arcLeft = Math.min(drawing.startX, drawing.endX);
    const arcTop = Math.min(drawing.startY, drawing.endY);
    const arcWidth = Math.abs(drawing.endX - drawing.startX);
    const arcHeight = Math.abs(drawing.endY - drawing.startY);

    // Use the larger dimension for radius to make it fit the rectangle
    const radius = Math.max(arcWidth, arcHeight) / 2;
    const centerX = arcLeft + arcWidth / 2;
    const centerY = arcTop + arcHeight / 2;

    // Draw from 0 to PI (top half circle)
    const startAngle = 0;
    const endAngle = Math.PI;

    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    
    // Draw fill if specified (for arc, fill the semicircle area) - fill is independent of line style
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      // Close the path to create a fillable area
      this.ctx.lineTo(centerX - radius, centerY);
      this.ctx.closePath();
      
      if (drawing.fillStyle === 'crosshatch') {
        // For arc, we need to fill the semicircle area
        this.drawCrosshatchFillArc(centerX, centerY, radius, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch (which clears the path)
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawPolygon(drawing) {
    if (!drawing.points || drawing.points.length < 3) return;
    
    this.ctx.beginPath();
    this.ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
    for (let i = 1; i < drawing.points.length; i++) {
      this.ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
    }
    this.ctx.closePath();
    
    // Draw fill if specified - fill is independent of line style
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      if (drawing.fillStyle === 'crosshatch') {
        this.drawCrosshatchFillPolygon(drawing.points, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch (which clears the path)
        this.ctx.beginPath();
        this.ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
        for (let i = 1; i < drawing.points.length; i++) {
          this.ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
        }
        this.ctx.closePath();
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
        for (let i = 1; i < drawing.points.length; i++) {
          this.ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
        }
        this.ctx.closePath();
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawTriangle(drawing) {
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    
    this.ctx.beginPath();
    // Top point (center of top edge)
    this.ctx.moveTo(left + width / 2, top);
    // Bottom right point
    this.ctx.lineTo(left + width, top + height);
    // Bottom left point
    this.ctx.lineTo(left, top + height);
    // Close triangle
    this.ctx.closePath();
    
    // Draw fill if specified - fill is independent of line style
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      if (drawing.fillStyle === 'crosshatch') {
        const trianglePoints = [
          {x: left + width / 2, y: top},
          {x: left + width, y: top + height},
          {x: left, y: top + height}
        ];
        this.drawCrosshatchFillPolygon(trianglePoints, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch
        this.ctx.beginPath();
        this.ctx.moveTo(left + width / 2, top);
        this.ctx.lineTo(left + width, top + height);
        this.ctx.lineTo(left, top + height);
        this.ctx.closePath();
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.moveTo(left + width / 2, top);
        this.ctx.lineTo(left + width, top + height);
        this.ctx.lineTo(left, top + height);
        this.ctx.closePath();
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawRectangle(drawing) {
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    
    this.ctx.beginPath();
    this.ctx.rect(left, top, width, height);
    
    // Draw fill if specified - fill is independent of line style
    if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
      const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
      const fillColor = drawing.fillColor || '#FFFFFF';
      
      if (drawing.fillStyle === 'crosshatch') {
        this.drawCrosshatchFillRect(left, top, width, height, fillColor, fillAlpha);
        // Recreate path for stroke after crosshatch
        this.ctx.beginPath();
        this.ctx.rect(left, top, width, height);
      } else {
        // Solid fill - ensure line style doesn't affect fill
        this.ctx.save();
        this.ctx.setLineDash([]); // Reset line dash for fill
        this.ctx.globalAlpha = fillAlpha;
        this.ctx.fillStyle = fillColor;
        this.ctx.fill();
        this.ctx.restore();
        // Recreate path for stroke
        this.ctx.beginPath();
        this.ctx.rect(left, top, width, height);
      }
    }
    
    // Apply line style only for stroke
    this.setLineStyle(drawing.lineStyle || 'solid');
    this.ctx.stroke();
  }

  drawFreehand(drawing) {
    if (!drawing.points || drawing.points.length < 2) return;
    
    this.ctx.save();
    this.ctx.strokeStyle = drawing.color || '#000000';
    this.ctx.lineWidth = drawing.lineWidth || 2;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    this.ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    
    this.ctx.beginPath();
    this.ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
    for (let i = 1; i < drawing.points.length; i++) {
      this.ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
    }
    this.ctx.stroke();
    this.ctx.restore();
  }
  
  // Add spray particles at a given position
  addSprayParticles(x, y) {
    const drawing = this.drawings[this.drawings.length - 1];
    if (!drawing || drawing.type !== 'spray') return;
    
    const radius = drawing.radius || this.sprayRadius;
    const density = drawing.density || this.sprayDensity;
    
    // Generate random particles within the spray radius
    for (let i = 0; i < density; i++) {
      // Random angle and distance (weighted towards center for more realistic spray)
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * Math.random() * radius; // Double random for center bias
      
      const particleX = x + Math.cos(angle) * distance;
      const particleY = y + Math.sin(angle) * distance;
      
      drawing.particles.push({ x: particleX, y: particleY });
    }
  }
  
  // Draw spray particles
  drawSpray(drawing) {
    if (!drawing.particles || drawing.particles.length === 0) return;
    
    this.ctx.save();
    this.ctx.fillStyle = drawing.color || '#000000';
    this.ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    
    const particleSize = drawing.particleSize || this.sprayParticleSize;
    
    // Draw each particle as a small circle
    drawing.particles.forEach(particle => {
      this.ctx.beginPath();
      this.ctx.arc(particle.x, particle.y, particleSize, 0, Math.PI * 2);
      this.ctx.fill();
    });
    
    this.ctx.restore();
  }
  
  // Get heat maps that overlap with a given position and radius
  getOverlappingHeatmaps(x, y, radius) {
    const overlappingIndices = [];
    const gridSize = this.heatmapGridSize;
    
    // Calculate bounding box for the new heat area
    const newMinX = x - radius;
    const newMaxX = x + radius;
    const newMinY = y - radius;
    const newMaxY = y + radius;
    
    // Check each existing heat map
    for (let i = 0; i < this.drawings.length; i++) {
      const drawing = this.drawings[i];
      if (drawing.type !== 'heatmap' || !drawing.heatGrid || Object.keys(drawing.heatGrid).length === 0) {
        continue;
      }
      
      // Calculate bounding box of existing heat map
      let minGridX = Infinity, minGridY = Infinity, maxGridX = -Infinity, maxGridY = -Infinity;
      Object.keys(drawing.heatGrid).forEach(gridKey => {
        const [gridX, gridY] = gridKey.split(',').map(Number);
        minGridX = Math.min(minGridX, gridX);
        minGridY = Math.min(minGridY, gridY);
        maxGridX = Math.max(maxGridX, gridX);
        maxGridY = Math.max(maxGridY, gridY);
      });
      
      const existingMinX = minGridX * gridSize;
      const existingMaxX = (maxGridX + 1) * gridSize;
      const existingMinY = minGridY * gridSize;
      const existingMaxY = (maxGridY + 1) * gridSize;
      
      // Check if bounding boxes overlap
      if (newMinX <= existingMaxX && newMaxX >= existingMinX &&
          newMinY <= existingMaxY && newMaxY >= existingMinY) {
        overlappingIndices.push(i);
      }
    }
    
    return overlappingIndices;
  }
  
  // Add heat at a given position (accumulates intensity over time)
  addHeatAtPosition(x, y, targetDrawings = null) {
    // Determine which heat maps to add heat to
    let drawingsToModify = [];
    
    if (targetDrawings && targetDrawings.length > 0) {
      // Use provided target drawings (for merging with existing heat maps)
      drawingsToModify = targetDrawings.map(index => this.drawings[index]).filter(d => d && d.type === 'heatmap');
    } else {
      // Default: use the last drawing (for new heat map creation)
      const lastDrawing = this.drawings[this.drawings.length - 1];
      if (lastDrawing && lastDrawing.type === 'heatmap') {
        drawingsToModify = [lastDrawing];
      }
    }
    
    if (drawingsToModify.length === 0) return;
    
    // Use the first drawing's properties for radius and grid size (they should be consistent)
    const firstDrawing = drawingsToModify[0];
    const radius = firstDrawing.radius || this.heatmapRadius;
    const gridSize = firstDrawing.gridSize || this.heatmapGridSize;
    const intensityIncrement = this.heatmapIntensityIncrement;
    const maxIntensity = this.heatmapMaxIntensity;
    
    // Calculate grid bounds
    const gridMinX = Math.floor((x - radius) / gridSize);
    const gridMaxX = Math.ceil((x + radius) / gridSize);
    const gridMinY = Math.floor((y - radius) / gridSize);
    const gridMaxY = Math.ceil((y + radius) / gridSize);
    
    // Process each grid cell within radius
    for (let gridX = gridMinX; gridX <= gridMaxX; gridX++) {
      for (let gridY = gridMinY; gridY <= gridMaxY; gridY++) {
        // Calculate center of grid cell in pixel coordinates
        const cellCenterX = gridX * gridSize + gridSize / 2;
        const cellCenterY = gridY * gridSize + gridSize / 2;
        
        // Calculate distance from mouse position to cell center
        const dx = cellCenterX - x;
        const dy = cellCenterY - y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // Skip if outside radius
        if (distance > radius) continue;
        
        // Calculate falloff (more intensity at center, less at edges)
        const falloff = 1 - (distance / radius);
        const intensityDelta = intensityIncrement * falloff;
        
        // Add heat to all target drawings
        drawingsToModify.forEach(drawing => {
          // Initialize heatGrid if it doesn't exist (plain object for JSON serialization)
          if (!drawing.heatGrid) {
            drawing.heatGrid = {};
          }
          
          // Get or initialize intensity for this grid cell
          const gridKey = `${gridX},${gridY}`;
          const currentIntensity = drawing.heatGrid[gridKey] || 0;
          // Add intensities together, capped at maxIntensity
          const newIntensity = Math.min(currentIntensity + intensityDelta, maxIntensity);
          
          // Store intensity (only store non-zero values for lightweight storage)
          if (newIntensity > 0) {
            drawing.heatGrid[gridKey] = newIntensity;
          } else if (drawing.heatGrid[gridKey] !== undefined) {
            delete drawing.heatGrid[gridKey];
          }
        });
      }
    }
  }
  
  // Convert intensity (0.0-1.0) to RGB color (light red to dark red)
  intensityToColor(intensity) {
    if (intensity <= 0) return null; // Transparent
    
    // Heat scale: green → yellow → orange → red → dark red
    // Intensity ranges: 0.0-0.2 = green, 0.2-0.4 = yellow, 0.4-0.6 = orange, 0.6-0.8 = red, 0.8-1.0 = dark red
    let r, g, b;
    
    if (intensity < 0.2) {
      // Green (0, 255, 0) to yellow-green
      const t = intensity / 0.2;
      r = Math.floor(0 + (200 * t));
      g = 255;
      b = Math.floor(0 + (100 * t));
    } else if (intensity < 0.4) {
      // Yellow-green to yellow
      const t = (intensity - 0.2) / 0.2;
      r = Math.floor(200 + (55 * t));
      g = 255;
      b = Math.floor(100 - (100 * t));
    } else if (intensity < 0.6) {
      // Yellow to orange
      const t = (intensity - 0.4) / 0.2;
      r = 255;
      g = Math.floor(255 - (100 * t));
      b = 0;
    } else if (intensity < 0.8) {
      // Orange to red
      const t = (intensity - 0.6) / 0.2;
      r = 255;
      g = Math.floor(155 - (155 * t));
      b = 0;
      } else {
      // Red to dark red
      const t = (intensity - 0.8) / 0.2;
      r = Math.floor(255 - (155 * t));
      g = 0;
      b = 0;
    }
    
    return `rgb(${r}, ${g}, ${b})`;
  }
  
  // Draw heat map
  drawHeatmap(drawing) {
    if (!drawing.heatGrid || Object.keys(drawing.heatGrid).length === 0) return;
    
    this.ctx.save();
    this.ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    
    const gridSize = drawing.gridSize || this.heatmapGridSize;
    
    // Draw each grid cell
    Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
      const [gridX, gridY] = gridKey.split(',').map(Number);
      const pixelX = gridX * gridSize;
      const pixelY = gridY * gridSize;
      
      // Get color based on intensity
      const color = this.intensityToColor(intensity);
      if (!color) return;
      
      // Draw filled rectangle for this grid cell
      this.ctx.fillStyle = color;
      this.ctx.fillRect(pixelX, pixelY, gridSize, gridSize);
    });
    
    this.ctx.restore();
  }

  drawText(drawing) {
    if (!drawing.text || typeof drawing.text !== 'string') return;
    
    this.ctx.save();
    
    const fontWeight = drawing.fontWeight || 400;
    const fontSize = drawing.fontSize || 16;
    this.ctx.font = `${fontWeight} ${fontSize}px sans-serif`;
    this.ctx.textAlign = 'left';
    this.ctx.textBaseline = 'top'; // Use 'top' for consistent positioning
    
    // Set fill color
    this.ctx.fillStyle = drawing.color || '#FFFFFF';
    this.ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    
    // Draw stroke if strokeColor is provided
    if (drawing.strokeColor) {
      this.ctx.strokeStyle = drawing.strokeColor;
      this.ctx.lineWidth = drawing.strokeWidth || 2;
      this.ctx.lineJoin = 'round';
      this.ctx.miterLimit = 2;
      // Draw stroke first, then fill on top
      this.ctx.strokeText(drawing.text, drawing.x, drawing.y);
    }
    
    // Draw fill text (only once)
    this.ctx.fillText(drawing.text, drawing.x, drawing.y);
    
    this.ctx.restore();
  }

  handleImageFileSelect(e) {
    const file = e.target.files[0];
    if (!file || !file.type.startsWith('image/')) {
      console.error('Invalid image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Get canvas dimensions (use reference size if canvas not initialized yet)
        const canvasWidth = this.canvas.width || this.referenceCanvasWidth;
        const canvasHeight = this.canvas.height || this.referenceCanvasHeight;
        
        // Calculate maximum size to fit within canvas (use 90% to leave some margin)
        const maxWidth = canvasWidth * 0.9;
        const maxHeight = canvasHeight * 0.9;
        
        // Calculate scaled dimensions while maintaining aspect ratio
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidth || height > maxHeight) {
          const aspectRatio = width / height;
          
          if (width > height) {
            // Image is wider - fit to max width
            width = maxWidth;
            height = maxWidth / aspectRatio;
          } else {
            // Image is taller - fit to max height
            height = maxHeight;
            width = maxHeight * aspectRatio;
          }
        }
        
        // Calculate placement - center image if flag is set
        let x, y;
        if (this.centerImageOnLoad) {
          // Center the image on canvas
          x = (canvasWidth / 2) - (width / 2);
          y = (canvasHeight / 2) - (height / 2);
          this.centerImageOnLoad = false; // Reset flag
        } else {
          // Use stored placement position (from canvas click) or default to center
          x = this.imagePlacementX !== undefined ? this.imagePlacementX : (canvasWidth / 2) - (width / 2);
          y = this.imagePlacementY !== undefined ? this.imagePlacementY : (canvasHeight / 2) - (height / 2);
        }
        
        // Create image drawing object
        const drawing = {
          type: 'image',
          imageData: event.target.result, // Store as data URL
          imageElement: img, // Cache the loaded image
          x: x,
          y: y,
          width: width,
          height: height,
          originalWidth: img.width,
          originalHeight: img.height
        };
        
        this.drawings.push(drawing);
        this.saveState();
        
        // Automatically switch to select tool and select the newly added image
        const newDrawingIndex = this.drawings.length - 1;
        this.selectTool('select');
        this.selectedDrawings = [newDrawingIndex];
        this.updateSelectionControls();
        this.redraw();
        
        // Reset file input
        e.target.value = '';
      };
      img.onerror = (errorEvent) => {
        // Safely extract file information
        const fileName = file?.name || 'unknown';
        const fileType = file?.type || 'unknown';
        const fileSize = file?.size || 0;
        const dataUrlLength = event?.target?.result?.length || 0;
        
        console.error('Failed to load image', {
          fileName: fileName,
          fileType: fileType,
          fileSize: fileSize,
          dataUrlLength: dataUrlLength,
          error: errorEvent
        });
        
        // Show user-friendly error notification
        let errorMessage = 'Failed to load image. The file may be corrupted or in an unsupported format.';
        
        if (file) {
          if (file.type && !file.type.startsWith('image/')) {
            errorMessage = 'Invalid file type. Please select an image file (PNG, JPG, GIF, etc.).';
          } else if (file.size > 50 * 1024 * 1024) { // 50MB
            errorMessage = 'Image file is too large. Please select a smaller image (max 50MB).';
          } else if (dataUrlLength === 0) {
            errorMessage = 'Failed to read image file. The file may be corrupted or inaccessible.';
          }
        }
        
        // Ensure errorMessage is always a string
        if (typeof errorMessage !== 'string') {
          errorMessage = 'Failed to load image. Please try a different file.';
        }
        
        showNotification(errorMessage, 'error', 5000);
        if (e?.target) {
          e.target.value = '';
        }
      };
      img.src = event.target.result;
    };
    reader.onerror = (errorEvent) => {
      console.error('Failed to read file', errorEvent);
      const errorMessage = 'Failed to read image file. Please try selecting the file again.';
      showNotification(errorMessage, 'error', 5000);
      if (e?.target) {
        e.target.value = '';
      }
    };
    reader.readAsDataURL(file);
  }

  placeFormation(clickX, clickY) {
    // Get team color and formation first if team is selected
    if (this.formationTeam && this.currentAnalysisId) {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === this.currentAnalysisId);
        let baseColor = this.formationColor || '#FFFFFF';
        let formationToUse = this.currentFormation;
        
        if (analysis && analysis.teams) {
          const teamObj = getTeamObject(this.formationTeam, analysis.teams);
          if (teamObj) {
            const teamData = ensureTeamObject(teamObj);
            // Use selected kit color (home or away)
            baseColor = this.formationKit === 'home' 
              ? (teamData.homeColor || '#FFFFFF')
              : (teamData.awayColor || '#000000');
            this.formationColor = baseColor;
            
            // Use selected kit design and second color
            this.tshirtDesign = this.formationKit === 'home'
              ? (teamData.homeDesign || 'solid')
              : (teamData.awayDesign || 'solid');
            this.tshirtSecondColor = this.formationKit === 'home'
              ? (teamData.homeSecondColor || '#000000')
              : (teamData.awaySecondColor || '#FFFFFF');
            
            // Use team's formation if it has one, otherwise use current formation
            if (teamData.formation) {
              formationToUse = teamData.formation;
            }
            
            // Update color input
            const colorInput = document.getElementById('editorFormationColor');
            if (colorInput) {
              colorInput.value = baseColor;
            }
          }
        }
        
        this.placeFormationWithColor(clickX, clickY, baseColor, formationToUse);
      });
      return;
    }
    
    // No team selected, use current formation color
    this.placeFormationWithColor(clickX, clickY, this.formationColor || '#FFFFFF', this.currentFormation);
  }

  // ============================================================
  // PLAYER PANEL METHODS
  // ============================================================
  
  initPlayerPanel() {
    const toggleBtn = document.getElementById('editorPlayerPanelToggle');
    const toolbarBtn = document.getElementById('editorPlayerPanelBtn');
    const panel = document.getElementById('editorPlayerPanel');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const teamSearchInput = document.getElementById('editorTeamSearchInput');
    const teamSelectorDropdown = document.getElementById('editorTeamSelectorDropdown');
    
    // Toggle from panel header button
    if (toggleBtn && panel) {
      toggleBtn.addEventListener('click', () => {
        this.togglePlayerPanel();
      });
    }
    
    // Toggle from toolbar button
    if (toolbarBtn && panel) {
      toolbarBtn.addEventListener('click', () => {
        this.togglePlayerPanel();
      });
    }
    
    // Setup new team selector UI
    if (teamSearchInput && teamSelectorDropdown) {
      // Show/hide dropdown on search input focus
      teamSearchInput.addEventListener('focus', () => {
        // Clear the input to show all teams when opening dropdown
        const currentValue = teamSelect ? teamSelect.value : '';
        teamSearchInput.value = '';
        teamSearchInput.style.color = '';
        teamSearchInput.style.fontWeight = '';
        teamSelectorDropdown.style.display = 'block';
        this.renderEditorTeamSelector('');
      });
      
      // Also allow clicking on the input to open dropdown
      teamSearchInput.addEventListener('click', () => {
        if (teamSelectorDropdown.style.display === 'none' || !teamSelectorDropdown.style.display) {
          const currentValue = teamSelect ? teamSelect.value : '';
          teamSearchInput.value = '';
          teamSearchInput.style.color = '';
          teamSearchInput.style.fontWeight = '';
          teamSelectorDropdown.style.display = 'block';
          this.renderEditorTeamSelector('');
        }
      });

      teamSearchInput.addEventListener('input', (e) => {
        // Reset styling when user types
        e.target.style.color = '';
        e.target.style.fontWeight = '';
        this.renderEditorTeamSelector(e.target.value);
        if (teamSelectorDropdown) {
          teamSelectorDropdown.style.display = 'block';
        }
      });

      teamSearchInput.addEventListener('blur', (e) => {
        // Delay hiding to allow clicks on items
        setTimeout(() => {
          if (teamSelectorDropdown && !teamSelectorDropdown.matches(':hover') && document.activeElement !== teamSearchInput) {
            teamSelectorDropdown.style.display = 'none';
            
            // Restore the selected team name display if a team is selected
            const selectedTeam = teamSelect ? teamSelect.value : '';
            if (selectedTeam) {
              teamSearchInput.value = selectedTeam;
              teamSearchInput.style.color = '#1f6feb';
              teamSearchInput.style.fontWeight = '500';
            } else {
              teamSearchInput.value = '';
              teamSearchInput.style.color = '';
              teamSearchInput.style.fontWeight = '';
            }
          }
        }, 200);
      });
    }

    // Keep dropdown open when hovering
    if (teamSelectorDropdown) {
      teamSelectorDropdown.addEventListener('mouseenter', () => {
        teamSelectorDropdown.style.display = 'block';
      });
      teamSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== teamSearchInput) {
          teamSelectorDropdown.style.display = 'none';
        }
      });
    }
    
    if (teamSelect) {
      teamSelect.addEventListener('change', (e) => {
        const teamName = e.target.value;
        this.loadPlayersForTeam(teamName);
        
        // Show/hide squad section
        const configSection = document.getElementById('editorSquadConfigSection');
        if (configSection) {
          if (teamName) {
            configSection.style.display = 'block';
            this.populateSquadConfigSelector(teamName);
            this.clearSquadConfiguration();
          } else {
            configSection.style.display = 'none';
            this.clearSquadConfiguration();
          }
        }
        
        // Update selected team display
        this.updateEditorSelectedTeamDisplay();
      });
      
      // Populate team selector
      this.populatePlayerPanelTeams();
    }
    
    // Setup drag events on canvas
    this.setupPlayerDragDrop();
    
    // Setup player assign popup
    this.initPlayerAssignPopup();
    
    // Setup squad configuration
    this.initSquadConfiguration();
    
    // Setup team/player management (modals and CRUD)
    this.initTeamPlayerManagement();
  }
  
  initSquadConfiguration() {
    // Initialize current squad arrays
    this.currentStartingSquad = [];
    this.currentBench = [];
    this.currentSquadConfigId = null;
    
    // Clean up duplicates on initialization
    this.cleanupDuplicateSquadConfigurations();
    
    const configSection = document.getElementById('editorSquadConfigSection');
    const configSelect = document.getElementById('editorSquadConfigSelect');
    const deleteBtn = document.getElementById('editorSquadConfigDeleteBtn');
    const saveBtn = document.getElementById('editorSaveSquadBtn');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const saveModal = document.getElementById('editorSaveSquadModal');
    const closeSaveModalBtn = document.getElementById('editorCloseSaveSquadModal');
    const confirmSaveBtn = document.getElementById('editorConfirmSaveSquadBtn');
    const modalNameInput = document.getElementById('editorSquadConfigNameInput');
    
    // Show/hide squad section based on team selection
    if (teamSelect) {
      const originalChangeHandler = teamSelect.onchange;
      teamSelect.addEventListener('change', (e) => {
        const teamName = e.target.value;
        if (configSection) {
          if (teamName) {
            configSection.style.display = 'block';
            this.populateSquadConfigSelector(teamName);
            this.clearSquadConfiguration();
          } else {
            configSection.style.display = 'none';
            this.clearSquadConfiguration();
          }
        }
      });
    }
    
    // Configuration selector change
    if (configSelect) {
      configSelect.addEventListener('change', (e) => {
        const configId = e.target.value;
        const squadNameInput = document.getElementById('editorSquadNameInput');
        
        if (!configId) {
          // "New Squad" selected - clear name input for new entry
          if (squadNameInput) {
            squadNameInput.value = '';
            const placeholder = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.enterSquadName')
              : 'Enter squad name...';
            squadNameInput.placeholder = placeholder;
            setTimeout(() => squadNameInput.focus(), 50);
          }
          this.loadSquadConfiguration(null);
        } else {
          // Existing config selected - load config and populate name
          this.loadSquadConfiguration(configId);
        }
      });
    }
    
    // Name input for new squad
    const squadNameInput = document.getElementById('editorSquadNameInput');
    if (squadNameInput) {
      squadNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const name = squadNameInput.value.trim();
          if (name) {
            // Update the selector to show this name (will be saved when user clicks Save)
            this.currentNewSquadName = name;
          }
        }
      });
    }
    
    // Delete configuration button
    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => {
        if (!this.currentSquadConfigId) return;
        
        const confirmText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.confirmDeleteItem')
          : 'Are you sure you want to delete this squad configuration?';
        if (confirm(confirmText)) {
          this.deleteSquadConfiguration(this.currentSquadConfigId)
            .then(() => {
              showNotification('Configuration deleted', 'success', 2000);
              this.clearSquadConfiguration();
              
              const teamSelect = document.getElementById('editorPlayerTeamSelect');
              const teamName = teamSelect ? teamSelect.value : null;
              if (teamName) {
                this.populateSquadConfigSelector(teamName);
              }
            })
            .catch((err) => {
              console.error('Error deleting configuration:', err);
              showNotification('Error deleting configuration', 'error', 2000);
            });
        }
      });
    }
    
    // Save button - now saves directly using the visible name input
    if (saveBtn) {
      saveBtn.addEventListener('click', () => {
        this.handleSaveSquadConfiguration();
      });
    }
    
    // Save modal handlers
    if (closeSaveModalBtn) {
      closeSaveModalBtn.addEventListener('click', () => {
        this.closeSaveSquadModal();
      });
    }
    
    
    if (confirmSaveBtn) {
      confirmSaveBtn.addEventListener('click', () => {
        this.handleSaveSquadConfiguration();
      });
    }
    
    if (modalNameInput) {
      modalNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.handleSaveSquadConfiguration();
        } else if (e.key === 'Escape') {
          this.closeSaveSquadModal();
        }
      });
    }
    
    if (saveModal) {
      saveModal.addEventListener('click', (e) => {
        if (e.target === saveModal) {
          this.closeSaveSquadModal();
        }
      });
    }
    
    // Setup click handlers for squad
    this.setupSquadClickHandlers();
  }
  
  // Initialize Team and Player Management UI
  initTeamPlayerManagement() {
    // State for modals
    this.editingTeamId = null;
    this.editingPlayerId = null;
    this.selectedPlayerId = null;
    this.deleteCallback = null;
    
    // Team management buttons
    const createTeamBtn = document.getElementById('editorCreateTeamBtn');
    const editTeamBtn = document.getElementById('editorEditTeamBtn');
    const deleteTeamBtn = document.getElementById('editorDeleteTeamBtn');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const teamActionsRow = document.getElementById('editorTeamActionsRow');
    
    // Team Modal elements
    const teamModal = document.getElementById('editorTeamModal');
    const closeTeamModalBtn = document.getElementById('editorCloseTeamModal');
    const cancelTeamModalBtn = document.getElementById('editorCancelTeamModal');
    const saveTeamModalBtn = document.getElementById('editorSaveTeamModal');
    
    // Player management buttons
    const createPlayerBtn = document.getElementById('editorCreatePlayerBtn');
    const playerSearchInput = document.getElementById('editorPlayerSearchInput');
    
    // Player Modal elements
    const playerModal = document.getElementById('editorPlayerModal');
    const closePlayerModalBtn = document.getElementById('editorClosePlayerModal');
    const cancelPlayerModalBtn = document.getElementById('editorCancelPlayerModal');
    const savePlayerModalBtn = document.getElementById('editorSavePlayerModal');
    
    // Confirm Delete Modal elements
    const confirmDeleteModal = document.getElementById('editorConfirmDeleteModal');
    const closeConfirmDeleteBtn = document.getElementById('editorCloseConfirmDeleteModal');
    const cancelDeleteBtn = document.getElementById('editorCancelDeleteModal');
    const confirmDeleteBtn = document.getElementById('editorConfirmDeleteBtn');
    
    // Create Team button
    if (createTeamBtn) {
      createTeamBtn.addEventListener('click', () => {
        this.openTeamModal(null);
      });
    }
    
    // Team Modal handlers
    if (closeTeamModalBtn) closeTeamModalBtn.addEventListener('click', () => this.closeTeamModal());
    if (cancelTeamModalBtn) cancelTeamModalBtn.addEventListener('click', () => this.closeTeamModal());
    if (teamModal) {
      teamModal.querySelector('.editor-modal-overlay')?.addEventListener('click', () => this.closeTeamModal());
    }
    if (saveTeamModalBtn) saveTeamModalBtn.addEventListener('click', () => this.saveTeamFromModal());
    
    // Create Player button
    if (createPlayerBtn) {
      createPlayerBtn.addEventListener('click', () => {
        this.openPlayerModal(null);
      });
    }
    
    
    // Player search
    if (playerSearchInput) {
      playerSearchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        this.filterPlayerList(query);
      });
    }
    
    // Player Modal handlers
    if (closePlayerModalBtn) closePlayerModalBtn.addEventListener('click', () => this.closePlayerModal());
    if (cancelPlayerModalBtn) cancelPlayerModalBtn.addEventListener('click', () => this.closePlayerModal());
    if (playerModal) {
      playerModal.querySelector('.editor-modal-overlay')?.addEventListener('click', () => this.closePlayerModal());
    }
    if (savePlayerModalBtn) savePlayerModalBtn.addEventListener('click', () => this.savePlayerFromModal());
    
    // Confirm Delete Modal handlers
    if (closeConfirmDeleteBtn) closeConfirmDeleteBtn.addEventListener('click', () => this.closeConfirmDeleteModal());
    if (cancelDeleteBtn) cancelDeleteBtn.addEventListener('click', () => this.closeConfirmDeleteModal());
    if (confirmDeleteModal) {
      confirmDeleteModal.querySelector('.editor-modal-overlay')?.addEventListener('click', () => this.closeConfirmDeleteModal());
    }
    if (confirmDeleteBtn) {
      confirmDeleteBtn.addEventListener('click', () => {
        if (this.deleteCallback) {
          this.deleteCallback();
        }
        this.closeConfirmDeleteModal();
      });
    }
    
    // Keyboard handlers for modals
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (teamModal && !teamModal.classList.contains('hidden')) {
          this.closeTeamModal();
        }
        if (playerModal && !playerModal.classList.contains('hidden')) {
          this.closePlayerModal();
        }
        if (confirmDeleteModal && !confirmDeleteModal.classList.contains('hidden')) {
          this.closeConfirmDeleteModal();
        }
      }
    });
  }
  
  // Team Modal Methods
  openTeamModal(team) {
    const modal = document.getElementById('editorTeamModal');
    const title = document.getElementById('editorTeamModalTitle');
    const nameInput = document.getElementById('editorTeamNameInput');
    const homeColorInput = document.getElementById('editorTeamHomeColor');
    const awayColorInput = document.getElementById('editorTeamAwayColor');
    const homeDesignSelect = document.getElementById('editorTeamHomeDesign');
    const awayDesignSelect = document.getElementById('editorTeamAwayDesign');
    const homeSecondColorInput = document.getElementById('editorTeamHomeSecondColor');
    const awaySecondColorInput = document.getElementById('editorTeamAwaySecondColor');
    const formationSelect = document.getElementById('editorTeamFormation');
    
    if (!modal) return;
    
    this.editingTeamId = team ? team.id : null;
    
    if (title) {
      const titleText = (window.i18n && typeof window.i18n.t === 'function')
        ? (team ? window.i18n.t('modals.editTeam') : window.i18n.t('modals.addTeam'))
        : (team ? (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.editTeam') : 'Edit Team') : (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.createTeam') : 'Create Team'));
      title.textContent = titleText;
    }
    
    // Populate form
    if (nameInput) nameInput.value = team ? team.name : '';
    if (homeColorInput) homeColorInput.value = team ? team.homeColor : '#FFFFFF';
    if (awayColorInput) awayColorInput.value = team ? team.awayColor : '#000000';
    if (homeDesignSelect) homeDesignSelect.value = team ? (team.homeDesign || 'solid') : 'solid';
    if (awayDesignSelect) awayDesignSelect.value = team ? (team.awayDesign || 'solid') : 'solid';
    if (homeSecondColorInput) homeSecondColorInput.value = team ? (team.homeSecondColor || '#000000') : '#000000';
    if (awaySecondColorInput) awaySecondColorInput.value = team ? (team.awaySecondColor || '#FFFFFF') : '#FFFFFF';
    if (formationSelect) formationSelect.value = team ? (team.formation || '') : '';
    
    modal.classList.remove('hidden');
    
    // Update previews
    setTimeout(() => {
      this.updateTeamKitPreview('home');
      this.updateTeamKitPreview('away');
    }, 50);
    
    // Setup event listeners for preview updates (only once)
    if (!this.teamModalPreviewListenersSetup) {
      if (homeColorInput) {
        homeColorInput.addEventListener('input', () => this.updateTeamKitPreview('home'));
        homeColorInput.addEventListener('change', () => this.updateTeamKitPreview('home'));
      }
      if (homeDesignSelect) {
        homeDesignSelect.addEventListener('change', () => this.updateTeamKitPreview('home'));
      }
      if (homeSecondColorInput) {
        homeSecondColorInput.addEventListener('input', () => this.updateTeamKitPreview('home'));
        homeSecondColorInput.addEventListener('change', () => this.updateTeamKitPreview('home'));
      }
      if (awayColorInput) {
        awayColorInput.addEventListener('input', () => this.updateTeamKitPreview('away'));
        awayColorInput.addEventListener('change', () => this.updateTeamKitPreview('away'));
      }
      if (awayDesignSelect) {
        awayDesignSelect.addEventListener('change', () => this.updateTeamKitPreview('away'));
      }
      if (awaySecondColorInput) {
        awaySecondColorInput.addEventListener('input', () => this.updateTeamKitPreview('away'));
        awaySecondColorInput.addEventListener('change', () => this.updateTeamKitPreview('away'));
      }
      this.teamModalPreviewListenersSetup = true;
    }
    
    // Focus name input
    setTimeout(() => nameInput?.focus(), 50);
  }
  
  closeTeamModal() {
    const modal = document.getElementById('editorTeamModal');
    if (modal) {
      modal.classList.add('hidden');
    }
    this.editingTeamId = null;
  }
  
  saveTeamFromModal() {
    const nameInput = document.getElementById('editorTeamNameInput');
    const homeColorInput = document.getElementById('editorTeamHomeColor');
    const awayColorInput = document.getElementById('editorTeamAwayColor');
    const homeDesignSelect = document.getElementById('editorTeamHomeDesign');
    const awayDesignSelect = document.getElementById('editorTeamAwayDesign');
    const homeSecondColorInput = document.getElementById('editorTeamHomeSecondColor');
    const awaySecondColorInput = document.getElementById('editorTeamAwaySecondColor');
    const formationSelect = document.getElementById('editorTeamFormation');
    
    const name = nameInput ? nameInput.value.trim() : '';
    
    if (!name) {
      const message = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.pleaseEnterTeamName')
        : (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.pleaseEnterTeamName') : 'Please enter a team name');
      showNotification(message, 'error', 2000);
      nameInput?.focus();
      return;
    }
    
    const teamData = {
      name: name,
      homeColor: homeColorInput ? homeColorInput.value : '#FFFFFF',
      awayColor: awayColorInput ? awayColorInput.value : '#000000',
      homeDesign: homeDesignSelect ? homeDesignSelect.value : 'solid',
      awayDesign: awayDesignSelect ? awayDesignSelect.value : 'solid',
      homeSecondColor: homeSecondColorInput ? homeSecondColorInput.value : '#000000',
      awaySecondColor: awaySecondColorInput ? awaySecondColorInput.value : '#FFFFFF',
      formation: formationSelect ? formationSelect.value : ''
    };
    
    const savePromise = this.editingTeamId 
      ? this.updateTeam(this.editingTeamId, teamData)
      : this.createTeam(teamData);
    
    savePromise
      .then((savedTeam) => {
        const successMessage = (window.i18n && typeof window.i18n.t === 'function')
          ? (this.editingTeamId ? window.i18n.t('editor.teamUpdated') : window.i18n.t('editor.teamCreated'))
          : (this.editingTeamId ? 'Team updated' : 'Team created');
        showNotification(successMessage, 'success', 2000);
        this.closeTeamModal();
        this.populatePlayerPanelTeams();
        
        // Select the newly created/updated team
        const teamSelect = document.getElementById('editorPlayerTeamSelect');
        if (teamSelect) {
          setTimeout(() => {
            teamSelect.value = savedTeam.name;
            teamSelect.dispatchEvent(new Event('change'));
            // Refresh the team selector UI
            const searchInput = document.getElementById('editorTeamSearchInput');
            this.renderEditorTeamSelector(searchInput ? searchInput.value : '');
          }, 100);
        }
      })
      .catch(err => {
        showNotification('Error: ' + err.message, 'error', 3000);
      });
  }
  
  // Player Modal Methods
  openPlayerModal(player) {
    const modal = document.getElementById('editorPlayerModal');
    const title = document.getElementById('editorPlayerModalTitle');
    const nameInput = document.getElementById('editorPlayerNameInput');
    const numberInput = document.getElementById('editorPlayerNumberInput');
    const positionSelect = document.getElementById('editorPlayerPositionSelect');
    const teamSelect = document.getElementById('editorPlayerTeamModalSelect');
    
    if (!modal) return;
    
    this.editingPlayerId = player ? player.id : null;
    
    if (title) {
      const titleText = (window.i18n && typeof window.i18n.t === 'function')
        ? (player ? window.i18n.t('modals.editPlayer') : window.i18n.t('modals.addPlayer'))
        : (player ? 'Edit Player' : 'Create Player');
      title.textContent = titleText;
    }
    
    // Populate team selector in modal
    this.populatePlayerModalTeamSelector(player ? player.team : null);
    
    // Populate form
    if (nameInput) nameInput.value = player ? player.fullName : '';
    if (numberInput) numberInput.value = player ? player.number : '';
    if (positionSelect) positionSelect.value = player ? (player.position || '') : '';
    
    modal.classList.remove('hidden');
    
    // Focus name input
    setTimeout(() => nameInput?.focus(), 50);
  }
  
  closePlayerModal() {
    const modal = document.getElementById('editorPlayerModal');
    if (modal) {
      modal.classList.add('hidden');
    }
    this.editingPlayerId = null;
  }
  
  populatePlayerModalTeamSelector(selectedTeamName) {
    const teamSelect = document.getElementById('editorPlayerTeamModalSelect');
    if (!teamSelect) return;
    
    // Clear existing options except first
    while (teamSelect.options.length > 1) {
      teamSelect.remove(1);
    }
    
    this.loadAllTeams().then(teams => {
      teams.forEach(team => {
        const option = document.createElement('option');
        option.value = team.name;
        option.textContent = team.name;
        teamSelect.appendChild(option);
      });
      
      if (selectedTeamName) {
        teamSelect.value = selectedTeamName;
      } else {
        // Default to currently selected team in main panel
        const mainTeamSelect = document.getElementById('editorPlayerTeamSelect');
        if (mainTeamSelect && mainTeamSelect.value) {
          teamSelect.value = mainTeamSelect.value;
        }
      }
    });
  }
  
  savePlayerFromModal() {
    const nameInput = document.getElementById('editorPlayerNameInput');
    const numberInput = document.getElementById('editorPlayerNumberInput');
    const positionSelect = document.getElementById('editorPlayerPositionSelect');
    const teamSelect = document.getElementById('editorPlayerTeamModalSelect');
    
    const fullName = nameInput ? nameInput.value.trim() : '';
    
    if (!fullName) {
      const playerNameText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.enterPlayerName')
        : 'Please enter a player name';
      showNotification(playerNameText, 'error', 2000);
      nameInput?.focus();
      return;
    }
    
    const playerData = {
      fullName: fullName,
      number: numberInput ? numberInput.value : '',
      position: positionSelect ? positionSelect.value : '',
      team: teamSelect ? teamSelect.value : ''
    };
    
    const savePromise = this.editingPlayerId 
      ? this.updatePlayer(this.editingPlayerId, playerData)
      : this.createPlayer(playerData);
    
    savePromise
      .then(() => {
        showNotification(this.editingPlayerId ? 'Player updated' : 'Player created', 'success', 2000);
        this.closePlayerModal();
        
        // Refresh player list
        const mainTeamSelect = document.getElementById('editorPlayerTeamSelect');
        const teamName = mainTeamSelect ? mainTeamSelect.value : '';
        this.loadPlayersForTeam(teamName);
      })
      .catch(err => {
        showNotification('Error: ' + err.message, 'error', 3000);
      });
  }
  
  // Filter player list by search query
  filterPlayerList(query) {
    const playerList = document.getElementById('editorPlayerList');
    if (!playerList) return;
    
    const items = playerList.querySelectorAll('.editor-player-item');
    items.forEach(item => {
      const name = item.querySelector('.editor-player-item-name')?.textContent.toLowerCase() || '';
      const number = item.querySelector('.editor-player-item-number')?.textContent.toLowerCase() || '';
      const position = item.querySelector('.editor-player-item-position')?.textContent.toLowerCase() || '';
      
      if (name.includes(query) || number.includes(query) || position.includes(query)) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    });
  }
  
  // Confirm Delete Modal Methods
  openConfirmDeleteModal(title, message, callback) {
    const modal = document.getElementById('editorConfirmDeleteModal');
    const titleEl = document.getElementById('editorConfirmDeleteTitle');
    const messageEl = document.getElementById('editorConfirmDeleteMessage');
    
    if (!modal) return;
    
    if (titleEl) titleEl.textContent = title;
    if (messageEl) messageEl.textContent = message;
    this.deleteCallback = callback;
    
    modal.classList.remove('hidden');
  }
  
  closeConfirmDeleteModal() {
    const modal = document.getElementById('editorConfirmDeleteModal');
    if (modal) {
      modal.classList.add('hidden');
    }
    this.deleteCallback = null;
  }

  togglePlayerPanel() {
    const panel = document.getElementById('editorPlayerPanel');
    const toolbarBtn = document.getElementById('editorPlayerPanelBtn');
    
    if (panel) {
      panel.classList.toggle('collapsed');
      const isCollapsed = panel.classList.contains('collapsed');
      
      // Update toolbar button state
      if (toolbarBtn) {
        toolbarBtn.classList.toggle('active', !isCollapsed);
      }
    }
  }

  initPlayerAssignPopup() {
    const closeBtn = document.getElementById('editorClosePlayerAssignPopup');
    const clearBtn = document.getElementById('editorClearPlayerAssign');
    const popup = document.getElementById('editorPlayerAssignPopup');
    
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closePlayerAssignPopup());
    }
    
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        if (this.assigningToDrawingIndex !== null) {
          const drawing = this.drawings[this.assigningToDrawingIndex];
          if (drawing) {
            drawing.number = '';
            drawing.surname = '';
            drawing.playerId = null;
            this.saveState();
            this.redraw();
            this.closePlayerAssignPopup();
            
            // Update toolbar controls
            const tshirtNumberInput = document.getElementById('editorTshirtNumber');
            const tshirtSurnameInput = document.getElementById('editorTshirtSurname');
            if (tshirtNumberInput) tshirtNumberInput.value = '';
            if (tshirtSurnameInput) tshirtSurnameInput.value = '';
            this.updateAssignPlayerButton();
          }
        }
      });
    }
    
    if (popup) {
      popup.addEventListener('click', (e) => {
        if (e.target === popup) {
          this.closePlayerAssignPopup();
        }
      });
    }
    
    // Track which drawing we're assigning to
    this.assigningToDrawingIndex = null;
  }

  openPlayerAssignPopup(drawingIndex) {
    const popup = document.getElementById('editorPlayerAssignPopup');
    const title = document.getElementById('editorPlayerAssignTitle');
    const info = document.getElementById('editorPlayerAssignInfo');
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const searchContainer = document.getElementById('editorPlayerAssignSearchContainer');
    
    if (!popup || !list) {
      console.error('Popup or list element not found');
      return;
    }
    
    const drawing = this.drawings[drawingIndex];
    if (!drawing || drawing.type !== 'tshirt') return;
    
    this.assigningToDrawingIndex = drawingIndex;
    
    const assignPlayerText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.assignPlayerButton')
      : 'Assign Player';
    title.textContent = assignPlayerText;
    list.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">Loading...</div>';
    if (info) info.textContent = '';
    
    // Hide search container for player assignment
    if (searchContainer) {
      searchContainer.style.display = 'none';
    }
    
    // Show popup immediately
    popup.classList.remove('hidden');
    popup.style.display = 'flex';
    popup.style.zIndex = '10002';
    
    // Load teams and players
    this.loadTeamsAndPlayersForAssignment(drawingIndex, drawing.team);
  }
  
  loadTeamsAndPlayersForAssignment(drawingIndex, currentTeamName) {
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const info = document.getElementById('editorPlayerAssignInfo');
    
    if (!list) return;
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      list.innerHTML = '<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Unable to access storage</div>';
      return;
    }
    
    // Load teams and players in one call
    chrome.storage.local.get(['analyses', 'currentAnalysisId', 'players'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error loading data:', chrome.runtime.lastError);
        list.innerHTML = `<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Error: ${chrome.runtime.lastError.message}</div>`;
        return;
      }
      
      const analyses = result.analyses || [];
      const currentAnalysisId = this.currentAnalysisId || result.currentAnalysisId;
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const players = result.players || [];
      
      // Get all unique teams from players
      const allTeams = [...new Set(players.map(p => p.team).filter(Boolean))];
      
      // Also get teams from analysis
      let analysisTeams = [];
      if (analysis && analysis.teams) {
        analysisTeams = analysis.teams.map(t => typeof t === 'object' ? t.name : t);
      }
      
      // Combine and deduplicate teams
      const availableTeams = [...new Set([...analysisTeams, ...allTeams])];
      
      console.log('Available teams:', availableTeams);
      console.log('Total players:', players.length);
      
      // Populate team selector
      if (teamSelect) {
        const allTeamsText = (window.i18n && typeof window.i18n.t === 'function') 
          ? window.i18n.t('commentsDatabase.allTeams')
          : 'All Teams';
        teamSelect.innerHTML = `<option value="">${allTeamsText}</option>`;
        availableTeams.forEach(team => {
          const option = document.createElement('option');
          option.value = team;
          option.textContent = team;
          if (team === currentTeamName) {
            option.selected = true;
          }
          teamSelect.appendChild(option);
        });
        
        // Remove old listener and add new one
        const newTeamSelect = teamSelect.cloneNode(true);
        teamSelect.parentNode.replaceChild(newTeamSelect, teamSelect);
        
        // Add event listener for team selection
        newTeamSelect.addEventListener('change', (e) => {
          const selectedTeam = e.target.value || null;
          this.displayPlayersForTeam(selectedTeam, drawingIndex, players);
        });
      }
      
      // Display players for current team (or all if no team)
      const teamToShow = currentTeamName || null;
      this.displayPlayersForTeam(teamToShow, drawingIndex, players);
    });
  }
  
  displayPlayersForTeam(teamName, drawingIndex, allPlayers) {
    const list = document.getElementById('editorPlayerAssignList');
    const info = document.getElementById('editorPlayerAssignInfo');
    const drawing = this.drawings[drawingIndex];
    
    if (!list || !drawing) return;
    
    // Filter players by team (case-insensitive)
    const teamPlayers = teamName 
      ? allPlayers.filter(p => {
          const playerTeam = (p.team || '').trim().toLowerCase();
          const searchTeam = teamName.trim().toLowerCase();
          return playerTeam === searchTeam;
        })
      : allPlayers;
    
    // Sort by number
    teamPlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
    
    console.log('Displaying players', { teamName, count: teamPlayers.length, total: allPlayers.length });
    
    // Update info
    if (info) {
      if (teamName) {
        const teamLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.team')
          : 'Team';
        const playerLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.playersLabel')
          : 'player';
        info.textContent = `${teamLabel}: ${teamName} (${teamPlayers.length} ${playerLabel}${teamPlayers.length !== 1 ? 's' : ''})`;
      } else {
        const allTeamsText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('commentsDatabase.allTeams')
          : 'All Teams';
        const playerLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.playersLabel')
          : 'player';
        info.textContent = `${allTeamsText} (${teamPlayers.length} ${playerLabel}${teamPlayers.length !== 1 ? 's' : ''})`;
      }
    }
    
    // Clear and populate list
    list.innerHTML = '';
    
    if (teamPlayers.length === 0) {
      list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
        ${teamName 
          ? (window.i18n && typeof window.i18n.t === 'function' 
              ? window.i18n.t('editor.noPlayersFoundForTeam', { teamName }) 
              : `No players found for team "${teamName}"`)
          : (window.i18n && typeof window.i18n.t === 'function' 
              ? window.i18n.t('editor.noPlayersFoundInStorage') 
              : 'No players found in storage')}<br><br>
        ${window.i18n && typeof window.i18n.t === 'function' 
          ? window.i18n.t('editor.totalPlayersInStorage', { count: allPlayers.length })
          : `Total players in storage: ${allPlayers.length}`}
      </div>`;
      return;
    }
    
    teamPlayers.forEach(player => {
      const isCurrentPlayer = drawing.playerId === player.id;
      
      const playerItem = document.createElement('div');
      playerItem.style.cssText = `
        display: flex;
        align-items: center;
        padding: 10px 12px;
        margin-bottom: 4px;
        background: ${isCurrentPlayer ? '#1f6feb' : '#0d1117'};
        border: 1px solid ${isCurrentPlayer ? '#58a6ff' : '#21262d'};
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
      `;
      
      const numberSpan = document.createElement('span');
      numberSpan.style.cssText = `
        width: 32px;
        height: 32px;
        background: ${isCurrentPlayer ? 'rgba(255,255,255,0.2)' : '#21262d'};
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        color: #c9d1d9;
        margin-right: 12px;
        flex-shrink: 0;
      `;
      numberSpan.textContent = player.number || '?';
      
      const infoDiv = document.createElement('div');
      infoDiv.style.cssText = 'flex: 1; min-width: 0;';
      
      const nameSpan = document.createElement('div');
      nameSpan.style.cssText = 'font-size: 13px; color: #c9d1d9; font-weight: 500; margin-bottom: 2px;';
      // Show surname (last name) in uppercase
      const fullName = player.fullName || 'Unknown';
      const surname = fullName.split(' ').pop().toUpperCase();
      nameSpan.textContent = surname;
      
      const positionSpan = document.createElement('div');
      positionSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
      positionSpan.textContent = player.position || '';
      
      infoDiv.appendChild(nameSpan);
      infoDiv.appendChild(positionSpan);
      
      playerItem.appendChild(numberSpan);
      playerItem.appendChild(infoDiv);
      
      playerItem.addEventListener('mouseenter', () => {
        if (!isCurrentPlayer) {
          playerItem.style.borderColor = '#30363d';
          playerItem.style.background = '#161b22';
        }
      });
      
      playerItem.addEventListener('mouseleave', () => {
        if (!isCurrentPlayer) {
          playerItem.style.borderColor = '#21262d';
          playerItem.style.background = '#0d1117';
        }
      });
      
      playerItem.addEventListener('click', () => {
        if (this.assigningToBench) {
          this.addPlayerToBench(player);
          this.closePlayerAssignPopup();
        } else {
          // Assign player's team to t-shirt if it doesn't have one
          if (!drawing.team && player.team) {
            drawing.team = player.team;
            this.saveState();
          }
          this.assignPlayerToDrawing(drawingIndex, player);
          this.closePlayerAssignPopup();
        }
      });
      
      list.appendChild(playerItem);
    });
  }
  
  loadPlayersForTeam_OLD(teamName, drawingIndex, popup, list, title, info) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    // Update info text
    if (info) {
      const infoText = teamName 
        ? (window.i18n && typeof window.i18n.t === 'function'
            ? window.i18n.t('editor.teamLabel', { teamName })
            : `Team: ${teamName}`)
        : (window.i18n && typeof window.i18n.t === 'function'
            ? window.i18n.t('editor.showingAllPlayers')
            : 'Showing all players');
      info.textContent = infoText;
    }
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      list.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">Unable to load players</div>';
      popup.classList.remove('hidden');
      popup.style.display = 'flex';
      console.log('Popup shown (no storage case)');
      return;
    }
    
    try {
      chrome.storage.local.get(['players'], (result) => {
        try {
          console.log('Players loaded from storage', { playerCount: result.players?.length || 0, teamName });
          
          // Check for errors
          if (chrome.runtime.lastError) {
            console.error('Error loading players:', chrome.runtime.lastError);
            list.innerHTML = `<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Error loading players: ${chrome.runtime.lastError.message}</div>`;
            popup.classList.remove('hidden');
            popup.style.display = 'flex';
            return;
          }
          
          const players = result.players || [];
          console.log('Total players in storage:', players.length);
          
          // If teamName is provided, filter by team; otherwise show all players
          // Use case-insensitive matching and trim whitespace
          let teamPlayers;
          if (teamName) {
            const searchTeam = teamName.trim().toLowerCase();
            teamPlayers = players.filter(p => {
              const playerTeam = (p.team || '').trim().toLowerCase();
              return playerTeam === searchTeam;
            });
            console.log(`Filtering for team "${teamName}":`, {
              found: teamPlayers.length,
              availableTeams: [...new Set(players.map(p => p.team).filter(Boolean))]
            });
          } else {
            teamPlayers = players;
            console.log('Showing all players (no team filter)');
          }
          
          console.log('Filtered players', { 
            teamPlayersCount: teamPlayers.length, 
            teamName, 
            totalPlayers: players.length,
            samplePlayers: teamPlayers.slice(0, 3).map(p => ({ name: p.fullName, team: p.team, number: p.number }))
          });
          
          if (teamPlayers.length === 0) {
            if (teamName) {
              const availableTeams = [...new Set(players.map(p => p.team).filter(Boolean))];
              const noPlayersTeamText = window.i18n && typeof window.i18n.t === 'function' 
                ? window.i18n.t('editor.noPlayersFoundForTeam', { teamName })
                : `No players found for team "${teamName}"`;
              const totalPlayersText = window.i18n && typeof window.i18n.t === 'function' 
                ? window.i18n.t('editor.totalPlayersInStorage', { count: players.length })
                : `Total players in storage: ${players.length}`;
              list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
                ${noPlayersTeamText}<br><br>
                ${totalPlayersText}<br>
                ${window.i18n && typeof window.i18n.t === 'function' 
                  ? window.i18n.t('editor.allTeams') + ': ' 
                  : 'Available teams: '}${availableTeams.length > 0 ? availableTeams.join(', ') : (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.noneOption') : 'None')}
              </div>`;
            } else {
              const noPlayersText = window.i18n && typeof window.i18n.t === 'function' 
                ? window.i18n.t('editor.noPlayersFoundInStorage')
                : 'No players found in storage';
              const addPlayersText = window.i18n && typeof window.i18n.t === 'function' 
                ? window.i18n.t('editor.pleaseAddPlayersToRoster')
                : 'Please add players to your team roster first.';
              list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
                ${noPlayersText}<br><br>
                ${addPlayersText}
              </div>`;
            }
            popup.classList.remove('hidden');
            popup.style.display = 'flex';
            console.log('Popup shown (no players case)');
          } else {
            teamPlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
            
            teamPlayers.forEach(player => {
              const isCurrentPlayer = drawing.playerId === player.id;
              
              const playerItem = document.createElement('div');
              playerItem.style.cssText = `
                display: flex;
                align-items: center;
                padding: 10px 12px;
                margin-bottom: 4px;
                background: ${isCurrentPlayer ? '#1f6feb' : '#0d1117'};
                border: 1px solid ${isCurrentPlayer ? '#58a6ff' : '#21262d'};
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.15s ease;
              `;
              
              const numberSpan = document.createElement('span');
              numberSpan.style.cssText = `
                width: 28px;
                height: 28px;
                background: ${isCurrentPlayer ? 'rgba(255,255,255,0.2)' : '#21262d'};
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 11px;
                font-weight: bold;
                color: #c9d1d9;
                margin-right: 10px;
              `;
              numberSpan.textContent = player.number || '?';
              
              const nameSpan = document.createElement('span');
              nameSpan.style.cssText = 'flex: 1; font-size: 13px; color: #c9d1d9;';
              nameSpan.textContent = player.fullName || 'Unknown';
              
              const posSpan = document.createElement('span');
              posSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
              posSpan.textContent = player.position || '';
              
              playerItem.appendChild(numberSpan);
              playerItem.appendChild(nameSpan);
              playerItem.appendChild(posSpan);
              
              playerItem.addEventListener('mouseenter', () => {
                if (!isCurrentPlayer) {
                  playerItem.style.borderColor = '#30363d';
                  playerItem.style.background = '#161b22';
                }
              });
              playerItem.addEventListener('mouseleave', () => {
                if (!isCurrentPlayer) {
                  playerItem.style.borderColor = '#21262d';
                  playerItem.style.background = '#0d1117';
                }
              });
              
              playerItem.addEventListener('click', () => {
                // If t-shirt doesn't have a team, assign the player's team
                if (!drawing.team && player.team) {
                  drawing.team = player.team;
                }
                this.assignPlayerToDrawing(drawingIndex, player);
                this.closePlayerAssignPopup();
              });
              
              list.appendChild(playerItem);
            });
          }
          
          // Ensure popup is visible
          popup.classList.remove('hidden');
          popup.style.display = 'flex';
          popup.style.zIndex = '10002';
          console.log('Popup updated with players', {
            playerCount: teamPlayers.length,
            hasHidden: popup.classList.contains('hidden'),
            display: popup.style.display
          });
        } catch (error) {
          console.error('Error in players callback:', error);
          list.innerHTML = `<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Error processing players: ${error.message}</div>`;
          popup.classList.remove('hidden');
          popup.style.display = 'flex';
        }
      });
    } catch (error) {
      console.error('Error accessing chrome.storage:', error);
      list.innerHTML = `<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Error accessing storage: ${error.message}</div>`;
      popup.classList.remove('hidden');
      popup.style.display = 'flex';
    }
  }

  closePlayerAssignPopup() {
    const popup = document.getElementById('editorPlayerAssignPopup');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const searchContainer = document.getElementById('editorPlayerAssignSearchContainer');
    const searchInput = document.getElementById('editorPlayerAssignSearch');
    if (popup) {
      popup.classList.add('hidden');
      popup.style.display = 'none';
      this.assigningToDrawingIndex = null;
      this.assigningToBench = false;
      this.assigningToEvents = false;
      this.assigningToPlayers = false;
      // Show team selector container again (it might have been hidden for events/players)
      if (teamSelect) {
        const teamSelectContainer = teamSelect.parentElement;
        if (teamSelectContainer) {
          teamSelectContainer.style.display = 'block';
        } else {
          teamSelect.style.display = 'block';
        }
      }
      // Hide search container
      if (searchContainer) {
        searchContainer.style.display = 'none';
      }
      if (searchInput) {
        searchInput.value = '';
        // Remove search handlers
        if (this.eventSearchHandler) {
          searchInput.removeEventListener('input', this.eventSearchHandler);
          searchInput.removeEventListener('keydown', this.eventSearchKeyHandler);
          this.eventSearchHandler = null;
          this.eventSearchKeyHandler = null;
        }
        if (this.playerSearchHandler) {
          searchInput.removeEventListener('input', this.playerSearchHandler);
          searchInput.removeEventListener('keydown', this.playerSearchKeyHandler);
          this.playerSearchHandler = null;
          this.playerSearchKeyHandler = null;
        }
      }
      console.log('Player assign popup closed');
    }
  }

  assignPlayerToDrawing(drawingIndex, player) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    drawing.number = player.number || '';
    drawing.surname = (player.fullName || '').split(' ').pop().toUpperCase();
    drawing.position = player.position || ''; // Store position
    drawing.playerId = player.id;
    
    // If t-shirt doesn't have a team, assign the player's team
    if (!drawing.team && player.team) {
      drawing.team = player.team;
    }
    
    this.saveState();
    this.redraw();
    
    // Update the assign button to show the player name
    this.updateAssignPlayerButton();
    
    // Update the number and surname inputs
    const tshirtNumberInput = document.getElementById('editorTshirtNumber');
    const tshirtSurnameInput = document.getElementById('editorTshirtSurname');
    if (tshirtNumberInput) tshirtNumberInput.value = drawing.number;
    if (tshirtSurnameInput) tshirtSurnameInput.value = drawing.surname;
  }

  openBenchPlayerAssignPopup() {
    const popup = document.getElementById('editorPlayerAssignPopup');
    const title = document.getElementById('editorPlayerAssignTitle');
    const info = document.getElementById('editorPlayerAssignInfo');
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    
    if (!popup || !list) {
      console.error('Popup or list element not found');
      return;
    }
    
    // Set flag to indicate this is for bench
    this.assigningToBench = true;
    
    const addPlayerToBenchText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.addPlayerToBench')
      : 'Add Player to Bench';
    title.textContent = addPlayerToBenchText;
    list.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">Loading...</div>';
    if (info) info.textContent = '';
    
    // Show popup immediately
    popup.classList.remove('hidden');
    popup.style.display = 'flex';
    popup.style.zIndex = '10002';
    
    // Load teams and players
    this.loadTeamsAndPlayersForBench();
  }
  
  loadTeamsAndPlayersForBench() {
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const info = document.getElementById('editorPlayerAssignInfo');
    
    if (!list) return;
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      list.innerHTML = '<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Unable to access storage</div>';
      return;
    }
    
    // Load teams and players
    chrome.storage.local.get(['analyses', 'currentAnalysisId', 'players'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error loading data:', chrome.runtime.lastError);
        list.innerHTML = `<div style="color: #f85149; font-size: 12px; padding: 12px; text-align: center;">Error: ${chrome.runtime.lastError.message}</div>`;
        return;
      }
      
      const analyses = result.analyses || [];
      const currentAnalysisId = this.currentAnalysisId || result.currentAnalysisId;
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const players = result.players || [];
      
      // Get all unique teams from players
      const allTeams = [...new Set(players.map(p => p.team).filter(Boolean))];
      
      // Also get teams from analysis
      let analysisTeams = [];
      if (analysis && analysis.teams) {
        analysisTeams = analysis.teams.map(t => typeof t === 'object' ? t.name : t);
      }
      
      // Combine and deduplicate teams
      const availableTeams = [...new Set([...analysisTeams, ...allTeams])];
      
      // Populate team selector
      if (teamSelect) {
        const allTeamsText = (window.i18n && typeof window.i18n.t === 'function') 
          ? window.i18n.t('commentsDatabase.allTeams')
          : 'All Teams';
        teamSelect.innerHTML = `<option value="">${allTeamsText}</option>`;
        availableTeams.forEach(team => {
          const option = document.createElement('option');
          option.value = team;
          option.textContent = team;
          teamSelect.appendChild(option);
        });
        
        // Remove old listener and add new one
        const newTeamSelect = teamSelect.cloneNode(true);
        teamSelect.parentNode.replaceChild(newTeamSelect, teamSelect);
        
        // Add event listener for team selection
        newTeamSelect.addEventListener('change', (e) => {
          const selectedTeam = e.target.value || null;
          this.displayPlayersForBench(selectedTeam, players);
        });
      }
      
      // Display all players initially
      this.displayPlayersForBench(null, players);
    });
  }
  
  displayPlayersForBench(teamName, allPlayers) {
    const list = document.getElementById('editorPlayerAssignList');
    const info = document.getElementById('editorPlayerAssignInfo');
    
    if (!list) return;
    
    // Get current bench players to avoid duplicates
    const currentSlide = this.slides[this.currentSlideIndex];
    const benchPlayers = currentSlide?.benchPlayers || [];
    const benchPlayerIds = new Set(benchPlayers.map(p => p.id));
    
    // Filter players by team (case-insensitive)
    const teamPlayers = teamName 
      ? allPlayers.filter(p => {
          const playerTeam = (p.team || '').trim().toLowerCase();
          const searchTeam = teamName.trim().toLowerCase();
          return playerTeam === searchTeam;
        })
      : allPlayers;
    
    // Filter out players already on bench
    const availablePlayers = teamPlayers.filter(p => !benchPlayerIds.has(p.id));
    
    // Sort by number
    availablePlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
    
    // Update info
    if (info) {
      if (teamName) {
        const teamLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.team')
          : 'Team';
        const availableText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.available')
          : 'available';
        const playerLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.playersLabel')
          : 'player';
        info.textContent = `${teamLabel}: ${teamName} (${availablePlayers.length} ${availableText} ${playerLabel}${availablePlayers.length !== 1 ? 's' : ''})`;
      } else {
        const allTeamsText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('commentsDatabase.allTeams')
          : 'All Teams';
        const availableText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.available')
          : 'available';
        const playerLabel = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.playersLabel')
          : 'player';
        info.textContent = `${allTeamsText} (${availablePlayers.length} ${availableText} ${playerLabel}${availablePlayers.length !== 1 ? 's' : ''})`;
      }
    }
    
    // Clear and populate list
    list.innerHTML = '';
    
    if (availablePlayers.length === 0) {
      list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
        ${teamName ? `No available players for team "${teamName}"` : 'No available players'}<br><br>
        ${benchPlayers.length > 0 ? `${benchPlayers.length} player${benchPlayers.length !== 1 ? 's' : ''} already on bench` : ''}
      </div>`;
      return;
    }
    
    availablePlayers.forEach(player => {
      const playerItem = document.createElement('div');
      playerItem.style.cssText = `
        display: flex;
        align-items: center;
        padding: 10px 12px;
        margin-bottom: 4px;
        background: #0d1117;
        border: 1px solid #21262d;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
      `;
      
      const numberSpan = document.createElement('span');
      numberSpan.style.cssText = `
        width: 32px;
        height: 32px;
        background: #21262d;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        color: #c9d1d9;
        margin-right: 12px;
        flex-shrink: 0;
      `;
      numberSpan.textContent = player.number || '?';
      
      const infoDiv = document.createElement('div');
      infoDiv.style.cssText = 'flex: 1; min-width: 0;';
      
      const nameSpan = document.createElement('div');
      nameSpan.style.cssText = 'font-size: 13px; color: #c9d1d9; font-weight: 500; margin-bottom: 2px;';
      const fullName = player.fullName || 'Unknown';
      const surname = fullName.split(' ').pop().toUpperCase();
      nameSpan.textContent = surname;
      
      const positionSpan = document.createElement('div');
      positionSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
      positionSpan.textContent = player.position || '';
      
      infoDiv.appendChild(nameSpan);
      infoDiv.appendChild(positionSpan);
      
      playerItem.appendChild(numberSpan);
      playerItem.appendChild(infoDiv);
      
      playerItem.addEventListener('mouseenter', () => {
        playerItem.style.borderColor = '#30363d';
        playerItem.style.background = '#161b22';
      });
      
      playerItem.addEventListener('mouseleave', () => {
        playerItem.style.borderColor = '#21262d';
        playerItem.style.background = '#0d1117';
      });
      
      playerItem.addEventListener('click', () => {
        this.addPlayerToBench(player);
        this.closePlayerAssignPopup();
      });
      
      list.appendChild(playerItem);
    });
  }
  
  addPlayerToBench(player) {
    if (!this.slides[this.currentSlideIndex]) return;
    
    // Initialize benchPlayers array if it doesn't exist
    if (!this.slides[this.currentSlideIndex].benchPlayers) {
      this.slides[this.currentSlideIndex].benchPlayers = [];
    }
    
    // Check if player is already on bench
    const existingIndex = this.slides[this.currentSlideIndex].benchPlayers.findIndex(p => p.id === player.id);
    if (existingIndex !== -1) {
      showNotification('Player is already on the bench', 'warning', 2000);
      return;
    }
    
    // Add player to bench
    this.slides[this.currentSlideIndex].benchPlayers.push({
      id: player.id,
      number: player.number || '',
      fullName: player.fullName || '',
      surname: (player.fullName || '').split(' ').pop().toUpperCase(),
      position: player.position || '',
      team: player.team || null
    });
    
    this.saveState();
    this.updateBenchDisplay();
    showNotification('Player added to bench', 'success', 2000);
  }
  
  removePlayerFromBench(playerId) {
    if (!this.slides[this.currentSlideIndex] || !this.slides[this.currentSlideIndex].benchPlayers) return;
    
    const benchPlayers = this.slides[this.currentSlideIndex].benchPlayers;
    const index = benchPlayers.findIndex(p => p.id === playerId);
    if (index !== -1) {
      benchPlayers.splice(index, 1);
      this.saveState();
      this.updateBenchDisplay();
      showNotification('Player removed from bench', 'info', 2000);
    }
  }
  
  updateEventsDisplay() {
    const eventsList = document.getElementById('editorEventsList');
    if (!eventsList) return;
    
    if (this.selectedDrawings.length === 0) {
      eventsList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No events attached</div>';
      return;
    }
    
    const selectedDrawing = this.drawings[this.selectedDrawings[0]];
    if (!selectedDrawing) {
      eventsList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No events attached</div>';
      return;
    }
    
    const attachedEvents = selectedDrawing.events || [];
    eventsList.innerHTML = '';
    
    if (attachedEvents.length === 0) {
      eventsList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No events attached</div>';
      return;
    }
    
    attachedEvents.forEach(eventName => {
      const eventItem = document.createElement('div');
      eventItem.style.cssText = `
        display: flex;
        align-items: center;
        gap: 3px;
        padding: 3px 6px;
        background: #21262d;
        border: 1px solid #30363d;
        border-radius: 3px;
        font-size: 10px;
        color: #c9d1d9;
        position: relative;
      `;
      
      const eventNameSpan = document.createElement('span');
      eventNameSpan.textContent = eventName;
      eventNameSpan.style.cssText = 'flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
      
      const removeBtn = document.createElement('button');
      removeBtn.innerHTML = '×';
      removeBtn.style.cssText = `
        margin-left: 2px;
        background: none;
        border: none;
        color: #8b949e;
        cursor: pointer;
        font-size: 12px;
        line-height: 1;
        padding: 0;
        width: 12px;
        height: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 2px;
        transition: all 0.15s ease;
        flex-shrink: 0;
      `;
      removeBtn.addEventListener('mouseenter', () => {
        removeBtn.style.color = '#f85149';
        removeBtn.style.background = '#21262d';
      });
      removeBtn.addEventListener('mouseleave', () => {
        removeBtn.style.color = '#8b949e';
        removeBtn.style.background = 'none';
      });
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.removeEventFromDrawing(this.selectedDrawings[0], eventName);
      });
      
      eventItem.appendChild(eventNameSpan);
      eventItem.appendChild(removeBtn);
      eventsList.appendChild(eventItem);
    });
  }
  
  updatePlayersDisplay() {
    const playersList = document.getElementById('editorPlayersList');
    if (!playersList) return;
    
    if (this.selectedDrawings.length === 0) {
      playersList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No players attached</div>';
      return;
    }
    
    const selectedDrawing = this.drawings[this.selectedDrawings[0]];
    if (!selectedDrawing) {
      playersList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No players attached</div>';
      return;
    }
    
    const attachedPlayerIds = selectedDrawing.players || [];
    playersList.innerHTML = '';
    
    if (attachedPlayerIds.length === 0) {
      playersList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No players attached</div>';
      return;
    }
    
    // Load players from storage to get their details
    if (typeof chrome === 'undefined' || !chrome.storage) {
      playersList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">Unable to load players</div>';
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const allPlayers = result.players || [];
      const attachedPlayers = allPlayers.filter(p => attachedPlayerIds.includes(p.id));
      
      if (attachedPlayers.length === 0) {
        playersList.innerHTML = '<div style="color: #6e7681; font-size: 10px; font-style: italic; width: 100%; text-align: center; padding: 6px 0;">No players attached</div>';
        return;
      }
      
      attachedPlayers.forEach(player => {
        const playerItem = document.createElement('div');
        playerItem.style.cssText = `
          display: flex;
          align-items: center;
          gap: 3px;
          padding: 3px 6px;
          background: #21262d;
          border: 1px solid #30363d;
          border-radius: 3px;
          font-size: 10px;
          color: #c9d1d9;
          position: relative;
        `;
        
        const playerNameSpan = document.createElement('span');
        const displayText = player.number ? 
          `#${player.number} ${player.fullName || ''}`.trim() : 
          (player.fullName || 'Unnamed');
        playerNameSpan.textContent = displayText;
        playerNameSpan.style.cssText = 'flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
        
        const removeBtn = document.createElement('button');
        removeBtn.innerHTML = '×';
        removeBtn.style.cssText = `
          margin-left: 2px;
          background: none;
          border: none;
          color: #8b949e;
          cursor: pointer;
          font-size: 12px;
          line-height: 1;
          padding: 0;
          width: 12px;
          height: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 2px;
          transition: all 0.15s ease;
          flex-shrink: 0;
        `;
        removeBtn.addEventListener('mouseenter', () => {
          removeBtn.style.color = '#f85149';
          removeBtn.style.background = '#21262d';
        });
        removeBtn.addEventListener('mouseleave', () => {
          removeBtn.style.color = '#8b949e';
          removeBtn.style.background = 'none';
        });
        removeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          e.preventDefault();
          this.removePlayerFromDrawing(this.selectedDrawings[0], player.id);
        });
        
        playerItem.appendChild(playerNameSpan);
        playerItem.appendChild(removeBtn);
        playersList.appendChild(playerItem);
      });
    });
  }
  
  openEventAssignPopup(drawingIndex) {
    const popup = document.getElementById('editorPlayerAssignPopup');
    const title = document.getElementById('editorPlayerAssignTitle');
    const info = document.getElementById('editorPlayerAssignInfo');
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const searchContainer = document.getElementById('editorPlayerAssignSearchContainer');
    const searchInput = document.getElementById('editorPlayerAssignSearch');
    
    if (!popup || !list) {
      console.error('Popup or list element not found');
      return;
    }
    
    // Set flag to indicate this is for events
    this.assigningToEvents = true;
    this.assigningToDrawingIndex = drawingIndex;
    
    title.textContent = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.attachEventToObject')
      : 'Attach Event to Object';
    list.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">Loading...</div>';
    if (info) info.textContent = '';
    
    // Show search container for events
    if (searchContainer) {
      searchContainer.style.display = 'block';
    }
    if (searchInput) {
      searchInput.value = '';
      // Focus on search input
      setTimeout(() => searchInput.focus(), 100);
      
      // Set up search event listener (remove old one if exists, then add new)
      const oldHandler = this.eventSearchHandler;
      const oldKeyHandler = this.eventSearchKeyHandler;
      if (oldHandler) {
        searchInput.removeEventListener('input', oldHandler);
      }
      if (oldKeyHandler) {
        searchInput.removeEventListener('keydown', oldKeyHandler);
      }
      
      const handleSearch = () => {
        const searchQuery = searchInput.value;
        const drawing = this.drawings[drawingIndex];
        if (!drawing) return;
        
        const attachedEvents = drawing.events || [];
        
        // Reload events with search filter
        if (typeof chrome === 'undefined' || !chrome.storage) {
          this.displayEventsForAssignment(list, info, attachedEvents, [], searchQuery);
          return;
        }
        
        chrome.storage.local.get(['customEvents'], (result) => {
          const customEvents = result.customEvents || [];
          this.displayEventsForAssignment(list, info, attachedEvents, customEvents, searchQuery);
        });
      };
      
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          searchInput.value = '';
          handleSearch();
        }
      };
      
      // Store handlers for cleanup
      this.eventSearchHandler = handleSearch;
      this.eventSearchKeyHandler = handleKeyDown;
      
      // Add event listeners
      searchInput.addEventListener('input', handleSearch);
      searchInput.addEventListener('keydown', handleKeyDown);
    }
    
    // Hide team selector container (label + select) for events
    if (teamSelect) {
      const teamSelectContainer = teamSelect.parentElement;
      if (teamSelectContainer) {
        teamSelectContainer.style.display = 'none';
      } else {
        // Fallback: hide select and label separately
        teamSelect.style.display = 'none';
        const teamSelectLabel = teamSelect.previousElementSibling;
        if (teamSelectLabel && teamSelectLabel.tagName === 'LABEL') {
          teamSelectLabel.style.display = 'none';
        }
      }
    }
    
    // Show popup immediately
    popup.classList.remove('hidden');
    popup.style.display = 'flex';
    popup.style.zIndex = '10002';
    
    // Load events
    this.loadEventsForAssignment(drawingIndex);
  }
  
  loadEventsForAssignment(drawingIndex) {
    const list = document.getElementById('editorPlayerAssignList');
    const info = document.getElementById('editorPlayerAssignInfo');
    
    if (!list) return;
    
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    const attachedEvents = drawing.events || [];
    
    // Load custom events from storage
    if (typeof chrome === 'undefined' || !chrome.storage) {
      this.displayEventsForAssignment(list, info, attachedEvents, []);
      return;
    }
    
    chrome.storage.local.get(['customEvents'], (result) => {
      const customEvents = result.customEvents || [];
      this.displayEventsForAssignment(list, info, attachedEvents, customEvents);
    });
  }
  
  displayEventsForAssignment(list, info, attachedEvents, customEvents, searchQuery = '') {
    if (!list) return;
    
    list.innerHTML = '';
    
    // Get all events (standard + custom)
    const allEvents = [];
    EVENT_CATEGORIES.forEach(category => {
      category.events.forEach(event => {
        allEvents.push({ name: event, category: category.name, isCustom: false });
      });
    });
    
    customEvents.forEach(event => {
      const eventName = typeof event === 'string' ? event : event.name;
      const eventCategory = typeof event === 'string' ? 'Custom' : (event.category || 'Custom');
      allEvents.push({ name: eventName, category: eventCategory, isCustom: true });
    });
    
    // Filter out already attached events
    let availableEvents = allEvents.filter(e => !attachedEvents.includes(e.name));
    
    // Apply search filter if provided - only filter by event name, not category
    if (searchQuery && searchQuery.trim()) {
      const query = searchQuery.trim().toLowerCase();
      availableEvents = availableEvents.filter(event => 
        event.name.toLowerCase().includes(query)
      );
    }
    
    // Store full event list for filtering
    this.allAvailableEvents = availableEvents;
    
    // Group by category
    const eventsByCategory = {};
    availableEvents.forEach(event => {
      if (!eventsByCategory[event.category]) {
        eventsByCategory[event.category] = [];
      }
      eventsByCategory[event.category].push(event);
    });
    
    // Update info
    if (info) {
      const totalAvailable = allEvents.filter(e => !attachedEvents.includes(e.name)).length;
      if (searchQuery && searchQuery.trim()) {
        info.textContent = `${availableEvents.length} of ${totalAvailable} event${totalAvailable !== 1 ? 's' : ''} shown`;
      } else {
      info.textContent = `${availableEvents.length} available event${availableEvents.length !== 1 ? 's' : ''}`;
      }
    }
    
    if (availableEvents.length === 0) {
      if (searchQuery && searchQuery.trim()) {
        list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
          No events found matching "${searchQuery}"
        </div>`;
      } else {
      list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
        All events are already attached
      </div>`;
      }
      return;
    }
    
    // Display events by category
    Object.keys(eventsByCategory).sort().forEach(categoryName => {
      const categoryDiv = document.createElement('div');
      categoryDiv.style.cssText = 'margin-bottom: 16px;';
      
      const categoryHeader = document.createElement('div');
      categoryHeader.style.cssText = 'font-size: 11px; font-weight: 600; color: #6e7681; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; padding: 4px 0;';
      categoryHeader.textContent = categoryName;
      categoryDiv.appendChild(categoryHeader);
      
      eventsByCategory[categoryName].forEach(event => {
        const eventItem = document.createElement('div');
        eventItem.style.cssText = `
          display: flex;
          align-items: center;
          padding: 10px 12px;
          margin-bottom: 4px;
          background: #0d1117;
          border: 1px solid #21262d;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.15s ease;
        `;
        
        const eventNameSpan = document.createElement('span');
        eventNameSpan.style.cssText = 'font-size: 13px; color: #c9d1d9; flex: 1;';
        eventNameSpan.textContent = event.name;
        
        eventItem.appendChild(eventNameSpan);
        
        eventItem.addEventListener('mouseenter', () => {
          eventItem.style.borderColor = '#30363d';
          eventItem.style.background = '#161b22';
        });
        
        eventItem.addEventListener('mouseleave', () => {
          eventItem.style.borderColor = '#21262d';
          eventItem.style.background = '#0d1117';
        });
        
        eventItem.addEventListener('click', () => {
          this.attachEventToDrawing(this.assigningToDrawingIndex, event.name);
          this.closePlayerAssignPopup();
        });
        
        categoryDiv.appendChild(eventItem);
      });
      
      list.appendChild(categoryDiv);
    });
  }
  
  openPlayerAttachPopup(drawingIndex) {
    const popup = document.getElementById('editorPlayerAssignPopup');
    const title = document.getElementById('editorPlayerAssignTitle');
    const info = document.getElementById('editorPlayerAssignInfo');
    const list = document.getElementById('editorPlayerAssignList');
    const teamSelect = document.getElementById('editorPlayerAssignTeamSelect');
    const searchContainer = document.getElementById('editorPlayerAssignSearchContainer');
    const searchInput = document.getElementById('editorPlayerAssignSearch');
    
    if (!popup || !list) {
      console.error('Popup or list element not found');
      return;
    }
    
    // Set flag to indicate this is for attaching players (multiple)
    this.assigningToEvents = false;
    this.assigningToPlayers = true;
    this.assigningToDrawingIndex = drawingIndex;
    
    title.textContent = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.attachPlayerToObject')
      : 'Attach Player to Object';
    list.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">Loading...</div>';
    if (info) info.textContent = '';
    
    // Show search container for player attachment
    if (searchContainer) {
      searchContainer.style.display = 'block';
    }
    if (searchInput) {
      searchInput.value = '';
      // Focus on search input
      setTimeout(() => searchInput.focus(), 100);
      
      // Set up search event listener (remove old one if exists, then add new)
      const oldHandler = this.playerSearchHandler;
      const oldKeyHandler = this.playerSearchKeyHandler;
      if (oldHandler) {
        searchInput.removeEventListener('input', oldHandler);
      }
      if (oldKeyHandler) {
        searchInput.removeEventListener('keydown', oldKeyHandler);
      }
      
      const handleSearch = () => {
        const searchQuery = searchInput.value;
        this.loadPlayersForAttachment(drawingIndex, searchQuery);
      };
      
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          searchInput.value = '';
          handleSearch();
        }
      };
      
      // Store handlers for cleanup
      this.playerSearchHandler = handleSearch;
      this.playerSearchKeyHandler = handleKeyDown;
      
      // Add event listeners
      searchInput.addEventListener('input', handleSearch);
      searchInput.addEventListener('keydown', handleKeyDown);
    }
    
    // Hide team selector container (label + select) for player attachment
    if (teamSelect) {
      const teamSelectContainer = teamSelect.parentElement;
      if (teamSelectContainer) {
        teamSelectContainer.style.display = 'none';
      } else {
        // Fallback: hide select and label separately
        teamSelect.style.display = 'none';
        const teamSelectLabel = teamSelect.previousElementSibling;
        if (teamSelectLabel && teamSelectLabel.tagName === 'LABEL') {
          teamSelectLabel.style.display = 'none';
        }
      }
    }
    
    // Show popup immediately
    popup.classList.remove('hidden');
    popup.style.display = 'flex';
    popup.style.zIndex = '10002';
    
    // Load players
    this.loadPlayersForAttachment(drawingIndex);
  }
  
  loadPlayersForAttachment(drawingIndex, searchQuery = '') {
    const list = document.getElementById('editorPlayerAssignList');
    const info = document.getElementById('editorPlayerAssignInfo');
    
    if (!list) return;
    
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    const attachedPlayerIds = drawing.players || [];
    
    // Load players from storage
    if (typeof chrome === 'undefined' || !chrome.storage) {
      this.displayPlayersForAssignment(list, info, attachedPlayerIds, [], searchQuery);
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const allPlayers = result.players || [];
      this.displayPlayersForAssignment(list, info, attachedPlayerIds, allPlayers, searchQuery);
    });
  }
  
  displayPlayersForAssignment(list, info, attachedPlayerIds, allPlayers, searchQuery = '') {
    if (!list) return;
    
    list.innerHTML = '';
    
    // Filter out already attached players
    let availablePlayers = allPlayers.filter(p => !attachedPlayerIds.includes(p.id));
    
    // Apply search filter if provided - search by name, number, or position
    if (searchQuery && searchQuery.trim()) {
      const query = searchQuery.trim().toLowerCase();
      availablePlayers = availablePlayers.filter(player => {
        const fullName = (player.fullName || '').toLowerCase();
        const number = (player.number || '').toString().toLowerCase();
        const position = (player.position || '').toLowerCase();
        const team = (player.team || '').toLowerCase();
        return fullName.includes(query) || 
               number.includes(query) || 
               position.includes(query) ||
               team.includes(query);
      });
    }
    
    // Update info
    if (info) {
      const totalAvailable = allPlayers.filter(p => !attachedPlayerIds.includes(p.id)).length;
      if (searchQuery && searchQuery.trim()) {
        info.textContent = `${availablePlayers.length} of ${totalAvailable} player${totalAvailable !== 1 ? 's' : ''} shown`;
      } else {
        info.textContent = `${availablePlayers.length} available player${availablePlayers.length !== 1 ? 's' : ''}`;
      }
    }
    
    if (availablePlayers.length === 0) {
      if (searchQuery && searchQuery.trim()) {
        list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
          ${window.i18n && typeof window.i18n.t === 'function' 
            ? window.i18n.t('editor.noPlayersFoundMatching', { searchQuery })
            : `No players found matching "${searchQuery}"`}
        </div>`;
      } else {
        list.innerHTML = `<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">
          All players are already attached
        </div>`;
      }
      return;
    }
    
    // Group by team
    const playersByTeam = {};
    availablePlayers.forEach(player => {
      const team = player.team || 'No Team';
      if (!playersByTeam[team]) {
        playersByTeam[team] = [];
      }
      playersByTeam[team].push(player);
    });
    
    // Display players by team
    Object.keys(playersByTeam).sort().forEach(teamName => {
      const teamDiv = document.createElement('div');
      teamDiv.style.cssText = 'margin-bottom: 16px;';
      
      const teamHeader = document.createElement('div');
      teamHeader.style.cssText = 'font-size: 11px; font-weight: 600; color: #6e7681; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; padding: 4px 0;';
      teamHeader.textContent = teamName;
      teamDiv.appendChild(teamHeader);
      
      playersByTeam[teamName].forEach(player => {
        const playerItem = document.createElement('div');
        playerItem.style.cssText = `
          display: flex;
          align-items: center;
          padding: 10px 12px;
          margin-bottom: 4px;
          background: #0d1117;
          border: 1px solid #21262d;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.15s ease;
        `;
        
        const playerInfo = document.createElement('div');
        playerInfo.style.cssText = 'flex: 1; display: flex; flex-direction: column; gap: 2px;';
        
        const playerNameSpan = document.createElement('span');
        playerNameSpan.style.cssText = 'font-size: 13px; color: #c9d1d9;';
        const displayText = player.number ? 
          `#${player.number} ${player.fullName || ''}`.trim() : 
          (player.fullName || 'Unnamed');
        playerNameSpan.textContent = displayText;
        playerInfo.appendChild(playerNameSpan);
        
        if (player.position) {
          const positionSpan = document.createElement('span');
          positionSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
          positionSpan.textContent = player.position;
          playerInfo.appendChild(positionSpan);
        }
        
        playerItem.appendChild(playerInfo);
        
        playerItem.addEventListener('mouseenter', () => {
          playerItem.style.borderColor = '#30363d';
          playerItem.style.background = '#161b22';
        });
        
        playerItem.addEventListener('mouseleave', () => {
          playerItem.style.borderColor = '#21262d';
          playerItem.style.background = '#0d1117';
        });
        
        playerItem.addEventListener('click', () => {
          this.attachPlayerToDrawing(this.assigningToDrawingIndex, player.id);
          // Reload the list to update attached players (don't close popup for multi-select)
          // Get current search query from input field
          const searchInput = document.getElementById('editorPlayerAssignSearch');
          const currentSearchQuery = searchInput ? searchInput.value : '';
          this.loadPlayersForAttachment(this.assigningToDrawingIndex, currentSearchQuery);
          // Update the players display in properties panel
          this.updatePlayersDisplay();
        });
        
        teamDiv.appendChild(playerItem);
      });
      
      list.appendChild(teamDiv);
    });
  }
  
  attachEventToDrawing(drawingIndex, eventName) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    // Initialize events array if it doesn't exist
    if (!drawing.events) {
      drawing.events = [];
    }
    
    // Check if event is already attached
    if (drawing.events.includes(eventName)) {
      showNotification('Event is already attached', 'warning', 2000);
      return;
    }
    
    // Add event
    drawing.events.push(eventName);
    
    this.saveState();
    this.updateEventsDisplay();
    showNotification('Event attached', 'success', 2000);
  }
  
  removeEventFromDrawing(drawingIndex, eventName) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing || !drawing.events) return;
    
    const index = drawing.events.indexOf(eventName);
    if (index !== -1) {
      drawing.events.splice(index, 1);
      this.saveState();
      this.updateEventsDisplay();
      showNotification('Event removed', 'info', 2000);
    }
  }
  
  attachPlayerToDrawing(drawingIndex, playerId) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing) return;
    
    // Initialize players array if it doesn't exist
    if (!drawing.players) {
      drawing.players = [];
    }
    
    // Check if player is already attached
    if (drawing.players.includes(playerId)) {
      showNotification('Player is already attached', 'warning', 2000);
      return;
    }
    
    // Add player
    drawing.players.push(playerId);
    
    this.saveState();
    this.updatePlayersDisplay();
    showNotification('Player attached', 'success', 2000);
  }
  
  removePlayerFromDrawing(drawingIndex, playerId) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing || !drawing.players) return;
    
    const index = drawing.players.indexOf(playerId);
    if (index !== -1) {
      drawing.players.splice(index, 1);
      this.saveState();
      this.updatePlayersDisplay();
      showNotification('Player removed', 'info', 2000);
    }
  }

  updateBenchDisplay() {
    const benchContent = document.getElementById('editorBenchContent');
    if (!benchContent) return;
    
    const currentSlide = this.slides[this.currentSlideIndex];
    const benchPlayers = currentSlide?.benchPlayers || [];
    
    benchContent.innerHTML = '';
    
    if (benchPlayers.length === 0) {
      const emptyDiv = document.createElement('div');
      emptyDiv.className = 'editor-bench-empty';
      const noBenchText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.noBenchPlayersAdded')
        : 'No bench players added';
      emptyDiv.textContent = noBenchText;
      benchContent.appendChild(emptyDiv);
      return;
    }
    
    benchPlayers.forEach(player => {
      const playerItem = document.createElement('div');
      playerItem.className = 'editor-bench-player-item';
      playerItem.draggable = true;
      
      const numberSpan = document.createElement('span');
      numberSpan.style.cssText = `
        width: 18px;
        height: 18px;
        background: #0d1117;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 10px;
        flex-shrink: 0;
      `;
      numberSpan.textContent = player.number || '?';
      
      const nameSpan = document.createElement('span');
      nameSpan.textContent = player.surname || '';
      nameSpan.style.cssText = 'font-weight: 500; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
      
      const removeBtn = document.createElement('button');
      removeBtn.innerHTML = '×';
      removeBtn.style.cssText = `
        margin-left: 4px;
        background: none;
        border: none;
        color: #8b949e;
        cursor: pointer;
        font-size: 14px;
        line-height: 1;
        padding: 0;
        width: 14px;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 2px;
        transition: all 0.15s ease;
        flex-shrink: 0;
      `;
      removeBtn.addEventListener('mouseenter', () => {
        removeBtn.style.color = '#f85149';
        removeBtn.style.background = '#21262d';
      });
      removeBtn.addEventListener('mouseleave', () => {
        removeBtn.style.color = '#8b949e';
        removeBtn.style.background = 'none';
      });
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.removePlayerFromBench(player.id);
      });
      
      // Drag event handlers
      playerItem.addEventListener('dragstart', (e) => {
        playerItem.classList.add('dragging');
        
        // Store player data for drop
        this.playerDragData = {
          id: player.id,
          number: player.number || '',
          fullName: player.fullName || player.surname || '',
          position: player.position || '',
          team: player.team || null
        };
        
        // Set drag image
        const dragPreview = document.createElement('div');
        dragPreview.style.cssText = `
          position: absolute;
          top: -1000px;
          background: #21262d;
          border: 1px solid #30363d;
          border-radius: 4px;
          padding: 4px 8px;
          color: #c9d1d9;
          font-size: 11px;
          pointer-events: none;
        `;
        dragPreview.textContent = `${player.number || '?'} ${player.surname || ''}`;
        document.body.appendChild(dragPreview);
        e.dataTransfer.setDragImage(dragPreview, 0, 0);
        
        setTimeout(() => {
          if (dragPreview.parentNode) {
            dragPreview.parentNode.removeChild(dragPreview);
          }
        }, 0);
        
        e.dataTransfer.effectAllowed = 'copy';
      });
      
      playerItem.addEventListener('dragend', () => {
        playerItem.classList.remove('dragging');
        // Don't clear playerDragData here - let the drop handler do it
      });
      
      playerItem.appendChild(numberSpan);
      playerItem.appendChild(nameSpan);
      playerItem.appendChild(removeBtn);
      benchContent.appendChild(playerItem);
    });
  }

  updateAssignPlayerButton() {
    const btn = document.getElementById('editorAssignPlayerBtn');
    const label = document.getElementById('editorAssignPlayerLabel');
    if (!btn || !label) return;
    
    // Get the first selected t-shirt
    let selectedTshirt = null;
    if (this.selectedDrawings.length > 0) {
      for (const index of this.selectedDrawings) {
        const drawing = this.drawings[index];
        if (drawing && drawing.type === 'tshirt') {
          selectedTshirt = drawing;
          break;
        }
      }
    }
    
    if (!selectedTshirt) {
      const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectPlayer')
        : 'Select Player...';
      label.textContent = selectPlayerText;
      btn.classList.remove('has-player');
      return;
    }
    
    if (selectedTshirt.playerId) {
      // Fetch player name
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const player = players.find(p => p.id === selectedTshirt.playerId);
          if (player) {
            const unknownText = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.unknown')
              : 'Unknown';
            label.textContent = `#${player.number || '?'} ${player.fullName || unknownText}`;
            btn.classList.add('has-player');
          } else {
            const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectPlayer')
        : 'Select Player...';
      label.textContent = selectPlayerText;
            btn.classList.remove('has-player');
          }
        });
      } else {
            const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.selectPlayer')
              : 'Select Player...';
            label.textContent = selectedTshirt.surname ? `#${selectedTshirt.number} ${selectedTshirt.surname}` : selectPlayerText;
        btn.classList.toggle('has-player', !!selectedTshirt.surname);
      }
    } else if (selectedTshirt.team) {
      const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectPlayer')
        : 'Select Player...';
      label.textContent = selectPlayerText;
      btn.classList.remove('has-player');
    } else {
      const noTeamAssignedText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.noTeamAssigned')
        : 'No team assigned';
      label.textContent = noTeamAssignedText;
      btn.classList.remove('has-player');
    }
  }

  populatePlayerPanelTeams() {
    // This now uses the new team selector UI
    this.renderEditorTeamSelector('');
  }

  renderEditorTeamSelector(searchQuery = '') {
    const teamList = document.getElementById('editorTeamList');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    if (!teamList || !teamSelect) return;
    
    if (!this.currentAnalysisId) {
      teamList.innerHTML = '<div style="padding: 10px; color: #8b949e; text-align: center; font-size: 13px;">No project selected</div>';
      return;
    }
    
    this.loadAllTeams()
      .then(teams => {
        // Get current analysis to check userTeam
        return new Promise((resolve) => {
          chrome.storage.local.get(['analyses'], (result) => {
            const analyses = result.analyses || [];
            const analysis = analyses.find(a => a.id === this.currentAnalysisId);
            const userTeam = analysis ? (analysis.userTeam || null) : null;
            resolve({ teams, userTeam });
          });
        });
      })
      .then(({ teams, userTeam }) => {
        const currentValue = teamSelect.value;
        
        // IMPORTANT: Sync the hidden select with all teams
        // This ensures teamSelect.value works correctly when read by other code
        const existingOptions = new Set();
        for (let i = 0; i < teamSelect.options.length; i++) {
          existingOptions.add(teamSelect.options[i].value);
        }
        teams.forEach(team => {
          if (team.name && !existingOptions.has(team.name)) {
            const option = document.createElement('option');
            option.value = team.name;
            option.textContent = team.name;
            teamSelect.appendChild(option);
          }
        });
        // Restore the previously selected value if it exists
        if (currentValue && teams.some(t => t.name === currentValue)) {
          teamSelect.value = currentValue;
        }
        
        // Filter teams by search query
        const filteredTeams = teams.filter(team => {
          const searchLower = searchQuery.toLowerCase();
          const teamName = team.name || '';
          return teamName.toLowerCase().includes(searchLower);
        });
        
        teamList.innerHTML = '';
        
        // Add "No team" option
        const noTeamItem = document.createElement('div');
        noTeamItem.style.display = 'flex';
        noTeamItem.style.alignItems = 'center';
        noTeamItem.style.padding = '4px 8px';
        noTeamItem.style.cursor = 'pointer';
        noTeamItem.style.borderRadius = '4px';
        
        noTeamItem.addEventListener('mouseenter', () => {
          noTeamItem.style.background = '#21262d';
        });
        noTeamItem.addEventListener('mouseleave', () => {
          noTeamItem.style.background = 'transparent';
        });
        
        noTeamItem.addEventListener('click', () => {
          this.selectEditorTeam(null);
        });
        
        const noTeamLabel = document.createElement('label');
        noTeamLabel.style.flex = '1';
        noTeamLabel.style.cursor = 'pointer';
        noTeamLabel.style.fontSize = '13px';
        noTeamLabel.style.color = '#c9d1d9';
        noTeamLabel.style.pointerEvents = 'none';
        const noTeamText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.noTeam')
          : 'No team';
        noTeamLabel.textContent = noTeamText;
        
        if (!currentValue || currentValue === '') {
          noTeamLabel.style.color = '#1f6feb';
          noTeamLabel.style.fontWeight = '500';
        }
        
        noTeamItem.appendChild(noTeamLabel);
        teamList.appendChild(noTeamItem);
        
        if (filteredTeams.length === 0 && searchQuery) {
          const emptyMsg = document.createElement('div');
          emptyMsg.style.padding = '10px';
          emptyMsg.style.color = '#8b949e';
          emptyMsg.style.textAlign = 'center';
          emptyMsg.style.fontSize = '13px';
          const noTeamsFoundText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.noTeamsFound')
            : 'No teams found';
          emptyMsg.textContent = noTeamsFoundText;
          teamList.appendChild(emptyMsg);
          return;
        }
        
        filteredTeams.forEach(team => {
          const teamName = team.name || '';
          const isUserTeam = userTeam === teamName;
          const isSelected = currentValue === teamName;
          
          const teamItem = document.createElement('div');
          teamItem.style.display = 'flex';
          teamItem.style.alignItems = 'center';
          teamItem.style.padding = '4px 8px';
          teamItem.style.cursor = 'pointer';
          teamItem.style.borderRadius = '4px';
          
          teamItem.addEventListener('mouseenter', () => {
            teamItem.style.background = '#21262d';
          });
          teamItem.addEventListener('mouseleave', () => {
            teamItem.style.background = 'transparent';
          });
          
          // Make the entire item clickable
          teamItem.addEventListener('click', (e) => {
            // Don't trigger if clicking on buttons
            if (e.target.tagName === 'BUTTON') {
              return;
            }
            this.selectEditorTeam(teamName);
          });
          
          const label = document.createElement('label');
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          label.style.pointerEvents = 'none'; // Let the parent handle clicks
          
          const teamNameSpan = document.createElement('span');
          teamNameSpan.textContent = teamName;
          label.appendChild(teamNameSpan);
          
          if (isSelected) {
            teamNameSpan.style.color = '#1f6feb';
            teamNameSpan.style.fontWeight = '500';
          }
          
          const myTeamBtn = document.createElement('button');
          myTeamBtn.textContent = isUserTeam ? '★' : '☆';
          myTeamBtn.style.background = 'transparent';
          myTeamBtn.style.border = 'none';
          myTeamBtn.style.color = isUserTeam ? '#fbbf24' : '#8b949e';
          myTeamBtn.style.cursor = 'pointer';
          myTeamBtn.style.padding = '2px 6px';
          myTeamBtn.style.marginLeft = '4px';
          myTeamBtn.style.fontSize = '14px';
          myTeamBtn.style.borderRadius = '4px';
          myTeamBtn.style.transition = 'all 0.15s ease';
          const removeMyTeamText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.removeAsMyTeam')
            : 'Remove as My Team';
          const setMyTeamText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.setAsMyTeam')
            : 'Set as My Team';
          myTeamBtn.title = isUserTeam ? removeMyTeamText : setMyTeamText;
          myTeamBtn.addEventListener('mouseenter', () => {
            myTeamBtn.style.background = '#21262d';
            myTeamBtn.style.color = isUserTeam ? '#fbbf24' : '#c9d1d9';
          });
          myTeamBtn.addEventListener('mouseleave', () => {
            myTeamBtn.style.background = 'transparent';
            myTeamBtn.style.color = isUserTeam ? '#fbbf24' : '#8b949e';
          });
          myTeamBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.saveEditorUserTeam(isUserTeam ? null : teamName);
          });
          
          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.style.borderRadius = '4px';
          editBtn.style.transition = 'all 0.15s ease';
          const editTeamText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.editTeam')
            : 'Edit team';
          editBtn.title = editTeamText;
          editBtn.addEventListener('mouseenter', () => {
            editBtn.style.background = '#21262d';
            editBtn.style.color = '#1f6feb';
          });
          editBtn.addEventListener('mouseleave', () => {
            editBtn.style.background = 'transparent';
            editBtn.style.color = '#8b949e';
          });
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.loadAllTeams().then(teams => {
              const teamObj = teams.find(t => t.name === teamName);
              if (teamObj) {
                this.openTeamModal(teamObj);
              }
            });
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.style.borderRadius = '4px';
          deleteBtn.style.transition = 'all 0.15s ease';
          const deleteTitle = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('modals.deleteTeam')
            : 'Delete team';
          deleteBtn.title = deleteTitle;
          deleteBtn.addEventListener('mouseenter', () => {
            deleteBtn.style.background = '#21262d';
            deleteBtn.style.color = '#f85149';
          });
          deleteBtn.addEventListener('mouseleave', () => {
            deleteBtn.style.background = 'transparent';
            deleteBtn.style.color = '#8b949e';
          });
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.loadAllTeams().then(teams => {
              const teamObj = teams.find(t => t.name === teamName);
              if (teamObj) {
                const deleteTitle = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('modals.deleteTeam')
                  : 'Delete Team';
                const deleteMessage = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.deleteTeamConfirm', { teamName })
                  : `Are you sure you want to delete "${teamName}"? This will remove the team from all players and delete all squad configurations for this team.`;
                this.openConfirmDeleteModal(
                  deleteTitle,
                  deleteMessage,
                  () => {
                    this.deleteTeam(teamObj.id)
                      .then(() => {
                        const deletedMessage = (window.i18n && typeof window.i18n.t === 'function')
                          ? window.i18n.t('editor.teamDeleted')
                          : 'Team deleted';
                        showNotification(deletedMessage, 'success', 2000);
                        this.renderEditorTeamSelector(document.getElementById('editorTeamSearchInput')?.value || '');
                        this.selectEditorTeam('');
                        this.loadPlayersForTeam('');
                        const configSection = document.getElementById('editorSquadConfigSection');
                        if (configSection) configSection.style.display = 'none';
                      })
                      .catch(err => {
                        const errorMessage = (window.i18n && typeof window.i18n.t === 'function')
                          ? window.i18n.t('editor.errorDeletingTeam') + ': ' + err.message
                          : 'Error deleting team: ' + err.message;
                        showNotification(errorMessage, 'error', 3000);
                      });
                  }
                );
              }
            });
          });
          
          teamItem.appendChild(label);
          teamItem.appendChild(myTeamBtn);
          teamItem.appendChild(editBtn);
          teamItem.appendChild(deleteBtn);
          teamList.appendChild(teamItem);
        });
        
        this.updateEditorSelectedTeamDisplay();
      })
      .catch(err => {
        console.error('Error loading teams:', err);
        teamList.innerHTML = '<div style="padding: 10px; color: #f85149; text-align: center; font-size: 13px;">Error loading teams</div>';
      });
  }

  selectEditorTeam(teamName) {
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const dropdown = document.getElementById('editorTeamSelectorDropdown');
    const searchInput = document.getElementById('editorTeamSearchInput');
    
    if (teamSelect) {
      const oldValue = teamSelect.value;
      
      // Ensure the option exists in the hidden select before setting the value
      if (teamName) {
        let optionExists = false;
        for (let i = 0; i < teamSelect.options.length; i++) {
          if (teamSelect.options[i].value === teamName) {
            optionExists = true;
            break;
          }
        }
        if (!optionExists) {
          const option = document.createElement('option');
          option.value = teamName;
          option.textContent = teamName;
          teamSelect.appendChild(option);
        }
      }
      
      teamSelect.value = teamName || '';
      
      // Directly load players and update UI, don't rely only on change event
      if (oldValue !== (teamName || '')) {
        // Load players for the selected team
        this.loadPlayersForTeam(teamName || '');
        
        // Show/hide squad section
        const configSection = document.getElementById('editorSquadConfigSection');
        if (configSection) {
          if (teamName) {
            configSection.style.display = 'block';
            this.populateSquadConfigSelector(teamName);
            this.clearSquadConfiguration();
          } else {
            configSection.style.display = 'none';
            this.clearSquadConfiguration();
          }
        }
        
        // Trigger change event for any other listeners
        const changeEvent = new Event('change', { bubbles: true });
        teamSelect.dispatchEvent(changeEvent);
      }
    }
    
    if (dropdown) {
      dropdown.style.display = 'none';
    }
    
    // Update search input to show selected team name
    if (searchInput) {
      searchInput.value = teamName || '';
      // Add a visual indicator that a team is selected
      if (teamName) {
        searchInput.style.color = '#1f6feb';
        searchInput.style.fontWeight = '500';
      } else {
        searchInput.style.color = '';
        searchInput.style.fontWeight = '';
      }
    }
    
    // Refresh the team selector to update visual state
    this.renderEditorTeamSelector('');
    this.updateEditorSelectedTeamDisplay();
  }

  saveEditorUserTeam(teamName) {
    if (!this.currentAnalysisId) return;

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === this.currentAnalysisId);

      if (analysisIndex !== -1) {
        analyses[analysisIndex].userTeam = teamName || null;
        chrome.storage.local.set({ analyses: analyses }, () => {
          console.log('User team saved:', teamName);
          const searchInput = document.getElementById('editorTeamSearchInput');
          this.renderEditorTeamSelector(searchInput ? searchInput.value : '');
          this.updateEditorSelectedTeamDisplay();
        });
      }
    });
  }

  updateEditorSelectedTeamDisplay() {
    const display = document.getElementById('editorSelectedTeamDisplay');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const searchInput = document.getElementById('editorTeamSearchInput');
    if (!display || !teamSelect) return;
    
    const selectedTeam = teamSelect.value;
    display.innerHTML = '';
    
    // Also update the search input display to show the selected team
    if (searchInput && document.activeElement !== searchInput) {
      if (selectedTeam && selectedTeam.trim() !== '') {
        searchInput.value = selectedTeam;
        searchInput.style.color = '#1f6feb';
        searchInput.style.fontWeight = '500';
      } else {
        searchInput.value = '';
        searchInput.style.color = '';
        searchInput.style.fontWeight = '';
      }
    }
    
    if (selectedTeam && selectedTeam.trim() !== '') {
      const tag = document.createElement('span');
      tag.style.display = 'inline-flex';
      tag.style.alignItems = 'center';
      tag.style.gap = '6px';
      tag.style.padding = '4px 8px';
      tag.style.background = '#21262d';
      tag.style.border = '1px solid #30363d';
      tag.style.borderRadius = '4px';
      tag.style.fontSize = '12px';
      tag.style.color = '#c9d1d9';
      tag.style.marginRight = '4px';
      tag.style.marginBottom = '4px';
      
      // Check if it's the user's team
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === this.currentAnalysisId);
        const userTeam = analysis ? (analysis.userTeam || null) : null;
        
        const teamNameSpan = document.createElement('span');
        teamNameSpan.textContent = selectedTeam;
        if (userTeam === selectedTeam) {
          teamNameSpan.style.color = '#fbbf24';
        }
        tag.appendChild(teamNameSpan);
        
        const removeBtn = document.createElement('button');
        removeBtn.textContent = '×';
        removeBtn.style.background = 'transparent';
        removeBtn.style.border = 'none';
        removeBtn.style.color = '#8b949e';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.padding = '0';
        removeBtn.style.marginLeft = '4px';
        removeBtn.style.fontSize = '14px';
        removeBtn.style.lineHeight = '1';
        const removeSelectionText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.removeSelection')
          : 'Remove selection';
        removeBtn.title = removeSelectionText;
        removeBtn.addEventListener('click', () => {
          this.selectEditorTeam(null);
        });
        
        tag.appendChild(removeBtn);
        display.appendChild(tag);
      });
    }
  }
  
  populateEventNameDropdown() {
    // This method is now replaced by populateCustomEventDropdown
    this.populateCustomEventDropdown();
  }
  
  populateCustomEventDropdown() {
    const menuContent = document.getElementById('editorEventNameMenuContent');
    if (!menuContent) return;
    
    // Get all standard events from categories
    const allEvents = [];
    EVENT_CATEGORIES.forEach(category => {
      category.events.forEach(event => {
        allEvents.push({ name: event, category: category.name, isCustom: false });
      });
    });
    
    // Load custom events from storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['customEvents'], (result) => {
        const customEvents = result.customEvents || [];
        
        // Add custom events
        customEvents.forEach(eventObj => {
          const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
          const eventCategory = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
          allEvents.push({ name: eventName, category: eventCategory, isCustom: true });
        });
        
        this.renderCustomEventDropdown(allEvents);
      });
    } else {
      this.renderCustomEventDropdown(allEvents);
    }
  }
  
  renderCustomEventDropdown(allEvents) {
    const menuContent = document.getElementById('editorEventNameMenuContent');
    if (!menuContent) return;
    
    menuContent.innerHTML = '';
    
    // Group by category
    const eventsByCategory = {};
    allEvents.forEach(event => {
      if (!eventsByCategory[event.category]) {
        eventsByCategory[event.category] = [];
      }
      eventsByCategory[event.category].push(event);
    });
    
    // Render categories and events
    Object.keys(eventsByCategory).sort().forEach(categoryName => {
      // Category header
      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'editor-custom-dropdown-category';
      categoryDiv.textContent = translateEventCategory(categoryName);
      menuContent.appendChild(categoryDiv);
      
      // Events in this category
      eventsByCategory[categoryName].forEach(event => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'editor-custom-dropdown-item';
        itemDiv.dataset.eventName = event.name;
        
        const nameSpan = document.createElement('span');
        nameSpan.className = 'editor-custom-dropdown-item-name';
        nameSpan.textContent = translateEventName(event.name);
        itemDiv.appendChild(nameSpan);
        
        // Add edit/delete buttons for custom events
        if (event.isCustom) {
          const actionsDiv = document.createElement('div');
          actionsDiv.className = 'editor-custom-dropdown-item-actions';
          
          const editBtn = document.createElement('button');
          editBtn.className = 'editor-custom-dropdown-item-btn edit';
          const editEventText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.editEvent')
            : 'Edit event';
          editBtn.title = editEventText;
          editBtn.innerHTML = '✎';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.openCustomEventModal(event.name);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.className = 'editor-custom-dropdown-item-btn delete';
          const deleteEventText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.deleteEvent')
            : 'Delete event';
          deleteBtn.title = deleteEventText;
          deleteBtn.innerHTML = '×';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.deleteCustomEvent(event.name);
          });
          
          actionsDiv.appendChild(editBtn);
          actionsDiv.appendChild(deleteBtn);
          itemDiv.appendChild(actionsDiv);
        }
        
        // Click handler for selection
        itemDiv.addEventListener('click', (e) => {
          if (!e.target.closest('.editor-custom-dropdown-item-btn')) {
            this.selectEventName(event.name);
            this.closeCustomEventDropdown();
          }
        });
        
        menuContent.appendChild(itemDiv);
      });
    });
    
    // Add "Add Custom Event" option at the bottom
    const addDiv = document.createElement('div');
    addDiv.className = 'editor-custom-dropdown-item';
    addDiv.style.cssText = 'border-top: 1px solid #21262d; margin-top: 4px; padding-top: 8px; color: #58a6ff;';
    
    const addSpan = document.createElement('span');
    addSpan.className = 'editor-custom-dropdown-item-name';
    const addCustomEventText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('modals.addCustomEvent')
      : 'Add Custom Event';
    addSpan.textContent = `+ ${addCustomEventText}`;
    addDiv.appendChild(addSpan);
    
    addDiv.addEventListener('click', (e) => {
      e.stopPropagation();
      this.openCustomEventModal();
      this.closeCustomEventDropdown();
    });
    
    menuContent.appendChild(addDiv);
  }
  
  initCustomEventDropdown() {
    const dropdown = document.getElementById('editorEventNameDropdown');
    const button = document.getElementById('editorEventNameButton');
    const menu = document.getElementById('editorEventNameMenu');
    
    if (!dropdown || !button || !menu) return;
    
    // Toggle dropdown on button click
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      if (menu.classList.contains('hidden')) {
        this.openCustomEventDropdown();
      } else {
        this.closeCustomEventDropdown();
      }
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target)) {
        this.closeCustomEventDropdown();
      }
    });
    
    // Populate dropdown on init
    this.populateCustomEventDropdown();
  }
  
  openCustomEventDropdown() {
    const menu = document.getElementById('editorEventNameMenu');
    if (!menu) return;
    
    // Refresh content before opening
    this.populateCustomEventDropdown();
    
    menu.classList.remove('hidden');
    
    // Highlight currently selected event
    const currentEventName = this.eventName || '';
    const items = menu.querySelectorAll('.editor-custom-dropdown-item');
    items.forEach(item => {
      if (item.dataset.eventName === currentEventName) {
        item.classList.add('selected');
      } else {
        item.classList.remove('selected');
      }
    });
  }
  
  closeCustomEventDropdown() {
    const menu = document.getElementById('editorEventNameMenu');
    if (menu) {
      menu.classList.add('hidden');
    }
  }
  
  selectEventName(eventName) {
    this.eventName = eventName || '';
    
    // Update display
    const display = document.getElementById('editorEventNameDisplay');
    if (display) {
      const selectEventText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectEvent')
        : '— Select event —';
      display.textContent = eventName ? translateEventName(eventName) : selectEventText;
    }
    
    // Update selected drawings' event name if any are selected
    if (this.selectedDrawings.length > 0) {
      this.selectedDrawings.forEach(index => {
        if (this.drawings[index]) {
          this.drawings[index].eventName = eventName || '';
        }
      });
      this.saveState();
    }
  }
  
  initCustomEventModal() {
    const modal = document.getElementById('editorCustomEventModal');
    const closeBtn = document.getElementById('editorCloseCustomEventModal');
    const cancelBtn = document.getElementById('editorCancelCustomEventBtn');
    const saveBtn = document.getElementById('editorSaveCustomEventBtn');
    const nameInput = document.getElementById('editorCustomEventNameInput');
    const categorySelect = document.getElementById('editorCustomEventCategorySelect');
    
    if (!modal) return;
    
    // Load categories for the select
    this.loadCustomEventCategories();
    
    // Close handlers
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeCustomEventModal());
    }
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => this.closeCustomEventModal());
    }
    
    // Overlay click to close
    const overlay = modal.querySelector('.editor-modal-overlay');
    if (overlay) {
      overlay.addEventListener('click', () => this.closeCustomEventModal());
    }
    
    // Save handler
    if (saveBtn) {
      saveBtn.addEventListener('click', () => this.saveCustomEventFromModal());
    }
    
    // Enter key to save
    if (nameInput) {
      nameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.saveCustomEventFromModal();
        }
      });
    }
    
    this.currentEditingEventName = null;
  }
  
  loadCustomEventCategories() {
    const categorySelect = document.getElementById('editorCustomEventCategorySelect');
    if (!categorySelect) return;
    
    const selectCategoryText = window.i18n && window.i18n.t ? window.i18n.t('modals.selectCategory') : 'Select category...';
    categorySelect.innerHTML = `<option value="">${selectCategoryText}</option>`;
    
    EVENT_CATEGORIES.forEach(category => {
      const option = document.createElement('option');
      option.value = category.name;
      option.textContent = translateEventCategory(category.name);
      categorySelect.appendChild(option);
    });
    
    // Add "Custom" category option
    const customOption = document.createElement('option');
    customOption.value = 'Custom';
    const customText = window.i18n && window.i18n.t ? window.i18n.t('modals.addCustomEvent') : 'Custom';
    customOption.textContent = customText;
    categorySelect.appendChild(customOption);
  }
  
  openCustomEventModal(eventName = null) {
    const modal = document.getElementById('editorCustomEventModal');
    const title = document.getElementById('editorCustomEventModalTitle');
    const nameInput = document.getElementById('editorCustomEventNameInput');
    const categorySelect = document.getElementById('editorCustomEventCategorySelect');
    
    if (!modal || !nameInput || !categorySelect) return;
    
    this.currentEditingEventName = eventName;
    
    if (eventName) {
      // Editing existing event
      if (title) {
        const editCustomEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.editCustomEvent')
          : 'Edit Custom Event';
        title.textContent = editCustomEventText;
      }
      nameInput.value = eventName;
      
      // Find the event and set its category
      chrome.storage.local.get(['customEvents'], (result) => {
        const customEvents = result.customEvents || [];
        const eventObj = customEvents.find(e => {
          const name = typeof e === 'string' ? e : e.name;
          return name === eventName;
        });
        if (eventObj) {
          const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
          categorySelect.value = category;
        }
      });
    } else {
      // Creating new event
      if (title) {
        const addCustomEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.addCustomEvent')
          : 'Add Custom Event';
        title.textContent = addCustomEventText;
      }
      nameInput.value = '';
      categorySelect.value = '';
    }
    
    modal.classList.remove('hidden');
    nameInput.focus();
  }
  
  closeCustomEventModal() {
    const modal = document.getElementById('editorCustomEventModal');
    if (modal) {
      modal.classList.add('hidden');
      this.currentEditingEventName = null;
    }
  }
  
  saveCustomEventFromModal() {
    const nameInput = document.getElementById('editorCustomEventNameInput');
    const categorySelect = document.getElementById('editorCustomEventCategorySelect');
    
    if (!nameInput || !categorySelect) return;
    
    const eventName = nameInput.value.trim();
    const category = categorySelect.value.trim() || 'Custom';
    
    if (!eventName) {
      const alertText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.enterCustomEventName')
        : 'Please enter an event name';
      alert(alertText);
      return;
    }
    
    chrome.storage.local.get(['customEvents'], (result) => {
      const customEvents = result.customEvents || [];
      
      if (this.currentEditingEventName) {
        // Editing existing event
        const eventIndex = customEvents.findIndex(e => {
          const name = typeof e === 'string' ? e : e.name;
          return name === this.currentEditingEventName;
        });
        
        if (eventIndex !== -1) {
          // Check if new name conflicts with another event
          const allEvents = [];
          EVENT_CATEGORIES.forEach(cat => {
            cat.events.forEach(evt => allEvents.push(evt));
          });
          customEvents.forEach(e => {
            const name = typeof e === 'string' ? e : e.name;
            if (name !== this.currentEditingEventName) {
              allEvents.push(name);
            }
          });
          
          if (allEvents.includes(eventName)) {
            const existsText = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.confirmDeleteItem') // Using generic message, could add specific key
              : 'An event with this name already exists';
            alert(existsText);
            return;
          }
          
          // Update event
          customEvents[eventIndex] = { name: eventName, category: category };
          
          // Update event name in drawings if it was changed
          if (eventName !== this.currentEditingEventName) {
            this.drawings.forEach(drawing => {
              if (drawing.eventName === this.currentEditingEventName) {
                drawing.eventName = eventName;
              }
            });
            this.saveState();
          }
        }
      } else {
        // Creating new event
        // Check if event already exists
        const allEvents = [];
        EVENT_CATEGORIES.forEach(cat => {
          cat.events.forEach(evt => allEvents.push(evt));
        });
        customEvents.forEach(e => {
          const name = typeof e === 'string' ? e : e.name;
          allEvents.push(name);
        });
        
        if (allEvents.includes(eventName)) {
          alert('An event with this name already exists');
          return;
        }
        
        customEvents.push({ name: eventName, category: category });
      }
      
      // Save to storage
      chrome.storage.local.set({ customEvents: customEvents }, () => {
        this.closeCustomEventModal();
        this.populateCustomEventDropdown();
        
        // If we're editing and the name changed, update the display
        if (this.currentEditingEventName && eventName !== this.currentEditingEventName) {
          this.selectEventName(eventName);
        }
      });
    });
  }
  
  deleteCustomEvent(eventName) {
    const deleteEventText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.confirmDeleteItem')
      : `Are you sure you want to delete the custom event "${eventName}"? This will remove the event from all shapes.`;
    if (!confirm(deleteEventText)) {
      return;
    }
    
    chrome.storage.local.get(['customEvents'], (result) => {
      const customEvents = result.customEvents || [];
      
      // Remove from custom events
      const filtered = customEvents.filter(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name !== eventName;
      });
      
      // Remove from drawings
      this.drawings.forEach(drawing => {
        if (drawing.eventName === eventName) {
          drawing.eventName = '';
        }
      });
      this.saveState();
      
      // Update display if this event was selected
      if (this.eventName === eventName) {
        this.selectEventName('');
      }
      
      // Save to storage
      chrome.storage.local.set({ customEvents: filtered }, () => {
        this.populateCustomEventDropdown();
      });
    });
  }

  loadPlayersForTeam(teamName) {
    const playerList = document.getElementById('editorPlayerList');
    if (!playerList) return;
    
    // Clear selection state
    this.selectedPlayerId = null;
    
    if (!teamName) {
      const emptyText = (window.i18n && typeof window.i18n.t === 'function') 
        ? window.i18n.t('editor.selectTeamToSeePlayers')
        : 'Select a team to see players';
      playerList.innerHTML = `<div class="editor-player-list-empty">${emptyText}</div>`;
      return;
    }
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      playerList.innerHTML = '<div class="editor-player-list-empty">Unable to load players</div>';
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const teamPlayers = players.filter(p => p.team === teamName);
      
      if (teamPlayers.length === 0) {
        playerList.innerHTML = '<div class="editor-player-list-empty">No players in this team. Click + to add.</div>';
        return;
      }
      
      // Sort by number
      teamPlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
      
      playerList.innerHTML = '';
      teamPlayers.forEach(player => {
        const item = document.createElement('div');
        item.className = 'editor-player-item';
        item.draggable = true;
        item.dataset.playerId = player.id;
        item.dataset.playerNumber = player.number || '';
        item.dataset.playerName = player.fullName || '';
        item.dataset.playerPosition = player.position || '';
        item.dataset.playerTeam = player.team || '';
        item.style.display = 'flex';
        item.style.alignItems = 'center';
        item.style.padding = '4px 8px';
        item.style.cursor = 'pointer';
        item.style.borderRadius = '4px';
        item.style.marginBottom = '2px';
        
        item.addEventListener('mouseenter', () => {
          if (!item.classList.contains('selected')) {
            item.style.background = '#21262d';
          }
        });
        item.addEventListener('mouseleave', () => {
          if (!item.classList.contains('selected')) {
            item.style.background = 'transparent';
          }
        });
        
        // Number circle
        const numberDiv = document.createElement('div');
        numberDiv.className = 'editor-player-item-number';
        numberDiv.style.cssText = `
          width: 24px;
          height: 24px;
          background: #21262d;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: bold;
          color: #c9d1d9;
          margin-right: 8px;
          flex-shrink: 0;
        `;
        numberDiv.textContent = player.number || '?';
        
        // Player info
        const infoDiv = document.createElement('div');
        infoDiv.className = 'editor-player-item-info';
        infoDiv.style.cssText = 'flex: 1; min-width: 0;';
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'editor-player-item-name';
        nameDiv.style.cssText = 'font-size: 13px; color: #c9d1d9; font-weight: 500;';
        const unknownText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.unknown')
          : 'Unknown';
        nameDiv.textContent = player.fullName || unknownText;
        
        const positionDiv = document.createElement('div');
        positionDiv.className = 'editor-player-item-position';
        positionDiv.style.cssText = 'font-size: 11px; color: #8b949e;';
        positionDiv.textContent = player.position || '';
        
        infoDiv.appendChild(nameDiv);
        infoDiv.appendChild(positionDiv);
        
        // Edit button
        const editBtn = document.createElement('button');
        editBtn.textContent = '✎';
        editBtn.style.cssText = `
          background: transparent;
          border: none;
          color: #8b949e;
          cursor: pointer;
          padding: 2px 6px;
          margin-left: 4px;
          font-size: 12px;
          border-radius: 4px;
          transition: all 0.15s ease;
        `;
        const editPlayerText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.editPlayer')
          : 'Edit player';
        editBtn.title = editPlayerText;
        editBtn.addEventListener('mouseenter', () => {
          editBtn.style.background = '#21262d';
          editBtn.style.color = '#1f6feb';
        });
        editBtn.addEventListener('mouseleave', () => {
          editBtn.style.background = 'transparent';
          editBtn.style.color = '#8b949e';
        });
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.loadAllPlayers().then(players => {
            const playerObj = players.find(p => p.id === player.id);
            if (playerObj) {
              this.openPlayerModal(playerObj);
            }
          });
        });
        
        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.style.cssText = `
          background: transparent;
          border: none;
          color: #8b949e;
          cursor: pointer;
          padding: 2px 6px;
          margin-left: 2px;
          font-size: 16px;
          border-radius: 4px;
          transition: all 0.15s ease;
        `;
        deleteBtn.title = 'Delete player';
        deleteBtn.addEventListener('mouseenter', () => {
          deleteBtn.style.background = '#21262d';
          deleteBtn.style.color = '#f85149';
        });
        deleteBtn.addEventListener('mouseleave', () => {
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.color = '#8b949e';
        });
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.loadAllPlayers().then(players => {
            const playerObj = players.find(p => p.id === player.id);
            if (playerObj) {
              this.openConfirmDeleteModal(
                'Delete Player',
                (window.i18n && typeof window.i18n.t === 'function'
                  ? window.i18n.t('editor.areYouSureDeletePlayer', { playerName: playerObj.fullName })
                  : `Are you sure you want to delete "${playerObj.fullName}"? This will remove the player from all squad configurations.`),
                () => {
                  this.deletePlayer(playerObj.id)
                    .then(() => {
                      showNotification('Player deleted', 'success', 2000);
                      const teamSelect = document.getElementById('editorPlayerTeamSelect');
                      const teamName = teamSelect ? teamSelect.value : '';
                      this.loadPlayersForTeam(teamName);
                    })
                    .catch(err => {
                      showNotification('Error deleting player: ' + err.message, 'error', 3000);
                    });
                }
              );
            }
          });
        });
        
        item.appendChild(numberDiv);
        item.appendChild(infoDiv);
        item.appendChild(editBtn);
        item.appendChild(deleteBtn);
        
        // Click to select player for squad assignment
        item.addEventListener('click', (e) => {
          // Don't trigger if clicking on buttons
          if (e.target.tagName === 'BUTTON') {
            return;
          }
          
          e.stopPropagation();
          const playerId = item.dataset.playerId;
          
          // Toggle selection for editing
          const wasSelected = item.classList.contains('selected');
          
          // Remove previous selection
          playerList.querySelectorAll('.editor-player-item.selected').forEach(el => {
            el.classList.remove('selected');
            el.style.background = '';
            el.style.borderColor = '';
          });
          
          if (!wasSelected) {
            // Select this player
            item.classList.add('selected');
            item.style.background = '#1f6feb';
            item.style.borderColor = '#58a6ff';
            this.selectedPlayerId = playerId;
            this.selectedPlayerForSquad = playerId;
            
            // Highlight target sections
            const startingSquadList = document.getElementById('editorStartingSquadList');
            const benchSquadList = document.getElementById('editorBenchSquadList');
            if (startingSquadList) {
              startingSquadList.classList.add('editor-squad-list-ready');
              const emptyDiv = startingSquadList.querySelector('.editor-squad-empty');
              if (emptyDiv) {
                const clickToAddText = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.clickToAddSelectedPlayer')
                  : 'Click to add selected player';
                emptyDiv.textContent = clickToAddText;
              }
            }
            if (benchSquadList) {
              benchSquadList.classList.add('editor-squad-list-ready');
              const emptyDiv = benchSquadList.querySelector('.editor-squad-empty');
              if (emptyDiv) {
                const clickToAddText = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.clickToAddSelectedPlayer')
                  : 'Click to add selected player';
                emptyDiv.textContent = clickToAddText;
              }
            }
          } else {
            // Deselect
            this.selectedPlayerId = null;
            this.selectedPlayerForSquad = null;
            
            // Remove highlight from squad sections
            const startingSquadList = document.getElementById('editorStartingSquadList');
            const benchSquadList = document.getElementById('editorBenchSquadList');
            if (startingSquadList) {
              startingSquadList.classList.remove('editor-squad-list-ready');
              const emptyDiv = startingSquadList.querySelector('.editor-squad-empty');
              if (emptyDiv) {
                const clickPlayersText = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.clickPlayersToAdd')
                  : 'Click players to add';
                emptyDiv.textContent = clickPlayersText;
              }
            }
            if (benchSquadList) {
              benchSquadList.classList.remove('editor-squad-list-ready');
              const emptyDiv = benchSquadList.querySelector('.editor-squad-empty');
              if (emptyDiv) {
                const clickPlayersText = (window.i18n && typeof window.i18n.t === 'function')
                  ? window.i18n.t('editor.clickPlayersToAdd')
                  : 'Click players to add';
                emptyDiv.textContent = clickPlayersText;
              }
            }
          }
        });
        
        // Keep drag for canvas only
        item.addEventListener('dragstart', (e) => {
          this.handlePlayerDragStart(e, player);
        });
        item.addEventListener('dragend', (e) => this.handlePlayerDragEnd(e));
        
        playerList.appendChild(item);
      });
    });
  }

  // TEAM MANAGEMENT FUNCTIONS (Global Storage)
  
  // Migrate teams from per-analysis storage to global storage
  migrateTeamsToGlobalStorage() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
      console.log('migrateTeamsToGlobalStorage: Chrome storage not available');
      return;
    }
    
    chrome.storage.local.get(['teams', 'teamsMigrated', 'analyses'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('migrateTeamsToGlobalStorage: Error reading storage:', chrome.runtime.lastError);
        return;
      }
      
      // Skip if already migrated
      if (result.teamsMigrated) {
        console.log('migrateTeamsToGlobalStorage: Already migrated');
        return;
      }
      
      const existingGlobalTeams = result.teams || [];
      const analyses = result.analyses || [];
      
      // Collect all teams from all analyses
      const teamsMap = new Map();
      
      // First, add any existing global teams
      existingGlobalTeams.forEach(team => {
        const name = typeof team === 'object' ? team.name : team;
        if (name && !teamsMap.has(name.toLowerCase())) {
          teamsMap.set(name.toLowerCase(), this.ensureTeamObjectWithId(team));
        }
      });
      
      // Then collect teams from all analyses
      analyses.forEach(analysis => {
        if (analysis.teams && Array.isArray(analysis.teams)) {
          analysis.teams.forEach(team => {
            const name = typeof team === 'object' ? team.name : team;
            if (name && !teamsMap.has(name.toLowerCase())) {
              teamsMap.set(name.toLowerCase(), this.ensureTeamObjectWithId(team));
            }
          });
        }
      });
      
      const migratedTeams = Array.from(teamsMap.values());
      
      // Save migrated teams to global storage
      chrome.storage.local.set({ 
        teams: migratedTeams, 
        teamsMigrated: true 
      }, () => {
        if (chrome.runtime.lastError) {
          console.error('migrateTeamsToGlobalStorage: Error saving teams:', chrome.runtime.lastError);
        } else {
          console.log(`migrateTeamsToGlobalStorage: Migrated ${migratedTeams.length} teams to global storage`);
        }
      });
    });
  }
  
  // Ensure team object has proper structure with ID
  ensureTeamObjectWithId(team) {
    const now = Date.now();
    if (typeof team === 'string') {
      return {
        id: `team_${now}_${Math.random().toString(36).substr(2, 9)}`,
        name: team,
        homeColor: '#FFFFFF',
        awayColor: '#000000',
        homeDesign: 'solid',
        awayDesign: 'solid',
        homeSecondColor: '#000000',
        awaySecondColor: '#FFFFFF',
        formation: '',
        createdAt: now,
        updatedAt: now
      };
    }
    return {
      id: team.id || `team_${now}_${Math.random().toString(36).substr(2, 9)}`,
      name: team.name || '',
      homeColor: team.homeColor || '#FFFFFF',
      awayColor: team.awayColor || '#000000',
      homeDesign: team.homeDesign || 'solid',
      awayDesign: team.awayDesign || 'solid',
      homeSecondColor: team.homeSecondColor || '#000000',
      awaySecondColor: team.awaySecondColor || '#FFFFFF',
      formation: team.formation || '',
      createdAt: team.createdAt || now,
      updatedAt: team.updatedAt || now
    };
  }
  
  // Load all teams from global storage (with fallback to analyses)
  loadAllTeams() {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        resolve([]);
        return;
      }
      
      chrome.storage.local.get(['teams', 'analyses', 'currentAnalysisId'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        let teams = result.teams || [];
        
        // Also include teams from current analysis for backward compatibility
        const analyses = result.analyses || [];
        const currentAnalysisId = this.currentAnalysisId || result.currentAnalysisId;
        const currentAnalysis = analyses.find(a => a.id === currentAnalysisId);
        
        if (currentAnalysis && currentAnalysis.teams) {
          const existingNames = new Set(teams.map(t => t.name.toLowerCase()));
          currentAnalysis.teams.forEach(team => {
            const name = typeof team === 'object' ? team.name : team;
            if (name && !existingNames.has(name.toLowerCase())) {
              teams.push(this.ensureTeamObjectWithId(team));
            }
          });
        }
        
        // Sort by name
        teams.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
        resolve(teams);
      });
    });
  }
  
  // Create a new team
  createTeam(teamData) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      if (!teamData.name || !teamData.name.trim()) {
        reject(new Error('Team name is required'));
        return;
      }
      
      chrome.storage.local.get(['teams'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const teams = result.teams || [];
        const trimmedName = teamData.name.trim();
        
        // Check for duplicate name
        if (teams.some(t => t.name.toLowerCase() === trimmedName.toLowerCase())) {
          reject(new Error('A team with this name already exists'));
          return;
        }
        
        const now = Date.now();
        const newTeam = {
          id: `team_${now}_${Math.random().toString(36).substr(2, 9)}`,
          name: trimmedName,
          homeColor: teamData.homeColor || '#FFFFFF',
          awayColor: teamData.awayColor || '#000000',
          homeDesign: teamData.homeDesign || 'solid',
          awayDesign: teamData.awayDesign || 'solid',
          homeSecondColor: teamData.homeSecondColor || '#000000',
          awaySecondColor: teamData.awaySecondColor || '#FFFFFF',
          formation: teamData.formation || '',
          createdAt: now,
          updatedAt: now
        };
        
        teams.push(newTeam);
        
        chrome.storage.local.set({ teams: teams }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Team created:', newTeam);
            resolve(newTeam);
          }
        });
      });
    });
  }
  
  // Update an existing team
  updateTeam(teamId, teamData) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      chrome.storage.local.get(['teams', 'players', 'squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const teams = result.teams || [];
        const players = result.players || [];
        const squadConfigs = result.squadConfigurations || [];
        
        const teamIndex = teams.findIndex(t => t.id === teamId);
        if (teamIndex === -1) {
          reject(new Error('Team not found'));
          return;
        }
        
        const oldTeamName = teams[teamIndex].name;
        const newTeamName = teamData.name ? teamData.name.trim() : oldTeamName;
        
        // Check for duplicate name (only if name changed)
        if (newTeamName.toLowerCase() !== oldTeamName.toLowerCase()) {
          if (teams.some(t => t.id !== teamId && t.name.toLowerCase() === newTeamName.toLowerCase())) {
            reject(new Error('A team with this name already exists'));
            return;
          }
        }
        
        // Update team
        teams[teamIndex] = {
          ...teams[teamIndex],
          name: newTeamName,
          homeColor: teamData.homeColor !== undefined ? teamData.homeColor : teams[teamIndex].homeColor,
          awayColor: teamData.awayColor !== undefined ? teamData.awayColor : teams[teamIndex].awayColor,
          homeDesign: teamData.homeDesign !== undefined ? teamData.homeDesign : teams[teamIndex].homeDesign,
          awayDesign: teamData.awayDesign !== undefined ? teamData.awayDesign : teams[teamIndex].awayDesign,
          homeSecondColor: teamData.homeSecondColor !== undefined ? teamData.homeSecondColor : teams[teamIndex].homeSecondColor,
          awaySecondColor: teamData.awaySecondColor !== undefined ? teamData.awaySecondColor : teams[teamIndex].awaySecondColor,
          formation: teamData.formation !== undefined ? teamData.formation : teams[teamIndex].formation,
          updatedAt: Date.now()
        };
        
        // Update players' team references if name changed
        let updatedPlayers = players;
        if (newTeamName !== oldTeamName) {
          updatedPlayers = players.map(p => {
            if (p.team === oldTeamName) {
              return { ...p, team: newTeamName };
            }
            return p;
          });
        }
        
        // Update squad configurations' team references if name changed
        let updatedConfigs = squadConfigs;
        if (newTeamName !== oldTeamName) {
          updatedConfigs = squadConfigs.map(c => {
            if (c.teamName === oldTeamName) {
              return { ...c, teamName: newTeamName };
            }
            return c;
          });
        }
        
        chrome.storage.local.set({ 
          teams: teams,
          players: updatedPlayers,
          squadConfigurations: updatedConfigs
        }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Team updated:', teams[teamIndex]);
            resolve(teams[teamIndex]);
          }
        });
      });
    });
  }
  
  // Delete a team
  deleteTeam(teamId) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      chrome.storage.local.get(['teams', 'players', 'squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const teams = result.teams || [];
        const players = result.players || [];
        const squadConfigs = result.squadConfigurations || [];
        
        const teamIndex = teams.findIndex(t => t.id === teamId);
        if (teamIndex === -1) {
          reject(new Error('Team not found'));
          return;
        }
        
        const deletedTeam = teams[teamIndex];
        const teamName = deletedTeam.name;
        
        // Remove team
        teams.splice(teamIndex, 1);
        
        // Clear team reference from players (don't delete players)
        const updatedPlayers = players.map(p => {
          if (p.team === teamName) {
            return { ...p, team: '' };
          }
          return p;
        });
        
        // Remove squad configurations for this team
        const updatedConfigs = squadConfigs.filter(c => c.teamName !== teamName);
        
        chrome.storage.local.set({ 
          teams: teams,
          players: updatedPlayers,
          squadConfigurations: updatedConfigs
        }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Team deleted:', deletedTeam);
            resolve(deletedTeam);
          }
        });
      });
    });
  }
  
  // PLAYER MANAGEMENT FUNCTIONS (Global Storage)
  
  // Load all players from global storage
  loadAllPlayers() {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        resolve([]);
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const players = result.players || [];
        // Sort by number, then by name
        players.sort((a, b) => {
          if (a.number !== b.number) {
            return (parseInt(a.number) || 0) - (parseInt(b.number) || 0);
          }
          return (a.fullName || '').localeCompare(b.fullName || '');
        });
        resolve(players);
      });
    });
  }
  
  // Create a new player
  createPlayer(playerData) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      if (!playerData.fullName || !playerData.fullName.trim()) {
        reject(new Error('Player name is required'));
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }

        const players = result.players || [];

        // Check if number is already taken by another player in the same team
        const duplicatePlayer = players.find(p => p.number === (playerData.number || '') && p.team === (playerData.team || ''));
        if (duplicatePlayer) {
          reject(new Error(`Player number ${playerData.number || ''} is already taken by ${duplicatePlayer.fullName || duplicatePlayer.name || 'another player'} in team ${playerData.team || ''}. Please choose a different number.`));
          return;
        }

        const now = Date.now();

        const newPlayer = {
          id: now.toString(),
          fullName: playerData.fullName.trim(),
          number: playerData.number || '',
          team: playerData.team || '',
          position: playerData.position || ''
        };

        players.push(newPlayer);
        
        chrome.storage.local.set({ players: players }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Player created:', newPlayer);
            resolve(newPlayer);
          }
        });
      });
    });
  }
  
  // Update an existing player
  updatePlayer(playerId, playerData) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const players = result.players || [];
        const playerIndex = players.findIndex(p => p.id === playerId);

        if (playerIndex === -1) {
          reject(new Error('Player not found'));
          return;
        }

        const currentPlayer = players[playerIndex];
        const newNumber = playerData.number !== undefined ? playerData.number : currentPlayer.number;
        const newTeam = playerData.team !== undefined ? playerData.team : currentPlayer.team;

        // Check if number is already taken by another player in the same team
        const duplicatePlayer = players.find(p =>
          p.id !== playerId &&
          p.number === newNumber &&
          p.team === newTeam
        );
        if (duplicatePlayer) {
          reject(new Error(`Player number ${newNumber} is already taken by ${duplicatePlayer.fullName || duplicatePlayer.name || 'another player'} in team ${newTeam}. Please choose a different number.`));
          return;
        }

        // Update player
        players[playerIndex] = {
          ...players[playerIndex],
          fullName: playerData.fullName !== undefined ? playerData.fullName.trim() : players[playerIndex].fullName,
          number: playerData.number !== undefined ? playerData.number : players[playerIndex].number,
          team: playerData.team !== undefined ? playerData.team : players[playerIndex].team,
          position: playerData.position !== undefined ? playerData.position : players[playerIndex].position
        };
        
        chrome.storage.local.set({ players: players }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Player updated:', players[playerIndex]);
            resolve(players[playerIndex]);
          }
        });
      });
    });
  }
  
  // Delete a player
  deletePlayer(playerId) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Chrome storage not available'));
        return;
      }
      
      chrome.storage.local.get(['players', 'squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const players = result.players || [];
        const squadConfigs = result.squadConfigurations || [];
        
        const playerIndex = players.findIndex(p => p.id === playerId);
        if (playerIndex === -1) {
          reject(new Error('Player not found'));
          return;
        }
        
        const deletedPlayer = players[playerIndex];
        players.splice(playerIndex, 1);
        
        // Remove player from all squad configurations
        const updatedConfigs = squadConfigs.map(config => ({
          ...config,
          startingSquad: (config.startingSquad || []).filter(id => id !== playerId),
          bench: (config.bench || []).filter(id => id !== playerId)
        }));
        
        chrome.storage.local.set({ 
          players: players,
          squadConfigurations: updatedConfigs
        }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            console.log('Player deleted:', deletedPlayer);
            resolve(deletedPlayer);
          }
        });
      });
    });
  }

  // SQUAD CONFIGURATION STORAGE FUNCTIONS
  
  cleanupDuplicateSquadConfigurations() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
      return Promise.resolve();
    }
    
    return new Promise((resolve) => {
      chrome.storage.local.get(['squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          resolve();
          return;
        }
        
        const allConfigs = result.squadConfigurations || [];
        if (allConfigs.length === 0) {
          resolve();
          return;
        }
        
        // Clean up duplicates: keep only the most recent config for each team+name combination
        const configMap = new Map();
        allConfigs.forEach(config => {
          if (!config.teamName || !config.name) return; // Skip invalid configs
          
          const normalizedName = (config.name || '').toLowerCase().trim();
          if (!normalizedName) return; // Skip configs with empty names
          
          const key = `${config.teamName}::${normalizedName}`;
          const existing = configMap.get(key);
          
          if (!existing) {
            configMap.set(key, config);
          } else {
            // Keep the one with the most recent update
            const existingTime = existing.updatedAt || existing.createdAt || 0;
            const currentTime = config.updatedAt || config.createdAt || 0;
            if (currentTime > existingTime) {
              configMap.set(key, config);
            }
          }
        });
        
        // Convert map back to array
        const cleanedConfigs = Array.from(configMap.values());
        
        // Save cleaned configs if duplicates were found
        if (cleanedConfigs.length !== allConfigs.length) {
          chrome.storage.local.set({ squadConfigurations: cleanedConfigs }, () => {
            if (chrome.runtime.lastError) {
              console.warn('Error saving cleaned configs:', chrome.runtime.lastError);
            } else {
              console.log(`Cleaned up ${allConfigs.length - cleanedConfigs.length} duplicate squad configurations`);
            }
            resolve();
          });
        } else {
          resolve();
        }
      });
    });
  }
  
  loadSquadConfigurations(teamName) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        resolve([]);
        return;
      }
      
      chrome.storage.local.get(['squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        let allConfigs = result.squadConfigurations || [];
        
        // Clean up duplicates: keep only the most recent config for each team+name combination
        const configMap = new Map();
        allConfigs.forEach(config => {
          const key = `${config.teamName || ''}::${(config.name || '').toLowerCase()}`;
          const existing = configMap.get(key);
          
          if (!existing) {
            configMap.set(key, config);
          } else {
            // Keep the one with the most recent update
            const existingTime = existing.updatedAt || existing.createdAt || 0;
            const currentTime = config.updatedAt || config.createdAt || 0;
            if (currentTime > existingTime) {
              configMap.set(key, config);
            }
          }
        });
        
        // Convert map back to array and save cleaned configs if duplicates were found
        const cleanedConfigs = Array.from(configMap.values());
        if (cleanedConfigs.length !== allConfigs.length) {
          // Duplicates were removed, save the cleaned version
          chrome.storage.local.set({ squadConfigurations: cleanedConfigs }, () => {
            if (chrome.runtime.lastError) {
              console.warn('Error saving cleaned configs:', chrome.runtime.lastError);
            }
          });
          allConfigs = cleanedConfigs;
        }
        
        const teamConfigs = teamName ? allConfigs.filter(config => config.teamName === teamName) : [];
        // Sort by updatedAt descending (most recent first)
        teamConfigs.sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
        resolve(teamConfigs);
      });
    });
  }
  
  saveSquadConfiguration(teamName, name, startingSquad, bench) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Storage not available'));
        return;
      }
      
      if (!teamName || !name || !name.trim()) {
        reject(new Error('Team name and configuration name are required'));
        return;
      }
      
      // Prevent saving with "New Squad" as the name
      const trimmedName = name.trim();
      if (trimmedName.toLowerCase() === 'new squad') {
        const customNameText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleaseEnterCustomNameForConfiguration')
          : 'Please enter a custom name for your configuration';
        reject(new Error(customNameText));
        return;
      }
      
      chrome.storage.local.get(['squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        let allConfigs = result.squadConfigurations || [];
        const now = Date.now();
        
        // First, check if we're updating an existing config by ID (if currentSquadConfigId is set)
        let existingIndex = -1;
        if (this.currentSquadConfigId) {
          existingIndex = allConfigs.findIndex(config => config.id === this.currentSquadConfigId);
        }
        
        // If not updating by ID, check if a config with the same name exists for this team (case-insensitive)
        // Also remove any other duplicates with the same name before checking
        if (existingIndex === -1) {
          // First, find and remove all duplicates with the same name (keep the most recent)
          const duplicates = allConfigs.filter(
            config => config.teamName === teamName && config.name.toLowerCase() === trimmedName.toLowerCase()
          );
          
          if (duplicates.length > 0) {
            // Sort by updatedAt descending, keep the first (most recent)
            duplicates.sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
            const keepConfig = duplicates[0];
            
            // Remove all duplicates from the array
            allConfigs = allConfigs.filter(
              config => !(config.teamName === teamName && config.name.toLowerCase() === trimmedName.toLowerCase() && config.id !== keepConfig.id)
            );
            
            // Find the index of the config we're keeping
            existingIndex = allConfigs.findIndex(config => config.id === keepConfig.id);
          }
        }
        
        // If we found an existing config, update it
        if (existingIndex >= 0) {
          const existingConfig = allConfigs[existingIndex];
          // Update the existing config
          allConfigs[existingIndex] = {
            ...existingConfig,
            name: trimmedName,
            startingSquad: startingSquad || [],
            bench: bench || [],
            updatedAt: now
          };
        } else {
          // Before creating new, remove any other duplicates with the same name for this team
          // This prevents duplicates from accumulating
          allConfigs = allConfigs.filter(
            config => !(config.teamName === teamName && config.name.toLowerCase() === trimmedName.toLowerCase())
          );
          
          // Create new config
          const newConfig = {
            id: `squad_${now}`,
            teamName: teamName,
            name: trimmedName,
            startingSquad: startingSquad || [],
            bench: bench || [],
            createdAt: now,
            updatedAt: now
          };
          allConfigs.push(newConfig);
        }
        
        chrome.storage.local.set({ squadConfigurations: allConfigs }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          // Return the updated/created config
          const savedConfig = existingIndex >= 0 ? allConfigs[existingIndex] : allConfigs[allConfigs.length - 1];
          resolve(savedConfig);
        });
      });
    });
  }
  
  deleteSquadConfiguration(configId) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.storage) {
        reject(new Error('Storage not available'));
        return;
      }
      
      chrome.storage.local.get(['squadConfigurations'], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        
        const allConfigs = result.squadConfigurations || [];
        const filtered = allConfigs.filter(config => config.id !== configId);
        
        chrome.storage.local.set({ squadConfigurations: filtered }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve();
        });
      });
    });
  }
  
  // SQUAD CONFIGURATION UI RENDERING FUNCTIONS
  
  populateSquadConfigSelector(teamName) {
    const selector = document.getElementById('editorSquadConfigSelect');
    if (!selector) return Promise.resolve();
    
    selector.innerHTML = '<option value="">— Or select existing —</option>';
    
    if (!teamName) {
      return Promise.resolve();
    }
    
    return this.loadSquadConfigurations(teamName).then(configs => {
      // Remove duplicates by name (keep the most recent one)
      const uniqueConfigs = [];
      const seenNames = new Map(); // Map to track name -> config
      
      // Sort by updatedAt descending to keep most recent
      const sortedConfigs = [...configs].sort((a, b) => 
        (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0)
      );
      
      sortedConfigs.forEach(config => {
        const nameKey = (config.name || '').toLowerCase().trim();
        if (!nameKey) return; // Skip configs with empty names
        
        if (!seenNames.has(nameKey)) {
          seenNames.set(nameKey, config);
          uniqueConfigs.push(config);
        }
      });
      
      // Clear and populate selector
      selector.innerHTML = '<option value="">New Squad</option>';
      uniqueConfigs.forEach(config => {
        const option = document.createElement('option');
        option.value = config.id;
        option.textContent = config.name;
        selector.appendChild(option);
      });
    }).catch(err => {
      console.error('Error loading squad configurations:', err);
    });
  }
  
  renderStartingSquad(playerIds) {
    const squadList = document.getElementById('editorStartingSquadList');
    const countSpan = document.getElementById('editorStartingSquadCount');
    if (!squadList) return;
    
    if (!playerIds || playerIds.length === 0) {
      const emptyMsg = this.selectedPlayerForSquad ? 'Click to add selected player' : 'Click players to add';
      squadList.innerHTML = `<div class="editor-squad-empty">${emptyMsg}</div>`;
      if (countSpan) countSpan.textContent = '0';
      return;
    }
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      squadList.innerHTML = '<div class="editor-squad-empty">Unable to load players</div>';
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const allPlayers = result.players || [];
      console.log('renderStartingSquad - playerIds:', playerIds, 'allPlayers count:', allPlayers.length);
      
      // Convert playerIds to strings for comparison
      const playerIdStrings = playerIds.map(id => String(id));
      const squadPlayers = allPlayers.filter(p => playerIdStrings.includes(String(p.id)));
      
      console.log('renderStartingSquad - found players:', squadPlayers.length, squadPlayers);
      
      squadList.innerHTML = '';
      
      if (squadPlayers.length === 0) {
        const emptyMsg = this.selectedPlayerForSquad ? 'Click to add selected player' : 'Click players to add';
        squadList.innerHTML = `<div class="editor-squad-empty">${emptyMsg}</div>`;
        if (countSpan) countSpan.textContent = '0';
        return;
      }
      
      if (countSpan) countSpan.textContent = squadPlayers.length.toString();
      
      squadPlayers.forEach(player => {
        const item = this.createSquadPlayerItem(player, 'starting');
        squadList.appendChild(item);
      });
    });
  }
  
  renderBench(playerIds) {
    const benchList = document.getElementById('editorBenchSquadList');
    const countSpan = document.getElementById('editorBenchSquadCount');
    if (!benchList) return;
    
    if (!playerIds || playerIds.length === 0) {
      const emptyMsg = this.selectedPlayerForSquad ? 'Click to add selected player' : 'Click players to add';
      benchList.innerHTML = `<div class="editor-squad-empty">${emptyMsg}</div>`;
      if (countSpan) countSpan.textContent = '0';
      return;
    }
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      benchList.innerHTML = '<div class="editor-squad-empty">Unable to load players</div>';
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const allPlayers = result.players || [];
      console.log('renderBench - playerIds:', playerIds, 'allPlayers count:', allPlayers.length);
      
      // Convert playerIds to strings for comparison
      const playerIdStrings = playerIds.map(id => String(id));
      const benchPlayers = allPlayers.filter(p => playerIdStrings.includes(String(p.id)));
      
      console.log('renderBench - found players:', benchPlayers.length, benchPlayers);
      
      benchList.innerHTML = '';
      
      if (benchPlayers.length === 0) {
        const emptyMsg = this.selectedPlayerForSquad ? 'Click to add selected player' : 'Click players to add';
        benchList.innerHTML = `<div class="editor-squad-empty">${emptyMsg}</div>`;
        if (countSpan) countSpan.textContent = '0';
        return;
      }
      
      if (countSpan) countSpan.textContent = benchPlayers.length.toString();
      
      benchPlayers.forEach(player => {
        const item = this.createSquadPlayerItem(player, 'bench');
        benchList.appendChild(item);
      });
    });
  }
  
  createSquadPlayerItem(player, squadType) {
    const item = document.createElement('div');
    item.className = 'editor-squad-player-item';
    item.draggable = true;
    item.dataset.playerId = player.id;
    item.dataset.squadType = squadType;
    
    const numberDiv = document.createElement('div');
    numberDiv.className = 'editor-squad-player-number';
    numberDiv.textContent = player.number || '?';
    
    const infoDiv = document.createElement('div');
    infoDiv.className = 'editor-squad-player-info';
    
    const nameDiv = document.createElement('div');
    nameDiv.className = 'editor-squad-player-name';
    const unknownText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.unknown')
      : 'Unknown';
    nameDiv.textContent = player.fullName || unknownText;
    
    const positionDiv = document.createElement('div');
    positionDiv.className = 'editor-squad-player-position';
    positionDiv.textContent = player.position || '';
    
    infoDiv.appendChild(nameDiv);
    if (player.position) {
      infoDiv.appendChild(positionDiv);
    }
    
    const removeBtn = document.createElement('button');
    removeBtn.className = 'editor-squad-player-remove';
    removeBtn.innerHTML = '×';
    removeBtn.title = 'Remove from squad';
    removeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.removePlayerFromSquad(player.id, squadType);
    });
    
    item.appendChild(numberDiv);
    item.appendChild(infoDiv);
    item.appendChild(removeBtn);
    
    // Drag events - support dragging to canvas
    item.addEventListener('dragstart', (e) => {
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'copy';
      
      // Store player data for canvas drop
      this.playerDragData = {
        id: player.id,
        number: player.number || '',
        fullName: player.fullName || player.surname || '',
        position: player.position || '',
        team: player.team || null
      };
      
      // Also set data for squad reordering (if needed)
      e.dataTransfer.setData('text/plain', JSON.stringify({
        playerId: player.id,
        squadType: squadType,
        source: 'squad'
      }));
      
      // Set drag image preview
      const dragPreview = document.createElement('div');
      dragPreview.className = 'editor-player-drag-preview';
      dragPreview.textContent = player.number || '?';
      document.body.appendChild(dragPreview);
      e.dataTransfer.setDragImage(dragPreview, 20, 20);
      
      // Remove after drag starts
      setTimeout(() => {
        if (dragPreview.parentNode) {
          dragPreview.parentNode.removeChild(dragPreview);
        }
      }, 0);
    });
    
    item.addEventListener('dragend', (e) => {
      item.classList.remove('dragging');
      // Clear playerDragData if drag was cancelled (drop handler clears it if drop succeeded)
      // Safe to clear here even if drop happened, as drop handler already cleared it
      this.playerDragData = null;
    });
    
    return item;
  }
  
  removePlayerFromSquad(playerId, squadType) {
    if (squadType === 'starting') {
      const currentSquad = this.currentStartingSquad || [];
      this.currentStartingSquad = currentSquad.filter(id => id !== playerId);
      this.renderStartingSquad(this.currentStartingSquad);
    } else if (squadType === 'bench') {
      const currentBench = this.currentBench || [];
      this.currentBench = currentBench.filter(id => id !== playerId);
      this.renderBench(this.currentBench);
    }
  }
  
  loadSquadConfiguration(configId) {
    if (!configId) {
      // Load "New Squad" - clear current
      this.currentStartingSquad = [];
      this.currentBench = [];
      this.currentSquadConfigId = null;
      this.renderStartingSquad([]);
      this.renderBench([]);
      
      const deleteBtn = document.getElementById('editorSquadConfigDeleteBtn');
      if (deleteBtn) deleteBtn.style.display = 'none';
      return;
    }
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      showNotification('Unable to load configuration', 'error', 2000);
      return;
    }
    
    chrome.storage.local.get(['squadConfigurations'], (result) => {
      if (chrome.runtime.lastError) {
        showNotification('Error loading configuration', 'error', 2000);
        return;
      }
      
      const allConfigs = result.squadConfigurations || [];
      const config = allConfigs.find(c => c.id === configId);
      
      if (!config) {
        const message = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.configurationNotFound')
          : 'Configuration not found';
        showNotification(message, 'error', 2000);
        return;
      }
      
      this.currentStartingSquad = config.startingSquad || [];
      this.currentBench = config.bench || [];
      this.currentSquadConfigId = configId;
      this.currentNewSquadName = config.name || '';
      
      // Populate the name input with the loaded config name
      const nameInput = document.getElementById('editorSquadNameInput');
      if (nameInput) {
        nameInput.value = config.name || '';
      }
      
      this.renderStartingSquad(this.currentStartingSquad);
      this.renderBench(this.currentBench);
      
      const deleteBtn = document.getElementById('editorSquadConfigDeleteBtn');
      if (deleteBtn) deleteBtn.style.display = 'block';
    });
  }
  
  clearSquadConfiguration() {
    this.currentStartingSquad = [];
    this.currentBench = [];
    this.currentSquadConfigId = null;
    this.currentNewSquadName = '';
    this.renderStartingSquad([]);
    this.renderBench([]);
    
    const selector = document.getElementById('editorSquadConfigSelect');
    if (selector) selector.value = '';
    
    const deleteBtn = document.getElementById('editorSquadConfigDeleteBtn');
    if (deleteBtn) deleteBtn.style.display = 'none';
    
    // Name input is always visible, just clear it
    const nameInput = document.getElementById('editorSquadNameInput');
    if (nameInput) {
      nameInput.value = '';
      nameInput.placeholder = 'Enter squad name...';
    }
  }
  
  openSaveSquadModal() {
    const modal = document.getElementById('editorSaveSquadModal');
    const modalNameInput = document.getElementById('editorSquadConfigNameInput');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    const squadNameInput = document.getElementById('editorSquadNameInput');
    
    if (!modal || !modalNameInput || !teamSelect) return;
    
    const teamName = teamSelect.value;
    if (!teamName) {
      const message = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.pleaseSelectTeamFirst')
        : (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.pleaseSelectTeamFirst') : 'Please select a team first');
      showNotification(message, 'warning', 2000);
      return;
    }
    
    // Pre-fill with current config name if editing, or from inline input if new squad
    if (this.currentSquadConfigId) {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get(['squadConfigurations'], (result) => {
          const configs = result.squadConfigurations || [];
          const config = configs.find(c => c.id === this.currentSquadConfigId);
          if (config) {
            modalNameInput.value = config.name;
          }
        });
      }
    } else {
      // Use name from inline input if available
      modalNameInput.value = (squadNameInput && squadNameInput.value.trim()) || this.currentNewSquadName || '';
    }
    
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
    setTimeout(() => modalNameInput.focus(), 100);
  }
  
  closeSaveSquadModal() {
    const modal = document.getElementById('editorSaveSquadModal');
    const modalNameInput = document.getElementById('editorSquadConfigNameInput');
    
    if (modal) {
      modal.classList.add('hidden');
      modal.style.display = 'none';
    }
    if (modalNameInput) {
      modalNameInput.value = '';
    }
  }
  
  handleSaveSquadConfiguration() {
    const squadNameInput = document.getElementById('editorSquadNameInput');
    const teamSelect = document.getElementById('editorPlayerTeamSelect');
    
    if (!squadNameInput || !teamSelect) return;
    
    const name = squadNameInput.value.trim();
    const teamName = teamSelect.value;
    
    if (!teamName) {
      const message = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.pleaseSelectTeamFirst')
        : (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t('editor.pleaseSelectTeamFirst') : 'Please select a team first');
      showNotification(message, 'warning', 2000);
      return;
    }
    
    if (!name) {
      const squadNameText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.enterSquadName')
        : 'Please enter a squad name';
      showNotification(squadNameText, 'warning', 2000);
      squadNameInput.focus();
      return;
    }
    
    const startingSquad = this.currentStartingSquad || [];
    const bench = this.currentBench || [];
    
    this.saveSquadConfiguration(teamName, name, startingSquad, bench)
      .then((config) => {
        showNotification('Squad configuration saved', 'success', 2000);
        this.currentSquadConfigId = config.id;
        this.currentNewSquadName = name;
        
        // Update selector and wait for it to complete before selecting
        this.populateSquadConfigSelector(teamName).then(() => {
          // Select the saved config after options are populated
          const selector = document.getElementById('editorSquadConfigSelect');
          if (selector) {
            selector.value = config.id;
          }
          
          const deleteBtn = document.getElementById('editorSquadConfigDeleteBtn');
          if (deleteBtn) deleteBtn.style.display = 'block';
        });
      })
      .catch((err) => {
        console.error('Error saving squad configuration:', err);
        showNotification('Error saving configuration: ' + (err.message || 'Unknown error'), 'error', 3000);
      });
  }
  
  setupSquadClickHandlers() {
    const startingSquadList = document.getElementById('editorStartingSquadList');
    const benchSquadList = document.getElementById('editorBenchSquadList');
    
    if (!startingSquadList || !benchSquadList) {
      return;
    }
    
    // Initialize current squad arrays
    if (!this.currentStartingSquad) this.currentStartingSquad = [];
    if (!this.currentBench) this.currentBench = [];
    this.selectedPlayerForSquad = null;
    
    // Check if listeners are already attached (avoid duplicates)
    if (startingSquadList.dataset.clickSetup === 'true' && benchSquadList.dataset.clickSetup === 'true') {
      return;
    }
    
    // Mark as set up
    startingSquadList.dataset.clickSetup = 'true';
    benchSquadList.dataset.clickSetup = 'true';
    
    // Click handler for Starting Squad
    startingSquadList.addEventListener('click', (e) => {
      // Don't trigger if clicking on a player item or remove button
      if (e.target.closest('.editor-squad-player-item') || e.target.closest('.editor-squad-player-remove')) {
        return;
      }
      
      if (!this.selectedPlayerForSquad) {
        const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleaseSelectPlayerFromList')
          : 'Please select a player from the list first';
        showNotification(selectPlayerText, 'warning', 2000);
        return;
      }
      
      const playerId = String(this.selectedPlayerForSquad);
      
      // Initialize arrays if needed
      if (!this.currentStartingSquad) this.currentStartingSquad = [];
      if (!this.currentBench) this.currentBench = [];
      
      // Remove from bench if it's there
      this.currentBench = this.currentBench.filter(id => String(id) !== playerId);
      
      // Add to starting squad if not already there
      if (!this.currentStartingSquad.some(id => String(id) === playerId)) {
        this.currentStartingSquad.push(playerId);
      }
      
      // Clear selection and highlight
      this.clearPlayerSelection();
      
      this.renderStartingSquad(this.currentStartingSquad);
      this.renderBench(this.currentBench);
      
      showNotification('Player added to starting squad', 'success', 2000);
    });
    
    // Click handler for Bench
    benchSquadList.addEventListener('click', (e) => {
      // Don't trigger if clicking on a player item or remove button
      if (e.target.closest('.editor-squad-player-item') || e.target.closest('.editor-squad-player-remove')) {
        return;
      }
      
      if (!this.selectedPlayerForSquad) {
        const selectPlayerText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleaseSelectPlayerFromList')
          : 'Please select a player from the list first';
        showNotification(selectPlayerText, 'warning', 2000);
        return;
      }
      
      const playerId = String(this.selectedPlayerForSquad);
      
      // Initialize arrays if needed
      if (!this.currentStartingSquad) this.currentStartingSquad = [];
      if (!this.currentBench) this.currentBench = [];
      
      // Remove from starting squad if it's there
      this.currentStartingSquad = this.currentStartingSquad.filter(id => String(id) !== playerId);
      
      // Add to bench if not already there
      if (!this.currentBench.some(id => String(id) === playerId)) {
        this.currentBench.push(playerId);
      }
      
      // Clear selection and highlight
      this.clearPlayerSelection();
      
      this.renderStartingSquad(this.currentStartingSquad);
      this.renderBench(this.currentBench);
      
      showNotification('Player added to bench', 'success', 2000);
    });
  }
  
  clearPlayerSelection() {
    this.selectedPlayerForSquad = null;
    
    const playerList = document.getElementById('editorPlayerList');
    if (playerList) {
      const selected = playerList.querySelector('.editor-player-item-selected');
      if (selected) {
        selected.classList.remove('editor-player-item-selected');
      }
    }
    
    const startingSquadList = document.getElementById('editorStartingSquadList');
    const benchSquadList = document.getElementById('editorBenchSquadList');
    if (startingSquadList) {
      startingSquadList.classList.remove('editor-squad-list-ready');
      const emptyDiv = startingSquadList.querySelector('.editor-squad-empty');
      if (emptyDiv) {
        emptyDiv.textContent = 'Click players to add';
      }
    }
    if (benchSquadList) {
      benchSquadList.classList.remove('editor-squad-list-ready');
      const emptyDiv = benchSquadList.querySelector('.editor-squad-empty');
      if (emptyDiv) {
        emptyDiv.textContent = 'Click players to add';
      }
    }
  }

  setupPlayerDragDrop() {
    const canvas = this.canvas;
    if (!canvas) return;
    
    // We need to track the drag position
    this.playerDragData = null;
    
    const canvasContainer = canvas.parentElement;
    
    // Handle dragover on both canvas and container
    const handleDragOver = (e) => {
      if (this.playerDragData) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
      }
    };
    
    canvas.addEventListener('dragover', handleDragOver);
    if (canvasContainer) {
      canvasContainer.addEventListener('dragover', handleDragOver);
    }
    
    // Handle drop on both canvas and container
    const handleDrop = (e) => {
      // Check if drop is on a squad zone (don't handle if so)
      const target = e.target;
      if (target && (target.closest('#editorStartingSquadList') || target.closest('#editorBenchSquadList'))) {
        // Let the squad drop handler take care of it
        return;
      }
      
      // playerDragData should be set by dragstart handler (from player list or squad items)
      if (this.playerDragData) {
        e.preventDefault();
        e.stopPropagation();
        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        this.placePlayerAtPosition(this.playerDragData, x, y);
        this.playerDragData = null;
      }
    };
    
    canvas.addEventListener('drop', handleDrop);
    if (canvasContainer) {
      canvasContainer.addEventListener('drop', handleDrop);
    }
  }

  handlePlayerDragStart(e, player) {
    const item = e.currentTarget;
    item.classList.add('dragging');
    
    // Store player data
    this.playerDragData = {
      id: player.id,
      number: player.number || '',
      fullName: player.fullName || '',
      position: player.position || '',
      team: player.team || ''
    };
    
    // Set drag image (optional custom image)
    const dragPreview = document.createElement('div');
    dragPreview.className = 'editor-player-drag-preview';
    dragPreview.textContent = player.number || '?';
    document.body.appendChild(dragPreview);
    e.dataTransfer.setDragImage(dragPreview, 20, 20);
    
    // Remove after drag starts
    setTimeout(() => {
      if (dragPreview.parentNode) {
        dragPreview.parentNode.removeChild(dragPreview);
      }
    }, 0);
    
    e.dataTransfer.effectAllowed = 'copy';
  }

  handlePlayerDragEnd(e) {
    const item = e.currentTarget;
    item.classList.remove('dragging');
    this.playerDragData = null;
  }

  placePlayerAtPosition(playerData, x, y) {
    // Get team color for the player
    const teamName = playerData.team;
    
    if (typeof chrome === 'undefined' || !chrome.storage) {
      // No storage - use default position (left side)
      const nativePosition = this.getPositionForRole(playerData.position, 'left');
      const finalX = nativePosition ? nativePosition.x : x;
      const finalY = nativePosition ? nativePosition.y : y;
      this.createPlayerTshirt(playerData, finalX, finalY, '#FFFFFF');
      return;
    }
    
    chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
      const analyses = result.analyses || [];
      const currentAnalysisId = this.currentAnalysisId || result.currentAnalysisId;
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      let teamColor = '#FFFFFF';
      let teamSide = 'left'; // Default to left side
      
      if (analysis && analysis.teams) {
        // Determine which side the team is on
        // First team in the array = left side (home)
        // Second team = right side (away)
        const teamIndex = analysis.teams.findIndex(t => (t.name || t) === teamName);
        if (teamIndex === 1) {
          teamSide = 'right';
        }
        
        const teamObj = analysis.teams.find(t => (t.name || t) === teamName);
        if (teamObj && typeof teamObj === 'object') {
          teamColor = teamObj.homeColor || '#FFFFFF';
        }
      }
      
      // Calculate position based on player's role and team side
      const nativePosition = this.getPositionForRole(playerData.position, teamSide);
      const finalX = nativePosition ? nativePosition.x : x;
      const finalY = nativePosition ? nativePosition.y : y;
      
      this.createPlayerTshirt(playerData, finalX, finalY, teamColor);
    });
  }
  
  // Convert player position/role to field coordinates
  // teamSide: 'left' or 'right' - which half of the field the team plays on
  getPositionForRole(position, teamSide = null) {
    if (!position || !this.canvas) return null;
    
    const canvasWidth = this.canvas.width;
    const canvasHeight = this.canvas.height;
    
    // Normalize position string - remove spaces, convert to uppercase
    const pos = position.toUpperCase().trim().replace(/\s+/g, '');
    
    // Define positions as percentage of field (0-100 scale)
    // For HORIZONTAL field layout:
    // x: 0 = left (defending goal), 100 = right (attacking goal) - DEPTH
    // y: 0 = top, 100 = bottom - WIDTH of field
    // Note: x values will be flipped for right-side teams
    const positionMap = {
      // Goalkeeper - near defending goal (x: 8), centered vertically (y: 50)
      'GK': { x: 8, y: 50 },
      'GOALKEEPER': { x: 8, y: 50 },
      
      // Defenders - near goal, spread vertically
      'DEF': { x: 18, y: 50 },
      'DEFENDER': { x: 18, y: 50 },
      'CB': { x: 18, y: 50 },        // Center Back
      'LB': { x: 18, y: 20 },        // Left Back (top of field)
      'RB': { x: 18, y: 80 },        // Right Back (bottom of field)
      'LWB': { x: 22, y: 15 },       // Left Wing Back
      'RWB': { x: 22, y: 85 },       // Right Wing Back
      'SW': { x: 14, y: 50 },        // Sweeper
      
      // Defensive Midfielders
      'DM': { x: 30, y: 50 },        // Defensive Mid
      'CDM': { x: 30, y: 50 },       // Central Defensive Mid
      'LDM': { x: 30, y: 35 },       // Left Defensive Mid
      'RDM': { x: 30, y: 65 },       // Right Defensive Mid
      
      // Midfielders - center of the half
      'MID': { x: 38, y: 50 },
      'MIDFIELDER': { x: 38, y: 50 },
      'CM': { x: 38, y: 50 },        // Central Mid
      'LM': { x: 38, y: 20 },        // Left Mid
      'RM': { x: 38, y: 80 },        // Right Mid
      'LCM': { x: 38, y: 35 },       // Left Center Mid
      'RCM': { x: 38, y: 65 },       // Right Center Mid
      
      // Attacking Midfielders
      'AM': { x: 46, y: 50 },        // Attacking Mid
      'CAM': { x: 46, y: 50 },       // Central Attacking Mid
      'LAM': { x: 46, y: 35 },       // Left Attacking Mid
      'RAM': { x: 46, y: 65 },       // Right Attacking Mid
      
      // Wingers - near center line, wide positions
      'LW': { x: 48, y: 15 },        // Left Winger
      'RW': { x: 48, y: 85 },        // Right Winger
      'WINGER': { x: 48, y: 25 },
      
      // Forwards - near center line
      'FWD': { x: 50, y: 50 },
      'FORWARD': { x: 50, y: 50 },
      'FW': { x: 50, y: 50 },
      'ST': { x: 50, y: 50 },        // Striker
      'CF': { x: 48, y: 50 },        // Center Forward
      'LF': { x: 50, y: 35 },        // Left Forward
      'RF': { x: 50, y: 65 },        // Right Forward
      'SS': { x: 46, y: 50 },        // Second Striker
    };
    
    // Try to find exact match
    let coords = positionMap[pos];
    
    // If not found, try to match partial
    if (!coords) {
      if (pos.includes('GK') || pos.includes('GOAL')) {
        coords = positionMap['GK'];
      } else if (pos.includes('DEF') || pos.includes('BACK')) {
        coords = positionMap['DEF'];
      } else if (pos.includes('MID')) {
        coords = positionMap['MID'];
      } else if (pos.includes('FWD') || pos.includes('FORWARD') || pos.includes('STRIKER') || pos.includes('ATTACK')) {
        coords = positionMap['FWD'];
      }
    }
    
    if (!coords) return null;
    
    // If team is on the right side, flip the x coordinate
    // (GK goes from 8% to 92%, etc.)
    let finalX = coords.x;
    if (teamSide === 'right') {
      finalX = 100 - coords.x;
    }
    
    // Convert percentage to actual canvas coordinates
    return {
      x: (finalX / 100) * canvasWidth,
      y: (coords.y / 100) * canvasHeight
    };
  }

  createPlayerTshirt(playerData, x, y, color) {
    // Scale default size based on original canvas dimensions (not rotated)
    const canvasWidth = this.originalCanvasWidth || this.canvas.width || this.referenceCanvasWidth;
    const canvasHeight = this.originalCanvasHeight || this.canvas.height || this.referenceCanvasHeight;
    const scaleFactor = Math.min(
      canvasWidth / this.referenceCanvasWidth,
      canvasHeight / this.referenceCanvasHeight
    );
    const tshirtWidth = 35 * scaleFactor;
    const tshirtHeight = 47 * scaleFactor;
    
    const drawing = {
      type: 'tshirt',
      startX: x - tshirtWidth / 2,
      startY: y - tshirtHeight / 2,
      endX: x + tshirtWidth / 2,
      endY: y + tshirtHeight / 2,
      color: color,
      number: playerData.number || '',
      surname: (playerData.fullName || '').split(' ').pop().toUpperCase(),
      position: playerData.position || '', // Store position
      design: this.tshirtDesign || 'solid',
      secondColor: this.tshirtSecondColor || '#000000',
      aspectRatio: 3 / 4,
      team: playerData.team || null,
      playerId: playerData.id
    };
    
    this.drawings.push(drawing);
    this.saveState();
    this.redraw();
    
    // Select the newly created t-shirt
    this.selectedDrawings = [this.drawings.length - 1];
    this.updateSelectionControls();
  }

  placeFormationWithColor(clickX, clickY, baseColor, formationName = null) {
    const allFormations = getAllFormations();
    const formation = allFormations[formationName || this.currentFormation];
    if (!formation) {
      console.error('Formation not found:', this.currentFormation);
      return;
    }

    // Fetch squad data and players if a team is selected
    this.getSquadData((squadData, players) => {
      this.placeFormationWithSquad(clickX, clickY, baseColor, formation, squadData, players);
    });
  }

  getSquadData(callback) {
    const teamName = this.formationTeam;
    if (!teamName || typeof chrome === 'undefined' || !chrome.storage) {
      callback({}, []);
      return;
    }

    chrome.storage.local.get(['analyses', 'players', 'currentAnalysisId'], (result) => {
      const analyses = result.analyses || [];
      const players = result.players || [];
      const analysis = analyses.find(a => a.id === (this.currentAnalysisId || result.currentAnalysisId));
      
      let squadData = {};
      if (analysis && analysis.teams) {
        const teamObj = analysis.teams.find(t => (t.name || t) === teamName);
        if (teamObj && teamObj.squad) {
          squadData = teamObj.squad;
        }
      }
      
      // Filter players for this team
      const teamPlayers = players.filter(p => p.team === teamName);
      callback(squadData, teamPlayers);
    });
  }

  placeFormationWithSquad(clickX, clickY, baseColor, formation, squadData, players) {
    // Use original canvas dimensions for consistent sizing regardless of rotation
    const canvasWidth = this.originalCanvasWidth || this.canvas.width || this.referenceCanvasWidth;
    const canvasHeight = this.originalCanvasHeight || this.canvas.height || this.referenceCanvasHeight;
    const fieldWidth = canvasWidth;
    const fieldHeight = canvasHeight;
    // Scale default size based on original canvas dimensions (not rotated)
    const scaleFactor = Math.min(
      canvasWidth / this.referenceCanvasWidth,
      canvasHeight / this.referenceCanvasHeight
    );
    const tshirtWidth = 35 * scaleFactor; // Scaled default t-shirt width
    const tshirtHeight = 47 * scaleFactor; // Scaled default t-shirt height (3:4 ratio)
    
    // Helper function to get player data for a position index
    const getPlayerForPosition = (positionIndex) => {
      // Squad data keys may be stored as strings, so check both
      const playerId = squadData[positionIndex] || squadData[String(positionIndex)];
      if (playerId) {
        return players.find(p => p.id === playerId);
      }
      return null;
    };
    
    // Check if this is a custom formation with exact positions
    if (formation.isCustom) {
      // For custom formations, place players at their exact saved positions
      const newDrawings = [];
      
      formation.positions.forEach((pos, index) => {
        // Convert relative positions (0-100) back to canvas coordinates
        const playerX = (pos.x / 100) * fieldWidth;
        const playerY = (pos.y / 100) * fieldHeight;
        
        // Determine color: use team colors if team is selected, otherwise use formation color
        let playerColor = baseColor;
        
        // Goalkeeper gets opposite color
        if (pos.role === 'GK') {
          // Calculate opposite color (invert brightness)
          const hex = playerColor.replace('#', '');
          const r = parseInt(hex.substr(0, 2), 16);
          const g = parseInt(hex.substr(2, 2), 16);
          const b = parseInt(hex.substr(4, 2), 16);
          const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
          if (brightness > 128) {
            playerColor = '#000000';
          } else {
            playerColor = '#FFFFFF';
          }
        }
        
        // Get assigned player for this position
        const assignedPlayer = getPlayerForPosition(index);
        const playerNumber = assignedPlayer ? (assignedPlayer.number || pos.number) : pos.number;
        const playerSurname = assignedPlayer ? (assignedPlayer.fullName || '').split(' ').pop().toUpperCase() : '';
        
        // Create t-shirt drawing
        const drawing = {
          type: 'tshirt',
          startX: playerX - tshirtWidth / 2,
          startY: playerY - tshirtHeight / 2,
          endX: playerX + tshirtWidth / 2,
          endY: playerY + tshirtHeight / 2,
          color: playerColor,
          number: playerNumber,
          surname: playerSurname,
          design: this.tshirtDesign || 'solid',
          secondColor: this.tshirtSecondColor || '#000000',
          aspectRatio: 3 / 4,
          team: this.formationTeam || null, // Store team association
          playerId: assignedPlayer ? assignedPlayer.id : null
        };
        
        newDrawings.push(drawing);
      });
      
      // Add all drawings at once
      this.drawings.push(...newDrawings);
      this.saveState();
      
      // Automatically switch to select tool
      this.selectTool('select');
      
      // Select all the newly created t-shirts
      const startIndex = this.drawings.length - newDrawings.length;
      this.selectedDrawings = [];
      for (let i = startIndex; i < this.drawings.length; i++) {
        this.selectedDrawings.push(i);
      }
      
      this.updateSelectionControls();
      this.redraw();
      return;
    }
    
    // Standard formation placement logic for built-in formations
    // Determine which half of the field was clicked
    const clickedSide = clickX < fieldWidth / 2 ? 'left' : 'right';
    
    // Calculate centered position for the clicked half
    // Left half: center at 1/4 of field width, vertically centered
    // Right half: center at 3/4 of field width, vertically centered
    const halfCenterX = clickedSide === 'left' ? fieldWidth / 4 : (fieldWidth * 3) / 4;
    const halfCenterY = fieldHeight / 2;
    
    // Field margins to keep players within bounds
    const marginX = 50; // Margin from sides
    const marginY = 50; // Margin from top
    const goalMargin = 60; // Margin from bottom (goal area)
    
    // Calculate usable area for the half
    const halfWidth = fieldWidth / 2;
    const usableWidth = halfWidth - marginX;
    const usableHeight = fieldHeight - marginY - goalMargin;
    
    // Fixed spacing constants - HORIZONTAL formation (goalkeeper on one side, forwards on other)
    const depthSpacing = 250; // px per 50 units of depth (GK to forwards) - horizontal spacing
    const widthSpacing = 180; // px per 50 units of width (left-right) - vertical spacing

    // Calculate formation bounds from relative positions (0-100 scale)
    // In our data: x = horizontal position across field (left-right), y = depth (GK=low, forwards=high)
    let minX = 100, maxX = 0, minY = 100, maxY = 0;
    formation.positions.forEach(pos => {
      minX = Math.min(minX, pos.x);
      maxX = Math.max(maxX, pos.x);
      minY = Math.min(minY, pos.y);
      maxY = Math.max(maxY, pos.y);
    });
    
    // Find goalkeeper position
    const goalkeeperPos = formation.positions.find(pos => pos.role === 'GK');
    if (!goalkeeperPos) {
      console.error('No goalkeeper found in formation');
      return;
    }
    
    // Calculate formation depth range
    const formationDepth = maxY - minY;
    const formationWidth = maxX - minX;
    
    // Map formation coordinates to canvas coordinates for HORIZONTAL layout:
    // Formation x (0-100, left-right) -> Canvas Y (vertical, top-bottom)
    // Formation y (0-100, GK=low to forwards=high) -> Canvas X (horizontal, left-right)
    
    // Position goalkeeper at the edge of clicked half (in front of goal)
    // For left side: GK on left edge, forwards spread to right
    // For right side: GK on right edge, forwards spread to left
    let gkX, formationCenterY;
    if (clickedSide === 'left') {
      // Left side: GK on left edge
      gkX = marginX + tshirtWidth / 2;
      formationCenterY = halfCenterY; // Center vertically
    } else {
      // Right side: GK on right edge
      gkX = fieldWidth - marginX - tshirtWidth / 2;
      formationCenterY = halfCenterY; // Center vertically
    }
    
    // Scale factors
    const scaleY = usableHeight / 100; // Formation x (0-100) -> canvas height (vertical)
    const scaleX = usableWidth / formationDepth; // Formation y range -> canvas width (horizontal)
    
    // Create all t-shirt drawings
    const newDrawings = [];
    
    formation.positions.forEach((pos, index) => {
      // Vertical position: formation x (0-100, left-right) -> canvas Y
      // Center formation vertically on the clicked half
      const offsetY = (pos.x - 50) * scaleY; // Offset from center (50)
      let playerY = formationCenterY + offsetY;
      
      // Horizontal position: formation y (GK=low, forwards=high) -> canvas X
      // For left side: GK (y=low) on left, forwards (y=high) on right
      // For right side: GK (y=low) on right, forwards (y=high) on left (flipped)
      const yOffsetFromGK = pos.y - goalkeeperPos.y; // How far forward from GK
      let offsetX;
      if (clickedSide === 'left') {
        // Left side: depth increases from left (GK) to right (forwards)
        offsetX = yOffsetFromGK * scaleX;
      } else {
        // Right side: depth increases from right (GK) to left (forwards) - flipped
        offsetX = -yOffsetFromGK * scaleX;
      }
      let playerX = gkX + offsetX;
      
      // Ensure players stay within field bounds
      playerX = Math.max(tshirtWidth / 2, Math.min(fieldWidth - tshirtWidth / 2, playerX));
      playerY = Math.max(tshirtHeight / 2, Math.min(fieldHeight - tshirtHeight / 2, playerY));
      
      // Determine color: goalkeeper gets opposite color
      let playerColor = baseColor;
      if (pos.role === 'GK') {
        // Calculate opposite color (invert brightness)
        const hex = playerColor.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
        // If bright, make dark; if dark, make bright
        if (brightness > 128) {
          playerColor = '#000000'; // Dark for bright colors
        } else {
          playerColor = '#FFFFFF'; // Bright for dark colors
        }
      }
      
      // Get assigned player for this position
      const assignedPlayer = getPlayerForPosition(index);
      const playerNumber = assignedPlayer ? (assignedPlayer.number || pos.number) : pos.number;
      const playerSurname = assignedPlayer ? (assignedPlayer.fullName || '').split(' ').pop().toUpperCase() : '';
      
      // Create t-shirt drawing
      const drawing = {
        type: 'tshirt',
        startX: playerX - tshirtWidth / 2,
        startY: playerY - tshirtHeight / 2,
        endX: playerX + tshirtWidth / 2,
        endY: playerY + tshirtHeight / 2,
        color: playerColor,
        number: playerNumber,
        surname: playerSurname,
        design: this.tshirtDesign || 'solid',
        secondColor: this.tshirtSecondColor || '#000000',
        aspectRatio: 3 / 4, // T-shirt maintains 3:4 ratio
        team: this.formationTeam || null, // Store team association
        playerId: assignedPlayer ? assignedPlayer.id : null
      };
      
      newDrawings.push(drawing);
    });
    
    // Add all drawings at once (single undo/redo action)
    this.drawings.push(...newDrawings);
    this.saveState();
    
    // Automatically switch to select tool after placing formation
    // so the t-shirts can be edited as regular t-shirts
    this.selectTool('select');
    
    // Select all the newly created t-shirts
    const startIndex = this.drawings.length - newDrawings.length;
    this.selectedDrawings = [];
    for (let i = startIndex; i < this.drawings.length; i++) {
      this.selectedDrawings.push(i);
    }
    
    // Update selection controls to show t-shirt properties
    this.updateSelectionControls();
    this.redraw();
  }

  drawImageDrawing(drawing) {
    if (!drawing.imageData) return;
    
    // Apply opacity if specified
    const opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    this.ctx.save();
    this.ctx.globalAlpha = opacity;
    
    // If image is already loaded, use it directly
    if (drawing.imageElement) {
      this.ctx.drawImage(drawing.imageElement, drawing.x, drawing.y, drawing.width || drawing.originalWidth, drawing.height || drawing.originalHeight);
      this.ctx.restore();
    } else {
      // Load image if not already loaded
      const img = new Image();
      img.onload = () => {
        drawing.imageElement = img; // Cache the loaded image
        this.ctx.drawImage(img, drawing.x, drawing.y, drawing.width || drawing.originalWidth, drawing.height || drawing.originalHeight);
        this.ctx.restore();
        this.redraw(); // Redraw to show the image
      };
      img.src = drawing.imageData;
    }
  }

  drawBall(drawing) {
    // Normalize bounds first to ensure perfect roundness
    this.normalizeBallBounds(drawing);

    // Calculate center and size from normalized bounds
    // After normalization, width and height are guaranteed to be equal
    const centerX = (drawing.startX + drawing.endX) / 2;
    const centerY = (drawing.startY + drawing.endY) / 2;
    
    // Use the stored originalWidth (set by normalizeBallBounds) or calculate from bounds
    const size = drawing.originalWidth || Math.abs(drawing.endX - drawing.startX);
    const radius = size / 2;
    
    this.ctx.save();
    
    // Main ball body (color adjustable) - draw as circle
    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    this.ctx.fillStyle = drawing.color || '#FFFFFF';
    this.ctx.fill();
    this.ctx.lineWidth = 2;
    this.ctx.strokeStyle = '#000000';
    this.ctx.stroke();
    
    // Soccer pattern (Pentagons/Hexagons)
    this.ctx.clip(); // Clip drawing to the ball circle
    
    const patternColor = '#000000'; // Black spots
    // Use radius for pattern scaling
    const spotRadius = radius * 0.25; 
    
    // Central pentagon
    this.drawPentagon(centerX, centerY, spotRadius, patternColor);
    
    // Surrounding spots (partial hexagons/pentagons)
    // We draw 5 spots around the center
    for (let i = 0; i < 5; i++) {
      const angle = (i * 72 - 90) * Math.PI / 180; // Start from top
      const dist = radius * 0.65;
      const spotX = centerX + Math.cos(angle) * dist;
      const spotY = centerY + Math.sin(angle) * dist;
      
      // Draw connecting lines from center pentagon to outer spots
      const innerAngle = (i * 72 - 90) * Math.PI / 180;
      const innerX = centerX + Math.cos(innerAngle) * spotRadius;
      const innerY = centerY + Math.sin(innerAngle) * spotRadius;
      
      this.ctx.beginPath();
      this.ctx.moveTo(innerX, innerY);
      this.ctx.lineTo(spotX, spotY);
      this.ctx.lineWidth = 1.5;
      this.ctx.strokeStyle = patternColor;
      this.ctx.stroke();
      
      // Draw outer blobs
      this.drawPentagon(spotX, spotY, spotRadius * 1.1, patternColor); // Slightly larger outer spots
    }
    
    this.ctx.restore();
    
    // Draw number to the right of the ball (if exists and not null/empty)
    if (drawing.number !== undefined && drawing.number !== null && drawing.number !== '') {
      const numberX = centerX + radius + 6; // 6px to the right of the ball
      const numberY = centerY;
      
      this.ctx.save();
      this.ctx.fillStyle = drawing.color || '#FFFFFF';
      this.ctx.font = `bold ${Math.max(size * 0.6, 16)}px Arial`; // Scale with ball size
      this.ctx.textAlign = 'left';
      this.ctx.textBaseline = 'middle';
      this.ctx.fillText(drawing.number.toString(), numberX, numberY);
      this.ctx.restore();
    }
  }

  // Helper for soccer ball pattern
  drawPentagon(x, y, radius, color) {
    this.ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 72 - 90) * Math.PI / 180;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      if (i === 0) this.ctx.moveTo(px, py);
      else this.ctx.lineTo(px, py);
    }
    this.ctx.closePath();
    this.ctx.fillStyle = color;
    this.ctx.fill();
  }

  // Draw animation path with dashed line and arrow
  drawAnimPath(drawing) {
    this.ctx.save();
    
    // Animation path color (blue by default, highlight if linked)
    const isLinked = drawing.targetIndex !== undefined;
    const pathColor = drawing.color || '#1f6feb';
    const isSelected = this.selectedDrawings.includes(this.drawings.indexOf(drawing));
    
    this.ctx.strokeStyle = pathColor;
    this.ctx.lineWidth = (drawing.lineWidth || 2) * (drawing.opacity || 1);
    this.ctx.globalAlpha = drawing.opacity || 0.8;
    
    // Dashed line style
    this.ctx.setLineDash([8, 4]);
    
    // Draw smooth spline curve through all points (start, waypoints, end)
    const pathPoints = this.getPathPoints(drawing);
    
    if (pathPoints.length < 2) {
      // Not enough points, just draw a point
      this.ctx.beginPath();
      this.ctx.arc(drawing.startX, drawing.startY, 2, 0, Math.PI * 2);
      this.ctx.fill();
    } else if (pathPoints.length === 2) {
      // Only start and end - draw straight line
      this.ctx.beginPath();
      this.ctx.moveTo(pathPoints[0].x, pathPoints[0].y);
      this.ctx.lineTo(pathPoints[1].x, pathPoints[1].y);
      this.ctx.stroke();
    } else {
      // Multiple points - draw smooth spline curve
      this.ctx.beginPath();
      this.ctx.moveTo(pathPoints[0].x, pathPoints[0].y);
      
      // Draw smooth curve through all segments
      for (let i = 0; i < pathPoints.length - 1; i++) {
        const p0 = i > 0 ? pathPoints[i - 1] : pathPoints[0];
        const p1 = pathPoints[i];
        const p2 = pathPoints[i + 1];
        const p3 = i < pathPoints.length - 2 ? pathPoints[i + 2] : pathPoints[pathPoints.length - 1];
        
        // Calculate control points for quadratic bezier approximation
        // Use Catmull-Rom to bezier conversion
        const cp1x = p1.x + (p2.x - p0.x) / 6;
        const cp1y = p1.y + (p2.y - p0.y) / 6;
        const cp2x = p2.x - (p3.x - p1.x) / 6;
        const cp2y = p2.y - (p3.y - p1.y) / 6;
        
        if (i === 0) {
          // First segment: start from p1
          this.ctx.moveTo(p1.x, p1.y);
        }
        
        // Draw quadratic bezier curve to next point
        this.ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
      }
      
      this.ctx.stroke();
    }
    
    this.ctx.setLineDash([]);
    
    // Draw start point (circle)
    this.ctx.beginPath();
    this.ctx.arc(drawing.startX, drawing.startY, 5, 0, Math.PI * 2);
    this.ctx.fillStyle = pathColor;
    this.ctx.fill();
    
    // Draw waypoints (only when path is selected)
    if (isSelected && drawing.waypoints && drawing.waypoints.length > 0) {
      const pathIndex = this.drawings.indexOf(drawing);
      drawing.waypoints.forEach((waypoint, waypointIndex) => {
        const isHovered = this.hoveredWaypoint && 
                         this.hoveredWaypoint.pathIndex === pathIndex && 
                         this.hoveredWaypoint.waypointIndex === waypointIndex;
        const isSelected = this.selectedWaypoint && 
                          this.selectedWaypoint.pathIndex === pathIndex && 
                          this.selectedWaypoint.waypointIndex === waypointIndex;
        
        // Draw waypoint marker
        this.ctx.beginPath();
        const radius = isSelected ? 7 : (isHovered ? 6 : 5);
        this.ctx.arc(waypoint.x, waypoint.y, radius, 0, Math.PI * 2);
        this.ctx.fillStyle = isSelected ? '#ff6b6b' : (isHovered ? '#ffa500' : pathColor);
        this.ctx.fill();
        
        // Draw outline for selected waypoint
        if (isSelected) {
          this.ctx.strokeStyle = '#ff6b6b';
          this.ctx.lineWidth = 2;
          this.ctx.stroke();
        }
      });
    }
    
    // Draw end point (arrow)
    const endPathPoints = this.getPathPoints(drawing);
    if (endPathPoints.length >= 2) {
      const lastPoint = endPathPoints[endPathPoints.length - 1];
      const secondLastPoint = endPathPoints[endPathPoints.length - 2];
      const angle = Math.atan2(lastPoint.y - secondLastPoint.y, lastPoint.x - secondLastPoint.x);
      this.drawEndpoint(drawing.endX, drawing.endY, angle, 'triangle', false);
    } else {
      const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
      this.drawEndpoint(drawing.endX, drawing.endY, angle, 'triangle', false);
    }
    
    // If linked, draw a small link indicator
    if (isLinked) {
      this.ctx.beginPath();
      this.ctx.arc(drawing.startX, drawing.startY, 8, 0, Math.PI * 2);
      this.ctx.strokeStyle = '#3fb950';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  drawTshirt(drawing) {
    // Calculate center and dimensions from stored coordinates
    const centerX = (drawing.startX + drawing.endX) / 2;
    const centerY = (drawing.startY + drawing.endY) / 2;
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    
    // T-shirt uses the full bounding box (already maintains 3:4 ratio)
    const shirtWidth = width;
    const shirtHeight = height;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;

    this.ctx.save();
    
    const primaryColor = drawing.color || '#FFFFFF';
    const secondColor = drawing.secondColor || '#000000';
    const design = drawing.design || 'solid';
    
    // Improved t-shirt proportions
    const collarWidth = shirtWidth * 0.35;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;
    const sleeveLength = shirtWidth * 0.18;
    
    // Helper function to create t-shirt path
    const createTshirtPath = () => {
      this.ctx.beginPath();
      
      // Start at left shoulder (slightly below top for natural shoulder slope)
      this.ctx.moveTo(startX, startY + shirtHeight * 0.08);
      
      // Left shoulder curve to collar
      this.ctx.quadraticCurveTo(
        startX + shoulderWidth * 0.5, 
        startY, 
        startX + shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Neck cutout (deeper, more natural curve)
      this.ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight * 0.15, 
        startX + shirtWidth - shoulderWidth, 
        startY + shirtHeight * 0.03
      );
      
      // Right shoulder curve
      this.ctx.quadraticCurveTo(
        startX + shirtWidth - shoulderWidth * 0.5, 
        startY, 
        startX + shirtWidth, 
        startY + shirtHeight * 0.08
      );
      
      // Right sleeve (more natural shape)
      this.ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
      this.ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
      this.ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
      
      // Right side (slightly tapered for more natural body shape)
      const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
      this.ctx.lineTo(rightBottomX, startY + shirtHeight);
      
      // Bottom hem (slightly curved)
      this.ctx.quadraticCurveTo(
        centerX, 
        startY + shirtHeight + shirtHeight * 0.02, 
        startX + shirtWidth * 0.03, 
        startY + shirtHeight
      );
      
      // Left side (slightly tapered)
      this.ctx.lineTo(startX, startY + shirtHeight * 0.38);
      
      // Left sleeve (more natural shape)
      this.ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
      this.ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
      
      this.ctx.closePath();
    };
    
    // Draw the base fill first
    createTshirtPath();
    this.ctx.fillStyle = primaryColor;
    this.ctx.fill();
    
    // Apply design pattern
    this.ctx.save();
    createTshirtPath();
    this.ctx.clip();
    
    const extLeft = startX - sleeveLength;
    const extRight = startX + shirtWidth + sleeveLength;
    const extTop = startY;
    const extBottom = startY + shirtHeight;
    const extWidth = extRight - extLeft;
    const extHeight = extBottom - extTop;
    
    switch (design) {
      case 'sleeves':
        // Colored sleeves - draw sleeves with second color
        this.ctx.fillStyle = secondColor;
        // Left sleeve area
        this.ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        // Right sleeve area
        this.ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        break;
        
      case 'horiz-stripes':
        // Horizontal stripes (5 stripes)
        const hStripeHeight = extHeight / 5;
        this.ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          this.ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
        }
        break;
        
      case 'vert-stripes':
        // Vertical stripes (5 stripes)
        const vStripeWidth = extWidth / 5;
        this.ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          this.ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
        }
        break;
        
      case 'diagonal-sash':
        // Big diagonal sash from top-left to bottom-right
        this.ctx.fillStyle = secondColor;
        this.ctx.beginPath();
        const sashWidth = extWidth * 0.25;
        this.ctx.moveTo(extLeft, extTop);
        this.ctx.lineTo(extLeft + sashWidth, extTop);
        this.ctx.lineTo(extRight, extBottom - sashWidth * 0.8);
        this.ctx.lineTo(extRight, extBottom);
        this.ctx.lineTo(extRight - sashWidth, extBottom);
        this.ctx.lineTo(extLeft, extTop + sashWidth * 0.8);
        this.ctx.closePath();
        this.ctx.fill();
        break;
        
      case 'vert-sash':
        // Big vertical sash down the center
        this.ctx.fillStyle = secondColor;
        const vSashWidth = extWidth * 0.25;
        const vSashX = extLeft + (extWidth - vSashWidth) / 2;
        this.ctx.fillRect(vSashX, extTop, vSashWidth, extHeight);
        break;
        
      case 'horiz-sash':
        // Big horizontal sash across the middle
        this.ctx.fillStyle = secondColor;
        const hSashHeight = extHeight * 0.25;
        const hSashY = extTop + (extHeight - hSashHeight) / 2;
        this.ctx.fillRect(extLeft, hSashY, extWidth, hSashHeight);
        break;
        
      case 'checkered':
        // Checkered pattern (squares)
        const squareSize = Math.min(extWidth, extHeight) / 4;
        this.ctx.fillStyle = secondColor;
        for (let row = 0; row < Math.ceil(extHeight / squareSize); row++) {
          for (let col = 0; col < Math.ceil(extWidth / squareSize); col++) {
            if ((row + col) % 2 === 1) {
              this.ctx.fillRect(
                extLeft + col * squareSize,
                extTop + row * squareSize,
                squareSize,
                squareSize
              );
            }
          }
        }
        break;
        
      case 'solid':
      default:
        // Solid - no additional pattern needed
        break;
    }
    
    this.ctx.restore();
    
    // Draw the outline
    createTshirtPath();
    this.ctx.strokeStyle = '#000000';
    this.ctx.lineWidth = 2;
    this.ctx.stroke();
    
    // Number and Surname
    if (drawing.number !== undefined || drawing.surname) {
      // Determine text color based on brightness of tshirt color
      const hex = primaryColor.replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
      const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
      
      this.ctx.textAlign = 'center';
      
      // Draw number on the shirt
      if (drawing.number !== undefined) {
        this.ctx.fillStyle = textColor;
        this.ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(drawing.number, centerX, centerY + shirtHeight * 0.1);
      }
      
      // Draw surname and position below the shirt (outside, as a label)
      if (drawing.surname) {
        this.ctx.font = `bold ${Math.max(shirtHeight * 0.15, 10)}px Arial`;
        this.ctx.textBaseline = 'top';
        const surnameY = startY + shirtHeight + 4;
        const lineHeight = Math.max(shirtHeight * 0.15, 10) * 1.2;
        
        // Draw surname on first line
        const surnameText = drawing.surname;
        
        // Draw stroke with t-shirt color (visible but not too bold)
        this.ctx.strokeStyle = primaryColor;
        this.ctx.lineWidth = 2.5;
        this.ctx.lineJoin = 'round';
        this.ctx.strokeText(surnameText, centerX, surnameY);
        
        // Draw fill with same color as number
        this.ctx.fillStyle = textColor;
        this.ctx.fillText(surnameText, centerX, surnameY);
        
        // Draw position on second line (if exists)
        if (drawing.position && drawing.position.trim()) {
          const positionY = surnameY + lineHeight;
          this.ctx.strokeText(drawing.position, centerX, positionY);
          this.ctx.fillText(drawing.position, centerX, positionY);
        }
      }
    }
    
    this.ctx.restore();
  }

  drawCross(drawing) {
    // Draw X shape (two diagonal lines)
    this.ctx.beginPath();
    // First diagonal: top-left to bottom-right
    this.ctx.moveTo(drawing.startX, drawing.startY);
    this.ctx.lineTo(drawing.endX, drawing.endY);
    // Second diagonal: top-right to bottom-left
    this.ctx.moveTo(drawing.endX, drawing.startY);
    this.ctx.lineTo(drawing.startX, drawing.endY);
    this.ctx.stroke();
  }

  // Draw SVG-based football elements
  drawSvgElement(drawing) {
    if (!drawing.svgUrl) {
      console.warn('drawSvgElement: Missing svgUrl for drawing:', drawing.type);
      return;
    }
    
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    
    // Skip drawing only if dimensions are truly invalid (allow very small sizes)
    if (width < 0.1 || height < 0.1) {
      console.warn('drawSvgElement: Invalid dimensions for', drawing.type, 'width:', width, 'height:', height);
      return;
    }
    
    // Log if svgElement is missing
    if (!drawing.svgElement) {
      console.warn('drawSvgElement: svgElement not loaded for', drawing.type, 'svgUrl:', drawing.svgUrl, 'Will draw placeholder');
    }
    
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    
    this.ctx.save();
    
    // Apply rotation if present
    if (drawing.rotation) {
      this.ctx.translate(centerX, centerY);
      this.ctx.rotate(drawing.rotation);
      this.ctx.translate(-centerX, -centerY);
    }
    
    // Apply opacity if specified
    if (drawing.opacity !== undefined) {
      this.ctx.globalAlpha = drawing.opacity;
    }
    
    // Draw the SVG image
    if (drawing.svgElement && drawing.svgElement.complete && drawing.svgElement.naturalWidth > 0) {
      // Apply color if specified (using composite operation to tint the SVG)
      if (drawing.color && drawing.color !== '#000000') {
        // Create offscreen canvas for color application
        const tempCanvas = document.createElement('canvas');
        // Ensure minimum size of 1px to avoid canvas errors
        tempCanvas.width = Math.max(1, Math.round(width));
        tempCanvas.height = Math.max(1, Math.round(height));
        const tempCtx = tempCanvas.getContext('2d');
        
        // Draw SVG to temp canvas first
        tempCtx.drawImage(drawing.svgElement, 0, 0, tempCanvas.width, tempCanvas.height);
        
        // Apply color using source-in to mask color to SVG shape
        tempCtx.globalCompositeOperation = 'source-in';
        tempCtx.fillStyle = drawing.color;
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        tempCtx.globalCompositeOperation = 'source-over';
        
        // Draw colored result to main canvas
        this.ctx.drawImage(tempCanvas, left, top, width, height);
      } else {
        // Draw without color tint
        this.ctx.drawImage(drawing.svgElement, left, top, width, height);
      }
      console.log('drawSvgElement: Successfully drew', drawing.type, 'at', left, top, 'size', width, 'x', height);
    } else {
      // Try to use cached SVG first
      if (this.svgCache[drawing.type]) {
        drawing.svgElement = this.svgCache[drawing.type];
        console.log('drawSvgElement: Recovered from cache for', drawing.type);
        // Redraw to show the recovered SVG
        requestAnimationFrame(() => this.redraw());
    } else {
      // Fallback: draw a placeholder rectangle if SVG is not loaded yet
      console.warn('drawSvgElement: SVG element not loaded for', drawing.type, 'drawing placeholder rectangle');
      this.ctx.strokeStyle = drawing.color || '#FFFFFF';
      this.ctx.lineWidth = 2;
      this.ctx.strokeRect(left, top, width, height);
      this.ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      this.ctx.fillRect(left, top, width, height);
        
        // Try to reload SVG if URL is available but element is missing
        if (drawing.svgUrl && !drawing.svgElement && !drawing._loadingInProgress) {
          drawing._loadingInProgress = true;
          console.log('drawSvgElement: Attempting to reload SVG for', drawing.type, 'URL:', drawing.svgUrl);
          this.loadSvgElement(drawing.svgUrl).then(img => {
            drawing.svgElement = img;
            this.svgCache[drawing.type] = img; // Cache for future use
            drawing._loadingInProgress = false;
            console.log('drawSvgElement: Successfully reloaded SVG for', drawing.type);
            this.redraw();
          }).catch(err => {
            drawing._loadingInProgress = false;
            console.error('drawSvgElement: Failed to reload SVG for', drawing.type, ':', err);
          });
        }
      }
    }
    
    this.ctx.restore();
  }

  drawBarrier(drawing) {
    this.drawSvgElement(drawing);
  }

  drawBigGoal(drawing) {
    this.drawSvgElement(drawing);
  }

  drawLadder(drawing) {
    this.drawSvgElement(drawing);
  }

  drawStick(drawing) {
    this.drawSvgElement(drawing);
  }

  // Draw SVG element on a specific context (for saving)
  drawSvgElementOnContext(ctx, drawing) {
    if (!drawing.svgUrl || !drawing.svgElement) return;
    
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    
    // Skip drawing if dimensions are invalid
    if (width < 0.1 || height < 0.1) return;
    
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    
    ctx.save();
    
    // Apply rotation if present
    if (drawing.rotation) {
      ctx.translate(centerX, centerY);
      ctx.rotate(drawing.rotation);
      ctx.translate(-centerX, -centerY);
    }
    
    // Apply opacity if specified
    if (drawing.opacity !== undefined) {
      ctx.globalAlpha = drawing.opacity;
    }
    
    // Draw the SVG image
    if (drawing.svgElement.complete && drawing.svgElement.naturalWidth > 0) {
      // Apply color if specified (using composite operation to tint the SVG)
      if (drawing.color && drawing.color !== '#000000') {
        // Create offscreen canvas for color application
        const tempCanvas = document.createElement('canvas');
        // Ensure minimum size of 1px to avoid canvas errors
        tempCanvas.width = Math.max(1, Math.round(width));
        tempCanvas.height = Math.max(1, Math.round(height));
        const tempCtx = tempCanvas.getContext('2d');
        
        // Draw SVG to temp canvas first
        tempCtx.drawImage(drawing.svgElement, 0, 0, tempCanvas.width, tempCanvas.height);
        
        // Apply color using source-in to mask color to SVG shape
        tempCtx.globalCompositeOperation = 'source-in';
        tempCtx.fillStyle = drawing.color;
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        tempCtx.globalCompositeOperation = 'source-over';
        
        // Draw colored result to main canvas
        ctx.drawImage(tempCanvas, left, top, width, height);
      } else {
        // Draw without color tint
        ctx.drawImage(drawing.svgElement, left, top, width, height);
      }
    }
    
    ctx.restore();
  }

  // Preload all SVG icons into cache at initialization
  preloadSvgIcons() {
    const svgFiles = {
      'barrier': 'Barrier.svg',
      'biggoal': 'Big goal.svg',
      'ladder': 'Ladder.svg',
      'stick': 'Stick.svg'
    };
    
    console.log('preloadSvgIcons: Starting to preload SVG icons');
    
    Object.entries(svgFiles).forEach(([type, filename]) => {
      const url = chrome.runtime.getURL(`icons/${filename}`);
      const img = new Image();
      img.onload = () => {
        this.svgCache[type] = img;
        console.log('preloadSvgIcons: Cached', type, 'complete:', img.complete, 'naturalWidth:', img.naturalWidth);
      };
      img.onerror = (err) => {
        console.error('preloadSvgIcons: Failed to load', type, 'from', url, ':', err);
      };
      img.src = url;
    });
  }

  // Load SVG element and cache it
  async loadSvgElement(svgUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        console.log('loadSvgElement: Image loaded successfully, URL:', svgUrl, 'complete:', img.complete, 'naturalWidth:', img.naturalWidth, 'naturalHeight:', img.naturalHeight);
        resolve(img);
      };
      img.onerror = (err) => {
        console.error('loadSvgElement: Failed to load image, URL:', svgUrl, 'error:', err);
        reject(err);
      };
      img.src = svgUrl;
      console.log('loadSvgElement: Started loading, URL:', svgUrl);
    });
  }

  // Reload SVG elements for all drawings (used when loading from saved state)
  reloadSvgElements() {
    // Map tool types to SVG file names
    const svgMap = {
      'barrier': 'Barrier.svg',
      'biggoal': 'Big goal.svg',
      'ladder': 'Ladder.svg',
      'stick': 'Stick.svg'
    };
    
    const svgLoadPromises = [];
    
    this.drawings.forEach(drawing => {
      if (['barrier', 'biggoal', 'ladder', 'stick'].includes(drawing.type)) {
        // Ensure svgUrl is set (in case it was lost during serialization)
        if (!drawing.svgUrl && svgMap[drawing.type]) {
          drawing.svgUrl = chrome.runtime.getURL(`icons/${svgMap[drawing.type]}`);
        }
        
        // Try to use cached SVG first
        if (!drawing.svgElement && this.svgCache[drawing.type]) {
          drawing.svgElement = this.svgCache[drawing.type];
          console.log('reloadSvgElements: Using cached SVG for', drawing.type);
        }
        // If not in cache, load SVG if URL is available and element is not loaded
        else if (drawing.svgUrl && !drawing.svgElement) {
          const loadPromise = this.loadSvgElement(drawing.svgUrl).then(img => {
            drawing.svgElement = img;
            // Also cache for future use
            this.svgCache[drawing.type] = img;
            console.log('Reloaded SVG for', drawing.type);
          }).catch(err => {
            console.error(`Failed to reload SVG ${drawing.type}:`, err);
          });
          svgLoadPromises.push(loadPromise);
        }
      }
    });
    
    // Return a promise that resolves when all SVGs are loaded
    return Promise.all(svgLoadPromises);
  }

  drawBallOnContext(ctx, drawing) {
    // Normalize bounds first to ensure perfect roundness
    this.normalizeBallBounds(drawing);

    // Calculate center and size from normalized bounds
    // After normalization, width and height are guaranteed to be equal
    const centerX = (drawing.startX + drawing.endX) / 2;
    const centerY = (drawing.startY + drawing.endY) / 2;
    
    // Use the stored originalWidth (set by normalizeBallBounds) or calculate from bounds
    const size = drawing.originalWidth || Math.abs(drawing.endX - drawing.startX);
    const radius = size / 2;

    ctx.save();

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.fillStyle = drawing.color || '#FFFFFF';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#000000';
    ctx.stroke();

    ctx.clip();

    const patternColor = '#000000';
    // Use radius for pattern scaling
    const spotRadius = radius * 0.25;

    this.drawPentagonOnContext(ctx, centerX, centerY, spotRadius, patternColor);

    for (let i = 0; i < 5; i++) {
      const angle = (i * 72 - 90) * Math.PI / 180;
      const dist = radius * 0.65;
      const spotX = centerX + Math.cos(angle) * dist;
      const spotY = centerY + Math.sin(angle) * dist;

      const innerX = centerX + Math.cos(angle) * spotRadius;
      const innerY = centerY + Math.sin(angle) * spotRadius;

      ctx.beginPath();
      ctx.moveTo(innerX, innerY);
      ctx.lineTo(spotX, spotY);
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = patternColor;
      ctx.stroke();

      this.drawPentagonOnContext(ctx, spotX, spotY, spotRadius * 1.1, patternColor);
    }

    ctx.restore();
  }

  drawPentagonOnContext(ctx, x, y, radius, color) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 72 - 90) * Math.PI / 180;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }

  normalizeBallBounds(drawing) {
    if (!drawing || drawing.type !== 'ball') {
      return;
    }

    // Calculate current dimensions
    const currentWidth = Math.abs(drawing.endX - drawing.startX);
    const currentHeight = Math.abs(drawing.endY - drawing.startY);
    
    // Default size: smaller round ball
    const defaultSize = 25;
    
    // Determine the size - use the larger dimension, or default if both are too small
    let size;
    if (currentWidth < 10 && currentHeight < 10) {
      size = defaultSize;
    } else {
      // ALWAYS use the larger dimension to ensure perfect roundness
      size = Math.max(currentWidth, currentHeight, defaultSize);
    }
    
    // Calculate center point
    const centerX = (drawing.startX + drawing.endX) / 2;
    const centerY = (drawing.startY + drawing.endY) / 2;

    // Apply the corrected dimensions - ALWAYS create a perfect square
    const halfSize = size / 2;
    drawing.startX = centerX - halfSize;
    drawing.endX = centerX + halfSize;
    drawing.startY = centerY - halfSize;
    drawing.endY = centerY + halfSize;
    
    // Store the exact dimensions (guaranteed to be round)
    drawing.originalWidth = size;
    drawing.originalHeight = size;
    drawing.aspectRatio = 1; // Always 1:1 for round ball
  }

  drawTshirtOnContext(ctx, drawing) {
    const left = Math.min(drawing.startX, drawing.endX);
    const top = Math.min(drawing.startY, drawing.endY);
    const width = Math.abs(drawing.endX - drawing.startX);
    const height = Math.abs(drawing.endY - drawing.startY);
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    
    // T-shirt uses the full bounding box (already maintains 3:4 ratio)
    const shirtWidth = width;
    const shirtHeight = height;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;

    ctx.save();

    ctx.fillStyle = drawing.color || '#FFFFFF';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;

    ctx.beginPath();
    const collarWidth = shirtWidth * 0.4;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;

    ctx.moveTo(startX, startY + shirtHeight * 0.1);
    ctx.quadraticCurveTo(startX + shoulderWidth, startY, startX + shoulderWidth, startY + shirtHeight * 0.05);
    ctx.quadraticCurveTo(centerX, startY + shirtHeight * 0.2, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.05);
    ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth, startY, startX + shirtWidth, startY + shirtHeight * 0.1);
    ctx.lineTo(startX + shirtWidth + shirtWidth * 0.15, startY + shirtHeight * 0.3);
    ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.4);
    ctx.lineTo(startX + shirtWidth, startY + shirtHeight);
    ctx.quadraticCurveTo(centerX, startY + shirtHeight + shirtHeight * 0.05, startX, startY + shirtHeight);
    ctx.lineTo(startX, startY + shirtHeight * 0.4);
    ctx.lineTo(startX - shirtWidth * 0.15, startY + shirtHeight * 0.3);
    ctx.closePath();

    ctx.fill();
    ctx.stroke();

    // Number and Surname
    if (drawing.number !== undefined || drawing.surname) {
      const hex = (drawing.color || '#FFFFFF').replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
      const textColor = brightness > 128 ? '#000000' : '#FFFFFF';

      ctx.textAlign = 'center';
      
      // Draw number on the shirt
      if (drawing.number !== undefined) {
        ctx.fillStyle = textColor;
        ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
        ctx.textBaseline = 'middle';
        ctx.fillText(drawing.number, centerX, centerY + shirtHeight * 0.1);
      }
      
      // Draw surname and position below the shirt (outside, as a label)
      if (drawing.surname) {
        ctx.font = `bold ${Math.max(shirtHeight * 0.15, 10)}px Arial`;
        ctx.textBaseline = 'top';
        const surnameY = startY + shirtHeight + 4;
        const lineHeight = Math.max(shirtHeight * 0.15, 10) * 1.2;
        
        // Draw surname on first line
        const surnameText = drawing.surname;
        
        // Draw stroke with t-shirt color
        ctx.strokeStyle = drawing.color || '#FFFFFF';
        ctx.lineWidth = 3;
        ctx.lineJoin = 'round';
        ctx.strokeText(surnameText, centerX, surnameY);
        
        // Draw white fill on top
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(surnameText, centerX, surnameY);
        
        // Draw position on second line (if exists)
        if (drawing.position && drawing.position.trim()) {
          const positionY = surnameY + lineHeight;
          ctx.strokeText(drawing.position, centerX, positionY);
          ctx.fillText(drawing.position, centerX, positionY);
        }
      }
    }

    ctx.restore();
  }


  drawCrosshatchFill(centerX, centerY, radius, color, alpha) {
    // Create a clipping path for the circle
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    this.ctx.clip();
    
    // Draw crosshatch pattern - lines are semi-transparent, gaps are fully transparent (showing image)
    // Use the alpha parameter so lines are semi-transparent and show the image behind
    this.ctx.globalAlpha = alpha; // Lines use the fill opacity to be semi-transparent
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const bounds = {
      left: centerX - radius,
      right: centerX + radius,
      top: centerY - radius,
      bottom: centerY + radius
    };
    
    const width = bounds.right - bounds.left;
    const height = bounds.bottom - bounds.top;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(bounds.left + offset, bounds.top);
      this.ctx.lineTo(bounds.left + offset + height, bounds.bottom);
      this.ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(bounds.right - offset, bounds.top);
      this.ctx.lineTo(bounds.right - offset - height, bounds.bottom);
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  drawCrosshatchFillOval(centerX, centerY, radiusX, radiusY, color, alpha) {
    // Create a clipping path for the oval
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
    this.ctx.clip();
    
    // Draw crosshatch pattern - lines are semi-transparent, gaps are fully transparent (showing image)
    // Use the alpha parameter so lines are semi-transparent and show the image behind
    this.ctx.globalAlpha = alpha; // Lines use the fill opacity to be semi-transparent
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10; // Wider lines for better visibility
    
    // Calculate bounding box for the oval
    const left = centerX - radiusX;
    const top = centerY - radiusY;
    const width = radiusX * 2;
    const height = radiusY * 2;
    
    // Draw diagonal lines from top-left to bottom-right
    const spacing = 60; // Larger spacing between lines - fewer lines
    const diagonalLength = Math.sqrt(width * width + height * height);
    const numLines = Math.ceil(diagonalLength / spacing);
    
    for (let i = -numLines; i <= numLines; i++) {
      const offset = i * spacing;
      this.ctx.beginPath();
      // Line from top edge to right edge
      const startX = left;
      const startY = top + offset;
      const endX = left + width;
      const endY = top + height + offset;
      this.ctx.moveTo(startX, startY);
      this.ctx.lineTo(endX, endY);
      this.ctx.stroke();
    }
    
    // Draw diagonal lines from top-right to bottom-left
    for (let i = -numLines; i <= numLines; i++) {
      const offset = i * spacing;
      this.ctx.beginPath();
      // Line from right edge to left edge
      const startX = left + width;
      const startY = top + offset;
      const endX = left;
      const endY = top + height + offset;
      this.ctx.moveTo(startX, startY);
      this.ctx.lineTo(endX, endY);
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  drawCrosshatchFillArc(centerX, centerY, radius, color, alpha) {
    // Create a clipping path for the semicircle
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, radius, 0, Math.PI);
    this.ctx.lineTo(centerX - radius, centerY);
    this.ctx.closePath();
    this.ctx.clip();
    
    // Draw crosshatch pattern - lines are semi-transparent, gaps are fully transparent (showing image)
    this.ctx.globalAlpha = alpha; // Lines use the fill opacity to be semi-transparent
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const bounds = {
      left: centerX - radius,
      right: centerX + radius,
      top: centerY - radius,
      bottom: centerY
    };
    
    const width = bounds.right - bounds.left;
    const height = bounds.bottom - bounds.top;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(bounds.left + offset, bounds.top);
      this.ctx.lineTo(bounds.left + offset + height, bounds.bottom);
      this.ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(bounds.right - offset, bounds.top);
      this.ctx.lineTo(bounds.right - offset - height, bounds.bottom);
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  drawCrosshatchFillPolygon(points, color, alpha) {
    // Create a clipping path for the polygon
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      this.ctx.lineTo(points[i].x, points[i].y);
    }
    this.ctx.closePath();
    this.ctx.clip();
    
    // Get bounding box
    const minX = Math.min(...points.map(p => p.x));
    const maxX = Math.max(...points.map(p => p.x));
    const minY = Math.min(...points.map(p => p.y));
    const maxY = Math.max(...points.map(p => p.y));
    
    // Draw crosshatch pattern - lines are semi-transparent, gaps are fully transparent (showing image)
    this.ctx.globalAlpha = alpha; // Lines use the fill opacity to be semi-transparent
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const width = maxX - minX;
    const height = maxY - minY;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(minX + offset, minY);
      this.ctx.lineTo(minX + offset + height, maxY);
      this.ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(maxX - offset, minY);
      this.ctx.lineTo(maxX - offset - height, maxY);
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  drawCrosshatchFillRect(left, top, width, height, color, alpha) {
    // Create a clipping path for the rectangle
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.rect(left, top, width, height);
    this.ctx.clip();
    
    // Draw crosshatch pattern - lines are semi-transparent, gaps are fully transparent (showing image)
    this.ctx.globalAlpha = alpha; // Lines use the fill opacity to be semi-transparent
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(left + offset, top);
      this.ctx.lineTo(left + offset + height, top + height);
      this.ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(left + width - offset, top);
      this.ctx.lineTo(left + width - offset - height, top + height);
      this.ctx.stroke();
    }
    
    this.ctx.restore();
  }

  // Context-based versions for save function
  drawCrosshatchFillOnContext(ctx, centerX, centerY, radius, color, alpha) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.clip();
    
    // Lines use the fill opacity to be semi-transparent
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const bounds = {
      left: centerX - radius,
      right: centerX + radius,
      top: centerY - radius,
      bottom: centerY + radius
    };
    
    const width = bounds.right - bounds.left;
    const height = bounds.bottom - bounds.top;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(bounds.left + offset, bounds.top);
      ctx.lineTo(bounds.left + offset + height, bounds.bottom);
      ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(bounds.right - offset, bounds.top);
      ctx.lineTo(bounds.right - offset - height, bounds.bottom);
      ctx.stroke();
    }
    
    ctx.restore();
  }

  drawCrosshatchFillArcOnContext(ctx, centerX, centerY, radius, color, alpha) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI);
    ctx.lineTo(centerX - radius, centerY);
    ctx.closePath();
    ctx.clip();
    
    // Lines use the fill opacity to be semi-transparent
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const bounds = {
      left: centerX - radius,
      right: centerX + radius,
      top: centerY - radius,
      bottom: centerY
    };
    
    const width = bounds.right - bounds.left;
    const height = bounds.bottom - bounds.top;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(bounds.left + offset, bounds.top);
      ctx.lineTo(bounds.left + offset + height, bounds.bottom);
      ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(bounds.right - offset, bounds.top);
      ctx.lineTo(bounds.right - offset - height, bounds.bottom);
      ctx.stroke();
    }
    
    ctx.restore();
  }

  drawCrosshatchFillPolygonOnContext(ctx, points, color, alpha) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.closePath();
    ctx.clip();
    
    const minX = Math.min(...points.map(p => p.x));
    const maxX = Math.max(...points.map(p => p.x));
    const minY = Math.min(...points.map(p => p.y));
    const maxY = Math.max(...points.map(p => p.y));
    
    // Lines use the fill opacity to be semi-transparent
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = 10; // Wider lines for better visibility
    
    const spacing = 60; // Larger spacing between lines - fewer lines
    const width = maxX - minX;
    const height = maxY - minY;
    
    // Draw diagonal lines (top-left to bottom-right)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(minX + offset, minY);
      ctx.lineTo(minX + offset + height, maxY);
      ctx.stroke();
    }
    
    // Draw diagonal lines (top-right to bottom-left)
    for (let offset = -width; offset < width + height; offset += spacing) {
      ctx.beginPath();
      ctx.moveTo(maxX - offset, minY);
      ctx.lineTo(maxX - offset - height, maxY);
      ctx.stroke();
    }
    
    ctx.restore();
  }

  // Undo/Redo
  saveState() {
    const state = JSON.parse(JSON.stringify(this.drawings));
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(state);
    this.historyIndex = this.history.length - 1;
    
    // Limit history size
    if (this.history.length > 50) {
      this.history.shift();
      this.historyIndex--;
    }
    
    // Initialize slides if they don't exist
    if (!this.slides || this.slides.length === 0) {
      this.initializeSlides();
    }
    
    // Ensure current slide exists
    if (!this.slides[this.currentSlideIndex]) {
      this.slides[this.currentSlideIndex] = {
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: [],
        backgroundImage: null
      };
    }
    
    // Sync with current slide (preserve backgroundImage if it exists)
    this.slides[this.currentSlideIndex].drawings = JSON.parse(JSON.stringify(this.drawings));
    
    // CRITICAL: Preserve backgroundImage - don't overwrite it, and NEVER use this.image.src
    // Each slide's backgroundImage should remain independent
    if (this.slides[this.currentSlideIndex].backgroundImage === undefined) {
      this.slides[this.currentSlideIndex].backgroundImage = null;
    }
    
    // Safety check: ensure we're not accidentally copying this.image.src to other slides
    if (this.image && this.image.src) {
      const currentSlideBg = this.slides[this.currentSlideIndex].backgroundImage;
      // Only the current slide should potentially match this.image.src (if it's the current slide's background)
      // Other slides should NEVER have this.image.src as their backgroundImage
      for (let i = 0; i < this.slides.length; i++) {
        if (i !== this.currentSlideIndex && this.slides[i].backgroundImage === this.image.src) {
          console.error(`saveState ERROR: Slide ${i} has this.image.src as background! This should not happen!`);
          // Don't fix it here - this indicates a bug elsewhere, but log it
        }
      }
    }
    
    this.updateSlideThumbnail(this.currentSlideIndex);
  }

  undo() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.drawings = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      this.selectedDrawings = [];
      this.reloadSvgElements().then(() => {
        this.redraw();
      }).catch(() => {
        this.redraw();
      });
    }
  }

  redo() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.drawings = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      this.selectedDrawings = [];
      this.reloadSvgElements().then(() => {
        this.redraw();
      }).catch(() => {
        this.redraw();
      });
    }
  }

  // Zoom
  zoomIn() {
    this.zoom = Math.min(this.zoom * 1.2, 2.0); // Max zoom in: 200%
    this.updateZoom();
  }

  zoomOut() {
    this.zoom = Math.max(this.zoom / 1.2, 0.5); // Max zoom out: 50%
    this.updateZoom();
  }

  resetZoom() {
    this.zoom = 1;
    this.updateZoom();
  }

  // Canvas rotation - rotates +90 degrees each call
  rotateCanvas() {
    // Store original dimensions on first rotation
    if (this.originalCanvasWidth === null && this.image) {
      this.originalCanvasWidth = this.image.width;
      this.originalCanvasHeight = this.image.height;
    }
    
    // Increment rotation by 90 degrees, cycling through 0 → 90 → 180 → 270 → 0
    this.canvasRotation = (this.canvasRotation + 90) % 360;
    
    // Update canvas dimensions based on rotation
    if (this.image && this.originalCanvasWidth !== null) {
      if (this.canvasRotation === 90 || this.canvasRotation === 270) {
        // Swap width and height for 90° or 270° rotation
        this.canvas.width = this.originalCanvasHeight;
        this.canvas.height = this.originalCanvasWidth;
      } else {
        // Restore original dimensions for 0° or 180°
        this.canvas.width = this.originalCanvasWidth;
        this.canvas.height = this.originalCanvasHeight;
      }
    }
    
    // Update canvas display size
    this.updateCanvasSize();
    
    // Redraw with rotation applied
    this.redraw();
    
    // Update slide thumbnails to reflect rotation
    this.updateSlidesPanel();
    
    console.log('Canvas rotated to', this.canvasRotation, 'degrees');
  }
  
  applyCanvasRotation() {
    if (!this.canvasRotation || this.canvasRotation === 0) {
      return;
    }
    
    const radians = (this.canvasRotation * Math.PI) / 180;
    const origWidth = this.originalCanvasWidth || this.image?.width || this.canvas.width;
    const origHeight = this.originalCanvasHeight || this.image?.height || this.canvas.height;
    
    switch (this.canvasRotation) {
      case 90:
        // For 90° rotation: translate to right edge, then rotate
        this.ctx.translate(origHeight, 0);
        this.ctx.rotate(radians);
        break;
      case 180:
        // For 180° rotation: translate to bottom-right, then rotate
        this.ctx.translate(origWidth, origHeight);
        this.ctx.rotate(radians);
        break;
      case 270:
        // For 270° rotation: translate to bottom edge, then rotate
        this.ctx.translate(0, origWidth);
        this.ctx.rotate(radians);
        break;
    }
  }

  updateZoom() {
    if (this.canvas && this.image) {
      // Get the actual display size of the canvas (set by updateCanvasSize)
      const displayWidth = parseFloat(this.canvas.style.width) || this.canvas.width;
      const displayHeight = parseFloat(this.canvas.style.height) || this.canvas.height;
      
      // Calculate the scaled dimensions
      const scaledWidth = displayWidth * this.zoom;
      const scaledHeight = displayHeight * this.zoom;
      
      // Calculate how much the canvas extends beyond its original size in each direction
      // When scaling from center, the canvas grows equally in all directions
      const extraWidth = (scaledWidth - displayWidth) / 2;
      const extraHeight = (scaledHeight - displayHeight) / 2;
      
      // Apply zoom transform - use center origin to keep it centered when zoomed out
      this.canvas.style.transform = `scale(${this.zoom})`;
      this.canvas.style.transformOrigin = 'center center';
      
      // For zoomed in views, we need to handle scrolling
      const container = document.querySelector('.editor-canvas-container');
      if (container) {
        if (this.zoom > 1) {
          // When zoomed in, the canvas scales from center
          // The canvas element is displayWidth x displayHeight
          // When scaled by zoom, it visually becomes scaledWidth x scaledHeight
          // The scaled canvas extends extraWidth/extraHeight beyond the element in each direction
          
          // To allow scrolling to all edges, we need:
          // 1. Padding equal to the extra space on each side (to see left/top edges)
          // 2. The container's content area must be large enough for the full scaled canvas
          
          // Calculate the total space needed
          const totalWidth = scaledWidth;
          const totalHeight = scaledHeight;
          
          // When zoomed, we need to allow scrolling to all edges
          // The canvas scales from center, so we need to ensure the container
          // can scroll to see the full scaled canvas
          
          // Use padding to create scrollable space on all sides
          // The padding equals the extra space on each side
          container.style.padding = `${extraHeight}px ${extraWidth}px ${extraHeight}px ${extraWidth}px`;
          
          // Change flexbox to position canvas at top-left of padded area
          // This allows scrolling to see left and top edges
          container.style.alignItems = 'flex-start';
          container.style.justifyContent = 'flex-start';
          
          // Ensure container can scroll
          container.style.overflow = 'auto';
          
          // The canvas element is at (extraWidth, extraHeight) due to padding
          // The canvas scales from center, so the scaled canvas extends:
          // - Left: from centerX - scaledWidth/2
          // - Right: to centerX + scaledWidth/2
          // Where centerX = extraWidth + displayWidth/2
          // So right edge is at: extraWidth + displayWidth/2 + scaledWidth/2 = scaledWidth
          // To ensure we can scroll to the right edge, the container's scrollable width
          // needs to be at least scaledWidth. Since we have padding, the canvas element
          // needs to extend to create that scrollable area.
          // We can do this by setting a min-width on the container or using a wrapper.
          // Actually, the canvas element itself creates the scrollable area, so we need
          // to ensure it extends far enough. But the canvas is only displayWidth wide.
          // The solution: use a wrapper div or adjust the canvas positioning.
          
          // Simpler solution: ensure the container's content area is large enough
          // by setting the canvas element's margin or using a pseudo-element
          // Actually, we can use the canvas's after pseudo-element or a wrapper
          
          // Best solution: create a wrapper div that has the correct size
          // But that requires HTML changes. Let's try a CSS-only solution:
          // Set the canvas to have enough space by using margin or positioning
          
          // Actually, I think the issue is that the container's scrollWidth is based on
          // the canvas element's size (displayWidth) plus padding, but we need it to be
          // based on the scaled size. We can achieve this by ensuring the container
          // has a min-width/min-height that accounts for the full scaled canvas.
          
          // The container's scrollable area should be at least:
          // Width: paddingLeft + scaledWidth = extraWidth + scaledWidth
          // Height: paddingTop + scaledHeight = extraHeight + scaledHeight
          
          // We can ensure this by setting min-width/min-height on the container
          // But that might not work with flexbox. Let's try a different approach:
          // Use the canvas element's size to create the scrollable area.
          
          // Actually, the simplest fix: ensure the canvas element creates enough
          // scrollable space by adjusting its display size or using a wrapper.
          // But we can't change the canvas display size (that would affect the image).
          
          // Let me try: use transform-origin top-left when zoomed, and position accordingly
          // Or: use a wrapper div approach (requires HTML change)
          
          // For now, let's try ensuring the container can scroll by setting
          // the canvas element to create the right scrollable area using margin
          // The canvas needs to extend to the right and bottom to create scrollable space
          
          // Calculate how far the scaled canvas extends to the right and bottom
          // Right edge: extraWidth + displayWidth/2 + scaledWidth/2 = scaledWidth
          // Bottom edge: extraHeight + displayHeight/2 + scaledHeight/2 = scaledHeight
          
          // So we need the container to be scrollable to at least (scaledWidth, scaledHeight)
          // Since the canvas is at (extraWidth, extraHeight), we need it to extend
          // to (scaledWidth, scaledHeight). The canvas element itself is only
          // (displayWidth, displayHeight), so we need additional space.
          
          // The canvas element is at (extraWidth, extraHeight) due to padding
          // The canvas center is at (extraWidth + displayWidth/2, extraHeight + displayHeight/2)
          // The scaled canvas right edge is at: centerX + scaledWidth/2 = scaledWidth
          // The scaled canvas bottom edge is at: centerY + scaledHeight/2 = scaledHeight
          // For the container to scroll to these edges, the content needs to extend to at least:
          // Width: scaledWidth, Height: scaledHeight
          // The canvas element extends from extraWidth to extraWidth + displayWidth
          // So we need: extraWidth + displayWidth + marginRight >= scaledWidth
          // marginRight >= scaledWidth - extraWidth - displayWidth
          // = scaledWidth - extraWidth - displayWidth
          // = displayWidth * zoom - extraWidth - displayWidth
          // = displayWidth * (zoom - 1) - extraWidth
          // = displayWidth * (zoom - 1) - (scaledWidth - displayWidth)/2
          // = displayWidth * (zoom - 1) - (displayWidth * zoom - displayWidth)/2
          // = displayWidth * (zoom - 1) - displayWidth * (zoom - 1)/2
          // = displayWidth * (zoom - 1) * 0.5 = extraWidth
          // So marginRight should be extraWidth, and similarly marginBottom = extraHeight
          this.canvas.style.marginRight = `${extraWidth}px`;
          this.canvas.style.marginBottom = `${extraHeight}px`;
          
          // Create a wrapper or ensure the container's scrollable area is large enough
          // The canvas element needs to be positioned such that the full scaled canvas fits
          // We'll use a wrapper div approach or adjust the canvas positioning
          
          // Actually, we need to ensure the container's scrollWidth/scrollHeight accounts for everything
          // The canvas is at (paddingLeft, paddingTop) = (extraWidth, extraHeight)
          // The canvas center is at (extraWidth + displayWidth/2, extraHeight + displayHeight/2)
          // The scaled canvas extends from (centerX - scaledWidth/2, centerY - scaledHeight/2)
          //   to (centerX + scaledWidth/2, centerY + scaledHeight/2)
          // So the right edge is at: extraWidth + displayWidth/2 + scaledWidth/2
          //   = extraWidth + displayWidth/2 + (displayWidth + 2*extraWidth)/2
          //   = extraWidth + displayWidth/2 + displayWidth/2 + extraWidth
          //   = displayWidth + 2*extraWidth = scaledWidth + extraWidth
          // Similarly for bottom: scaledHeight + extraHeight
          
          // So the container needs scrollable area of at least:
          // Width: scaledWidth + extraWidth (but we have padding of extraWidth, so total is scaledWidth + 2*extraWidth)
          // Height: scaledHeight + extraHeight (but we have padding of extraHeight, so total is scaledHeight + 2*extraHeight)
          
          // The padding already provides extraWidth/extraHeight on each side
          // So the total scrollable area is: canvas position + scaled size
          // = (extraWidth, extraHeight) + scaledWidth x scaledHeight
          // But we need to ensure the container can scroll to see the full scaled canvas
          // The right edge is at: extraWidth + scaledWidth/2 + scaledWidth/2 = extraWidth + scaledWidth
          // The bottom edge is at: extraHeight + scaledHeight/2 + scaledHeight/2 = extraHeight + scaledHeight
          
          // So we need the container's content to extend to at least:
          // Width: extraWidth (padding) + scaledWidth = scaledWidth + extraWidth
          // Height: extraHeight (padding) + scaledHeight = scaledHeight + extraHeight
          
          // But wait, the canvas scales from center, so:
          // Left edge of scaled canvas: centerX - scaledWidth/2 = (extraWidth + displayWidth/2) - scaledWidth/2
          //   = extraWidth + displayWidth/2 - (displayWidth + 2*extraWidth)/2
          //   = extraWidth + displayWidth/2 - displayWidth/2 - extraWidth = 0
          // So left edge is at 0, which is good - we can scroll to it with padding
          
          // Right edge: centerX + scaledWidth/2 = extraWidth + displayWidth/2 + scaledWidth/2
          //   = extraWidth + displayWidth/2 + (displayWidth + 2*extraWidth)/2
          //   = extraWidth + displayWidth/2 + displayWidth/2 + extraWidth
          //   = displayWidth + 2*extraWidth = scaledWidth
          // So right edge is at scaledWidth from container's scrollLeft = 0
          
          // We need the container to be scrollable to at least scaledWidth width
          // Since we have padding of extraWidth on the right, the total scrollable width should be:
          // paddingLeft + scaledWidth = extraWidth + scaledWidth
          
          // Actually, I think the issue is simpler - we just need to ensure the container
          // has enough space. Let me use a different approach: wrap the canvas in a div
          // that has the correct size, or adjust the canvas positioning.
        } else {
          // At normal or zoomed out, restore centering and remove padding
          container.style.padding = '0';
          container.style.alignItems = 'center';
          container.style.justifyContent = 'center';
          container.style.overflow = 'auto';
          // Remove any margins we added for zooming
          if (this.canvas) {
            this.canvas.style.marginRight = '0';
            this.canvas.style.marginBottom = '0';
          }
        }
      }
    }
    const zoomLevelEl = document.getElementById('editorZoomLevel');
    if (zoomLevelEl) {
      zoomLevelEl.textContent = Math.round(this.zoom * 100) + '%';
    }
    this.redraw();
  }

  // Helper function to update animation path targetIndex references after array reordering
  updateAnimPathReferences() {
    // After any layer manipulation, we need to find the correct target for each animation path
    // by matching the path's start position with the object's center position
    this.drawings.forEach((pathDrawing, pathIndex) => {
      if (pathDrawing.type === 'animpath' && pathDrawing.targetIndex !== undefined) {
        const oldTargetIndex = pathDrawing.targetIndex;
        
        // Check if the reference is still valid
        if (oldTargetIndex >= 0 && oldTargetIndex < this.drawings.length) {
          const targetAtOldIndex = this.drawings[oldTargetIndex];
          if (targetAtOldIndex && ['ball', 'tshirt'].includes(targetAtOldIndex.type)) {
            // Reference is still valid, keep it
            return;
          }
        }
        
        // Reference is invalid - find the correct target by position
        let bestMatch = null;
        let bestDistance = Infinity;
        
        for (let i = 0; i < this.drawings.length; i++) {
          const candidate = this.drawings[i];
          if (candidate && ['ball', 'tshirt'].includes(candidate.type)) {
            const candidateCenterX = (candidate.startX + candidate.endX) / 2;
            const candidateCenterY = (candidate.startY + candidate.endY) / 2;
            const pathStartX = pathDrawing.startX;
            const pathStartY = pathDrawing.startY;
            
            const distance = Math.sqrt(
              Math.pow(candidateCenterX - pathStartX, 2) + 
              Math.pow(candidateCenterY - pathStartY, 2)
            );
            
            // Find the closest match within tolerance
            const tolerance = 100;
            if (distance < tolerance && distance < bestDistance) {
              bestMatch = i;
              bestDistance = distance;
            }
          }
        }
        
        if (bestMatch !== null) {
          pathDrawing.targetIndex = bestMatch;
        }
      }
    });
  }

  // Layer control methods
  bringToFront() {
    if (this.selectedDrawings.length === 0) return;
    
    // Sort selected indices in descending order to avoid index shifting issues
    const sortedIndices = [...this.selectedDrawings].sort((a, b) => b - a);
    const selectedDrawingsCopy = sortedIndices.map(i => this.drawings[i]);
    
    // Remove selected drawings from their current positions
    sortedIndices.forEach(index => {
      this.drawings.splice(index, 1);
    });
    
    // Add them to the end (top layer)
    this.drawings.push(...selectedDrawingsCopy.reverse());
    
    // Update selected indices to new positions
    const newStartIndex = this.drawings.length - this.selectedDrawings.length;
    this.selectedDrawings = [];
    for (let i = 0; i < selectedDrawingsCopy.length; i++) {
      this.selectedDrawings.push(newStartIndex + i);
    }
    
    // Update animation path references after reordering
    this.updateAnimPathReferences();
    
    this.saveState();
    this.redraw();
  }
  
  sendToBack() {
    if (this.selectedDrawings.length === 0) return;
    
    // Sort selected indices in descending order
    const sortedIndices = [...this.selectedDrawings].sort((a, b) => b - a);
    const selectedDrawingsCopy = sortedIndices.map(i => this.drawings[i]);
    
    // Remove selected drawings from their current positions
    sortedIndices.forEach(index => {
      this.drawings.splice(index, 1);
    });
    
    // Add them to the beginning (bottom layer)
    this.drawings.unshift(...selectedDrawingsCopy.reverse());
    
    // Update selected indices to new positions (at the beginning)
    this.selectedDrawings = [];
    for (let i = 0; i < selectedDrawingsCopy.length; i++) {
      this.selectedDrawings.push(i);
    }
    
    // Update animation path references after reordering
    this.updateAnimPathReferences();
    
    this.saveState();
    this.redraw();
  }
  
  bringForward() {
    if (this.selectedDrawings.length === 0) return;
    
    // Sort selected indices in descending order to process from top to bottom
    const sortedIndices = [...this.selectedDrawings].sort((a, b) => b - a);
    
    // Check if any selected item is already at the top
    const maxIndex = this.drawings.length - 1;
    if (sortedIndices[0] >= maxIndex) return;
    
    // Move each selected item one position up
    sortedIndices.forEach(index => {
      if (index < this.drawings.length - 1) {
        // Swap with the item above
        const temp = this.drawings[index];
        this.drawings[index] = this.drawings[index + 1];
        this.drawings[index + 1] = temp;
      }
    });
    
    // Update selected indices
    this.selectedDrawings = this.selectedDrawings.map(i => Math.min(i + 1, maxIndex));
    
    // Update animation path references after reordering
    this.updateAnimPathReferences();
    
    this.saveState();
    this.redraw();
  }
  
  sendBackward() {
    if (this.selectedDrawings.length === 0) return;
    
    // Sort selected indices in ascending order to process from bottom to top
    const sortedIndices = [...this.selectedDrawings].sort((a, b) => a - b);
    
    // Check if any selected item is already at the bottom
    if (sortedIndices[0] <= 0) return;
    
    // Move each selected item one position down
    sortedIndices.forEach(index => {
      if (index > 0) {
        // Swap with the item below
        const temp = this.drawings[index];
        this.drawings[index] = this.drawings[index - 1];
        this.drawings[index - 1] = temp;
      }
    });
    
    // Update selected indices
    this.selectedDrawings = this.selectedDrawings.map(i => Math.max(i - 1, 0));
    
    // Update animation path references after reordering
    this.updateAnimPathReferences();
    
    this.saveState();
    this.redraw();
  }
  
  // Tool groups setup
  setupToolGroups() {
    const groupBtns = document.querySelectorAll('.editor-tool-group-btn');
    console.log('Setting up tool groups, found:', groupBtns.length, 'group buttons');
    
    groupBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const group = btn.closest('.editor-tool-group');
        if (!group) return;
        
        const wasExpanded = group.classList.contains('expanded');
        
        // Close all groups first
        document.querySelectorAll('.editor-tool-group.expanded').forEach(g => {
          g.classList.remove('expanded');
        });
        
        // Toggle this group
        if (!wasExpanded) {
          group.classList.add('expanded');
        }
      });
    });
    
    // Close groups when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.editor-tool-group')) {
        document.querySelectorAll('.editor-tool-group.expanded').forEach(g => {
          g.classList.remove('expanded');
        });
      }
    });
  }
  
  // Layers panel methods
  toggleLayersPanel(show = null) {
    const panel = document.getElementById('editorLayersPanel');
    const btn = document.getElementById('editorLayersPanelBtn');
    if (!panel) return;
    
    const isVisible = panel.classList.contains('visible');
    const shouldShow = show !== null ? show : !isVisible;
    
    if (shouldShow) {
      panel.classList.add('visible');
      btn?.classList.add('active');
      this.updateLayersList();
    } else {
      panel.classList.remove('visible');
      btn?.classList.remove('active');
    }
  }
  
  updateLayersList() {
    const listEl = document.getElementById('editorLayersList');
    if (!listEl) return;
    
    if (this.drawings.length === 0) {
      listEl.innerHTML = '<div class="editor-layers-empty">No elements yet</div>';
      return;
    }
    
    // Clear and rebuild the list (top layer first, so reverse order)
    listEl.innerHTML = '';
    
    for (let i = this.drawings.length - 1; i >= 0; i--) {
      const drawing = this.drawings[i];
      const isSelected = this.selectedDrawings.includes(i);
      
      const item = document.createElement('div');
      item.className = `editor-layer-item${isSelected ? ' selected' : ''}`;
      item.dataset.index = i;
      item.draggable = true;
      
      // Get layer name and icon
      const { name, icon } = this.getLayerInfo(drawing);
      
      item.innerHTML = `
        <div class="editor-layer-preview">${icon}</div>
        <div class="editor-layer-info">
          <div class="editor-layer-name">${name}</div>
          <div class="editor-layer-type">${drawing.type}</div>
        </div>
        <div class="editor-layer-actions">
          <button class="editor-layer-action-btn delete-layer" title="Delete">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      `;
      
      // Click to select
      item.addEventListener('click', (e) => {
        if (e.target.closest('.delete-layer')) return;
        this.selectLayerItem(parseInt(item.dataset.index));
      });
      
      // Delete button
      item.querySelector('.delete-layer')?.addEventListener('click', (e) => {
        e.stopPropagation();
        this.deleteLayerItem(parseInt(item.dataset.index));
      });
      
      // Drag events
      item.addEventListener('dragstart', (e) => this.handleLayerDragStart(e, i));
      item.addEventListener('dragend', (e) => this.handleLayerDragEnd(e));
      item.addEventListener('dragover', (e) => this.handleLayerDragOver(e));
      item.addEventListener('dragleave', (e) => this.handleLayerDragLeave(e));
      item.addEventListener('drop', (e) => this.handleLayerDrop(e, i));
      
      listEl.appendChild(item);
    }
  }
  
  getLayerInfo(drawing) {
    let name = '';
    let icon = '';
    
    switch (drawing.type) {
      case 'tshirt':
        name = drawing.surname ? `${drawing.number || ''} ${drawing.surname}` : `Player ${drawing.number || ''}`;
        icon = `<svg viewBox="0 0 24 24" fill="${drawing.color || '#fff'}" stroke="#000" stroke-width="1">
          <path d="M20.38 3.46L16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 1 .84H6v10h12V10h2.14a1 1 0 0 0 1-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/>
        </svg>`;
        break;
      case 'ball':
        name = drawing.number ? `Ball #${drawing.number}` : 'Ball';
        icon = `<svg viewBox="0 0 24 24" fill="${drawing.color || '#fff'}" stroke="#000" stroke-width="1">
          <circle cx="12" cy="12" r="10"/>
        </svg>`;
        break;
      case 'line':
        name = 'Line';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <line x1="5" y1="19" x2="19" y2="5"/>
        </svg>`;
        break;
      case 'arrow':
        name = 'Arrow';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <line x1="5" y1="19" x2="19" y2="5"/>
          <polyline points="9 5 19 5 19 15"/>
        </svg>`;
        break;
      case 'curve':
        name = 'Curve';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <path d="M3 17c3-6 9-6 18 0"/>
        </svg>`;
        break;
      case 'circle':
        name = 'Circle';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <circle cx="12" cy="12" r="8"/>
        </svg>`;
        break;
      case 'oval':
        name = 'Oval';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <ellipse cx="12" cy="12" rx="10" ry="6"/>
        </svg>`;
        break;
      case 'rectangle':
        name = 'Rectangle';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <rect x="4" y="6" width="16" height="12" rx="1"/>
        </svg>`;
        break;
      case 'triangle':
        name = 'Triangle';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <polygon points="12 4 4 20 20 20"/>
        </svg>`;
        break;
      case 'text':
        name = drawing.text ? `"${drawing.text.substring(0, 15)}${drawing.text.length > 15 ? '...' : ''}"` : 'Text';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <polyline points="4 7 4 4 20 4 20 7"/>
          <line x1="12" y1="4" x2="12" y2="20"/>
          <line x1="8" y1="20" x2="16" y2="20"/>
        </svg>`;
        break;
      case 'animpath':
        name = 'Movement Path';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="#1f6feb" stroke-width="2" stroke-dasharray="4 2">
          <line x1="5" y1="19" x2="19" y2="5"/>
          <polyline points="12 5 19 5 19 12"/>
        </svg>`;
        break;
      case 'freehand':
        name = 'Freehand';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <path d="M3 17c3-3 6-6 9-3s6 3 9-3"/>
        </svg>`;
        break;
      case 'spray':
        name = 'Spray';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="1">
          <circle cx="12" cy="12" r="10" fill="none"/>
          <circle cx="8" cy="8" r="1.5" fill="${drawing.color || '#fff'}"/>
          <circle cx="12" cy="6" r="1" fill="${drawing.color || '#fff'}"/>
          <circle cx="16" cy="8" r="1.5" fill="${drawing.color || '#fff'}"/>
          <circle cx="10" cy="12" r="1" fill="${drawing.color || '#fff'}"/>
          <circle cx="14" cy="12" r="1.5" fill="${drawing.color || '#fff'}"/>
          <circle cx="9" cy="16" r="1" fill="${drawing.color || '#fff'}"/>
          <circle cx="15" cy="16" r="1.5" fill="${drawing.color || '#fff'}"/>
        </svg>`;
        break;
      case 'heatmap':
        name = 'Heat Map';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#ff0000'}" stroke-width="1">
          <circle cx="12" cy="12" r="10" fill="none"/>
          <circle cx="12" cy="12" r="8" fill="${drawing.color || '#ff0000'}" opacity="0.6"/>
        </svg>`;
        break;
      case 'polygon':
        name = 'Polygon';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <polygon points="12 2 22 9 18 21 6 21 2 9"/>
        </svg>`;
        break;
      case 'cross':
        name = 'Cross';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <line x1="6" y1="6" x2="18" y2="18"/>
          <line x1="18" y1="6" x2="6" y2="18"/>
        </svg>`;
        break;
      case 'arc':
        name = 'Arc';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="${drawing.color || '#fff'}" stroke-width="2">
          <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9"/>
        </svg>`;
        break;
      case 'image':
        name = 'Image';
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="#8b949e" stroke-width="2">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <circle cx="8.5" cy="8.5" r="1.5"/>
          <polyline points="21 15 16 10 5 21"/>
        </svg>`;
        break;
      default:
        name = drawing.type;
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="#8b949e" stroke-width="2">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
        </svg>`;
    }
    
    return { name, icon };
  }
  
  selectLayerItem(index) {
    this.selectedDrawings = [index];
    this.updateSelectionControls();
    this.updateLayersList();
    this.redraw();
  }
  
  deleteLayerItem(index) {
    if (index < 0 || index >= this.drawings.length) return;
    
    const drawingToDelete = this.drawings[index];
    
    // If deleting an animation path (movement line), reset the target object to starting position
    if (drawingToDelete && drawingToDelete.type === 'animpath' && drawingToDelete.targetIndex !== undefined && drawingToDelete.targetIndex !== null) {
      const targetIndex = drawingToDelete.targetIndex;
      const targetDrawing = this.drawings[targetIndex];
      
      if (targetDrawing && ['ball', 'tshirt'].includes(targetDrawing.type)) {
        // Get the object's current size
        const width = targetDrawing.endX - targetDrawing.startX;
        const height = targetDrawing.endY - targetDrawing.startY;
        
        // Reset object to starting position (at the start of the animation path)
        targetDrawing.startX = drawingToDelete.startX - width / 2;
        targetDrawing.startY = drawingToDelete.startY - height / 2;
        targetDrawing.endX = drawingToDelete.startX + width / 2;
        targetDrawing.endY = drawingToDelete.startY + height / 2;
      }
    }
    
    this.drawings.splice(index, 1);
    
    // Update animation path references after deletion (indices shift)
    this.drawings.forEach((drawing) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined && drawing.targetIndex !== null) {
        // If target index is greater than deleted index, shift it down by 1
        if (drawing.targetIndex > index) {
          drawing.targetIndex = drawing.targetIndex - 1;
        } else if (drawing.targetIndex === index) {
          // Target was deleted, clear the reference
          drawing.targetIndex = undefined;
        }
      }
    });
    
    // Update animation path references to find new targets if needed
    this.updateAnimPathReferences();
    
    this.selectedDrawings = [];
    this.saveState();
    this.updateLayersList();
    this.updateSelectionControls();
    this.redraw();
  }
  
  // Drag and drop for layers
  handleLayerDragStart(e, index) {
    this.draggedLayerIndex = index;
    e.target.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  }
  
  handleLayerDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.editor-layer-item').forEach(item => {
      item.classList.remove('drag-over');
    });
    this.draggedLayerIndex = null;
  }
  
  handleLayerDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const item = e.target.closest('.editor-layer-item');
    if (item && this.draggedLayerIndex !== parseInt(item.dataset.index)) {
      item.classList.add('drag-over');
    }
  }
  
  handleLayerDragLeave(e) {
    const item = e.target.closest('.editor-layer-item');
    if (item) {
      item.classList.remove('drag-over');
    }
  }
  
  handleLayerDrop(e, targetIndex) {
    e.preventDefault();
    const item = e.target.closest('.editor-layer-item');
    if (item) {
      item.classList.remove('drag-over');
    }
    
    if (this.draggedLayerIndex === null || this.draggedLayerIndex === targetIndex) return;
    
    const oldIndex = this.draggedLayerIndex;
    const newIndex = targetIndex;
    
    // Move the drawing from draggedLayerIndex to targetIndex
    const [movedDrawing] = this.drawings.splice(oldIndex, 1);
    this.drawings.splice(newIndex, 0, movedDrawing);
    
    // Update animation path targetIndex references to account for the index shift
    this.drawings.forEach((drawing) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined && drawing.targetIndex !== null) {
        const currentTargetIndex = drawing.targetIndex;
        
        if (currentTargetIndex === oldIndex) {
          // This path targets the moved object - update to new position
          drawing.targetIndex = newIndex;
        } else if (oldIndex < newIndex) {
          // Moving forward: indices between oldIndex+1 and newIndex shift left by 1
          if (currentTargetIndex > oldIndex && currentTargetIndex <= newIndex) {
            drawing.targetIndex = currentTargetIndex - 1;
          }
        } else {
          // Moving backward: indices between newIndex and oldIndex-1 shift right by 1
          if (currentTargetIndex >= newIndex && currentTargetIndex < oldIndex) {
            drawing.targetIndex = currentTargetIndex + 1;
          }
        }
      }
    });
    
    // Update selection if the moved item was selected
    if (this.selectedDrawings.includes(oldIndex)) {
      this.selectedDrawings = [newIndex];
    } else {
      // Adjust other selected indices
      this.selectedDrawings = this.selectedDrawings.map(i => {
        if (i === oldIndex) return newIndex;
        if (oldIndex < newIndex) {
          if (i > oldIndex && i <= newIndex) return i - 1;
        } else {
          if (i >= newIndex && i < oldIndex) return i + 1;
        }
        return i;
      });
    }
    
    // Update animation path references after reordering
    this.updateAnimPathReferences();
    
    this.draggedLayerIndex = null;
    this.saveState();
    this.updateLayersList();
    this.redraw();
  }

  // Color picker
  updateColorPresets() {
    document.querySelectorAll('.editor-color-preset').forEach(preset => {
      if (preset.dataset.color === this.currentColor) {
        preset.style.borderColor = '#1f6feb';
        preset.style.borderWidth = '3px';
      } else {
        preset.style.borderColor = 'transparent';
        preset.style.borderWidth = '2px';
      }
    });
    // Update color input to match
    const colorInput = document.getElementById('editorColorInput');
    if (colorInput) {
      colorInput.value = this.currentColor;
    }
  }

  // Merge drawings into the background image (makes them non-selectable)
  mergeDrawingsIntoBackground(drawings) {
    return new Promise((resolve, reject) => {
      if (!this.image || !drawings || drawings.length === 0) {
        resolve();
        return;
      }

      // Create a temporary canvas to composite everything
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = this.canvas.width;
      tempCanvas.height = this.canvas.height;
      const tempCtx = tempCanvas.getContext('2d');
      
      // Draw current background image
      tempCtx.drawImage(this.image, 0, 0);
      
      // Preload all images and SVG elements first
      const imagePromises = drawings
        .filter(d => d.type === 'image' && d.imageData)
        .map(drawing => {
          return new Promise((resolve) => {
            if (drawing.imageElement) {
              resolve(drawing.imageElement);
            } else {
              const img = new Image();
              img.onload = () => {
                drawing.imageElement = img;
                resolve(img);
              };
              img.onerror = () => resolve(null);
              img.src = drawing.imageData;
            }
          });
        });
      
      // Preload SVG elements
      const svgPromises = drawings
        .filter(d => ['barrier', 'biggoal', 'ladder', 'stick'].includes(d.type) && d.svgUrl)
        .map(drawing => {
          return new Promise((resolve) => {
            if (drawing.svgElement && drawing.svgElement.complete) {
              resolve(drawing.svgElement);
            } else if (drawing.svgUrl) {
              this.loadSvgElement(drawing.svgUrl).then(img => {
                drawing.svgElement = img;
                resolve(img);
              }).catch(() => resolve(null));
            } else {
              resolve(null);
            }
          });
        });
      
      // Wait for all images and SVG elements to load, then draw everything
      Promise.all([...imagePromises, ...svgPromises]).then(() => {
        console.log('mergeDrawingsIntoBackground: Starting to draw', drawings.length, 'drawings');
        console.log('mergeDrawingsIntoBackground: Canvas size:', tempCanvas.width, 'x', tempCanvas.height);
        
        const sprayDrawings = drawings.filter(d => d.type === 'spray');
        console.log('mergeDrawingsIntoBackground: Found', sprayDrawings.length, 'spray drawings');
        if (sprayDrawings.length > 0) {
          sprayDrawings.forEach((sd, idx) => {
            console.log('mergeDrawingsIntoBackground: Spray drawing', idx, 'details:', {
              particlesCount: sd.particles ? sd.particles.length : 0,
              color: sd.color,
              opacity: sd.opacity,
              particleSize: sd.particleSize,
              firstParticle: sd.particles && sd.particles.length > 0 ? sd.particles[0] : null
            });
          });
        }
        // Draw all drawings using the same logic as save()
        drawings.forEach((drawing, drawingIndex) => {
          tempCtx.save();
          const opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
          tempCtx.globalAlpha = Math.min(opacity, 1.0);
          tempCtx.strokeStyle = drawing.color;
          tempCtx.fillStyle = drawing.color;
          const baseLineWidth = drawing.lineWidth || 2;
          tempCtx.lineWidth = opacity > 0 ? baseLineWidth * Math.max(opacity, 1.0) : 0;
          
          // Apply line style
          const lineStyle = drawing.lineStyle || 'solid';
          switch (lineStyle) {
            case 'solid':
              tempCtx.setLineDash([]);
              break;
            case 'dashed':
              tempCtx.setLineDash([8, 4]);
              break;
            case 'dotted':
              tempCtx.setLineDash([2, 2]);
              break;
            default:
              tempCtx.setLineDash([]);
          }
          
          // Draw based on type (reuse save() logic)
          switch (drawing.type) {
            case 'line':
              tempCtx.beginPath();
              tempCtx.moveTo(drawing.startX, drawing.startY);
              tempCtx.lineTo(drawing.endX, drawing.endY);
              tempCtx.stroke();
              const lineAngle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
              this.drawEndpointOnContext(tempCtx, drawing.startX, drawing.startY, lineAngle, drawing.startCap || 'none', true);
              this.drawEndpointOnContext(tempCtx, drawing.endX, drawing.endY, lineAngle, drawing.endCap || 'none', false);
              break;
            case 'arrow':
              const arrowAngle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
              const arrowStartCap = drawing.startCap || 'none';
              const arrowEndCap = drawing.endCap || 'line';
              let arrowLineStartX = drawing.startX;
              let arrowLineStartY = drawing.startY;
              let arrowLineEndX = drawing.endX;
              let arrowLineEndY = drawing.endY;
              if (arrowEndCap !== 'none') {
                const arrowBaseOffset = 12;
                arrowLineEndX = drawing.endX - arrowBaseOffset * Math.cos(arrowAngle);
                arrowLineEndY = drawing.endY - arrowBaseOffset * Math.sin(arrowAngle);
              }
              if (arrowStartCap !== 'none') {
                const arrowBaseOffset = 12;
                arrowLineStartX = drawing.startX + arrowBaseOffset * Math.cos(arrowAngle);
                arrowLineStartY = drawing.startY + arrowBaseOffset * Math.sin(arrowAngle);
              }
              tempCtx.beginPath();
              tempCtx.moveTo(arrowLineStartX, arrowLineStartY);
              tempCtx.lineTo(arrowLineEndX, arrowLineEndY);
              tempCtx.stroke();
              this.drawEndpointOnContext(tempCtx, drawing.startX, drawing.startY, arrowAngle, arrowStartCap, true);
              this.drawEndpointOnContext(tempCtx, drawing.endX, drawing.endY, arrowAngle, arrowEndCap, false);
              break;
            case 'curve':
              const saveCurveType = drawing.curveType || 'quadratic';
              if (saveCurveType === 'quadratic' && drawing.controlPoint) {
                tempCtx.beginPath();
                tempCtx.moveTo(drawing.startX, drawing.startY);
                tempCtx.quadraticCurveTo(drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY);
                tempCtx.stroke();
              } else if (saveCurveType === 'cubic' && drawing.controlPoints && drawing.controlPoints.length >= 2) {
                tempCtx.beginPath();
                tempCtx.moveTo(drawing.startX, drawing.startY);
                tempCtx.bezierCurveTo(
                  drawing.controlPoints[0].x, drawing.controlPoints[0].y,
                  drawing.controlPoints[1].x, drawing.controlPoints[1].y,
                  drawing.endX, drawing.endY
                );
                tempCtx.stroke();
              } else {
                tempCtx.beginPath();
                tempCtx.moveTo(drawing.startX, drawing.startY);
                tempCtx.lineTo(drawing.endX, drawing.endY);
                tempCtx.stroke();
              }
              const curveAngle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
              this.drawEndpointOnContext(tempCtx, drawing.startX, drawing.startY, curveAngle, drawing.startCap || 'none', true);
              this.drawEndpointOnContext(tempCtx, drawing.endX, drawing.endY, curveAngle, drawing.endCap || 'none', false);
              break;
            case 'circle':
              const left = Math.min(drawing.startX, drawing.endX);
              const top = Math.min(drawing.startY, drawing.endY);
              const width = Math.abs(drawing.endX - drawing.startX);
              const height = Math.abs(drawing.endY - drawing.startY);
              const saveRadius = Math.max(width, height) / 2;
              const centerX = left + width / 2;
              const centerY = top + height / 2;
              tempCtx.beginPath();
              tempCtx.arc(centerX, centerY, saveRadius, 0, Math.PI * 2);
              if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                const fillColor = drawing.fillColor || '#FFFFFF';
                if (drawing.fillStyle === 'crosshatch') {
                  this.drawCrosshatchFillOnContext(tempCtx, centerX, centerY, saveRadius, fillColor, fillAlpha);
                } else {
                  tempCtx.save();
                  tempCtx.globalAlpha = fillAlpha;
                  tempCtx.fillStyle = fillColor;
                  tempCtx.fill();
                  tempCtx.restore();
                }
              }
              tempCtx.stroke();
              break;
            case 'oval':
              const ovalLeft = Math.min(drawing.startX, drawing.endX);
              const ovalTop = Math.min(drawing.startY, drawing.endY);
              const ovalWidth = Math.abs(drawing.endX - drawing.startX);
              const ovalHeight = Math.abs(drawing.endY - drawing.startY);
              const ovalRadiusX = ovalWidth / 2;
              const ovalRadiusY = ovalHeight / 2;
              const ovalCenterX = ovalLeft + ovalWidth / 2;
              const ovalCenterY = ovalTop + ovalHeight / 2;
              tempCtx.beginPath();
              tempCtx.ellipse(ovalCenterX, ovalCenterY, ovalRadiusX, ovalRadiusY, 0, 0, Math.PI * 2);
              if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                const fillColor = drawing.fillColor || '#FFFFFF';
                tempCtx.save();
                tempCtx.globalAlpha = fillAlpha;
                tempCtx.fillStyle = fillColor;
                tempCtx.fill();
                tempCtx.restore();
              }
              tempCtx.stroke();
              break;
            case 'arc':
              const arcLeft = Math.min(drawing.startX, drawing.endX);
              const arcTop = Math.min(drawing.startY, drawing.endY);
              const arcWidth = Math.abs(drawing.endX - drawing.startX);
              const arcHeight = Math.abs(drawing.endY - drawing.startY);
              const saveArcRadius = Math.max(arcWidth, arcHeight) / 2;
              const arcCenterX = arcLeft + arcWidth / 2;
              const arcCenterY = arcTop + arcHeight / 2;
              const startAngle = 0;
              const endAngle = Math.PI;
              tempCtx.beginPath();
              tempCtx.arc(arcCenterX, arcCenterY, saveArcRadius, startAngle, endAngle);
              if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                const fillColor = drawing.fillColor || '#FFFFFF';
                tempCtx.lineTo(arcCenterX - saveArcRadius, arcCenterY);
                tempCtx.closePath();
                if (drawing.fillStyle === 'crosshatch') {
                  this.drawCrosshatchFillArcOnContext(tempCtx, arcCenterX, arcCenterY, saveArcRadius, fillColor, fillAlpha);
                } else {
                  tempCtx.save();
                  tempCtx.globalAlpha = fillAlpha;
                  tempCtx.fillStyle = fillColor;
                  tempCtx.fill();
                  tempCtx.restore();
                }
                tempCtx.beginPath();
                tempCtx.arc(arcCenterX, arcCenterY, saveArcRadius, startAngle, endAngle);
              }
              tempCtx.stroke();
              break;
            case 'polygon':
              if (drawing.points && drawing.points.length >= 3) {
                tempCtx.beginPath();
                tempCtx.moveTo(drawing.points[0].x, drawing.points[0].y);
                for (let i = 1; i < drawing.points.length; i++) {
                  tempCtx.lineTo(drawing.points[i].x, drawing.points[i].y);
                }
                tempCtx.closePath();
                if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                  const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                  const fillColor = drawing.fillColor || '#FFFFFF';
                  if (drawing.fillStyle === 'crosshatch') {
                    this.drawCrosshatchFillPolygonOnContext(tempCtx, drawing.points, fillColor, fillAlpha);
                  } else {
                    tempCtx.save();
                    tempCtx.globalAlpha = fillAlpha;
                    tempCtx.fillStyle = fillColor;
                    tempCtx.fill();
                    tempCtx.restore();
                  }
                }
                tempCtx.stroke();
              }
              break;
            case 'freehand':
              if (drawing.points && drawing.points.length >= 2) {
                tempCtx.beginPath();
                tempCtx.moveTo(drawing.points[0].x, drawing.points[0].y);
                for (let i = 1; i < drawing.points.length; i++) {
                  tempCtx.lineTo(drawing.points[i].x, drawing.points[i].y);
                }
                tempCtx.stroke();
              }
              break;
            case 'text':
              const textFontWeight = drawing.fontWeight || 400;
              tempCtx.font = `${textFontWeight} ${drawing.fontSize || 16}px sans-serif`;
              tempCtx.fillStyle = drawing.color || '#FFFFFF';
              const textOpacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
              tempCtx.globalAlpha = textOpacity;
              tempCtx.fillText(drawing.text, drawing.x, drawing.y);
              break;
            case 'image':
              if (drawing.imageData && drawing.imageElement) {
                const imgOpacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
                tempCtx.save();
                tempCtx.globalAlpha = imgOpacity;
                tempCtx.drawImage(drawing.imageElement, drawing.x, drawing.y, drawing.width || drawing.originalWidth, drawing.height || drawing.originalHeight);
                tempCtx.restore();
              }
              break;
            case 'ball':
              this.drawBallOnContext(tempCtx, drawing);
              break;
            case 'tshirt':
              this.drawTshirtOnContext(tempCtx, drawing);
              break;
            case 'barrier':
            case 'biggoal':
            case 'ladder':
            case 'stick':
              this.drawSvgElementOnContext(tempCtx, drawing);
              break;
            case 'cross':
              tempCtx.beginPath();
              tempCtx.moveTo(drawing.startX, drawing.startY);
              tempCtx.lineTo(drawing.endX, drawing.endY);
              tempCtx.moveTo(drawing.endX, drawing.startY);
              tempCtx.lineTo(drawing.startX, drawing.endY);
              tempCtx.stroke();
              break;
            case 'spray':
              // Draw spray particles
              console.log('mergeDrawingsIntoBackground: Processing spray drawing', {
                hasParticles: !!drawing.particles,
                particlesLength: drawing.particles ? drawing.particles.length : 0,
                color: drawing.color,
                opacity: opacity,
                particleSize: drawing.particleSize
              });
              
              if (drawing.particles && drawing.particles.length > 0) {
                console.log('mergeDrawingsIntoBackground: Rendering spray with', drawing.particles.length, 'particles');
                // Save context state before drawing spray
                tempCtx.save();
                
                // Set fill style and opacity
                const sprayColor = drawing.color || '#FF0000'; // Default to red for visibility
                tempCtx.fillStyle = sprayColor;
                tempCtx.globalAlpha = Math.max(opacity, 0.1); // Ensure at least some opacity
                
                // Ensure minimum particle size for visibility (make it larger for testing)
                const particleSize = Math.max(drawing.particleSize || 3, 3);
                
                console.log('mergeDrawingsIntoBackground: Drawing with color', sprayColor, 'opacity', tempCtx.globalAlpha, 'particleSize', particleSize);
                
                let particlesDrawn = 0;
                let validParticles = 0;
                let invalidParticles = 0;
                
                drawing.particles.forEach((particle, idx) => {
                  if (particle && typeof particle.x === 'number' && typeof particle.y === 'number') {
                    validParticles++;
                    // Ensure coordinates are within canvas bounds
                    const x = Math.max(particleSize, Math.min(particle.x, tempCanvas.width - particleSize));
                    const y = Math.max(particleSize, Math.min(particle.y, tempCanvas.height - particleSize));
                    
                    // Draw the particle
                    tempCtx.beginPath();
                    tempCtx.arc(x, y, particleSize, 0, Math.PI * 2);
                    tempCtx.fill();
                    particlesDrawn++;
                    
                    if (idx < 10) {
                      console.log('mergeDrawingsIntoBackground: Drew particle', idx, 'at', x, y, 'size', particleSize);
                    }
                  } else {
                    invalidParticles++;
                    if (idx < 5) {
                      console.warn('mergeDrawingsIntoBackground: Invalid particle', idx, particle);
                    }
                  }
                });
                
                console.log('mergeDrawingsIntoBackground: Summary - Valid:', validParticles, 'Drew:', particlesDrawn, 'Invalid:', invalidParticles, 'Total:', drawing.particles.length);
                
                tempCtx.restore();
              } else {
                console.error('mergeDrawingsIntoBackground: Spray drawing has NO particles!', {
                  type: drawing.type,
                  hasParticles: !!drawing.particles,
                  particlesLength: drawing.particles ? drawing.particles.length : 0,
                  drawingKeys: Object.keys(drawing)
                });
              }
              break;
            case 'heatmap':
              // Draw heat map
              if (drawing.heatGrid && Object.keys(drawing.heatGrid).length > 0) {
                tempCtx.save();
                tempCtx.globalAlpha = Math.max(opacity, 0.1);
                
                const gridSize = drawing.gridSize || 4;
                
                // Draw each grid cell
                Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
                  const [gridX, gridY] = gridKey.split(',').map(Number);
                  const pixelX = gridX * gridSize;
                  const pixelY = gridY * gridSize;
                  
                  // Convert intensity to color using heat scale
                  const color = this.intensityToColor(intensity);
                  if (!color) return;
                  
                  // Draw filled rectangle for this grid cell
                  tempCtx.fillStyle = color;
                  tempCtx.fillRect(pixelX, pixelY, gridSize, gridSize);
                });
                
                tempCtx.restore();
              }
              break;
            case 'formation':
              // Formations are complex and handled separately, skip in merge
              break;
            case 'triangle':
              tempCtx.beginPath();
              tempCtx.moveTo((drawing.startX + drawing.endX) / 2, drawing.startY);
              tempCtx.lineTo(drawing.startX, drawing.endY);
              tempCtx.lineTo(drawing.endX, drawing.endY);
              tempCtx.closePath();
              if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                const fillColor = drawing.fillColor || '#FFFFFF';
                tempCtx.save();
                tempCtx.globalAlpha = fillAlpha;
                tempCtx.fillStyle = fillColor;
                tempCtx.fill();
                tempCtx.restore();
              }
              tempCtx.stroke();
              break;
            case 'rectangle':
              tempCtx.strokeRect(drawing.startX, drawing.startY, drawing.endX - drawing.startX, drawing.endY - drawing.startY);
              if (drawing.fillColor && drawing.fillOpacity !== undefined && drawing.fillOpacity > 0) {
                const fillAlpha = drawing.fillOpacity !== undefined ? drawing.fillOpacity : 1.0;
                const fillColor = drawing.fillColor || '#FFFFFF';
                tempCtx.save();
                tempCtx.globalAlpha = fillAlpha;
                tempCtx.fillStyle = fillColor;
                tempCtx.fillRect(drawing.startX, drawing.startY, drawing.endX - drawing.startX, drawing.endY - drawing.startY);
                tempCtx.restore();
              }
              break;
            case 'animpath':
              // Animation path - similar to line but with dashed style and special endpoints
              const animPathColor = drawing.color || '#1f6feb';
              tempCtx.strokeStyle = animPathColor;
              tempCtx.fillStyle = animPathColor;
              tempCtx.setLineDash([8, 4]); // Dashed line style
              tempCtx.beginPath();
              tempCtx.moveTo(drawing.startX, drawing.startY);
              tempCtx.lineTo(drawing.endX, drawing.endY);
              tempCtx.stroke();
              tempCtx.setLineDash([]); // Reset line dash
              
              // Draw start point (circle)
              tempCtx.beginPath();
              tempCtx.arc(drawing.startX, drawing.startY, 5, 0, Math.PI * 2);
              tempCtx.fill();
              
              // Draw end point (triangle arrow)
              const animPathAngle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
              this.drawEndpointOnContext(tempCtx, drawing.endX, drawing.endY, animPathAngle, 'triangle', false);
              
              // If linked to an object, draw link indicator
              if (drawing.targetIndex !== undefined && drawing.targetIndex !== null) {
                tempCtx.beginPath();
                tempCtx.arc(drawing.startX, drawing.startY, 8, 0, Math.PI * 2);
                tempCtx.strokeStyle = '#3fb950';
                tempCtx.lineWidth = 2;
                tempCtx.stroke();
                tempCtx.strokeStyle = animPathColor; // Reset stroke style
              }
              break;
            default:
              console.warn('mergeDrawingsIntoBackground: Unhandled drawing type:', drawing.type, drawing);
              break;
          }
          
          tempCtx.restore();
        });
        
        console.log('mergeDrawingsIntoBackground: Finished drawing all', drawings.length, 'drawings');
        
        // Convert canvas to image and replace background
        const mergedImageData = tempCanvas.toDataURL('image/jpeg', 0.95);
        const newImg = new Image();
        newImg.onload = () => {
          this.image = newImg;
          this.originalImageData = mergedImageData;
          resolve();
        };
        newImg.onerror = () => {
          console.error('Failed to create merged image');
          reject(new Error('Failed to create merged image'));
        };
        newImg.src = mergedImageData;
      }).catch(err => {
        console.error('Error merging drawings:', err);
        reject(err);
      });
    });
  }

  // Save/Cancel
  save() {
    if (!this.image) {
      console.error('Cannot save: no image loaded');
      return;
    }

    // Ensure slides are initialized before saving
    if (this.slides.length === 0) {
      this.initializeSlides();
    }
    
    // Ensure current slide exists
    if (!this.slides[this.currentSlideIndex]) {
      this.slides[this.currentSlideIndex] = {
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: []
      };
    }

    // Save current slide data before exporting
    this.saveCurrentSlide();
    
    console.log('save(): After saveCurrentSlide, slides.length =', this.slides.length);
    console.log('save(): Current slide drawings count =', this.slides[this.currentSlideIndex]?.drawings?.length || 0);
    console.log('save(): this.drawings.length =', this.drawings.length);

    console.log('Saving image...', {
      hasCallback: !!window.editorSaveCallback,
      hasChromeRuntime: !!(window.chrome && window.chrome.runtime),
      originalImageData: this.originalImageData,
      trueOriginalImageData: this.trueOriginalImageData,
      callbackId: this.callbackId,
      slidesCount: this.slides.length,
      currentSlideDrawingsCount: this.slides[this.currentSlideIndex]?.drawings?.length || 0
    });

    // Get the original background (for editor restoration)
    const originalBackground = this.trueOriginalImageData || this.originalImageData;
    
    if (!originalBackground) {
      console.error('Cannot save: no original background image available');
      showNotification('Error: No original background image found', 'error');
      return;
    }

    // Convert the original background to data URL if it's not already
    let originalBackgroundData = originalBackground;
    
    // If originalBackground is an Image object or data URL, we need to convert it
    if (typeof originalBackground === 'string' && originalBackground.startsWith('data:image/')) {
      // Already a data URL, use it directly
      originalBackgroundData = originalBackground;
    } else if (this.image && this.image.src) {
      // Use the current image's src if it matches the original
      // Create a canvas to export the original background
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = this.canvas.width;
      tempCanvas.height = this.canvas.height;
      const tempCtx = tempCanvas.getContext('2d');
      
      // Draw only the background image (no drawings)
      tempCtx.drawImage(this.image, 0, 0);
      originalBackgroundData = tempCanvas.toDataURL('image/jpeg', 0.95);
    } else {
      // Fallback: try to use originalBackground as-is
      originalBackgroundData = originalBackground;
    }

    // Create a merged image (with drawings) for preview display
    // This will be used as imageData in previews, while originalBackgroundData is used for editor restoration
    console.log('save(): Creating merged image for preview with', this.drawings.length, 'drawings');
    
    // Check for spray drawings before merging
    const sprayDrawings = this.drawings.filter(d => d.type === 'spray');
    console.log('save(): Found', sprayDrawings.length, 'spray drawings in this.drawings');
    if (sprayDrawings.length > 0) {
      sprayDrawings.forEach((sd, idx) => {
        console.log('save(): Spray drawing', idx, 'has', sd.particles ? sd.particles.length : 0, 'particles');
      });
    }
    
    // Also check what's in the current slide
    if (this.slides[this.currentSlideIndex] && this.slides[this.currentSlideIndex].drawings) {
      const slideSprayDrawings = this.slides[this.currentSlideIndex].drawings.filter(d => d.type === 'spray');
      console.log('save(): Found', slideSprayDrawings.length, 'spray drawings in current slide');
    }
    
    // Preserve the current image and originalImageData before merging
    const originalImageBeforeMerge = this.image;
    const originalImageDataBeforeMerge = this.originalImageData;
    
    // Use mergeDrawingsIntoBackground to create the merged preview image
    // Use drawings from current slide if available, otherwise use this.drawings
    const drawingsToMerge = (this.slides[this.currentSlideIndex] && this.slides[this.currentSlideIndex].drawings) 
      ? this.slides[this.currentSlideIndex].drawings 
      : this.drawings;
    console.log('save(): Merging', drawingsToMerge.length, 'drawings');
    this.mergeDrawingsIntoBackground(drawingsToMerge).then(() => {
      // After merging, this.originalImageData will contain the merged image
      const mergedImageData = this.originalImageData; // This is now the merged image
      
      console.log('save(): Merged image created, sending save message');
      console.log('save(): Original background length:', originalBackgroundData ? originalBackgroundData.length : 0);
      console.log('save(): Merged image length:', mergedImageData ? mergedImageData.length : 0);
      
      // Restore the original image and originalImageData for next time
      this.image = originalImageBeforeMerge;
      this.originalImageData = originalImageDataBeforeMerge;
      
      // Send the merged image as imageData (for previews) and original background as originalImageSrc (for editor)
      this.sendSaveMessage(mergedImageData, originalBackgroundData);
    }).catch(err => {
      console.error('save(): Failed to merge drawings, saving without merge:', err);
      // Restore the original image and originalImageData
      this.image = originalImageBeforeMerge;
      this.originalImageData = originalImageDataBeforeMerge;
      // Fallback: use original background as imageData if merge fails
      this.sendSaveMessage(originalBackgroundData, originalBackgroundData);
    });

    // Note: The actual save is now handled in the mergeDrawingsIntoBackground promise above
    // The sendSaveMessage call will handle chrome.runtime messaging and fallback scenarios
  }
  
  sendSaveMessage(modifiedImageData, originalImageSrc = null) {
    // Get originalImageSrc and callbackId from storage as fallback if not set
    const getSaveData = () => {
      // Use provided originalImageSrc, or fall back to trueOriginalImageData
      // This ensures we always reference the unmerged background, not a previously merged image
      const originalBackground = originalImageSrc || this.trueOriginalImageData || this.originalImageData || null;
      
      // Ensure slides are saved before sending
      if (this.slides.length === 0 || !this.slides[this.currentSlideIndex] || !this.slides[this.currentSlideIndex].drawings) {
        console.warn('Slides not properly initialized, saving current slide now');
        this.saveCurrentSlide();
      }
      
      // Ensure all slides are saved with their current data before sending
      this.saveCurrentSlide();
      
      // Deep clone slides to ensure all properties including backgroundImage are included
      // IMPORTANT: Use each slide's own backgroundImage, never use this.image.src
      console.log('sendSaveMessage: Creating slidesToSave from', this.slides.length, 'slides');
      const slidesToSave = this.slides.map((slide, idx) => {
        // Ensure we're using the slide's own backgroundImage, not the global this.image.src
        // CRITICAL: Use strict undefined check - if undefined, set to null, otherwise use the actual value
        const slideBg = slide.backgroundImage !== undefined && slide.backgroundImage !== null ? slide.backgroundImage : null;
        
        // Log each slide's background status
        console.log(`sendSaveMessage: Slide ${idx} - backgroundImage:`, {
          original: slide.backgroundImage !== undefined ? (slide.backgroundImage ? 'has value' : 'null') : 'undefined',
          final: slideBg !== null ? 'has value' : 'null',
          isSameAsImageSrc: this.image && this.image.src && slideBg === this.image.src ? 'ERROR - SAME AS IMAGE.SRC!' : 'OK'
        });
        
        // Safety check: if slide has no backgroundImage, it should be null, not this.image.src
        if (slideBg === null && this.image && this.image.src) {
          // This slide should use the default background (null), not the current loaded image
          // The default background is stored in trueOriginalImageData, but each slide's
          // backgroundImage should be null if it doesn't have its own custom background
          console.log(`sendSaveMessage: Slide ${idx} has no custom background (null), will use default on load`);
        }
        
        // CRITICAL: Create a completely new object to avoid any reference issues
        const slideToSave = {
          drawings: slide.drawings ? JSON.parse(JSON.stringify(slide.drawings)) : [],
          thumbnail: slide.thumbnail,
          comment: slide.comment || '',
          benchPlayers: slide.benchPlayers ? JSON.parse(JSON.stringify(slide.benchPlayers)) : [],
          backgroundImage: slideBg // Use the slide's own backgroundImage, never this.image.src
        };
        
        return slideToSave;
      });
      
      const message = {
        action: 'imageEditorSaved',
        imageData: modifiedImageData,
        originalImageSrc: originalBackground,
        slidesData: slidesToSave
      };
      
      console.log('sendSaveMessage: Sending slidesData with', slidesToSave.length, 'slides');
      slidesToSave.forEach((slide, idx) => {
        const bgPreview = slide.backgroundImage ? slide.backgroundImage.substring(0, 50) + '...' : 'null';
        console.log(`sendSaveMessage: Slide ${idx} - drawings: ${slide.drawings.length}, hasBackground: ${!!slide.backgroundImage}, bgPreview: ${bgPreview}`);
      });
      
      // Verify that slides have different backgrounds (if they should)
      const backgrounds = slidesToSave.map(s => s.backgroundImage);
      const uniqueBackgrounds = new Set(backgrounds.filter(bg => bg !== null));
      if (uniqueBackgrounds.size < backgrounds.filter(bg => bg !== null).length) {
        console.warn('sendSaveMessage: WARNING - Multiple slides have the same background!', {
          totalSlides: slidesToSave.length,
          slidesWithBackground: backgrounds.filter(bg => bg !== null).length,
          uniqueBackgrounds: uniqueBackgrounds.size
        });
      }
      
      // Always include callbackId if we have it (from chrome.storage)
      if (this.callbackId) {
        message.callbackId = this.callbackId;
        console.log('Sending save message with callbackId:', this.callbackId);
      } else {
        console.log('Sending save message without callbackId');
      }
      
      return message;
    };
    
    // If originalImageData is missing, try to get it from storage
    if (!this.originalImageData && window.chrome && window.chrome.storage) {
      chrome.storage.local.get(['pendingEditorImageSrc', 'pendingEditorCallbackId'], (result) => {
        if (result.pendingEditorImageSrc && !this.originalImageData) {
          this.originalImageData = result.pendingEditorImageSrc;
          console.log('Retrieved originalImageSrc from storage:', this.originalImageData);
        }
        if (result.pendingEditorCallbackId && !this.callbackId) {
          this.callbackId = result.pendingEditorCallbackId;
          console.log('Retrieved callbackId from storage:', this.callbackId);
        }
        
        const message = getSaveData();
        this.sendMessageToBackground(message);
      });
    } else {
      const message = getSaveData();
      this.sendMessageToBackground(message);
    }
  }
  
  sendMessageToBackground(message) {
    // Send message - this is the primary save mechanism
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error sending save message:', chrome.runtime.lastError.message);
        // Fallback: try direct callback if message fails
        if (window.editorSaveCallback) {
          console.log('Message failed, using direct callback as fallback');
          window.editorSaveCallback(message.imageData);
        }
        // Only close if callback is not available
        if (!window.editorSaveCallback) {
          this.close();
        }
      } else {
        console.log('Save message sent successfully', response);
        // Show success notification and close window
        const imageSavedText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.imageSavedSuccessfully')
          : 'Image saved successfully!';
        showNotification(imageSavedText, 'success', 2000);
        setTimeout(() => {
          this.close();
        }, 2000);
      }
    });
  }

  updateOpacityControlForSelection() {
    const styleToolbar = document.getElementById('editorStyleToolbar');
    const opacityInput = document.getElementById('editorOpacity');
    const opacityValue = document.getElementById('editorOpacityValue');
    const colorInput = document.getElementById('editorColorInput');
    const fontSizeControl = document.getElementById('editorFontSizeControl');
    const fontSizeInput = document.getElementById('editorFontSize');
    const fontSizeValue = document.getElementById('editorFontSizeValue');
    const fillColorInput = document.getElementById('editorFillColor');
    const fillOpacityInput = document.getElementById('editorFillOpacity');
    const fillOpacityValue = document.getElementById('editorFillOpacityValue');
    const fillStyleSelect = document.getElementById('editorFillStyle');
    // T-shirt number input
    const tshirtNumberInput = document.getElementById('editorTshirtNumber');

    if (this.selectedDrawings.length === 0) {
      if (styleToolbar) {
        styleToolbar.classList.add('hidden');
      }
      if (fontSizeControl) {
        fontSizeControl.classList.add('hidden');
      }
      return;
    }

    // Get the first selected drawing
    const firstDrawing = this.drawings[this.selectedDrawings[0]];
    const isText = firstDrawing && firstDrawing.type === 'text';
    const isImage = firstDrawing && firstDrawing.type === 'image';
    const isBall = firstDrawing && firstDrawing.type === 'ball';
    const isTshirt = firstDrawing && firstDrawing.type === 'tshirt';
    const isShape = firstDrawing && ['circle', 'arc', 'polygon', 'triangle', 'rectangle'].includes(firstDrawing.type);

    // Handle style toolbar (thickness, fill, opacity, style)
    const lineOpacityInput = document.getElementById('editorLineOpacity');
    const lineOpacityValue = document.getElementById('editorLineOpacityValue');
    if (styleToolbar && lineOpacityInput && lineOpacityValue) {
      if (isText) {
        // Hide style control for text (text uses font size instead)
        styleToolbar.classList.add('hidden');
      } else if (isImage) {
        // For images, show only opacity control (hide thickness, fill, style)
        styleToolbar.classList.remove('hidden');
        
        // Get all row elements
        const thicknessRow = document.getElementById('editorThicknessRow');
        const fillColorRow = document.getElementById('editorFillColorRow');
        const fillOpacityRow = document.getElementById('editorFillOpacityRow');
        const fillStyleRow = document.getElementById('editorFillStyleRow');
        
        // Hide thickness row for images (use both class and style to ensure it's hidden)
        if (thicknessRow) {
          thicknessRow.classList.add('hidden');
          thicknessRow.style.display = 'none';
        }
        
        // Hide fill color and style rows for images
        if (fillColorRow) {
          fillColorRow.classList.add('hidden');
          fillColorRow.style.display = 'none';
        }
        if (fillStyleRow) {
          fillStyleRow.classList.add('hidden');
          fillStyleRow.style.display = 'none';
        }
        
        // Show only fill opacity row for images (but it controls image opacity)
        if (fillOpacityRow) {
          fillOpacityRow.classList.remove('hidden');
          fillOpacityRow.style.display = 'flex';
          // Update label to just "Opacity" for images
          const label = fillOpacityRow.querySelector('label');
          if (label) label.textContent = 'Opacity:';
        }
        
        // Make the control compact (narrower) when only opacity is shown
        if (styleToolbar) {
          styleToolbar.classList.add('compact');
        }
        
        // Set opacity value for images
        if (fillOpacityInput && fillOpacityValue) {
          const currentOpacity = firstDrawing.opacity !== undefined ? firstDrawing.opacity : 1.0;
          fillOpacityInput.value = Math.round(currentOpacity * 100);
          fillOpacityValue.textContent = Math.round(currentOpacity * 100) + '%';
        }
      } else if (isBall || isTshirt) {
        // For ball and t-shirt, show only color control (hide thickness, fill, style)
        styleToolbar.classList.remove('hidden');
        
        // Get all row elements
        const thicknessRow = document.getElementById('editorThicknessRow');
        const fillColorRow = document.getElementById('editorFillColorRow');
        const fillOpacityRow = document.getElementById('editorFillOpacityRow');
        const fillStyleRow = document.getElementById('editorFillStyleRow');
        
        // Hide thickness row
        if (thicknessRow) {
          thicknessRow.classList.add('hidden');
          thicknessRow.style.display = 'none';
        }
        
        // Hide fill opacity and style rows
        if (fillOpacityRow) {
          fillOpacityRow.classList.add('hidden');
          fillOpacityRow.style.display = 'none';
        }
        if (fillStyleRow) {
          fillStyleRow.classList.add('hidden');
          fillStyleRow.style.display = 'none';
        }
        
        // Show fill color row (but it controls the ball/t-shirt color)
        if (fillColorRow) {
          fillColorRow.classList.remove('hidden');
          fillColorRow.style.display = 'flex';
          // Update label to "Color:" for ball/t-shirt
          const label = fillColorRow.querySelector('label');
          if (label) {
            const colorText = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.color')
              : 'Color:';
            label.textContent = colorText;
          }
        }
        
        // Make the control compact (narrower) when only color is shown
        if (styleToolbar) {
          styleToolbar.classList.add('compact');
        }
        
        // Set color value
        if (fillColorInput) {
          const currentColor = firstDrawing.color || this.currentColor || '#FFFFFF';
          fillColorInput.value = currentColor;
        }
      } else {
        // Show full style control for other drawings (lines, shapes, etc.)
        styleToolbar.classList.remove('hidden');
        // Remove compact class for full controls
        styleToolbar.classList.remove('compact');
        const currentOpacity = firstDrawing.opacity !== undefined ? firstDrawing.opacity : 1.0;
        if (lineOpacityInput && lineOpacityValue) {
          lineOpacityInput.value = Math.round(currentOpacity * 100);
          lineOpacityValue.textContent = Math.round(currentOpacity * 100) + '%';
        }
        
        // Always show thickness row for non-images
        const thicknessRow = document.getElementById('editorThicknessRow');
        if (thicknessRow) {
          thicknessRow.classList.remove('hidden');
          thicknessRow.style.display = 'flex';
        }
        
        // Show fill controls for shapes
        const fillColorRow = document.getElementById('editorFillColorRow');
        const fillOpacityRow = document.getElementById('editorFillOpacityRow');
        const fillStyleRow = document.getElementById('editorFillStyleRow');
        
        if (isShape) {
          // Show all fill controls for shapes
          if (fillColorRow) {
            fillColorRow.classList.remove('hidden');
            fillColorRow.style.display = 'flex';
          }
          if (fillOpacityRow) {
            fillOpacityRow.classList.remove('hidden');
            fillOpacityRow.style.display = 'flex';
            // Restore label to "Opacity:" for shapes
            const label = fillOpacityRow.querySelector('label');
            if (label) label.textContent = 'Opacity:';
          }
          if (fillStyleRow) {
            fillStyleRow.classList.remove('hidden');
            fillStyleRow.style.display = 'flex';
          }
          
          if (fillColorInput && fillOpacityInput && fillOpacityValue && fillStyleSelect) {
            const currentFillColor = firstDrawing.fillColor || this.fillColor || '#FFFFFF';
            const currentFillOpacity = firstDrawing.fillOpacity !== undefined ? firstDrawing.fillOpacity : (this.fillOpacity || 1.0);
            const currentFillStyle = firstDrawing.fillStyle || this.fillStyle || 'solid';
            
            fillColorInput.value = currentFillColor;
            fillOpacityInput.value = Math.round(currentFillOpacity * 100);
            fillOpacityValue.textContent = Math.round(currentFillOpacity * 100) + '%';
            fillStyleSelect.value = currentFillStyle;
          }
        } else {
          // Hide fill controls for non-shapes (lines, arrows, etc.)
          if (fillColorRow) {
            fillColorRow.classList.add('hidden');
            fillColorRow.style.display = 'none';
          }
          if (fillOpacityRow) {
            fillOpacityRow.classList.add('hidden');
            fillOpacityRow.style.display = 'none';
          }
          if (fillStyleRow) {
            fillStyleRow.classList.add('hidden');
            fillStyleRow.style.display = 'none';
          }
        }
      }
    }

    // Handle font size control (only for text)
    if (fontSizeControl && fontSizeInput && fontSizeValue) {
      if (isText) {
        fontSizeControl.classList.remove('hidden');
        const currentFontSize = firstDrawing.fontSize || 16;
        fontSizeInput.value = currentFontSize;
        fontSizeValue.textContent = currentFontSize + 'px';
      } else {
        fontSizeControl.classList.add('hidden');
      }
    }

    // Update the color picker to show the selected drawing's color
    if (colorInput) {
      const currentColor = firstDrawing.color || this.currentColor;
      colorInput.value = currentColor;
      this.currentColor = currentColor;
      this.updateColorPresets();
    }

    // If multiple objects are selected, we could show some indication
    // For now, just use the first object's properties
  }

  downloadImage(imageData) {
    // Create a download link for the image
    const link = document.createElement('a');
    link.download = 'edited-image.jpg';
    link.href = imageData;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  drawArrowOnContext(ctx, drawing) {
    const arrowStyle = drawing.arrowStyle || 'line';
    
    // Draw the main line
    ctx.beginPath();
    ctx.moveTo(drawing.startX, drawing.startY);
    ctx.lineTo(drawing.endX, drawing.endY);
    ctx.stroke();
    
    // Calculate arrow properties
    const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
    const arrowLength = 12;
    const arrowAngle = Math.PI / 6;
    const arrowWidth = 8;
    
    // Draw arrowhead based on style
    ctx.save();
    
    switch (arrowStyle) {
      case 'line':
        // Simple V-shaped arrow
        ctx.beginPath();
        ctx.moveTo(drawing.endX, drawing.endY);
        ctx.lineTo(
          drawing.endX - arrowLength * Math.cos(angle - arrowAngle),
          drawing.endY - arrowLength * Math.sin(angle - arrowAngle)
        );
        ctx.moveTo(drawing.endX, drawing.endY);
        ctx.lineTo(
          drawing.endX - arrowLength * Math.cos(angle + arrowAngle),
          drawing.endY - arrowLength * Math.sin(angle + arrowAngle)
        );
        ctx.stroke();
        break;
        
      case 'triangle':
        // Filled triangle arrow
        ctx.beginPath();
        ctx.moveTo(drawing.endX, drawing.endY);
        ctx.lineTo(
          drawing.endX - arrowLength * Math.cos(angle - arrowAngle),
          drawing.endY - arrowLength * Math.sin(angle - arrowAngle)
        );
        ctx.lineTo(
          drawing.endX - arrowLength * Math.cos(angle + arrowAngle),
          drawing.endY - arrowLength * Math.sin(angle + arrowAngle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'reversed':
        // Reversed triangle (pointing backwards)
        const backOffset = arrowLength * 0.7;
        ctx.beginPath();
        ctx.moveTo(
          drawing.endX - backOffset * Math.cos(angle),
          drawing.endY - backOffset * Math.sin(angle)
        );
        ctx.lineTo(
          drawing.endX - backOffset * Math.cos(angle) + arrowLength * Math.cos(angle - arrowAngle),
          drawing.endY - backOffset * Math.sin(angle) + arrowLength * Math.sin(angle - arrowAngle)
        );
        ctx.lineTo(
          drawing.endX - backOffset * Math.cos(angle) + arrowLength * Math.cos(angle + arrowAngle),
          drawing.endY - backOffset * Math.sin(angle) + arrowLength * Math.sin(angle + arrowAngle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'circle':
        // Circle arrow
        const circleRadius = arrowWidth / 2;
        ctx.beginPath();
        ctx.arc(drawing.endX, drawing.endY, circleRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        break;
        
      case 'diamond':
        // Diamond arrow
        const diamondLength = arrowLength;
        ctx.beginPath();
        // Tip of diamond
        ctx.moveTo(drawing.endX, drawing.endY);
        // Top point
        ctx.lineTo(
          drawing.endX - diamondLength * 0.5 * Math.cos(angle) - arrowWidth * 0.5 * Math.sin(angle),
          drawing.endY - diamondLength * 0.5 * Math.sin(angle) + arrowWidth * 0.5 * Math.cos(angle)
        );
        // Back point
        ctx.lineTo(
          drawing.endX - diamondLength * Math.cos(angle),
          drawing.endY - diamondLength * Math.sin(angle)
        );
        // Bottom point
        ctx.lineTo(
          drawing.endX - diamondLength * 0.5 * Math.cos(angle) + arrowWidth * 0.5 * Math.sin(angle),
          drawing.endY - diamondLength * 0.5 * Math.sin(angle) - arrowWidth * 0.5 * Math.cos(angle)
        );
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
    }
    
    ctx.restore();
  }

  cancel() {
    this.close();
  }

  close() {
    // Clean up ResizeObserver
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    
    // If this is a standalone window, close it
    const modal = document.getElementById('editorModal');
    if (!modal) {
      // Standalone window - close it
      window.close();
    } else {
      // Modal mode - hide it
      modal.classList.add('hidden');
    }
    
    // Reset state
    this.image = null;
    this.originalImageData = null;
    this.trueOriginalImageData = null; // Reset true original when closing
    this.callbackId = null;
    this.drawings = [];
    this.selectedDrawings = [];
    this.selectionRect = null;
    this.history = [];
    this.historyIndex = -1;
    this.zoom = 1;
    this.polygonPoints = [];
    // Reset slides state
    this.slides = [];
    this.currentSlideIndex = 0;
    if (this.textInput) {
      this.textInput.remove();
      this.textInput = null;
    }
  }

  open(imageSrc, saveCallback, slidesData = null, originalImageSrc = null) {
    // Check if we're in a standalone window (editor.html) or modal (popup.html)
    // In editor.html, there's no editorModal element, so we're in standalone mode
    const modal = document.getElementById('editorModal');
    const isStandaloneWindow = !modal || window.location.href.includes('editor.html');
    
    if (modal && !isStandaloneWindow) {
      // Modal mode (backward compatibility - only if we're in popup.html)
      modal.classList.remove('hidden');
      window.editorSaveCallback = saveCallback;
      modal.style.zIndex = '10000';
      modal.focus();
      if (window.focus) {
        window.focus();
      }
    } else {
      // Standalone window mode (editor.html)
      window.editorSaveCallback = saveCallback;
    }

    // Check for pending autocapture screenshots BEFORE loading image
    // This ensures we handle screenshots before initializing with default image
    chrome.storage.local.get(['pendingAutocaptureScreenshots'], async (result) => {
      if (result.pendingAutocaptureScreenshots && Array.isArray(result.pendingAutocaptureScreenshots) && result.pendingAutocaptureScreenshots.length > 0) {
        // Clear the pending screenshots from storage
        chrome.storage.local.remove(['pendingAutocaptureScreenshots'], async () => {
          // Load first screenshot as background
          await this.loadImage(result.pendingAutocaptureScreenshots[0], true, true);
          // Create slides from screenshots (this will replace the current slide)
          await this.createSlidesFromScreenshots(result.pendingAutocaptureScreenshots);
        });
        return; // Don't continue with normal loading
      }
      
      // No autocapture screenshots, continue with normal loading
      this.continueNormalLoad(imageSrc, saveCallback, slidesData, originalImageSrc);
    });
  }

  continueNormalLoad(imageSrc, saveCallback, slidesData, originalImageSrc) {
    // Check if this is a goal image - disable zones for goal schemes
    const isGoalImage = imageSrc && (imageSrc.includes('goal.svg') || imageSrc.includes('goal'));
    if (isGoalImage) {
      this.showZoneOverlay = false;
      // Hide the zone overlay button
      const zoneOverlayBtn = document.getElementById('editorZoneOverlayBtn');
      if (zoneOverlayBtn) {
        zoneOverlayBtn.style.display = 'none';
      }
    } else {
      // Show the zone overlay button for non-goal images
      const zoneOverlayBtn = document.getElementById('editorZoneOverlayBtn');
      if (zoneOverlayBtn) {
        zoneOverlayBtn.style.display = 'flex';
      }
    }
    
    // If we have slidesData, ALWAYS use the original background image, never the merged one
    // This prevents duplicate drawings (one merged in background, one as separate objects)
    // Since we now save only the original background (not merged), imageSrc should be the original
    // if originalImageSrc is not explicitly provided
    let imageToLoad = imageSrc;
    if (slidesData && Array.isArray(slidesData) && slidesData.length > 0) {
      if (originalImageSrc) {
        // Use the provided original background
        imageToLoad = originalImageSrc;
      } else {
        // No originalImageSrc provided, but we have slidesData
        // Since we now save only the original background (not merged), imageSrc should be the original
        // Use imageSrc as the original background
        imageToLoad = imageSrc;
        console.log('Editor: Loading with slidesData but no originalImageSrc provided. Using imageSrc as original background (should be original since we no longer merge).');
      }
    }
    
    this.loadImage(imageToLoad).then(() => {
      // Track that we've loaded the default background initially
      this.currentLoadedBackground = 'default';
      
      // When loading with slidesData, ensure trueOriginalImageData is set to the original background
      // This ensures future saves reference the correct original
      if (slidesData && originalImageSrc && imageToLoad === originalImageSrc) {
        // We loaded the original background, so set trueOriginalImageData if not already set
        if (this.trueOriginalImageData === null) {
          this.trueOriginalImageData = originalImageSrc;
        }
        // Also update originalImageData to match
        this.originalImageData = originalImageSrc;
      } else if (slidesData && !originalImageSrc) {
        // We have slidesData but no originalImageSrc - this shouldn't happen ideally
        // But if it does, we'll use the loaded image as the original
        if (this.trueOriginalImageData === null) {
          this.trueOriginalImageData = imageToLoad;
        }
      }
      this.updateZoom();

      // Load slides data if provided
      if (slidesData && Array.isArray(slidesData) && slidesData.length > 0) {
        console.log('Editor: Loading slidesData:', slidesData.length, 'slides');
        console.log('Editor: First slide has', slidesData[0]?.drawings?.length || 0, 'drawings');
        
        // Deep clone slides to ensure all properties are preserved
        // CRITICAL: Preserve each slide's backgroundImage independently
        console.log('Editor: Loading slidesData, mapping', slidesData.length, 'slides');
        this.slides = slidesData.map((slide, idx) => {
          // Use strict check - if backgroundImage is undefined or null, set to null
          // Otherwise, use the actual value (even if it's an empty string, though that shouldn't happen)
          const slideBg = slide.backgroundImage !== undefined && slide.backgroundImage !== null ? slide.backgroundImage : null;
          
          console.log(`Editor: Loading slide ${idx} - backgroundImage:`, {
            original: slide.backgroundImage !== undefined ? (slide.backgroundImage ? 'has value' : 'null') : 'undefined',
            final: slideBg !== null ? 'has value' : 'null',
            preview: slideBg ? slideBg.substring(0, 30) + '...' : 'null'
          });
          
          return {
            drawings: slide.drawings || [],
            thumbnail: slide.thumbnail || null,
            comment: slide.comment || '',
            benchPlayers: slide.benchPlayers || [],
            backgroundImage: slideBg // Preserve the actual backgroundImage value, or null if not set
          };
        });
        
        this.currentSlideIndex = 0;
        
        // Log each slide's background status
        console.log('Editor: Loaded slides with backgrounds:', this.slides.map((s, i) => ({
          index: i,
          hasBackground: !!s.backgroundImage,
          backgroundPreview: s.backgroundImage ? s.backgroundImage.substring(0, 50) + '...' : 'null'
        })));
        
        // Normalize slides for backward compatibility
        this.normalizeSlides();
        
        // If first slide has a background image, load it instead of the default
        const firstSlideBackground = this.slides[0]?.backgroundImage;
        if (firstSlideBackground) {
          // Load the first slide's background (mark as slide-specific so it doesn't overwrite trueOriginalImageData)
          this.loadImage(firstSlideBackground, true, true).then(() => {
            // Track that we've loaded slide 0's background
            this.currentLoadedBackground = 0;
            // Continue with loading drawings after background loads
            this.loadSlideDrawings();
          }).catch(() => {
            // If background load fails, continue with default and load drawings
            this.currentLoadedBackground = 'default';
            this.loadSlideDrawings();
          });
        } else {
          // No slide-specific background, continue with default (already loaded)
          this.currentLoadedBackground = 'default';
          this.loadSlideDrawings();
        }
      } else {
        // No slides data provided - initialize with a fresh slide
        console.log('Editor: No slidesData provided, initializing fresh slides');
        console.log('Editor: slidesData value:', slidesData);
        this.slides = [{
          drawings: [],
          thumbnail: null,
          comment: '',
          benchPlayers: [],
          backgroundImage: null
        }];
        this.currentSlideIndex = 0;
        this.drawings = [];
        this.redraw();
        this.updateSlidesPanel();
        // Update phase comment input after a short delay to ensure DOM is ready
        setTimeout(() => {
          this.updatePhaseCommentInput();
        }, 100);
      }
    }).catch(err => {
      console.error('Failed to load image:', err);
      showNotification('Failed to load image', 'error');
      this.close();
    });
  }
  
  // Helper method to load drawings after background is loaded
  loadSlideDrawings() {
    const savedDrawings = JSON.parse(JSON.stringify(this.slides[0].drawings || []));
    console.log('Editor: Parsed savedDrawings:', savedDrawings.length, 'drawings');
    
    // Restore drawings as separate objects to preserve animations and editability
    if (savedDrawings.length > 0) {
      console.log('Editor: Restoring', savedDrawings.length, 'drawings from first slide');
      // Restore drawings array from the first slide
      this.drawings = savedDrawings;
      console.log('Editor: this.drawings set to', this.drawings.length, 'drawings');
      console.log('Editor: First drawing:', this.drawings[0] ? { 
        type: this.drawings[0].type, 
        startX: this.drawings[0].startX, 
        startY: this.drawings[0].startY,
        endX: this.drawings[0].endX,
        endY: this.drawings[0].endY,
        svgUrl: this.drawings[0].svgUrl,
        hasSvgElement: !!this.drawings[0].svgElement,
        color: this.drawings[0].color
      } : 'null');
      
      // Update animation path references to ensure they're valid after restoration
      this.updateAnimPathReferences();
      
      // Ensure objects with animation paths are at their start positions
      this.drawings.forEach((drawing) => {
        if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
          const targetIndex = drawing.targetIndex;
          if (targetIndex >= 0 && targetIndex < this.drawings.length) {
            const target = this.drawings[targetIndex];
            if (target && (['ball', 'tshirt'].includes(target.type) || ['barrier', 'biggoal', 'ladder', 'stick'].includes(target.type))) {
              // Get object size
              const width = target.endX - target.startX;
              const height = target.endY - target.startY;
              
              // Reset object to start position (from animation path's start)
              target.startX = drawing.startX - width / 2;
              target.startY = drawing.startY - height / 2;
              target.endX = drawing.startX + width / 2;
              target.endY = drawing.startY + height / 2;
            }
          }
        }
      });
      
      // Reload SVG elements for proper rendering (async, but we'll redraw after)
      this.reloadSvgElements().then(() => {
        console.log('Editor: SVG elements reloaded, redrawing canvas');
        this.redraw();
      }).catch(err => {
        console.error('Editor: Error reloading SVG elements:', err);
        // Redraw anyway even if SVG reload fails
        this.redraw();
      });
      
      // Also redraw immediately (before SVG loads) to show non-SVG elements
      console.log('Editor: About to call redraw(), this.drawings.length =', this.drawings.length);
      this.redraw();
      console.log('Editor: After redraw(), this.drawings.length =', this.drawings.length);
      this.updateSlidesPanel();
      // Update phase comment input after a short delay to ensure DOM is ready
      setTimeout(() => {
        this.updatePhaseCommentInput();
        this.updateBenchDisplay();
      }, 100);
    } else {
      // No drawings to restore
      console.log('Editor: No drawings to restore from first slide');
      console.log('Editor: slidesData[0]:', this.slides[0]);
      console.log('Editor: slidesData[0].drawings:', this.slides[0]?.drawings);
      this.drawings = [];
      this.redraw();
      this.updateSlidesPanel();
      setTimeout(() => {
        this.updatePhaseCommentInput();
      }, 100);
    }
  }
  
  // Initialize from parent window if available
  initFromParent() {
    console.log('Editor: initFromParent() called');
    
    // FIRST: Check for autocapture screenshots BEFORE doing anything else
    // This must happen before any reset or existing data check
    chrome.storage.local.get(['pendingAutocaptureScreenshots'], (autocaptureResult) => {
      if (autocaptureResult.pendingAutocaptureScreenshots && Array.isArray(autocaptureResult.pendingAutocaptureScreenshots) && autocaptureResult.pendingAutocaptureScreenshots.length > 0) {
        console.log('Editor: Found autocapture screenshots in early check:', autocaptureResult.pendingAutocaptureScreenshots.length);
        // Handle autocapture screenshots - this will reset and load them
        this.handleAutocaptureScreenshots(autocaptureResult.pendingAutocaptureScreenshots);
        return; // Don't continue with normal initialization
      }
      
      // No autocapture screenshots, continue with normal initialization
      this.continueNormalInitFromParent();
    });
  }

  async handleAutocaptureScreenshots(screenshots) {
    console.log('Editor: handleAutocaptureScreenshots called with', screenshots.length, 'screenshots');
    
    // Reset editor state
    this.slides = [];
    this.currentSlideIndex = 0;
    this.drawings = [];
    this.selectedDrawings = [];
    this.selectionRect = null;
    this.image = null;
    this.originalImageData = null;
    this.trueOriginalImageData = null;
    
    // Get callback ID
    chrome.storage.local.get(['pendingEditorCallbackId'], (result) => {
      const callbackId = result.pendingEditorCallbackId || 'autocapture_' + Date.now();
      this.callbackId = callbackId;
      
      // Clear storage
      chrome.storage.local.remove(['pendingAutocaptureScreenshots', 'pendingEditorImageSrc'], async () => {
        console.log('Editor: Cleared autocapture screenshots from storage');
        
        // Load first screenshot
        console.log('Editor: Loading first screenshot');
        await this.loadImage(screenshots[0], true, true);
        console.log('Editor: First screenshot loaded');
        
        // Create slides
        console.log('Editor: Creating slides from screenshots');
        await this.createSlidesFromScreenshots(screenshots);
        console.log('Editor: Slides created');
        
        // Set up save callback
        window.editorSaveCallback = (modifiedImageData, slidesDataFromSave, savedOriginalImageSrc) => {
          console.log('Editor: Autocapture save callback executed');
          chrome.runtime.sendMessage({
            action: 'imageEditorSaved',
            imageData: modifiedImageData,
            originalImageSrc: savedOriginalImageSrc || screenshots[0],
            slidesData: slidesDataFromSave,
            callbackId: callbackId
          }, (saveResponse) => {
            if (chrome.runtime.lastError) {
              console.error('Error sending save message:', chrome.runtime.lastError.message);
            } else {
              console.log('Editor: Save message sent successfully');
            }
          });
        };
      });
    });
  }

  continueNormalInitFromParent() {
    console.log('Editor: continueNormalInitFromParent() called');
    
    // Only reset if we don't already have slides/drawings loaded
    // This prevents clearing drawings that were just loaded
    const hasExistingData = (this.slides && this.slides.length > 0) || (this.drawings && this.drawings.length > 0);
    if (hasExistingData) {
      console.log('Editor: initFromParent() - preserving existing data, slides:', this.slides.length, 'drawings:', this.drawings.length);
      // Don't reset if we already have data
      return;
    }

    // Reset editor state to ensure clean slate for new image
    this.slides = [];
    this.currentSlideIndex = 0;
    this.drawings = [];
    this.selectedDrawings = [];
    this.selectionRect = null;
    this.image = null;
    this.originalImageData = null;
    this.trueOriginalImageData = null; // Reset true original for new image
    this.callbackId = null;

    // Clear the phase comment input
    const commentInput = document.getElementById('editorPhaseComment');
    if (commentInput) {
      commentInput.value = '';
    }

    // Use chrome.storage instead of window.opener (works across origins)
    if (window.chrome && window.chrome.runtime) {
      console.log('Editor: chrome.runtime available, proceeding with storage read');
      // Listen for messages from extension (for direct image loading)
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'loadImage') {
          // Check if this is a goal image - disable zones for goal schemes
          const isGoalImage = request.imageSrc && (request.imageSrc.includes('goal.svg') || request.imageSrc.includes('goal'));
          if (isGoalImage) {
            this.showZoneOverlay = false;
            // Hide the zone overlay button
            const zoneOverlayBtn = document.getElementById('editorZoneOverlayBtn');
            if (zoneOverlayBtn) {
              zoneOverlayBtn.style.display = 'none';
            }
          }
          
          this.open(request.imageSrc, (modifiedImageData) => {
            // Send result back to opener
            chrome.runtime.sendMessage({
              action: 'imageEditorSaved',
              imageData: modifiedImageData,
              originalImageSrc: request.imageSrc,
              callbackId: request.callbackId
            }, (response) => {
              if (chrome.runtime.lastError) {
                console.error('Error sending save message:', chrome.runtime.lastError.message);
              }
            });
          });
          sendResponse({ success: true });
        }
        return true;
      });
      
      // Get image data from chrome.storage (more reliable than message passing)
      // Check for autocapture screenshots FIRST, before loading normal image
      chrome.storage.local.get(['pendingAutocaptureScreenshots', 'pendingEditorImageSrc', 'pendingEditorCallbackId', 'pendingEditorCallbackContext', 'pendingEditorSlidesData', 'pendingEditorOriginalImageSrc'], async (result) => {
        // Check for autocapture screenshots first
        if (result.pendingAutocaptureScreenshots && Array.isArray(result.pendingAutocaptureScreenshots) && result.pendingAutocaptureScreenshots.length > 0) {
          console.log('Editor: Found autocapture screenshots:', result.pendingAutocaptureScreenshots.length);
          const callbackId = result.pendingEditorCallbackId || 'autocapture_' + Date.now();
          // Store callbackId for later use in save()
          this.callbackId = callbackId;
          // Clear the pending screenshots AND image src from storage (to prevent normal loading)
          chrome.storage.local.remove(['pendingAutocaptureScreenshots', 'pendingEditorImageSrc'], async () => {
            // Load first screenshot as background
            await this.loadImage(result.pendingAutocaptureScreenshots[0], true, true);
            // Create slides from screenshots
            await this.createSlidesFromScreenshots(result.pendingAutocaptureScreenshots);
            // Set up save callback
            window.editorSaveCallback = (modifiedImageData, slidesDataFromSave, savedOriginalImageSrc) => {
              console.log('Editor: Autocapture save callback executed, sending save message with callbackId:', callbackId);
              chrome.runtime.sendMessage({
                action: 'imageEditorSaved',
                imageData: modifiedImageData,
                originalImageSrc: savedOriginalImageSrc || result.pendingAutocaptureScreenshots[0],
                slidesData: slidesDataFromSave,
                callbackId: callbackId
              }, (saveResponse) => {
                if (chrome.runtime.lastError) {
                  console.error('Error sending save message:', chrome.runtime.lastError.message);
                } else {
                  console.log('Editor: Save message sent successfully, response:', saveResponse);
                }
              });
            };
          });
          return; // Don't continue with normal loading
        }

        console.log('Editor: initFromParent - storage result:', {
          hasImageSrc: !!result.pendingEditorImageSrc,
          callbackId: result.pendingEditorCallbackId,
          context: result.pendingEditorCallbackContext,
          hasSlidesData: !!result.pendingEditorSlidesData,
          hasOriginalImageSrc: !!result.pendingEditorOriginalImageSrc
        });
        if (result.pendingEditorImageSrc) {
          let imageSrc = result.pendingEditorImageSrc;
          // Handle case where imageSrc might be an object with imageData property
          if (typeof imageSrc === 'object' && imageSrc !== null) {
            imageSrc = imageSrc.imageData || imageSrc;
          }
          // Ensure imageSrc is a string
          if (typeof imageSrc !== 'string') {
            console.error('Editor: imageSrc is not a string:', typeof imageSrc, imageSrc);
            return;
          }
          
          const callbackId = result.pendingEditorCallbackId;
          const slidesData = result.pendingEditorSlidesData; // This will be null for new images
          const originalImageSrc = result.pendingEditorOriginalImageSrc; // Original background image if available
          
          // Check if this is a goal image - disable zones for goal schemes
          const isGoalImage = imageSrc.includes('goal.svg') || imageSrc.includes('goal');
          if (isGoalImage) {
            this.showZoneOverlay = false;
            // Hide the zone overlay button
            const zoneOverlayBtn = document.getElementById('editorZoneOverlayBtn');
            if (zoneOverlayBtn) {
              zoneOverlayBtn.style.display = 'none';
            }
          }
          
          // Store callbackId for later use in save()
          this.callbackId = callbackId;
          console.log('Editor: Stored callbackId:', this.callbackId);
          console.log('Editor: initFromParent - About to call open() with:', {
            imageSrc: imageSrc ? imageSrc.substring(0, 50) + '...' : 'null',
            hasSlidesData: !!slidesData,
            slidesDataLength: slidesData ? slidesData.length : 0,
            hasOriginalImageSrc: !!originalImageSrc
          });

          // Call open() with slidesData and originalImageSrc so drawings can be loaded
          // CRITICAL: Pass slidesData and originalImageSrc as 3rd and 4th parameters
          console.log('Editor: Calling open() with slidesData:', !!slidesData, 'originalImageSrc:', !!originalImageSrc);
          // Pass slidesData and originalImageSrc to open() so drawings can be loaded
          // The open() function signature is: open(imageSrc, saveCallback, slidesData = null, originalImageSrc = null)
          // CRITICAL: Must pass slidesData and originalImageSrc as 3rd and 4th parameters!
          this.open(imageSrc, (modifiedImageData, slidesDataFromSave, savedOriginalImageSrc) => {
            // Send save message with callback ID
            console.log('Editor: open callback executed, sending save message with callbackId:', callbackId);
            chrome.runtime.sendMessage({
              action: 'imageEditorSaved',
              imageData: modifiedImageData,
              originalImageSrc: savedOriginalImageSrc || originalImageSrc || imageSrc,
              slidesData: slidesDataFromSave,
              callbackId: callbackId
            }, (saveResponse) => {
              if (chrome.runtime.lastError) {
                console.error('Error sending save message:', chrome.runtime.lastError.message);
              } else {
                console.log('Editor: Save message sent successfully, response:', saveResponse);
              }
            });
          }, slidesData, originalImageSrc);
        } else {
          console.log('Editor: No pendingEditorImageSrc found in storage');
        }
      });
    }
  }

  openSaveFormationModal(formationName = null) {
    // Check if there are any t-shirt drawings (unless editing)
    if (!formationName) {
      const tshirtDrawings = this.drawings.filter(d => d.type === 'tshirt');
      if (tshirtDrawings.length === 0) {
        const placePlayersText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleasePlacePlayers')
          : 'Please place some players (t-shirts) on the field first.';
        alert(placePlayersText);
        return;
      }
    }

    const modal = document.getElementById('editorSaveFormationModal');
    const nameInput = document.getElementById('editorFormationNameInput');
    const descInput = document.getElementById('editorFormationDescriptionInput');
    const deleteSection = document.getElementById('editorFormationDeleteSection');
    const modalTitle = modal?.querySelector('h3');
    
    if (modal && nameInput && descInput) {
      this.editingFormationName = formationName;
      
      if (formationName) {
        // Editing existing formation
        const editFormationText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.editCustomFormation')
          : 'Edit Custom Formation';
        if (modalTitle) modalTitle.textContent = editFormationText;
        const allFormations = getAllFormations();
        const formation = allFormations[formationName];
        if (formation) {
          nameInput.value = formation.name || '';
          descInput.value = formation.description || '';
          nameInput.disabled = true; // Don't allow renaming
          if (deleteSection) deleteSection.style.display = 'block';
        }
      } else {
        // Creating new formation
        const saveFormationText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.saveCustomFormation')
          : 'Save Custom Formation';
        if (modalTitle) modalTitle.textContent = saveFormationText;
        nameInput.value = '';
        descInput.value = '';
        nameInput.disabled = false;
        if (deleteSection) deleteSection.style.display = 'none';
      }
      
      modal.classList.remove('hidden');
      nameInput.focus();
    }
  }

  closeSaveFormationModal() {
    const modal = document.getElementById('editorSaveFormationModal');
    const nameInput = document.getElementById('editorFormationNameInput');
    const descInput = document.getElementById('editorFormationDescriptionInput');
    if (modal) {
      modal.classList.add('hidden');
    }
    if (nameInput) {
      nameInput.value = '';
      nameInput.disabled = false;
    }
    if (descInput) {
      descInput.value = '';
    }
    this.editingFormationName = null;
  }

  saveCustomFormation() {
    const nameInput = document.getElementById('editorFormationNameInput');
    const descInput = document.getElementById('editorFormationDescriptionInput');
    if (!nameInput || !descInput) return;

    const formationName = nameInput.value.trim();
    if (!formationName) {
      const formationNameText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.enterFormationName')
        : 'Please enter a formation name.';
      showNotification(formationNameText, 'warning');
      return;
    }

    const description = descInput.value.trim() || `Custom formation with ${this.drawings.filter(d => d.type === 'tshirt').length} players`;

    // If editing, use the original name
    const finalFormationName = this.editingFormationName || formationName;
    
    // Get all t-shirt drawings (skip if editing, as we'll use existing positions)
    let positions = [];
    
    if (this.editingFormationName) {
      // Editing: check if there are t-shirts on field to update positions
      const tshirtDrawings = this.drawings.filter(d => d.type === 'tshirt');
      if (tshirtDrawings.length > 0) {
        // User has placed t-shirts, use those positions
        // Use original canvas dimensions for consistent positioning regardless of rotation
        const fieldWidth = this.originalCanvasWidth || this.canvas.width;
        const fieldHeight = this.originalCanvasHeight || this.canvas.height;
        
        positions = tshirtDrawings.map(drawing => {
          const centerX = (drawing.startX + drawing.endX) / 2;
          const centerY = (drawing.startY + drawing.endY) / 2;
          
          const relativeX = (centerX / fieldWidth) * 100;
          const relativeY = (centerY / fieldHeight) * 100;
          
          let role = 'MID';
          const normalizedY = relativeY / 100;
          if (normalizedY > 0.85) {
            role = 'GK';
          } else if (normalizedY > 0.6) {
            role = 'DEF';
          } else if (normalizedY > 0.3) {
            role = 'MID';
          } else {
            role = 'FWD';
          }

          return {
            x: Math.max(0, Math.min(100, relativeX)),
            y: Math.max(0, Math.min(100, relativeY)),
            role: role,
            number: drawing.number || 10
          };
        });
      } else {
        // No t-shirts on field, keep existing positions
        const allFormations = getAllFormations();
        const existingFormation = allFormations[this.editingFormationName];
        if (existingFormation) {
          positions = existingFormation.positions;
        } else {
          showNotification('Formation not found.', 'error');
          return;
        }
      }
    } else {
      // Creating new: extract positions from current t-shirt drawings
      const tshirtDrawings = this.drawings.filter(d => d.type === 'tshirt');
      if (tshirtDrawings.length === 0) {
        const noPlayersText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.noPlayersFoundPlaceTshirts')
          : 'No players found. Please place some t-shirts on the field first.';
        showNotification(noPlayersText, 'warning');
        return;
      }

      // Save exact canvas positions relative to field dimensions
      // This preserves the exact placement when the formation is loaded
      // Use original canvas dimensions for consistent positioning regardless of rotation
      const fieldWidth = this.originalCanvasWidth || this.canvas.width;
      const fieldHeight = this.originalCanvasHeight || this.canvas.height;
      
      // Convert to relative positions (0-100 scale) based on field dimensions
      // This allows the formation to work on different field sizes
      positions = tshirtDrawings.map(drawing => {
      const centerX = (drawing.startX + drawing.endX) / 2;
      const centerY = (drawing.startY + drawing.endY) / 2;
      
      // Save as relative positions (0-100) based on field dimensions
      // x: horizontal position (0 = left, 100 = right)
      // y: vertical position (0 = top, 100 = bottom)
      const relativeX = (centerX / fieldWidth) * 100;
      const relativeY = (centerY / fieldHeight) * 100;
      
      // Determine role based on position
      // For custom formations, we'll try to detect role from position
      // GK is typically at bottom, forwards at top
      let role = 'MID';
      const normalizedY = relativeY / 100;
      if (normalizedY > 0.85) {
        role = 'GK';
      } else if (normalizedY > 0.6) {
        role = 'DEF';
      } else if (normalizedY > 0.3) {
        role = 'MID';
      } else {
        role = 'FWD';
      }

      return {
        x: Math.max(0, Math.min(100, relativeX)),
          y: Math.max(0, Math.min(100, relativeY)),
          role: role,
          number: drawing.number || 10
        };
      });
    }

    // Check if name already exists (only if creating new, not editing)
    if (!this.editingFormationName) {
      const allFormations = getAllFormations();
      if (allFormations[formationName]) {
        showConfirm(
          `A formation named "${formationName}" already exists. Overwrite?`,
          () => {
            this.saveCustomFormationInternal(finalFormationName, description, positions);
          }
        );
        return;
      }
    }

    this.saveCustomFormationInternal(finalFormationName, description, positions);
  }

  saveCustomFormationInternal(finalFormationName, description, positions) {
    // Create formation object with custom flag
    const customFormation = {
      name: finalFormationName,
      description: description,
      positions: positions,
      isCustom: true // Flag to indicate this is a custom formation with exact positions
    };

    // Save to storage
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([CUSTOM_FORMATIONS_KEY], (result) => {
        const existing = result[CUSTOM_FORMATIONS_KEY] || {};
        
        // If editing and name changed, remove old entry
        if (this.editingFormationName && this.editingFormationName !== finalFormationName) {
          delete existing[this.editingFormationName];
        }
        
        existing[finalFormationName] = customFormation;
        customFormations = existing;
        
        chrome.storage.local.set({ [CUSTOM_FORMATIONS_KEY]: existing }, () => {
          updateFormationSelector();
          this.closeSaveFormationModal();
          const action = this.editingFormationName ? 'updated' : 'saved';
          showNotification(`Formation "${finalFormationName}" ${action} successfully!`, 'success');
        });
      });
    } else {
      // Fallback for non-extension context
      if (this.editingFormationName && this.editingFormationName !== finalFormationName) {
        delete customFormations[this.editingFormationName];
      }
      customFormations[finalFormationName] = customFormation;
      updateFormationSelector();
      this.closeSaveFormationModal();
      const action = this.editingFormationName ? 'updated' : 'saved';
      showNotification(`Formation "${finalFormationName}" ${action} successfully!`, 'success');
    }
  }

  deleteCustomFormation() {
    if (!this.editingFormationName) return;
    
    showConfirm(
      (window.i18n && typeof window.i18n.t === 'function'
        ? window.i18n.t('editor.areYouSureDeleteFormation', { formationName: this.editingFormationName })
        : `Are you sure you want to delete the formation "${this.editingFormationName}"?`),
      () => {
        this.performDelete();
      }
    );
  }

  performDelete() {

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([CUSTOM_FORMATIONS_KEY], (result) => {
        const existing = result[CUSTOM_FORMATIONS_KEY] || {};
        delete existing[this.editingFormationName];
        customFormations = existing;
        
        chrome.storage.local.set({ [CUSTOM_FORMATIONS_KEY]: existing }, () => {
          updateFormationSelector();
          this.closeSaveFormationModal();
          
          // Clear current formation if it was the deleted one
          if (this.currentFormation === this.editingFormationName) {
            this.currentFormation = '4-3-3';
            const select = document.getElementById('editorFormationSelect');
            if (select) select.value = '4-3-3';
            this.updateFormationDescription();
          }
          
          const deletedText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('editor.formationDeletedSuccessfully', { formationName: this.editingFormationName })
            : `Formation "${this.editingFormationName}" deleted successfully!`;
          showNotification(deletedText, 'success');
        });
      });
    } else {
      // Fallback for non-extension context
      delete customFormations[this.editingFormationName];
      updateFormationSelector();
      this.closeSaveFormationModal();
      
      if (this.currentFormation === this.editingFormationName) {
        this.currentFormation = '4-3-3';
        const select = document.getElementById('editorFormationSelect');
        if (select) select.value = '4-3-3';
        this.updateFormationDescription();
      }
      
      showNotification(`Formation "${this.editingFormationName}" deleted successfully!`, 'success');
    }
  }

  // ==================== ANIMATION METHODS ====================
  
  // Update linked animation paths when an object moves
  updateLinkedAnimPaths(movedDrawing, deltaX, deltaY) {
    // Find the index of the moved drawing
    const movedIndex = this.drawings.indexOf(movedDrawing);
    if (movedIndex === -1) return;
    
    // Find all animation paths linked to this object
    this.drawings.forEach(drawing => {
      if (drawing.type === 'animpath' && drawing.targetIndex === movedIndex) {
        // Move the start point to follow the object
        drawing.startX += deltaX;
        drawing.startY += deltaY;
      }
    });
  }
  
  // Start adding movement to the currently selected object
  startAddMovement() {
    if (this.selectedDrawings.length === 0) {
      showNotification('Select an object to add movement', 'warning');
      return;
    }
    
    // Find the first ball or t-shirt in the selection
    let targetIndex = null;
    let targetDrawing = null;
    
    for (const idx of this.selectedDrawings) {
      const drawing = this.drawings[idx];
      if (drawing && ['ball', 'tshirt'].includes(drawing.type)) {
        targetIndex = idx;
        targetDrawing = drawing;
        break;
      }
    }
    
    if (!targetDrawing) {
      showNotification('Select a ball or t-shirt to add movement', 'warning');
      return;
    }
    
    // If multiple elements are selected, check if they're all in the same group
    if (this.selectedDrawings.length > 1) {
      const targetGroupId = targetDrawing.groupId;
      const allInSameGroup = this.selectedDrawings.every(idx => {
        const d = this.drawings[idx];
        return d && (d.groupId === targetGroupId || (d.groupId === undefined && targetGroupId === undefined));
      });
      
      if (!allInSameGroup) {
        showNotification('Selected elements must be in the same group to add movement', 'warning');
        return;
      }
    }
    
    // Store the target and switch to animpath tool
    // If the object is in a group, the animation system will handle moving the whole group
    this.pendingMovementTarget = targetIndex;
    this.selectTool('animpath');
    
    // Show the movement hint
    this.showMovementHint();
  }
  
  // Group selected drawings
  groupSelected() {
    if (this.selectedDrawings.length < 2) {
      showNotification('Select at least 2 elements to group', 'warning');
      return;
    }
    
    const groupId = this.nextGroupId++;
    
    // Assign groupId to all selected drawings
    this.selectedDrawings.forEach(index => {
      if (this.drawings[index]) {
        this.drawings[index].groupId = groupId;
      }
    });
    
    this.saveState();
    this.updateSelectionControls();
    this.redraw();
    showNotification(`Grouped ${this.selectedDrawings.length} elements`, 'success');
  }
  
  // Ungroup selected drawings
  ungroupSelected() {
    if (this.selectedDrawings.length === 0) {
      showNotification('Select elements to ungroup', 'warning');
      return;
    }
    
    let ungroupedCount = 0;
    const groupIds = new Set();
    
    // Collect all group IDs from selected drawings
    this.selectedDrawings.forEach(index => {
      if (this.drawings[index] && this.drawings[index].groupId !== undefined) {
        groupIds.add(this.drawings[index].groupId);
      }
    });
    
    if (groupIds.size === 0) {
      showNotification('Selected elements are not grouped', 'warning');
      return;
    }
    
    // Remove groupId from all drawings in the selected groups
    this.drawings.forEach(drawing => {
      if (drawing && drawing.groupId !== undefined && groupIds.has(drawing.groupId)) {
        drawing.groupId = undefined;
        ungroupedCount++;
      }
    });
    
    this.saveState();
    this.updateSelectionControls();
    this.redraw();
    showNotification(`Ungrouped ${ungroupedCount} elements`, 'success');
  }
  
  // Get all drawings in the same group as the given drawing
  getGroupMembers(drawingIndex) {
    const drawing = this.drawings[drawingIndex];
    if (!drawing || drawing.groupId === undefined) {
      return [drawingIndex];
    }
    
    const groupId = drawing.groupId;
    const members = [];
    
    this.drawings.forEach((d, index) => {
      if (d && d.groupId === groupId) {
        members.push(index);
      }
    });
    
    return members;
  }
  
  showMovementHint() {
    const hint = document.getElementById('editorMovementHint');
    if (hint) {
      hint.classList.remove('hidden');
    }
  }
  
  hideMovementHint() {
    const hint = document.getElementById('editorMovementHint');
    if (hint) {
      hint.classList.add('hidden');
    }
  }
  
  // Play animation for all objects with animation paths
  playAnimation() {
    // Collect all animatable objects (objects with linked animation paths and shapes with animations)
    this.animatedObjects = [];
    this.animatedShapes = []; // Array for shape animations
    const processedGroups = new Set(); // Track groups we've already processed
    
    // First, collect shapes with animations
    this.drawings.forEach((drawing, index) => {
      if (drawing.animationType && drawing.animationType !== '') {
        console.log('Found shape with animation:', drawing.type, 'animationType:', drawing.animationType);
        // Store original state for animation
        const bounds = this.getDrawingBoundsForRotation(drawing);
        if (bounds) {
          const originalOpacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
          const originalPosition = {
            startX: drawing.startX,
            startY: drawing.startY,
            endX: drawing.endX,
            endY: drawing.endY
          };
          
          // Longer duration for light animation to be visible
          const duration = drawing.animationType === 'light' ? 2000 : 800;
          
          this.animatedShapes.push({
            drawingIndex: index,
            drawing: drawing,
            animationType: drawing.animationType,
            originalOpacity: originalOpacity,
            originalPosition: originalPosition,
            centerX: (bounds.minX + bounds.maxX) / 2,
            centerY: (bounds.minY + bounds.maxY) / 2,
            width: bounds.maxX - bounds.minX,
            height: bounds.maxY - bounds.minY,
            duration: duration,
            delay: 0,
            startTime: null // Will be set when animation starts
          });
        }
      }
    });
    
    this.drawings.forEach((drawing, index) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
        const targetDrawing = this.drawings[drawing.targetIndex];
        if (targetDrawing && ['ball', 'tshirt'].includes(targetDrawing.type)) {
          // Check if target is in a group
          const groupId = targetDrawing.groupId;
          
          // If this group was already processed, skip
          if (groupId !== undefined && processedGroups.has(groupId)) {
            return;
          }
          
          // Get all group members (or just the target if not grouped)
          const groupMembers = groupId !== undefined 
            ? this.getGroupMembers(drawing.targetIndex)
            : [drawing.targetIndex];
          
          // Store original positions for all group members
          const groupOriginalPositions = {};
          groupMembers.forEach(memberIndex => {
            const member = this.drawings[memberIndex];
            if (member && ['ball', 'tshirt'].includes(member.type)) {
              const width = member.endX - member.startX;
              const height = member.endY - member.startY;
              
              // Calculate center of member
              const centerX = (member.startX + member.endX) / 2;
              const centerY = (member.startY + member.endY) / 2;
              
              // Calculate offset from the target's center
              const targetCenterX = (targetDrawing.startX + targetDrawing.endX) / 2;
              const targetCenterY = (targetDrawing.startY + targetDrawing.endY) / 2;
              
              const offsetX = centerX - targetCenterX;
              const offsetY = centerY - targetCenterY;
              
              // Original position at the start of the animation path
              const originalPosition = {
                startX: drawing.startX - width / 2 + offsetX,
                startY: drawing.startY - height / 2 + offsetY,
                endX: drawing.startX + width / 2 + offsetX,
                endY: drawing.startY + height / 2 + offsetY,
                offsetX: offsetX,
                offsetY: offsetY
              };
              
              groupOriginalPositions[memberIndex] = originalPosition;
              
              // Reset member to start position before animation
              member.startX = originalPosition.startX;
              member.startY = originalPosition.startY;
              member.endX = originalPosition.endX;
              member.endY = originalPosition.endY;
            }
          });
          
          // Mark group as processed
          if (groupId !== undefined) {
            processedGroups.add(groupId);
          }
          
          // Get the target's size for the main animation object
          const width = targetDrawing.endX - targetDrawing.startX;
          const height = targetDrawing.endY - targetDrawing.startY;
          
          const originalPosition = {
            startX: drawing.startX - width / 2,
            startY: drawing.startY - height / 2,
            endX: drawing.startX + width / 2,
            endY: drawing.startY + height / 2
          };
          
          this.animatedObjects.push({
            pathIndex: index,
            targetIndex: drawing.targetIndex,
            path: drawing,
            target: targetDrawing,
            originalPosition: originalPosition,
            groupMembers: groupMembers,
            groupOriginalPositions: groupOriginalPositions,
            duration: (drawing.duration || this.animPathDuration) * 1000,
            delay: (drawing.delay || 0) * 1000,
            easing: drawing.easing || this.animPathEasing
          });
        }
      }
    });
    
    // Initialize shape animations start time
    this.animatedShapes.forEach(shapeAnim => {
      shapeAnim.startTime = performance.now();
    });
    
    if (this.animatedObjects.length === 0 && this.animatedShapes.length === 0) {
      showNotification('No animations to play. Select a shape, choose an animation type (Fade, Scale, Spin, Slide Left/Right, Light) from the style toolbar, then click Play.', 'warning', 5000);
      return;
    }
    
    // Start animation
    this.isAnimating = true;
    this.animationStartTime = performance.now();
    
    // Update UI - hide play button while animating
    const playBtn = document.getElementById('editorPlayBtn');
    const backBtn = document.getElementById('editorBackBtn');
    if (playBtn) playBtn.classList.add('hidden');
    if (backBtn) backBtn.classList.add('hidden');
    
    // Redraw to show objects at start positions
    this.redraw();
    
    this.animateFrame();
  }
  
  // Animation loop
  animateFrame() {
    if (!this.isAnimating) return;
    
    const currentTime = performance.now();
    const elapsed = (currentTime - this.animationStartTime) * this.animationSpeed;
    
    let allComplete = true;
    
    // Process shape animations
    this.animatedShapes.forEach(shapeAnim => {
      const shapeElapsed = (currentTime - shapeAnim.startTime) * this.animationSpeed;
      let progress = (shapeElapsed / shapeAnim.duration) % 1; // Loop for light animation
      
      // For non-looping animations, cap at 1
      if (shapeAnim.animationType !== 'light' && !this.animationLoop) {
        progress = Math.min(progress, 1);
      }
      
      if (progress < 1 || shapeAnim.animationType === 'light') {
        allComplete = false;
      }
      
      // Apply easing (linear for light to maintain constant speed, ease-out for others)
      const easedProgress = shapeAnim.animationType === 'light' 
        ? progress // Linear for smooth continuous movement
        : 1 - Math.pow(1 - progress, 3); // Ease-out for other animations
      
      // Store animation progress in the drawing for rendering
      shapeAnim.drawing._animationProgress = easedProgress;
      shapeAnim.drawing._animationType = shapeAnim.animationType;
    });
    
    // Process path animations (existing code)
    this.animatedObjects.forEach(animObj => {
      // Apply per-path speed multiplier (multiplies global speed)
      const pathSpeed = animObj.speed !== undefined ? animObj.speed : 1.0;
      const effectiveSpeed = this.animationSpeed * pathSpeed;
      const pathAdjustedElapsed = elapsed * effectiveSpeed - animObj.delay;
      
      if (pathAdjustedElapsed < 0) {
        allComplete = false;
        return; // Still waiting for delay
      }
      
      const progress = Math.min(pathAdjustedElapsed / animObj.duration, 1);
      const easedProgress = this.applyEasing(progress, animObj.easing);
      
      if (progress < 1) {
        allComplete = false;
      }
      
      // Calculate position along path
      const pathPoints = this.getPathPoints(animObj.path);
      if (pathPoints.length >= 2) {
        const pos = this.getPositionAlongPath(pathPoints, easedProgress);
        
        // Update target object position
        const target = this.drawings[animObj.targetIndex];
        if (target) {
          const width = animObj.originalPosition.endX - animObj.originalPosition.startX;
          const height = animObj.originalPosition.endY - animObj.originalPosition.startY;
          
          target.startX = pos.x - width / 2;
          target.startY = pos.y - height / 2;
          target.endX = pos.x + width / 2;
          target.endY = pos.y + height / 2;
          
          // If target is in a group, move all group members together
          if (animObj.groupMembers && animObj.groupMembers.length > 1) {
            animObj.groupMembers.forEach(memberIndex => {
              if (memberIndex !== animObj.targetIndex) {
                const member = this.drawings[memberIndex];
                const originalPos = animObj.groupOriginalPositions[memberIndex];
                if (member && originalPos) {
                  // Calculate new position maintaining relative offset
                  const memberWidth = originalPos.endX - originalPos.startX;
                  const memberHeight = originalPos.endY - originalPos.startY;
                  
                  member.startX = pos.x - memberWidth / 2 + originalPos.offsetX;
                  member.startY = pos.y - memberHeight / 2 + originalPos.offsetY;
                  member.endX = pos.x + memberWidth / 2 + originalPos.offsetX;
                  member.endY = pos.y + memberHeight / 2 + originalPos.offsetY;
                }
              }
            });
          }
        }
      }
    });
    
    this.redraw();
    
    if (allComplete) {
      if (this.animationLoop) {
        // Reset positions and restart
        this.animatedObjects.forEach(animObj => {
          const target = this.drawings[animObj.targetIndex];
          if (target) {
            target.startX = animObj.originalPosition.startX;
            target.startY = animObj.originalPosition.startY;
            target.endX = animObj.originalPosition.endX;
            target.endY = animObj.originalPosition.endY;
          }
        });
        // Reset shape animations
        this.animatedShapes.forEach(shapeAnim => {
          shapeAnim.startTime = performance.now();
          shapeAnim.drawing._animationProgress = 0;
        });
        this.animationStartTime = performance.now();
        requestAnimationFrame(() => this.animateFrame());
      } else {
        // Animation complete - stop but keep elements at their end positions
        this.isAnimating = false;
        
        // Mark shape animations as complete (keep final state)
        if (this.animatedShapes) {
          this.animatedShapes.forEach(shapeAnim => {
            const drawing = shapeAnim.drawing;
            if (drawing) {
              drawing._animationProgress = 1; // Keep final state
            }
          });
        }
        
        // Show Back button (to return to original positions)
        const playBtn = document.getElementById('editorPlayBtn');
        const backBtn = document.getElementById('editorBackBtn');
        if (playBtn) playBtn.classList.add('hidden');
        if (backBtn) backBtn.classList.remove('hidden');
        this.redraw();
        
        // Call completion callback if exists (for playAllSlides)
        if (this.animationCompleteCallback) {
          const callback = this.animationCompleteCallback;
          this.animationCompleteCallback = null;
          callback();
        }
      }
    } else {
      requestAnimationFrame(() => this.animateFrame());
    }
  }
  
  // Stop animation (keeps elements at current position)
  stopAnimation() {
    this.isAnimating = false;
    this.animationStartTime = null;
    this.animationPausedTime = null;
    
    // Clear shape animation states (keep final state visible)
    if (this.animatedShapes) {
      this.animatedShapes.forEach(shapeAnim => {
        const drawing = shapeAnim.drawing;
        if (drawing) {
          // Keep final animation state but mark as complete
          drawing._animationProgress = 1;
        }
      });
    }
    
    // Show Back button (to return to original positions)
    const playBtn = document.getElementById('editorPlayBtn');
    const backBtn = document.getElementById('editorBackBtn');
    if (playBtn) playBtn.classList.add('hidden');
    if (backBtn) backBtn.classList.remove('hidden');
    
    this.redraw();
  }
  
  // Reset all animated objects to their original positions
  resetToOriginalPositions() {
    // Stop any running animation first
    this.isAnimating = false;
    
    // Reset all objects to original positions
    this.animatedObjects.forEach(animObj => {
      const target = this.drawings[animObj.targetIndex];
      if (target) {
        target.startX = animObj.originalPosition.startX;
        target.startY = animObj.originalPosition.startY;
        target.endX = animObj.originalPosition.endX;
        target.endY = animObj.originalPosition.endY;
      }
    });
    
    // Reset shape animations
    if (this.animatedShapes) {
      this.animatedShapes.forEach(shapeAnim => {
        const drawing = shapeAnim.drawing;
        if (drawing) {
          // Reset position
          drawing.startX = shapeAnim.originalPosition.startX;
          drawing.startY = shapeAnim.originalPosition.startY;
          drawing.endX = shapeAnim.originalPosition.endX;
          drawing.endY = shapeAnim.originalPosition.endY;
          // Clear animation state
          delete drawing._animationProgress;
          delete drawing._animationType;
        }
      });
      this.animatedShapes = [];
    }
    
    this.animatedObjects = [];
    this.animationStartTime = null;
    this.animationPausedTime = null;
    
    // Show Play button, hide Back button
    const playBtn = document.getElementById('editorPlayBtn');
    const backBtn = document.getElementById('editorBackBtn');
    if (playBtn) playBtn.classList.remove('hidden');
    if (backBtn) backBtn.classList.add('hidden');
    
    this.redraw();
  }
  
  // =====================
  // SLIDES/PHASES SYSTEM
  // =====================
  
  // Toggle slides panel visibility
  toggleSlidesPanel() {
    const panel = document.getElementById('editorSlidesPanel');
    if (panel) {
      panel.classList.toggle('collapsed');
    }
  }
  
  // Toggle phase comment and bench panel visibility
  togglePhaseBenchPanel() {
    const panel = document.getElementById('editorPhaseBenchPanel');
    if (panel) {
      panel.classList.toggle('collapsed');
    }
  }
  
  // Ensure all slides have required fields (for backward compatibility)
  normalizeSlides() {
    this.slides.forEach(slide => {
      if (slide.comment === undefined) {
        slide.comment = '';
      }
      if (slide.backgroundImage === undefined) {
        slide.backgroundImage = null; // Will use default background
      }
    });
  }
  
  // Initialize slides with the first slide
  initializeSlides() {
    console.log('Initializing slides, current drawings:', this.drawings.length);
    // Clear any existing drawings before initializing fresh slides
    // This ensures a clean start when loading a new image
    this.drawings = [];
    this.selectedDrawings = [];
    this.animatedObjects = [];
    
    this.slides = [{
      drawings: [], // Always start with empty drawings for fresh initialization
      thumbnail: null,
      comment: '',
      backgroundImage: null // Will use default background
    }];
    this.currentSlideIndex = 0;
    
    // Ensure slides are normalized
    this.normalizeSlides();
    
    // Update the slides panel UI
    const slidesList = document.getElementById('editorSlidesList');
    if (slidesList) {
      // Clear and rebuild
      this.updateSlidesPanel();
    }
    
    // Initialize comment input
    this.updatePhaseCommentInput();
    this.updateBenchDisplay();
    
    console.log('Slides initialized:', this.slides.length, 'slides');
  }
  
  // Create slides from autocaptured screenshots
  async createSlidesFromScreenshots(screenshots) {
    if (!screenshots || screenshots.length === 0) {
      console.warn('No screenshots provided to createSlidesFromScreenshots');
      return;
    }

    console.log('createSlidesFromScreenshots: Creating', screenshots.length, 'slides');

    // Clear existing slides and start fresh
    this.slides = [];
    this.currentSlideIndex = 0;
    this.drawings = [];
    this.selectedDrawings = [];
    this.animatedObjects = [];

    // Create a slide for each screenshot
    for (let i = 0; i < screenshots.length; i++) {
      const screenshot = screenshots[i];
      
      // Create new slide with screenshot as background
      const newSlide = {
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: [],
        backgroundImage: screenshot
      };

      this.slides.push(newSlide);
      console.log(`createSlidesFromScreenshots: Created slide ${i} with background`);
    }

    // First slide's background is already loaded in initFromParent, just ensure state is correct
    if (this.slides.length > 0) {
      this.currentSlideIndex = 0;
      this.currentLoadedBackground = 0;
      this.drawings = [];
      this.selectedDrawings = [];
      this.animatedObjects = [];
    }

    // Update UI
    this.updateSlidesPanel();
    this.updatePhaseCommentInput();
    this.updateBenchDisplay();
    this.redraw();
    this.saveState();

    console.log(`createSlidesFromScreenshots: Successfully created ${this.slides.length} slides from screenshots`);
  }

  // Add a new slide (phase)
  addSlide() {
    // First, run animation to completion for current slide to get end positions
    // Then create new slide with elements at their end positions
    
    // Save current slide first
    this.saveCurrentSlide();
    
    // Calculate end positions for animated objects
    const newDrawings = JSON.parse(JSON.stringify(this.drawings));
    
    // Find all animation paths and move their linked objects to end positions
    newDrawings.forEach((drawing, index) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
        const target = newDrawings[drawing.targetIndex];
        if (target && ['ball', 'tshirt'].includes(target.type)) {
          // Move target to end of animation path
          const width = target.endX - target.startX;
          const height = target.endY - target.startY;
          
          // Set new position at end of path
          target.startX = drawing.endX - width / 2;
          target.startY = drawing.endY - height / 2;
          target.endX = drawing.endX + width / 2;
          target.endY = drawing.endY + height / 2;
        }
      }
    });
    
    // Remove animation paths from new slide (they were for previous phase)
    const filteredDrawings = newDrawings.filter(d => d.type !== 'animpath');
    
    // Update target indices after removing animation paths
    filteredDrawings.forEach(drawing => {
      if (drawing.targetIndex !== undefined) {
        delete drawing.targetIndex;
      }
    });
    
    // Create new slide
    this.slides.push({
      drawings: filteredDrawings,
      thumbnail: null,
      comment: '',
      benchPlayers: [],
      backgroundImage: null // Will use default background
    });
    
    // Switch to new slide
    this.currentSlideIndex = this.slides.length - 1;
    this.drawings = JSON.parse(JSON.stringify(filteredDrawings));
    this.selectedDrawings = [];
    this.animatedObjects = [];
    
    // Reset animation state - show Play button for new slide
    this.isAnimating = false;
    const playBtn = document.getElementById('editorPlayBtn');
    const backBtn = document.getElementById('editorBackBtn');
    if (playBtn) playBtn.classList.remove('hidden');
    if (backBtn) backBtn.classList.add('hidden');
    
    // Update comment input for new slide
    this.updatePhaseCommentInput();
    this.updateBenchDisplay();
    
    this.saveState();
    
    // Reload SVG elements for the new slide and redraw when done
    this.reloadSvgElements().then(() => {
    this.redraw();
    }).catch(() => {
      this.redraw();
    });
    this.updateSlidesPanel();
  }
  
  // Save current slide's state
  saveCurrentSlide() {
    // Ensure slides array exists and has at least one slide
    if (this.slides.length === 0) {
      this.slides = [{
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: [],
        backgroundImage: null
      }];
      this.currentSlideIndex = 0;
    }
    
    // Ensure current slide exists
    if (!this.slides[this.currentSlideIndex]) {
      this.slides[this.currentSlideIndex] = {
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: [],
        backgroundImage: null
      };
    }
    
    // Create a copy of drawings, ensuring all properties are included
    const drawingsToSave = JSON.parse(JSON.stringify(this.drawings));
    
    console.log('saveCurrentSlide: Current this.drawings.length =', this.drawings.length);
    console.log('saveCurrentSlide: Saving', drawingsToSave.length, 'drawings to slide', this.currentSlideIndex);
    console.log('saveCurrentSlide: Drawing types:', drawingsToSave.map(d => d.type));
    
    // Check spray drawings before and after serialization
    const sprayBefore = this.drawings.filter(d => d.type === 'spray');
    const sprayAfter = drawingsToSave.filter(d => d.type === 'spray');
    console.log('saveCurrentSlide: Spray drawings before serialization:', sprayBefore.length);
    console.log('saveCurrentSlide: Spray drawings after serialization:', sprayAfter.length);
    if (sprayAfter.length > 0) {
      sprayAfter.forEach((sd, idx) => {
        console.log('saveCurrentSlide: Spray', idx, 'has', sd.particles ? sd.particles.length : 0, 'particles after serialization');
        if (sd.particles && sd.particles.length > 0) {
          console.log('saveCurrentSlide: First particle:', sd.particles[0]);
        }
      });
    }
    
    // Reset objects with animation paths to their start positions before saving
    // This ensures slides are always saved with objects at start positions
    drawingsToSave.forEach((drawing, index) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
        const targetIndex = drawing.targetIndex;
        if (targetIndex >= 0 && targetIndex < drawingsToSave.length) {
          const target = drawingsToSave[targetIndex];
          if (target && (['ball', 'tshirt'].includes(target.type) || ['barrier', 'biggoal', 'ladder', 'stick'].includes(target.type))) {
            // Get object size
            const width = target.endX - target.startX;
            const height = target.endY - target.startY;
            
            // Reset object to start position (from animation path's start)
            target.startX = drawing.startX - width / 2;
            target.startY = drawing.startY - height / 2;
            target.endX = drawing.startX + width / 2;
            target.endY = drawing.startY + height / 2;
          }
        }
      }
    });
    
    // Ensure the slide object exists and has all properties
    if (!this.slides[this.currentSlideIndex]) {
      this.slides[this.currentSlideIndex] = {
        drawings: [],
        thumbnail: null,
        comment: '',
        benchPlayers: [],
        backgroundImage: null
      };
    }
    
    // Update drawings
    this.slides[this.currentSlideIndex].drawings = drawingsToSave;
    
    // Save comment
    const commentInput = document.getElementById('editorPhaseComment');
    if (commentInput) {
      this.slides[this.currentSlideIndex].comment = commentInput.value || '';
    }
    
    // Preserve backgroundImage if it exists (don't overwrite it)
    if (this.slides[this.currentSlideIndex].backgroundImage === undefined) {
      this.slides[this.currentSlideIndex].backgroundImage = null;
    }
    
    this.updateSlideThumbnail(this.currentSlideIndex);
    
    console.log('saveCurrentSlide: Saved', this.slides[this.currentSlideIndex].drawings.length, 'drawings');
    console.log('saveCurrentSlide: Slide', this.currentSlideIndex, 'has background:', !!this.slides[this.currentSlideIndex].backgroundImage);
  }
  
  // Switch to a different slide
  switchToSlide(index) {
    if (index < 0 || index >= this.slides.length) return;
    
    // Save current slide first
    this.saveCurrentSlide();
    
    // Switch to new slide
    this.currentSlideIndex = index;
    this.drawings = JSON.parse(JSON.stringify(this.slides[index].drawings));
    this.selectedDrawings = [];
    this.animatedObjects = [];
    
    // Load slide-specific background if available
    const slide = this.slides[index];
    if (slide.backgroundImage) {
      // Check if we're already showing this slide's background by comparing image sources
      const currentImageSrc = this.image && this.image.src ? this.image.src : null;
      const isCorrectBackgroundLoaded = currentImageSrc === slide.backgroundImage && this.currentLoadedBackground === index;
      
      if (isCorrectBackgroundLoaded) {
        // Already showing the correct background, just finish switching
        this.finishSlideSwitch();
      } else {
        // Load the slide's background image (skip initializeSlides, mark as slide-specific)
        this.loadImage(slide.backgroundImage, true, true).then(() => {
          // Track that we've loaded this slide's background
          this.currentLoadedBackground = index;
          // After background loads, continue with slide switch
          this.finishSlideSwitch();
        }).catch(() => {
          // If background load fails, use default and continue
          this.currentLoadedBackground = null;
          this.finishSlideSwitch();
        });
      }
    } else {
      // No slide-specific background, use default
      // Always check if we need to load the default background
      const defaultBackground = this.trueOriginalImageData || this.originalImageData;
      
      // Check if we're already showing the default background
      const currentImageSrc = this.image && this.image.src ? this.image.src : null;
      const isDefaultLoaded = defaultBackground && currentImageSrc === defaultBackground;
      
      if (isDefaultLoaded && this.currentLoadedBackground === 'default') {
        // Already showing default background
        this.finishSlideSwitch();
      } else if (defaultBackground) {
        // Need to load default background (either not loaded or wrong one is loaded)
        this.loadImage(defaultBackground, true, false).then(() => {
          // Track that we've loaded the default background
          this.currentLoadedBackground = 'default';
          this.finishSlideSwitch();
        }).catch(() => {
          this.currentLoadedBackground = null;
          this.finishSlideSwitch();
        });
      } else {
        // No default background available
        this.currentLoadedBackground = null;
        this.finishSlideSwitch();
      }
    }
  }
  
  // Helper method to finish slide switching after background loads
  finishSlideSwitch() {
    // Ensure objects are at their start positions (from animation paths)
    // This is important because slides should always load with objects at start positions
    this.drawings.forEach((drawing) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
        const targetIndex = drawing.targetIndex;
        if (targetIndex >= 0 && targetIndex < this.drawings.length) {
          const target = this.drawings[targetIndex];
          if (target && ['ball', 'tshirt'].includes(target.type)) {
            // Get object size
            const width = target.endX - target.startX;
            const height = target.endY - target.startY;
            
            // Reset object to start position (from animation path's start)
            target.startX = drawing.startX - width / 2;
            target.startY = drawing.startY - height / 2;
            target.endX = drawing.startX + width / 2;
            target.endY = drawing.startY + height / 2;
          }
        }
      }
    });
    
    // Reset animation state
    this.isAnimating = false;
    const playBtn = document.getElementById('editorPlayBtn');
    const backBtn = document.getElementById('editorBackBtn');
    if (playBtn) playBtn.classList.remove('hidden');
    if (backBtn) backBtn.classList.add('hidden');
    
    // Update comment input for the new slide
    this.updatePhaseCommentInput();
    this.updateBenchDisplay();
    
    // Reload SVG elements for the new slide and redraw when done
    this.reloadSvgElements().then(() => {
      this.redraw();
    }).catch(() => {
      this.redraw();
    });
    
    // Also redraw immediately to show non-SVG elements
    this.redraw();
    this.updateSlidesPanel();
  }
  
  // Change background image for a specific slide
  changeSlideBackground(slideIndex) {
    if (slideIndex < 0 || slideIndex >= this.slides.length) return;
    
    // Save current slide first to preserve all data
    this.saveCurrentSlide();
    
    // Ensure the slide exists and has all required properties
    if (!this.slides[slideIndex]) {
      console.error('Slide at index', slideIndex, 'does not exist');
      return;
    }
    
    // Preserve all slide data - get the most up-to-date version
    const slideData = {
      drawings: JSON.parse(JSON.stringify(
        slideIndex === this.currentSlideIndex ? this.drawings : (this.slides[slideIndex].drawings || [])
      )),
      thumbnail: this.slides[slideIndex].thumbnail,
      comment: this.slides[slideIndex].comment || '',
      benchPlayers: JSON.parse(JSON.stringify(this.slides[slideIndex].benchPlayers || [])),
      backgroundImage: this.slides[slideIndex].backgroundImage
    };
    
    console.log('Changing background for slide', slideIndex, 'Current slide:', this.currentSlideIndex);
    console.log('Slide data before change:', {
      hasDrawings: slideData.drawings.length > 0,
      hasComment: !!slideData.comment,
      hasBackground: !!slideData.backgroundImage
    });
    
    // Create file input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    
    input.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target.result;
        
        console.log('Background image loaded, updating slide', slideIndex);
        console.log('All slides BEFORE update:', this.slides.map((s, i) => ({
          index: i,
          hasBackground: !!s.backgroundImage,
          backgroundPreview: s.backgroundImage ? s.backgroundImage.substring(0, 50) + '...' : 'null',
          backgroundIsSame: s.backgroundImage === imageData ? 'SAME (ERROR!)' : 'DIFFERENT'
        })));
        
        // Store the old backgroundImage values for all OTHER slides to ensure they're preserved
        const otherSlidesBackgrounds = this.slides.map((s, i) => 
          i === slideIndex ? null : (s.backgroundImage || null)
        );
        
        // Update ONLY this slide with new background while preserving all other data
        // Make sure we're not affecting other slides by creating a completely new object
        const updatedSlide = {
          drawings: slideData.drawings,
          thumbnail: slideData.thumbnail,
          comment: slideData.comment,
          benchPlayers: slideData.benchPlayers,
          backgroundImage: imageData // This is a NEW data URL string, not a reference
        };
        
        // Update only this specific slide in the array
        this.slides[slideIndex] = updatedSlide;
        
        // Verify that other slides' backgrounds are still preserved
        otherSlidesBackgrounds.forEach((oldBg, i) => {
          if (i !== slideIndex && oldBg !== null) {
            if (this.slides[i].backgroundImage !== oldBg) {
              console.error(`ERROR: Slide ${i} background was changed! Restoring...`);
              this.slides[i].backgroundImage = oldBg;
            }
          } else if (i !== slideIndex && oldBg === null && this.slides[i].backgroundImage !== null) {
            // If slide had no background before, ensure it still has none
            if (this.slides[i].backgroundImage === imageData) {
              console.error(`ERROR: Slide ${i} got the new background! Clearing...`);
              this.slides[i].backgroundImage = null;
            }
          }
        });
        
        console.log('Slide updated with new background. Drawings preserved:', this.slides[slideIndex].drawings.length);
        
        // Log each slide's background status explicitly
        for (let i = 0; i < this.slides.length; i++) {
          const slide = this.slides[i];
          const hasBg = !!slide.backgroundImage;
          const bgSame = slide.backgroundImage === imageData;
          const bgPreview = slide.backgroundImage ? slide.backgroundImage.substring(0, 30) + '...' : 'null';
          console.log(`  Slide ${i}: hasBackground=${hasBg}, isUpdated=${i === slideIndex}, bgSame=${bgSame}, preview=${bgPreview}`);
          
          if (i !== slideIndex && bgSame) {
            console.error(`  ERROR: Slide ${i} has the SAME background as slide ${slideIndex}! This should not happen!`);
          }
        }
        
        console.log('All slides AFTER update:', this.slides.map((s, i) => ({
          index: i,
          hasBackground: !!s.backgroundImage,
          backgroundPreview: s.backgroundImage ? s.backgroundImage.substring(0, 50) + '...' : 'null',
          isUpdated: i === slideIndex ? 'YES' : 'NO',
          backgroundIsSame: s.backgroundImage === imageData ? (i === slideIndex ? 'CORRECT' : 'ERROR - SAME AS SLIDE 0!') : 'DIFFERENT'
        })));
        
        // If this is the current slide, load the new background immediately
        if (slideIndex === this.currentSlideIndex) {
          // Preserve current drawings (they're already in slideData)
          const currentDrawings = JSON.parse(JSON.stringify(this.drawings));
          
          console.log('Loading background for current slide. Current drawings:', currentDrawings.length);
          
          // Load image with skipInitializeSlides=true and isSlideSpecific=true to prevent affecting other slides
          this.loadImage(imageData, true, true).then(() => {
            console.log('Background loaded, restoring drawings');
            // Track that we've loaded this slide's background
            this.currentLoadedBackground = slideIndex;
            // Restore drawings after background loads
            this.drawings = currentDrawings;
            // Ensure the slide's drawings are up to date
            this.slides[slideIndex].drawings = JSON.parse(JSON.stringify(currentDrawings));
            this.redraw();
            // Update the thumbnail for this slide
            this.updateSlideThumbnail(slideIndex);
            this.updateSlidesPanel();
            
            // Before saving, verify all slides still have correct backgrounds
            console.log('Before saveState - verifying backgrounds:');
            for (let i = 0; i < this.slides.length; i++) {
              const slide = this.slides[i];
              const hasBg = !!slide.backgroundImage;
              const bgSame = slide.backgroundImage === imageData;
              console.log(`  Slide ${i}: hasBackground=${hasBg}, bgSame=${bgSame}`);
              if (i !== slideIndex && bgSame) {
                console.error(`  ERROR BEFORE SAVE: Slide ${i} has the SAME background as slide ${slideIndex}!`);
              }
            }
            
            this.saveState();
            
            // After saving, verify backgrounds again
            console.log('After saveState - verifying backgrounds:');
            for (let i = 0; i < this.slides.length; i++) {
              const slide = this.slides[i];
              const hasBg = !!slide.backgroundImage;
              const bgSame = slide.backgroundImage === imageData;
              console.log(`  Slide ${i}: hasBackground=${hasBg}, bgSame=${bgSame}`);
              if (i !== slideIndex && bgSame) {
                console.error(`  ERROR AFTER SAVE: Slide ${i} has the SAME background as slide ${slideIndex}!`);
              }
            }
            
            showNotification('Background changed successfully', 'success');
          }).catch((err) => {
            console.error('Failed to load background image:', err);
            showNotification('Failed to load background image', 'error');
            // Restore drawings even if background load fails
            this.drawings = currentDrawings;
            this.slides[slideIndex].drawings = JSON.parse(JSON.stringify(currentDrawings));
            this.redraw();
            this.updateSlideThumbnail(slideIndex);
          });
        } else {
          // For non-current slides, just update the thumbnail and save
          console.log('Updating thumbnail for non-current slide');
          
          // Before saving, verify all slides still have correct backgrounds
          console.log('Before saveState (non-current) - verifying backgrounds:');
          for (let i = 0; i < this.slides.length; i++) {
            const slide = this.slides[i];
            const hasBg = !!slide.backgroundImage;
            const bgSame = slide.backgroundImage === imageData;
            console.log(`  Slide ${i}: hasBackground=${hasBg}, bgSame=${bgSame}`);
            if (i !== slideIndex && bgSame) {
              console.error(`  ERROR BEFORE SAVE: Slide ${i} has the SAME background as slide ${slideIndex}!`);
            }
          }
          
          this.updateSlideThumbnail(slideIndex);
          this.updateSlidesPanel();
          this.saveState();
          
          // After saving, verify backgrounds again
          console.log('After saveState (non-current) - verifying backgrounds:');
          for (let i = 0; i < this.slides.length; i++) {
            const slide = this.slides[i];
            const hasBg = !!slide.backgroundImage;
            const bgSame = slide.backgroundImage === imageData;
            console.log(`  Slide ${i}: hasBackground=${hasBg}, bgSame=${bgSame}`);
            if (i !== slideIndex && bgSame) {
              console.error(`  ERROR AFTER SAVE: Slide ${i} has the SAME background as slide ${slideIndex}!`);
            }
          }
          
          showNotification('Background changed for slide ' + (slideIndex + 1), 'success');
        }
      };
      
      reader.onerror = () => {
        showNotification('Failed to read image file', 'error');
      };
      
      reader.readAsDataURL(file);
    });
    
    document.body.appendChild(input);
    input.click();
    // Remove input after a delay to ensure file dialog opens
    setTimeout(() => {
      if (input.parentNode) {
        document.body.removeChild(input);
      }
    }, 100);
  }
  
  // Update phase comment input with current slide's comment
  updatePhaseCommentInput() {
    const commentInput = document.getElementById('editorPhaseComment');
    if (commentInput && this.slides[this.currentSlideIndex]) {
      commentInput.value = this.slides[this.currentSlideIndex].comment || '';
    }
  }
  
  // Delete a slide
  deleteSlide(index) {
    if (this.slides.length <= 1) {
      showNotification('Cannot delete the only phase', 'warning');
      return;
    }
    
    this.slides.splice(index, 1);
    
    // Adjust current index if needed
    if (this.currentSlideIndex >= this.slides.length) {
      this.currentSlideIndex = this.slides.length - 1;
    } else if (this.currentSlideIndex > index) {
      this.currentSlideIndex--;
    }
    
    // If we deleted the current slide, load the new current slide
    if (index === this.currentSlideIndex || index < this.currentSlideIndex) {
      this.drawings = JSON.parse(JSON.stringify(this.slides[this.currentSlideIndex].drawings));
      this.selectedDrawings = [];
      this.updatePhaseCommentInput();
      this.updateBenchDisplay();
      // Reload SVG elements and redraw when done
      this.reloadSvgElements().then(() => {
      this.redraw();
      }).catch(() => {
        this.redraw();
      });
    }
    
    this.updateSlidesPanel();
  }
  
  // Update the slides panel UI
  updateSlidesPanel() {
    const slidesList = document.getElementById('editorSlidesList');
    if (!slidesList) {
      console.warn('Slides list element not found');
      return;
    }
    
    console.log('Updating slides panel, slides count:', this.slides.length);
    slidesList.innerHTML = '';
    
    // Store dragged index for use in drop zones
    let draggedIndex = null;
    
    this.slides.forEach((slide, index) => {
      // Create drop zone before this slide (including before first slide)
      const dropZone = document.createElement('div');
      dropZone.className = 'editor-slide-drop-zone';
      dropZone.dataset.insertIndex = index;
      
      dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'move';
        // Highlight this drop zone
        dropZone.classList.add('drag-over');
        // Remove highlight from all other drop zones and slide items
        slidesList.querySelectorAll('.editor-slide-drop-zone, .editor-slide-item').forEach(item => {
          if (item !== dropZone) {
            item.classList.remove('drag-over');
          }
        });
      });
      
      dropZone.addEventListener('dragleave', (e) => {
        // Only remove if we're actually leaving the drop zone (not entering a child)
        if (!dropZone.contains(e.relatedTarget)) {
          dropZone.classList.remove('drag-over');
        }
      });
      
      dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.remove('drag-over');
        
        const draggedIdx = parseInt(e.dataTransfer.getData('text/plain'));
        const insertIdx = index;
        
        // Only reorder if it's actually a different position
        if (draggedIdx !== insertIdx && draggedIdx !== insertIdx - 1) {
          this.reorderSlide(draggedIdx, insertIdx);
        }
      });
      
      slidesList.appendChild(dropZone);
      
      const slideItem = document.createElement('div');
      slideItem.className = 'editor-slide-item' + (index === this.currentSlideIndex ? ' active' : '');
      slideItem.dataset.index = index;
      slideItem.draggable = true; // Enable drag-and-drop
      
      // Create thumbnail canvas
      const thumbCanvas = document.createElement('canvas');
      thumbCanvas.width = 100;
      thumbCanvas.height = 60;
      // Render thumbnail with slide's background and drawings
      this.renderSlideThumbnail(thumbCanvas, slide.drawings || [], slide.backgroundImage);
      slideItem.appendChild(thumbCanvas);
      
      // Slide number
      const number = document.createElement('span');
      number.className = 'editor-slide-item-number';
      number.textContent = (index + 1).toString();
      slideItem.appendChild(number);
      
      // Delete button (only if more than 1 slide)
      if (this.slides.length > 1) {
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'editor-slide-item-delete';
        deleteBtn.innerHTML = '×';
        deleteBtn.title = 'Delete phase';
        deleteBtn.draggable = false; // Prevent button from interfering with drag
        deleteBtn.addEventListener('mousedown', (e) => {
          e.stopPropagation(); // Prevent drag when clicking delete
        });
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          e.preventDefault();
          this.deleteSlide(index);
        });
        slideItem.appendChild(deleteBtn);
      }
      
      // Background change button
      const bgChangeBtn = document.createElement('button');
      bgChangeBtn.className = 'editor-slide-item-bg-change';
      bgChangeBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
      bgChangeBtn.title = 'Change background';
      bgChangeBtn.draggable = false; // Prevent button from interfering with drag
      bgChangeBtn.addEventListener('mousedown', (e) => {
        e.stopPropagation(); // Prevent drag when clicking background button
      });
      bgChangeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.changeSlideBackground(index);
      });
      slideItem.appendChild(bgChangeBtn);
      
      // PNG export button
      const exportPngBtn = document.createElement('button');
      exportPngBtn.className = 'editor-slide-item-export-png';
      exportPngBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';
      exportPngBtn.title = 'Export as PNG';
      exportPngBtn.draggable = false; // Prevent button from interfering with drag
      exportPngBtn.addEventListener('mousedown', (e) => {
        e.stopPropagation(); // Prevent drag when clicking export button
      });
      exportPngBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.exportSlideAsPng(index);
      });
      slideItem.appendChild(exportPngBtn);
      
      // Make canvas non-draggable so it doesn't interfere
      thumbCanvas.draggable = false;
      thumbCanvas.style.pointerEvents = 'none'; // Allow clicks to pass through to slide item
      
      // Drag-and-drop event handlers
      slideItem.addEventListener('dragstart', (e) => {
        // Don't start drag if clicking on buttons
        if (e.target.classList.contains('editor-slide-item-delete') || 
            e.target.classList.contains('editor-slide-item-bg-change') ||
            e.target.classList.contains('editor-slide-item-export-png') ||
            e.target.closest('.editor-slide-item-delete') ||
            e.target.closest('.editor-slide-item-bg-change') ||
            e.target.closest('.editor-slide-item-export-png')) {
          e.preventDefault();
          return;
        }
        
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', index.toString());
        draggedIndex = index;
        slideItem.classList.add('dragging');
      });
      
      slideItem.addEventListener('dragend', (e) => {
        slideItem.classList.remove('dragging');
        draggedIndex = null;
        // Remove drag-over class from all items and drop zones
        slidesList.querySelectorAll('.editor-slide-item, .editor-slide-drop-zone').forEach(item => {
          item.classList.remove('drag-over');
        });
      });
      
      // Allow dropping on slide items too (inserts after the item)
      slideItem.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'move';
        // Show drop zone after this item
        const nextDropZone = slideItem.nextElementSibling;
        if (nextDropZone && nextDropZone.classList.contains('editor-slide-drop-zone')) {
          nextDropZone.classList.add('drag-over');
          // Remove from other drop zones
          slidesList.querySelectorAll('.editor-slide-drop-zone').forEach(zone => {
            if (zone !== nextDropZone) {
              zone.classList.remove('drag-over');
            }
          });
        }
      });
      
      slideItem.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const draggedIdx = parseInt(e.dataTransfer.getData('text/plain'));
        const insertIdx = index + 1; // Insert after this slide
        
        // Only reorder if it's actually a different position
        if (draggedIdx !== insertIdx && draggedIdx !== insertIdx - 1) {
          this.reorderSlide(draggedIdx, insertIdx);
        }
        
        // Clean up
        slidesList.querySelectorAll('.editor-slide-drop-zone').forEach(zone => {
          zone.classList.remove('drag-over');
        });
      });
      
      // Click to switch - use a flag to distinguish from drag
      let hasDragged = false;
      let mouseDownTime = 0;
      let mouseDownPos = null;
      
      slideItem.addEventListener('mousedown', (e) => {
        // Don't handle click if clicking on buttons
        if (e.target.classList.contains('editor-slide-item-delete') || 
            e.target.classList.contains('editor-slide-item-bg-change') ||
            e.target.classList.contains('editor-slide-item-export-png') ||
            e.target.closest('.editor-slide-item-delete') ||
            e.target.closest('.editor-slide-item-bg-change') ||
            e.target.closest('.editor-slide-item-export-png')) {
          return;
        }
        
        hasDragged = false;
        mouseDownTime = Date.now();
        mouseDownPos = { x: e.clientX, y: e.clientY };
      });
      
      slideItem.addEventListener('mousemove', (e) => {
        if (mouseDownPos) {
          // Check if mouse moved significantly (more than 5px)
          const dx = Math.abs(e.clientX - mouseDownPos.x);
          const dy = Math.abs(e.clientY - mouseDownPos.y);
          if (dx > 5 || dy > 5) {
            hasDragged = true;
          }
        }
      });
      
      slideItem.addEventListener('mouseup', (e) => {
        // Don't handle click if clicking on buttons
        if (e.target.classList.contains('editor-slide-item-delete') || 
            e.target.classList.contains('editor-slide-item-bg-change') ||
            e.target.classList.contains('editor-slide-item-export-png') ||
            e.target.closest('.editor-slide-item-delete') ||
            e.target.closest('.editor-slide-item-bg-change') ||
            e.target.closest('.editor-slide-item-export-png')) {
          mouseDownPos = null;
          return;
        }
        
        // If mouse was held down for less than 300ms and didn't drag, treat as click
        const clickDuration = Date.now() - mouseDownTime;
        if (!hasDragged && clickDuration < 300 && mouseDownPos) {
          e.preventDefault();
          e.stopPropagation();
          this.switchToSlide(index);
        }
        
        mouseDownPos = null;
      });
      
      slideItem.addEventListener('dragstart', () => {
        hasDragged = true;
        mouseDownPos = null;
      });
      
      slidesList.appendChild(slideItem);
    });
    
    // Add drop zone at the end
    const endDropZone = document.createElement('div');
    endDropZone.className = 'editor-slide-drop-zone';
    endDropZone.dataset.insertIndex = this.slides.length;
    
    endDropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
      endDropZone.classList.add('drag-over');
      // Remove from other drop zones
      slidesList.querySelectorAll('.editor-slide-drop-zone').forEach(zone => {
        if (zone !== endDropZone) {
          zone.classList.remove('drag-over');
        }
      });
    });
    
    endDropZone.addEventListener('dragleave', (e) => {
      if (!endDropZone.contains(e.relatedTarget)) {
        endDropZone.classList.remove('drag-over');
      }
    });
    
    endDropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      endDropZone.classList.remove('drag-over');
      
      const draggedIdx = parseInt(e.dataTransfer.getData('text/plain'));
      const insertIdx = this.slides.length;
      
      // Only reorder if it's actually a different position
      if (draggedIdx !== insertIdx - 1) {
        this.reorderSlide(draggedIdx, insertIdx);
      }
    });
    
    slidesList.appendChild(endDropZone);
  }
  
  // Helper method to reorder slides
  reorderSlide(draggedIndex, insertIndex) {
    // Save current slide before reordering
    this.saveCurrentSlide();
    
    // Validate indices
    if (draggedIndex < 0 || draggedIndex >= this.slides.length) return;
    if (insertIndex < 0 || insertIndex > this.slides.length) return;
    
    // If dragging to the same position, do nothing
    if (draggedIndex === insertIndex || draggedIndex === insertIndex - 1) return;
    
    // Reorder slides array
    const draggedSlide = this.slides[draggedIndex];
    this.slides.splice(draggedIndex, 1);
    
    // Adjust insert index if dragged item was before insert point
    const adjustedInsertIndex = draggedIndex < insertIndex ? insertIndex - 1 : insertIndex;
    this.slides.splice(adjustedInsertIndex, 0, draggedSlide);
    
    // Update currentSlideIndex to track the moved slide
    if (this.currentSlideIndex === draggedIndex) {
      // The active slide was moved
      this.currentSlideIndex = adjustedInsertIndex;
    } else if (draggedIndex < adjustedInsertIndex) {
      // Slide was moved forward - adjust indices of slides between old and new position
      if (this.currentSlideIndex > draggedIndex && this.currentSlideIndex <= adjustedInsertIndex) {
        this.currentSlideIndex--;
      }
    } else {
      // Slide was moved backward - adjust indices of slides between new and old position
      if (this.currentSlideIndex >= adjustedInsertIndex && this.currentSlideIndex < draggedIndex) {
        this.currentSlideIndex++;
      }
    }
    
    // Update UI
    this.updateSlidesPanel();
    this.saveState();
  }
  
  // Render a thumbnail for a slide
  renderSlideThumbnail(canvas, drawings, backgroundImage = null) {
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Apply rotation transformation for thumbnails
    const applyThumbnailRotation = (imgWidth, imgHeight) => {
      if (!this.canvasRotation || this.canvasRotation === 0) {
        return;
      }
      
      const radians = (this.canvasRotation * Math.PI) / 180;
      
      // Calculate the scale factor for the thumbnail
      let thumbAspect, imgAspect;
      if (this.canvasRotation === 90 || this.canvasRotation === 270) {
        imgAspect = imgHeight / imgWidth; // Swapped for rotated view
      } else {
        imgAspect = imgWidth / imgHeight;
      }
      thumbAspect = canvas.width / canvas.height;
      
      switch (this.canvasRotation) {
        case 90:
          ctx.translate(canvas.width, 0);
          ctx.rotate(radians);
          break;
        case 180:
          ctx.translate(canvas.width, canvas.height);
          ctx.rotate(radians);
          break;
        case 270:
          ctx.translate(0, canvas.height);
          ctx.rotate(radians);
          break;
      }
    };
    
    // Draw background image - use slide-specific background if available
    // If backgroundImage is null/undefined, use the default background (trueOriginalImageData)
    // CRITICAL: Don't use this.image as fallback - it might be a different slide's background!
    let backgroundToUse = null;
    if (backgroundImage) {
      // Slide has its own custom background (data URL string)
      backgroundToUse = backgroundImage;
    } else {
      // Slide uses default background - use trueOriginalImageData
      // Only use this.image if it matches the default background
      const defaultBg = this.trueOriginalImageData || this.originalImageData;
      if (defaultBg && this.image && this.image.src === defaultBg && this.image.complete) {
        backgroundToUse = this.image;
      } else if (defaultBg) {
        backgroundToUse = defaultBg; // Use the data URL string
      }
    }
    
    // Helper to calculate scale and draw drawings after background is ready
    const drawDrawings = (bgWidth, bgHeight) => {
      const scaleX = canvas.width / bgWidth;
      const scaleY = canvas.height / bgHeight;
      const scale = Math.min(scaleX, scaleY); // Use uniform scale
      this.drawThumbnailDrawings(ctx, drawings, scale);
    };
    
    // Helper to draw image with rotation
    const drawImageWithRotation = (img, offsetX, offsetY, drawWidth, drawHeight) => {
      ctx.save();
      
      if (this.canvasRotation && this.canvasRotation !== 0) {
        const radians = (this.canvasRotation * Math.PI) / 180;
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        
        ctx.translate(centerX, centerY);
        ctx.rotate(radians);
        
        // Adjust draw position based on rotation
        if (this.canvasRotation === 90 || this.canvasRotation === 270) {
          // Swap dimensions for 90/270 degree rotations
          const tempWidth = drawWidth;
          drawWidth = drawHeight;
          drawHeight = tempWidth;
          const tempOffset = offsetX;
          offsetX = offsetY;
          offsetY = tempOffset;
        }
        
        ctx.translate(-centerX, -centerY);
      }
      
      ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
      ctx.restore();
    };
    
    if (backgroundToUse) {
      if (typeof backgroundToUse === 'string' && backgroundToUse.startsWith('data:image/')) {
        // It's a data URL string - load it asynchronously
        const img = new Image();
        img.onload = () => {
          try {
            // Draw background scaled to fit thumbnail while maintaining aspect ratio
            // Account for rotation when calculating aspect ratio
            let imgAspect = img.width / img.height;
            if (this.canvasRotation === 90 || this.canvasRotation === 270) {
              imgAspect = img.height / img.width; // Swap for rotated view
            }
            const canvasAspect = canvas.width / canvas.height;
            let drawWidth = canvas.width;
            let drawHeight = canvas.height;
            let offsetX = 0;
            let offsetY = 0;
            
            if (imgAspect > canvasAspect) {
              // Image is wider - fit to width
              drawHeight = canvas.width / imgAspect;
              offsetY = (canvas.height - drawHeight) / 2;
            } else {
              // Image is taller - fit to height
              drawWidth = canvas.height * imgAspect;
              offsetX = (canvas.width - drawWidth) / 2;
            }
            
            drawImageWithRotation(img, offsetX, offsetY, drawWidth, drawHeight);
            // Draw drawings on top with correct scale
            drawDrawings(img.width, img.height);
          } catch (err) {
            console.warn('Failed to draw background in thumbnail:', err);
            ctx.fillStyle = '#1a472a';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
          }
        };
        img.onerror = () => {
          ctx.fillStyle = '#1a472a';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
        };
        img.src = backgroundToUse;
        return; // Exit early, will continue in onload
      } else if (backgroundToUse.complete && backgroundToUse.naturalWidth > 0) {
        // It's an Image object that's already loaded
        try {
          // Draw background scaled to fit thumbnail while maintaining aspect ratio
          // Account for rotation when calculating aspect ratio
          let imgAspect = backgroundToUse.width / backgroundToUse.height;
          if (this.canvasRotation === 90 || this.canvasRotation === 270) {
            imgAspect = backgroundToUse.height / backgroundToUse.width; // Swap for rotated view
          }
          const canvasAspect = canvas.width / canvas.height;
          let drawWidth = canvas.width;
          let drawHeight = canvas.height;
          let offsetX = 0;
          let offsetY = 0;
          
          if (imgAspect > canvasAspect) {
            // Image is wider - fit to width
            drawHeight = canvas.width / imgAspect;
            offsetY = (canvas.height - drawHeight) / 2;
          } else {
            // Image is taller - fit to height
            drawWidth = canvas.height * imgAspect;
            offsetX = (canvas.width - drawWidth) / 2;
          }
          
          drawImageWithRotation(backgroundToUse, offsetX, offsetY, drawWidth, drawHeight);
          drawDrawings(backgroundToUse.width, backgroundToUse.height);
        } catch (err) {
          console.warn('Failed to draw background in thumbnail:', err);
          ctx.fillStyle = '#1a472a';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
        }
      } else {
        // Image not loaded yet, wait for it
        if (backgroundToUse.onload) {
          // Already has a handler, just draw fallback for now
          ctx.fillStyle = '#1a472a';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
        } else {
          backgroundToUse.onload = () => {
            try {
              // Account for rotation when calculating aspect ratio
              let imgAspect = backgroundToUse.width / backgroundToUse.height;
              if (this.canvasRotation === 90 || this.canvasRotation === 270) {
                imgAspect = backgroundToUse.height / backgroundToUse.width; // Swap for rotated view
              }
              const canvasAspect = canvas.width / canvas.height;
              let drawWidth = canvas.width;
              let drawHeight = canvas.height;
              let offsetX = 0;
              let offsetY = 0;
              
              if (imgAspect > canvasAspect) {
                drawHeight = canvas.width / imgAspect;
                offsetY = (canvas.height - drawHeight) / 2;
              } else {
                drawWidth = canvas.height * imgAspect;
                offsetX = (canvas.width - drawWidth) / 2;
              }
              
              drawImageWithRotation(backgroundToUse, offsetX, offsetY, drawWidth, drawHeight);
              drawDrawings(backgroundToUse.width, backgroundToUse.height);
            } catch (err) {
              ctx.fillStyle = '#1a472a';
              ctx.fillRect(0, 0, canvas.width, canvas.height);
              drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
            }
            backgroundToUse.onload = null;
          };
          // Draw fallback while waiting
          ctx.fillStyle = '#1a472a';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
        }
      }
    } else {
      // Fallback to dark green background if no image
      ctx.fillStyle = '#1a472a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      drawDrawings(this.canvas?.width || 800, this.canvas?.height || 600);
    }
  }
  
  // Helper method to draw drawings on thumbnail
  drawThumbnailDrawings(ctx, drawings, scale) {
    if (drawings && drawings.length > 0) {
      // Calculate canvas rotation in radians for element rotation
      const canvasRotationRadians = (this.canvasRotation || 0) * Math.PI / 180;
      
      drawings.forEach(drawing => {
        ctx.save();
        
        // Apply opacity if specified
        if (drawing.opacity !== undefined) {
          ctx.globalAlpha = drawing.opacity;
        }
        
        if (drawing.type === 'tshirt') {
          // Draw t-shirt as a recognizable shape
          const centerX = (drawing.startX + drawing.endX) / 2;
          const centerY = (drawing.startY + drawing.endY) / 2;
          const width = Math.abs(drawing.endX - drawing.startX);
          const height = Math.abs(drawing.endY - drawing.startY);
          const scaledWidth = width * scale;
          const scaledHeight = height * scale;
          
          // Counter-rotate to keep t-shirt upright (cancel canvas rotation)
          const elementRotation = drawing.rotation || 0;
          const totalRotation = elementRotation - canvasRotationRadians;
          if (totalRotation !== 0) {
            ctx.translate(centerX * scale, centerY * scale);
            ctx.rotate(totalRotation);
            ctx.translate(-centerX * scale, -centerY * scale);
          }
          
          ctx.fillStyle = drawing.color || '#ff0000';
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = Math.max(1, 1 * scale);
          
          // Draw simplified t-shirt shape (rounded rectangle with collar)
          ctx.beginPath();
          const x = centerX * scale - scaledWidth / 2;
          const y = centerY * scale - scaledHeight / 2;
          
          // Top with collar cutout
          ctx.moveTo(x, y + scaledHeight * 0.1);
          ctx.lineTo(x + scaledWidth * 0.3, y);
          ctx.lineTo(x + scaledWidth * 0.5, y + scaledHeight * 0.15);
          ctx.lineTo(x + scaledWidth * 0.7, y);
          ctx.lineTo(x + scaledWidth, y + scaledHeight * 0.1);
          
          // Right side
          ctx.lineTo(x + scaledWidth, y + scaledHeight);
          
          // Bottom
          ctx.lineTo(x, y + scaledHeight);
          
          // Left side
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          
          // Draw number if available
          if (drawing.number !== undefined && drawing.number !== null) {
            ctx.fillStyle = drawing.secondColor || '#000000';
            ctx.font = `bold ${Math.max(6, scaledHeight * 0.3)}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(String(drawing.number), centerX * scale, centerY * scale);
          }
          
        } else if (drawing.type === 'ball') {
          // Draw ball as a circle
          const centerX = (drawing.startX + drawing.endX) / 2;
          const centerY = (drawing.startY + drawing.endY) / 2;
          const size = Math.abs(drawing.endX - drawing.startX);
          const radius = (size / 2) * scale;
          
          // Counter-rotate to keep ball upright (cancel canvas rotation)
          const elementRotation = drawing.rotation || 0;
          const totalRotation = elementRotation - canvasRotationRadians;
          if (totalRotation !== 0) {
            ctx.translate(centerX * scale, centerY * scale);
            ctx.rotate(totalRotation);
            ctx.translate(-centerX * scale, -centerY * scale);
          }
          
          ctx.fillStyle = drawing.color || '#ffffff';
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = Math.max(1, 1 * scale);
          
          ctx.beginPath();
          ctx.arc(centerX * scale, centerY * scale, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          
        } else if (drawing.type === 'line') {
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          ctx.setLineDash([]);
          
          ctx.beginPath();
          if (drawing.points && drawing.points.length > 0) {
            ctx.moveTo(drawing.points[0].x * scale, drawing.points[0].y * scale);
            for (let i = 1; i < drawing.points.length; i++) {
              ctx.lineTo(drawing.points[i].x * scale, drawing.points[i].y * scale);
            }
          } else if (drawing.startX !== undefined && drawing.startY !== undefined) {
            ctx.moveTo(drawing.startX * scale, drawing.startY * scale);
            ctx.lineTo(drawing.endX * scale, drawing.endY * scale);
          }
          ctx.stroke();
          
        } else if (drawing.type === 'arrow') {
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.fillStyle = drawing.color || '#ffffff';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          ctx.setLineDash([]);
          
          ctx.beginPath();
          if (drawing.points && drawing.points.length > 0) {
            ctx.moveTo(drawing.points[0].x * scale, drawing.points[0].y * scale);
            for (let i = 1; i < drawing.points.length; i++) {
              ctx.lineTo(drawing.points[i].x * scale, drawing.points[i].y * scale);
            }
          } else if (drawing.startX !== undefined && drawing.startY !== undefined) {
            ctx.moveTo(drawing.startX * scale, drawing.startY * scale);
            ctx.lineTo(drawing.endX * scale, drawing.endY * scale);
          }
          ctx.stroke();
          
          // Draw arrowhead
          if (drawing.endX !== undefined && drawing.endY !== undefined) {
            const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
            const arrowLength = Math.max(4, 6 * scale);
            const arrowWidth = Math.max(2, 3 * scale);
            
            ctx.beginPath();
            ctx.moveTo(drawing.endX * scale, drawing.endY * scale);
            ctx.lineTo(
              drawing.endX * scale - arrowLength * Math.cos(angle - Math.PI / 6),
              drawing.endY * scale - arrowLength * Math.sin(angle - Math.PI / 6)
            );
            ctx.lineTo(
              drawing.endX * scale - arrowLength * Math.cos(angle + Math.PI / 6),
              drawing.endY * scale - arrowLength * Math.sin(angle + Math.PI / 6)
            );
            ctx.closePath();
            ctx.fill();
          }
          
        } else if (drawing.type === 'curve') {
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          ctx.setLineDash([]);
          
          if (drawing.points && drawing.points.length >= 2) {
            ctx.beginPath();
            ctx.moveTo(drawing.points[0].x * scale, drawing.points[0].y * scale);
            
            if (drawing.points.length === 2) {
              // Simple line
              ctx.lineTo(drawing.points[1].x * scale, drawing.points[1].y * scale);
            } else if (drawing.points.length === 3) {
              // Quadratic curve
              ctx.quadraticCurveTo(
                drawing.points[1].x * scale,
                drawing.points[1].y * scale,
                drawing.points[2].x * scale,
                drawing.points[2].y * scale
              );
            } else if (drawing.points.length === 4) {
              // Cubic curve
              ctx.bezierCurveTo(
                drawing.points[1].x * scale,
                drawing.points[1].y * scale,
                drawing.points[2].x * scale,
                drawing.points[2].y * scale,
                drawing.points[3].x * scale,
                drawing.points[3].y * scale
              );
            }
            ctx.stroke();
          }
          
        } else if (drawing.type === 'circle' || drawing.type === 'oval') {
          const centerX = (drawing.startX + drawing.endX) / 2;
          const centerY = (drawing.startY + drawing.endY) / 2;
          const radiusX = Math.abs(drawing.endX - drawing.startX) / 2;
          const radiusY = Math.abs(drawing.endY - drawing.startY) / 2;
          
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.fillStyle = drawing.fillOpacity > 0 ? (drawing.fillColor || drawing.color || '#ffffff') : 'transparent';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          
          if (drawing.type === 'circle') {
            const radius = radiusX * scale;
            ctx.beginPath();
            ctx.arc(centerX * scale, centerY * scale, radius, 0, Math.PI * 2);
            if (drawing.fillOpacity > 0) {
              ctx.globalAlpha = drawing.fillOpacity;
              ctx.fill();
              ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
            }
            ctx.stroke();
          } else {
            ctx.beginPath();
            ctx.ellipse(centerX * scale, centerY * scale, radiusX * scale, radiusY * scale, 0, 0, Math.PI * 2);
            if (drawing.fillOpacity > 0) {
              ctx.globalAlpha = drawing.fillOpacity;
              ctx.fill();
              ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
            }
            ctx.stroke();
          }
          
        } else if (drawing.type === 'rectangle' || drawing.type === 'polygon') {
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.fillStyle = drawing.fillOpacity > 0 ? (drawing.fillColor || drawing.color || '#ffffff') : 'transparent';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          
          if (drawing.points && drawing.points.length > 0) {
            ctx.beginPath();
            ctx.moveTo(drawing.points[0].x * scale, drawing.points[0].y * scale);
            for (let i = 1; i < drawing.points.length; i++) {
              ctx.lineTo(drawing.points[i].x * scale, drawing.points[i].y * scale);
            }
            ctx.closePath();
            if (drawing.fillOpacity > 0) {
              ctx.globalAlpha = drawing.fillOpacity;
              ctx.fill();
              ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
            }
            ctx.stroke();
          } else if (drawing.type === 'rectangle') {
            const x = Math.min(drawing.startX, drawing.endX) * scale;
            const y = Math.min(drawing.startY, drawing.endY) * scale;
            const w = Math.abs(drawing.endX - drawing.startX) * scale;
            const h = Math.abs(drawing.endY - drawing.startY) * scale;
            
            ctx.beginPath();
            ctx.rect(x, y, w, h);
            if (drawing.fillOpacity > 0) {
              ctx.globalAlpha = drawing.fillOpacity;
              ctx.fill();
              ctx.globalAlpha = drawing.opacity !== undefined ? drawing.opacity : 1.0;
            }
            ctx.stroke();
          }
          
        } else if (drawing.type === 'freehand') {
          ctx.strokeStyle = drawing.color || '#ffffff';
          ctx.lineWidth = Math.max(1, (drawing.lineWidth || 2) * scale);
          ctx.setLineDash([]);
          
          if (drawing.points && drawing.points.length > 1) {
            ctx.beginPath();
            ctx.moveTo(drawing.points[0].x * scale, drawing.points[0].y * scale);
            for (let i = 1; i < drawing.points.length; i++) {
              ctx.lineTo(drawing.points[i].x * scale, drawing.points[i].y * scale);
            }
            ctx.stroke();
          }
        } else if (drawing.type === 'spray') {
          ctx.fillStyle = drawing.color || '#ffffff';
          const particleSize = Math.max(1, (drawing.particleSize || 2) * scale);
          
          if (drawing.particles && drawing.particles.length > 0) {
            drawing.particles.forEach(particle => {
              ctx.beginPath();
              ctx.arc(particle.x * scale, particle.y * scale, particleSize, 0, Math.PI * 2);
              ctx.fill();
            });
          }
          
        } else if (drawing.type === 'heatmap') {
          if (drawing.heatGrid && Object.keys(drawing.heatGrid).length > 0) {
            const gridSize = (drawing.gridSize || 4) * scale;
            
            Object.entries(drawing.heatGrid).forEach(([gridKey, intensity]) => {
              const [gridX, gridY] = gridKey.split(',').map(Number);
              const pixelX = gridX * (drawing.gridSize || 4) * scale;
              const pixelY = gridY * (drawing.gridSize || 4) * scale;
              
              // Convert intensity to color using heat scale
              const color = this.intensityToColor(intensity);
              if (!color) return;
              
              // Draw filled rectangle for this grid cell
              ctx.fillStyle = color;
              ctx.fillRect(pixelX, pixelY, gridSize, gridSize);
            });
          }
          
        } else if (drawing.type === 'animpath') {
          ctx.strokeStyle = '#1f6feb';
          ctx.lineWidth = Math.max(1, 1 * scale);
          ctx.setLineDash([3 * scale, 3 * scale]);
          ctx.beginPath();
          ctx.moveTo(drawing.startX * scale, drawing.startY * scale);
          ctx.lineTo(drawing.endX * scale, drawing.endY * scale);
          ctx.stroke();
        }
        
        ctx.restore();
      });
    }
  }
  
  // Update thumbnail for a specific slide
  updateSlideThumbnail(index) {
    const slidesList = document.getElementById('editorSlidesList');
    if (!slidesList) return;
    
    const slideItem = slidesList.querySelector(`[data-index="${index}"]`);
    if (slideItem && this.slides[index]) {
      const thumbCanvas = slideItem.querySelector('canvas');
      if (thumbCanvas) {
        // Render with the slide's specific background
        this.renderSlideThumbnail(thumbCanvas, this.slides[index].drawings, this.slides[index].backgroundImage);
      }
    }
  }
  
  // Play all slides in sequence
  async playAllSlides() {
    if (this.isPlayingAllSlides) return;
    
    this.isPlayingAllSlides = true;
    const originalSlideIndex = this.currentSlideIndex;
    
    // Store original slide data to restore later
    const originalSlides = this.slides.map(s => JSON.parse(JSON.stringify(s)));
    
    // Start from first slide
    for (let i = 0; i < this.slides.length; i++) {
      if (!this.isPlayingAllSlides) break;
      
      this.switchToSlide(i);
      
      // Wait a moment for the slide to load
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // For slides after the first, update objects to start from previous slide's end positions
      if (i > 0) {
        // Get end positions from previous slide (stored before switching)
        const prevEndPositions = this.prevSlideEndPositions || {};
        
        // Update current slide's objects to be at previous slide's end positions
        Object.keys(prevEndPositions).forEach(targetIndexStr => {
          const targetIndex = parseInt(targetIndexStr);
          if (targetIndex < this.drawings.length) {
            const target = this.drawings[targetIndex];
            if (target && ['ball', 'tshirt'].includes(target.type)) {
              const endPos = prevEndPositions[targetIndex];
              target.startX = endPos.startX;
              target.startY = endPos.startY;
              target.endX = endPos.endX;
              target.endY = endPos.endY;
            }
          }
        });
        
        // Update animation paths in current slide to start from these positions
        this.drawings.forEach((drawing) => {
          if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
            const targetIndex = drawing.targetIndex;
            if (prevEndPositions[targetIndex]) {
              const endPos = prevEndPositions[targetIndex];
              // Update path start to match object's current center
              const centerX = (endPos.startX + endPos.endX) / 2;
              const centerY = (endPos.startY + endPos.endY) / 2;
              drawing.startX = centerX;
              drawing.startY = centerY;
            }
          }
        });
      }
      
      // Check if this slide has animations
      const hasAnimations = this.drawings.some(d => 
        d.type === 'animpath' && d.targetIndex !== undefined
      );
      
      if (hasAnimations) {
        // Reset objects to start positions (from animation paths)
        // For first slide: paths start at original positions
        // For subsequent slides: paths start at previous slide's end positions (updated above)
        this.resetAnimatedObjectsToStart();
        this.redraw();
        
        // Brief pause to show starting position
        await new Promise(resolve => setTimeout(resolve, 400));
        
        // Play animation for this slide
        await this.playAnimationAsync();
        
        // Brief pause at end position (show finishing position twice for smooth transition)
        await new Promise(resolve => setTimeout(resolve, 600));
        await new Promise(resolve => setTimeout(resolve, 600));
        
        // Store end positions for next slide
        this.prevSlideEndPositions = {};
        this.drawings.forEach((drawing, index) => {
          if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
            const target = this.drawings[drawing.targetIndex];
            if (target && ['ball', 'tshirt'].includes(target.type)) {
              this.prevSlideEndPositions[drawing.targetIndex] = {
                startX: target.startX,
                startY: target.startY,
                endX: target.endX,
                endY: target.endY
              };
            }
          }
        });
      } else {
        // No animations, just show the slide for a moment
        this.redraw();
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Store current positions for next slide (even without animations)
        this.prevSlideEndPositions = {};
        this.drawings.forEach((drawing, index) => {
          if (['ball', 'tshirt'].includes(drawing.type)) {
            this.prevSlideEndPositions[index] = {
              startX: drawing.startX,
              startY: drawing.startY,
              endX: drawing.endX,
              endY: drawing.endY
            };
          }
        });
      }
    }
    
    // Restore original slide data
    this.slides = originalSlides;
    this.prevSlideEndPositions = null;
    
    this.isPlayingAllSlides = false;
    this.switchToSlide(originalSlideIndex);
  }
  
  // Async version of playAnimation that returns a promise
  playAnimationAsync() {
    return new Promise((resolve) => {
      // Check if there are animation paths
      let hasAnimations = false;
      this.drawings.forEach((drawing) => {
        if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
          hasAnimations = true;
        }
      });
      
      if (!hasAnimations) {
        // No animations, just wait a moment and resolve
        setTimeout(resolve, 500);
        return;
      }
      
      // Store resolve callback
      this.animationCompleteCallback = resolve;
      
      // Start animation
      this.playAnimation();
    });
  }
  
  // Export all slides as GIF animation
  async exportAsGif() {
    if (typeof GIF === 'undefined') {
      showNotification('GIF library not loaded. Please refresh the page.', 'error');
      return;
    }
    
    if (this.slides.length === 0) {
      showNotification('No slides to export', 'warning');
      return;
    }
    
    const exportBtn = document.getElementById('editorExportGifBtn');
    if (exportBtn) {
      exportBtn.disabled = true;
      exportBtn.innerHTML = '<span style="font-size: 11px;">Creating...</span>';
    }
    
    // Get export scale from dropdown (default to 2x if not found)
    const scaleSelect = document.getElementById('editorExportScale');
    const exportScale = scaleSelect ? parseInt(scaleSelect.value, 10) : 2;
    
    const exportWidth = this.canvas.width * exportScale;
    const exportHeight = this.canvas.height * exportScale;
    
    showNotification(`Creating GIF at ${exportScale}x resolution (${exportWidth}×${exportHeight})... This may take a moment.`, 'info');
    
    // Set flag to skip animation paths during export
    this.isExportingGif = true;
    
    // Create a scaled export canvas
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = exportWidth;
    exportCanvas.height = exportHeight;
    const exportCtx = exportCanvas.getContext('2d', { willReadFrequently: true });
    exportCtx.imageSmoothingEnabled = true;
    exportCtx.imageSmoothingQuality = 'high';
    
    // Get worker script path - try chrome extension path first, then fallback to relative
    let workerScript = 'gif.worker.js';
    if (chrome && chrome.runtime && chrome.runtime.getURL) {
      try {
        workerScript = chrome.runtime.getURL('gif.worker.js');
      } catch (e) {
        // Fallback to relative path
        workerScript = 'gif.worker.js';
      }
    }
    
    const gif = new GIF({
      workerScript: workerScript,
      workers: 2,
      quality: 10, // Better quality for higher resolution
      width: exportWidth,
      height: exportHeight,
      repeat: 0 // Loop forever
    });
    
    // Store current slide to restore later
    const originalSlideIndex = this.currentSlideIndex;
    
    try {
      // Process each slide
      for (let slideIndex = 0; slideIndex < this.slides.length; slideIndex++) {
        // Switch to this slide
        this.switchToSlide(slideIndex);
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // Check if this slide has animations
        const hasAnimations = this.drawings.some(d => 
          d.type === 'animpath' && d.targetIndex !== undefined
        );
        
        // Helper function to capture a scaled frame
        const captureScaledFrame = () => {
          exportCtx.clearRect(0, 0, exportWidth, exportHeight);
          exportCtx.drawImage(this.canvas, 0, 0, exportWidth, exportHeight);
          return exportCtx.getImageData(0, 0, exportWidth, exportHeight);
        };
        
        if (hasAnimations) {
          // First, reset all animated objects to their starting positions
          this.resetAnimatedObjectsToStart();
          
          // Capture the starting frame (before animation)
          this.redraw();
          const startFrame = captureScaledFrame();
          gif.addFrame(startFrame, { delay: 500 }); // 500ms pause at start
          
          // Capture frames during animation (with scaling)
          const frames = await this.captureAnimationFrames(exportCanvas, exportCtx, exportScale);
          const frameDelay = Math.round(1000 / 24); // ~42ms per frame for 24fps
          frames.forEach(frame => {
            gif.addFrame(frame, { delay: frameDelay });
          });
          
          // Move all objects to their final positions (end of animation paths)
          this.moveObjectsToEndPositions();
          
          // Ensure redraw happens after position update
          this.redraw();
          
          // Add a pause frame at the end of animation (object at final position)
          const endFrame = captureScaledFrame();
          gif.addFrame(endFrame, { delay: 500 }); // 500ms pause
        } else {
          // No animations, just capture the static slide
          this.redraw();
          const frame = captureScaledFrame();
          gif.addFrame(frame, { delay: 1000 }); // 1 second for static slides
        }
      }
      
      // Render the GIF
      gif.on('finished', (blob) => {
        // Create download link
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `tactical-animation-${Date.now()}.gif`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        // Restore original slide
        this.switchToSlide(originalSlideIndex);
        
        // Re-enable button
        if (exportBtn) {
          exportBtn.disabled = false;
          exportBtn.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            <span style="font-size: 11px; margin-left: 4px;">Export GIF</span>
          `;
        }
        
        showNotification('GIF exported successfully!', 'success');
      });
      
      gif.on('progress', (p) => {
        // Optional: show progress
        console.log('GIF progress:', Math.round(p * 100) + '%');
      });
      
      gif.render();
      
    } catch (error) {
      console.error('Error creating GIF:', error);
      showNotification('Error creating GIF: ' + error.message, 'error');
      // Restore original slide
      this.switchToSlide(originalSlideIndex);
      
      // Re-enable button
      const exportBtn = document.getElementById('editorExportGifBtn');
      if (exportBtn) {
        exportBtn.disabled = false;
        exportBtn.innerHTML = `
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          <span style="font-size: 11px; margin-left: 4px;">Export GIF</span>
        `;
      }
    } finally {
      // Always clear the export flag
      this.isExportingGif = false;
      // Restore original slide
      this.switchToSlide(originalSlideIndex);
      // Redraw to show animation paths again
      this.redraw();
    }
  }
  
  // Export a single slide as PNG
  async exportSlideAsPng(slideIndex) {
    if (slideIndex < 0 || slideIndex >= this.slides.length) {
      showNotification('Invalid slide index', 'error');
      return;
    }
    
    // Get export scale from dropdown (default to 2x if not found)
    const scaleSelect = document.getElementById('editorExportScale');
    const exportScale = scaleSelect ? parseInt(scaleSelect.value, 10) : 2;
    
    const exportWidth = this.canvas.width * exportScale;
    const exportHeight = this.canvas.height * exportScale;
    
    // Store current slide to restore later
    const originalSlideIndex = this.currentSlideIndex;
    
    try {
      // Switch to the slide we want to export
      this.switchToSlide(slideIndex);
      
      // Wait a moment for the slide to fully load and render
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Ensure the canvas is fully rendered
      this.redraw();
      
      // Wait one more frame to ensure everything is drawn
      await new Promise(resolve => requestAnimationFrame(resolve));
      
      // Create a temporary canvas with scaled dimensions
      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = exportWidth;
      exportCanvas.height = exportHeight;
      const exportCtx = exportCanvas.getContext('2d');
      
      // Enable high quality scaling
      exportCtx.imageSmoothingEnabled = true;
      exportCtx.imageSmoothingQuality = 'high';
      
      // Draw the current canvas scaled to the export canvas
      exportCtx.drawImage(this.canvas, 0, 0, exportWidth, exportHeight);
      
      // Convert to blob and download
      exportCanvas.toBlob((blob) => {
        if (!blob) {
          showNotification('Failed to create PNG image', 'error');
          return;
        }
        
        // Create download link
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `slide-${slideIndex + 1}-${exportScale}x.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clean up the URL
        setTimeout(() => URL.revokeObjectURL(url), 100);
        
        showNotification(`Slide ${slideIndex + 1} exported as PNG (${exportWidth}×${exportHeight})`, 'success');
      }, 'image/png');
      
    } catch (error) {
      console.error('Error exporting slide as PNG:', error);
      showNotification('Error exporting slide: ' + error.message, 'error');
    } finally {
      // Restore original slide
      if (originalSlideIndex !== slideIndex) {
        this.switchToSlide(originalSlideIndex);
      }
    }
  }
  
  // Move all animated objects to their end positions (at the end of animation paths)
  moveObjectsToEndPositions() {
    this.animatedObjects.forEach(animObj => {
      const target = this.drawings[animObj.targetIndex];
      if (target && animObj.path) {
        // Get the object's size from original position
        const width = animObj.originalPosition.endX - animObj.originalPosition.startX;
        const height = animObj.originalPosition.endY - animObj.originalPosition.startY;
        
        // Move to the end of the animation path (use path.endX, path.endY directly)
        target.startX = animObj.path.endX - width / 2;
        target.startY = animObj.path.endY - height / 2;
        target.endX = animObj.path.endX + width / 2;
        target.endY = animObj.path.endY + height / 2;
        
        // If target is in a group, move all group members to end position
        if (animObj.groupMembers && animObj.groupMembers.length > 1) {
          animObj.groupMembers.forEach(memberIndex => {
            if (memberIndex !== animObj.targetIndex) {
              const member = this.drawings[memberIndex];
              const originalPos = animObj.groupOriginalPositions[memberIndex];
              if (member && originalPos) {
                const memberWidth = originalPos.endX - originalPos.startX;
                const memberHeight = originalPos.endY - originalPos.startY;
                
                member.startX = animObj.path.endX - memberWidth / 2 + originalPos.offsetX;
                member.startY = animObj.path.endY - memberHeight / 2 + originalPos.offsetY;
                member.endX = animObj.path.endX + memberWidth / 2 + originalPos.offsetX;
                member.endY = animObj.path.endY + memberHeight / 2 + originalPos.offsetY;
              }
            }
          });
        }
      }
    });
  }
  
  // Reset all animated objects to their starting positions
  resetAnimatedObjectsToStart() {
    // Collect all animatable objects first (same logic as playAnimation)
    this.animatedObjects = [];
    const processedGroups = new Set(); // Track groups we've already processed
    
    this.drawings.forEach((drawing, index) => {
      if (drawing.type === 'animpath' && drawing.targetIndex !== undefined) {
        const targetDrawing = this.drawings[drawing.targetIndex];
        if (targetDrawing && ['ball', 'tshirt'].includes(targetDrawing.type)) {
          // Check if target is in a group
          const groupId = targetDrawing.groupId;
          
          // If this group was already processed, skip
          if (groupId !== undefined && processedGroups.has(groupId)) {
            return;
          }
          
          // Get all group members (or just the target if not grouped)
          const groupMembers = groupId !== undefined 
            ? this.getGroupMembers(drawing.targetIndex)
            : [drawing.targetIndex];
          
          // Store original positions for all group members
          const groupOriginalPositions = {};
          groupMembers.forEach(memberIndex => {
            const member = this.drawings[memberIndex];
            if (member && ['ball', 'tshirt'].includes(member.type)) {
              const width = member.endX - member.startX;
              const height = member.endY - member.startY;
              
              // Calculate center of member
              const centerX = (member.startX + member.endX) / 2;
              const centerY = (member.startY + member.endY) / 2;
              
              // Calculate offset from the target's center
              const targetCenterX = (targetDrawing.startX + targetDrawing.endX) / 2;
              const targetCenterY = (targetDrawing.startY + targetDrawing.endY) / 2;
              
              const offsetX = centerX - targetCenterX;
              const offsetY = centerY - targetCenterY;
              
              // Original position at the start of the animation path
              const originalPosition = {
                startX: drawing.startX - width / 2 + offsetX,
                startY: drawing.startY - height / 2 + offsetY,
                endX: drawing.startX + width / 2 + offsetX,
                endY: drawing.startY + height / 2 + offsetY,
                offsetX: offsetX,
                offsetY: offsetY
              };
              
              groupOriginalPositions[memberIndex] = originalPosition;
              
              // Reset member to start position before animation
              member.startX = originalPosition.startX;
              member.startY = originalPosition.startY;
              member.endX = originalPosition.endX;
              member.endY = originalPosition.endY;
            }
          });
          
          // Mark group as processed
          if (groupId !== undefined) {
            processedGroups.add(groupId);
          }
          
          // Get the target's size for the main animation object
          const width = targetDrawing.endX - targetDrawing.startX;
          const height = targetDrawing.endY - targetDrawing.startY;
          
          const originalPosition = {
            startX: drawing.startX - width / 2,
            startY: drawing.startY - height / 2,
            endX: drawing.startX + width / 2,
            endY: drawing.startY + height / 2
          };
          
          this.animatedObjects.push({
            pathIndex: index,
            targetIndex: drawing.targetIndex,
            path: drawing,
            target: targetDrawing,
            originalPosition: originalPosition,
            groupMembers: groupMembers,
            groupOriginalPositions: groupOriginalPositions,
            duration: (drawing.duration || this.animPathDuration) * 1000,
            delay: (drawing.delay || 0) * 1000,
            easing: drawing.easing || this.animPathEasing
          });
        }
      }
    });
    
    // Reset shape animations to start state
    if (this.animatedShapes) {
      this.animatedShapes.forEach(shapeAnim => {
        const drawing = shapeAnim.drawing;
        if (drawing) {
          // Reset position
          drawing.startX = shapeAnim.originalPosition.startX;
          drawing.startY = shapeAnim.originalPosition.startY;
          drawing.endX = shapeAnim.originalPosition.endX;
          drawing.endY = shapeAnim.originalPosition.endY;
          // Clear animation state
          delete drawing._animationProgress;
          delete drawing._animationType;
        }
      });
    }
  }
  
  // Capture frames during animation
  // Optional exportCanvas and exportCtx for scaled export
  async captureAnimationFrames(exportCanvas = null, exportCtx = null, exportScale = 1) {
    return new Promise((resolve) => {
      const frames = [];
      const fps = 24; // 24fps for smooth but lightweight animation
      const frameInterval = 1000 / fps; // ~41.67ms per frame
      const maxFrames = 300; // Max ~12.5 seconds at 24fps
      
      // Determine if we're doing scaled export
      const useScaledExport = exportCanvas && exportCtx && exportScale > 1;
      const exportWidth = useScaledExport ? exportCanvas.width : this.canvas.width;
      const exportHeight = useScaledExport ? exportCanvas.height : this.canvas.height;
      
      // Find the maximum animation duration
      let maxDuration = 0;
      this.animatedObjects.forEach(animObj => {
        const totalTime = animObj.delay + animObj.duration;
        if (totalTime > maxDuration) {
          maxDuration = totalTime;
        }
      });
      
      // Calculate total number of frames needed (maxDuration is in ms, frameInterval is in ms)
      const totalFrames = Math.ceil(maxDuration / frameInterval);
      
      // Reset animation - also reset group members
      this.animatedObjects.forEach(animObj => {
        const target = this.drawings[animObj.targetIndex];
        if (target) {
          target.startX = animObj.originalPosition.startX;
          target.startY = animObj.originalPosition.startY;
          target.endX = animObj.originalPosition.endX;
          target.endY = animObj.originalPosition.endY;
        }
        
        // Reset group members if target is in a group
        if (animObj.groupMembers && animObj.groupMembers.length > 1) {
          animObj.groupMembers.forEach(memberIndex => {
            if (memberIndex !== animObj.targetIndex) {
              const member = this.drawings[memberIndex];
              const originalPos = animObj.groupOriginalPositions[memberIndex];
              if (member && originalPos) {
                member.startX = originalPos.startX;
                member.startY = originalPos.startY;
                member.endX = originalPos.endX;
                member.endY = originalPos.endY;
              }
            }
          });
        }
      });
      
      // Track milestone frames we've captured (25%, 50%, 75%) to avoid duplicates
      const milestoneFrames = new Set();
      
      // Calculate milestone times for each animation
      const milestones = [0.25, 0.5, 0.75]; // 25%, 50%, 75%
      this.animatedObjects.forEach(animObj => {
        milestones.forEach(milestone => {
          const milestoneTime = animObj.delay + (animObj.duration * milestone);
          const milestoneFrame = Math.round((milestoneTime * 1000) / frameInterval);
          milestoneFrames.add(milestoneFrame);
        });
      });
      
      // Helper function to update object positions based on elapsed time
      const updateObjectPositions = (elapsed) => {
        this.animatedObjects.forEach(animObj => {
          const adjustedElapsed = elapsed - animObj.delay;
          
          if (adjustedElapsed < 0) {
            // Animation hasn't started yet, keep at original position
            return;
          }
          
          const progress = Math.min(adjustedElapsed / animObj.duration, 1);
          const easedProgress = this.applyEasing(progress, animObj.easing);
          
          const pathPoints = this.getPathPoints(animObj.path);
          if (pathPoints.length >= 2) {
            const pos = this.getPositionAlongPath(pathPoints, easedProgress);
            const target = this.drawings[animObj.targetIndex];
            if (target) {
              const width = animObj.originalPosition.endX - animObj.originalPosition.startX;
              const height = animObj.originalPosition.endY - animObj.originalPosition.startY;
              
              target.startX = pos.x - width / 2;
              target.startY = pos.y - height / 2;
              target.endX = pos.x + width / 2;
              target.endY = pos.y + height / 2;
              
              // If target is in a group, move all group members together
              if (animObj.groupMembers && animObj.groupMembers.length > 1) {
                animObj.groupMembers.forEach(memberIndex => {
                  if (memberIndex !== animObj.targetIndex) {
                    const member = this.drawings[memberIndex];
                    const originalPos = animObj.groupOriginalPositions[memberIndex];
                    if (member && originalPos) {
                      // Calculate new position maintaining relative offset
                      const memberWidth = originalPos.endX - originalPos.startX;
                      const memberHeight = originalPos.endY - originalPos.startY;
                      
                      member.startX = pos.x - memberWidth / 2 + originalPos.offsetX;
                      member.startY = pos.y - memberHeight / 2 + originalPos.offsetY;
                      member.endX = pos.x + memberWidth / 2 + originalPos.offsetX;
                      member.endY = pos.y + memberHeight / 2 + originalPos.offsetY;
                    }
                  }
                });
              }
            }
          }
        });
      };
      
      // Capture all frames synchronously for smooth animation
      // Use a loop instead of setTimeout for more reliable frame capture
      for (let frameIndex = 0; frameIndex < totalFrames && frameIndex < maxFrames; frameIndex++) {
        // Calculate elapsed time for this frame (in milliseconds, matching animObj.duration)
        const elapsed = frameIndex * frameInterval; // Keep in milliseconds
        
        // Update object positions
        updateObjectPositions(elapsed);
        
        // Capture frame (with optional scaling)
        this.redraw();
        
        let frame;
        if (useScaledExport) {
          // Draw main canvas scaled to export canvas
          exportCtx.clearRect(0, 0, exportWidth, exportHeight);
          exportCtx.drawImage(this.canvas, 0, 0, exportWidth, exportHeight);
          frame = exportCtx.getImageData(0, 0, exportWidth, exportHeight);
        } else {
          frame = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        }
        frames.push(frame);
      }
      
      // Resolve with all captured frames
          resolve(frames);
    });
  }
  
  // Apply easing function
  applyEasing(t, easing) {
    switch (easing) {
      case 'linear':
        return t;
      case 'easeIn':
        return t * t;
      case 'easeOut':
        return 1 - (1 - t) * (1 - t);
      case 'easeInOut':
        return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      default:
        return t;
    }
  }
  
  // Get points along the animation path
  getPathPoints(path) {
    const points = [];
    
    if (path.type === 'animpath') {
      // Start point
      points.push({ x: path.startX, y: path.startY });
      
      // Add waypoints if they exist
      if (path.waypoints && path.waypoints.length > 0) {
        path.waypoints.forEach(waypoint => {
          points.push({ x: waypoint.x, y: waypoint.y });
        });
      }
      
      // End point
      points.push({ x: path.endX, y: path.endY });
    }
    
    return points;
  }
  
  // Get point on bezier curve at parameter t
  getPointOnBezier(path, t) {
    const x0 = path.startX;
    const y0 = path.startY;
    const x2 = path.endX;
    const y2 = path.endY;
    
    if (path.controlPoint) {
      // Quadratic bezier
      const cx = path.controlPoint.x;
      const cy = path.controlPoint.y;
      
      const x = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x2;
      const y = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y2;
      
      return { x, y };
    } else if (path.controlPoints && path.controlPoints.length >= 2) {
      // Cubic bezier
      const cx1 = path.controlPoints[0].x;
      const cy1 = path.controlPoints[0].y;
      const cx2 = path.controlPoints[1].x;
      const cy2 = path.controlPoints[1].y;
      
      const x = Math.pow(1 - t, 3) * x0 + 3 * Math.pow(1 - t, 2) * t * cx1 + 3 * (1 - t) * t * t * cx2 + Math.pow(t, 3) * x2;
      const y = Math.pow(1 - t, 3) * y0 + 3 * Math.pow(1 - t, 2) * t * cy1 + 3 * (1 - t) * t * t * cy2 + Math.pow(t, 3) * y2;
      
      return { x, y };
    }
    
    // Fallback: linear interpolation
    return {
      x: x0 + (x2 - x0) * t,
      y: y0 + (y2 - y0) * t
    };
  }
  
  // Calculate Catmull-Rom spline point
  getCatmullRomPoint(p0, p1, p2, p3, t) {
    const t2 = t * t;
    const t3 = t2 * t;
    
    return {
      x: 0.5 * ((2 * p1.x) +
                (-p0.x + p2.x) * t +
                (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 +
                (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
      y: 0.5 * ((2 * p1.y) +
                (-p0.y + p2.y) * t +
                (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 +
                (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3)
    };
  }
  
  // Get point on spline segment with arc-length parameterization
  getSplineSegmentPoint(points, segmentIndex, t) {
    // Need at least 2 points for a segment
    if (points.length < 2) return points[0] || { x: 0, y: 0 };
    
    // If only 2 points, use linear interpolation
    if (points.length === 2) {
      return {
        x: points[0].x + (points[1].x - points[0].x) * t,
        y: points[0].y + (points[1].y - points[0].y) * t
      };
    }
    
    // For Catmull-Rom, we need 4 points: p0, p1, p2, p3
    // p1 and p2 are the segment endpoints
    let p0, p1, p2, p3;
    
    if (segmentIndex === 0) {
      // First segment: duplicate first point for p0
      p0 = points[0];
      p1 = points[0];
      p2 = points[1];
      p3 = points.length > 2 ? points[2] : points[1];
    } else if (segmentIndex === points.length - 2) {
      // Last segment: duplicate last point for p3
      p0 = points[segmentIndex - 1];
      p1 = points[segmentIndex];
      p2 = points[segmentIndex + 1];
      p3 = points[segmentIndex + 1];
    } else {
      // Middle segments
      p0 = points[segmentIndex - 1];
      p1 = points[segmentIndex];
      p2 = points[segmentIndex + 1];
      p3 = points[segmentIndex + 2];
    }
    
    return this.getCatmullRomPoint(p0, p1, p2, p3, t);
  }
  
  // Calculate arc length of a spline segment (approximation using sampling)
  getSplineSegmentLength(points, segmentIndex, samples = 20) {
    let length = 0;
    let prevPoint = this.getSplineSegmentPoint(points, segmentIndex, 0);
    
    for (let i = 1; i <= samples; i++) {
      const t = i / samples;
      const currentPoint = this.getSplineSegmentPoint(points, segmentIndex, t);
      const dx = currentPoint.x - prevPoint.x;
      const dy = currentPoint.y - prevPoint.y;
      length += Math.sqrt(dx * dx + dy * dy);
      prevPoint = currentPoint;
    }
    
    return length;
  }
  
  // Get position along a path given progress (0-1) using smooth splines
  getPositionAlongPath(points, progress) {
    if (points.length < 2) return points[0] || { x: 0, y: 0 };
    
    // If only 2 points, use linear interpolation (no waypoints)
    if (points.length === 2) {
      return {
        x: points[0].x + (points[1].x - points[0].x) * progress,
        y: points[0].y + (points[1].y - points[0].y) * progress
      };
    }
    
    // Calculate total path length using arc-length parameterization
    let totalLength = 0;
    const segmentLengths = [];
    
    // Calculate length of each spline segment
    for (let i = 0; i < points.length - 1; i++) {
      const length = this.getSplineSegmentLength(points, i);
      segmentLengths.push(length);
      totalLength += length;
    }
    
    if (totalLength === 0) return points[0];
    
    // Find position at progress using arc-length parameterization
    const targetLength = totalLength * progress;
    let currentLength = 0;
    
    for (let i = 0; i < segmentLengths.length; i++) {
      const segmentLength = segmentLengths[i];
      
      if (currentLength + segmentLength >= targetLength) {
        // We're in this segment
        const segmentProgress = (targetLength - currentLength) / segmentLength;
        return this.getSplineSegmentPoint(points, i, segmentProgress);
      }
      
      currentLength += segmentLength;
    }
    
    // Fallback to last point
    return points[points.length - 1];
  }
  
  // Update selected animation path property
  updateSelectedAnimPath(property, value) {
    // Update instance variables so new paths use these values
    if (property === 'duration') {
      this.animPathDuration = value;
    } else if (property === 'delay') {
      this.animPathDelay = value;
    } else if (property === 'easing') {
      this.animPathEasing = value;
    }
    
    // Update selected drawings if any are selected
    if (this.selectedDrawings.length > 0) {
      this.selectedDrawings.forEach(index => {
        const drawing = this.drawings[index];
        if (drawing && drawing.type === 'animpath') {
          drawing[property] = value;
        }
      });
      this.saveState();
    }
  }
  
}

// Update formation selector with custom formations
function updateFormationSelector() {
  const select = document.getElementById('editorFormationSelect');
  if (!select) return;

  // Remove existing custom formations optgroup
  const existingCustomGroup = select.querySelector('optgroup[label="Custom Formations"]');
  if (existingCustomGroup) {
    existingCustomGroup.remove();
  }

  // Add custom formations if any exist
  const customKeys = Object.keys(customFormations);
  if (customKeys.length > 0) {
    const customGroup = document.createElement('optgroup');
    customGroup.label = 'Custom Formations';
    
    customKeys.sort().forEach(key => {
      const option = document.createElement('option');
      option.value = key;
      option.textContent = customFormations[key].name;
      option.dataset.isCustom = 'true';
      customGroup.appendChild(option);
    });
    
    select.appendChild(customGroup);
    
    // Add edit/delete buttons for custom formations
    // We'll add them as a separate UI element near the selector
    addCustomFormationControls();
  } else {
    // Remove controls if no custom formations
    removeCustomFormationControls();
  }
}

// Add edit/delete controls for custom formations
function addCustomFormationControls() {
  const select = document.getElementById('editorFormationSelect');
  if (!select) return;
  
  // Check if controls already exist
  let controlsContainer = document.getElementById('editorCustomFormationControls');
  if (!controlsContainer) {
    controlsContainer = document.createElement('div');
    controlsContainer.id = 'editorCustomFormationControls';
    controlsContainer.style.display = 'flex';
    controlsContainer.style.gap = '8px';
    controlsContainer.style.marginTop = '8px';
    
    const editBtn = document.createElement('button');
    editBtn.id = 'editorEditFormationBtn';
    editBtn.className = 'editor-save-btn';
    editBtn.style.padding = '6px 12px';
    editBtn.style.fontSize = '12px';
    const editText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('common.edit')
      : 'Edit';
    const editFormationTitleText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.editSelectedCustomFormation')
      : 'Edit selected custom formation';
    editBtn.textContent = editText;
    editBtn.title = editFormationTitleText;
    
    const deleteBtn = document.createElement('button');
    deleteBtn.id = 'editorDeleteFormationFromListBtn';
    deleteBtn.className = 'editor-cancel-btn';
    deleteBtn.style.padding = '6px 12px';
    deleteBtn.style.fontSize = '12px';
    const deleteText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('common.delete')
      : 'Delete';
    const deleteFormationTitleText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('editor.deleteSelectedCustomFormation')
      : 'Delete selected custom formation';
    deleteBtn.textContent = deleteText;
    deleteBtn.title = deleteFormationTitleText;
    
    controlsContainer.appendChild(editBtn);
    controlsContainer.appendChild(deleteBtn);
    
    // Insert after the select
    const selectRow = select.closest('.editor-fill-row');
    if (selectRow) {
      selectRow.appendChild(controlsContainer);
    }
    
    // Add event listeners
    editBtn.addEventListener('click', () => {
      const selectedValue = select.value;
      if (selectedValue && customFormations[selectedValue]) {
        if (window.tacticalEditor) {
          window.tacticalEditor.openSaveFormationModal(selectedValue);
        }
      } else {
        const selectFormationText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleaseSelectCustomFormationToEdit')
          : 'Please select a custom formation to edit.';
        alert(selectFormationText);
      }
    });
    
    deleteBtn.addEventListener('click', () => {
      const selectedValue = select.value;
      if (selectedValue && customFormations[selectedValue]) {
        showConfirm(
          (window.i18n && typeof window.i18n.t === 'function'
            ? window.i18n.t('editor.areYouSureDeleteFormation', { formationName: selectedValue })
            : `Are you sure you want to delete the formation "${selectedValue}"?`),
          () => {
            if (window.tacticalEditor) {
              window.tacticalEditor.editingFormationName = selectedValue;
              window.tacticalEditor.deleteCustomFormation();
            }
          }
        );
      } else {
        const selectFormationDeleteText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.pleaseSelectCustomFormationToDelete')
          : 'Please select a custom formation to delete.';
        showNotification(selectFormationDeleteText, 'warning');
      }
    });
    
    // Update button states based on selection
    select.addEventListener('change', () => {
      const selectedValue = select.value;
      const isCustom = selectedValue && customFormations[selectedValue];
      editBtn.style.display = isCustom ? 'block' : 'none';
      deleteBtn.style.display = isCustom ? 'block' : 'none';
    });
    
    // Initial state
    const selectedValue = select.value;
    const isCustom = selectedValue && customFormations[selectedValue];
    editBtn.style.display = isCustom ? 'block' : 'none';
    deleteBtn.style.display = isCustom ? 'block' : 'none';
  }
}

// Remove custom formation controls
function removeCustomFormationControls() {
  const controlsContainer = document.getElementById('editorCustomFormationControls');
  if (controlsContainer) {
    controlsContainer.remove();
  }
}

// Helper functions for team data structure (backward compatibility)
function getTeamName(team) {
  return typeof team === 'string' ? team : (team?.name || team);
}

function getTeamObject(teamName, teams) {
  if (!teams || !Array.isArray(teams)) return null;
  return teams.find(t => getTeamName(t) === teamName) || null;
}

function ensureTeamObject(team) {
  if (typeof team === 'string') {
    return { name: team, homeColor: '#FFFFFF', awayColor: '#000000', formation: '', squad: {}, homeDesign: 'solid', awayDesign: 'solid', homeSecondColor: '#000000', awaySecondColor: '#FFFFFF' };
  }
  return {
    name: team.name || '',
    homeColor: team.homeColor || '#FFFFFF',
    awayColor: team.awayColor || '#000000',
    formation: team.formation || '',
    squad: team.squad || {},
    homeDesign: team.homeDesign || 'solid',
    awayDesign: team.awayDesign || 'solid',
    homeSecondColor: team.homeSecondColor || '#000000',
    awaySecondColor: team.awaySecondColor || '#FFFFFF'
  };
}

// Initialize editor when DOM is ready
let tacticalEditor = null;

function initEditor() {
  console.log('Editor: initEditor() called, document.readyState:', document.readyState);
  
  if (!tacticalEditor) {
    console.log('Editor: Creating new TacticalEditor instance');
    loadCustomFormations();
    tacticalEditor = new TacticalEditor();
    window.tacticalEditor = tacticalEditor;
    
    // Try to initialize from parent window
    console.log('Editor: Calling initFromParent()');
    tacticalEditor.initFromParent();
  } else {
    console.log('Editor: TacticalEditor already exists, re-initializing from parent');
    tacticalEditor.initFromParent();
  }
  
  // Ensure i18n elements are updated after DOM is ready
  // Use setTimeout to ensure this runs after i18n.js has initialized
  setTimeout(() => {
    if (window.i18n && window.i18n.updateI18nElements) {
      console.log('Editor: Updating i18n elements');
      window.i18n.updateI18nElements();
    }
  }, 100);
  
  // Also update when language changes
  if (window.i18n && window.i18n.onLanguageChange) {
    window.i18n.onLanguageChange(() => {
      if (window.i18n && window.i18n.updateI18nElements) {
        window.i18n.updateI18nElements();
      }
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initEditor);
} else {
  initEditor();
}
