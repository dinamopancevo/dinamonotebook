// AI Analysis Utilities for Distats
// Shared functions for both popup and sidebar

(function() {
  'use strict';

  // ========== API KEY MANAGEMENT ==========
  
  async function loadOpenAIKey() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['openai_api_key'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(result.openai_api_key || null);
        }
      });
    });
  }

  function validateAPIKey(key) {
    if (!key || typeof key !== 'string') {
      return false;
    }
    return key.trim().startsWith('sk-') && key.trim().length >= 20;
  }

  // ========== PROXY FETCH FOR OPENAI API (avoids host_permissions) ==========
  
  /**
   * Proxy fetch calls to OpenAI API through background script
   * This avoids needing host_permissions in manifest.json
   */
  async function proxyFetch(url, options) {
    return new Promise(async (resolve, reject) => {
      // Handle FormData - convert to serializable format
      let formDataArray = null;
      let modifiedOptions = { ...options };
      
      if (options.body instanceof FormData) {
        formDataArray = [];
        const entries = Array.from(options.body.entries());
        
        // Convert all entries, handling Files specially
        for (const [key, value] of entries) {
          if (value instanceof File) {
            try {
              // Convert File to ArrayBuffer, then to array
              const arrayBuffer = await value.arrayBuffer();
              formDataArray.push([
                key,
                {
                  name: value.name,
                  type: value.type,
                  data: Array.from(new Uint8Array(arrayBuffer))
                }
              ]);
            } catch (err) {
              reject(new Error(`Failed to serialize file: ${err.message}`));
              return;
            }
          } else {
            formDataArray.push([key, value]);
          }
        }
        // Remove body from options - we'll send formData separately
        delete modifiedOptions.body;
      }
      
      chrome.runtime.sendMessage({
        action: 'openaiApiCall',
        url: url,
        options: modifiedOptions,
        formData: formDataArray
      }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        
        if (!response || !response.success) {
          reject(new Error(response?.error || 'Proxy request failed'));
          return;
        }
        
        // Create a Response-like object
        const proxyResponse = {
          ok: response.ok,
          status: response.status,
          statusText: response.statusText,
          headers: new Headers(response.headers),
          json: async () => JSON.parse(response.data),
          text: async () => response.data,
          blob: async () => new Blob([response.data])
        };
        
        resolve(proxyResponse);
      });
    });
  }

  // ========== DATA COLLECTION ==========
  
  async function collectAnalysisData(analysisId) {
    return new Promise((resolve, reject) => {
      if (!analysisId) {
        reject(new Error('No analysis ID provided'));
        return;
      }

      chrome.storage.local.get(['analyses', `timelineMarkers_${analysisId}`], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === analysisId);

        if (!analysis) {
          reject(new Error('Analysis not found'));
          return;
        }

        const timelineMarkers = result[`timelineMarkers_${analysisId}`] || [];

        // Collect tactical editor schemes and regular images from notes
        const tacticalSchemes = [];
        const regularImages = [];
        if (analysis.notes) {
          analysis.notes.forEach(note => {
            if (note.images && Array.isArray(note.images)) {
              note.images.forEach(image => {
                if (typeof image === 'object' && image.slidesData && Array.isArray(image.slidesData) && image.slidesData.length > 0) {
                  tacticalSchemes.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    slidesData: image.slidesData,
                    slides: image.slidesData || []
                  });
                } else if (typeof image === 'string' || (typeof image === 'object' && image.imageData)) {
                  regularImages.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    imageData: typeof image === 'string' ? image : image.imageData
                  });
                }
              });
            } else if (note.image) {
              if (typeof note.image === 'string') {
                regularImages.push({
                  timestamp: note.timestamp,
                  videoTime: note.videoTime,
                  timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                  imageData: note.image
                });
              }
            }
          });
        }

        const data = {
          analysis: {
            id: analysis.id,
            name: analysis.name,
            date: analysis.date,
            createdAt: analysis.createdAt,
            videos: analysis.videos || []
          },
          notes: analysis.notes || [],
          timelineMarkers: timelineMarkers,
          tacticalSchemes: tacticalSchemes,
          regularImages: regularImages
        };

        resolve(data);
      });
    });
  }

  // ========== RAG RETRIEVAL ==========
  
  // Retrieve relevant historical comments from comments database for RAG
  async function retrieveRelevantComments(currentProjectData, maxResults = 50) {
    return new Promise((resolve, reject) => {
      if (!currentProjectData || !currentProjectData.analysis) {
        resolve([]);
        return;
      }

      const currentAnalysisId = currentProjectData.analysis.id;
      
      // Extract context from current project
      const context = {
        teams: new Set(),
        players: new Set(),
        events: new Set(),
        zones: new Set()
      };

      // Extract teams from notes
      if (currentProjectData.notes && Array.isArray(currentProjectData.notes)) {
        currentProjectData.notes.forEach(note => {
          if (note.team && note.team.trim() !== '') {
            context.teams.add(note.team.trim());
          }
          if (note.teams && Array.isArray(note.teams)) {
            note.teams.forEach(t => {
              if (t && t.trim() !== '') context.teams.add(t.trim());
            });
          }
          if (note.players && Array.isArray(note.players)) {
            note.players.forEach(p => {
              const playerId = typeof p === 'string' ? p : (p.id || p.name);
              if (playerId) context.players.add(playerId.toString());
            });
          }
          if (note.events && Array.isArray(note.events)) {
            note.events.forEach(e => {
              if (e && e.trim() !== '') context.events.add(e.trim());
            });
          }
          if (note.zones && Array.isArray(note.zones)) {
            note.zones.forEach(z => {
              if (z !== null && z !== undefined) {
                const zoneStr = z.toString().trim();
                if (zoneStr !== '') context.zones.add(zoneStr);
              }
            });
          }
        });
      }

      // Extract teams, players, and events from timeline markers
      if (currentProjectData.timelineMarkers && Array.isArray(currentProjectData.timelineMarkers)) {
        currentProjectData.timelineMarkers.forEach(marker => {
          if (marker.team && marker.team.trim() !== '') {
            context.teams.add(marker.team.trim());
          }
          if (marker.players && Array.isArray(marker.players)) {
            marker.players.forEach(playerId => {
              if (playerId) context.players.add(playerId.toString());
            });
          }
          if (marker.event && marker.event.trim() !== '') {
            context.events.add(marker.event.trim());
          }
        });
      }
      
      // Also extract from notes that were converted from timeline markers
      if (currentProjectData.notes && Array.isArray(currentProjectData.notes)) {
        currentProjectData.notes.forEach(note => {
          // Include timeline-originated comments in RAG context
          if (note.source === 'timeline') {
            if (note.team && note.team.trim() !== '') {
              context.teams.add(note.team.trim());
            }
            if (note.players && Array.isArray(note.players)) {
              note.players.forEach(playerId => {
                if (playerId) context.players.add(playerId.toString());
              });
            }
            if (note.events && Array.isArray(note.events)) {
              note.events.forEach(event => {
                if (event && event.trim() !== '') context.events.add(event.trim());
              });
            }
          }
        });
      }
      
      // Extract teams, players, and events from timeline markers (already done above, this is legacy code)
      // This section is now redundant but kept for backward compatibility

      // Extract teams and zones from tactical schemes
      if (currentProjectData.tacticalSchemes && Array.isArray(currentProjectData.tacticalSchemes)) {
        currentProjectData.tacticalSchemes.forEach(scheme => {
          if (scheme.slidesData && Array.isArray(scheme.slidesData)) {
            scheme.slidesData.forEach(slide => {
              if (slide.drawings && Array.isArray(slide.drawings)) {
                slide.drawings.forEach(drawing => {
                  if (drawing.team && drawing.team.trim() !== '') {
                    context.teams.add(drawing.team.trim());
                  }
                  if (drawing.eventName && drawing.eventName.trim() !== '') {
                    context.events.add(drawing.eventName.trim());
                  }
                });
              }
            });
          }
        });
      }

      // If no context extracted, return empty array
      if (context.teams.size === 0 && context.players.size === 0 && 
          context.events.size === 0 && context.zones.size === 0) {
        resolve([]);
        return;
      }

      // Load all comments from storage
      chrome.storage.local.get(['analyses'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const allComments = [];

        // Collect all comments with metadata
        analyses.forEach(analysis => {
          if (analysis.notes && Array.isArray(analysis.notes)) {
            analysis.notes.forEach(note => {
              // Skip comments from current project
              if (analysis.id === currentAnalysisId) {
                return;
              }

              const commentWithMetadata = {
                ...note,
                analysisId: analysis.id,
                analysisName: analysis.name,
                analysisDate: analysis.date
              };
              allComments.push(commentWithMetadata);
            });
          }
        });

        if (allComments.length === 0) {
          resolve([]);
          return;
        }

        // Score and rank comments by relevance
        const scoredComments = allComments.map(comment => {
          let relevanceScore = 0;
          const matchReasons = [];

          // Score by team matches
          const commentTeams = new Set();
          if (comment.team && comment.team.trim() !== '') {
            commentTeams.add(comment.team.trim());
          }
          if (comment.teams && Array.isArray(comment.teams)) {
            comment.teams.forEach(t => {
              if (t && t.trim() !== '') commentTeams.add(t.trim());
            });
          }

          commentTeams.forEach(commentTeam => {
            context.teams.forEach(contextTeam => {
              if (commentTeam.toLowerCase() === contextTeam.toLowerCase()) {
                relevanceScore += 10; // Exact match
                matchReasons.push(`Team: ${commentTeam}`);
              } else if (commentTeam.toLowerCase().includes(contextTeam.toLowerCase()) || 
                         contextTeam.toLowerCase().includes(commentTeam.toLowerCase())) {
                relevanceScore += 5; // Partial match
                matchReasons.push(`Team (partial): ${commentTeam}`);
              }
            });
          });

          // Score by player matches
          if (comment.players && Array.isArray(comment.players) && context.players.size > 0) {
            comment.players.forEach(p => {
              const playerId = typeof p === 'string' ? p : (p.id || p.name);
              if (playerId && context.players.has(playerId.toString())) {
                relevanceScore += 8;
                matchReasons.push(`Player: ${playerId}`);
              }
            });
          }

          // Score by event matches
          if (comment.events && Array.isArray(comment.events) && context.events.size > 0) {
            comment.events.forEach(e => {
              if (e && e.trim() !== '') {
                context.events.forEach(contextEvent => {
                  if (e.toLowerCase() === contextEvent.toLowerCase()) {
                    relevanceScore += 6; // Exact match
                    matchReasons.push(`Event: ${e}`);
                  } else if (e.toLowerCase().includes(contextEvent.toLowerCase()) || 
                             contextEvent.toLowerCase().includes(e.toLowerCase())) {
                    relevanceScore += 3; // Partial match
                    matchReasons.push(`Event (partial): ${e}`);
                  }
                });
              }
            });
          }

          // Score by zone matches
          if (comment.zones && Array.isArray(comment.zones) && context.zones.size > 0) {
            comment.zones.forEach(z => {
              if (z !== null && z !== undefined) {
                const zoneStr = z.toString().trim();
                context.zones.forEach(contextZone => {
                  if (zoneStr === contextZone) {
                    relevanceScore += 4;
                    matchReasons.push(`Zone: ${zoneStr}`);
                  }
                });
              }
            });
          }

          return {
            comment: comment,
            relevanceScore: relevanceScore,
            matchReasons: matchReasons
          };
        });

        // Filter out comments with zero relevance and sort by score
        const relevantComments = scoredComments
          .filter(item => item.relevanceScore > 0)
          .sort((a, b) => b.relevanceScore - a.relevanceScore)
          .slice(0, maxResults)
          .map(item => item.comment);

        resolve(relevantComments);
      });
    });
  }

  // ========== ZONE UTILITIES ==========
  
  function getZoneNumber(x, y, canvasWidth = 1000, canvasHeight = 600) {
    const relX = (x / canvasWidth) * 100;
    const relY = (y / canvasHeight) * 100;
    
    // Standard 9-zone grid (3x3) - but we map to 18-zone system
    let zoneX = 1; // left
    if (relX >= 33 && relX < 67) zoneX = 2; // center
    else if (relX >= 67) zoneX = 3; // right
    
    let zoneY = 1; // defensive
    if (relY >= 33 && relY < 67) zoneY = 2; // midfield
    else if (relY >= 67) zoneY = 3; // attacking
    
    const zone9 = (zoneY - 1) * 3 + zoneX; // Zone 1-9
    
    // Convert 9-zone to 18-zone (3 rows x 6 columns)
    // Row 1 (defensive): zones 1-3 -> zones 1-6
    // Row 2 (midfield): zones 4-6 -> zones 7-12
    // Row 3 (attacking): zones 7-9 -> zones 13-18
    const row = zoneY - 1; // 0, 1, or 2
    const col = zoneX - 1; // 0, 1, or 2
    return row * 6 + col * 2 + 1; // Map to 18-zone system
  }

  function isPointInShape(px, py, shape) {
    if (!shape || !shape.type) return false;
    
    const minX = Math.min(shape.startX, shape.endX);
    const maxX = Math.max(shape.startX, shape.endX);
    const minY = Math.min(shape.startY, shape.endY);
    const maxY = Math.max(shape.startY, shape.endY);
    
    switch (shape.type) {
      case 'circle':
        const centerX = (shape.startX + shape.endX) / 2;
        const centerY = (shape.startY + shape.endY) / 2;
        const radius = Math.max(Math.abs(shape.endX - shape.startX), Math.abs(shape.endY - shape.startY)) / 2;
        const dist = Math.sqrt(Math.pow(px - centerX, 2) + Math.pow(py - centerY, 2));
        return dist <= radius;
        
      case 'oval':
      case 'rectangle':
      case 'triangle':
        return px >= minX && px <= maxX && py >= minY && py <= maxY;
        
      default:
        return false;
    }
  }

  function getZonesForShape(shape, canvasWidth = 1000, canvasHeight = 600) {
    const zones = new Set();
    const points = [
      {x: shape.startX, y: shape.startY},
      {x: shape.endX, y: shape.startY},
      {x: shape.startX, y: shape.endY},
      {x: shape.endX, y: shape.endY},
      {x: (shape.startX + shape.endX) / 2, y: (shape.startY + shape.endY) / 2}
    ];
    points.forEach(p => {
      zones.add(getZoneNumber(p.x, p.y, canvasWidth, canvasHeight));
    });
    return Array.from(zones).sort((a, b) => a - b);
  }

  // ========== DRAWING DESCRIPTION ==========
  
  function describeDrawing(drawing, index, canvasWidth = 1000, canvasHeight = 600, allDrawings = []) {
    if (!drawing || !drawing.type) return null;
    
    const descriptions = [];
    const type = drawing.type;
    
    const getFieldPosition = (x, y) => {
      const relX = (x / canvasWidth) * 100;
      const relY = (y / canvasHeight) * 100;
      
      let xPos = '';
      if (relX < 30) xPos = 'left side';
      else if (relX > 70) xPos = 'right side';
      else xPos = 'center';
      
      let yPos = '';
      if (relY < 25) yPos = 'defensive third';
      else if (relY < 60) yPos = 'midfield';
      else yPos = 'attacking third';
      
      return `${xPos} of ${yPos}`;
    };
    
    const getZoneInfo = (x, y) => {
      const zoneNum = getZoneNumber(x, y, canvasWidth, canvasHeight);
      const zoneNames = {
        1: 'Zone 1 (left defensive)', 2: 'Zone 2 (center defensive)', 3: 'Zone 3 (right defensive)',
        4: 'Zone 4 (left midfield)', 5: 'Zone 5 (center midfield)', 6: 'Zone 6 (right midfield)',
        7: 'Zone 7 (left attacking)', 8: 'Zone 8 (center attacking)', 9: 'Zone 9 (right attacking)',
        10: 'Zone 10', 11: 'Zone 11', 12: 'Zone 12', 13: 'Zone 13', 14: 'Zone 14', 15: 'Zone 15',
        16: 'Zone 16', 17: 'Zone 17', 18: 'Zone 18'
      };
      return zoneNames[zoneNum] || `Zone ${zoneNum}`;
    };
    
    const getDirection = (startX, startY, endX, endY) => {
      const dx = endX - startX;
      const dy = endY - startY;
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      
      if (Math.abs(dx) < 10) {
        return dy < 0 ? 'upward' : 'downward';
      } else if (Math.abs(dy) < 10) {
        return dx > 0 ? 'rightward' : 'leftward';
      } else {
        if (angle > -45 && angle < 45) return 'rightward';
        if (angle > 45 && angle < 135) return 'downward';
        if (angle > 135 || angle < -135) return 'leftward';
        return 'upward';
      }
    };
    
    const getZonesForMovement = (startX, startY, endX, endY) => {
      const startZone = getZoneNumber(startX, startY, canvasWidth, canvasHeight);
      const endZone = getZoneNumber(endX, endY, canvasWidth, canvasHeight);
      const zones = new Set([startZone, endZone]);
      
      const midX = (startX + endX) / 2;
      const midY = (startY + endY) / 2;
      const midZone = getZoneNumber(midX, midY, canvasWidth, canvasHeight);
      zones.add(midZone);
      
      return Array.from(zones).sort((a, b) => a - b);
    };
    
    const getZonesForShapeLocal = (shape) => {
      return getZonesForShape(shape, canvasWidth, canvasHeight);
    };
    
    switch (type) {
      case 'arrow':
        const arrowStart = getFieldPosition(drawing.startX, drawing.startY);
        const arrowEnd = getFieldPosition(drawing.endX, drawing.endY);
        const arrowDir = getDirection(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
        const arrowZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        let arrowDesc = `Arrow from ${arrowStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${arrowEnd} (${getZoneInfo(drawing.endX, drawing.endY)}) - ${arrowDir} direction`;
        arrowDesc += ` - Passes through zones: ${arrowZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.eventName) arrowDesc += ` - Event: ${drawing.eventName}`;
        return arrowDesc;
        
      case 'line':
        const lineStart = getFieldPosition(drawing.startX, drawing.startY);
        const lineEnd = getFieldPosition(drawing.endX, drawing.endY);
        const lineZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
        let lineDesc = `Line connecting ${lineStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${lineEnd} (${getZoneInfo(drawing.endX, drawing.endY)})`;
        lineDesc += ` - Zones: ${lineZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.eventName) lineDesc += ` - Event: ${drawing.eventName}`;
        return lineDesc;
        
      case 'circle':
        const circleCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const circleRadius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
        const circleSize = circleRadius > 50 ? 'large' : circleRadius > 25 ? 'medium' : 'small';
        const circleZones = getZonesForShapeLocal(drawing);
        let circleDesc = `${circleSize} circle ZONE at ${circleCenter}`;
        circleDesc += ` - Covers zones: ${circleZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.fillOpacity > 0) circleDesc += ` (filled - active zone)`;
        if (drawing.eventName) circleDesc += ` - Event in this zone: ${drawing.eventName}`;
        return circleDesc;
        
      case 'oval':
        const ovalCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const ovalZones = getZonesForShapeLocal(drawing);
        let ovalDesc = `oval/ellipse ZONE at ${ovalCenter}`;
        ovalDesc += ` - Covers zones: ${ovalZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.fillOpacity > 0) ovalDesc += ` (filled - active zone)`;
        if (drawing.eventName) ovalDesc += ` - Event in this zone: ${drawing.eventName}`;
        return ovalDesc;
        
      case 'rectangle':
        const rectCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const rectZones = getZonesForShapeLocal(drawing);
        let rectDesc = `Rectangle ZONE at ${rectCenter}`;
        rectDesc += ` - Covers zones: ${rectZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.fillOpacity > 0) rectDesc += ` (filled - active zone)`;
        if (drawing.eventName) rectDesc += ` - Event in this zone: ${drawing.eventName}`;
        return rectDesc;
        
      case 'triangle':
        const triCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const triZones = getZonesForShapeLocal(drawing);
        let triDesc = `Triangle ZONE at ${triCenter}`;
        triDesc += ` - Covers zones: ${triZones.map(z => `Zone ${z}`).join(', ')}`;
        if (drawing.fillOpacity > 0) triDesc += ` (filled - active zone)`;
        if (drawing.eventName) triDesc += ` - Event in this zone: ${drawing.eventName}`;
        return triDesc;
        
      case 'animpath':
        const pathStart = getFieldPosition(drawing.startX, drawing.startY);
        const pathEnd = getFieldPosition(drawing.endX, drawing.endY);
        const pathDir = getDirection(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
        const pathZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
        let pathDesc = `Player movement path from ${pathStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${pathEnd} (${getZoneInfo(drawing.endX, drawing.endY)}) - ${pathDir}`;
        pathDesc += ` - Movement through zones: ${pathZones.map(z => `Zone ${z}`).join(' → ')}`;
        if (drawing.duration) pathDesc += ` - Duration: ${drawing.duration}s`;
        return pathDesc;
        
      case 'tshirt':
        const tshirtPos = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const tshirtZone = getZoneInfo((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        let tshirtDesc = `Player at ${tshirtPos} (${tshirtZone})`;
        if (drawing.number) tshirtDesc += ` - Number: ${drawing.number}`;
        if (drawing.surname) tshirtDesc += ` - Name: ${drawing.surname}`;
        return tshirtDesc;
        
      case 'ball':
        const ballPos = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        const ballZone = getZoneInfo((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
        return `Ball at ${ballPos} (${ballZone})`;
        
      default:
        return `${type} drawing`;
    }
  }

  // ========== ZONE ANALYSIS FUNCTIONS ==========
  
  // Analyze zone patterns from notes, markers, and tactical schemes
  function analyzeZonePatterns(data) {
    const zoneData = {
      byTeam: new Map(), // Map<teamName, teamZoneData>
      overall: {
        zones: new Map(), // Map<zoneNumber, zoneStats>
        transitions: [] // Array of {from: zone, to: zone, team, event}
      }
    };

    // Initialize zone stats structure
    const initZoneStats = () => ({
      totalEvents: 0,
      attackingEvents: 0,
      defensiveEvents: 0,
      errors: 0,
      goals: 0,
      shots: 0,
      dangerousAttacks: 0,
      recoveries: 0,
      pressingActions: 0,
      events: [],
      coverageScore: 0, // Defensive actions count
      productivityScore: 0 // Attacking success count
    });

    // Helper to categorize events
    const isAttackingEvent = (event) => {
      const attackingKeywords = ['attack', 'shot', 'goal', 'assist', 'cross', 'cutback', 'through ball', 'final third', 'penalty box', 'progressive pass', 'carry', 'dribble'];
      return attackingKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isDefensiveEvent = (event) => {
      const defensiveKeywords = ['defense', 'defensive', 'pressing', 'recovery', 'tackle', 'interception', 'block', 'clearance', 'transition defense'];
      return defensiveKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isErrorEvent = (event) => {
      const errorKeywords = ['error', 'poor', 'bad decision', 'miscommunication', 'failed'];
      return errorKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    // Process notes
    if (data.notes && Array.isArray(data.notes)) {
      data.notes.forEach(note => {
        const teams = [];
        if (note.team) teams.push(note.team);
        if (note.teams && Array.isArray(note.teams)) teams.push(...note.teams);
        if (teams.length === 0) teams.push('Unknown');

        teams.forEach(team => {
          if (!zoneData.byTeam.has(team)) {
            zoneData.byTeam.set(team, {
              zones: new Map(),
              transitions: []
            });
          }
          const teamData = zoneData.byTeam.get(team);

          // Process zones from note
          if (note.zones && Array.isArray(note.zones)) {
            note.zones.forEach(zoneStr => {
              const zoneMatch = zoneStr.toString().match(/(\d+)/);
              if (zoneMatch) {
                const zoneNum = parseInt(zoneMatch[1]);
                if (zoneNum >= 1 && zoneNum <= 18) {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  zoneStats.events.push({
                    type: 'note',
                    event: note.events ? note.events.join(', ') : 'General note',
                    text: note.text || note.content || ''
                  });

                  // Categorize by events
                  const eventText = (note.events || []).join(' ').toLowerCase() + ' ' + (note.text || note.content || '').toLowerCase();
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    if (eventText.includes('goal')) zoneStats.goals++;
                    if (eventText.includes('shot')) zoneStats.shots++;
                    if (eventText.includes('dangerous') || eventText.includes('chance')) zoneStats.dangerousAttacks++;
                    zoneStats.productivityScore += 2;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    if (eventText.includes('recovery')) zoneStats.recoveries++;
                    if (eventText.includes('pressing')) zoneStats.pressingActions++;
                    zoneStats.coverageScore += 2;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                }
              }
            });
          }

          // Process events for transitions
          if (note.events && Array.isArray(note.events) && note.zones && note.zones.length >= 2) {
            const zones = note.zones.map(z => {
              const match = z.toString().match(/(\d+)/);
              return match ? parseInt(match[1]) : null;
            }).filter(z => z !== null && z >= 1 && z <= 18);
            
            if (zones.length >= 2) {
              for (let i = 0; i < zones.length - 1; i++) {
                teamData.transitions.push({
                  from: zones[i],
                  to: zones[i + 1],
                  event: note.events.join(', '),
                  type: 'note'
                });
              }
            }
          }
        });
      });
    }

    // Process timeline markers
    if (data.timelineMarkers && Array.isArray(data.timelineMarkers)) {
      data.timelineMarkers.forEach(marker => {
        const team = marker.team || 'Unknown';
        if (!zoneData.byTeam.has(team)) {
          zoneData.byTeam.set(team, {
            zones: new Map(),
            transitions: []
          });
        }
        // Timeline markers don't have zones directly, but we can infer from event type
        // This is handled in the tactical schemes processing
      });
    }

    // Process tactical schemes
    if (data.tacticalSchemes && Array.isArray(data.tacticalSchemes)) {
      data.tacticalSchemes.forEach(scheme => {
        if (scheme.slidesData && Array.isArray(scheme.slidesData)) {
          scheme.slidesData.forEach(slide => {
            if (slide.drawings && Array.isArray(slide.drawings)) {
              const canvasWidth = 1000;
              const canvasHeight = 600;

              // Process zones (shapes)
              const zones = slide.drawings.filter(d => ['circle', 'oval', 'rectangle', 'triangle'].includes(d.type));
              zones.forEach(zone => {
                const zoneNums = getZonesForShape(zone, canvasWidth, canvasHeight);
                const team = zone.team || 'Unknown';
                
                if (!zoneData.byTeam.has(team)) {
                  zoneData.byTeam.set(team, {
                    zones: new Map(),
                    transitions: []
                  });
                }
                const teamData = zoneData.byTeam.get(team);

                // Convert 9-zone to 18-zone for tactical schemes
                const convert9to18Zones = (zones9) => {
                  return zones9.map(zone9 => {
                    if (zone9 < 1 || zone9 > 9) return null;
                    const row = Math.floor((zone9 - 1) / 3);
                    const col = ((zone9 - 1) % 3);
                    // Map to approximate 18-zone
                    return row * 6 + col * 2 + 1;
                  }).filter(z => z !== null);
                };
                const zoneNums18 = convert9to18Zones(zoneNums);
                
                zoneNums18.forEach(zoneNum => {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  
                  const eventName = zone.eventName || '';
                  const eventText = eventName.toLowerCase();
                  
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    zoneStats.productivityScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    zoneStats.coverageScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                  
                  zoneStats.events.push({
                    type: 'scheme',
                    event: eventName,
                    filled: zone.fillOpacity > 0
                  });
                });
              });

              // Process movements for transitions
              const movements = slide.drawings.filter(d => ['arrow', 'line', 'curve', 'animpath'].includes(d.type));
              movements.forEach(movement => {
                // For tactical schemes, convert 9-zone to 18-zone system
                const startZone9 = getZoneNumber(movement.startX, movement.startY, canvasWidth, canvasHeight);
                const endZone9 = getZoneNumber(movement.endX, movement.endY, canvasWidth, canvasHeight);
                // Convert 9-zone (1-9) to approximate 18-zone (1-18) mapping
                const convert9to18 = (zone9) => {
                  if (zone9 < 1 || zone9 > 9) return null;
                  const row = Math.floor((zone9 - 1) / 3); // 0, 1, or 2
                  const col = ((zone9 - 1) % 3); // 0, 1, or 2
                  // Map to 18-zone: each 9-zone maps to 2 zones in 18-zone system
                  return row * 6 + col * 2 + 1; // Approximate mapping
                };
                const startZone = convert9to18(startZone9);
                const endZone = convert9to18(endZone9);
                const team = movement.team || 'Unknown';
                
                if (startZone && endZone && startZone !== endZone && startZone >= 1 && startZone <= 18 && endZone >= 1 && endZone <= 18) {
                  if (!zoneData.byTeam.has(team)) {
                    zoneData.byTeam.set(team, {
                      zones: new Map(),
                      transitions: []
                    });
                  }
                  const teamData = zoneData.byTeam.get(team);
                  
                  teamData.transitions.push({
                    from: startZone,
                    to: endZone,
                    event: movement.eventName || 'Movement',
                    type: 'scheme'
                  });
                }
              });
            }
          });
        }
      });
    }

    // Aggregate overall stats
    zoneData.byTeam.forEach((teamData, team) => {
      teamData.zones.forEach((stats, zoneNum) => {
        if (!zoneData.overall.zones.has(zoneNum)) {
          zoneData.overall.zones.set(zoneNum, initZoneStats());
        }
        const overallStats = zoneData.overall.zones.get(zoneNum);
        overallStats.totalEvents += stats.totalEvents;
        overallStats.attackingEvents += stats.attackingEvents;
        overallStats.defensiveEvents += stats.defensiveEvents;
        overallStats.errors += stats.errors;
        overallStats.goals += stats.goals;
        overallStats.shots += stats.shots;
        overallStats.dangerousAttacks += stats.dangerousAttacks;
        overallStats.recoveries += stats.recoveries;
        overallStats.pressingActions += stats.pressingActions;
        overallStats.coverageScore += stats.coverageScore;
        overallStats.productivityScore += stats.productivityScore;
      });
      zoneData.overall.transitions.push(...teamData.transitions);
    });

    return zoneData;
  }

  // Calculate zone statistics
  function calculateZoneStatistics(zoneData) {
    const stats = {
      byTeam: new Map(),
      overall: {
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      }
    };

    // Process each team
    zoneData.byTeam.forEach((teamData, team) => {
      const teamStats = {
        zones: [],
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      };

      // Calculate zone rankings
      const zoneArray = Array.from(teamData.zones.entries()).map(([zoneNum, zoneStats]) => ({
        zone: zoneNum,
        ...zoneStats
      }));

      teamStats.zones = zoneArray;
      teamStats.mostActiveZones = [...zoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
      teamStats.mostProductiveZones = [...zoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
      teamStats.mostCoveredZones = [...zoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
      teamStats.mostVulnerableZones = [...zoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
        .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

      // Analyze transition patterns
      const transitionMap = new Map();
      teamData.transitions.forEach(trans => {
        const key = `${trans.from}->${trans.to}`;
        if (!transitionMap.has(key)) {
          transitionMap.set(key, { from: trans.from, to: trans.to, count: 0, events: [] });
        }
        transitionMap.get(key).count++;
        transitionMap.get(key).events.push(trans.event);
      });
      teamStats.transitionPatterns = Array.from(transitionMap.values())
        .sort((a, b) => b.count - a.count).slice(0, 5);

      stats.byTeam.set(team, teamStats);
    });

    // Calculate overall stats
    const overallZoneArray = Array.from(zoneData.overall.zones.entries()).map(([zoneNum, zoneStats]) => ({
      zone: zoneNum,
      ...zoneStats
    }));

    stats.overall.mostActiveZones = [...overallZoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
    stats.overall.mostProductiveZones = [...overallZoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
    stats.overall.mostCoveredZones = [...overallZoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
    stats.overall.mostVulnerableZones = [...overallZoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
      .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

    // Overall transition patterns
    const overallTransitionMap = new Map();
    zoneData.overall.transitions.forEach(trans => {
      const key = `${trans.from}->${trans.to}`;
      if (!overallTransitionMap.has(key)) {
        overallTransitionMap.set(key, { from: trans.from, to: trans.to, count: 0 });
      }
      overallTransitionMap.get(key).count++;
    });
    stats.overall.transitionPatterns = Array.from(overallTransitionMap.values())
      .sort((a, b) => b.count - a.count).slice(0, 5);

    return stats;
  }

  // Identify game plan from zone stats and events
  function identifyGamePlan(zoneStats, events) {
    const gamePlan = {
      primaryAttackZones: [],
      primaryDefenseZones: [],
      buildUpPattern: '',
      finishingPattern: '',
      transitionStyle: ''
    };

    // Identify primary attack zones (high productivity)
    gamePlan.primaryAttackZones = zoneStats.mostProductiveZones
      .filter(z => z.attackingEvents > 0)
      .map(z => z.zone);

    // Identify primary defense zones (high coverage)
    gamePlan.primaryDefenseZones = zoneStats.mostCoveredZones
      .filter(z => z.defensiveEvents > 0)
      .map(z => z.zone);

    // Analyze build-up pattern (zones 1-6 to 7-12)
    const defensiveZones = zoneStats.zones.filter(z => z.zone >= 1 && z.zone <= 6 && z.totalEvents > 0);
    const midfieldZones = zoneStats.zones.filter(z => z.zone >= 7 && z.zone <= 12 && z.totalEvents > 0);
    if (defensiveZones.length > 0 && midfieldZones.length > 0) {
      gamePlan.buildUpPattern = `Builds from defensive zones (${defensiveZones.map(z => z.zone).join(', ')}) through midfield (${midfieldZones.map(z => z.zone).join(', ')})`;
    }

    // Analyze finishing pattern (zones 13-18)
    const attackingZones = zoneStats.zones.filter(z => z.zone >= 13 && z.zone <= 18 && z.attackingEvents > 0);
    if (attackingZones.length > 0) {
      gamePlan.finishingPattern = `Finishes in attacking zones: ${attackingZones.map(z => z.zone).join(', ')}`;
    }

    // Analyze transition style
    const forwardTransitions = zoneStats.transitionPatterns.filter(t => t.from < t.to);
    const backwardTransitions = zoneStats.transitionPatterns.filter(t => t.from > t.to);
    if (forwardTransitions.length > backwardTransitions.length) {
      gamePlan.transitionStyle = 'Forward-pressing, counter-attacking style';
    } else if (backwardTransitions.length > forwardTransitions.length) {
      gamePlan.transitionStyle = 'Possession-based, build-up style';
    } else {
      gamePlan.transitionStyle = 'Balanced transition style';
    }

    return gamePlan;
  }

  // Compare two teams' data
  function compareTeams(team1Data, team2Data) {
    const comparisons = {
      attackComparison: [],
      defenseComparison: [],
      tacticalMatchups: [],
      exploitationOpportunities: []
    };

    // Compare attack zones
    const team1AttackZones = team1Data.mostProductiveZones.map(z => z.zone);
    const team2DefenseZones = team2Data.mostCoveredZones.map(z => z.zone);
    const team2VulnerableZones = team2Data.mostVulnerableZones.map(z => z.zone);

    team1AttackZones.forEach(zone => {
      if (team2VulnerableZones.includes(zone)) {
        comparisons.exploitationOpportunities.push({
          type: 'attack',
          team1Zone: zone,
          team2Vulnerability: zone,
          description: `Team 1's strength in zone ${zone} matches Team 2's vulnerability`
        });
      }
    });

    // Compare defense zones
    const team1DefenseZones = team1Data.mostCoveredZones.map(z => z.zone);
    const team2AttackZones = team2Data.mostProductiveZones.map(z => z.zone);

    team2AttackZones.forEach(zone => {
      if (team1DefenseZones.includes(zone)) {
        comparisons.tacticalMatchups.push({
          type: 'defense',
          zone: zone,
          description: `Team 1's defensive strength in zone ${zone} will face Team 2's attacking strength`
        });
      }
    });

    return comparisons;
  }

  // ========== FORMAT DATA FOR AI ==========
  
  // Format data for AI prompt - UNIFIED VERSION for both popup and sidebar
  // analysisFocus: optional custom question/focus from the coach (e.g., "What are the defensive weaknesses of Team X?")
  function formatDataForAI(data, language = 'auto', historicalComments = [], analysisFocus = null) {
    const languageInstructions = {
      'auto': 'Respond in the same language as the notes (if notes are in multiple languages, use the most common one).',
      'en': 'Respond in English.',
      'sr': 'Respond in Serbian (Srpski).',
      'fr': 'Respond in French (Français).',
      'es': 'Respond in Spanish (Español).',
      'pt': 'Respond in Portuguese (Português).',
      'ru': 'Respond in Russian (Русский).',
      'de': 'Respond in German (Deutsch).',
      'pl': 'Respond in Polish (Polski).',
      'it': 'Respond in Italian (Italiano).'
    };

    const langInstruction = languageInstructions[language] || languageInstructions['auto'];
    
    // Get template phrase translations
    const templatePhrases = {
      'auto': {
        team: 'TEAM', insufficientData: 'Insufficient data', keyStrengths: 'Key Strengths', keyWeaknesses: 'Key Weaknesses',
        opportunities: 'Opportunities', threats: 'Threats', defense: 'Defense', midfield: 'Midfield', attack: 'Attack',
        overallTactical: 'Overall Tactical Approach', forTeam: 'For Team', matchPreparation: 'Match Preparation',
        teamsIdentified: 'TEAMS IDENTIFIED IN ANALYSIS', teamLabel: 'Team'
      },
      'en': {
        team: 'TEAM', insufficientData: 'Insufficient data', keyStrengths: 'Key Strengths', keyWeaknesses: 'Key Weaknesses',
        opportunities: 'Opportunities', threats: 'Threats', defense: 'Defense', midfield: 'Midfield', attack: 'Attack',
        overallTactical: 'Overall Tactical Approach', forTeam: 'For Team', matchPreparation: 'Match Preparation',
        teamsIdentified: 'TEAMS IDENTIFIED IN ANALYSIS', teamLabel: 'Team'
      },
      'ru': {
        team: 'КОМАНДА', insufficientData: 'Недостаточно данных', keyStrengths: 'Ключевые сильные стороны',
        keyWeaknesses: 'Ключевые слабые стороны', opportunities: 'Возможности', threats: 'Угрозы',
        defense: 'Защита', midfield: 'Полузащита', attack: 'Атака', overallTactical: 'Общий тактический подход',
        forTeam: 'Для команды', matchPreparation: 'Подготовка к матчу',
        teamsIdentified: 'КОМАНДЫ В АНАЛИЗЕ', teamLabel: 'Команда'
      },
      'sr': {
        team: 'TIM', insufficientData: 'Nedovoljno podataka', keyStrengths: 'Ključne prednosti',
        keyWeaknesses: 'Ključni nedostaci', opportunities: 'Mogućnosti', threats: 'Pretnje',
        defense: 'Odbrana', midfield: 'Sredina', attack: 'Napad', overallTactical: 'Opšti taktički pristup',
        forTeam: 'Za tim', matchPreparation: 'Priprema za utakmicu',
        teamsIdentified: 'TIMOVI U ANALIZI', teamLabel: 'Tim'
      },
      'de': {
        team: 'MANNSCHAFT', insufficientData: 'Unzureichende Daten', keyStrengths: 'Hauptstärken',
        keyWeaknesses: 'Hauptschwächen', opportunities: 'Möglichkeiten', threats: 'Bedrohungen',
        defense: 'Verteidigung', midfield: 'Mittelfeld', attack: 'Angriff', overallTactical: 'Gesamter taktischer Ansatz',
        forTeam: 'Für Mannschaft', matchPreparation: 'Spielvorbereitung',
        teamsIdentified: 'MANNSCHAFTEN IN DER ANALYSE', teamLabel: 'Mannschaft'
      },
      'pl': {
        team: 'DRUŻYNA', insufficientData: 'Niewystarczające dane', keyStrengths: 'Kluczowe mocne strony',
        keyWeaknesses: 'Kluczowe słabe strony', opportunities: 'Możliwości', threats: 'Zagrożenia',
        defense: 'Obrona', midfield: 'Pomoc', attack: 'Atak', overallTactical: 'Ogólne podejście taktyczne',
        forTeam: 'Dla drużyny', matchPreparation: 'Przygotowanie do meczu',
        teamsIdentified: 'DRUŻYNY W ANALIZIE', teamLabel: 'Drużyna'
      },
      'es': {
        team: 'EQUIPO', insufficientData: 'Datos insuficientes', keyStrengths: 'Fortalezas clave',
        keyWeaknesses: 'Debilidades clave', opportunities: 'Oportunidades', threats: 'Amenazas',
        defense: 'Defensa', midfield: 'Mediocampo', attack: 'Ataque', overallTactical: 'Enfoque táctico general',
        forTeam: 'Para el equipo', matchPreparation: 'Preparación del partido',
        teamsIdentified: 'EQUIPOS EN EL ANÁLISIS', teamLabel: 'Equipo'
      },
      'fr': {
        team: 'ÉQUIPE', insufficientData: 'Données insuffisantes', keyStrengths: 'Forces clés',
        keyWeaknesses: 'Faiblesses clés', opportunities: 'Opportunités', threats: 'Menaces',
        defense: 'Défense', midfield: 'Milieu de terrain', attack: 'Attaque', overallTactical: 'Approche tactique globale',
        forTeam: 'Pour l\'équipe', matchPreparation: 'Préparation du match',
        teamsIdentified: 'ÉQUIPES DANS L\'ANALYSE', teamLabel: 'Équipe'
      },
      'it': {
        team: 'SQUADRA', insufficientData: 'Dati insufficienti', keyStrengths: 'Punti di forza chiave',
        keyWeaknesses: 'Punti deboli chiave', opportunities: 'Opportunità', threats: 'Minacce',
        defense: 'Difesa', midfield: 'Centrocampo', attack: 'Attacco', overallTactical: 'Approccio tattico generale',
        forTeam: 'Per la squadra', matchPreparation: 'Preparazione della partita',
        teamsIdentified: 'SQUADRE NELL\'ANALISI', teamLabel: 'Squadra'
      },
      'pt': {
        team: 'TIME', insufficientData: 'Dados insuficientes', keyStrengths: 'Pontos fortes principais',
        keyWeaknesses: 'Pontos fracos principais', opportunities: 'Oportunidades', threats: 'Ameaças',
        defense: 'Defesa', midfield: 'Meio-campo', attack: 'Ataque', overallTactical: 'Abordagem tática geral',
        forTeam: 'Para o time', matchPreparation: 'Preparação para o jogo',
        teamsIdentified: 'TIMES NA ANÁLISE', teamLabel: 'Time'
      }
    };
    const phrases = templatePhrases[language] || templatePhrases['en'];
    
    // IDENTIFY TEAMS STRICTLY ONLY FROM CURRENT PROJECT DATA
    // ABSOLUTELY CRITICAL: DO NOT include ANY teams from historical comments or other projects
    // ONLY teams that appear in THIS project's notes, markers, or schemes should be analyzed
    // If a team appears only in historical comments, it should NOT be included in analysis
    const teams = new Set();
    const teamsWithData = new Map(); // Track which teams have what type of data

    console.log('AI Analysis - Starting team identification for project:', data.analysis?.name);
    
    if (data.notes) {
      data.notes.forEach(note => {
        if (note.team && note.team.trim() !== '') {
          teams.add(note.team);
          if (!teamsWithData.has(note.team)) teamsWithData.set(note.team, { notes: 0, markers: 0, schemes: 0 });
          teamsWithData.get(note.team).notes++;
        }
        if (note.teams && Array.isArray(note.teams)) {
          note.teams.forEach(t => {
            if (t && t.trim() !== '') {
              teams.add(t);
              if (!teamsWithData.has(t)) teamsWithData.set(t, { notes: 0, markers: 0, schemes: 0 });
              teamsWithData.get(t).notes++;
            }
          });
        }
      });
    }
    if (data.timelineMarkers) {
      data.timelineMarkers.forEach(marker => {
        if (marker.team && marker.team.trim() !== '') {
          teams.add(marker.team);
          if (!teamsWithData.has(marker.team)) teamsWithData.set(marker.team, { notes: 0, markers: 0, schemes: 0 });
          teamsWithData.get(marker.team).markers++;
        }
      });
    }
    // Check tactical schemes for team information (if players in schemes have team info)
    if (data.tacticalSchemes) {
      data.tacticalSchemes.forEach(scheme => {
        if (scheme.slidesData && Array.isArray(scheme.slidesData)) {
          scheme.slidesData.forEach(slide => {
            if (slide.drawings && Array.isArray(slide.drawings)) {
              slide.drawings.forEach(drawing => {
                // Check if drawing has team info (e.g., from player assignments)
                if (drawing.team && drawing.team.trim() !== '') {
                  teams.add(drawing.team);
                  if (!teamsWithData.has(drawing.team)) teamsWithData.set(drawing.team, { notes: 0, markers: 0, schemes: 0 });
                  teamsWithData.get(drawing.team).schemes++;
                }
              });
            }
          });
        }
      });
    }
    
    // Be extremely lenient - include teams that have ANY data at all
    // If there's any data in the project, we should provide analysis
    const teamList = Array.from(teams);
    console.log('AI Analysis - Identified teams from current project data:', teamList);

    // If no teams were identified from the data, but there's still data in the project,
    // create a generic analysis based on all available data
    if (teamList.length === 0 && (data.notes?.length > 0 || data.timelineMarkers?.length > 0 || data.tacticalSchemes?.length > 0)) {
      teamList.push('General Analysis');
      teamsWithData.set('General Analysis', {
        notes: data.notes?.length || 0,
        markers: data.timelineMarkers?.length || 0,
        schemes: data.tacticalSchemes?.length || 0
      });
    }
    
    let prompt = `You are an expert football/soccer coach analyzing a video analysis project. The coach has been analyzing game footage, taking notes, creating tactical schemes, and marking timeline events. Your task is to provide a comprehensive coaching analysis that helps improve the coach's team and identify advantages/disadvantages of opponents.

CRITICAL LANGUAGE REQUIREMENT: ${langInstruction} This means EVERYTHING must be in ${language === 'ru' ? 'Russian' : language === 'sr' ? 'Serbian' : language === 'de' ? 'German' : language === 'pl' ? 'Polish' : language === 'es' ? 'Spanish' : language === 'fr' ? 'French' : language === 'it' ? 'Italian' : language === 'pt' ? 'Portuguese' : 'the requested language'} - ALL text, ALL labels, ALL phrases, including "TEAM", "Insufficient data", "Key Strengths", etc. Use the translated phrases provided below. CHECK THIS LANGUAGE SETTING BEFORE EVERY RESPONSE AND ENSURE YOUR ENTIRE OUTPUT IS IN THE CORRECT LANGUAGE.

CRITICAL ANALYSIS REQUIREMENT: ALWAYS ANALYZE ALL AVAILABLE CONTENT - Read and provide insights from EVERY note, marker, scheme, image, chat message, and any other data in the project. NEVER say "insufficient data" unless the project is completely empty with zero content of any kind.

ABSOLUTE PROJECT SCOPE LIMITATION: This analysis is for PROJECT "${data.analysis?.name || 'Unknown Project'}". ONLY analyze teams that appear in THIS PROJECT'S data (notes, markers, schemes). DO NOT analyze any teams that appear only in historical comments from other projects. If you see team names in historical data that aren't in the current project, IGNORE THEM COMPLETELY.

CRITICAL: Historical comments may mention team names, but these are NOT teams you should analyze. Historical comments are for context only - they do not introduce new teams for analysis.\n\n`;

    // Get citation term translations (needed for analysisFocus section)
    const citationTerms = {
      'auto': { note: 'Note', marker: 'Marker', scheme: 'Scheme', image: 'Image' },
      'en': { note: 'Note', marker: 'Marker', scheme: 'Scheme', image: 'Image' },
      'sr': { note: 'Napomena', marker: 'Marker', scheme: 'Šema', image: 'Slika' },
      'ru': { note: 'Заметка', marker: 'Маркер', scheme: 'Схема', image: 'Изображение' },
      'de': { note: 'Notiz', marker: 'Marker', scheme: 'Schema', image: 'Bild' },
      'pl': { note: 'Notatka', marker: 'Marker', scheme: 'Schemat', image: 'Obraz' },
      'es': { note: 'Nota', marker: 'Marcador', scheme: 'Esquema', image: 'Imagen' },
      'fr': { note: 'Note', marker: 'Marqueur', scheme: 'Schéma', image: 'Image' },
      'it': { note: 'Nota', marker: 'Marcatore', scheme: 'Schema', image: 'Immagine' },
      'pt': { note: 'Nota', marker: 'Marcador', scheme: 'Esquema', image: 'Imagem' }
    };
    const citationLang = citationTerms[language] || citationTerms['en'];

    // Add custom analysis focus if provided by the coach
    if (analysisFocus && analysisFocus.trim()) {
      prompt += `COACH'S SPECIFIC ANALYSIS REQUEST:\n`;
      prompt += `================================\n`;
      prompt += `The coach has requested a FOCUSED analysis on the following topic:\n`;
      prompt += `"${analysisFocus.trim()}"\n\n`;
      prompt += `CRITICAL INSTRUCTION: Your response MUST directly answer this specific question. DO NOT provide a general analysis with sections like "TACTICAL INSIGHTS", "KEY FINDINGS", etc.\n`;
      prompt += `- Give a direct, concise answer to the question using all available data\n`;
      prompt += `- Structure your response as a direct answer (e.g., "2 goals were scored from zone 15 by Jonas and Ozhegovich (Note 34) (Note 35)")\n`;
      prompt += `- Include specific details, numbers, player names, and zone references when relevant\n`;
      prompt += `- Cite sources for every claim you make using SEPARATE formats: (${citationLang.note} X) (${citationLang.marker} Y) etc. - each citation must be in its own parentheses for separate clickable links\n`;
      prompt += `- If the question asks for specific information (like "where were goals scored?"), list them clearly with details\n`;
      prompt += `- Keep the response focused and direct - no unnecessary sections or headers\n`;
      prompt += `================================\n\n`;
    }
    
    // Identify user's team and opponent teams
    const userTeam = data.userTeam || null;
    const opponentTeams = teamList.filter(team => team !== userTeam);
    
    if (teamList.length > 0) {
      prompt += `${phrases.teamsIdentified}:\n`;
      prompt += `ABSOLUTELY CRITICAL: Analyze ONLY the teams listed below that have data in THIS CURRENT PROJECT.\n`;
      prompt += `DO NOT analyze ANY teams that appear only in historical comments from other projects.\n`;
      prompt += `DO NOT mention or analyze teams that are not in this list, even if they appear in historical data.\n`;
      prompt += `If a team name appears in historical comments but not in current project data, IGNORE it completely.\n\n`;
      teamList.forEach((team, idx) => {
        const teamData = teamsWithData.get(team);
        const dataTypes = [];
        if (teamData.notes > 0) dataTypes.push(`${teamData.notes} note(s)`);
        if (teamData.markers > 0) dataTypes.push(`${teamData.markers} marker(s)`);
        if (teamData.schemes > 0) dataTypes.push(`${teamData.schemes} scheme(s)`);
        const teamLabel = team === userTeam ? `${phrases.teamLabel} ${idx + 1}: ${team} (YOUR TEAM)` : `${phrases.teamLabel} ${idx + 1}: ${team}`;
        prompt += `- ${teamLabel} (found in: ${dataTypes.join(', ')})\n`;
      });
      prompt += `\n`;
      
      // Add user team context
      if (userTeam && teamList.includes(userTeam)) {
        prompt += `USER'S TEAM (YOUR TEAM): ${userTeam}\n`;
        if (opponentTeams.length > 0) {
          prompt += `OPPONENT TEAMS: ${opponentTeams.join(', ')}\n`;
        }
        prompt += `\n`;
        prompt += `CRITICAL ANALYSIS REQUIREMENTS:\n`;
        prompt += `- For YOUR TEAM (${userTeam}): Provide improvement recommendations, identify weaknesses to address, suggest tactical adjustments to enhance performance, and highlight areas where the team can improve based on the data.\n`;
        if (opponentTeams.length > 0) {
          prompt += `- For OPPONENT TEAMS (${opponentTeams.join(', ')}): Provide competitive analysis - identify their strengths and weaknesses, suggest how to exploit their vulnerabilities, recommend defensive strategies against their attacks, and outline tactical approaches to counter their game plan.\n`;
        }
        prompt += `- Clearly distinguish between "your team" and "opponents" in all recommendations.\n`;
        prompt += `\n`;
      }
      
      prompt += `CRITICAL RESTRICTION: The teams listed above are the ONLY teams that appear in this project's data (notes, timeline markers, and tactical schemes).\n`;
      prompt += `- You MUST ONLY analyze these ${teamList.length} team(s): ${teamList.join(', ')}\n`;
      prompt += `- Do NOT mention, analyze, or reference ANY other teams that are not in this list\n`;
      prompt += `- Do NOT assume there are other teams - if a team is not listed above, it does NOT exist in this project\n`;
      prompt += `- If you see team names in the data that are not in the list above, ignore them - they are not part of this analysis\n`;
      prompt += `- Analyze ALL identified teams using whatever data is available for each one\n`;
      prompt += `- Be creative with analysis - even minimal data can provide insights\n\n`;
    } else {
      prompt += `IMPORTANT: Even if no teams are explicitly identified, analyze all available content in the project - notes, markers, schemes, images, chat messages, and any other data. Provide tactical analysis based on whatever information exists.\n\n`;
    }
    
    prompt += `CRITICAL FORMATTING INSTRUCTIONS - STRICTLY FOLLOW:\n`;
    prompt += `- ABSOLUTELY NO MARKDOWN FORMATTING: Do NOT use ** (bold), __ (underline), ### (headers), * (italics), or any other markdown symbols\n`;
    prompt += `- Use plain text ONLY - no formatting symbols whatsoever\n`;
    prompt += `- Use clear section headers in ALL CAPS (like "TACTICAL INSIGHTS")\n`;
    prompt += `- Use simple line breaks and indentation for structure\n`;
    prompt += `- Do NOT use asterisks, underscores, or hash symbols for emphasis\n`;
    prompt += `- If you want to emphasize something, use ALL CAPS or just write it normally\n`;
    prompt += `- ${langInstruction}\n\n`;
    
    prompt += `PROJECT INFORMATION:\n`;
    prompt += `- Name: ${data.analysis.name}\n`;
    prompt += `- Date: ${data.analysis.date}\n`;
    prompt += `- Videos: ${data.analysis.videos.length} video(s)\n\n`;

    if (data.notes && data.notes.length > 0) {
      prompt += `COACH NOTES (${data.notes.length} notes):\n`;
      data.notes.forEach((note, index) => {
        const timecode = note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null;
        const timecodeStr = timecode ? timecode[0] : (note.videoTime ? `[${Math.floor(note.videoTime / 60)}:${String(Math.floor(note.videoTime % 60)).padStart(2, '0')}]` : '');
        const noteText = note.text || note.content || '';
        const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
        
        prompt += `\nNote ${index + 1} ${timecodeStr}:\n`;
        prompt += `- Text: ${cleanText}\n`;
        if (note.team) prompt += `- Team: ${note.team}\n`;
        if (note.teams && note.teams.length > 0) prompt += `- Teams: ${note.teams.join(', ')}\n`;
        if (note.players && note.players.length > 0) {
          prompt += `- Players: ${note.players.map(p => typeof p === 'string' ? p : (p.name || p.id)).join(', ')}\n`;
        }
        if (note.events && note.events.length > 0) prompt += `- Events: ${note.events.join(', ')}\n`;
        if (note.zones && note.zones.length > 0) prompt += `- Zones: ${note.zones.join(', ')}\n`;
        if (note.intensity !== null && note.intensity !== undefined) {
          const intensityLabels = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
          prompt += `- Intensity: ${intensityLabels[note.intensity] || note.intensity}\n`;
        }
      });
      prompt += `\n`;
    }

    if (data.timelineMarkers && data.timelineMarkers.length > 0) {
      prompt += `TIMELINE MARKERS (${data.timelineMarkers.length} markers):\n`;
      data.timelineMarkers.forEach((marker, index) => {
        const minutes = Math.floor(marker.time / 60);
        const seconds = Math.floor(marker.time % 60);
        prompt += `\nMarker ${index + 1} [${minutes}:${String(seconds).padStart(2, '0')}]:\n`;
        if (marker.team) prompt += `- Team: ${marker.team}\n`;
        if (marker.eventType) prompt += `- Event: ${marker.eventType}\n`;
        if (marker.videoId) prompt += `- Video ID: ${marker.videoId}\n`;
      });
      prompt += `\n`;
    }

    if (data.tacticalSchemes && data.tacticalSchemes.length > 0) {
      prompt += `TACTICAL EDITOR SCHEMES (${data.tacticalSchemes.length} schemes):\n`;
      prompt += `IMPORTANT: These schemes contain detailed tactical drawings showing formations, player positions, movements, zones, and tactical patterns. Analyze them carefully.\n\n`;
      data.tacticalSchemes.forEach((scheme, index) => {
        const timecode = scheme.timecode ? scheme.timecode[0] : (scheme.videoTime ? `[${Math.floor(scheme.videoTime / 60)}:${String(Math.floor(scheme.videoTime % 60)).padStart(2, '0')}]` : '');
        prompt += `\nScheme ${index + 1} ${timecode}:\n`;
        prompt += `- Contains ${scheme.slides ? scheme.slides.length : (scheme.slidesData ? scheme.slidesData.length : 0)} slide(s) with tactical drawings\n`;
        if (scheme.slidesData && scheme.slidesData.length > 0) {
          scheme.slidesData.forEach((slide, slideIndex) => {
            if (slide.drawings && slide.drawings.length > 0) {
              prompt += `\n  Slide ${slideIndex + 1} (${slide.drawings.length} drawing(s)):\n`;
              
              // First, identify all zones
              const zones = slide.drawings.filter(d => ['circle', 'oval', 'rectangle', 'triangle'].includes(d.type));
              if (zones.length > 0) {
                prompt += `    ZONES IDENTIFIED:\n`;
                zones.forEach((zone, zoneIndex) => {
                  const description = describeDrawing(zone, zoneIndex, 1000, 600, slide.drawings);
                  if (description) {
                    prompt += `      - ${description}\n`;
                  }
                });
                prompt += `    \n`;
              }
              
              // Then, describe movements and their relationship to zones
              const movements = slide.drawings.filter(d => ['arrow', 'line', 'curve', 'animpath'].includes(d.type));
              if (movements.length > 0) {
                prompt += `    MOVEMENTS AND ACTIONS:\n`;
                movements.forEach((movement, moveIndex) => {
                  const description = describeDrawing(movement, moveIndex, 1000, 600, slide.drawings);
                  if (description) {
                    prompt += `      - ${description}\n`;
                  }
                });
                prompt += `    \n`;
              }
              
              // Then, describe players and ball positions
              const players = slide.drawings.filter(d => d.type === 'tshirt');
              const balls = slide.drawings.filter(d => d.type === 'ball');
              if (players.length > 0 || balls.length > 0) {
                prompt += `    POSITIONS:\n`;
                players.forEach((player, playerIndex) => {
                  const description = describeDrawing(player, playerIndex, 1000, 600, slide.drawings);
                  if (description) {
                    prompt += `      - ${description}\n`;
                  }
                });
                balls.forEach((ball, ballIndex) => {
                  const description = describeDrawing(ball, ballIndex, 1000, 600, slide.drawings);
                  if (description) {
                    prompt += `      - ${description}\n`;
                  }
                });
                prompt += `    \n`;
              }
              
              // Finally, describe other elements
              const others = slide.drawings.filter(d => !['circle', 'oval', 'rectangle', 'triangle', 'arrow', 'line', 'curve', 'animpath', 'tshirt', 'ball'].includes(d.type));
              if (others.length > 0) {
                others.forEach((other, otherIndex) => {
                  const description = describeDrawing(other, otherIndex, 1000, 600, slide.drawings);
                  if (description) {
                    prompt += `    - ${description}\n`;
                  }
                });
              }
              
              // Zone analysis summary
              if (zones.length > 0 || movements.length > 0) {
                prompt += `    ZONE ANALYSIS SUMMARY:\n`;
                const zoneMap = new Map();
                const canvasWidth = 1000;
                const canvasHeight = 600;
                
                // Helper functions for zone analysis
                const getZonesForShapeLocal = (shape) => {
                  const zones = new Set();
                  const points = [
                    {x: shape.startX, y: shape.startY},
                    {x: shape.endX, y: shape.startY},
                    {x: shape.startX, y: shape.endY},
                    {x: shape.endX, y: shape.endY},
                    {x: (shape.startX + shape.endX) / 2, y: (shape.startY + shape.endY) / 2}
                  ];
                  points.forEach(p => {
                    zones.add(getZoneNumber(p.x, p.y, canvasWidth, canvasHeight));
                  });
                  return Array.from(zones).sort((a, b) => a - b);
                };
                
                const getZonesForMovementLocal = (startX, startY, endX, endY) => {
                  const startZone = getZoneNumber(startX, startY, canvasWidth, canvasHeight);
                  const endZone = getZoneNumber(endX, endY, canvasWidth, canvasHeight);
                  const zones = new Set([startZone, endZone]);
                  const midX = (startX + endX) / 2;
                  const midY = (startY + endY) / 2;
                  const midZone = getZoneNumber(midX, midY, canvasWidth, canvasHeight);
                  zones.add(midZone);
                  return Array.from(zones).sort((a, b) => a - b);
                };
                
                zones.forEach(zone => {
                  const zoneNums = getZonesForShapeLocal(zone);
                  zoneNums.forEach(z => {
                    if (!zoneMap.has(z)) zoneMap.set(z, []);
                    zoneMap.get(z).push({
                      type: zone.type,
                      event: zone.eventName || 'no event',
                      filled: zone.fillOpacity > 0
                    });
                  });
                });
                movements.forEach(movement => {
                  const zoneNums = getZonesForMovementLocal(movement.startX, movement.startY, movement.endX, movement.endY);
                  zoneNums.forEach(z => {
                    if (!zoneMap.has(z)) zoneMap.set(z, []);
                    zoneMap.get(z).push({
                      type: 'movement',
                      movementType: movement.type,
                      event: movement.eventName || 'no event'
                    });
                  });
                });
                const sortedZones = Array.from(zoneMap.keys()).sort((a, b) => a - b);
                sortedZones.forEach(zoneNum => {
                  const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
                  prompt += `      - Zone ${zoneNum} (${zoneNames[zoneNum] || `zone ${zoneNum}`}): `;
                  const activities = zoneMap.get(zoneNum);
                  const zoneShapes = activities.filter(a => a.type !== 'movement');
                  const zoneMovements = activities.filter(a => a.type === 'movement');
                  if (zoneShapes.length > 0) {
                    prompt += `${zoneShapes.length} zone marker(s)`;
                    const events = zoneShapes.filter(s => s.event !== 'no event').map(s => s.event);
                    if (events.length > 0) prompt += ` - Events: ${events.join(', ')}`;
                    const filledZones = zoneShapes.filter(s => s.filled);
                    if (filledZones.length > 0) prompt += ` (${filledZones.length} filled/active)`;
                  }
                  if (zoneMovements.length > 0) {
                    if (zoneShapes.length > 0) prompt += `; `;
                    prompt += `${zoneMovements.length} movement(s)`;
                    const moveEvents = zoneMovements.filter(m => m.event !== 'no event').map(m => m.event);
                    if (moveEvents.length > 0) prompt += ` - Events: ${moveEvents.join(', ')}`;
                  }
                  prompt += `\n`;
                });
              }
            }
          });
        }
      });
      prompt += `\n`;
    }

    if (data.regularImages && data.regularImages.length > 0) {
      prompt += `REGULAR IMAGES (${data.regularImages.length} images):\n`;
      prompt += `- ${data.regularImages.length} image(s) attached to notes (screenshots, photos, etc.)\n`;
      prompt += `- These images contain visual information relevant to the analysis\n\n`;
    }

    // ZONE STATISTICS AND GAME PLAN ANALYSIS
    // Analyze zone patterns from all data sources
    const zoneData = analyzeZonePatterns(data);
    const zoneStats = calculateZoneStatistics(zoneData);
    
    if (zoneData.byTeam.size > 0 || zoneData.overall.zones.size > 0) {
      prompt += `ZONE STATISTICS AND TACTICAL PATTERNS:\n`;
      prompt += `IMPORTANT: The following zone statistics are calculated from notes, timeline markers, and tactical schemes. Use this quantitative data to identify game plans, attack patterns, defensive coverage, and tactical weaknesses.\n\n`;
      prompt += `ZONE MAP (18 zones total):\n`;
      prompt += `- Defensive third: Zones 1-6 (left to right: 1,2,3,4,5,6)\n`;
      prompt += `- Middle third: Zones 7-12 (left to right: 7,8,9,10,11,12)\n`;
      prompt += `- Attacking third: Zones 13-18 (left to right: 13,14,15,16,17,18)\n\n`;
      
      // Add team-specific zone statistics
      zoneStats.byTeam.forEach((teamStats, team) => {
        if (teamList.includes(team) && teamStats.zones.length > 0) {
          prompt += `${phrases.teamLabel} ${teamList.indexOf(team) + 1} (${team}) - ZONE ANALYSIS:\n`;
          
          // Most active zones
          if (teamStats.mostActiveZones.length > 0) {
            prompt += `- Most Active Zones: ${teamStats.mostActiveZones.map(z => `Zone ${z.zone} (${z.totalEvents} events)`).join(', ')}\n`;
          }
          
          // Most productive zones (attacking)
          if (teamStats.mostProductiveZones.length > 0) {
            prompt += `- Most Productive Attacking Zones: ${teamStats.mostProductiveZones.map(z => `Zone ${z.zone} (${z.attackingEvents} attacks, productivity score: ${z.productivityScore})`).join(', ')}\n`;
          }
          
          // Most covered zones (defensive)
          if (teamStats.mostCoveredZones.length > 0) {
            prompt += `- Best Covered Defensive Zones: ${teamStats.mostCoveredZones.map(z => `Zone ${z.zone} (${z.defensiveEvents} defensive actions, coverage score: ${z.coverageScore})`).join(', ')}\n`;
          }
          
          // Most vulnerable zones
          if (teamStats.mostVulnerableZones.length > 0) {
            prompt += `- Most Vulnerable Zones: ${teamStats.mostVulnerableZones.map(z => `Zone ${z.zone} (${z.errors} errors, coverage score: ${z.coverageScore})`).join(', ')}\n`;
          }
          
          // Transition patterns
          if (teamStats.transitionPatterns.length > 0) {
            prompt += `- Common Transition Patterns: ${teamStats.transitionPatterns.map(t => `Zone ${t.from} → Zone ${t.to} (${t.count} times)`).join(', ')}\n`;
          }
          
          // Zone-by-zone breakdown
          prompt += `- Zone-by-Zone Breakdown:\n`;
          teamStats.zones.forEach(zone => {
            const zoneNames = {
              1: 'defensive left', 2: 'defensive left-center', 3: 'defensive center-left', 4: 'defensive center-right', 5: 'defensive right-center', 6: 'defensive right',
              7: 'midfield left', 8: 'midfield left-center', 9: 'midfield center-left', 10: 'midfield center-right', 11: 'midfield right-center', 12: 'midfield right',
              13: 'attacking left', 14: 'attacking left-center', 15: 'attacking center-left', 16: 'attacking center-right', 17: 'attacking right-center', 18: 'attacking right'
            };
            const zoneName = zoneNames[zone.zone] || `zone ${zone.zone}`;
            prompt += `  Zone ${zone.zone} (${zoneName}): ${zone.totalEvents} total events, ${zone.attackingEvents} attacking, ${zone.defensiveEvents} defensive, ${zone.errors} errors, ${zone.goals} goals, ${zone.shots} shots\n`;
          });
          
          // Game plan identification
          const gamePlan = identifyGamePlan(teamStats, []);
          if (gamePlan.primaryAttackZones.length > 0 || gamePlan.primaryDefenseZones.length > 0) {
            prompt += `- Identified Game Plan:\n`;
            if (gamePlan.primaryAttackZones.length > 0) {
              prompt += `  Primary Attack Zones: ${gamePlan.primaryAttackZones.join(', ')}\n`;
            }
            if (gamePlan.primaryDefenseZones.length > 0) {
              prompt += `  Primary Defense Zones: ${gamePlan.primaryDefenseZones.join(', ')}\n`;
            }
            if (gamePlan.buildUpPattern) {
              prompt += `  Build-Up: ${gamePlan.buildUpPattern}\n`;
            }
            if (gamePlan.finishingPattern) {
              prompt += `  Finishing: ${gamePlan.finishingPattern}\n`;
            }
            if (gamePlan.transitionStyle) {
              prompt += `  Transition Style: ${gamePlan.transitionStyle}\n`;
            }
          }
          
          prompt += `\n`;
        }
      });
      
      // Overall zone statistics
      if (zoneStats.overall.mostActiveZones.length > 0) {
        prompt += `OVERALL ZONE STATISTICS (All Teams Combined):\n`;
        prompt += `- Most Active Zones Overall: ${zoneStats.overall.mostActiveZones.map(z => `Zone ${z.zone} (${z.totalEvents} events)`).join(', ')}\n`;
        prompt += `- Most Productive Zones Overall: ${zoneStats.overall.mostProductiveZones.map(z => `Zone ${z.zone} (productivity: ${z.productivityScore})`).join(', ')}\n`;
        prompt += `- Best Covered Zones Overall: ${zoneStats.overall.mostCoveredZones.map(z => `Zone ${z.zone} (coverage: ${z.coverageScore})`).join(', ')}\n`;
        if (zoneStats.overall.mostVulnerableZones.length > 0) {
          prompt += `- Most Vulnerable Zones Overall: ${zoneStats.overall.mostVulnerableZones.map(z => `Zone ${z.zone} (${z.errors} errors)`).join(', ')}\n`;
        }
        if (zoneStats.overall.transitionPatterns.length > 0) {
          prompt += `- Common Transition Patterns: ${zoneStats.overall.transitionPatterns.map(t => `Zone ${t.from} → Zone ${t.to} (${t.count} times)`).join(', ')}\n`;
        }
        prompt += `\n`;
      }
      
      // Comparative analysis for multiple teams
      if (teamList.length >= 2) {
        prompt += `COMPARATIVE ANALYSIS (Multiple Teams Detected):\n`;
        prompt += `IMPORTANT: Since multiple teamsƒ are present in this analysis, provide direct comparisons between teams.\n`;
        prompt += `- Compare attack zones: Which team attacks more effectively from which zones?\n`;
        prompt += `- Compare defensive coverage: Which team defends better in which zones?\n`;
        prompt += `- Identify tactical matchups: Where do one team's strengths match another team's weaknesses?\n`;
        prompt += `- Suggest exploitation opportunities: How can one team exploit another team's vulnerabilities?\n`;
        
        // Generate comparison data
        const teamArray = Array.from(teamList);
        if (teamArray.length >= 2) {
          const team1 = teamArray[0];
          const team2 = teamArray[1];
          const team1Stats = zoneStats.byTeam.get(team1);
          const team2Stats = zoneStats.byTeam.get(team2);
          
          if (team1Stats && team2Stats) {
            const comparisons = compareTeams(team1Stats, team2Stats);
            
            if (comparisons.exploitationOpportunities.length > 0) {
              prompt += `- Exploitation Opportunities for ${team1} against ${team2}:\n`;
              comparisons.exploitationOpportunities.forEach(opp => {
                prompt += `  Zone ${opp.team1Zone}: ${opp.description}\n`;
              });
            }
            
            if (comparisons.tacticalMatchups.length > 0) {
              prompt += `- Key Tactical Matchups:\n`;
              comparisons.tacticalMatchups.forEach(matchup => {
                prompt += `  Zone ${matchup.zone}: ${matchup.description}\n`;
              });
            }
          }
        }
        prompt += `\n`;
      }
    }

    // Add historical comments section if available
    if (historicalComments && historicalComments.length > 0) {
      console.log('AI Analysis - Including', historicalComments.length, 'historical comments in prompt');
      const historicalHeaders = {
        'auto': { title: 'HISTORICAL OBSERVATIONS FROM PREVIOUS PROJECTS', comment: 'Historical Comment', fromProject: 'From Project' },
        'en': { title: 'HISTORICAL OBSERVATIONS FROM PREVIOUS PROJECTS', comment: 'Historical Comment', fromProject: 'From Project' },
        'sr': { title: 'ISTORIJSKA ZAPAŽANJA IZ PRETHODNIH PROJEKATA', comment: 'Istorijski komentar', fromProject: 'Iz projekta' },
        'ru': { title: 'ИСТОРИЧЕСКИЕ НАБЛЮДЕНИЯ ИЗ ПРЕДЫДУЩИХ ПРОЕКТОВ', comment: 'Исторический комментарий', fromProject: 'Из проекта' },
        'de': { title: 'HISTORISCHE BEOBACHTUNGEN AUS VORHERIGEN PROJEKTEN', comment: 'Historischer Kommentar', fromProject: 'Aus Projekt' },
        'pl': { title: 'HISTORYCZNE OBSERWACJE Z POPRZEDNICH PROJEKTÓW', comment: 'Historyczny komentarz', fromProject: 'Z projektu' },
        'es': { title: 'OBSERVACIONES HISTÓRICAS DE PROYECTOS ANTERIORES', comment: 'Comentario histórico', fromProject: 'Del proyecto' },
        'fr': { title: 'OBSERVATIONS HISTORIQUES DES PROJETS PRÉCÉDENTS', comment: 'Commentaire historique', fromProject: 'Du projet' },
        'it': { title: 'OSERVAZIONI STORICHE DA PROGETTI PRECEDENTI', comment: 'Commento storico', fromProject: 'Dal progetto' },
        'pt': { title: 'OBSERVAÇÕES HISTÓRICAS DE PROJETOS ANTERIORES', comment: 'Comentário histórico', fromProject: 'Do projeto' }
      };
      const histHeaders = historicalHeaders[language] || historicalHeaders['en'];
      
      prompt += `\n${histHeaders.title}:\n`;
      prompt += `IMPORTANT: The following comments are from PREVIOUS PROJECTS (different from the current project being analyzed). These historical observations can help identify patterns, trends, and consistent behaviors across multiple projects.\n\n`;
      prompt += `CRITICAL INSTRUCTIONS FOR USING HISTORICAL DATA:\n`;
      prompt += `- READ ALL HISTORICAL COMMENTS THOROUGHLY - do not skip or partially read any comments\n`;
      prompt += `- EMERGENCY RULE: DO NOT analyze ANY teams that appear ONLY in historical comments\n`;
      prompt += `- ONLY use historical comments to provide additional context for teams ALREADY identified in current project data\n`;
      prompt += `- If a team appears in historical comments but NOT in current project notes/markers/schemes, COMPLETELY IGNORE that team\n`;
      prompt += `- DO NOT introduce new teams for analysis based on historical data\n`;
      prompt += `- Compare current project observations with historical patterns ONLY for teams present in current project\n`;
      prompt += `- When citing historical comments, use the format: (${histHeaders.comment} X ${histHeaders.fromProject} "Project Name")\n`;
      prompt += `- Example citation: (${histHeaders.comment} 3 ${histHeaders.fromProject} "Match Analysis vs Team A")\n`;
      prompt += `- Distinguish clearly between current project data and historical data in your analysis\n`;
      prompt += `- Historical data should ONLY support analysis of current project teams, NEVER introduce new teams\n`;
      prompt += `- If historical data contradicts current observations for current project teams, note both and explain the context\n\n`;
      
      prompt += `HISTORICAL COMMENTS (${historicalComments.length} comment(s) from previous projects):\n\n`;
      
      historicalComments.forEach((comment, index) => {
        const timecode = comment.text ? comment.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null;
        const timecodeStr = timecode ? timecode[0] : (comment.videoTime ? `[${Math.floor(comment.videoTime / 60)}:${String(Math.floor(comment.videoTime % 60)).padStart(2, '0')}]` : '');
        const commentText = comment.text || comment.content || '';
        const cleanText = commentText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
        
        prompt += `${histHeaders.comment} ${index + 1} ${timecodeStr} ${histHeaders.fromProject} "${comment.analysisName || 'Unknown Project'}" (${comment.analysisDate || 'Unknown Date'}):\n`;
        prompt += `- Text: ${cleanText}\n`;
        // DO NOT include team information from historical comments to prevent AI from analyzing those teams
        // prompt += `- Team: ${comment.team}\n`;
        // prompt += `- Teams: ${comment.teams.join(', ')}\n`;
        if (comment.players && comment.players.length > 0) {
          prompt += `- Players: ${comment.players.map(p => typeof p === 'string' ? p : (p.name || p.id)).join(', ')}\n`;
        }
        if (comment.events && comment.events.length > 0) prompt += `- Events: ${comment.events.join(', ')}\n`;
        if (comment.zones && comment.zones.length > 0) prompt += `- Zones: ${comment.zones.join(', ')}\n`;
        if (comment.intensity !== null && comment.intensity !== undefined) {
          const intensityLabels = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
          prompt += `- Intensity: ${intensityLabels[comment.intensity] || comment.intensity}\n`;
        }
        prompt += `\n`;
      });
      
      prompt += `\n`;
    }

    // Get section header translations based on language
    const sectionHeaders = {
      'auto': { insights: 'TACTICAL INSIGHTS', summary: 'SUMMARY', findings: 'KEY FINDINGS', suggestions: 'SUGGESTIONS' },
      'en': { insights: 'TACTICAL INSIGHTS', summary: 'SUMMARY', findings: 'KEY FINDINGS', suggestions: 'SUGGESTIONS' },
      'sr': { insights: 'TAKTIČKI UVIDI', summary: 'REZIME', findings: 'KLJUČNI NALAZI', suggestions: 'PREDLOZI' },
      'ru': { insights: 'ТАКТИЧЕСКИЕ ИНСАЙТЫ', summary: 'РЕЗЮМЕ', findings: 'КЛЮЧЕВЫЕ НАХОДКИ', suggestions: 'ПРЕДЛОЖЕНИЯ' },
      'de': { insights: 'TAKTISCHE EINSICHTEN', summary: 'ZUSAMMENFASSUNG', findings: 'WICHTIGE ERKENNTNISSE', suggestions: 'EMPFEHLUNGEN' },
      'pl': { insights: 'WGLĄDY TAKTYCZNE', summary: 'PODSUMOWANIE', findings: 'KLUCZOWE USTALENIA', suggestions: 'SUGERENCJE' },
      'es': { insights: 'PERSPECTIVAS TÁCTICAS', summary: 'RESUMEN', findings: 'HALLAZGOS CLAVE', suggestions: 'SUGERENCIAS' },
      'fr': { insights: 'APERÇUS TACTIQUES', summary: 'RÉSUMÉ', findings: 'CONSTATATIONS CLÉS', suggestions: 'SUGGESTIONS' },
      'it': { insights: 'SPUNTI TATTICI', summary: 'RIEPILOGO', findings: 'RISULTATI CHIAVE', suggestions: 'SUGGERIMENTI' },
      'pt': { insights: 'PERSPECTIVAS TÁTICAS', summary: 'RESUMO', findings: 'DESCOBERTAS CHAVE', suggestions: 'SUGESTÕES' }
    };
    
    const headers = sectionHeaders[language] || sectionHeaders['en'];
    
    prompt += `\nPlease provide a comprehensive COACHING analysis with the following structure (use the translated headers provided):\n\n`;
    
    // Add game plan analysis instructions
    prompt += `GAME PLAN ANALYSIS REQUIREMENTS:\n`;
    prompt += `- Identify and describe each team's primary attack patterns: Which zones do they typically attack from? What percentage of dangerous attacks originate from each zone?\n`;
    prompt += `- Analyze defensive structure: Which zones are well-covered during defensive actions? Which zones are vulnerable or uncovered?\n`;
    prompt += `- Describe transition patterns: How do teams move from defense to attack and vice versa? What are the common zone-to-zone progressions?\n`;
    prompt += `- Identify set-piece tendencies: Preferred zones and patterns for corners, free kicks, throw-ins\n`;
    prompt += `- Zone load analysis: Which zones are "loaded" (many players/actions) vs "unloaded" during different phases?\n`;
    prompt += `- Use the zone statistics provided above to support your analysis with quantitative data\n\n`;
    
    // EMERGENCY INSTRUCTION: Regardless of what teams appear in historical data, ONLY analyze teams from current project
    prompt += `EMERGENCY TEAM FILTERING INSTRUCTION:\n`;
    prompt += `- You are analyzing PROJECT: "${data.analysis.name}"\n`;
    prompt += `- ONLY analyze teams that have data in THIS SPECIFIC PROJECT\n`;
    prompt += `- The ONLY teams you should analyze are: ${teamList.length > 0 ? teamList.join(', ') : 'None identified'}\n`;
    prompt += `- IGNORE any teams that appear only in historical comments from other projects\n`;
    prompt += `- If historical comments mention teams not in current project, do NOT analyze those teams\n`;
    prompt += `- Your analysis should be limited EXACTLY to the teams listed above - no more, no less\n\n`;

    // Skip structured format when analysisFocus is provided - give direct answer instead
    if (!analysisFocus || !analysisFocus.trim()) {
      if (teamList.length >= 2) {
        // Multiple teams - analyze each separately plus comparisons
        prompt += `CRITICAL ANALYSIS REQUIREMENTS:\n`;
        prompt += `========================================\n`;
        prompt += `EXTREMELY IMPORTANT: If the coach asks a SPECIFIC QUESTION, you MUST answer it using ANY available data - even just one note!\n`;
        prompt += `EXAMPLE: If asked "How does Team A defend set pieces?" and there's only 1 note mentioning "Team A defends set pieces poorly", you MUST analyze and answer based on that single piece of information.\n`;
        prompt += `Never say "insufficient data" when answering a specific question - use whatever data exists, no matter how limited.\n`;
        prompt += `For general analysis requests, be more lenient but still provide analysis based on available data.\n`;
        prompt += `========================================\n\n`;

        prompt += `${headers.insights}:\n`;
        prompt += `Provide analysis for all teams that have any data at all - be very lenient!\n`;
        prompt += `Only skip teams with literally zero notes, zero markers, and zero schemes.\n\n`;
        prompt += `For teams WITH data, provide:\n`;
        prompt += `   - Game Plan Summary: High-level overview of their tactical approach based on zone statistics\n`;
        prompt += `   - Zone-Based Analysis: Which zones they use for attack/defense, coverage patterns, vulnerabilities\n`;
        prompt += `   - ${phrases.defense}: Defensive organization, pressing zones, transition defense patterns\n`;
        prompt += `   - ${phrases.midfield}: Midfield control, ball distribution zones, positioning\n`;
        prompt += `   - ${phrases.attack}: Attacking patterns by zone, creativity, finishing zones\n`;
        prompt += `   - ${phrases.overallTactical}: Formation effectiveness, pressing triggers, transition play\n\n`;

        prompt += `${headers.findings}:\n`;
        prompt += `ONLY include teams that have actual data with specific findings. SKIP teams with no data.\n`;
        prompt += `For each team WITH data, provide:\n`;
        prompt += `- ${phrases.keyStrengths}: Zone-specific strengths (e.g., "Effective counterattacks from zone 2 to zone 8")\n`;
        prompt += `- ${phrases.keyWeaknesses}: Zone-specific weaknesses (e.g., "Struggles to create chances from zone 9")\n`;
        prompt += `- Patterns: Recurring successful/unsuccessful tactical patterns with zone references\n`;
        prompt += `- Comparative Insights: Direct comparisons between teams (e.g., "Team A attacks from zone 7 more effectively than Team B")\n`;
        prompt += `If NO team has enough data for findings, write ONE sentence and move on.\n\n`;
      } else if (teamList.length === 1) {
        // Single team - focus on improvement
        prompt += `${headers.insights}:\n`;
        prompt += `- Game Plan Summary: High-level overview of the team's tactical approach based on zone statistics\n`;
        prompt += `- Zone-Based Analysis: Which zones they use for attack/defense, coverage patterns, vulnerabilities\n`;
        prompt += `- ${phrases.defense}: Analyze defensive organization by zone, pressing zones, and transitions\n`;
        prompt += `- ${phrases.midfield}: Analyze midfield control by zone, ball distribution, and positioning\n`;
        prompt += `- ${phrases.attack}: Analyze attacking patterns by zone, creativity, and finishing\n`;
        prompt += `- ${phrases.overallTactical}: Formation effectiveness, pressing triggers, transition play\n`;

        prompt += `\n${headers.findings}:\n`;
        prompt += `- ${phrases.keyStrengths}: Zone-specific strengths (e.g., "Effective counterattacks from zone 2 to zone 8", "Strong coverage in zones 1-3")\n`;
        prompt += `- ${phrases.keyWeaknesses}: Zone-specific weaknesses (e.g., "Struggles to create chances from zone 9", "Exposed in zone 6 during transitions")\n`;
        prompt += `- Patterns: Recurring successful/unsuccessful tactical patterns with zone references\n`;
      } else {
        // No teams identified - general analysis
        prompt += `${headers.insights}: Identify key tactical patterns, formations, and strategic elements based on zone statistics\n`;
        prompt += `- Use the zone statistics to identify overall game plans and patterns\n`;
        prompt += `\n${headers.findings}: Highlight the most important observations with zone references\n`;
      }

      prompt += `\n${headers.summary}: Provide a concise summary based on whatever data is available. Even with minimal data, provide some analysis - coaches appreciate any insights.\n`;
      prompt += `\n${headers.suggestions}:\n`;
      prompt += `IMPORTANT: Provide suggestions based on ANY available data, even if limited. Be creative with recommendations!\n`;
      if (teamList.length >= 2) {
        prompt += `CRITICAL: If the coach asks a specific question, provide suggestions even with minimal data related to that question.\n`;
        prompt += `- For general requests, provide suggestions based on whatever patterns you can identify from the available data\n`;
        prompt += `- Don't say "insufficient data" for suggestions - make reasonable recommendations based on what you know\n`;
        prompt += `- For each team with sufficient data, provide:\n`;
        prompt += `  - Training Focus: Specific drills or exercises based on identified weaknesses (e.g., "Focus on defending zone 6 during transitions")\n`;
        prompt += `  - Tactical Adjustments: Specific changes to game plan with zone references (e.g., "Increase pressure in zone 5 to force turnovers", "Exploit opponent's vulnerability in zone 7")\n`;
        prompt += `  - Match Preparation: How to play against specific opponents based on their zone patterns (e.g., "Prepare to defend against attacks from zones 7-8", "Exploit opponent's weak coverage in zone 6")\n`;
        prompt += `  - Formation Suggestions: Recommended formations based on zone usage patterns\n`;
      } else if (teamList.length === 1) {
        prompt += `- Training Focus: Specific drills or exercises based on identified weaknesses with zone references (e.g., "Focus on defending zone 6 during transitions", "Practice attacking from zone 7")\n`;
        prompt += `- Tactical Adjustments: Specific tactical changes to implement with zone references (e.g., "Increase pressure in zone 5 to force turnovers", "Improve coverage in zone 3 during defensive transitions")\n`;
        prompt += `- Match Preparation: How to prepare for upcoming matches based on identified patterns (e.g., "Strengthen defensive coverage in zones 1-3", "Develop attacking patterns through zones 4-6 to 7-9")\n`;
        prompt += `- Formation Suggestions: Recommended formations based on zone usage patterns and identified strengths/weaknesses\n`;
        prompt += `- Player Development: Individual and collective improvements needed, referencing specific zones where applicable\n`;
      } else {
        prompt += `- Offer actionable recommendations for improvement with zone references where applicable\n`;
        prompt += `- Training Focus: Specific drills based on identified patterns\n`;
        prompt += `- Tactical Adjustments: Specific changes with zone references\n`;
      }
    }
    
    prompt += `CRITICAL REQUIREMENTS:\n`;
    prompt += `- ${langInstruction}\n`;
    prompt += `- EVERYTHING must be in the requested language - ALL text, ALL phrases, ALL labels, ALL words, NO EXCEPTIONS\n`;
    prompt += `- ALWAYS TRY TO ANSWER USING ALL AVAILABLE INFORMATION - DO NOT SAY "INSUFFICIENT DATA" UNLESS THERE IS LITERALLY NO DATA AT ALL\n`;
    prompt += `- COMPREHENSIVE ANALYSIS REQUIRED: Read and analyze EVERYTHING in the project - all notes, markers, schemes, images, chat messages, timestamps, and any other content. Extract insights from unstructured data and provide helpful analysis.\n`;
    prompt += `- Use the translated section headers provided above (${headers.insights}, ${headers.summary}, ${headers.findings}, ${headers.suggestions})\n`;
    prompt += `- Use the translated template phrases EXACTLY as provided below - DO NOT translate them yourself, use them as-is:\n`;
    prompt += `  * "${phrases.team}" (NOT "TEAM" or any other translation)\n`;
    prompt += `  * "${phrases.insufficientData}" (NOT "Insufficient data" or any other translation)\n`;
    prompt += `  * "${phrases.keyStrengths}" (NOT "Key Strengths" or any other translation)\n`;
    prompt += `  * "${phrases.keyWeaknesses}" (NOT "Key Weaknesses" or any other translation)\n`;
    prompt += `  * "${phrases.opportunities}" (NOT "Opportunities" or any other translation)\n`;
    prompt += `  * "${phrases.threats}" (NOT "Threats" or any other translation)\n`;
    prompt += `  * "${phrases.defense}" (NOT "Defense" or any other translation)\n`;
    prompt += `  * "${phrases.midfield}" (NOT "Midfield" or any other translation)\n`;
    prompt += `  * "${phrases.attack}" (NOT "Attack" or any other translation)\n`;
    prompt += `  * "${phrases.overallTactical}" (NOT "Overall Tactical Approach" or any other translation)\n`;
    prompt += `  * "${phrases.forTeam}" (NOT "For Team" or any other translation)\n`;
    prompt += `  * "${phrases.matchPreparation}" (NOT "Match Preparation" or any other translation)\n`;
    prompt += `- DO NOT mix languages - if the language is ${language === 'ru' ? 'Russian' : language === 'sr' ? 'Serbian' : language === 'de' ? 'German' : language === 'pl' ? 'Polish' : language === 'es' ? 'Spanish' : language === 'fr' ? 'French' : language === 'it' ? 'Italian' : language === 'pt' ? 'Portuguese' : 'the requested language'}, EVERYTHING must be in ${language === 'ru' ? 'Russian' : language === 'sr' ? 'Serbian' : language === 'de' ? 'German' : language === 'pl' ? 'Polish' : language === 'es' ? 'Spanish' : language === 'fr' ? 'French' : language === 'it' ? 'Italian' : language === 'pt' ? 'Portuguese' : 'that language'}, including ALL labels and phrases\n`;
    prompt += `- Translate ALL analysis text, not just the main content - labels, phrases, and descriptions must all be in the requested language\n`;
    prompt += `- DATA HANDLING - ANALYZE EVERYTHING THAT EXISTS:\n`;
    prompt += `  * READ AND ANALYZE ALL CONTENT IN THE PROJECT - comments, schemes, images, timestamps, chat messages, ANYTHING\n`;
    prompt += `  * DO NOT REQUIRE team tags, zone references, or structured data - analyze whatever content exists\n`;
    prompt += `  * If there are ANY notes, markers, schemes, images, or timeline events, provide analysis based on them\n`;
    prompt += `  * NEVER say "insufficient data" - always try to provide insights from whatever information is available\n`;
    prompt += `  * Be creative and helpful - extract meaning from unstructured content, chat discussions, and any observations\n`;
    prompt += `  * ONLY say "${phrases.insufficientData}" if the project is COMPLETELY EMPTY with zero notes, zero markers, zero schemes, zero images, zero timeline events, and zero chat content\n`;
    prompt += `  * The goal is to help the coach - always provide analysis when there's anything to work with\n`;
    prompt += `- ANALYSIS APPROACH:\n`;
    prompt += `  * Read all project content thoroughly - every note, every marker, every scheme, every image, every chat message\n`;
    prompt += `  * Extract insights from any observations, even if they're informal or unstructured\n`;
    prompt += `  * Look for patterns in timestamps, discussions, and visual elements\n`;
    prompt += `  * Provide helpful analysis based on whatever information exists - the coach will appreciate any insights\n`;
    prompt += `  * ONLY use "${phrases.insufficientData}" when the project has literally nothing in it at all\n`;
    prompt += `- For EVERY statement or insight you make, cite the specific source(s) that support it\n`;
    prompt += `- Cite sources using SEPARATE parenthetical formats: (${citationLang.note} X) (${citationLang.marker} Y) (${citationLang.scheme} Z) (${citationLang.image} W)\n`;
    prompt += `- If you reference multiple sources, use SEPARATE parentheses for each: (${citationLang.note} 3) (${citationLang.note} 7) (${citationLang.marker} 2)\n`;
    prompt += `- Be specific - always indicate which note number, marker number, scheme number, or image number you're referencing\n`;
    prompt += `- CRITICAL CITATION RULE: When mentioning zone statistics, event counts, or coverage scores, you MUST ALWAYS include citations in the proper format. DO NOT write numbers in parentheses like "(3 events)" or "(coverage: 4)" without citations. These are NOT valid citations and will not be clickable.\n`;
    prompt += `- CORRECT FORMAT: "Team actively uses zone 3 for attacks (${citationLang.note} 22) (${citationLang.note} 23)" - this includes separate citations for each source\n`;
    prompt += `- WRONG FORMAT: "Team actively uses zone 3 for attacks (3 events)" - this has NO citations and is INVALID\n`;
    prompt += `- CORRECT FORMAT: "Zone 4 is well covered (${citationLang.note} 5) (${citationLang.marker} 2)" - this includes separate citations for each source\n`;
    prompt += `- WRONG FORMAT: "Zone 4 is well covered (coverage: 4)" - this has NO citations and is INVALID\n`;
    prompt += `- When referencing zone statistics event counts (e.g., "3 events in Zone 3"), you MUST cite ALL sources that contributed to that count. Zone statistics aggregate events from notes, markers, and schemes. If zone statistics show "Zone 3 (3 events)", you must find and cite all notes, markers, and schemes that mention Zone 3, not just some of them. If you cannot cite all sources for an event count, do not state the specific count - instead, say "multiple events" and cite what you can verify.\n`;
    prompt += `- When mentioning coverage scores, vulnerability scores, or any zone statistics, ALWAYS cite the sources. For example, instead of "coverage: 4", write "coverage: 4 (${citationLang.note} 5, ${citationLang.marker} 2)" or similar with actual citations.\n`;
    prompt += `- CRITICAL ANTI-HALLUCINATION RULE: Only state facts that are EXPLICITLY mentioned in the notes, markers, schemes, or images\n`;
    prompt += `- ABSOLUTE PROHIBITION ON INFERENCES: DO NOT make ANY assumptions, inferences, interpretations, or conclusions. DO NOT use inference language like:\n`;
    prompt += `  * "this indicates"\n`;
    prompt += `  * "which allows"\n`;
    prompt += `  * "may be"\n`;
    prompt += `  * "probably"\n`;
    prompt += `  * "this suggests"\n`;
    prompt += `  * "team prefers" - UNLESS explicitly stated\n`;
    prompt += `  * "team uses strategy" - UNLESS explicitly stated\n`;
    prompt += `  * Any conclusion about team preferences, strategies, or tactical approaches\n`;
    prompt += `- EXAMPLE OF WRONG (INFERENCE): "Team actively uses zone 3 for attacks, which indicates their preference to attack through central zones" - WRONG! The inference "preference to attack through central zones" is not in the data\n`;
    prompt += `- EXAMPLE OF CORRECT (FACT ONLY): "Team had attacks in zone 3 (${citationLang.note} 22, ${citationLang.note} 23)" - CORRECT! Only states the fact\n`;
    prompt += `- EXAMPLE OF WRONG (INFERENCE): "Zone 4 is well covered, which allows the team to defend effectively" - WRONG! The inference "which allows the team to defend effectively" is not in the data\n`;
    prompt += `- EXAMPLE OF CORRECT (FACT ONLY): "Zone 4 had defensive actions (${citationLang.note} 5, ${citationLang.marker} 2)" - CORRECT! Only states the fact\n`;
    prompt += `- EXAMPLE OF WRONG (INFERENCE): "Team uses a balanced approach, alternating attacks and defensive actions" - WRONG! This is an inference/conclusion not in the data\n`;
    prompt += `- EXAMPLE OF CORRECT (FACT ONLY): "Team had attacks in zone 3 and defensive actions in zone 4 (${citationLang.note} 22, ${citationLang.note} 23, ${citationLang.note} 5, ${citationLang.marker} 2)" - CORRECT! Only states facts\n`;
    prompt += `- If the data is insufficient to make a conclusion, use the phrase: "${phrases.insufficientData}" followed by text in the requested language explaining what cannot be assessed\n`;
    prompt += `- DO NOT invent details that are not in the source material\n`;
    prompt += `- EXAMPLE OF WRONG ANALYSIS: If a note only says "Final third attack" and "Zone 3", you CANNOT conclude: "lacks creativity", "reduced effectiveness", "poor finishing", "team prefers central attacks" - these are NOT mentioned in the data\n`;
    prompt += `- EXAMPLE OF CORRECT ANALYSIS: If a note says "Final third attack" and "Zone 3", you can only state: "The team had attacks in the final third (Zone 3) (${citationLang.note} X)" - nothing more, no inferences\n`;
    prompt += `- When citing, only reference what is actually written or shown - do not extrapolate beyond the data\n`;
    prompt += `- If you cannot make a meaningful analysis from the available data, say so explicitly rather than inventing conclusions or making inferences\n`;
    prompt += `- Analyze ALL teams that have ANY data - even minimal or unstructured information is valuable for analysis\n`;
    prompt += `- ABSOLUTELY NO MARKDOWN: Do NOT use ** for bold, __ for underline, ### for headers, * for italics, or ANY markdown symbols\n`;
    prompt += `- Write in plain text only - if you need emphasis, use ALL CAPS or write normally, but NEVER use asterisks or underscores\n`;
    prompt += `- Use clear line breaks and indentation for structure\n`;
    prompt += `- Example of WRONG format: **Important point** or *emphasis* or ### Header\n`;
    prompt += `- Example of CORRECT format: IMPORTANT POINT or Emphasis or HEADER\n`;

    return prompt;
  }

  // ========== COMMENT PROPERTY EXTRACTION ==========
  
  async function extractCommentProperties(commentText, apiKey, language = 'auto') {
    if (!commentText || !commentText.trim()) {
      throw new Error('Comment text is required');
    }
    
    if (!apiKey) {
      throw new Error('API key is required');
    }
    
    // Build list of all available events
    const allEvents = [
      // Possession phases
      'Build-up', 'Consolidation / Middle third possession', 'Final third attack', 'Counterattack', 'Transition defense', 'Set-piece attack', 'Set-piece defense',
      // Ball progression events
      'Progressive pass', 'Line-breaking pass', 'Third-man combination', 'Switch of play', 'Carry that bypasses a line', 'Successful dribble forward', 'Inside-channel progression', 'Half-space entry', 'Final third entry', 'Penalty box entry',
      // Chance creation events
      'Shot', 'Shot on target', 'Assist / key pass', 'Cutback', 'Through ball', 'Cross (successful)', 'Cross (unsuccessful)', 'Deep completion (dangerous pass inside 20m, no shot)', '1v1 attacking win', '1v1 attacking loss',
      // Defensive structure events
      'Pressing action', 'Pressing trap triggered', 'Ball recovery (high)', 'Ball recovery (mid)', 'Ball recovery (low)', 'Counterpress success', 'Counterpress failure', 'Defensive line broken', 'Block shot', 'Interception', 'Tackle/Duel won', 'Tackle/Duel lost', '1v1 defensive win', '1v1 defensive loss',
      // Transition events
      'Positive transition (winning the ball)', 'Negative transition (losing the ball)', 'Counterattack start', 'Dangerous turnover', 'Turnover leading to chance', 'Recovery leading to chance',
      // Set-piece tactical events
      'Corner attack', 'Corner defense', 'Free kick (crossing)', 'Free kick (shooting)', 'Throw-in routine (only if structured, e.g., long throw)', 'Second ball win', 'Second ball loss', 'Set-piece chance created',
      // Structural / off-ball tactical events
      'Overload created (right)', 'Overload created (left)', 'Overload created (central)', 'Overload lost', 'Bad spacing / poor distances', 'Line height shift (too high)', 'Line height shift (too low)', 'Offside trap activated (successful)', 'Offside trap activated (unsuccessful)', 'Numerical superiority achieved', 'Numerical superiority lost',
      // Error / critical moment events
      'Error leading to shot', 'Error leading to goal', 'Poor clearance', 'Bad decision under pressure', 'Miscommunication', 'Failed press',
      // Protocol recordings
      'Goal', 'Assist', 'Substitution', 'Penalty', 'Red card', 'Yellow card'
    ];
    
    const prompt = `You are a professional football analyst with 10 years of experience in the game. You know everything about tactics, strategy, zones, formations, players, schemes, and everything regarding football as a game. You are part of an analytical system that processes coach comments and extracts structured tactical data.

TASK: Analyze the following comment and extract the following properties:

⚠️ CRITICAL PLAYER NAME EXTRACTION - READ THIS FIRST:
As a professional football analyst, you MUST identify and extract ALL player names. A player name is:
- ANY capitalized word(s) that form a person's name (e.g., "Jovan Ivanovic", "Messi", "Ivanovic", "Jovan")
- If a name appears at the START of the comment, it is DEFINITELY a player
- If a name appears before an action verb (shoots, scores, passes, tackles, defends, etc.), it is a player
- Common patterns: "[Name] [action]" (e.g., "Jovan Ivanovic shots"), "[Name] after..." (e.g., "Jovan Ivanovic after..."), "[Name] from..."
- Extract the COMPLETE name if both first and last name are present (e.g., "Jovan Ivanovic" not just "Ivanovic")
- DO NOT skip player names - if you see "Jovan Ivanovic" in the text, you MUST extract it as ["Jovan Ivanovic"]

1. Teams: Team names mentioned (e.g., "Zrenjanin", "Real Madrid", "Barcelona")
2. Players: Player names mentioned - EXTRACT ALL PLAYER NAMES:
   - Examples: "Jovan Ivanovic", "Messi", "Ronaldo", "Ivanovic", "Jovan", "Cristiano Ronaldo"
   - If the comment starts with "Jovan Ivanovic after...", then "Jovan Ivanovic" MUST be in the players array
   - If you see any capitalized name that looks like a person's name, extract it as a player
3. Zones: Zone numbers (1-18) mentioned in the comment. Look for phrases like "zone 14", "zone X", or just numbers that refer to field zones.
4. Events: Event types from the list below that are mentioned or implied. Look for action words like "shot", "goal", "pass", "tackle", etc.
5. Intensity: A value from 0-4 based on the context:
   - 0: Full defense (defensive actions, defending deep)
   - 1: Defense (mostly defensive, some balance)
   - 2: Balance (neutral, mixed actions)
   - 3: Attack (mostly attacking, some balance)
   - 4: Full attack (aggressive attacking, high intensity attack, long attack)

AVAILABLE EVENTS:
${allEvents.map(e => `- ${e}`).join('\n')}

ZONE SYSTEM:
The field is divided into 18 zones (1-18). Zones are typically mentioned as "zone X" or "zone 14" etc.

INTENSITY INDICATORS:
- Words like "attack", "attacking", "long attack", "pressure", "scores", "shots" suggest higher intensity (3-4)
- Words like "defense", "defending", "deep", "retreat" suggest lower intensity (0-1)
- Neutral descriptions suggest balance (2)

EXAMPLES:
Example 1: "Jovan Ivanovic after a long attack from Zrenjanin shots from the zone 14 and scores a goal!"
Expected output:
{
  "teams": ["Zrenjanin"],
  "players": ["Jovan Ivanovic"],
  "zones": [14],
  "events": ["Shot", "Goal"],
  "intensity": 4
}
Note: "Jovan Ivanovic" is a player name (two capitalized words at the start of the sentence).

Example 2: "Messi passes to Ronaldo who scores"
Expected output:
{
  "teams": [],
  "players": ["Messi", "Ronaldo"],
  "zones": [],
  "events": ["Assist / key pass", "Goal"],
  "intensity": 3
}

Example 3: "Ivanovic tackles the ball in zone 5"
Expected output:
{
  "teams": [],
  "players": ["Ivanovic"],
  "zones": [5],
  "events": ["Tackle/Duel won"],
  "intensity": 1
}

COMMENT TEXT TO ANALYZE:
"${commentText}"

STEP-BY-STEP ANALYSIS (MANDATORY):
1. FIRST STEP - Scan the entire comment for ALL capitalized words that look like person names
2. If a name appears at the START of the comment (e.g., "Jovan Ivanovic after..."), it is DEFINITELY a player - EXTRACT IT
3. If a name appears before an action verb (shoots, scores, passes, tackles, defends, etc.), it is a player - EXTRACT IT
4. Extract the COMPLETE name (both first and last name if present, e.g., "Jovan Ivanovic" not just "Ivanovic")
5. DO NOT leave the players array empty if you see any person's name in the comment

CRITICAL EXTRACTION RULES:
1. PLAYER NAMES (HIGHEST PRIORITY - DO NOT SKIP):
   - ANY capitalized word(s) that form a person's name MUST be extracted as a player - NO EXCEPTIONS
   - Pattern: "FirstName LastName" (e.g., "Jovan Ivanovic") → Extract as ["Jovan Ivanovic"]
   - Pattern: "LastName" (e.g., "Ivanovic") → Extract as ["Ivanovic"]
   - Pattern: "FirstName" (e.g., "Jovan") → Extract as ["Jovan"]
   - If a name appears at the START of the sentence, it's ALWAYS a player - EXTRACT IT
   - If a name appears before an action verb (shoots, scores, passes, tackles, defends, etc.), it's a player - EXTRACT IT
   - Common patterns: "[Name] after...", "[Name] shots...", "[Name] scores...", "[Name] passes..."
   - Extract the COMPLETE name if both first and last name are present (e.g., "Jovan Ivanovic" not just "Ivanovic")
   - MANDATORY: If the comment contains "Jovan Ivanovic", the players array MUST contain "Jovan Ivanovic" - DO NOT return empty array []
   - MANDATORY: If you see ANY person's name, it MUST appear in the players array

2. TEAMS: Extract team names (usually single capitalized words or city names)

3. ZONES: Extract zone numbers (1-18) when mentioned with "zone" or as standalone numbers referring to field zones

4. EVENTS: Map action words to event types from the list above

5. INTENSITY: Infer from context (0-4 scale)

Return ONLY valid JSON, no other text

RESPONSE FORMAT (JSON only):
{
  "teams": ["team name 1", "team name 2"],
  "players": ["player name 1", "player name 2"],
  "zones": [14, 15],
  "events": ["Shot", "Goal"],
  "intensity": 3
}

If a property is not found, use an empty array [] or null:
- teams: [] if no teams mentioned
- players: [] if no players mentioned
- zones: [] if no zones mentioned
- events: [] if no events mentioned
- intensity: null if cannot determine

Return ONLY the JSON object, no explanations or markdown formatting.`;

    try {
      const response = await proxyFetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content: 'You are a professional football analyst with 10 years of experience in the game. You know everything about tactics, strategy, zones, formations, players, schemes, and everything regarding football as a game. You are part of an analytical system that processes coach comments and extracts structured tactical data.\n\nCRITICAL PLAYER NAME EXTRACTION RULE - MANDATORY:\nYou MUST extract ALL player names mentioned in the text. A player name is ANY capitalized name (first name, last name, or both) that appears in the comment.\n\nEXAMPLES:\n- If you see "Jovan Ivanovic after a long attack..." → Extract as players: ["Jovan Ivanovic"]\n- If you see "Messi scores..." → Extract as players: ["Messi"]\n- If you see "Ivanovic tackles..." → Extract as players: ["Ivanovic"]\n\nRULES:\n1. Names at the start of sentences are ALWAYS players - EXTRACT THEM\n2. Names before action verbs (shoots, scores, passes, tackles, defends, etc.) are ALWAYS players - EXTRACT THEM\n3. Two capitalized words together (e.g., "Jovan Ivanovic") are ALWAYS a player name - EXTRACT THEM\n4. DO NOT skip player names - if you see a person\'s name, it MUST appear in the players array\n5. Extract the COMPLETE name (e.g., "Jovan Ivanovic" not just "Ivanovic")\n\nAlways respond with valid JSON only, no explanations.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 500,
          response_format: { type: 'json_object' }
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          throw new Error('Invalid API key. Please check your OpenAI API key.');
        }
        throw new Error(errorData.error?.message || `API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices[0]?.message?.content;
      
      if (!content) {
        throw new Error('No response from AI');
      }

      // Parse JSON response
      let extracted;
      try {
        extracted = JSON.parse(content);
      } catch (e) {
        // Try to extract JSON from markdown code blocks if present
        const jsonMatch = content.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/);
        if (jsonMatch) {
          extracted = JSON.parse(jsonMatch[1]);
        } else {
          throw new Error('Invalid JSON response from AI');
        }
      }

      // Validate and normalize response
      const result = {
        teams: Array.isArray(extracted.teams) ? extracted.teams.filter(t => t && t.trim()) : [],
        players: Array.isArray(extracted.players) ? extracted.players.filter(p => p && p.trim()) : [],
        zones: Array.isArray(extracted.zones) ? extracted.zones.filter(z => typeof z === 'number' && z >= 1 && z <= 18) : [],
        events: Array.isArray(extracted.events) ? extracted.events.filter(e => e && e.trim()) : [],
        intensity: typeof extracted.intensity === 'number' && extracted.intensity >= 0 && extracted.intensity <= 4 ? extracted.intensity : null
      };

      return result;
    } catch (error) {
      console.error('Error extracting comment properties:', error);
      throw error;
    }
  }

  // ========== SYSTEM PROMPT ==========
  
  function getSystemPrompt() {
    return 'You are a professional football analyst with 10 years of experience in the game. You know everything about tactics, strategy, zones, formations, players, schemes, and everything regarding football as a game. You are part of an analytical system that processes tactical data and provides insights to coaches. You specialize in zone-based tactical analysis and help coaches understand their team\'s and competitors\' game plans, identify strengths and weaknesses by zone, and provide actionable recommendations for match preparation.\n\nCRITICAL RULES - ABSOLUTE STRICTNESS REQUIRED:\n1. ONLY state facts that are EXPLICITLY written in the provided data. Do NOT make ANY assumptions, inferences, interpretations, or conclusions.\n2. DO NOT use phrases like "this indicates", "which allows", "may be", "probably", or any other inference language.\n3. DO NOT make conclusions about team preferences, strategies, or tactical approaches unless explicitly stated in the notes/markers/schemes.\n4. DO NOT interpret data - only report what is explicitly written. For example, if a note says "attack in zone 3", you can ONLY say "attacks occurred in zone 3" - NOT "team prefers attacking through central zones" or "team strategy focuses on zone 3".\n5. SKIP TEAMS/SECTIONS WITH NO DATA - CRITICAL: If a team has no actual tactical data (no notes with content, no events, no zones mentioned), DO NOT include that team in your response at all. Do NOT list teams just to say "insufficient data" - simply omit them entirely. If ALL teams have insufficient data, write ONE brief sentence and stop.\n6. Provide insights based ONLY on what is actually written in coach notes, timeline markers, and tactical diagrams - nothing more.\n7. Focus on zone-based analysis: Report which zones (1-18) teams used for attacks and which zones had defensive actions, but ONLY if explicitly mentioned in the data.\n8. MANDATORY CITATION REQUIREMENT - ABSOLUTELY CRITICAL: For EVERY statement, insight, or factual claim you make, you MUST cite the specific source(s) that support it using the format (Note X), (Marker Y), (Scheme Z), or (Image W). This is NOT optional - citations are REQUIRED for every factual statement. If you cannot cite a source, DO NOT make that statement. NO EXCEPTIONS.\n9. CITATION FORMAT RULE: When mentioning zone statistics, event counts, or coverage scores, you MUST ALWAYS include citations in the proper format. DO NOT write numbers in parentheses like "(3 events)" or "(coverage: 4)" without citations - these are NOT valid citations and will not be clickable. Always use the format like "(Note 22, Note 23)" or "(Marker 5, Scheme 2)" depending on the language.\n10. Every factual statement MUST be traceable to a specific note, marker, scheme, or image. Do not make unsupported claims. Without a citation, a statement is invalid.\n11. ANTI-INFERENCE RULE: DO NOT make any statements that require interpretation or inference. Examples of FORBIDDEN statements:\n    - "This indicates..."\n    - "Which allows..."\n    - "May be..."\n    - "Team prefers..." (unless explicitly stated)\n    - "Team strategy..." (unless explicitly stated)\n    - "This suggests..."\n    - Any conclusion about team preferences, strategies, or tactical approaches\n12. ONLY report explicit facts: "Team X had attacks in zone 3 (Note 22, Note 23)" is CORRECT. "Team X prefers attacking through zone 3" is WRONG unless explicitly stated.\n13. CONSISTENCY REQUIREMENT: When analyzing the same data, provide consistent insights. Base your analysis strictly on the provided data and maintain consistency across multiple analyses of the same dataset.\n14. USER TEAM FOCUS: When a user\'s team is designated, clearly distinguish between:\n    - Improvement recommendations for the user\'s team (how to enhance their performance, address weaknesses, optimize tactics)\n    - Competitive analysis for opponent teams (how to exploit their weaknesses, counter their strengths, defend against their tactics)\n15. ANTI-HALLUCINATION: Every factual statement must be traceable to specific notes, markers, schemes, or images. Do not make unsupported claims or inferences beyond what is explicitly stated in the data.\n16. HISTORICAL COMMENTS USAGE: If historical comments from previous projects are provided, use them to identify patterns and trends across multiple projects. Compare current project observations with historical patterns to identify consistency or changes. When citing historical comments, use the format specified in the prompt (e.g., "Historical Comment X from Project Y"). Historical data should support pattern recognition and provide context, but current project data takes precedence. If historical data contradicts current observations, note both and explain the context.\n17. BE CONCISE: Do not waste output on teams/sections with no data. Only write about what you can actually analyze with citations.';
  }

  // ========== VOICE INPUT / WHISPER API ==========
  
  let mediaRecorder = null;
  let audioChunks = [];
  let audioStream = null;

  /**
   * Start recording audio from the microphone
   * @returns {Promise<void>}
   */
  async function startRecording() {
    try {
      // Request microphone access
      audioStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      // Determine the best audio format supported by the browser
      // Whisper API accepts: mp3, mp4, mpeg, mpga, m4a, wav, webm
      // Prefer simpler mime types that Whisper definitely accepts
      let mimeType = '';
      if (MediaRecorder.isTypeSupported('audio/webm')) {
        mimeType = 'audio/webm';
      } else if (MediaRecorder.isTypeSupported('audio/wav')) {
        mimeType = 'audio/wav';
      } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
        mimeType = 'audio/mp4';
      } else if (MediaRecorder.isTypeSupported('audio/mpeg')) {
        mimeType = 'audio/mpeg';
      } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
        mimeType = 'audio/ogg';
      } else {
        // Let browser choose default, but we'll normalize it later
        mimeType = '';
      }

      // Initialize MediaRecorder
      mediaRecorder = new MediaRecorder(audioStream, {
        mimeType: mimeType
      });

      audioChunks = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunks.push(event.data);
        }
      };

      // Start recording with timeslice to ensure data is collected regularly
      // Timeslice of 1000ms (1 second) ensures we get data chunks regularly
      mediaRecorder.start(1000);
      return Promise.resolve();
    } catch (error) {
      console.error('Error starting recording:', error);
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        throw new Error('Microphone permission denied. Please allow microphone access in your browser settings.');
      } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
        throw new Error('No microphone found. Please connect a microphone and try again.');
      } else {
        throw new Error('Failed to start recording: ' + error.message);
      }
    }
  }

  /**
   * Stop recording and return audio blob
   * @returns {Promise<Blob>}
   */
  function stopRecording() {
    return new Promise((resolve, reject) => {
      if (!mediaRecorder || mediaRecorder.state === 'inactive') {
        reject(new Error('No active recording to stop'));
        return;
      }

      mediaRecorder.onstop = () => {
        // Normalize mime type - remove codec specifications for Whisper compatibility
        let normalizedMimeType = mediaRecorder.mimeType || 'audio/webm';
        if (normalizedMimeType.includes('webm')) {
          normalizedMimeType = 'audio/webm';
        } else if (normalizedMimeType.includes('wav')) {
          normalizedMimeType = 'audio/wav';
        } else if (normalizedMimeType.includes('mp4') || normalizedMimeType.includes('m4a')) {
          normalizedMimeType = 'audio/mp4';
        } else if (normalizedMimeType.includes('mpeg') || normalizedMimeType.includes('mp3')) {
          normalizedMimeType = 'audio/mpeg';
        } else if (normalizedMimeType.includes('ogg')) {
          normalizedMimeType = 'audio/ogg';
        }
        
        const audioBlob = new Blob(audioChunks, { type: normalizedMimeType });
        
        // Validate blob has data
        if (audioBlob.size === 0) {
          reject(new Error('Recording produced no audio data. Please try again.'));
          return;
        }
        
        // Stop all tracks to release microphone
        if (audioStream) {
          audioStream.getTracks().forEach(track => track.stop());
          audioStream = null;
        }
        
        mediaRecorder = null;
        audioChunks = [];
        resolve(audioBlob);
      };

      mediaRecorder.onerror = (event) => {
        reject(new Error('Recording error: ' + (event.error?.message || 'Unknown error')));
      };

      // Request any remaining data before stopping
      if (mediaRecorder.state === 'recording') {
        mediaRecorder.requestData();
      }
      
      mediaRecorder.stop();
    });
  }

  /**
   * Convert audio blob to File object for Whisper API
   * @param {Blob} audioBlob - The audio blob to convert
   * @param {string} filename - Optional filename
   * @returns {File}
   */
  function convertAudioToFile(audioBlob, filename = 'recording.webm') {
    // Whisper API accepts: mp3, mp4, mpeg, mpga, m4a, wav, webm
    // Determine file extension and mime type based on blob type
    let extension = 'webm';
    let mimeType = audioBlob.type || 'audio/webm';
    
    // Normalize mime type and extension
    if (audioBlob.type) {
      if (audioBlob.type.includes('webm')) {
        extension = 'webm';
        mimeType = 'audio/webm';
      } else if (audioBlob.type.includes('ogg') || audioBlob.type.includes('opus')) {
        extension = 'ogg';
        mimeType = 'audio/ogg';
      } else if (audioBlob.type.includes('wav')) {
        extension = 'wav';
        mimeType = 'audio/wav';
      } else if (audioBlob.type.includes('mp4') || audioBlob.type.includes('m4a')) {
        extension = 'm4a';
        mimeType = 'audio/mp4';
      } else if (audioBlob.type.includes('mp3') || audioBlob.type.includes('mpeg')) {
        extension = 'mp3';
        mimeType = 'audio/mpeg';
      }
    }
    
    // Ensure we have a valid mime type
    if (!mimeType || mimeType === 'application/octet-stream') {
      mimeType = 'audio/webm';
      extension = 'webm';
    }

    const finalFilename = filename.replace(/\.[^.]+$/, '') + '.' + extension;
    return new File([audioBlob], finalFilename, { type: mimeType });
  }

  /**
   * Transcribe audio using Whisper-1 API
   * @param {File} audioFile - The audio file to transcribe
   * @param {string} apiKey - OpenAI API key
   * @returns {Promise<string>} - Transcribed text
   */
  async function transcribeAudio(audioFile, apiKey) {
    if (!apiKey) {
      throw new Error('OpenAI API key is required for voice transcription');
    }

    if (!audioFile) {
      throw new Error('Audio file is required');
    }

    // Validate file size (Whisper has a 25MB limit, but we'll check for reasonable size)
    if (audioFile.size === 0) {
      throw new Error('Audio file is empty. Please try recording again.');
    }

    if (audioFile.size > 25 * 1024 * 1024) {
      throw new Error('Audio file is too large (max 25MB). Please record a shorter audio clip.');
    }

    try {
      const formData = new FormData();
      formData.append('file', audioFile);
      formData.append('model', 'whisper-1');
      
      // Log file info for debugging (in development)
      if (console && console.log) {
        console.log('Transcribing audio file:', {
          name: audioFile.name,
          type: audioFile.type,
          size: audioFile.size
        });
      }

      const response = await proxyFetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`
        },
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          throw new Error('Invalid API key. Please check your OpenAI API key.');
        } else if (response.status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        } else if (response.status === 500 || response.status === 503) {
          throw new Error('OpenAI service is temporarily unavailable. Please try again later.');
        } else {
          throw new Error(errorData.error?.message || `API error: ${response.status}`);
        }
      }

      const data = await response.json();
      if (data.text) {
        return data.text.trim();
      } else {
        throw new Error('Unexpected response format from Whisper API');
      }
    } catch (error) {
      if (error.message) {
        throw error;
      } else if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your internet connection.');
      } else {
        throw new Error('An unexpected error occurred while transcribing audio: ' + error.message);
      }
    }
  }

  // Export all functions
  if (typeof window !== 'undefined') {
    window.aiAnalysisUtils = window.aiAnalysisUtils || {};
    window.aiAnalysisUtils.loadOpenAIKey = loadOpenAIKey;
    window.aiAnalysisUtils.validateAPIKey = validateAPIKey;
    window.aiAnalysisUtils.proxyFetch = proxyFetch;
    window.aiAnalysisUtils.collectAnalysisData = collectAnalysisData;
    window.aiAnalysisUtils.retrieveRelevantComments = retrieveRelevantComments;
    window.aiAnalysisUtils.getZoneNumber = getZoneNumber;
    window.aiAnalysisUtils.isPointInShape = isPointInShape;
    window.aiAnalysisUtils.getZonesForShape = getZonesForShape;
    window.aiAnalysisUtils.describeDrawing = describeDrawing;
    window.aiAnalysisUtils.analyzeZonePatterns = analyzeZonePatterns;
    window.aiAnalysisUtils.calculateZoneStatistics = calculateZoneStatistics;
    window.aiAnalysisUtils.identifyGamePlan = identifyGamePlan;
    window.aiAnalysisUtils.compareTeams = compareTeams;
    window.aiAnalysisUtils.formatDataForAI = formatDataForAI;
    window.aiAnalysisUtils.getSystemPrompt = getSystemPrompt;
    window.aiAnalysisUtils.extractCommentProperties = extractCommentProperties;
    window.aiAnalysisUtils.startRecording = startRecording;
    window.aiAnalysisUtils.stopRecording = stopRecording;
    window.aiAnalysisUtils.convertAudioToFile = convertAudioToFile;
    window.aiAnalysisUtils.transcribeAudio = transcribeAudio;
  }
})();
