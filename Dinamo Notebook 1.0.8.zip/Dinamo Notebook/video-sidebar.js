// Multi-Platform Video Dinamo Notebook Content Script

// ========== MINIMAL CONTENT SCRIPT INITIALIZATION ==========
// No violation suppression - let YouTube warnings show (they're not our fault)

// Mark that content script is loaded
window.distatsContentScriptReady = true;
(function() {
  'use strict';

  // Platform detection function (must be defined before use)
  function detectPlatform() {
    const hostname = window.location.hostname.toLowerCase();
    
    if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
      return 'youtube';
    } else if (hostname.includes('dailymotion.com')) {
      return 'dailymotion';
    } else if (hostname.includes('twitch.tv')) {
      return 'twitch';
    }
    
    return 'unknown';
  }

  // Detect current platform
  const platform = detectPlatform();

  // Global variables
  let currentAnalysisId = null;
  let currentVideoId = null;
  let currentVideoUrl = null;
  let sidebarVisible = false;
  let isProcessingUrl = false; // Flag to prevent duplicate URL processing
  let pendingImages = []; // Store compressed image data array
  let isLoadingAnalysis = false; // Flag to prevent recursive calls to loadCurrentAnalysis
  let loadAnalysisDebounceTimer = null; // Timer for debouncing loadCurrentAnalysis calls
  let isCreatingProject = false; // Flag to prevent storage listener from firing during project creation
  let selectedTeam = null; // Keep for backward compatibility with analysis.selectedTeam
  let selectedTeams = []; // Array for multiple team selection
  let selectedEvents = []; // Selected events for current message
  let selectedZones = []; // Selected zones for current message
  let selectedPlayers = []; // Selected players for current message
  let selectedIntensity = null; // Selected intensity for current message
  
  // Global references to display elements
  let selectedTeamDisplay = null;
  let selectedPlayersDisplay = null;

  // Helper function to update project button text with translation
  function updateProjectButtonText() {
    const projectButtonText = document.getElementById('distatsProjectButtonText');
    if (!projectButtonText) return;
    
    // Only update if no project is selected (otherwise keep the project name)
    if (!currentAnalysisId) {
      projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
    }
  }
  let imagePreviewContainer = null;
  let attachImageBtn = null;
  function ensureImagePreviewElements() {
    if (!imagePreviewContainer) {
      imagePreviewContainer = document.getElementById('distatsImagePreviewContainer');
    }
    if (!attachImageBtn) {
      attachImageBtn = document.getElementById('distatsAttachImageBtn');
    }
    return imagePreviewContainer;
  }

  function openEditorWindowWithImage(imageData, onSaveCallback, slidesData = null, originalImageSrc = null) {
    if (!imageData) return;
    
    // Extract imageData string if it's an object
    let actualImageData = imageData;
    if (typeof imageData === 'object' && imageData !== null) {
      actualImageData = imageData.imageData || imageData;
    }
    // Ensure it's a string
    if (typeof actualImageData !== 'string') {
      console.error('openEditorWindowWithImage: imageData must be a string, got:', typeof actualImageData);
      return;
    }

    const editorDataId = 'editor_' + Date.now();

    window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};
    window.pendingEditorCallbacks[editorDataId] = (modifiedImageData, slidesData, savedOriginalImageSrc) => {
      console.log(': Callback received:', {
        hasImageData: !!modifiedImageData,
        hasSlidesData: !!slidesData,
        slidesDataLength: slidesData ? slidesData.length : 0,
        firstSlideDrawings: slidesData && slidesData[0] ? (slidesData[0].drawings ? slidesData[0].drawings.length : 0) : 0,
        hasOriginalSrc: !!savedOriginalImageSrc
      });
      if (typeof onSaveCallback === 'function') {
        onSaveCallback(modifiedImageData, slidesData, savedOriginalImageSrc);
      }
    };

    const storageData = {
      pendingEditorImageSrc: actualImageData, // Use the extracted string
      pendingEditorCallbackId: editorDataId,
      pendingEditorCallbackContext: 'sidebar',
      pendingEditorSlidesData: slidesData || null, // Always set, even if null, to ensure fresh start
      pendingEditorOriginalImageSrc: originalImageSrc || null
    };

    chrome.storage.local.set(storageData, () => {
      chrome.runtime.sendMessage({
        action: 'openEditorWindow',
        source: 'sidebar',
        width: 1200,
        height: 800
      }, (response) => {
        if (chrome.runtime.lastError || !response || !response.success) {
          console.error(': Failed to open editor via background (preview/helper)', chrome.runtime.lastError, response);
          const fallbackWindow = window.open(chrome.runtime.getURL('editor.html'), 'tacticalEditor', 'width=1200,height=800');
          if (!fallbackWindow) {
            alert(window.i18n ? window.i18n.t('messages.pleaseAllowPopups') : 'Please allow popups to open the editor');
          }
        }
      });
    });
  }

  function updateImagePreview() {
    const previewContainer = ensureImagePreviewElements();
    if (!previewContainer) return;

    if (pendingImages.length === 0) {
      previewContainer.style.display = 'none';
      previewContainer.innerHTML = '';
      return;
    }

    previewContainer.style.display = 'flex';
    previewContainer.innerHTML = '';

    pendingImages.forEach((imageObj, index) => {
      const previewItem = document.createElement('div');
      previewItem.className = 'image-preview-item';
      previewItem.style.position = 'relative';

      const img = document.createElement('img');
      img.src = imageObj.imageData;
      img.className = 'image-preview';
      img.alt = `Preview ${index + 1}`;
      img.style.cursor = 'pointer';
      const clickToEditText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('messages.clickToEdit')
        : 'Click to edit in tactical editor';
      img.title = clickToEditText;

      img.addEventListener('click', () => {
        openEditorWindowWithImage(imageObj.imageData, (modifiedImageData, slidesData) => {
          pendingImages[index] = { imageData: modifiedImageData, slidesData: slidesData };
          updateImagePreview();
        }, imageObj.slidesData);
      });

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-image-preview';
      removeBtn.textContent = '×';
      const removeImageText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('messages.removeImage')
        : 'Remove image';
      removeBtn.title = removeImageText;
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        pendingImages.splice(index, 1);
        updateImagePreview();
      });

      previewItem.appendChild(img);
      previewItem.appendChild(removeBtn);
      previewContainer.appendChild(previewItem);
    });
  }

  function hideImagePreview() {
    pendingImages = [];
    updateImagePreview();
    ensureImagePreviewElements();
    if (attachImageBtn) {
      attachImageBtn.disabled = false;
    }
  }
  
  // Initialize pendingEditorCallbacks
  window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};

  // Helper function to check if extension context is valid
  function isExtensionContextValid() {
    try {
      return chrome && chrome.runtime && chrome.runtime.id;
    } catch (e) {
      return false;
    }
  }

  // Helper function to handle storage errors
  function openEditorWindowWithImage(imageData, onSaveCallback) {
    if (!imageData) return;

    const editorDataId = 'editor_' + Date.now();
    window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};
    window.pendingEditorCallbacks[editorDataId] = (modifiedImageData, slidesData) => {
      if (typeof onSaveCallback === 'function') {
        onSaveCallback(modifiedImageData, slidesData);
      }
    };

    chrome.storage.local.set({
      pendingEditorImageSrc: imageData,
      pendingEditorCallbackId: editorDataId,
      pendingEditorCallbackContext: 'sidebar'
    }, () => {
      chrome.runtime.sendMessage({
        action: 'openEditorWindow',
        source: 'sidebar',
        width: 1200,
        height: 800
      }, (response) => {
        if (chrome.runtime.lastError || !response || !response.success) {
          console.error(': Failed to open editor via background (preview/helper)', chrome.runtime.lastError, response);
          const fallbackWindow = window.open(chrome.runtime.getURL('editor.html'), 'tacticalEditor', 'width=1200,height=800');
          if (!fallbackWindow) {
            alert(window.i18n ? window.i18n.t('messages.pleaseAllowPopups') : 'Please allow popups to open the editor');
          }
        }
      });
    });
  }

  // Render image with drawings for preview
  function renderImagePreviewWithDrawings(backgroundImageData, drawings) {
    return new Promise((resolve, reject) => {
      if (!drawings || drawings.length === 0) {
        resolve(backgroundImageData);
        return;
      }

      const bgImg = new Image();
      bgImg.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = bgImg.width;
        canvas.height = bgImg.height;
        const ctx = canvas.getContext('2d');
        
        // Draw background
        ctx.drawImage(bgImg, 0, 0);
        
        // Draw drawings (simplified version for preview)
        // Include movement lines (animpath) to show tactical movements in citation previews
        drawings.forEach(drawing => {
          if (!drawing) return;
          
          // Handle movement paths (animpath) - these show tactical movements
          if (drawing.type === 'animpath') {
            if (drawing.points && drawing.points.length > 1) {
              ctx.save();
              const opacity = drawing.opacity !== undefined ? drawing.opacity : 0.8;
              ctx.globalAlpha = Math.min(opacity, 1.0);
              ctx.strokeStyle = drawing.color || '#FF0000';
              ctx.fillStyle = drawing.color || '#FF0000';
              // Make movement lines more visible
              ctx.lineWidth = (drawing.lineWidth || 3) * 1.5;
              ctx.setLineDash([]);
              
              // Draw path
              ctx.beginPath();
              ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
              for (let i = 1; i < drawing.points.length; i++) {
                ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
              }
              ctx.stroke();
              
              // Draw arrowhead at the end to show direction
              if (drawing.points.length >= 2) {
                const lastPoint = drawing.points[drawing.points.length - 1];
                const secondLastPoint = drawing.points[drawing.points.length - 2];
                const angle = Math.atan2(lastPoint.y - secondLastPoint.y, lastPoint.x - secondLastPoint.x);
                const arrowLength = 12;
                
                ctx.beginPath();
                ctx.moveTo(lastPoint.x, lastPoint.y);
                ctx.lineTo(
                  lastPoint.x - arrowLength * Math.cos(angle - Math.PI / 6),
                  lastPoint.y - arrowLength * Math.sin(angle - Math.PI / 6)
                );
                ctx.lineTo(
                  lastPoint.x - arrowLength * Math.cos(angle + Math.PI / 6),
                  lastPoint.y - arrowLength * Math.sin(angle + Math.PI / 6)
                );
                ctx.closePath();
                ctx.fill();
              }
              
              ctx.restore();
            }
            return;
          }
          
          ctx.save();
          const opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
          ctx.globalAlpha = Math.min(opacity, 1.0);
          ctx.strokeStyle = drawing.color || '#FF0000';
          ctx.fillStyle = drawing.color || '#FF0000';
          ctx.lineWidth = drawing.lineWidth || 2;
          
          // Apply line style
          if (drawing.lineStyle === 'dashed') {
            ctx.setLineDash([8, 4]);
          } else if (drawing.lineStyle === 'dotted') {
            ctx.setLineDash([2, 2]);
          } else {
            ctx.setLineDash([]);
          }
          
          // Draw based on type (simplified for preview)
          switch (drawing.type) {
            case 'line':
              ctx.beginPath();
              ctx.moveTo(drawing.startX, drawing.startY);
              ctx.lineTo(drawing.endX, drawing.endY);
              ctx.stroke();
              break;
            case 'arrow':
              ctx.beginPath();
              ctx.moveTo(drawing.startX, drawing.startY);
              ctx.lineTo(drawing.endX, drawing.endY);
              ctx.stroke();
              
              // Draw arrowhead
              if (drawing.endX !== undefined && drawing.endY !== undefined && drawing.startX !== undefined && drawing.startY !== undefined) {
                const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
                const arrowLength = 10;
                
                ctx.beginPath();
                ctx.moveTo(drawing.endX, drawing.endY);
                ctx.lineTo(
                  drawing.endX - arrowLength * Math.cos(angle - Math.PI / 6),
                  drawing.endY - arrowLength * Math.sin(angle - Math.PI / 6)
                );
                ctx.lineTo(
                  drawing.endX - arrowLength * Math.cos(angle + Math.PI / 6),
                  drawing.endY - arrowLength * Math.sin(angle + Math.PI / 6)
                );
                ctx.closePath();
                ctx.fill();
              }
              break;
            case 'curve':
              if (drawing.controlPoint) {
                ctx.beginPath();
                ctx.moveTo(drawing.startX, drawing.startY);
                ctx.quadraticCurveTo(drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY);
                ctx.stroke();
              }
              break;
            case 'circle':
              const radius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
              const centerX = (drawing.startX + drawing.endX) / 2;
              const centerY = (drawing.startY + drawing.endY) / 2;
              ctx.beginPath();
              ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
              if (drawing.fillOpacity > 0) {
                ctx.globalAlpha = drawing.fillOpacity;
                ctx.fillStyle = drawing.fillColor || drawing.color;
                ctx.fill();
              }
              ctx.globalAlpha = opacity;
              ctx.beginPath();
              ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
              ctx.stroke();
              break;
            case 'ball':
              // Draw simplified ball representation
              const ballSize = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY));
              const ballX = Math.min(drawing.startX, drawing.endX);
              const ballY = Math.min(drawing.startY, drawing.endY);
              ctx.fillStyle = drawing.color || '#FFFFFF';
              ctx.beginPath();
              ctx.arc(ballX + ballSize / 2, ballY + ballSize / 2, ballSize / 2, 0, Math.PI * 2);
              ctx.fill();
              break;
            case 'tshirt':
              // Draw proper t-shirt shape
              const tshirtCenterX = (drawing.startX + drawing.endX) / 2;
              const tshirtCenterY = (drawing.startY + drawing.endY) / 2;
              const shirtWidth = Math.abs(drawing.endX - drawing.startX);
              const shirtHeight = Math.abs(drawing.endY - drawing.startY);
              const startX = tshirtCenterX - shirtWidth / 2;
              const startY = tshirtCenterY - shirtHeight / 2;
              
              const primaryColor = drawing.color || '#FFFFFF';
              const secondColor = drawing.secondColor || '#000000';
              const design = drawing.design || 'solid';
              
              // T-shirt proportions
              const collarWidth = shirtWidth * 0.35;
              const shoulderWidth = (shirtWidth - collarWidth) / 2;
              const sleeveLength = shirtWidth * 0.18;
              
              // Create t-shirt path
              ctx.beginPath();
              ctx.moveTo(startX, startY + shirtHeight * 0.08);
              ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
              ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
              ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
              const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
              ctx.lineTo(rightBottomX, startY + shirtHeight);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
              ctx.lineTo(startX, startY + shirtHeight * 0.38);
              ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
              ctx.closePath();
              
              // Fill base color
              ctx.fillStyle = primaryColor;
              ctx.fill();
              
              // Apply design pattern (simplified for preview)
              if (design !== 'solid') {
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(startX, startY + shirtHeight * 0.08);
                ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
                ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
                ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
                ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
                ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
                ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
                ctx.lineTo(rightBottomX, startY + shirtHeight);
                ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
                ctx.lineTo(startX, startY + shirtHeight * 0.38);
                ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
                ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
                ctx.closePath();
                ctx.clip();
                
                const extLeft = startX - sleeveLength;
                const extRight = startX + shirtWidth + sleeveLength;
                const extTop = startY;
                const extBottom = startY + shirtHeight;
                const extWidth = extRight - extLeft;
                const extHeight = extBottom - extTop;
                
                ctx.fillStyle = secondColor;
                if (design === 'sleeves') {
                  ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
                  ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
                } else if (design === 'horiz-stripes') {
                  const hStripeHeight = extHeight / 5;
                  for (let i = 1; i < 5; i += 2) {
                    ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
                  }
                } else if (design === 'vert-stripes') {
                  const vStripeWidth = extWidth / 5;
                  for (let i = 1; i < 5; i += 2) {
                    ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
                  }
                }
                ctx.restore();
              }
              
              // Draw outline
              ctx.beginPath();
              ctx.moveTo(startX, startY + shirtHeight * 0.08);
              ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
              ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
              ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
              ctx.lineTo(rightBottomX, startY + shirtHeight);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
              ctx.lineTo(startX, startY + shirtHeight * 0.38);
              ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
              ctx.closePath();
              ctx.strokeStyle = '#000000';
              ctx.lineWidth = 2;
              ctx.stroke();
              
              // Draw number if available
              if (drawing.number !== undefined && drawing.number !== null && drawing.number !== '') {
                const hex = primaryColor.replace('#', '');
                const r = parseInt(hex.substr(0, 2), 16);
                const g = parseInt(hex.substr(2, 2), 16);
                const b = parseInt(hex.substr(4, 2), 16);
                const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
                const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
                ctx.fillStyle = textColor;
                ctx.font = `bold ${shirtHeight * 0.25}px sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(String(drawing.number), tshirtCenterX, tshirtCenterY);
              }
              break;
            case 'text':
              ctx.font = `${drawing.fontSize || 16}px sans-serif`;
              ctx.fillStyle = drawing.color || '#FFFFFF';
              ctx.fillText(drawing.text || '', drawing.x || 0, drawing.y || 0);
              break;
            case 'spray':
              // Draw spray particles
              if (drawing.particles && drawing.particles.length > 0) {
                ctx.fillStyle = drawing.color || '#000000';
                ctx.globalAlpha = opacity; // Ensure opacity is applied
                const particleSize = drawing.particleSize || 2;
                drawing.particles.forEach(particle => {
                  ctx.beginPath();
                  ctx.arc(particle.x, particle.y, particleSize, 0, Math.PI * 2);
                  ctx.fill();
                });
              }
              break;
            case 'rectangle':
            case 'oval':
            case 'triangle':
            case 'polygon':
            case 'arc':
            case 'cross':
            case 'freehand':
              // Draw basic shape outline
              if (drawing.type === 'rectangle') {
                const rectLeft = Math.min(drawing.startX, drawing.endX);
                const rectTop = Math.min(drawing.startY, drawing.endY);
                const rectWidth = Math.abs(drawing.endX - drawing.startX);
                const rectHeight = Math.abs(drawing.endY - drawing.startY);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fillRect(rectLeft, rectTop, rectWidth, rectHeight);
                }
                ctx.globalAlpha = opacity;
                ctx.strokeRect(rectLeft, rectTop, rectWidth, rectHeight);
              } else if (drawing.type === 'oval') {
                const radiusX = Math.abs(drawing.endX - drawing.startX) / 2;
                const radiusY = Math.abs(drawing.endY - drawing.startY) / 2;
                const centerX = (drawing.startX + drawing.endX) / 2;
                const centerY = (drawing.startY + drawing.endY) / 2;
                ctx.beginPath();
                ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.stroke();
              } else if (drawing.type === 'triangle') {
                ctx.beginPath();
                ctx.moveTo((drawing.startX + drawing.endX) / 2, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.closePath();
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo((drawing.startX + drawing.endX) / 2, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.closePath();
                ctx.stroke();
              } else if (drawing.type === 'arc') {
                const radius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
                const centerX = (drawing.startX + drawing.endX) / 2;
                const centerY = (drawing.startY + drawing.endY) / 2;
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, 0, Math.PI);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, 0, Math.PI);
                ctx.stroke();
              } else if (drawing.type === 'cross') {
                ctx.beginPath();
                ctx.moveTo(drawing.startX, drawing.startY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.moveTo(drawing.endX, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.stroke();
              } else if (drawing.type === 'freehand' && drawing.points && drawing.points.length > 0) {
                ctx.beginPath();
                ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
                for (let i = 1; i < drawing.points.length; i++) {
                  ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
                }
                ctx.stroke();
              }
              break;
          }
          
          ctx.restore();
        });
        
        resolve(canvas.toDataURL('image/jpeg', 0.95));
      };
      bgImg.onerror = () => reject(new Error('Failed to load background image'));
      bgImg.src = backgroundImageData;
    });
  }

  function updateImagePreview() {
    if (!imagePreviewContainer) {
      imagePreviewContainer = document.getElementById('distatsImagePreviewContainer');
    }
    if (!imagePreviewContainer) return;

    if (pendingImages.length === 0) {
      imagePreviewContainer.style.display = 'none';
      imagePreviewContainer.innerHTML = '';
      return;
    }

    imagePreviewContainer.style.display = 'flex';
    imagePreviewContainer.innerHTML = '';

    pendingImages.forEach((imageObj, index) => {
      const previewItem = document.createElement('div');
      previewItem.className = 'image-preview-item';
      previewItem.style.position = 'relative';
      previewItem.style.display = 'inline-block';
      previewItem.style.maxWidth = '100%';

      const img = document.createElement('img');
      
      // Get original background and slidesData
      const originalImageSrc = imageObj.originalSrc || imageObj.imageData;
      const slidesData = imageObj.slidesData;
      const drawings = slidesData && slidesData[0] && slidesData[0].drawings ? slidesData[0].drawings : [];
      
      // Use imageData directly - it should already be merged with drawings for preview
      // The imageData is the merged image (with drawings), originalImageSrc is the clean background for editor
      img.src = imageObj.imageData;
      
      img.className = 'image-preview';
      img.alt = `Preview ${index + 1}`;
      img.style.cursor = 'pointer';
      img.style.maxWidth = '150px';
      img.style.maxHeight = '150px';
      img.style.width = 'auto';
      img.style.height = 'auto';
      img.style.display = 'block';
      img.style.objectFit = 'contain';
      const clickToEditText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('messages.clickToEdit')
        : 'Click to edit in tactical editor';
      img.title = clickToEditText;

      img.addEventListener('click', () => {
        const originalSrc = imageObj.originalSrc || imageObj.imageData;
        openEditorWindowWithImage(imageObj.imageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
          pendingImages[index] = { 
            imageData: modifiedImageData, 
            slidesData: slidesData,
            originalSrc: savedOriginalImageSrc || originalSrc
          };
          updateImagePreview();
        }, imageObj.slidesData, originalSrc);
      });

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-image-preview';
      removeBtn.textContent = '×';
      const removeImageText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('messages.removeImage')
        : 'Remove image';
      removeBtn.title = removeImageText;
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        pendingImages.splice(index, 1);
        updateImagePreview();
      });

      previewItem.appendChild(img);
      previewItem.appendChild(removeBtn);
      imagePreviewContainer.appendChild(previewItem);
    });
  }

  function hideImagePreview() {
    pendingImages = [];
    updateImagePreview();
    if (attachImageBtn) {
      attachImageBtn.disabled = false;
    }
  }

  function handleStorageError(error, operation) {
    // Check for extension context invalidation in the error parameter
    if (error && error.message && error.message.includes('Extension context invalidated')) {
      console.error('Extension context invalidated. Please reload the page.');
      alert('Extension was reloaded. Please refresh this page to continue using Dinamo Notebook.');
      return true;
    }
    // Check for extension context invalidation in chrome.runtime.lastError
    if (chrome.runtime.lastError && chrome.runtime.lastError.message &&
        chrome.runtime.lastError.message.includes('Extension context invalidated')) {
      console.error('Extension context invalidated. Please reload the page.');
      alert('Extension was reloaded. Please refresh this page to continue using Dinamo Notebook.');
      return true;
    }
    // Handle other storage errors
    if (chrome.runtime.lastError) {
      console.error(`Storage error in ${operation}:`, chrome.runtime.lastError.message);
      return true;
    }
    // Handle other errors passed directly
    if (error) {
      console.error(`Error in ${operation}:`, error.message || error);
      return true;
    }
    return false;
  }

  // Platform detection function moved to top (before first use)

  function normalizeVideoUrl(url) {
    if (!url) {
      return '';
    }

    try {
      const urlObj = new URL(url);
      urlObj.searchParams.delete('t');
      urlObj.searchParams.delete('start');
      urlObj.searchParams.delete('time_continue');
      urlObj.hash = '';
      return urlObj.toString();
    } catch (e) {
      return url;
    }
  }

  function isSameVideoAsCurrent(noteVideo) {
    if (!noteVideo) {
      return false;
    }

    // Compare by video ID when possible
    if (
      noteVideo.videoId &&
      currentVideoId &&
      noteVideo.videoId === currentVideoId &&
      (!noteVideo.platform || !platform || noteVideo.platform === platform)
    ) {
      return true;
    }

    // Compare by normalized URLs
    if (noteVideo.videoUrl && currentVideoUrl) {
      return normalizeVideoUrl(noteVideo.videoUrl) === normalizeVideoUrl(currentVideoUrl);
    }

    return false;
  }

  // Create sidebar HTML structure
  function create() {
    if (document.querySelector('.distats-sidebar')) {
      return; // Already exists
    }

    const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
    const placeholderText = `Type your notes below. Timestamps will be saved when you add a note.`;

    const sidebarHTML = `
      <div class="distats-sidebar hidden" id="distats">
        <div class="chat-section">
          <div class="chat-header">
            <div class="chat-header-row">
              <div class="project-dropdown-container" style="position: relative; display: inline-flex; align-items: center;">
                <button type="button" id="distatsProjectButton" class="project-button" title="Select project" style="border-top-right-radius: 0; border-bottom-right-radius: 0; border-right: none;">
                  <span id="distatsProjectButtonText" style="font-size: 13px;">No project</span>
                </button>
                <button type="button" id="distatsProjectDropdownArrow" class="project-dropdown-arrow" title="Project Options" style="width: 20px; height: 26px; padding: 0; border-top-left-radius: 0; border-bottom-left-radius: 0; display: flex; align-items: center; justify-content: center; border-left: 1px solid #30363d; cursor: pointer; pointer-events: auto;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="pointer-events: none;">
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                <div id="distatsProjectDropdown" class="project-dropdown hidden" style="position: absolute; top: 100%; left: 0; margin-top: 4px; background: #161b22; border: 1px solid #30363d; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 99999 !important; min-width: 150px; display: none; visibility: visible; opacity: 1;">
                  <button class="project-dropdown-item" id="distatsCreateProjectDropdownItem">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <line x1="12" y1="5" x2="12" y2="19"/>
                      <line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                    <span data-i18n="project.createProject">Create Project</span>
                  </button>
                  <button class="project-dropdown-item" id="distatsRenameProjectDropdownItem">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    <span data-i18n="project.renameProject">Rename Project</span>
                  </button>
                  <button class="project-dropdown-item" id="distatsDeleteProjectDropdownItem">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <polyline points="3 6 5 6 21 6"/>
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                    </svg>
                    <span data-i18n="project.deleteProject">Delete Project</span>
                  </button>
                </div>
              </div>
              <div class="ai-analysis-dropdown-container" style="position: relative; display: inline-flex; align-items: center;">
                <button type="button" class="ai-analysis-button" id="distatsAIAnalysisButton" data-i18n-title="ai.aiAnalysis" title="AI Analysis" style="border-top-right-radius: 0; border-bottom-right-radius: 0; border-right: none;">
                  <span style="font-size: 11px; font-weight: 600; letter-spacing: 0.5px;">AI</span>
                </button>
                <button type="button" class="ai-analysis-dropdown-arrow" id="distatsAIAnalysisDropdownArrow" data-i18n-title="ai.aiAnalysisOptions" title="AI Analysis Options" style="width: 20px; height: 26px; padding: 0; border-top-left-radius: 0; border-bottom-left-radius: 0; display: flex; align-items: center; justify-content: center; border-left: 1px solid #30363d; cursor: pointer; pointer-events: auto;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="pointer-events: none;">
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                <div id="distatsAIAnalysisDropdown" class="ai-analysis-dropdown hidden" style="position: absolute; top: 100%; right: 0; margin-top: 4px; background: #161b22; border: 1px solid #30363d; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 99999 !important; min-width: 150px; display: none; visibility: visible; opacity: 1;">
                  <button class="ai-analysis-dropdown-item" id="distatsAIAnalysisDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                    </svg>
                    <span data-i18n="ai.aiAnalysis">AI Analysis</span>
                  </button>
                  <button class="ai-analysis-dropdown-item" id="distatsEnhanceWithAIDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    <span data-i18n="ai.enhanceWithAI">Enhance with AI</span>
                  </button>
                  <button class="ai-analysis-dropdown-item" id="distatsAIAnalysisSettingsDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
                    </svg>
                    <span data-i18n="ai.aiSettings">AI Settings</span>
                  </button>
                </div>
              </div>
              <div class="saving-options-dropdown-container" style="position: relative; display: inline-flex; align-items: center;">
                <button type="button" id="distatsSavingOptionsButton" class="saving-options-button" data-i18n-title="common.settings" title="Settings" style="border-top-right-radius: 0; border-bottom-right-radius: 0; border-right: none;">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6M5.64 5.64l4.24 4.24m4.24 4.24l4.24 4.24M1 12h6m6 0h6M5.64 18.36l4.24-4.24m4.24-4.24l4.24-4.24"/>
                  </svg>
                </button>
                <button type="button" id="distatsSavingOptionsDropdownArrow" class="saving-options-dropdown-arrow" data-i18n-title="common.settings" title="Settings" style="width: 20px; height: 26px; padding: 0; border-top-left-radius: 0; border-bottom-left-radius: 0; display: flex; align-items: center; justify-content: center; border-left: 1px solid #30363d; cursor: pointer; pointer-events: auto;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="pointer-events: none;">
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                <div id="distatsSavingOptionsDropdown" class="saving-options-dropdown hidden" style="position: absolute; top: 100%; right: 0; margin-top: 4px; background: #161b22; border: 1px solid #30363d; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 99999 !important; min-width: 150px; display: none; visibility: visible; opacity: 1;">
                  <button class="saving-options-dropdown-item" id="distatsImportProjectDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                      <polyline points="17 8 12 3 7 8"/>
                      <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span data-i18n="saving.importProject">Import Project</span>
                  </button>
                  <button class="saving-options-dropdown-item" id="distatsExportProjectDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s; display: none;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                      <polyline points="7 10 12 15 17 10"/>
                      <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <span data-i18n="saving.exportProject">Export Project</span>
                  </button>
                  <button class="saving-options-dropdown-item" id="distatsExportNotesDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s; display: none;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                      <polyline points="14 2 14 8 20 8"/>
                      <line x1="16" y1="13" x2="8" y2="13"/>
                      <line x1="16" y1="17" x2="8" y2="17"/>
                      <polyline points="10 9 9 9 8 9"/>
                    </svg>
                    <span data-i18n="saving.exportNotes">Export Notes (PDF/HTML)</span>
                  </button>
                  <button class="saving-options-dropdown-item" id="distatsBackupDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                      <polyline points="17 21 17 13 7 13 7 21"/>
                      <polyline points="7 3 7 8 15 8"/>
                    </svg>
                    <span data-i18n="saving.createBackup">Create Backup</span>
                  </button>
                  <button class="saving-options-dropdown-item" id="distatsRestoreDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
                      <path d="M21 3v5h-5"/>
                      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
                      <path d="M8 16H3v5"/>
                    </svg>
                    <span data-i18n="saving.restoreBackup">Restore Backup</span>
                  </button>
                  <div style="width: 100%; height: 1px; background: #21262d; margin: 4px 0;"></div>
                  <button class="saving-options-dropdown-item" id="distatsSettingsDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <circle cx="12" cy="12" r="10"/>
                      <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                    </svg>
                    <span data-i18n="settings.languageSettings">Language Settings</span>
                  </button>
                  <div style="width: 100%; height: 1px; background: #21262d; margin: 4px 0;"></div>
                  <button class="saving-options-dropdown-item" id="commentsDatabaseDropdownItem" style="width: 100%; padding: 8px 12px; background: transparent; border: none; color: #c9d1d9; text-align: left; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; transition: background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                      <line x1="8" y1="9" x2="16" y2="9"/>
                      <line x1="8" y1="13" x2="16" y2="13"/>
                    </svg>
                    <span data-i18n="commentsDatabase.title">Comments Database</span>
                  </button>
                </div>
              </div>
              <button class="delete-button" id="distatsCloseBtn" data-i18n-title="sidebar.close" title="Close sidebar" style="margin-left: auto;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="18" y1="6" x2="6" y2="18"/>
                  <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>
          </div>
          <div class="project-videos-section" id="distatsVideosSection" style="display: none;">
            <div class="project-videos-header">
              <div class="project-videos-header-left" style="display: flex; align-items: center; gap: 8px; cursor: pointer; flex: 1;" id="distatsVideosToggle">
                <button class="project-videos-collapse-btn" id="distatsVideosCollapseBtn" data-i18n-title="project.collapseExpandVideos" title="Collapse/Expand videos">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 6 9 9 6"></polyline>
                  </svg>
                </button>
                <span class="project-videos-label" data-i18n="project.videos">Videos:</span>
              </div>
              <button class="project-add-video-btn" id="distatsAddVideoBtn" data-i18n-title="project.addVideoToProject" title="Add video to project">+</button>
            </div>
            <div class="project-videos-list" id="distatsVideosList"></div>
          </div>
          <div class="chat-messages" id="distatsNotesList">
            <div style="color: #6e7681; font-style: italic; text-align: center; padding: 20px;">
              ${placeholderText}
            </div>
          </div>
          <div class="chat-input-container">
            <div id="distatsImagePreviewContainer" class="image-preview-container" style="display: none;"></div>
            <div class="chat-input-bar">
              <div class="chat-input-row" style="display: flex; align-items: flex-end; gap: 8px; width: 100%;">
                <textarea
                  class="chat-input"
                  id="distatsNoteInput"
                  data-i18n-placeholder="sidebar.writeMessage"
                  rows="1"
                  style="flex: 1;"
                ></textarea>
                <input type="file" id="distatsImageInput" accept="image/*" multiple style="display: none;">
                <button class="send-icon-button" id="distatsAddBtn" data-i18n-title="sidebar.sendMessage">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                  </svg>
                </button>
              </div>
              <div class="chat-input-icons-row" style="display: flex; align-items: center; gap: 8px; margin-top: 8px;">
                <button class="input-icon-button" id="distatsAttachImageBtn" data-i18n-title="sidebar.attachImage" title="Attach image">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                  </svg>
                </button>
                <button class="input-icon-button" id="distatsAutocaptureBtn" data-i18n-title="sidebar.autocapture" title="Autocapture Screenshots">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                    <line x1="8" y1="21" x2="16" y2="21"/>
                    <line x1="12" y1="17" x2="12" y2="21"/>
                    <circle cx="12" cy="10" r="2"/>
                  </svg>
                </button>
                <div class="tactical-editor-dropdown-container">
                  <button class="input-icon-button" id="distatsAttachTacticalEditorBtn" data-i18n-title="sidebar.tacticalEditor" title="Tactical editor">
                    <svg width="20" height="20" viewBox="0 0 512 512" fill="none" stroke="currentColor" stroke-width="42">
                      <path d="M496 96H16V416H496V96Z"/>
                      <path d="M256 96V416"/>
                      <path d="M256 320C291.346 320 320 291.346 320 256C320 220.654 291.346 192 256 192C220.654 192 192 220.654 192 256C192 291.346 220.654 320 256 320Z"/>
                      <path d="M112 176H16V336H112V176Z"/>
                      <path d="M496 176H400V336H496V176Z"/>
                    </svg>
                  </button>
                  <div id="distatsTacticalEditorDropdown" class="tactical-editor-dropdown hidden">
                    <button class="tactical-editor-dropdown-item" data-type="scheme">
                      <svg width="16" height="16" viewBox="0 0 512 512" fill="none" stroke="currentColor" stroke-width="42">
                        <path d="M496 96H16V416H496V96Z"/>
                        <path d="M256 96V416"/>
                        <path d="M256 320C291.346 320 320 291.346 320 256C320 220.654 291.346 192 256 192C220.654 192 192 220.654 192 256C192 291.346 220.654 320 256 320Z"/>
                        <path d="M112 176H16V336H112V176Z"/>
                        <path d="M496 176H400V336H496V176Z"/>
                      </svg>
                      <span data-i18n="editor.fullField">Full Field</span>
                    </button>
                    <button class="tactical-editor-dropdown-item" data-type="goal">
                      <svg width="16" height="16" viewBox="0 0 402 274" fill="none" stroke="currentColor" stroke-width="36" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M9 265V9H393V265"/>
                        <path d="M105 9V233" stroke-width="20"/>
                        <path d="M201 9V233" stroke-width="20"/>
                        <path d="M297 9V233" stroke-width="20"/>
                        <path d="M9 73L393 73" stroke-width="20"/>
                        <path d="M9 124L393 120" stroke-width="20"/>
                        <path d="M9 168L393 174" stroke-width="20"/>
                        <path d="M9 217.5H393.001" stroke-width="20"/>
                      </svg>
                      <span data-i18n="editor.goal">Goal</span>
                    </button>
                    <button class="tactical-editor-dropdown-item" data-type="half">
                      <svg width="16" height="16" viewBox="0 0 2594 1930" fill="none" stroke="currentColor" stroke-width="120">
                        <rect x="205" y="159" width="2172" height="1678"/>
                        <path d="M1583.77 1836.62C1583.77 1759 1552.97 1684.68 1498.15 1629.84C1443.34 1575 1368.99 1544.19 1291.47 1544.19C1213.95 1544.19 1139.6 1575 1084.79 1629.84C1029.97 1684.68 999.174 1759.07 999.174 1836.62"/>
                        <rect x="999" y="159" width="582" height="176"/>
                        <rect x="647" y="159" width="1285" height="527"/>
                        <path d="M1525 686C1497 722 1462 752 1422 772C1381 792 1337 803 1291 803C1246 803 1201 792 1161 772C1120 752 1085 722 1058 686"/>
                      </svg>
                      <span data-i18n="editor.halfField">Half Field</span>
                    </button>
                  </div>
                </div>
                <button class="input-icon-button" id="distatsOpenTimelineBtn" data-i18n-title="sidebar.timelineAnalysis" title="Timeline Analysis">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="4" y1="21" x2="4" y2="14"/>
                    <line x1="4" y1="10" x2="4" y2="3"/>
                    <line x1="12" y1="21" x2="12" y2="12"/>
                    <line x1="12" y1="8" x2="12" y2="3"/>
                    <line x1="20" y1="21" x2="20" y2="16"/>
                    <line x1="20" y1="12" x2="20" y2="3"/>
                    <line x1="1" y1="14" x2="7" y2="14"/>
                    <line x1="9" y1="8" x2="15" y2="8"/>
                    <line x1="17" y1="16" x2="23" y2="16"/>
                  </svg>
                </button>
                <button class="input-icon-button" id="distatsCreateHighlightsBtn" data-i18n-title="highlights.createHighlights" title="Create Highlights Video">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="23 7 16 12 23 17 23 7"/>
                    <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
                    <line x1="12" y1="9" x2="12" y2="15"/>
                    <line x1="9" y1="12" x2="15" y2="12"/>
                  </svg>
                </button>
                <button class="input-icon-button" id="distatsVoiceInputBtn" data-i18n-title="sidebar.voiceInput" title="Voice Input">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" id="distatsVoiceInputIcon">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                    <line x1="12" y1="19" x2="12" y2="23"/>
                    <line x1="8" y1="23" x2="16" y2="23"/>
                  </svg>
                  <div id="distatsVoiceInputPulse" class="voice-input-pulse hidden"></div>
                </button>
                <button class="input-icon-button" id="distatsCommentPropertiesBtn" data-i18n-title="sidebar.commentProperties" title="Comment Properties">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="7" height="7"/>
                    <rect x="14" y="3" width="7" height="7"/>
                    <rect x="3" y="14" width="7" height="7"/>
                    <rect x="14" y="14" width="7" height="7"/>
                  </svg>
                </button>
              </div>
            </div>
            <div class="collapsible-section" id="distatsAnalysisControlsSection">
              <div class="collapsible-header" id="distatsAnalysisControlsHeader" style="display: none;">
                <span class="collapsible-title" data-i18n="sidebar.commentProperties">Comment Properties</span>
                <svg class="collapsible-chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </div>
              <div class="collapsible-content" id="distatsAnalysisControlsContent">
                <div class="team-selector-container">
                  <div class="team-selector-header">
                    <input type="text" class="team-search-input" id="distatsTeamSearchInput" data-i18n-placeholder="sidebar.searchTeams" placeholder="Search teams..." />
                    <button class="add-team-btn" id="distatsAddTeamBtn" data-i18n-title="sidebar.addNewTeam" title="Add new team">+</button>
                  </div>
                  <div class="team-selector-dropdown" id="distatsTeamSelectorDropdown" style="display: none;">
                    <div class="team-list" id="distatsTeamList"></div>
                  </div>
                  <div class="selected-team-display" id="distatsSelectedTeamDisplay"></div>
                </div>
                <div class="player-selector-container">
                  <div class="player-selector-header">
                    <input type="text" class="player-search-input" id="distatsPlayerSearchInput" data-i18n-placeholder="sidebar.searchPlayers" placeholder="Search players..." />
                    <button class="add-player-btn" id="distatsAddPlayerBtn" data-i18n-title="sidebar.addNewPlayer" title="Add new player">+</button>
                  </div>
                  <div class="player-selector-dropdown" id="distatsPlayerSelectorDropdown" style="display: none;">
                    <div class="player-list" id="distatsPlayerList"></div>
                  </div>
                  <div class="selected-players-display" id="distatsSelectedPlayersDisplay"></div>
                </div>
                <div class="event-selector-container">
                  <div class="event-selector-header">
                    <input type="text" class="event-search-input" id="distatsEventSearchInput" data-i18n-placeholder="sidebar.searchEvents" placeholder="Search events..." />
                    <button class="add-custom-event-btn" id="distatsAddCustomEventBtn" data-i18n-title="sidebar.addCustomEvent" title="Add custom event">+</button>
                  </div>
                  <div class="event-selector-dropdown" id="distatsEventSelectorDropdown" style="display: none;">
                    <div class="event-categories" id="distatsEventCategories"></div>
                  </div>
                  <div class="selected-events-display" id="distatsSelectedEventsDisplay"></div>
                </div>
                <div class="zones-selector-container">
                  <div class="zones-selector-header">
                    <input type="text" class="zones-search-input" id="distatsZonesSearchInput" data-i18n-placeholder="sidebar.searchZones" placeholder="Search zones..." />
                  </div>
                  <div class="zones-selector-dropdown" id="distatsZonesSelectorDropdown" style="display: none;">
                    <div class="zones-categories" id="distatsZonesCategories"></div>
                  </div>
                  <div class="selected-zones-display" id="distatsSelectedZonesDisplay"></div>
                </div>
                <div class="intensity-selector-container">
                  <label class="intensity-label" data-i18n="sidebar.intensity" id="distatsIntensityLabel">Intensity:</label>
                  <div class="intensity-scale" id="distatsIntensityScale" aria-labelledby="distatsIntensityLabel" role="slider" tabindex="0">
                    <div class="intensity-track">
                      <div class="intensity-slider" id="distatsIntensitySlider"></div>
                    </div>
                    <div class="intensity-labels">
                      <span class="intensity-label-point" data-value="0" data-i18n="sidebar.fullDefense">Full defense</span>
                      <span class="intensity-label-point" data-value="1" data-i18n="sidebar.defense">Defense</span>
                      <span class="intensity-label-point" data-value="2" data-i18n="sidebar.balance">Balance</span>
                      <span class="intensity-label-point" data-value="3" data-i18n="sidebar.attack">Attack</span>
                      <span class="intensity-label-point" data-value="4" data-i18n="sidebar.fullAttack">Full attack</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button class="distats-toggle-btn" id="distatsToggleBtn" data-i18n-title="sidebar.showDistatsAnalysis" title="Show Dinamo Notebook Analysis">
        <img src="${chrome.runtime.getURL('icons/D.png')}" alt="Dinamo Notebook" width="20" height="20" style="display: block;">
        <span>Dinamo Notebook</span>
      </button>
      
      <!-- Timeline Floating Panel -->
      <div class="distats-timeline-panel hidden" id="distatsTimelinePanel">
        <div class="timeline-panel-header" id="distatsTimelinePanelHeader">
          <span class="timeline-panel-title" data-i18n="timeline.title">Timeline</span>
          <span class="timeline-panel-project" id="distatsTimelineProjectName" data-i18n="project.noProject">No project</span>
          <div class="timeline-panel-controls">
            <button class="timeline-panel-btn" id="distatsTimelineMinimize" data-i18n-title="common.minimize" title="Minimize">−</button>
            <button class="timeline-panel-btn" id="distatsTimelineClose" data-i18n-title="common.close" title="Close">×</button>
          </div>
        </div>
        
        <div class="timeline-panel-body" id="distatsTimelinePanelBody">
          <!-- Time Display -->
          <div class="timeline-time-row">
            <div class="timeline-current-time" id="distatsTimelineCurrentTime">0:00</div>
            <span class="timeline-time-separator">/</span>
            <div class="timeline-duration" id="distatsTimelineDuration">0:00</div>
          </div>
          
          <!-- Timeline Bar -->
          <div class="timeline-bar-wrapper">
            <div class="timeline-bar" id="distatsTimelineBar">
              <div class="timeline-progress" id="distatsTimelineProgress"></div>
              <div class="timeline-playhead" id="distatsTimelinePlayhead"></div>
              <div class="timeline-markers" id="distatsTimelineMarkersBar"></div>
            </div>
          </div>
          
          <!-- Video Selector -->
          <div class="timeline-video-selector">
            <label class="timeline-selector-label" data-i18n="timeline.video">Video</label>
            <select class="timeline-video-select" id="distatsTimelineVideoSelect">
              <option value="" data-i18n="timeline.allVideos">All videos</option>
            </select>
          </div>
          
          <!-- Team Selector -->
          <div class="timeline-team-selector">
            <label class="timeline-selector-label" data-i18n="sidebar.team">Team</label>
            <div class="timeline-team-multiselect-container">
              <div class="timeline-team-tags-container" id="distatsTimelineTeamTagsContainer">
                <!-- Team tags populated dynamically -->
              </div>
              <div class="timeline-team-selector-input-wrapper" style="position: relative;">
                <input 
                  type="text" 
                  class="timeline-team-selector-input" 
                  id="distatsTimelineTeamSelectorInput" 
                  data-i18n-placeholder="sidebar.selectTeams"
                  placeholder="Select teams..." 
                  readonly
                  style="padding-right: 28px; background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%238b949e' d='M3 4.5L6 7.5L9 4.5'/%3E%3C/svg%3E\"); background-repeat: no-repeat; background-position: right 8px center;"
                />
                <div class="timeline-team-dropdown" id="distatsTimelineTeamDropdown" style="display: none;">
                  <!-- Team dropdown items populated dynamically -->
                </div>
              </div>
            </div>
          </div>
          
          <!-- Player Selector -->
          <div class="timeline-player-selector">
            <label class="timeline-selector-label" data-i18n="timeline.playersSelectBeforeEvents">Players (select before clicking events)</label>
            <div class="player-selector-container">
              <div class="player-selector-header-wrapper" style="position: relative;">
                <div class="player-selector-header">
                  <input type="text" class="player-search-input" id="distatsTimelinePlayerSearchInput" data-i18n-placeholder="sidebar.searchPlayers" placeholder="Search players..." />
                  <button class="add-player-btn" id="distatsTimelineAddPlayerBtn" data-i18n-title="sidebar.addNewPlayer" title="Add new player">+</button>
                </div>
                <div class="player-selector-dropdown" id="distatsTimelinePlayerSelectorDropdown" style="display: none;">
                  <div class="player-list" id="distatsTimelinePlayerList"></div>
                </div>
              </div>
              <div class="selected-players-display" id="distatsTimelineSelectedPlayersDisplay"></div>
            </div>
          </div>
          
          <!-- Quick Events -->
          <div class="timeline-quick-events">
            <div class="timeline-quick-events-header">
              <span class="timeline-selector-label" data-i18n="timeline.quickEvents">Quick Events</span>
              <button class="timeline-edit-events-btn" id="distatsTimelineEditEventsBtn" data-i18n-title="timeline.editEvents" title="Edit events">✎</button>
            </div>
            <div class="timeline-quick-events-buttons" id="distatsTimelineQuickEvents">
              <!-- Buttons populated dynamically -->
            </div>
          </div>
          
          <!-- Marker List -->
          <div class="timeline-markers-section">
            <div class="timeline-markers-header">
              <span>Markers</span>
              <span class="timeline-marker-count" id="distatsTimelineMarkerCount">0</span>
            </div>
            <div class="timeline-markers-list" id="distatsTimelineMarkersList">
              <div class="timeline-no-markers">Click an event button to add a marker at the current time</div>
            </div>
          </div>
          
          <!-- Jump to Time -->
          <div class="timeline-jump-section">
            <label class="timeline-jump-label" data-i18n="timeline.jumpToTime">Jump to time</label>
            <div class="timeline-jump-row">
              <input type="text" class="timeline-manual-time" id="distatsTimelineManualTime" data-i18n-placeholder="timeline.manualTime" placeholder="e.g. 1:23 or 1:23:45">
              <button class="timeline-goto-btn" id="distatsTimelineGotoTime">→</button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Timeline Edit Events Modal -->
      <div class="project-modal hidden" id="distatsTimelineEventsModal">
        <div class="project-modal-content" style="max-width: 500px; width: 90vw;">
          <div class="project-modal-header">
            <h3 data-i18n="timeline.editQuickEvents">Edit Quick Events</h3>
            <button class="close-modal-btn" id="distatsCloseTimelineEventsModal">×</button>
          </div>
          <div class="project-modal-body">
            <div style="margin-bottom: 12px;">
              <label style="display: block; font-size: 11px; font-weight: 500; color: #8b949e; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;" data-i18n="timeline.selectTeamToEdit">Select Team to Edit</label>
              <select class="timeline-team-select" id="distatsTimelineModalTeamSelect" style="width: 100%;">
                <option value="" data-i18n="modals.selectTeam">Select team...</option>
              </select>
            </div>
            <div class="timeline-events-modal-list" id="distatsTimelineEventsModalList">
              <!-- Events list populated dynamically -->
            </div>
            <div class="timeline-events-modal-add">
              <div class="event-selector-container">
                <div class="event-selector-header">
                  <input type="text" class="event-search-input" id="distatsTimelineEventSearchInput" data-i18n-placeholder="sidebar.searchEvents" placeholder="Search events..." />
                  <button class="add-custom-event-btn" id="distatsTimelineAddCustomEventBtn" data-i18n-title="sidebar.addCustomEvent" title="Add custom event">+</button>
                </div>
                <div class="event-selector-dropdown" id="distatsTimelineEventSelectorDropdown" style="display: none;">
                  <div class="event-categories" id="distatsTimelineEventCategories"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Add Video URL Modal -->
      <div class="project-modal hidden" id="distatsAddVideoModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 data-i18n="modals.addVideoUrl">Add Video URL</h3>
            <button class="close-modal-btn" id="distatsCloseAddVideoModal">×</button>
          </div>
          <div class="project-modal-body">
            <textarea
              class="url-input-modal"
              id="distatsUrlInput"
              placeholder="Paste video URL (YouTube, Dailymotion, Twitch)..."
              rows="3"
            ></textarea>
          </div>
        </div>
      </div>
      <!-- Player Modal -->
      <div class="project-modal hidden" id="distatsPlayerModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 id="distatsPlayerModalTitle" data-i18n="modals.addPlayer">Add Player</h3>
            <button class="close-modal-btn" id="distatsClosePlayerModal">×</button>
          </div>
          <div class="project-modal-body">
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.fullNameOrSurname">Full Name or Surname:</label>
              <input 
                type="text" 
                id="distatsPlayerNameInput" 
                class="url-input-modal" 
                data-i18n-placeholder="modals.enterPlayerName"
                placeholder="Enter player name..."
                style="width: 100%; padding: 8px 12px;"
              />
            </div>
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.number">Number:</label>
              <input 
                type="text" 
                id="distatsPlayerNumberInput" 
                class="url-input-modal" 
                data-i18n-placeholder="modals.enterPlayerNumber"
                placeholder="Enter player number..."
                style="width: 100%; padding: 8px 12px;"
              />
            </div>
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.position">Position:</label>
              <select 
                id="distatsPlayerPositionSelect" 
                class="url-input-modal" 
                style="width: 100%; padding: 8px 12px;"
              >
                <option value="" data-i18n="modals.selectPosition">Select position...</option>
                <optgroup data-i18n-label="modals.goalkeeper" label="Goalkeeper">
                  <option value="GK" data-i18n="positions.gk">GK - Goalkeeper</option>
                </optgroup>
                <optgroup data-i18n-label="modals.defenders" label="Defenders">
                  <option value="CB" data-i18n="positions.cb">CB - Center Back</option>
                  <option value="LB" data-i18n="positions.lb">LB - Left Back</option>
                  <option value="RB" data-i18n="positions.rb">RB - Right Back</option>
                  <option value="LWB" data-i18n="positions.lwb">LWB - Left Wing Back</option>
                  <option value="RWB" data-i18n="positions.rwb">RWB - Right Wing Back</option>
                </optgroup>
                <optgroup data-i18n-label="modals.midfielders" label="Midfielders">
                  <option value="CDM" data-i18n="positions.cdm">CDM - Defensive Midfielder</option>
                  <option value="CM" data-i18n="positions.cm">CM - Central Midfielder</option>
                  <option value="CAM" data-i18n="positions.cam">CAM - Attacking Midfielder</option>
                  <option value="LM" data-i18n="positions.lm">LM - Left Midfielder</option>
                  <option value="RM" data-i18n="positions.rm">RM - Right Midfielder</option>
                </optgroup>
                <optgroup data-i18n-label="modals.forwards" label="Forwards">
                  <option value="LW" data-i18n="positions.lw">LW - Left Winger</option>
                  <option value="RW" data-i18n="positions.rw">RW - Right Winger</option>
                  <option value="CF" data-i18n="positions.cf">CF - Center Forward</option>
                  <option value="ST" data-i18n="positions.st">ST - Striker</option>
                </optgroup>
              </select>
            </div>
            <div style="margin-bottom: 20px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.team">Team:</label>
              <select 
                id="distatsPlayerTeamSelect" 
                class="url-input-modal" 
                style="width: 100%; padding: 8px 12px;"
              >
                <option value="" data-i18n="modals.selectTeam">Select team...</option>
              </select>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="distatsSavePlayerBtn" class="modal-btn-primary">Save</button>
            </div>
            
            <!-- Bulk Import Section -->
            <div id="distatsBulkImportSection" style="margin-top: 20px; padding-top: 16px; border-top: 1px solid #30363d;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <label style="font-size: 13px; color: #c9d1d9; font-weight: 500;" data-i18n="modals.bulkImport">Bulk Import from File</label>
                <button type="button" id="distatsToggleImportInstructions" class="modal-btn-secondary" style="font-size: 12px; padding: 4px 8px;">?</button>
              </div>
              
              <div id="distatsImportInstructions" style="display: none; margin-bottom: 12px; padding: 12px; background: #0d1117; border: 1px solid #21262d; border-radius: 6px; font-size: 13px; color: #8b949e; line-height: 1.6;">
                <div style="font-weight: 500; color: #c9d1d9; margin-bottom: 8px;" data-i18n="modals.importInstructionsTitle">CSV File Format:</div>
                <div>
                  Create a CSV file with 4 columns (comma-separated):<br>
                  <code style="background: #161b22; padding: 2px 6px; border-radius: 3px; font-family: monospace; font-size: 12px;">name,number,position,team</code><br><br>
                  <strong>Example:</strong><br>
                  <code style="background: #161b22; padding: 6px 8px; border-radius: 3px; font-family: monospace; font-size: 12px; display: block; margin-top: 6px; white-space: pre; overflow-x: auto;">name,number,position,team
John Doe,10,CM,Dinamo
Jane Smith,1,GK,Dinamo</code><br>
                  <strong>Positions:</strong> GK, CB, LB, RB, LWB, RWB, CDM, CM, CAM, LM, RM, LW, RW, CF, ST<br>
                  <strong>Team:</strong> If team doesn't exist, it will be created automatically.
                </div>
              </div>
              
              <div style="display: flex; gap: 8px; align-items: center;">
                <input type="file" id="distatsPlayerImportFile" accept=".csv" style="display: none;" />
                <button type="button" id="distatsSelectImportFileBtn" class="modal-btn-secondary" data-i18n="modals.selectFile">Select CSV File</button>
                <span id="distatsImportFileName" style="font-size: 12px; color: #8b949e; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></span>
                <button type="button" id="distatsImportPlayersBtn" class="modal-btn-primary" style="display: none;" data-i18n="modals.importPlayers">Import</button>
              </div>
              <div id="distatsImportResultMessage" style="margin-top: 8px; font-size: 12px; display: none;"></div>
            </div>
          </div>
        </div>
      </div>
      <!-- Custom Event Modal -->
      <div class="project-modal hidden" id="distatsCustomEventModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 id="distatsCustomEventModalTitle" data-i18n="modals.addCustomEvent">Add Custom Event</h3>
            <button class="close-modal-btn" id="distatsCloseCustomEventModal">×</button>
          </div>
          <div class="project-modal-body">
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.eventName">Event Name:</label>
              <input 
                type="text" 
                id="distatsCustomEventNameInput" 
                class="url-input-modal" 
                data-i18n-placeholder="modals.enterCustomEventName"
                placeholder="Enter custom event name..."
                style="width: 100%; padding: 8px 12px;"
              />
            </div>
            <div style="margin-bottom: 20px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.category">Category:</label>
              <select 
                id="distatsCustomEventCategorySelect" 
                class="url-input-modal" 
                style="width: 100%; padding: 8px 12px;"
              >
                <option value="" data-i18n="modals.selectCategory">Select category...</option>
              </select>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="distatsSaveCustomEventBtn" class="modal-btn-primary">Save</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Team Modal -->
      <div class="project-modal hidden" id="distatsTeamModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 id="distatsTeamModalTitle" data-i18n="modals.addTeam">Add Team</h3>
            <button class="close-modal-btn" id="distatsCloseTeamModal">×</button>
          </div>
          <div class="project-modal-body">
            <div style="margin-bottom: 20px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.teamName">Team Name:</label>
              <input 
                type="text" 
                id="distatsTeamNameInput" 
                class="url-input-modal" 
                data-i18n-placeholder="modals.enterTeamName"
                placeholder="Enter team name..."
                style="width: 100%; padding: 8px 12px;"
              />
            </div>
            <div style="margin-bottom: 20px; display: flex; gap: 24px;">
              <div style="flex: 1;">
                <label style="display: block; margin-bottom: 10px; font-size: 12px; font-weight: 500; color: #8b949e; text-transform: uppercase; letter-spacing: 0.5px;" data-i18n="modals.homeKit">Home Kit</label>
                <div style="display: flex; justify-content: center; padding: 16px; background: #0d1117; border: 1px solid #21262d; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; position: relative;" id="distatsTeamHomeTshirtContainer" data-i18n-title="modals.clickToChangeColor" title="Click to change color">
                  <canvas id="distatsTeamHomeTshirtPreview" width="80" height="106" style="display: block; pointer-events: none;"></canvas>
                  <input 
                    type="color" 
                    id="distatsTeamHomeColorInput" 
                    value="#FFFFFF"
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer;"
                  />
                </div>
              </div>
              <div style="flex: 1;">
                <label style="display: block; margin-bottom: 10px; font-size: 12px; font-weight: 500; color: #8b949e; text-transform: uppercase; letter-spacing: 0.5px;" data-i18n="modals.awayKit">Away Kit</label>
                <div style="display: flex; justify-content: center; padding: 16px; background: #0d1117; border: 1px solid #21262d; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; position: relative;" id="distatsTeamAwayTshirtContainer" data-i18n-title="modals.clickToChangeColor" title="Click to change color">
                  <canvas id="distatsTeamAwayTshirtPreview" width="80" height="106" style="display: block; pointer-events: none;"></canvas>
                  <input 
                    type="color" 
                    id="distatsTeamAwayColorInput" 
                    value="#000000"
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer;"
                  />
                </div>
              </div>
            </div>
            <div style="margin-bottom: 20px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.formation">Formation:</label>
              <select 
                id="distatsTeamFormationSelect" 
                class="url-input-modal" 
                style="width: 100%; padding: 8px 12px;"
              >
                <option value="" data-i18n="modals.selectFormation">Select formation...</option>
              </select>
            </div>
            <!-- Squad Assignment Section -->
            <div id="distatsTeamSquadSection" style="display: none; margin-bottom: 20px; padding-top: 16px; border-top: 1px solid #21262d;">
              <label style="display: block; margin-bottom: 12px; font-size: 13px; color: #c9d1d9; font-weight: 500;" data-i18n="modals.squadAssignment">Squad Assignment:</label>
              <div id="distatsTeamSquadFormation" style="position: relative; width: 100%; height: 320px; background: linear-gradient(180deg, #1a472a 0%, #2d5a3a 50%, #1a472a 100%); border-radius: 8px; border: 2px solid #3d6e4a; overflow: hidden;">
                <!-- Formation positions will be dynamically rendered here -->
              </div>
              <p style="margin-top: 8px; font-size: 11px; color: #8b949e; text-align: center;" data-i18n="modals.clickPositionToAssign">Click on a position to assign a player</p>
            </div>
            <div id="distatsTeamPlayersSection" style="display: none; margin-bottom: 20px; padding-top: 16px; border-top: 1px solid #21262d;">
              <label style="display: block; margin-bottom: 8px; font-size: 13px; color: #c9d1d9;" data-i18n="modals.attachedPlayers">Attached Players:</label>
              <div id="distatsTeamPlayersList" style="max-height: 300px; overflow-y: auto;">
                <!-- Players will be dynamically added here -->
              </div>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="distatsSaveTeamBtn" class="modal-btn-primary">Save</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Squad Position Player Assignment Popup -->
      <div id="distatsSquadPlayerPopup" class="project-modal hidden" style="z-index: 10002;">
        <div class="project-modal-content" style="max-width: 300px;">
          <div class="project-modal-header">
            <h3 id="distatsSquadPlayerPopupTitle" data-i18n="modals.squadAssignment">Assign Player</h3>
            <button id="distatsCloseSquadPlayerPopup" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body">
            <div id="distatsSquadPlayerPopupPosition" style="margin-bottom: 12px; font-size: 12px; color: #8b949e;"></div>
            <div id="distatsSquadPlayerList" style="max-height: 250px; overflow-y: auto;">
              <!-- Available players will be listed here -->
            </div>
            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #21262d;">
              <button id="distatsClearSquadPosition" class="create-new-project-btn" style="width: 100%; background: transparent; border: 1px solid #30363d; color: #8b949e; font-size: 12px;" data-i18n="editor.clearPosition">Clear Position</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Delete Confirmation Modal -->
      <div class="project-modal hidden" id="distatsDeleteConfirmModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 data-i18n="modals.confirmDelete">Confirm Delete</h3>
            <button class="close-modal-btn" id="distatsCloseDeleteConfirmModal">×</button>
          </div>
          <div class="project-modal-body">
            <p id="distatsDeleteConfirmMessage" data-i18n="modals.confirmDeleteMessage">Are you sure you want to delete this message?</p>
            <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
              <button id="distatsConfirmDeleteBtn" class="modal-btn-primary" style="background: #da3633; border-color: #da3633;">Delete</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Import Project Modal -->
      <div class="project-modal hidden" id="distatsImportProjectModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 data-i18n="saving.importProject">Import Project</h3>
            <button class="close-modal-btn" id="distatsCloseImportProjectModal">×</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #c9d1d9; margin-bottom: 12px; font-size: 13px;" data-i18n="saving.importProjectFile">Select a project .zip file to import:</p>
            <input type="file" id="distatsImportProjectFileInput" accept=".zip" style="display: none;">
            <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 16px;">
              <button id="distatsSelectImportProjectFileBtn" class="import-file-btn" style="flex-shrink: 0;" data-i18n="saving.chooseFile">Choose File</button>
              <div id="distatsImportProjectFileName" style="color: #8b949e; font-size: 12px; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></div>
            </div>
            <div id="distatsImportProjectError" style="color: #da3633; font-size: 12px; margin-bottom: 12px; display: none;"></div>
            <div style="display: flex; gap: 8px; justify-content: flex-end;">
              <button id="distatsConfirmImportProjectBtn" class="import-confirm-btn" disabled data-i18n="common.import">Import</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Restore Backup Modal -->
      <div class="project-modal hidden" id="distatsRestoreBackupModal">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 data-i18n="saving.restoreFromBackup">Restore from Backup</h3>
            <button class="close-modal-btn" id="distatsCloseRestoreBackupModal">×</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #c9d1d9; margin-bottom: 8px; font-weight: 500; font-size: 13px;" data-i18n="saving.restoreWarning">Warning: This will replace all existing data!</p>
            <p style="color: #8b949e; font-size: 12px; margin-bottom: 12px;" data-i18n="saving.restoreWarningText">All current projects, players, and custom data will be replaced with the backup data.</p>
            <input type="file" id="distatsRestoreBackupFileInput" accept=".zip" style="display: none;">
            <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 16px;">
              <button id="distatsSelectRestoreBackupFileBtn" class="import-file-btn" style="flex-shrink: 0;" data-i18n="saving.chooseFile">Choose File</button>
              <div id="distatsRestoreBackupFileName" style="color: #8b949e; font-size: 12px; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></div>
            </div>
            <div id="distatsRestoreBackupError" style="color: #da3633; font-size: 12px; margin-bottom: 12px; display: none;"></div>
            <div style="display: flex; gap: 8px; justify-content: flex-end;">
              <button id="distatsConfirmRestoreBackupBtn" class="restore-confirm-btn" disabled data-i18n="saving.restoreBackup">Restore</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Settings Modal -->
      <div class="project-modal hidden" id="distatsSettingsModal" style="z-index: 10002;">
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3 data-i18n="settings.languageSettings">Language Settings</h3>
            <button class="close-modal-btn" id="distatsCloseSettingsModal">×</button>
          </div>
          <div class="project-modal-body">
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;" data-i18n="language.selectLanguage">Interface Language:</label>
              <select id="distatsInterfaceLanguageSelect" class="url-input-modal" style="width: 100%; padding: 8px 12px;">
                <option value="en" data-i18n="language.english">English</option>
                <option value="sr" data-i18n="language.serbian">Serbian (Srpski)</option>
                <option value="de" data-i18n="language.german">German (Deutsch)</option>
                <option value="fr" data-i18n="language.french">French (Français)</option>
                <option value="es" data-i18n="language.spanish">Spanish (Español)</option>
                <option value="pt" data-i18n="language.portuguese">Portuguese (Português)</option>
              </select>
              <p style="color: #8b949e; font-size: 12px; margin-top: 6px; margin-bottom: 0;" data-i18n="settings.languageDescription">Change the language for the user interface. This affects all menus, buttons, and labels.</p>
            </div>
            <div style="display: flex; gap: 8px; justify-content: flex-end;">
              <button id="distatsSaveSettingsBtn" class="create-new-project-btn" data-i18n="common.save">Save</button>
            </div>
          </div>
        </div>
      </div>
      <!-- AI Enhancement Modal -->
      <div id="distatsAiEnhancementModal" class="project-modal hidden">
        <div class="project-modal-content" style="max-width: 500px;">
          <div class="project-modal-header">
            <h3 data-i18n="ai.enhanceWithAI">Enhance with AI</h3>
            <button id="distatsCloseAiEnhancementModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #8b949e; margin-bottom: 20px; font-size: 13px; line-height: 1.5;" data-i18n="ai.enhancementDescription">AI will analyze your comments and automatically extract properties (teams, players, zones, events, intensity) from the text.</p>
            <div style="margin-bottom: 20px;">
              <div style="font-size: 12px; color: #8b949e; margin-bottom: 8px;" data-i18n="ai.enhancementScope">Enhance:</div>
              <select id="distatsEnhancementScopeSelect" style="width: 100%; padding: 8px 12px; background: #0d1117; border: 1px solid #21262d; border-radius: 6px; color: #c9d1d9; font-size: 13px; cursor: pointer;">
                <option value="all" data-i18n="ai.enhanceCurrentProject">All comments in current project</option>
                <option value="marked" data-i18n="ai.enhanceMarkedComments">Marked comments</option>
              </select>
            </div>
            <div style="margin-bottom: 20px;">
              <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: #c9d1d9; cursor: pointer;">
                <input type="checkbox" id="distatsEnhancementSkipExisting" checked style="cursor: pointer; width: 16px; height: 16px;">
                <span data-i18n="ai.skipCommentsWithProperties">Skip comments that already have properties</span>
              </label>
            </div>
            <div id="distatsEnhancementProgress" style="display: none; margin-bottom: 16px;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 12px; color: #8b949e;">
                <span id="distatsEnhancementProgressText" data-i18n="ai.enhancingComments">Enhancing comments...</span>
                <span id="distatsEnhancementProgressCount">0 / 0</span>
              </div>
              <div style="width: 100%; height: 6px; background: #21262d; border-radius: 3px; overflow: hidden;">
                <div id="distatsEnhancementProgressBar" style="height: 100%; background: #3fb950; width: 0%; transition: width 0.3s ease;"></div>
              </div>
            </div>
            <div id="distatsEnhancementResults" style="display: none; margin-bottom: 16px; padding: 12px; background: #0d1117; border: 1px solid #21262d; border-radius: 6px;">
              <div style="font-size: 13px; color: #3fb950; margin-bottom: 8px;" id="distatsEnhancementSuccessCount"></div>
              <div style="font-size: 13px; color: #da3633; margin-bottom: 8px; display: none;" id="distatsEnhancementErrorCount"></div>
              <div style="font-size: 12px; color: #8b949e; max-height: 200px; overflow-y: auto;" id="distatsEnhancementErrorDetails"></div>
              <div id="distatsEnhancementUnresolvedSection" style="display: none; margin-top: 12px; border-top: 1px solid #21262d; padding-top: 12px;">
                <div style="font-size: 12px; color: #d29922; margin-bottom: 8px; font-weight: 500;" data-i18n="ai.unresolvedItemsTitle">Unresolved items (not in your library):</div>
                <div id="distatsEnhancementUnresolvedTeamsList" style="display: none; margin-bottom: 8px;">
                  <div style="font-size: 11px; color: #8b949e; margin-bottom: 4px;" data-i18n="ai.unresolvedTeams">Unresolved teams:</div>
                  <div id="distatsEnhancementUnresolvedTeamsItems" style="display: flex; flex-direction: column; gap: 4px;"></div>
                </div>
                <div id="distatsEnhancementUnresolvedPlayersList" style="display: none; margin-bottom: 8px;">
                  <div style="font-size: 11px; color: #8b949e; margin-bottom: 4px;" data-i18n="ai.unresolvedPlayers">Unresolved players:</div>
                  <div id="distatsEnhancementUnresolvedPlayersItems" style="display: flex; flex-direction: column; gap: 4px;"></div>
                </div>
                <div style="display: flex; gap: 8px; margin-top: 8px;">
                  <button id="distatsCreateAllUnresolvedBtn" style="padding: 4px 10px; background: #238636; color: #ffffff; border: none; border-radius: 4px; font-size: 11px; cursor: pointer; transition: all 0.15s ease;" data-i18n="ai.createAllSelected">Create All Selected</button>
                  <button id="distatsSkipUnresolvedBtn" style="padding: 4px 10px; background: transparent; color: #8b949e; border: 1px solid #30363d; border-radius: 4px; font-size: 11px; cursor: pointer; transition: all 0.15s ease;" data-i18n="ai.skipUnresolved">Skip</button>
                </div>
              </div>
            </div>
            <div id="distatsEnhancementError" style="display: none; color: #da3633; font-size: 12px; margin-bottom: 12px;"></div>
          </div>
          <div class="project-modal-footer" style="padding: 12px 16px; border-top: 1px solid #21262d; display: flex; gap: 8px; justify-content: flex-end;">
            <button id="distatsStartAiEnhancementBtn" class="modal-btn-secondary" data-i18n="ai.startEnhancement">Start Enhancement</button>
            <button id="distatsOkAiEnhancementBtn" class="modal-btn-secondary" style="display: none;" data-i18n="common.ok">OK</button>
          </div>
        </div>
      </div>
      
      <!-- Comments Database Modal -->
      <div id="commentsDatabaseModal" class="project-modal hidden">
        <div class="project-modal-content" style="max-width: 1200px; max-height: 90vh;">
          <div class="project-modal-header">
            <h3 data-i18n="commentsDatabase.title">Comments Database</h3>
            <button id="closeCommentsDatabaseModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body" style="max-height: calc(90vh - 120px); overflow: hidden; display: flex; flex-direction: column; padding: 0;">
            <!-- Search and Filter Bar -->
            <div style="padding: 12px 16px; border-bottom: 1px solid #21262d; background: #0d1117;">
              <div style="display: flex; gap: 8px; margin-bottom: 10px; align-items: center;">
                <input 
                  type="text" 
                  id="commentsDatabaseSearch" 
                  class="url-input-modal" 
                  data-i18n-placeholder="commentsDatabase.search"
                  style="flex: 1; padding: 6px 10px; font-size: 13px; height: 32px;"
                />
                <button id="clearCommentsFiltersBtn" class="comments-db-clear-btn" data-i18n="commentsDatabase.clearFilters">Clear</button>
              </div>
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 6px; margin-bottom: 8px;">
                <select id="commentsFilterTeam" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allTeams">All Teams</option>
                </select>
                <select id="commentsFilterPlayer" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allPlayers">All Players</option>
                </select>
                <select id="commentsFilterEvent" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allEvents">All Events</option>
                </select>
                <select id="commentsFilterZone" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allZones">All Zones</option>
                </select>
                <select id="commentsFilterIntensity" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allIntensities">All Intensities</option>
                  <option value="0" data-i18n="sidebar.fullDefense">Full defense</option>
                  <option value="1" data-i18n="sidebar.defense">Defense</option>
                  <option value="2" data-i18n="sidebar.balance">Balance</option>
                  <option value="3" data-i18n="sidebar.attack">Attack</option>
                  <option value="4" data-i18n="sidebar.fullAttack">Full attack</option>
                </select>
                <select id="commentsFilterVideo" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allVideos">All Videos</option>
                </select>
                <select id="commentsFilterProject" class="comments-db-filter-select">
                  <option value="" data-i18n="commentsDatabase.allProjects">All Projects</option>
                </select>
              </div>
              <div style="font-size: 11px; color: #8b949e; margin-top: 4px;">
                <span id="commentsResultsCount" data-i18n="commentsDatabase.resultsCount">0 comments</span>
              </div>
            </div>
            <!-- Results Area -->
            <div id="commentsDatabaseResults" style="flex: 1; overflow-y: auto; padding: 16px;">
              <div id="commentsDatabaseLoading" style="text-align: center; padding: 40px; display: none;">
                <div class="loading-spinner" style="margin: 0 auto 16px; width: 32px; height: 32px; border-width: 3px;"></div>
                <p style="color: #8b949e;" data-i18n="common.loading">Loading...</p>
              </div>
              <div id="commentsDatabaseEmpty" style="text-align: center; padding: 40px; color: #8b949e; display: none;" data-i18n="commentsDatabase.noResults">
                No comments found
              </div>
              <table id="commentsDatabaseTable" style="width: 100%; border-collapse: collapse; display: none;">
                <thead>
                  <tr style="border-bottom: 2px solid #21262d;">
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnText">Text</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnSchemes">Schemes</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnTeam">Team</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnPlayers">Players</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnEvents">Events</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnZones">Zones</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnVideo">Video</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnDate">Date</th>
                    <th style="text-align: left; padding: 12px 8px; font-size: 12px; font-weight: 600; color: #8b949e; text-transform: uppercase;" data-i18n="commentsDatabase.columnProject">Project</th>
                  </tr>
                </thead>
                <tbody id="commentsDatabaseTableBody">
                  <!-- Results will be inserted here -->
                </tbody>
              </table>
            </div>
          </div>
          <div class="project-modal-footer" style="padding: 12px 16px; border-top: 1px solid #21262d; display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 12px; color: #8b949e;">
              <span id="commentsDatabasePageInfo"></span>
            </div>
            <div style="display: flex; gap: 8px;">
              <button id="commentsDatabasePrevPage" class="modal-btn-secondary" disabled data-i18n="common.previous">Previous</button>
              <button id="commentsDatabaseNextPage" class="modal-btn-secondary" disabled data-i18n="common.next">Next</button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Scheme Viewer Modal -->
      <div id="schemeViewerModal" class="project-modal hidden">
        <div class="project-modal-content" style="max-width: 1400px; max-height: 95vh;">
          <div class="project-modal-header">
            <h3 id="schemeViewerTitle">Tactical Scheme</h3>
            <button id="closeSchemeViewerModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body" style="max-height: calc(95vh - 120px); overflow-y: auto; padding: 20px;">
            <div id="schemeViewerContent">
              <!-- Scheme slides will be rendered here -->
            </div>
            <div id="schemeViewerNavigation" style="display: none; margin-top: 20px; text-align: center;">
              <button id="schemeViewerPrevSlide" class="modal-btn-secondary" style="margin-right: 10px;">Previous</button>
              <span id="schemeViewerSlideInfo" style="color: #8b949e; margin: 0 10px;">Slide 1 of 1</span>
              <button id="schemeViewerNextSlide" class="modal-btn-secondary" style="margin-left: 10px;">Next</button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Autocapture Floating Panel -->
      <div class="distats-autocapture-panel hidden" id="distatsAutocaptureModal">
        <div class="autocapture-panel-header" id="distatsAutocapturePanelHeader">
          <div class="autocapture-panel-title" data-i18n="autocapture.title">Autocapture Screenshots</div>
          <div class="autocapture-panel-controls">
            <button class="autocapture-panel-btn" id="distatsCloseAutocaptureModal" title="Close">×</button>
          </div>
        </div>
        <div class="autocapture-panel-body">
            <!-- Mode Selection -->
            <div class="autocapture-field">
              <label class="autocapture-label" data-i18n="autocapture.mode">Capture Mode:</label>
              <div class="autocapture-mode-group">
                <button class="autocapture-mode-btn active" data-mode="single" data-i18n="autocapture.singleScreenshot">Single Screenshot</button>
                <button class="autocapture-mode-btn" data-mode="series" data-i18n="autocapture.series">Series</button>
              </div>
            </div>
            
            <!-- Series Mode Fields (hidden by default) -->
            <div id="distatsAutocaptureSeriesFields" class="autocapture-series-fields" style="display: none;">
              <div class="autocapture-field">
                <label class="autocapture-label" data-i18n="autocapture.startTime">Start Time:</label>
                <input type="text" id="distatsAutocaptureStartTime" class="url-input-modal autocapture-input" placeholder="0:00">
              </div>
              <div class="autocapture-field">
                <label class="autocapture-label" data-i18n="autocapture.endTime">End Time:</label>
                <input type="text" id="distatsAutocaptureEndTime" class="url-input-modal autocapture-input" placeholder="0:00">
              </div>
              <div class="autocapture-field">
                <label class="autocapture-label" data-i18n="autocapture.interval">Capture Interval:</label>
                <div class="autocapture-interval-group">
                  <button class="autocapture-interval-btn" data-interval="0.5">0.5s</button>
                  <button class="autocapture-interval-btn" data-interval="1">1s</button>
                  <button class="autocapture-interval-btn" data-interval="2">2s</button>
                  <button class="autocapture-interval-btn" data-interval="5">5s</button>
                </div>
                <input type="number" id="distatsAutocaptureCustomInterval" class="url-input-modal autocapture-input" data-i18n-placeholder="autocapture.customInterval" placeholder="Custom interval (seconds)" min="0.1" step="0.1">
              </div>
              <div class="autocapture-preview-box">
                <div class="autocapture-preview-label" data-i18n="autocapture.preview">Preview:</div>
                <div id="distatsAutocapturePreview" class="autocapture-preview-text" data-i18n="autocapture.previewText">Will capture 0 screenshots</div>
              </div>
            </div>
            
            <!-- Single Screenshot Mode Fields -->
            <div id="distatsAutocaptureSingleFields" class="autocapture-single-fields">
              <div class="autocapture-field">
                <label class="autocapture-label" data-i18n="autocapture.currentTime">Current Time:</label>
                <input type="text" id="distatsAutocaptureCurrentTime" class="url-input-modal autocapture-input" placeholder="0:00">
              </div>
              <div class="autocapture-preview-box">
                <div class="autocapture-preview-label" data-i18n="autocapture.preview">Preview:</div>
                <div id="distatsAutocaptureSinglePreview" class="autocapture-preview-text" data-i18n="autocapture.singlePreview">Will capture 1 screenshot at current time</div>
              </div>
            </div>
            <div id="distatsAutocaptureProgress" class="autocapture-progress" style="display: none;">
              <div class="autocapture-progress-label" data-i18n="autocapture.progress">Progress:</div>
              <div class="autocapture-progress-box">
                <div id="distatsAutocaptureProgressText" class="autocapture-progress-text">Capturing 0/0...</div>
                <div class="autocapture-progress-bar-container">
                  <div id="distatsAutocaptureProgressBar" class="autocapture-progress-bar"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="autocapture-panel-footer">
            <button id="distatsAutocaptureStartBtn" class="autocapture-start-btn" data-i18n="autocapture.start">Start Capture</button>
          </div>
        </div>
      </div>
      
      <!-- Highlight Creator Floating Panel -->
      <div class="distats-highlight-panel hidden" id="distatsHighlightCreatorPanel">
        <div class="highlight-panel-header" id="distatsHighlightPanelHeader">
          <span class="highlight-panel-title" data-i18n="highlights.createHighlights">Create Highlights Video</span>
          <div class="highlight-panel-controls">
            <button class="highlight-panel-btn" id="distatsHighlightMinimize" title="Minimize">−</button>
            <button class="highlight-panel-btn" id="distatsHighlightClose" title="Close">×</button>
          </div>
        </div>
        <div class="highlight-panel-body" id="distatsHighlightPanelBody">
          <!-- Mode Toggle -->
          <div class="highlight-mode-toggle" style="display: flex; gap: 4px; margin-bottom: 16px; background: #0d1117; border-radius: 6px; padding: 4px;">
            <button class="highlight-mode-btn active" id="distatsHighlightSimpleMode" data-mode="simple" style="flex: 1; padding: 8px 12px; border: none; background: #21262d; color: #c9d1d9; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; transition: all 0.15s ease;" data-i18n="highlights.simpleMode">Simple Mode</button>
            <button class="highlight-mode-btn" id="distatsHighlightAdvancedMode" data-mode="advanced" style="flex: 1; padding: 8px 12px; border: none; background: transparent; color: #8b949e; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; transition: all 0.15s ease;" data-i18n="highlights.advancedMode">Timeline Editor</button>
          </div>
          
          <!-- Simple Mode Content -->
          <div id="distatsHighlightSimpleContent">
            <div style="margin-bottom: 12px;">
              <label style="display: block; margin-bottom: 6px; font-size: 12px; color: #8b949e;" data-i18n="highlights.timeFramesLabel">Enter time frames (one per line):</label>
              <textarea 
                id="distatsHighlightTimeFrames" 
                class="highlight-timeframes-textarea"
                placeholder="1:11-1:21&#10;2:12-2:34&#10;15:11-17:24"
                data-i18n-placeholder="highlights.timeFramesPlaceholder"
              ></textarea>
              <!-- Timestamp Capture Buttons -->
              <div class="highlight-timestamp-buttons" style="display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap;">
                <button id="distatsHighlightSetStart" class="modal-btn-secondary highlight-timestamp-btn" style="padding: 6px 10px; font-size: 11px; display: flex; align-items: center; gap: 4px;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="5 3 19 12 5 21 5 3"/>
                  </svg>
                  <span data-i18n="highlights.setStart">Set Start</span>
                </button>
                <button id="distatsHighlightSetEnd" class="modal-btn-secondary highlight-timestamp-btn" style="padding: 6px 10px; font-size: 11px; display: flex; align-items: center; gap: 4px;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="6" y="4" width="4" height="16"/>
                    <rect x="14" y="4" width="4" height="16"/>
                  </svg>
                  <span data-i18n="highlights.setEnd">Set End</span>
                </button>
                <button id="distatsHighlightAddSegment" class="modal-btn-primary highlight-timestamp-btn" style="padding: 6px 10px; font-size: 11px; display: flex; align-items: center; gap: 4px;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19"/>
                    <line x1="5" y1="12" x2="19" y2="12"/>
                  </svg>
                  <span data-i18n="highlights.addSegment">Add Segment</span>
                </button>
              </div>
              <div id="distatsHighlightCurrentTime" style="margin-top: 8px; font-size: 11px; color: #8b949e;">
                <span data-i18n="highlights.currentTime">Current time:</span> <span id="distatsHighlightCurrentTimeValue">0:00</span>
              </div>
              <p style="margin-top: 6px; font-size: 10px; color: #6e7681;" data-i18n="highlights.formatHint">Format: START-END (e.g., 1:30-2:45)</p>
            </div>
          </div>
          
          <!-- Advanced Mode Content (Timeline Editor) -->
          <div id="distatsHighlightAdvancedContent" style="display: none;">
            <div class="highlight-timeline-editor">
              <div class="highlight-timeline-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <span style="font-size: 12px; color: #8b949e;" data-i18n="highlights.timelineItems">Timeline Items</span>
              </div>
              <div id="distatsHighlightTimelineList" class="highlight-timeline-list" style="min-height: 150px; max-height: 300px; overflow-y: auto; background: #0d1117; border: 1px solid #21262d; border-radius: 6px; padding: 8px;">
                <div class="highlight-timeline-empty" style="text-align: center; padding: 40px 20px; color: #6e7681; font-size: 12px;" data-i18n="highlights.timelineEmpty">
                  No items yet. Add segments in Simple Mode first, then switch here to add images.
                </div>
              </div>
              <div id="distatsHighlightTimelineSummary" style="margin-top: 10px; font-size: 11px; color: #8b949e; display: none;">
                <span data-i18n="highlights.totalDuration">Total duration:</span> <span id="distatsHighlightTotalDuration">0:00</span>
              </div>
            </div>
          </div>
          
          <!-- Parsed Preview (for simple mode) -->
          <div id="distatsHighlightParsedPreview" style="display: none; margin-bottom: 12px; padding: 10px; background: #0d1117; border: 1px solid #21262d; border-radius: 4px;">
            <div style="font-size: 11px; font-weight: 500; color: #8b949e; margin-bottom: 6px;" data-i18n="highlights.parsedSegments">Parsed Segments:</div>
            <div id="distatsHighlightSegmentsList" style="font-size: 11px; color: #c9d1d9; max-height: 120px; overflow-y: auto;"></div>
          </div>
          
          <div id="distatsHighlightError" style="display: none; color: #da3633; font-size: 11px; margin-bottom: 10px; padding: 8px; background: rgba(218, 54, 51, 0.1); border-radius: 4px;"></div>
          <div id="distatsHighlightProgress" style="display: none; margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 11px; color: #8b949e;">
              <span id="distatsHighlightProgressText" data-i18n="highlights.recording">Recording segments...</span>
              <span id="distatsHighlightProgressCount">0 / 0</span>
            </div>
            <div style="width: 100%; height: 4px; background: #21262d; border-radius: 2px; overflow: hidden;">
              <div id="distatsHighlightProgressBar" style="height: 100%; background: #3fb950; width: 0%; transition: width 0.3s ease;"></div>
            </div>
            <div id="distatsHighlightCurrentSegment" style="margin-top: 6px; font-size: 10px; color: #8b949e;"></div>
          </div>
          <div id="distatsHighlightComplete" style="display: none; text-align: center; padding: 16px;">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#3fb950" stroke-width="2" style="margin-bottom: 10px;">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22 4 12 14.01 9 11.01"/>
            </svg>
            <p style="font-size: 13px; color: #c9d1d9; margin-bottom: 12px;" data-i18n="highlights.videoReady">Your highlight video is ready!</p>
            <div style="display: flex; flex-direction: column; gap: 8px; align-items: center;">
              <button id="distatsHighlightDownloadMp4Btn" class="modal-btn-primary" style="display: inline-flex; align-items: center; gap: 6px; width: 160px; justify-content: center;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                  <polyline points="7 10 12 15 17 10"/>
                  <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                <span data-i18n="highlights.downloadMp4">Download MP4</span>
              </button>
              <button id="distatsHighlightDownloadWebmBtn" class="modal-btn-secondary" style="display: inline-flex; align-items: center; gap: 6px; width: 160px; justify-content: center;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                  <polyline points="7 10 12 15 17 10"/>
                  <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                <span data-i18n="highlights.downloadWebm">Download WebM</span>
              </button>
            </div>
            <p id="distatsHighlightFormatNote" style="font-size: 10px; color: #8b949e; margin-top: 10px;"></p>
          </div>
          
          <!-- Disclaimer Checkbox -->
          <div id="distatsHighlightDisclaimer" class="highlight-disclaimer" style="margin-top: 12px; padding: 10px; background: rgba(139, 148, 158, 0.1); border: 1px solid #30363d; border-radius: 6px;">
            <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; font-size: 11px; color: #8b949e; line-height: 1.4;">
              <input type="checkbox" id="distatsHighlightDisclaimerCheckbox" style="margin-top: 2px; cursor: pointer; width: 16px; height: 16px; flex-shrink: 0;">
              <span data-i18n="highlights.disclaimerText">I understand that this feature is available for educational purposes only. Using it for any kind of pirating or copyright infringement is strictly forbidden.</span>
            </label>
          </div>
          
          <div id="distatsHighlightFooter" style="display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px;">
            <button id="distatsHighlightCreateBtn" class="modal-btn-primary" style="opacity: 0.5; cursor: not-allowed;" disabled data-i18n="highlights.createVideo">Create Video</button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', sidebarHTML);
    
    // Initialize i18n for sidebar elements
    if (window.i18n && window.i18n.updateI18nElements) {
      // Wait a bit for DOM to be ready
      setTimeout(() => {
        window.i18n.updateI18nElements();
        // Update project button text with translation if no project selected
        updateProjectButtonText();
        // Register callback for language changes
        window.i18n.onLanguageChange(() => {
          window.i18n.updateI18nElements();
          updateProjectButtonText();
        });
      }, 100);
    }
    
    // Load popup.css styles dynamically and scope them to sidebar only
    loadStyles();

    // Add event listeners
    setupEventListeners();

    // Load existing analysis if available (this will update the project button text)
    // Also check storage immediately to set button text
    chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
      const analyses = result.analyses || [];
      const currentId = result.currentAnalysisId;
      
      // Update button text immediately if we have a project
      const projectButtonText = document.getElementById('distatsProjectButtonText');
      if (projectButtonText) {
        if (currentId) {
          const selectedAnalysis = analyses.find(a => a.id === currentId);
          if (selectedAnalysis) {
            projectButtonText.textContent = selectedAnalysis.name;
          } else {
            // Project ID exists but project not found - show translated "Select project"
            projectButtonText.textContent = window.i18n ? window.i18n.t('project.selectProject') : 'Select project';
          }
        } else {
          // No project selected - show translated "No project"
          projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
        }
      }
      
      // Update export buttons visibility on initialization
      const exportProjectDropdownItem = document.getElementById('distatsExportProjectDropdownItem');
      if (exportProjectDropdownItem) {
        exportProjectDropdownItem.style.display = currentId ? 'flex' : 'none';
      }
      const exportNotesDropdownItem = document.getElementById('distatsExportNotesDropdownItem');
      if (exportNotesDropdownItem) {
        exportNotesDropdownItem.style.display = currentId ? 'flex' : 'none';
      }
    });
    
    // Then load the full analysis
    loadCurrentAnalysis();

    // Get current video ID
    getCurrentVideoId();
  }

  // Load popup.css styles dynamically and scope them to sidebar
  function loadStyles() {
    // Create a style element that will contain scoped styles
    const styleId = 'distats-sidebar-styles';
    let styleElement = document.getElementById(styleId);
    
    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = styleId;
      document.head.appendChild(styleElement);
    }

    // Fetch popup.css and scope all styles to .distats-sidebar
    fetch(chrome.runtime.getURL('popup.css'))
      .then(response => response.text())
      .then(css => {
        // Remove global * and body rules that would affect the page
        let scoped = css
          .replace(/^\*\s*\{[^}]*\}/gm, '') // Remove global * rules
          .replace(/^body\s*\{[^}]*\}/gm, '') // Remove body rules
          .replace(/^html\s*\{[^}]*\}/gm, ''); // Remove html rules

        // Scope all other rules to .distats-sidebar
        // Simple regex approach - scope selectors that don't start with @
        scoped = scoped.replace(/(^[^@\s][^{]*?)\{/gm, (match, selector) => {
          // Skip if already scoped, empty, or is a comment
          if (!selector || selector.trim() === '' || 
              selector.includes('.distats-sidebar') ||
              selector.trim().startsWith('/*')) {
            return match;
          }
          
          // Scope the selector to .distats-sidebar
          const trimmed = selector.trim();
          const scopedSelector = trimmed
            .split(',')
            .map(s => s.trim())
            .filter(s => s.length > 0)
            .map(s => {
              if (s.startsWith(':')) return s;
              return `.distats-sidebar ${s}`;
            })
            .join(', ');
          
          return scopedSelector ? `${scopedSelector} {` : match;
        });

        // Add icon button hover styles with high specificity to ensure they work
        const iconButtonStyles = `
          .distats-sidebar .input-icon-button:hover {
            background: #21262d !important;
            color: #ffffff !important;
          }
          .distats-sidebar .input-icon-button:hover svg {
            color: #ffffff !important;
            stroke: #ffffff !important;
          }
          .distats-sidebar .input-icon-button:hover img {
            filter: brightness(0) invert(1) !important;
          }
        `;

        styleElement.textContent = scoped + iconButtonStyles;
      })
      .catch(error => {
        console.error('Error loading sidebar styles:', error);
      });
  }

  // Auto-resize textarea function
  function autoResizeTextarea(textarea) {
    if (!textarea) return;
    // Reset height to auto to get the correct scrollHeight
    textarea.style.height = 'auto';
    // Set height based on scrollHeight, with min and max constraints
    const minHeight = 20; // Minimum height (1 row)
    const maxHeight = 200; // Maximum height (approximately 10 rows)
    const newHeight = Math.min(Math.max(textarea.scrollHeight, minHeight), maxHeight);
    textarea.style.height = newHeight + 'px';
    // Enable scrolling if content exceeds max height
    textarea.style.overflowY = textarea.scrollHeight > maxHeight ? 'auto' : 'hidden';
  }

  // Setup event listeners
  function setupEventListeners() {
    const sidebar = document.getElementById('distats');
    const toggleBtn = document.getElementById('distatsToggleBtn');
    const closeBtn = document.getElementById('distatsCloseBtn');
    const addBtn = document.getElementById('distatsAddBtn');
    const noteInput = document.getElementById('distatsNoteInput');
    const createProjectBtn = document.getElementById('distatsCreateProjectBtn');

    // Toggle sidebar visibility
    toggleBtn.addEventListener('click', toggle);
    closeBtn.addEventListener('click', hide);

    // Project dropdown functionality
    const projectButton = document.getElementById('distatsProjectButton');
    const projectButtonTextEl = document.getElementById('distatsProjectButtonText');
    const projectDropdownArrow = document.getElementById('distatsProjectDropdownArrow');
    const projectDropdown = document.getElementById('distatsProjectDropdown');
    const createProjectDropdownItem = document.getElementById('distatsCreateProjectDropdownItem');
    const renameProjectDropdownItem = document.getElementById('distatsRenameProjectDropdownItem');
    const deleteProjectDropdownItem = document.getElementById('distatsDeleteProjectDropdownItem');

    // Function to close all dropdowns except the one specified
    function closeAllDropdowns(exceptDropdown = null) {
      const projectDropdownEl = document.getElementById('distatsProjectDropdown');
      const aiAnalysisDropdown = document.getElementById('distatsAIAnalysisDropdown');
      const savingOptionsDropdown = document.getElementById('distatsSavingOptionsDropdown');
      
      if (projectDropdownEl && projectDropdownEl !== exceptDropdown) {
        projectDropdownEl.classList.add('hidden');
        projectDropdownEl.style.display = 'none';
      }
      if (aiAnalysisDropdown && aiAnalysisDropdown !== exceptDropdown) {
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
      }
      if (savingOptionsDropdown && savingOptionsDropdown !== exceptDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
    }

    // Function to populate project list in dropdown
    function populateProjectDropdown() {
      return new Promise((resolve) => {
        chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
          const analyses = result.analyses || [];
          const currentId = result.currentAnalysisId;
          
          // Remove existing project list items and separators (keep Create, Rename, Delete)
          const existingItems = projectDropdown.querySelectorAll('.project-list-item, .project-list-separator');
          existingItems.forEach(item => item.remove());
          
          // Add project list items before the action buttons
          if (analyses.length > 0) {
            const sortedAnalyses = [...analyses].sort((a, b) => {
              const dateA = a.createdAt || 0;
              const dateB = b.createdAt || 0;
              return dateB - dateA; // Newest first
            });
            
            sortedAnalyses.forEach(analysis => {
              const projectItem = document.createElement('button');
              projectItem.className = 'project-dropdown-item project-list-item';
              if (analysis.id === currentId) {
                projectItem.style.background = '#21262d';
                projectItem.style.fontWeight = '500';
              }
              // Truncate long project names
              let displayName = analysis.name;
              const maxLength = 40;
              if (displayName.length > maxLength) {
                displayName = displayName.substring(0, maxLength) + '...';
              }
              projectItem.innerHTML = `<span>${displayName}</span>`;
              projectItem.addEventListener('click', () => {
                projectDropdown.classList.add('hidden');
                projectDropdown.style.display = 'none';
                // Switch to the selected project
                currentAnalysisId = analysis.id;
                // Update button text immediately with the selected project name
                const projectButtonText = document.getElementById('distatsProjectButtonText');
                if (projectButtonText) {
                  projectButtonText.textContent = analysis.name;
                }
                // Save to storage
                chrome.storage.local.set({ currentAnalysisId: analysis.id }, () => {
                  // Update all displays
                  updateProjectSelect();
                  // Then load the analysis
                  loadCurrentAnalysis();
                });
              });
              // Insert before the first action button (Create Project)
              if (createProjectDropdownItem) {
                projectDropdown.insertBefore(projectItem, createProjectDropdownItem);
              }
            });
            
            // Add separator if there are projects
            if (sortedAnalyses.length > 0 && createProjectDropdownItem) {
              const separator = document.createElement('div');
              separator.className = 'project-list-separator';
              separator.style.cssText = 'height: 1px; background: #21262d; margin: 4px 0;';
              projectDropdown.insertBefore(separator, createProjectDropdownItem);
            }
          }
          resolve();
        });
      });
    }

    // Project button click - toggle dropdown with project list
    if (projectButton) {
      projectButton.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        const isHidden = projectDropdown.classList.contains('hidden') || projectDropdown.style.display === 'none';
        
        if (isHidden) {
          closeAllDropdowns(projectDropdown);
          await populateProjectDropdown();
          projectDropdown.classList.remove('hidden');
          projectDropdown.style.display = 'block';
          projectDropdown.style.visibility = 'visible';
          projectDropdown.style.opacity = '1';
          projectDropdown.style.zIndex = '10001';
        } else {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
      });
    }

    // Project dropdown arrow click - toggle dropdown
    if (projectDropdownArrow && projectDropdown) {
      projectDropdownArrow.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        const isHidden = projectDropdown.classList.contains('hidden') || projectDropdown.style.display === 'none';
        
        if (isHidden) {
          closeAllDropdowns(projectDropdown);
          await populateProjectDropdown();
          projectDropdown.classList.remove('hidden');
          projectDropdown.style.display = 'block';
          projectDropdown.style.visibility = 'visible';
          projectDropdown.style.opacity = '1';
          projectDropdown.style.zIndex = '10001';
        } else {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
      });

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (projectDropdown && 
            !projectDropdown.contains(e.target) && 
            e.target !== projectDropdownArrow && 
            e.target !== projectButton &&
            !projectDropdownArrow.contains(e.target) &&
            !projectButton.contains(e.target)) {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
      });
    }

    // Create project dropdown item
    if (createProjectDropdownItem) {
      createProjectDropdownItem.addEventListener('click', () => {
        if (projectDropdown) {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
        checkForExistingProject();
      });
    }

    // Rename project dropdown item
    if (renameProjectDropdownItem) {
      renameProjectDropdownItem.addEventListener('click', () => {
        if (projectDropdown) {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
        renameCurrentProject();
      });
    }

    // Delete project dropdown item
    if (deleteProjectDropdownItem) {
      deleteProjectDropdownItem.addEventListener('click', () => {
        if (projectDropdown) {
          projectDropdown.classList.add('hidden');
          projectDropdown.style.display = 'none';
        }
        deleteCurrentProject();
      });
    }

    // AI Analysis button
    // AI Analysis button with dropdown
    const aiAnalysisButton = document.getElementById('distatsAIAnalysisButton');
    const aiAnalysisDropdownArrow = document.getElementById('distatsAIAnalysisDropdownArrow');
    const aiAnalysisDropdown = document.getElementById('distatsAIAnalysisDropdown');
    const aiAnalysisDropdownItem = document.getElementById('distatsAIAnalysisDropdownItem');
    const aiAnalysisSettingsDropdownItem = document.getElementById('distatsAIAnalysisSettingsDropdownItem');
    const distatsEnhanceWithAIDropdownItem = document.getElementById('distatsEnhanceWithAIDropdownItem');
    
    // AI Analysis button now opens dropdown instead of triggering analysis directly
    if (aiAnalysisButton && aiAnalysisDropdown) {
      aiAnalysisButton.addEventListener('click', (e) => {
        e.stopPropagation();
        const isHidden = aiAnalysisDropdown.classList.contains('hidden') || aiAnalysisDropdown.style.display === 'none';
        if (isHidden) {
          closeAllDropdowns(aiAnalysisDropdown);
          setTimeout(() => {
            aiAnalysisDropdown.classList.remove('hidden');
            aiAnalysisDropdown.style.display = 'block';
            aiAnalysisDropdown.style.visibility = 'visible';
            aiAnalysisDropdown.style.opacity = '1';
            aiAnalysisDropdown.style.zIndex = '10001';
          }, 0);
        } else {
          aiAnalysisDropdown.classList.add('hidden');
          aiAnalysisDropdown.style.display = 'none';
        }
      });
    }

    // Dropdown arrow click handler
    if (aiAnalysisDropdownArrow && aiAnalysisDropdown) {
      // Initialize dropdown as hidden
      aiAnalysisDropdown.style.display = 'none';
      
      // Make sure the button and SVG are clickable
      aiAnalysisDropdownArrow.style.pointerEvents = 'auto';
      aiAnalysisDropdownArrow.style.cursor = 'pointer';
      
      // Add click handler to both button and SVG
      const handleDropdownClick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const isHidden = aiAnalysisDropdown.classList.contains('hidden') || aiAnalysisDropdown.style.display === 'none';
        if (isHidden) {
          closeAllDropdowns(aiAnalysisDropdown);
          // Use setTimeout to ensure closeAllDropdowns completes first
          setTimeout(() => {
            aiAnalysisDropdown.classList.remove('hidden');
            aiAnalysisDropdown.style.display = 'block';
            aiAnalysisDropdown.style.visibility = 'visible';
            aiAnalysisDropdown.style.opacity = '1';
            aiAnalysisDropdown.style.zIndex = '10001';
            // Ensure it's positioned correctly
            const container = aiAnalysisDropdownArrow.closest('.ai-analysis-dropdown-container');
            if (container) {
              container.style.position = 'relative';
              container.style.zIndex = '10001';
              // Ensure parent containers don't clip the dropdown
              const chatHeaderRow = container.closest('.chat-header-row');
              if (chatHeaderRow) {
                chatHeaderRow.style.overflow = 'visible';
              }
              const chatHeader = container.closest('.chat-header');
              if (chatHeader) {
                chatHeader.style.overflow = 'visible';
              }
            }
          }, 0);
        } else {
          aiAnalysisDropdown.classList.add('hidden');
          aiAnalysisDropdown.style.display = 'none';
        }
      };
      
      aiAnalysisDropdownArrow.addEventListener('click', handleDropdownClick);
      
      // Also add to SVG if it exists
      const svg = aiAnalysisDropdownArrow.querySelector('svg');
      if (svg) {
        svg.style.pointerEvents = 'none'; // Let clicks pass through to button
      }
    } else {
      console.error('AI dropdown elements not found!', {
        arrow: !!aiAnalysisDropdownArrow,
        dropdown: !!aiAnalysisDropdown
      });
    }

    // AI Analysis item in dropdown
    if (aiAnalysisDropdownItem) {
      aiAnalysisDropdownItem.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
        showAIAnalysisFocusModal();
      });
    }

    // Settings item in dropdown
    if (aiAnalysisSettingsDropdownItem) {
      aiAnalysisSettingsDropdownItem.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
        showAPISettingsModal();
      });
    }

    // Enhance with AI item in dropdown
    if (distatsEnhanceWithAIDropdownItem) {
      distatsEnhanceWithAIDropdownItem.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
        openDistatsAiEnhancementModal();
      });
    }

    // Close dropdown when clicking outside
    if (aiAnalysisDropdown) {
      document.addEventListener('click', (e) => {
        if (!aiAnalysisDropdown.contains(e.target) && 
            e.target !== aiAnalysisDropdownArrow && 
            e.target !== aiAnalysisButton &&
            !aiAnalysisDropdownArrow.contains(e.target) &&
            !aiAnalysisButton.contains(e.target)) {
          aiAnalysisDropdown.classList.add('hidden');
          aiAnalysisDropdown.style.display = 'none';
        }
      });
    }

    // Export/Import/Backup handlers
    const savingOptionsButton = document.getElementById('distatsSavingOptionsButton');
    const savingOptionsDropdownArrow = document.getElementById('distatsSavingOptionsDropdownArrow');
    const savingOptionsDropdown = document.getElementById('distatsSavingOptionsDropdown');
    const importProjectDropdownItem = document.getElementById('distatsImportProjectDropdownItem');
    const exportProjectDropdownItem = document.getElementById('distatsExportProjectDropdownItem');
    const exportNotesDropdownItem = document.getElementById('distatsExportNotesDropdownItem');
    const backupDropdownItem = document.getElementById('distatsBackupDropdownItem');
    const restoreDropdownItem = document.getElementById('distatsRestoreDropdownItem');
    
    // Save button click handler - opens dropdown (same as AI button)
    if (savingOptionsButton && savingOptionsDropdown) {
      savingOptionsButton.addEventListener('click', (e) => {
        e.stopPropagation();
        const isHidden = savingOptionsDropdown.classList.contains('hidden') || savingOptionsDropdown.style.display === 'none';
        if (isHidden) {
          closeAllDropdowns(savingOptionsDropdown);
          setTimeout(() => {
            savingOptionsDropdown.classList.remove('hidden');
            savingOptionsDropdown.style.display = 'block';
            savingOptionsDropdown.style.visibility = 'visible';
            savingOptionsDropdown.style.opacity = '1';
            savingOptionsDropdown.style.zIndex = '10001';
          }, 0);
        } else {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
      });
    }
    
    // Saving options dropdown toggle
    if (savingOptionsDropdownArrow && savingOptionsDropdown) {
      savingOptionsDropdownArrow.addEventListener('click', (e) => {
        e.stopPropagation();
        const isHidden = savingOptionsDropdown.classList.contains('hidden') || savingOptionsDropdown.style.display === 'none';
        
        if (isHidden) {
          closeAllDropdowns(savingOptionsDropdown);
          // Use setTimeout to ensure closeAllDropdowns completes first
          setTimeout(() => {
            savingOptionsDropdown.classList.remove('hidden');
            savingOptionsDropdown.style.display = 'block';
            savingOptionsDropdown.style.visibility = 'visible';
            savingOptionsDropdown.style.opacity = '1';
            savingOptionsDropdown.style.zIndex = '10001';
          }, 0);
        } else {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
      });

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (savingOptionsDropdown && 
            !savingOptionsDropdown.contains(e.target) && 
            e.target !== savingOptionsDropdownArrow && 
            e.target !== savingOptionsButton &&
            !savingOptionsDropdownArrow.contains(e.target) &&
            !savingOptionsButton.contains(e.target)) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
      });
    }

    // Keep old references for backward compatibility
    const exportProjectBtn = exportProjectDropdownItem;
    const importProjectBtn = importProjectDropdownItem;
    const backupBtn = backupDropdownItem;
    const restoreBtn = restoreDropdownItem;
    const importProjectModal = document.getElementById('distatsImportProjectModal');
    const restoreBackupModal = document.getElementById('distatsRestoreBackupModal');
    const importProjectFileInput = document.getElementById('distatsImportProjectFileInput');
    const restoreBackupFileInput = document.getElementById('distatsRestoreBackupFileInput');
    const selectImportProjectFileBtn = document.getElementById('distatsSelectImportProjectFileBtn');
    const selectRestoreBackupFileBtn = document.getElementById('distatsSelectRestoreBackupFileBtn');
    const confirmImportProjectBtn = document.getElementById('distatsConfirmImportProjectBtn');
    const confirmRestoreBackupBtn = document.getElementById('distatsConfirmRestoreBackupBtn');
    const closeImportProjectModal = document.getElementById('distatsCloseImportProjectModal');
    const closeRestoreBackupModal = document.getElementById('distatsCloseRestoreBackupModal');
    const importProjectFileName = document.getElementById('distatsImportProjectFileName');
    const restoreBackupFileName = document.getElementById('distatsRestoreBackupFileName');
    const importProjectError = document.getElementById('distatsImportProjectError');
    const restoreBackupError = document.getElementById('distatsRestoreBackupError');

    // Export project dropdown item
    if (exportProjectDropdownItem) {
      exportProjectDropdownItem.addEventListener('click', async () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        if (!currentAnalysisId) return;
        try {
          exportProjectDropdownItem.disabled = true;
          await window.backupUtils.exportProject(currentAnalysisId);
          alert('Project exported successfully!');
        } catch (error) {
          console.error('Export error:', error);
          alert('Error exporting project: ' + error.message);
        } finally {
          exportProjectDropdownItem.disabled = false;
        }
      });
    }

    // Export notes (PDF/HTML) dropdown item
    if (exportNotesDropdownItem) {
      exportNotesDropdownItem.addEventListener('click', () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        if (!currentAnalysisId) {
          alert('Please select a project first.');
          return;
        }
        // Open export preview modal
        if (window.ExportPreview) {
          window.ExportPreview.open(currentAnalysisId);
        } else {
          console.error('ExportPreview not loaded');
          alert('Export feature not available. Please reload the extension.');
        }
      });
    }

    // Import project dropdown item
    if (importProjectDropdownItem) {
      importProjectDropdownItem.addEventListener('click', () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        if (importProjectModal) {
          importProjectModal.classList.remove('hidden');
          importProjectFileInput.value = '';
          importProjectFileName.style.display = 'none';
          importProjectError.style.display = 'none';
          confirmImportProjectBtn.disabled = true;
          if (importProjectFileInput) {
            importProjectFileInput.files = null;
          }
        }
      });
    }

    // Backup dropdown item
    if (backupDropdownItem) {
      backupDropdownItem.addEventListener('click', async () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        try {
          backupDropdownItem.disabled = true;
          await window.backupUtils.exportFullBackup();
          alert('Backup created successfully!');
        } catch (error) {
          console.error('Backup error:', error);
          alert('Error creating backup: ' + error.message);
        } finally {
          backupDropdownItem.disabled = false;
        }
      });
    }

    // Restore dropdown item
    if (restoreDropdownItem) {
      restoreDropdownItem.addEventListener('click', () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        if (restoreBackupModal) {
          restoreBackupModal.classList.remove('hidden');
          restoreBackupFileInput.value = '';
          restoreBackupFileName.style.display = 'none';
          restoreBackupError.style.display = 'none';
          confirmRestoreBackupBtn.disabled = true;
          if (restoreBackupFileInput) {
            restoreBackupFileInput.files = null;
          }
        }
      });
    }

    // Language Settings dropdown item
    const settingsDropdownItem = document.getElementById('distatsSettingsDropdownItem');
    const settingsModal = document.getElementById('distatsSettingsModal');
    const closeSettingsModal = document.getElementById('distatsCloseSettingsModal');
    const interfaceLanguageSelect = document.getElementById('distatsInterfaceLanguageSelect');
    const saveSettingsBtn = document.getElementById('distatsSaveSettingsBtn');

    if (settingsDropdownItem) {
      settingsDropdownItem.addEventListener('click', () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        if (settingsModal) {
          // Load current language
          if (interfaceLanguageSelect && window.i18n) {
            const currentLang = window.i18n.getCurrentLanguage();
            interfaceLanguageSelect.value = currentLang;
          }
          settingsModal.classList.remove('hidden');
        }
      });
    }

    // Close Settings modal
    if (closeSettingsModal) {
      closeSettingsModal.addEventListener('click', () => {
        if (settingsModal) {
          settingsModal.classList.add('hidden');
        }
      });
    }

    if (settingsModal) {
      settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
          settingsModal.classList.add('hidden');
        }
      });
    }

    // ========== COMMENTS DATABASE ==========
    
    // Global state for comments database
    let allCommentsData = [];
    let filteredComments = [];
    let currentPage = 1;
    const commentsPerPage = 50;
    let editingCommentId = null; // Track which comment is being edited
    let searchDebounceTimer = null;
    let playerNameToIdMap = new Map(); // Map player display name to player ID for filtering

    // Load all comments from all analyses
    // Load all comments from all analyses
    async function loadAllComments() {
      return new Promise((resolve, reject) => {
        chrome.storage.local.get(['analyses'], (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          const analyses = result.analyses || [];
          allCommentsData = [];

          analyses.forEach(analysis => {
            if (analysis.notes && Array.isArray(analysis.notes)) {
              analysis.notes.forEach(note => {
                // Check if note has schemes
                const hasSchemes = note.images && Array.isArray(note.images) && 
                  note.images.some(img => typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData) && img.slidesData.length > 0);
                
                // Check if comment text is empty (after removing timecode)
                const noteText = note.text || note.content || '';
                const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
                const isEmptyComment = !cleanText || cleanText.length === 0;
                
                // Skip empty comments that have schemes (scheme entry will be shown separately)
                if (isEmptyComment && hasSchemes) {
                  // Only add scheme entries, skip the empty comment
                } else {
                  // Add the comment entry
                  const commentWithMetadata = {
                    ...note,
                    analysisId: analysis.id,
                    analysisName: analysis.name,
                    analysisDate: analysis.date
                  };
                  allCommentsData.push(commentWithMetadata);
                }
                
                // Extract schemes from note images
                if (note.images && Array.isArray(note.images)) {
                  note.images.forEach(image => {
                    // Check if image has slidesData (tactical scheme)
                    if (typeof image === 'object' && image.slidesData && Array.isArray(image.slidesData) && image.slidesData.length > 0) {
                      const schemeEntry = {
                        type: 'scheme',
                        slidesData: image.slidesData,
                        timestamp: note.timestamp,
                        videoTime: note.videoTime,
                        timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                        analysisId: analysis.id,
                        analysisName: analysis.name,
                        analysisDate: analysis.date,
                        teams: note.teams || (note.team ? [note.team] : []),
                        players: note.players || [],
                        events: note.events || [],
                        zones: note.zones || [],
                        intensity: note.intensity,
                        videoId: note.videoId,
                        videoTitle: note.videoTitle,
                        videoUrl: note.videoUrl
                      };
                      allCommentsData.push(schemeEntry);
                    }
                  });
                }
              });
            }
          });

          resolve(allCommentsData);
        });
      });
    }

    // Search comments by text
    function searchComments(comments, query) {
      if (!query || query.trim() === '') {
        return comments;
      }

      const searchTerm = query.toLowerCase().trim();
      return comments.filter(comment => {
        const text = (comment.text || comment.content || '').toLowerCase();
        return text.includes(searchTerm);
      });
    }

    // Filter comments by various attributes
    function filterComments(comments, filters) {
      let filtered = comments;

      // Team filter
      if (filters.team && filters.team !== '') {
        filtered = filtered.filter(comment => {
          if (comment.teams && Array.isArray(comment.teams)) {
            return comment.teams.some(t => t === filters.team);
          }
          return comment.team === filters.team;
        });
      }

      // Player filter
      if (filters.player && filters.player !== '') {
        // Get player IDs that match the selected player name
        const matchingPlayerIds = playerNameToIdMap.get(filters.player);
        if (matchingPlayerIds && matchingPlayerIds.size > 0) {
          filtered = filtered.filter(comment => {
            if (comment.players && Array.isArray(comment.players)) {
              return comment.players.some(p => {
                const playerId = typeof p === 'string' ? p : (p.id || p.name || '');
                return matchingPlayerIds.has(playerId);
              });
            }
            return false;
          });
        } else {
          // Fallback: try direct match (for legacy data or names stored directly)
          filtered = filtered.filter(comment => {
            if (comment.players && Array.isArray(comment.players)) {
              return comment.players.some(p => {
                const playerName = typeof p === 'string' ? p : (p.name || p.id || '');
                return playerName === filters.player;
              });
            }
            return false;
          });
        }
      }

      // Event filter
      if (filters.event && filters.event !== '') {
        filtered = filtered.filter(comment => {
          if (comment.events && Array.isArray(comment.events)) {
            return comment.events.includes(filters.event);
          }
          return false;
        });
      }

      // Zone filter
      if (filters.zone && filters.zone !== '') {
        filtered = filtered.filter(comment => {
          if (comment.zones && Array.isArray(comment.zones)) {
            return comment.zones.some(z => {
              const zoneStr = z.toString();
              return zoneStr.includes(filters.zone) || zoneStr === filters.zone;
            });
          }
          return false;
        });
      }

      // Intensity filter
      if (filters.intensity !== null && filters.intensity !== undefined && filters.intensity !== '') {
        filtered = filtered.filter(comment => {
          return comment.intensity !== null && comment.intensity !== undefined && 
                 comment.intensity.toString() === filters.intensity.toString();
        });
      }

      // Video filter
      if (filters.video && filters.video !== '') {
        filtered = filtered.filter(comment => {
          const videoId = filters.video;
          return comment.videoId === videoId || 
                 (comment.videoUrl && comment.videoUrl.includes(videoId)) ||
                 (comment.videoTitle && comment.videoTitle.includes(videoId));
        });
      }

      // Project filter
      if (filters.project && filters.project !== '') {
        filtered = filtered.filter(comment => {
          return comment.analysisId === filters.project;
        });
      }

      return filtered;
    }

    // Format comment text for display
    function formatCommentText(comment) {
      const text = comment.text || comment.content || '';
      // Remove timecode if present
      return text.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
    }

    // Format date for display
    function formatCommentDate(timestamp) {
      if (!timestamp) return 'N/A';
      const date = new Date(timestamp);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    // Display comments in table
    function displayComments(comments, page = 1) {
      const tableBody = document.getElementById('commentsDatabaseTableBody');
      const table = document.getElementById('commentsDatabaseTable');
      const emptyState = document.getElementById('commentsDatabaseEmpty');
      const loadingState = document.getElementById('commentsDatabaseLoading');
      const resultsCount = document.getElementById('commentsResultsCount');

      if (!tableBody) {
        console.error('commentsDatabaseTableBody not found');
        return;
      }

      if (loadingState) loadingState.style.display = 'none';

      if (resultsCount) {
        const count = comments.length;
        let countText = window.i18n ? window.i18n.t('commentsDatabase.resultsCount', { count }) : `${count} comment(s)`;
        countText = countText.replace('{count}', count);
        resultsCount.textContent = countText;
      }

      if (comments.length === 0) {
        if (table) table.style.display = 'none';
        if (emptyState) emptyState.style.display = 'block';
        return;
      }

      if (emptyState) emptyState.style.display = 'none';
      if (table) {
        table.style.display = 'table';
        table.style.visibility = 'visible';
      }

      const startIndex = (page - 1) * commentsPerPage;
      const endIndex = startIndex + commentsPerPage;
      const pageComments = comments.slice(startIndex, endIndex);

      tableBody.innerHTML = '';
      
      if (pageComments.length === 0) {
        return;
      }

      pageComments.forEach(comment => {
        const row = document.createElement('tr');
        
        const textCell = document.createElement('td');
        const textContent = formatCommentText(comment);
        textCell.className = 'comment-text-cell';
        
        // Create container for text with expand/collapse functionality
        const textContainer = document.createElement('div');
        textContainer.className = 'comment-text-container';
        
        const textDisplay = document.createElement('div');
        textDisplay.className = 'comment-text-display';
        textDisplay.textContent = textContent || '(No text)';
        
        // Check if text is long (more than 100 characters)
        const isLongText = textContent && textContent.length > 100;
        
        if (isLongText) {
          // Add truncated view
          const truncatedText = textContent.substring(0, 100) + '...';
          textDisplay.textContent = truncatedText;
          textDisplay.dataset.fullText = textContent;
          textDisplay.dataset.isExpanded = 'false';
          
          // Add expand/collapse button
          const expandBtn = document.createElement('button');
          expandBtn.className = 'comment-expand-btn';
          const showMoreText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('common.showMore')
            : 'Show more';
          expandBtn.textContent = showMoreText;
          expandBtn.type = 'button';
          
          expandBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isExpanded = textDisplay.dataset.isExpanded === 'true';
            
            if (isExpanded) {
              // Collapse
              textDisplay.textContent = truncatedText;
              textDisplay.dataset.isExpanded = 'false';
              const showMoreText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('common.showMore')
            : 'Show more';
          expandBtn.textContent = showMoreText;
              textDisplay.classList.remove('expanded');
            } else {
              // Expand
              textDisplay.textContent = textContent;
              textDisplay.dataset.isExpanded = 'true';
              const showLessText = (window.i18n && typeof window.i18n.t === 'function')
                ? window.i18n.t('common.showLess')
                : 'Show less';
              expandBtn.textContent = showLessText;
              textDisplay.classList.add('expanded');
            }
          });
          
          textContainer.appendChild(textDisplay);
          textContainer.appendChild(expandBtn);
        } else {
          // Short text - no expand button needed
          textContainer.appendChild(textDisplay);
        }
        
        textCell.appendChild(textContainer);
        textCell.title = textContent; // Keep title for tooltip
        row.appendChild(textCell);

        // Schemes column
        const schemesCell = document.createElement('td');
        schemesCell.className = 'comment-schemes-cell';
        
        // Only show schemes for scheme-type entries (not for regular comments that have schemes)
        // This prevents duplicates since we create separate scheme entries in loadAllComments()
        if (comment.type === 'scheme' && comment.slidesData) {
          // This is a scheme entry - show preview
          const schemePreview = document.createElement('div');
          schemePreview.className = 'scheme-preview-container';
          schemePreview.style.cursor = 'pointer';
          schemePreview.style.display = 'inline-block';
          
          // Create thumbnail placeholder
          const thumbnail = document.createElement('div');
          thumbnail.className = 'scheme-thumbnail';
          thumbnail.style.width = '60px';
          thumbnail.style.height = '40px';
          thumbnail.style.background = '#161b22';
          thumbnail.style.border = '1px solid #30363d';
          thumbnail.style.borderRadius = '4px';
          thumbnail.style.display = 'flex';
          thumbnail.style.alignItems = 'center';
          thumbnail.style.justifyContent = 'center';
          thumbnail.style.color = '#8b949e';
          thumbnail.style.fontSize = '10px';
          thumbnail.textContent = 'Scheme';
          
          schemePreview.appendChild(thumbnail);
          schemePreview.title = 'Click to view scheme';
          
          // Generate thumbnail preview asynchronously
          (async () => {
            try {
              const defaultBackground = chrome.runtime.getURL('icons/soccer-145794.svg');
              const firstSlide = comment.slidesData[0];
              if (firstSlide && firstSlide.drawings && firstSlide.drawings.length > 0) {
                const renderedImage = await renderImagePreviewWithDrawings(
                  firstSlide.backgroundImage || defaultBackground,
                  firstSlide.drawings
                );
                thumbnail.style.backgroundImage = `url(${renderedImage})`;
                thumbnail.style.backgroundSize = 'cover';
                thumbnail.style.backgroundPosition = 'center';
                thumbnail.textContent = '';
              }
            } catch (error) {
              console.error('Error generating scheme thumbnail:', error);
            }
          })();
          
          // Add click handler to open scheme viewer
          schemePreview.addEventListener('click', (e) => {
            e.stopPropagation();
            openSchemeViewer(comment);
          });
          
          schemesCell.appendChild(schemePreview);
        } else {
          // Regular comment - don't show schemes here to avoid duplicates
          // Schemes are shown as separate entries (type === 'scheme')
          schemesCell.textContent = '-';
        }
        row.appendChild(schemesCell);

        const teamCell = document.createElement('td');
        const teams = comment.teams || (comment.team ? [comment.team] : []);
        if (teams.length > 0) {
          teams.forEach(team => {
            const tag = document.createElement('span');
            tag.className = 'comment-attribute-tag';
            tag.textContent = team;
            teamCell.appendChild(tag);
          });
        } else {
          teamCell.textContent = '-';
        }
        row.appendChild(teamCell);

        const playersCell = document.createElement('td');
        if (comment.players && Array.isArray(comment.players) && comment.players.length > 0) {
          // Resolve player IDs to names
          const playerNames = [];
          comment.players.forEach(playerId => {
            // Try to find player name from the mapping
            let playerName = playerId;
            for (const [name, ids] of playerNameToIdMap.entries()) {
              if (ids.has(playerId)) {
                playerName = name;
                break;
              }
            }
            // If not found in mapping, keep as ID
            if (playerName === playerId && typeof playerId === 'string') {
              playerName = playerId;
            }
            playerNames.push(playerName);
          });
          playerNames.forEach(playerName => {
            const tag = document.createElement('span');
            tag.className = 'comment-attribute-tag';
            tag.textContent = playerName;
            playersCell.appendChild(tag);
          });
        } else {
          playersCell.textContent = '-';
        }
        row.appendChild(playersCell);

        const eventsCell = document.createElement('td');
        if (comment.events && Array.isArray(comment.events) && comment.events.length > 0) {
          comment.events.forEach(event => {
            const tag = document.createElement('span');
            tag.className = 'comment-attribute-tag';
            tag.textContent = event;
            eventsCell.appendChild(tag);
          });
        } else {
          eventsCell.textContent = '-';
        }
        row.appendChild(eventsCell);

        const zonesCell = document.createElement('td');
        if (comment.zones && Array.isArray(comment.zones) && comment.zones.length > 0) {
          comment.zones.forEach(zone => {
            const tag = document.createElement('span');
            tag.className = 'comment-attribute-tag';
            tag.textContent = zone.toString();
            zonesCell.appendChild(tag);
          });
        } else {
          zonesCell.textContent = '-';
        }
        row.appendChild(zonesCell);

        const videoCell = document.createElement('td');
        videoCell.className = 'comment-video-cell';
        videoCell.textContent = comment.videoTitle || comment.videoUrl || '-';
        videoCell.title = comment.videoTitle || comment.videoUrl || '';
        row.appendChild(videoCell);

        const dateCell = document.createElement('td');
        dateCell.className = 'comment-date-cell';
        dateCell.textContent = formatCommentDate(comment.timestamp);
        row.appendChild(dateCell);

        const projectCell = document.createElement('td');
        projectCell.className = 'comment-project-cell';
        const unknownText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.unknown')
          : 'Unknown';
        projectCell.textContent = comment.analysisName || unknownText;
        row.appendChild(projectCell);

        // Actions column with edit button
        const actionsCell = document.createElement('td');
        actionsCell.className = 'comment-actions-cell';

        const editBtn = document.createElement('button');
        editBtn.className = 'comment-edit-btn';
        editBtn.title = 'Edit comment';
        editBtn.innerHTML = `
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
          </svg>
        `;
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          editComment(comment);
        });

        actionsCell.appendChild(editBtn);
        row.appendChild(actionsCell);

        tableBody.appendChild(row);
      });

      updatePagination(comments.length, page);
    }

    // Edit comment function
    function editComment(comment) {
      const noteInput = document.getElementById('distatsNoteInput');
      if (!noteInput) return;

      // Populate textarea with comment text
      const commentText = formatCommentText(comment);
      noteInput.value = commentText;
      noteInput.focus();

      // Set editing mode
      editingCommentId = comment.id;

      // Update send button text to indicate editing
      const addBtn = document.getElementById('distatsAddBtn');
      if (addBtn) {
        addBtn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
          </svg>
        `;
        addBtn.title = 'Update comment';
      }

      // Scroll to the chat input area
      const chatSection = document.querySelector('.chat-section');
      if (chatSection) {
        chatSection.scrollIntoView({ behavior: 'smooth' });
      }
    }

    // Cancel edit mode
    function cancelEdit() {
      editingCommentId = null;
      const noteInput = document.getElementById('distatsNoteInput');
      const addBtn = document.getElementById('distatsAddBtn');

      if (noteInput) {
        noteInput.value = '';
      }

      if (addBtn) {
        addBtn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        `;
        addBtn.title = 'Send message';
      }
    }

    // Update existing comment
    async function updateComment(commentId, newContent, imageData = null) {
      if (!currentAnalysisId) {
        console.error('No current analysis');
        return;
      }

      // Normalize imageData to array
      let imagesArray = null;
      if (imageData) {
        if (Array.isArray(imageData)) {
          imagesArray = imageData;
        } else {
          imagesArray = [imageData];
        }
      }

      return new Promise((resolve, reject) => {
        chrome.storage.local.get(['analyses'], (result) => {
          if (handleStorageError(null, 'updateComment')) {
            reject(new Error('Failed to get analyses'));
            return;
          }

          const analyses = result.analyses || [];
          const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

          if (analysisIndex !== -1) {
            const analysis = analyses[analysisIndex];
            const noteIndex = analysis.notes.findIndex(note => note.id === commentId);

            if (noteIndex !== -1) {
              const note = analysis.notes[noteIndex];

              // Update the note content
              note.content = newContent;
              note.text = newContent;
              note.timestamp = Date.now(); // Update timestamp to show it was edited

              // Update images if provided
              if (imagesArray && imagesArray.length > 0) {
                // Validate images
                const validImages = imagesArray.filter(img => {
                  if (!img) return false;
                  const isValid = typeof img === 'string' &&
                    (img.startsWith('data:image/') || img.startsWith('blob:'));
                  if (!isValid) {
                    console.warn('Skipping invalid image data in update:', typeof img, img ? img.substring(0, 50) : 'null');
                  }
                  return isValid;
                });

                if (validImages.length > 0) {
                  note.images = validImages;
                  note.image = validImages[0];
                }
              }

              // Get selected events, zones, players, intensity for update
              const eventsToSave = selectedEvents.length > 0 ? [...selectedEvents] : null;
              const zonesToSave = selectedZones.length > 0 ? [...selectedZones] : null;
              const playersToSave = selectedPlayers.length > 0 ? [...selectedPlayers] : null;
              const intensityToSave = selectedIntensity !== null ? selectedIntensity : null;

              // Update metadata
              note.events = eventsToSave;
              note.zones = zonesToSave;
              note.players = playersToSave;
              note.intensity = intensityToSave;

              // Update teams (get from selected teams and players)
              chrome.storage.local.get(['players'], (playerResult) => {
                const players = playerResult.players || [];
                const selectedPlayerObjects = playersToSave ? players.filter(p => playersToSave.includes(p.id)) : [];
                const teamsFromPlayers = [...new Set(selectedPlayerObjects.map(p => p.team).filter(t => t && t.trim() !== ''))];

                const allTeams = new Set();
                if (selectedTeam) allTeams.add(selectedTeam);
                selectedTeams.forEach(team => allTeams.add(team));
                teamsFromPlayers.forEach(team => allTeams.add(team));

                const teamsToSave = allTeams.size > 0 ? Array.from(allTeams) : null;
                note.teams = teamsToSave;
                note.team = teamsToSave && teamsToSave.length > 0 ? teamsToSave[0] : null;

                // Save the updated analysis
                chrome.storage.local.set({ analyses: analyses }, () => {
                  if (handleStorageError(null, 'updateComment-set')) {
                    reject(new Error('Failed to update comment'));
                    return;
                  }

                  // Refresh the comments display
                  loadAllComments();

                  // Clear selected items after update
                  selectedEvents = [];
                  selectedZones = [];
                  selectedPlayers = [];
                  selectedTeams = [];
                  selectedIntensity = null;
                  selectedTeam = null;
                  updateSelectedEventsDisplay();
                  updateSelectedZonesDisplay();
                  updateSelectedPlayersDisplay();

                  resolve();
                });
              });
            } else {
              reject(new Error('Comment not found'));
            }
          } else {
            reject(new Error('Analysis not found'));
          }
        });
      });
    }

    // Update pagination controls
    function updatePagination(totalComments, page) {
      const prevBtn = document.getElementById('commentsDatabasePrevPage');
      const nextBtn = document.getElementById('commentsDatabaseNextPage');
      const pageInfo = document.getElementById('commentsDatabasePageInfo');

      const totalPages = Math.ceil(totalComments / commentsPerPage);
      currentPage = page;

      if (prevBtn) prevBtn.disabled = page <= 1;
      if (nextBtn) nextBtn.disabled = page >= totalPages;
      if (pageInfo) {
        const start = (page - 1) * commentsPerPage + 1;
        const end = Math.min(page * commentsPerPage, totalComments);
        pageInfo.textContent = `${start}-${end} of ${totalComments}`;
      }
    }

    // Populate filter dropdowns with unique values
    async function populateFilterDropdowns(comments) {
      const teams = new Set();
      const playerIds = new Set();
      const events = new Set();
      const zones = new Set();
      const videos = new Map();
      const projects = new Map();

      // First pass: collect all IDs and values
      comments.forEach(comment => {
        // Collect teams
        if (comment.teams && Array.isArray(comment.teams)) {
          comment.teams.forEach(t => {
            if (t && t.trim() !== '') teams.add(t);
          });
        } else if (comment.team && comment.team.trim() !== '') {
          teams.add(comment.team);
        }

        // Collect player IDs
        if (comment.players && Array.isArray(comment.players)) {
          comment.players.forEach(p => {
            if (typeof p === 'string') {
              playerIds.add(p);
            } else if (p && (p.id || p.name)) {
              playerIds.add(p.id || p.name);
            }
          });
        }

        // Collect events
        if (comment.events && Array.isArray(comment.events)) {
          comment.events.forEach(e => {
            if (e && e.trim() !== '') events.add(e);
          });
        }

        // Collect zones
        if (comment.zones && Array.isArray(comment.zones)) {
          comment.zones.forEach(z => {
            if (z !== null && z !== undefined) {
              const zoneStr = z.toString().trim();
              if (zoneStr !== '') zones.add(zoneStr);
            }
          });
        }

        // Collect videos
        if (comment.videoId || comment.videoTitle) {
          const videoKey = comment.videoId || comment.videoTitle;
          if (videoKey && !videos.has(videoKey)) {
            videos.set(videoKey, comment.videoTitle || comment.videoUrl || videoKey);
          }
        }

        // Collect projects
        if (comment.analysisId && comment.analysisName) {
          projects.set(comment.analysisId, comment.analysisName);
        }
      });

      // Load players from storage to resolve IDs to names
      const playersMap = new Map();
      try {
        const playerResult = await new Promise((resolve) => {
          chrome.storage.local.get(['players'], resolve);
        });
        const allPlayers = playerResult.players || [];
        allPlayers.forEach(player => {
          if (player && player.id) {
            const displayName = player.number ? 
              `#${player.number} ${player.fullName || player.name || ''}`.trim() : 
              (player.fullName || player.name || player.id);
            playersMap.set(player.id, displayName);
          }
        });
      } catch (error) {
        console.error('Error loading players:', error);
      }

      // Resolve player IDs to names and create reverse mapping
      const players = new Set();
      playerNameToIdMap.clear(); // Reset mapping
      playerIds.forEach(playerId => {
        const playerName = playersMap.get(playerId) || playerId;
        if (playerName) {
          players.add(playerName);
          // Create reverse mapping: name -> ID (handle multiple IDs with same name)
          if (!playerNameToIdMap.has(playerName)) {
            playerNameToIdMap.set(playerName, new Set());
          }
          playerNameToIdMap.get(playerName).add(playerId);
        }
      });

      const teamSelect = document.getElementById('commentsFilterTeam');
      if (teamSelect) {
        const currentValue = teamSelect.value;
        teamSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allTeams">All Teams</option>';
        Array.from(teams).sort().forEach(team => {
          const option = document.createElement('option');
          option.value = team;
          option.textContent = team;
          teamSelect.appendChild(option);
        });
        if (currentValue) teamSelect.value = currentValue;
      }

      const playerSelect = document.getElementById('commentsFilterPlayer');
      if (playerSelect) {
        const currentValue = playerSelect.value;
        playerSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allPlayers">All Players</option>';
        Array.from(players).sort().forEach(playerName => {
          const option = document.createElement('option');
          option.value = playerName; // Store display name as value
          option.textContent = playerName;
          playerSelect.appendChild(option);
        });
        if (currentValue) playerSelect.value = currentValue;
      }

      const eventSelect = document.getElementById('commentsFilterEvent');
      if (eventSelect) {
        const currentValue = eventSelect.value;
        eventSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allEvents">All Events</option>';
        Array.from(events).sort().forEach(event => {
          const option = document.createElement('option');
          option.value = event;
          option.textContent = event;
          eventSelect.appendChild(option);
        });
        if (currentValue) eventSelect.value = currentValue;
      }

      const zoneSelect = document.getElementById('commentsFilterZone');
      if (zoneSelect) {
        const currentValue = zoneSelect.value;
        zoneSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allZones">All Zones</option>';
        Array.from(zones).sort((a, b) => {
          const numA = parseInt(a) || 0;
          const numB = parseInt(b) || 0;
          return numA - numB;
        }).forEach(zone => {
          const option = document.createElement('option');
          option.value = zone;
          option.textContent = `Zone ${zone}`;
          zoneSelect.appendChild(option);
        });
        if (currentValue) zoneSelect.value = currentValue;
      }

      const videoSelect = document.getElementById('commentsFilterVideo');
      if (videoSelect) {
        const currentValue = videoSelect.value;
        videoSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allVideos">All Videos</option>';
        Array.from(videos.entries()).sort((a, b) => a[1].localeCompare(b[1])).forEach(([key, title]) => {
          const option = document.createElement('option');
          option.value = key;
          option.textContent = title;
          videoSelect.appendChild(option);
        });
        if (currentValue) videoSelect.value = currentValue;
      }

      const projectSelect = document.getElementById('commentsFilterProject');
      if (projectSelect) {
        const currentValue = projectSelect.value;
        projectSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allProjects">All Projects</option>';
        Array.from(projects.entries()).sort((a, b) => a[1].localeCompare(b[1])).forEach(([id, name]) => {
          const option = document.createElement('option');
          option.value = id;
          option.textContent = name;
          projectSelect.appendChild(option);
        });
        if (currentValue) projectSelect.value = currentValue;
      }
      
      // Apply translations to dynamically created elements
      if (window.i18n && window.i18n.updateI18nElements) {
        window.i18n.updateI18nElements();
      }
    }

    // Apply filters and search
    function applyFiltersAndSearch() {
      const searchQuery = document.getElementById('commentsDatabaseSearch')?.value || '';
      const filters = {
        team: document.getElementById('commentsFilterTeam')?.value || '',
        player: document.getElementById('commentsFilterPlayer')?.value || '',
        event: document.getElementById('commentsFilterEvent')?.value || '',
        zone: document.getElementById('commentsFilterZone')?.value || '',
        intensity: document.getElementById('commentsFilterIntensity')?.value || '',
        video: document.getElementById('commentsFilterVideo')?.value || '',
        project: document.getElementById('commentsFilterProject')?.value || ''
      };

      let results = filterComments(allCommentsData, filters);
      results = searchComments(results, searchQuery);

      filteredComments = results;
      currentPage = 1;
      displayComments(results, 1);
    }

    // Load players mapping for display
    async function loadPlayersMapping() {
      try {
        const playerResult = await new Promise((resolve) => {
          chrome.storage.local.get(['players'], resolve);
        });
        const allPlayers = playerResult.players || [];
        const tempMap = new Map();
        allPlayers.forEach(player => {
          if (player && player.id) {
            const displayName = player.number ? 
              `#${player.number} ${player.fullName || player.name || ''}`.trim() : 
              (player.fullName || player.name || player.id);
            if (!tempMap.has(displayName)) {
              tempMap.set(displayName, new Set());
            }
            tempMap.get(displayName).add(player.id);
          }
        });
        // Update global mapping
        playerNameToIdMap = tempMap;
      } catch (error) {
        console.error('Error loading players mapping:', error);
      }
    }

    // Load players mapping for display (separate from populateFilterDropdowns)
    async function loadPlayersMappingForDisplay() {
      try {
        const playerResult = await new Promise((resolve) => {
          chrome.storage.local.get(['players'], resolve);
        });
        const allPlayers = playerResult.players || [];
        playerNameToIdMap.clear();
        allPlayers.forEach(player => {
          if (player && player.id) {
            const displayName = player.number ? 
              `#${player.number} ${player.fullName || player.name || ''}`.trim() : 
              (player.fullName || player.name || player.id);
            if (!playerNameToIdMap.has(displayName)) {
              playerNameToIdMap.set(displayName, new Set());
            }
            playerNameToIdMap.get(displayName).add(player.id);
          }
        });
      } catch (error) {
        console.error('Error loading players mapping:', error);
      }
    }

    // Open comments database modal
    async function openCommentsDatabase() {
      const modal = document.getElementById('commentsDatabaseModal');
      if (!modal) {
        console.error('commentsDatabaseModal not found');
        return;
      }

      modal.classList.remove('hidden');
      
      const loadingState = document.getElementById('commentsDatabaseLoading');
      const table = document.getElementById('commentsDatabaseTable');
      const emptyState = document.getElementById('commentsDatabaseEmpty');
      if (loadingState) loadingState.style.display = 'block';
      if (table) table.style.display = 'none';
      if (emptyState) emptyState.style.display = 'none';

      try {
        await loadAllComments();
        console.log('Loaded comments:', allCommentsData.length);
        
        // Load players mapping for display
        await loadPlayersMappingForDisplay();
        
        await populateFilterDropdowns(allCommentsData);
        filteredComments = allCommentsData;
        currentPage = 1;
        displayComments(allCommentsData, 1);
      } catch (error) {
        console.error('Error loading comments:', error);
        if (loadingState) loadingState.style.display = 'none';
        if (emptyState) {
          const errorText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('commentsDatabase.errorLoadingComments', { message: error.message })
            : 'Error loading comments: ' + error.message;
          emptyState.textContent = errorText;
          emptyState.style.display = 'block';
        }
      }
    }

    // Comments Database Modal handlers
    const commentsDatabaseModal = document.getElementById('commentsDatabaseModal');
    const closeCommentsDatabaseModal = document.getElementById('closeCommentsDatabaseModal');
    const commentsDatabaseDropdownItem = document.getElementById('commentsDatabaseDropdownItem');

    if (commentsDatabaseDropdownItem) {
      commentsDatabaseDropdownItem.addEventListener('click', () => {
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
          savingOptionsDropdown.style.display = 'none';
        }
        openCommentsDatabase();
      });
    }

    if (closeCommentsDatabaseModal) {
      closeCommentsDatabaseModal.addEventListener('click', () => {
        if (commentsDatabaseModal) {
          commentsDatabaseModal.classList.add('hidden');
        }
      });
    }

    if (commentsDatabaseModal) {
      commentsDatabaseModal.addEventListener('click', (e) => {
        if (e.target === commentsDatabaseModal) {
          commentsDatabaseModal.classList.add('hidden');
        }
      });
    }

    // Search input handler with debouncing
    const commentsDatabaseSearch = document.getElementById('commentsDatabaseSearch');
    if (commentsDatabaseSearch) {
      commentsDatabaseSearch.addEventListener('input', () => {
        clearTimeout(searchDebounceTimer);
        searchDebounceTimer = setTimeout(() => {
          applyFiltersAndSearch();
        }, 300);
      });
    }

    // Filter change handlers
    ['commentsFilterTeam', 'commentsFilterPlayer', 'commentsFilterEvent', 
     'commentsFilterZone', 'commentsFilterIntensity', 'commentsFilterVideo', 
     'commentsFilterProject'].forEach(filterId => {
      const filterElement = document.getElementById(filterId);
      if (filterElement) {
        filterElement.addEventListener('change', () => {
          applyFiltersAndSearch();
        });
      }
    });

    // Clear filters button
    const clearCommentsFiltersBtn = document.getElementById('clearCommentsFiltersBtn');
    if (clearCommentsFiltersBtn) {
      clearCommentsFiltersBtn.addEventListener('click', () => {
        document.getElementById('commentsDatabaseSearch').value = '';
        document.getElementById('commentsFilterTeam').value = '';
        document.getElementById('commentsFilterPlayer').value = '';
        document.getElementById('commentsFilterEvent').value = '';
        document.getElementById('commentsFilterZone').value = '';
        document.getElementById('commentsFilterIntensity').value = '';
        document.getElementById('commentsFilterVideo').value = '';
        document.getElementById('commentsFilterProject').value = '';
        applyFiltersAndSearch();
      });
    }

    // Pagination handlers
    const commentsDatabasePrevPage = document.getElementById('commentsDatabasePrevPage');
    const commentsDatabaseNextPage = document.getElementById('commentsDatabaseNextPage');

    if (commentsDatabasePrevPage) {
      commentsDatabasePrevPage.addEventListener('click', () => {
        if (currentPage > 1) {
          displayComments(filteredComments, currentPage - 1);
        }
      });
    }

    if (commentsDatabaseNextPage) {
      commentsDatabaseNextPage.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredComments.length / commentsPerPage);
        if (currentPage < totalPages) {
          displayComments(filteredComments, currentPage + 1);
        }
      });
    }

    // Scheme Viewer Modal
    let currentSchemeViewerData = null;
    let currentSchemeSlideIndex = 0;

    async function openSchemeViewer(scheme) {
      const modal = document.getElementById('schemeViewerModal');
      const title = document.getElementById('schemeViewerTitle');
      const content = document.getElementById('schemeViewerContent');
      const navigation = document.getElementById('schemeViewerNavigation');
      const prevBtn = document.getElementById('schemeViewerPrevSlide');
      const nextBtn = document.getElementById('schemeViewerNextSlide');
      const slideInfo = document.getElementById('schemeViewerSlideInfo');

      if (!modal || !content) {
        console.error('Scheme viewer modal elements not found');
        return;
      }

      currentSchemeViewerData = scheme;
      currentSchemeSlideIndex = 0;

      // Set title
      const timecode = scheme.timecode ? scheme.timecode[0] : (scheme.videoTime ? `[${Math.floor(scheme.videoTime / 60)}:${String(Math.floor(scheme.videoTime % 60)).padStart(2, '0')}]` : '');
      if (title) {
        title.textContent = `Tactical Scheme ${timecode}`;
      }

      // Show modal
      modal.classList.remove('hidden');

      // Render scheme slides
      await renderSchemeInModal(scheme, content, navigation, prevBtn, nextBtn, slideInfo);
    }

    async function renderSchemeInModal(scheme, content, navigation, prevBtn, nextBtn, slideInfo) {
      if (!scheme || !scheme.slidesData || scheme.slidesData.length === 0) {
        content.innerHTML = '<div style="color: #8b949e; padding: 12px; text-align: center;">No scheme data available</div>';
        if (navigation) navigation.style.display = 'none';
        return;
      }

      const defaultBackground = chrome.runtime.getURL('icons/soccer-145794.svg');
      const slides = scheme.slidesData;
      
      // Update navigation visibility
      if (navigation) {
        navigation.style.display = slides.length > 1 ? 'block' : 'none';
      }

      // Render all slides
      content.innerHTML = '';
      const slideContainers = [];

      for (let slideIndex = 0; slideIndex < slides.length; slideIndex++) {
        const slide = slides[slideIndex];
        const slideContainer = document.createElement('div');
        slideContainer.className = 'scheme-slide-container';
        slideContainer.style.display = slideIndex === 0 ? 'block' : 'none';
        slideContainer.style.marginBottom = '20px';
        slideContainer.style.textAlign = 'center';

        const slideLabel = document.createElement('div');
        slideLabel.style.fontSize = '14px';
        slideLabel.style.color = '#8b949e';
        slideLabel.style.marginBottom = '12px';
        slideLabel.textContent = `Slide ${slideIndex + 1} of ${slides.length}`;
        slideContainer.appendChild(slideLabel);

        const slideImage = document.createElement('img');
        slideImage.style.maxWidth = '100%';
        slideImage.style.height = 'auto';
        slideImage.style.borderRadius = '8px';
        slideImage.style.border = '1px solid #21262d';
        slideImage.style.background = '#0d1117';
        slideImage.alt = `Scheme slide ${slideIndex + 1}`;

        // Render slide
        try {
          const renderedImage = await renderImagePreviewWithDrawings(
            slide.backgroundImage || defaultBackground,
            slide.drawings || []
          );
          slideImage.src = renderedImage;
        } catch (error) {
          console.error('Error rendering scheme slide:', error);
          slideImage.src = '';
          slideImage.style.display = 'none';
          const errorDiv = document.createElement('div');
          errorDiv.style.color = '#f85149';
          errorDiv.textContent = `Error rendering slide ${slideIndex + 1}`;
          slideContainer.appendChild(errorDiv);
        }

        slideContainer.appendChild(slideImage);
        content.appendChild(slideContainer);
        slideContainers.push(slideContainer);
      }

      // Update slide info
      if (slideInfo) {
        slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
      }

      // Navigation handlers
      if (prevBtn) {
        prevBtn.onclick = () => {
          if (currentSchemeSlideIndex > 0) {
            slideContainers[currentSchemeSlideIndex].style.display = 'none';
            currentSchemeSlideIndex--;
            slideContainers[currentSchemeSlideIndex].style.display = 'block';
            if (slideInfo) {
              slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
            }
            prevBtn.disabled = currentSchemeSlideIndex === 0;
            if (nextBtn) nextBtn.disabled = false;
          }
        };
        prevBtn.disabled = currentSchemeSlideIndex === 0;
      }

      if (nextBtn) {
        nextBtn.onclick = () => {
          if (currentSchemeSlideIndex < slides.length - 1) {
            slideContainers[currentSchemeSlideIndex].style.display = 'none';
            currentSchemeSlideIndex++;
            slideContainers[currentSchemeSlideIndex].style.display = 'block';
            if (slideInfo) {
              slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
            }
            nextBtn.disabled = currentSchemeSlideIndex === slides.length - 1;
            if (prevBtn) prevBtn.disabled = false;
          }
        };
        nextBtn.disabled = currentSchemeSlideIndex === slides.length - 1;
      }
    }

    // Scheme Viewer Modal handlers
    const schemeViewerModal = document.getElementById('schemeViewerModal');
    const closeSchemeViewerModal = document.getElementById('closeSchemeViewerModal');

    if (closeSchemeViewerModal) {
      closeSchemeViewerModal.addEventListener('click', () => {
        if (schemeViewerModal) {
          schemeViewerModal.classList.add('hidden');
          currentSchemeViewerData = null;
          currentSchemeSlideIndex = 0;
        }
      });
    }

    if (schemeViewerModal) {
      schemeViewerModal.addEventListener('click', (e) => {
        if (e.target === schemeViewerModal) {
          schemeViewerModal.classList.add('hidden');
          currentSchemeViewerData = null;
          currentSchemeSlideIndex = 0;
        }
      });
    }

    // Save language settings
    if (saveSettingsBtn && interfaceLanguageSelect) {
      saveSettingsBtn.addEventListener('click', async () => {
        const newLang = interfaceLanguageSelect.value;
        if (window.i18n && window.i18n.setLanguage) {
          await window.i18n.setLanguage(newLang);
          // Update sidebar elements with new translations
          if (window.i18n.updateI18nElements) {
            window.i18n.updateI18nElements();
          }
          // Update project button text if needed
          updateProjectButtonText();
          // Close modal after saving
          if (settingsModal) {
            settingsModal.classList.add('hidden');
          }
        }
      });
    }

    // Import project file selection
    if (selectImportProjectFileBtn) {
      selectImportProjectFileBtn.addEventListener('click', () => {
        importProjectFileInput.click();
      });
    }

    if (importProjectFileInput) {
      importProjectFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          importProjectFileName.textContent = file.name;
          importProjectFileName.style.display = 'block';
          importProjectError.style.display = 'none';
          confirmImportProjectBtn.disabled = false;
        } else {
          importProjectFileName.textContent = '';
          importProjectFileName.style.display = 'none';
          confirmImportProjectBtn.disabled = true;
        }
      });
    }

    // Restore backup file selection
    if (selectRestoreBackupFileBtn) {
      selectRestoreBackupFileBtn.addEventListener('click', () => {
        restoreBackupFileInput.click();
      });
    }

    if (restoreBackupFileInput) {
      restoreBackupFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          restoreBackupFileName.textContent = file.name;
          restoreBackupFileName.style.display = 'block';
          restoreBackupError.style.display = 'none';
          confirmRestoreBackupBtn.disabled = false;
        } else {
          restoreBackupFileName.textContent = '';
          restoreBackupFileName.style.display = 'none';
          confirmRestoreBackupBtn.disabled = true;
        }
      });
    }

    // Confirm import project
    if (confirmImportProjectBtn) {
      confirmImportProjectBtn.addEventListener('click', async () => {
        const file = importProjectFileInput.files[0];
        if (!file) return;

        try {
          confirmImportProjectBtn.disabled = true;
          importProjectError.style.display = 'none';
          
          const result = await window.backupUtils.importProject(file, { renameOnConflict: true });
          
          if (result.success) {
            alert(result.message);
            importProjectModal.classList.add('hidden');
            // Reload current analysis
            loadCurrentAnalysis();
          }
        } catch (error) {
          console.error('Import error:', error);
          const importErrorText = (window.i18n && typeof window.i18n.t === 'function')
            ? (error.message || window.i18n.t('saving.errorImportingProject'))
            : (error.message || 'Error importing project');
          importProjectError.textContent = importErrorText;
          importProjectError.style.display = 'block';
        } finally {
          confirmImportProjectBtn.disabled = false;
        }
      });
    }

    // Confirm restore backup
    if (confirmRestoreBackupBtn) {
      confirmRestoreBackupBtn.addEventListener('click', async () => {
        const file = restoreBackupFileInput.files[0];
        if (!file) return;

        const confirmRestoreText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('saving.confirmRestoreBackup')
          : 'Are you sure you want to restore from backup? This will replace all existing data!';
        if (!confirm(confirmRestoreText)) {
          return;
        }

        try {
          confirmRestoreBackupBtn.disabled = true;
          restoreBackupError.style.display = 'none';
          
          const result = await window.backupUtils.importBackup(file);
          
          if (result.success) {
            alert(result.message);
            restoreBackupModal.classList.add('hidden');
            // Reload page to refresh all data
            location.reload();
          }
        } catch (error) {
          console.error('Restore error:', error);
          const restoreErrorText = (window.i18n && typeof window.i18n.t === 'function')
            ? (error.message || window.i18n.t('saving.errorRestoringBackup'))
            : (error.message || 'Error restoring backup');
          restoreBackupError.textContent = restoreErrorText;
          restoreBackupError.style.display = 'block';
        } finally {
          confirmRestoreBackupBtn.disabled = false;
        }
      });
    }

    // Close modals
    if (closeImportProjectModal) {
      closeImportProjectModal.addEventListener('click', () => {
        importProjectModal.classList.add('hidden');
      });
    }

    if (closeRestoreBackupModal) {
      closeRestoreBackupModal.addEventListener('click', () => {
        restoreBackupModal.classList.add('hidden');
      });
    }


    // Close modals on background click
    if (importProjectModal) {
      importProjectModal.addEventListener('click', (e) => {
        if (e.target === importProjectModal) {
          importProjectModal.classList.add('hidden');
        }
      });
    }

    if (restoreBackupModal) {
      restoreBackupModal.addEventListener('click', (e) => {
        if (e.target === restoreBackupModal) {
          restoreBackupModal.classList.add('hidden');
        }
      });
    }

    // Project selector functionality
    // Project selection is now handled via button click or dropdown
    // The change event is no longer needed as we use the button text to show current project
    // Keep this for backward compatibility but it won't be used
    const projectSelect = null;
    if (false && projectSelect) {
      projectSelect.addEventListener('change', (e) => {
        const selectedProjectId = e.target.value;
        if (selectedProjectId) {
          // Load the selected project
          currentAnalysisId = selectedProjectId;
          // Show export buttons when project is selected
          const exportProjectDropdownItem = document.getElementById('distatsExportProjectDropdownItem');
          if (exportProjectDropdownItem) {
            exportProjectDropdownItem.style.display = selectedProjectId ? 'flex' : 'none';
          }
          const exportNotesDropdownItem = document.getElementById('distatsExportNotesDropdownItem');
          if (exportNotesDropdownItem) {
            exportNotesDropdownItem.style.display = selectedProjectId ? 'flex' : 'none';
          }
          if (false) { // Keep bracket matching for existing code
          }
          chrome.storage.local.set({ currentAnalysisId: selectedProjectId }, () => {
            loadCurrentAnalysis();
          });
        }
      });
    }

    // Image attachment functionality
    const imageInput = document.getElementById('distatsImageInput');
    attachImageBtn = document.getElementById('distatsAttachImageBtn');
    const attachTacticalEditorBtn = document.getElementById('distatsAttachTacticalEditorBtn');
    const tacticalEditorDropdown = document.getElementById('distatsTacticalEditorDropdown');
    imagePreviewContainer = document.getElementById('distatsImagePreviewContainer');

    // Compress image to reduce memory usage
    function compressImage(file, maxWidth = 1200, maxHeight = 1200, quality = 0.95) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;

            // Calculate new dimensions
            if (width > height) {
              if (width > maxWidth) {
                height = (height * maxWidth) / width;
                width = maxWidth;
              }
            } else {
              if (height > maxHeight) {
                width = (width * maxHeight) / height;
                height = maxHeight;
              }
            }

            canvas.width = width;
            canvas.height = height;

            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            // Convert to base64 with compression
            const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
            resolve(compressedDataUrl);
          };
          img.onerror = reject;
          img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }

    // Handle image processing
    async function processImageFile(file) {
      if (!file || !file.type.startsWith('image/')) {
        return;
      }
      
      try {
        if (attachImageBtn) {
          attachImageBtn.disabled = true;
        }
        const compressedImage = await compressImage(file);
        pendingImages.push({ imageData: compressedImage, slidesData: null });
        updateImagePreview();
        if (attachImageBtn) {
          attachImageBtn.disabled = false;
        }
      } catch (error) {
        console.error('Error compressing image:', error);
        alert('Error processing image. Please try again.');
        if (attachImageBtn) {
          attachImageBtn.disabled = false;
        }
      }
    }

    if (attachImageBtn && imageInput) {
      attachImageBtn.addEventListener('click', () => {
        imageInput.click();
      });

      imageInput.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        if (files.length > 0) {
          for (const file of files) {
            await processImageFile(file);
          }
        }
        e.target.value = '';
      });
    }

    // Voice input functionality
    const voiceInputBtn = document.getElementById('distatsVoiceInputBtn');
    const voiceInputIcon = document.getElementById('distatsVoiceInputIcon');
    const voiceInputPulse = document.getElementById('distatsVoiceInputPulse');
    let isRecording = false;
    let isProcessing = false;

    if (voiceInputBtn && noteInput) {
      voiceInputBtn.addEventListener('click', async () => {
        if (isProcessing) {
          return; // Prevent multiple simultaneous recordings
        }

        if (!isRecording) {
          // Start recording
          try {
            // Check for API key
            const apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
            if (!apiKey) {
              alert('OpenAI API key is required for voice input. Please configure it in AI Analysis Settings.');
              return;
            }

            await window.aiAnalysisUtils.startRecording();
            isRecording = true;
            
            // Update UI
            voiceInputBtn.classList.add('recording');
            if (voiceInputIcon) {
              voiceInputIcon.style.color = '#da3633'; // Red color
            }
            if (voiceInputPulse) {
              voiceInputPulse.classList.remove('hidden');
            }
            voiceInputBtn.disabled = false;
          } catch (error) {
            console.error('Error starting recording:', error);
            alert(error.message || 'Failed to start recording. Please check microphone permissions.');
            isRecording = false;
          }
        } else {
          // Stop recording and transcribe
          try {
            isRecording = false;
            isProcessing = true;
            
            // Update UI to processing state
            voiceInputBtn.classList.remove('recording');
            voiceInputBtn.classList.add('processing');
            voiceInputBtn.disabled = true;
            if (voiceInputPulse) {
              voiceInputPulse.classList.add('hidden');
            }
            
            // Stop recording
            const audioBlob = await window.aiAnalysisUtils.stopRecording();
            
            // Convert to file
            const audioFile = window.aiAnalysisUtils.convertAudioToFile(audioBlob);
            
            // Get API key
            const apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
            
            // Transcribe
            const transcribedText = await window.aiAnalysisUtils.transcribeAudio(audioFile, apiKey);
            
            // Insert transcribed text into input
            const currentText = noteInput.value.trim();
            if (currentText) {
              noteInput.value = currentText + ' ' + transcribedText;
            } else {
              noteInput.value = transcribedText;
            }
            
            // Auto-resize textarea to fit all text
            autoResizeTextarea(noteInput);
            
            // Focus input
            noteInput.focus();
            // Move cursor to end
            noteInput.setSelectionRange(noteInput.value.length, noteInput.value.length);
            
          } catch (error) {
            console.error('Error transcribing audio:', error);
            alert(error.message || 'Failed to transcribe audio. Please try again.');
          } finally {
            // Reset UI
            isProcessing = false;
            voiceInputBtn.classList.remove('recording', 'processing');
            voiceInputBtn.disabled = false;
            if (voiceInputIcon) {
              voiceInputIcon.style.color = ''; // Reset to default
            }
          }
        }
      });
    }

    // Autocapture functionality
    const autocaptureBtn = document.getElementById('distatsAutocaptureBtn');
    const autocaptureModal = document.getElementById('distatsAutocaptureModal');
    const closeAutocaptureModal = document.getElementById('distatsCloseAutocaptureModal');
    const autocaptureCancelBtn = document.getElementById('distatsAutocaptureCancelBtn');
    const autocaptureStartBtn = document.getElementById('distatsAutocaptureStartBtn');
    const autocaptureStartTimeInput = document.getElementById('distatsAutocaptureStartTime');
    const autocaptureEndTimeInput = document.getElementById('distatsAutocaptureEndTime');
    const autocaptureCustomIntervalInput = document.getElementById('distatsAutocaptureCustomInterval');
    const autocapturePreview = document.getElementById('distatsAutocapturePreview');
    const autocaptureProgress = document.getElementById('distatsAutocaptureProgress');
    const autocaptureProgressText = document.getElementById('distatsAutocaptureProgressText');
    const autocaptureProgressBar = document.getElementById('distatsAutocaptureProgressBar');
    const autocaptureIntervalBtns = document.querySelectorAll('.autocapture-interval-btn');
    const autocaptureModeBtns = document.querySelectorAll('.autocapture-mode-btn');
    const autocaptureSeriesFields = document.getElementById('distatsAutocaptureSeriesFields');
    const autocaptureSingleFields = document.getElementById('distatsAutocaptureSingleFields');
    const autocaptureCurrentTimeInput = document.getElementById('distatsAutocaptureCurrentTime');
    const autocaptureSinglePreview = document.getElementById('distatsAutocaptureSinglePreview');
    
    let autocaptureCancelled = false;
    let selectedInterval = 1; // Default 1 second
    let captureMode = 'single'; // 'single' or 'series'
    let autocaptureTimeUpdateInterval = null; // Interval for updating current time
    let isManuallyEditingTime = false; // Flag to prevent auto-update while user is editing

    // Parse time string (MM:SS or HH:MM:SS) to seconds
    function parseTimeString(timeStr) {
      if (!timeStr || !timeStr.trim()) return null;
      const parts = timeStr.trim().split(':').map(p => parseInt(p, 10));
      if (parts.length === 2) {
        return parts[0] * 60 + parts[1];
      } else if (parts.length === 3) {
        return parts[0] * 3600 + parts[1] * 60 + parts[2];
      }
      return null;
    }

    // Format seconds to MM:SS or HH:MM:SS
    function formatTimeString(seconds) {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = Math.floor(seconds % 60);
      if (hours > 0) {
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      }
      return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    // Update preview of how many screenshots will be captured
    function updateAutocapturePreview() {
      const startTime = parseTimeString(autocaptureStartTimeInput.value);
      const endTime = parseTimeString(autocaptureEndTimeInput.value);
      const interval = selectedInterval;

      if (startTime !== null && endTime !== null && interval > 0 && endTime > startTime) {
        const count = Math.floor((endTime - startTime) / interval) + 1;
        if (window.i18n) {
          autocapturePreview.textContent = window.i18n.t('autocapture.previewCount', { count });
        } else {
          const captureText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('autocapture.previewCount', { count })
            : `Will capture ${count} screenshots`;
          autocapturePreview.textContent = captureText;
        }
      } else {
        if (window.i18n) {
          autocapturePreview.textContent = window.i18n.t('autocapture.previewText');
        } else {
          const previewText = (window.i18n && typeof window.i18n.t === 'function')
            ? window.i18n.t('autocapture.previewText')
            : 'Will capture 0 screenshots';
          autocapturePreview.textContent = previewText;
        }
      }
    }
    
    // Start/stop time update interval
    function startTimeUpdateInterval() {
      stopTimeUpdateInterval(); // Clear any existing interval
      
      if (captureMode !== 'single' || !autocaptureModal || autocaptureModal.classList.contains('hidden')) {
        return;
      }
      
      // Update immediately
      updateCurrentTimeDisplay();
      
      // Update every 500ms
      autocaptureTimeUpdateInterval = setInterval(() => {
        if (!isManuallyEditingTime && captureMode === 'single' && autocaptureModal && !autocaptureModal.classList.contains('hidden')) {
          updateCurrentTimeDisplay();
        }
      }, 500);
    }
    
    function stopTimeUpdateInterval() {
      if (autocaptureTimeUpdateInterval) {
        clearInterval(autocaptureTimeUpdateInterval);
        autocaptureTimeUpdateInterval = null;
      }
    }
    
    // Update current time display
    function updateCurrentTimeDisplay() {
      if (!autocaptureCurrentTimeInput || isManuallyEditingTime) return;
      
      const currentTime = getCurrentVideoTime() || 0;
      autocaptureCurrentTimeInput.value = formatTimeString(currentTime);
    }
    
    // Switch between single and series mode
    function switchAutocaptureMode(mode) {
      captureMode = mode;
      
      // Update mode buttons
      if (autocaptureModeBtns && autocaptureModeBtns.length > 0) {
        autocaptureModeBtns.forEach(btn => {
          if (btn.dataset.mode === mode) {
            btn.classList.add('active');
          } else {
            btn.classList.remove('active');
          }
        });
      }
      
      // Show/hide fields based on mode
      if (mode === 'single') {
        if (autocaptureSeriesFields) autocaptureSeriesFields.style.display = 'none';
        if (autocaptureSingleFields) autocaptureSingleFields.style.display = 'block';
        // Update current time
        updateCurrentTimeDisplay();
        // Start time update interval
        startTimeUpdateInterval();
        // Update button text
        if (autocaptureStartBtn) {
          autocaptureStartBtn.textContent = window.i18n ? window.i18n.t('autocapture.captureSingle') : 'Capture Screenshot';
        }
      } else {
        // Stop time update interval when switching to series mode
        stopTimeUpdateInterval();
        if (autocaptureSeriesFields) autocaptureSeriesFields.style.display = 'block';
        if (autocaptureSingleFields) autocaptureSingleFields.style.display = 'none';
        // Update button text
        if (autocaptureStartBtn) {
          autocaptureStartBtn.textContent = window.i18n ? window.i18n.t('autocapture.start') : 'Start Capture';
        }
        updateAutocapturePreview();
      }
    }
    
    // Capture single screenshot
    async function captureSingleScreenshot() {
      try {
        // Get time from input field (may be manually edited) or current video time
        let currentTime = getCurrentVideoTime() || 0;
        if (autocaptureCurrentTimeInput && autocaptureCurrentTimeInput.value) {
          const parsedTime = parseTimeString(autocaptureCurrentTimeInput.value);
          if (parsedTime !== null && parsedTime >= 0) {
            currentTime = parsedTime;
          }
        }
        
        // Ensure video is at the specified time
        seekVideo(currentTime);
        await waitForVideoReady(currentTime, 3000);
        
        // Capture screenshot
        const screenshot = await captureVideoScreenshot();
        
        if (screenshot) {
          // Store single screenshot for editor
          chrome.storage.local.set({
            pendingAutocaptureScreenshots: [screenshot],
            pendingEditorImageSrc: screenshot,
            pendingEditorCallbackId: 'autocapture_' + Date.now(),
            pendingEditorCallbackContext: 'sidebar'
          }, () => {
            if (chrome.runtime.lastError) {
              console.error('Autocapture: Storage error:', chrome.runtime.lastError);
              alert('Failed to store screenshot: ' + chrome.runtime.lastError.message);
              return;
            }
            
            // Open editor
            chrome.runtime.sendMessage({
              action: 'openEditorWindow',
              source: 'sidebar',
              width: 1200,
              height: 800
            }, (response) => {
              if (chrome.runtime.lastError || !response || !response.success) {
                console.error('Failed to open editor via background:', chrome.runtime.lastError);
                const fallbackWindow = window.open(chrome.runtime.getURL('editor.html'), 'tacticalEditor', 'width=1200,height=800');
                if (!fallbackWindow) {
                  alert(window.i18n ? window.i18n.t('messages.pleaseAllowPopups') : 'Please allow popups to open the editor');
                }
              }
            });
          });
        } else {
          alert(window.i18n ? window.i18n.t('autocapture.noScreenshots') : 'Failed to capture screenshot');
        }
      } catch (err) {
        console.error('Single screenshot capture error:', err);
        alert(window.i18n ? window.i18n.t('autocapture.error') : 'Error capturing screenshot: ' + err.message);
      }
    }

    // Make autocapture panel draggable
    function makeAutocapturePanelDraggable() {
      const panel = document.getElementById('distatsAutocaptureModal');
      const header = document.getElementById('distatsAutocapturePanelHeader');
      
      if (!panel || !header) return;
      
      let isDragging = false;
      let startX, startY, startLeft, startTop;
      
      // Helper function to keep panel within viewport bounds
      function constrainToViewport() {
        const panelRect = panel.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        let needsUpdate = false;
        let newLeft = panelRect.left;
        let newTop = panelRect.top;
        
        // Keep at least 100px of panel visible horizontally
        const minVisibleX = 100;
        if (panelRect.right < minVisibleX) {
          newLeft = minVisibleX - panelRect.width;
          needsUpdate = true;
        } else if (panelRect.left > viewportWidth - minVisibleX) {
          newLeft = viewportWidth - minVisibleX;
          needsUpdate = true;
        }
        
        // Keep header always visible
        const minTop = 0;
        const maxTop = viewportHeight - 60;
        if (panelRect.top < minTop) {
          newTop = minTop;
          needsUpdate = true;
        } else if (panelRect.top > maxTop) {
          newTop = maxTop;
          needsUpdate = true;
        }
        
        if (needsUpdate) {
          panel.style.transform = 'none';
          panel.style.left = newLeft + 'px';
          panel.style.top = newTop + 'px';
          panel.style.right = 'auto';
        }
      }
      
      header.addEventListener('mousedown', (e) => {
        if (e.target.closest('.autocapture-panel-btn')) return; // Don't drag when clicking buttons
        
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        
        // Remove transform and use actual position
        const rect = panel.getBoundingClientRect();
        panel.style.transform = 'none';
        panel.style.left = rect.left + 'px';
        panel.style.top = rect.top + 'px';
        panel.style.right = 'auto';
        
        startLeft = rect.left;
        startTop = rect.top;
        
        document.addEventListener('mousemove', onDrag);
        document.addEventListener('mouseup', stopDrag);
      });
      
      function onDrag(e) {
        if (!isDragging) return;
        
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        
        let newLeft = startLeft + dx;
        let newTop = startTop + dy;
        
        const panelRect = panel.getBoundingClientRect();
        const panelWidth = panelRect.width;
        
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        // Keep at least 100px of panel visible horizontally
        const minVisibleX = 100;
        newLeft = Math.max(minVisibleX - panelWidth, Math.min(newLeft, viewportWidth - minVisibleX));
        
        // Keep header always visible
        const minTop = 0;
        const maxTop = viewportHeight - 60;
        newTop = Math.max(minTop, Math.min(newTop, maxTop));
        
        panel.style.left = newLeft + 'px';
        panel.style.top = newTop + 'px';
      }
      
      function stopDrag() {
        isDragging = false;
        document.removeEventListener('mousemove', onDrag);
        document.removeEventListener('mouseup', stopDrag);
      }
      
      // Constrain panel on window resize
      window.addEventListener('resize', constrainToViewport);
      
      // Also constrain when panel becomes visible
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            if (!panel.classList.contains('hidden')) {
              setTimeout(constrainToViewport, 10);
            }
          }
        });
      });
      observer.observe(panel, { attributes: true });
    }
    
    // Initialize draggable functionality
    makeAutocapturePanelDraggable();
    
    // Open autocapture modal (make it accessible globally for message listener)
    window.openAutocaptureModal = function openAutocaptureModal() {
      const currentTime = getCurrentVideoTime() || 0;
      const duration = getVideoDuration() || 0;
      
      autocaptureStartTimeInput.value = formatTimeString(currentTime);
      autocaptureEndTimeInput.value = formatTimeString(duration);
      selectedInterval = 1;
      autocaptureCustomIntervalInput.value = '';
      
      // Reset interval buttons
      autocaptureIntervalBtns.forEach(btn => {
        btn.classList.remove('active');
      });
      autocaptureIntervalBtns[1].classList.add('active');
      
      // Reset to single mode by default
      switchAutocaptureMode('single');
      
      autocaptureProgress.style.display = 'none';
      autocaptureCancelled = false;
      
      autocaptureModal.classList.remove('hidden');
      
      // Start time update interval
      startTimeUpdateInterval();
    }

    // Close autocapture modal
    function closeAutocaptureModalFunc() {
      autocaptureModal.classList.add('hidden');
      autocaptureCancelled = true;
      // Stop time update interval
      stopTimeUpdateInterval();
      isManuallyEditingTime = false;
    }

    // Perform autocapture
    async function performAutocapture(startTime, endTime, interval) {
      const screenshots = [];
      const timestamps = [];
      
      // Generate list of timestamps
      for (let t = startTime; t <= endTime; t += interval) {
        timestamps.push(Math.min(t, endTime));
      }
      
      const total = timestamps.length;
      autocaptureProgress.style.display = 'block';
      
      for (let i = 0; i < timestamps.length; i++) {
        if (autocaptureCancelled) {
          throw new Error('Capture cancelled');
        }

        const timestamp = timestamps[i];
        
        // Update progress
        const progress = ((i + 1) / total) * 100;
        autocaptureProgressBar.style.width = progress + '%';
        if (window.i18n) {
          autocaptureProgressText.textContent = window.i18n.t('autocapture.progressText', { current: i + 1, total });
        } else {
          autocaptureProgressText.textContent = `Capturing ${i + 1}/${total}...`;
        }

        // Seek to timestamp
        const seekSuccess = seekVideo(timestamp);
        if (!seekSuccess) {
          console.warn(`Failed to seek to ${timestamp}s`);
          continue;
        }

        // Wait for video to be ready
        try {
          await waitForVideoReady(timestamp, 3000);
        } catch (err) {
          console.warn(`Video not ready at ${timestamp}s:`, err);
          continue;
        }

        // Capture screenshot (already compressed by captureVideoScreenshot)
        try {
          const screenshot = await captureVideoScreenshot();
          screenshots.push(screenshot);
          const sizeKB = Math.round(screenshot.length / 1024);
          console.log(`Captured screenshot ${i + 1}/${total}, size: ${sizeKB}KB`);
        } catch (err) {
          console.warn(`Failed to capture at ${timestamp}s:`, err);
        }

        // Small delay between captures
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      return screenshots;
    }

    // Event listeners
    if (autocaptureBtn) {
      autocaptureBtn.addEventListener('click', () => {
        openAutocaptureModal();
      });
    }

    if (closeAutocaptureModal) {
      closeAutocaptureModal.addEventListener('click', closeAutocaptureModalFunc);
    }

    if (autocaptureCancelBtn) {
      autocaptureCancelBtn.addEventListener('click', closeAutocaptureModalFunc);
    }

    // Interval preset buttons
    autocaptureIntervalBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        selectedInterval = parseFloat(btn.dataset.interval);
        autocaptureCustomIntervalInput.value = '';
        autocaptureIntervalBtns.forEach(b => {
          b.classList.remove('active');
        });
        btn.classList.add('active');
        updateAutocapturePreview();
      });
    });

    // Custom interval input
    if (autocaptureCustomIntervalInput) {
      autocaptureCustomIntervalInput.addEventListener('input', () => {
        const customInterval = parseFloat(autocaptureCustomIntervalInput.value);
        if (customInterval > 0) {
          selectedInterval = customInterval;
          autocaptureIntervalBtns.forEach(btn => {
            btn.classList.remove('active');
          });
          updateAutocapturePreview();
        }
      });
    }

    // Time input listeners
    if (autocaptureStartTimeInput) {
      autocaptureStartTimeInput.addEventListener('input', updateAutocapturePreview);
    }
    if (autocaptureEndTimeInput) {
      autocaptureEndTimeInput.addEventListener('input', updateAutocapturePreview);
    }
    
    // Current time input - manual editing
    if (autocaptureCurrentTimeInput) {
      // When user starts editing, stop auto-updates
      autocaptureCurrentTimeInput.addEventListener('focus', () => {
        isManuallyEditingTime = true;
      });
      
      // When user finishes editing (blur or Enter), seek to the entered time
      autocaptureCurrentTimeInput.addEventListener('blur', () => {
        handleManualTimeEdit();
      });
      
      autocaptureCurrentTimeInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          autocaptureCurrentTimeInput.blur(); // This will trigger the blur handler
        }
      });
    }
    
    // Handle manual time editing
    function handleManualTimeEdit() {
      if (!autocaptureCurrentTimeInput) return;
      
      const timeString = autocaptureCurrentTimeInput.value.trim();
      const timeSeconds = parseTimeString(timeString);
      
      if (timeSeconds !== null && timeSeconds >= 0) {
        // Seek to the entered time
        const seekSuccess = seekVideo(timeSeconds);
        if (seekSuccess) {
          // Update display with formatted time
          autocaptureCurrentTimeInput.value = formatTimeString(timeSeconds);
        } else {
          // If seek failed, revert to current video time
          const currentTime = getCurrentVideoTime() || 0;
          autocaptureCurrentTimeInput.value = formatTimeString(currentTime);
        }
      } else {
        // Invalid time, revert to current video time
        const currentTime = getCurrentVideoTime() || 0;
        autocaptureCurrentTimeInput.value = formatTimeString(currentTime);
      }
      
      // Re-enable auto-updates after a short delay
      setTimeout(() => {
        isManuallyEditingTime = false;
      }, 100);
    }

    // Start capture button
    // Mode button handlers
    if (autocaptureModeBtns.length > 0) {
      autocaptureModeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          switchAutocaptureMode(btn.dataset.mode);
        });
      });
    }
    
    if (autocaptureStartBtn) {
      autocaptureStartBtn.addEventListener('click', async () => {
        // Check mode
        if (captureMode === 'single') {
          // Single screenshot mode
          autocaptureStartBtn.disabled = true;
          
          try {
            await captureSingleScreenshot();
            closeAutocaptureModalFunc();
          } catch (err) {
            console.error('Single screenshot error:', err);
          } finally {
            autocaptureStartBtn.disabled = false;
          }
          return;
        }
        
        // Series mode - original logic
        const startTime = parseTimeString(autocaptureStartTimeInput.value);
        const endTime = parseTimeString(autocaptureEndTimeInput.value);
        const interval = selectedInterval;

        // Validation
        if (startTime === null || endTime === null) {
          alert(window.i18n ? window.i18n.t('autocapture.invalidTime') : 'Please enter valid start and end times');
          return;
        }
        if (endTime <= startTime) {
          alert(window.i18n ? window.i18n.t('autocapture.invalidRange') : 'End time must be greater than start time');
          return;
        }
        if (interval <= 0) {
          alert(window.i18n ? window.i18n.t('autocapture.invalidInterval') : 'Please select a valid interval');
          return;
        }

        autocaptureStartBtn.disabled = true;

        try {
          const screenshots = await performAutocapture(startTime, endTime, interval);
          
          if (screenshots.length > 0) {
            console.log('Autocapture: Storing', screenshots.length, 'screenshots');
            // Store screenshots for editor to pick up
            // Use a callback to ensure storage is complete before opening editor
            // Calculate total size to check quota
            const totalSize = screenshots.reduce((sum, s) => sum + s.length, 0);
            const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2);
            console.log('Autocapture: Total size:', totalSizeMB, 'MB');
            
            // Check if we're approaching quota (Chrome limit is ~10MB)
            if (totalSize > 8 * 1024 * 1024) {
              console.warn('Autocapture: Large data size (' + totalSizeMB + 'MB), may exceed quota');
              const proceed = confirm(`Total size is ${totalSizeMB}MB. This may exceed storage limits. Continue anyway?`);
              if (!proceed) {
                console.log('Autocapture: User cancelled due to large size');
                return;
              }
            }
            
            chrome.storage.local.set({
              pendingAutocaptureScreenshots: screenshots,
              pendingEditorImageSrc: screenshots[0], // Also set this so editor opens
              pendingEditorCallbackId: 'autocapture_' + Date.now(),
              pendingEditorCallbackContext: 'sidebar'
            }, () => {
              // Check for storage errors (especially quota exceeded)
              if (chrome.runtime.lastError) {
                console.error('Autocapture: Storage error:', chrome.runtime.lastError);
                if (chrome.runtime.lastError.message && chrome.runtime.lastError.message.includes('quota')) {
                  alert(`Storage quota exceeded. Total size: ${totalSizeMB}MB. Please reduce the number of screenshots or use a longer interval.`);
                } else {
                  alert('Failed to store screenshots: ' + chrome.runtime.lastError.message);
                }
                return;
              }
              
              // Verify storage was successful
              chrome.storage.local.get(['pendingAutocaptureScreenshots'], (verifyResult) => {
                if (chrome.runtime.lastError) {
                  console.error('Autocapture: Error verifying storage:', chrome.runtime.lastError);
                  alert('Failed to verify screenshots storage. Please try again.');
                  return;
                }
                
                if (verifyResult.pendingAutocaptureScreenshots && verifyResult.pendingAutocaptureScreenshots.length === screenshots.length) {
                  console.log('Autocapture: Screenshots verified in storage, opening editor');
                  // Small delay to ensure storage is fully committed
                  setTimeout(() => {
                    // Open editor - it will detect pendingAutocaptureScreenshots and create slides
                    chrome.runtime.sendMessage({
                      action: 'openEditorWindow',
                      source: 'sidebar',
                      width: 1200,
                      height: 800
                    }, (response) => {
                      if (chrome.runtime.lastError || !response || !response.success) {
                        console.error('Failed to open editor via background:', chrome.runtime.lastError);
                        const fallbackWindow = window.open(chrome.runtime.getURL('editor.html'), 'tacticalEditor', 'width=1200,height=800');
                        if (!fallbackWindow) {
                          alert(window.i18n ? window.i18n.t('messages.pleaseAllowPopups') : 'Please allow popups to open the editor');
                        }
                      }
                    });
                  }, 100);
                } else {
                  console.error('Autocapture: Storage verification failed! Expected', screenshots.length, 'got', verifyResult.pendingAutocaptureScreenshots ? verifyResult.pendingAutocaptureScreenshots.length : 0);
                  alert('Failed to store screenshots. Please try again with fewer screenshots or a longer interval.');
                }
              });
            });
          } else {
            alert(window.i18n ? window.i18n.t('autocapture.noScreenshots') : 'No screenshots were captured');
          }
          
          closeAutocaptureModalFunc();
        } catch (err) {
          if (err.message !== 'Capture cancelled') {
            console.error('Autocapture error:', err);
            alert(window.i18n ? window.i18n.t('autocapture.error') : 'Error during capture: ' + err.message);
          }
        } finally {
          autocaptureStartBtn.disabled = false;
        }
      });
    }

    // Close modal on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !autocaptureModal.classList.contains('hidden')) {
        closeAutocaptureModalFunc();
      }
    });

    // Handle tactical editor dropdown
    if (attachTacticalEditorBtn && tacticalEditorDropdown) {
      // Function to position dropdown intelligently (above or below based on available space)
      const positionDropdown = () => {
        const buttonRect = attachTacticalEditorBtn.getBoundingClientRect();
        const dropdownHeight = tacticalEditorDropdown.offsetHeight || 120; // Estimated height if not yet visible
        const spaceBelow = window.innerHeight - buttonRect.bottom;
        const spaceAbove = buttonRect.top;
        
        // Position dropdown
        tacticalEditorDropdown.style.left = `${buttonRect.left + window.scrollX}px`;
        
        // If there's not enough space below but enough space above, open upward
        if (spaceBelow < dropdownHeight + 8 && spaceAbove > dropdownHeight + 8) {
          // Open upward
          tacticalEditorDropdown.style.top = `${buttonRect.top + window.scrollY - dropdownHeight - 8}px`;
          tacticalEditorDropdown.style.bottom = 'auto';
        } else {
          // Open downward (default)
          tacticalEditorDropdown.style.top = `${buttonRect.bottom + window.scrollY + 8}px`;
          tacticalEditorDropdown.style.bottom = 'auto';
        }
      };

      // Toggle dropdown on button click
      attachTacticalEditorBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isHidden = tacticalEditorDropdown.classList.contains('hidden');
        if (isHidden) {
          // Show dropdown first to get its actual height
          tacticalEditorDropdown.classList.remove('hidden');
          // Use requestAnimationFrame to ensure dropdown is rendered before positioning
          requestAnimationFrame(() => {
            positionDropdown();
          });
        } else {
          tacticalEditorDropdown.classList.add('hidden');
        }
      });

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (!attachTacticalEditorBtn.contains(e.target) && !tacticalEditorDropdown.contains(e.target)) {
          tacticalEditorDropdown.classList.add('hidden');
        }
      });

      // Handle dropdown item clicks
      const dropdownItems = tacticalEditorDropdown.querySelectorAll('.tactical-editor-dropdown-item');
      dropdownItems.forEach(item => {
        item.addEventListener('click', (e) => {
          e.stopPropagation();
          
          // Check if extension context is still valid
          if (!isExtensionContextValid()) {
            alert('Extension context invalidated. Please reload the page.');
            return;
          }
          
          const type = item.dataset.type;
          let imageUrl;
          
          try {
            switch(type) {
              case 'scheme':
                imageUrl = chrome.runtime.getURL('icons/soccer-145794.svg');
                break;
              case 'goal':
                imageUrl = chrome.runtime.getURL('icons/goal.svg');
                break;
              case 'half':
                imageUrl = chrome.runtime.getURL('icons/Half.svg');
                break;
            }
          } catch (err) {
            console.error('Extension context error:', err);
            alert('Extension context invalidated. Please reload the page.');
            return;
          }
          
          if (imageUrl) {
            tacticalEditorDropdown.classList.add('hidden');
            // Open with a fresh template - no slidesData or originalImageSrc
            openEditorWindowWithImage(imageUrl, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
              pendingImages.push({ 
                imageData: modifiedImageData, 
                slidesData: slidesData,
                originalSrc: savedOriginalImageSrc || imageUrl
              });
              updateImagePreview();
            }, null, null); // Explicitly pass null for slidesData and originalImageSrc to ensure fresh start
          }
        });
      });
    }

    // Timeline floating panel - toggle show/hide
    const openTimelineBtn = document.getElementById('distatsOpenTimelineBtn');
    const timelinePanel = document.getElementById('distatsTimelinePanel');
    
    if (openTimelineBtn && timelinePanel) {
      openTimelineBtn.addEventListener('click', () => {
        const isHidden = timelinePanel.classList.contains('hidden');
        if (isHidden) {
          timelinePanel.classList.remove('hidden');
          // Ensure panel is within viewport when shown
          setTimeout(() => {
            constrainTimelinePanelToViewport();
          }, 0);
          initTimelinePanel();
        } else {
          timelinePanel.classList.add('hidden');
        }
      });
      
      // Close button
      const closeBtn = document.getElementById('distatsTimelineClose');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          timelinePanel.classList.add('hidden');
        });
      }
      
      // Minimize button
      const minimizeBtn = document.getElementById('distatsTimelineMinimize');
      if (minimizeBtn) {
        minimizeBtn.addEventListener('click', () => {
          timelinePanel.classList.toggle('minimized');
          minimizeBtn.textContent = timelinePanel.classList.contains('minimized') ? '+' : '−';
        });
      }
      
      // Make panel draggable
      makeTimelinePanelDraggable();
    }

    // Setup highlight creator listeners
    setupHighlightCreatorListeners();

    // Drag and drop functionality - on input field
    if (noteInput) {
      noteInput.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        noteInput.style.borderColor = '#8DD8F9';
      });

      noteInput.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        noteInput.style.borderColor = '#444';
      });

      noteInput.addEventListener('drop', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        noteInput.style.borderColor = '#444';
        
        const files = Array.from(e.dataTransfer.files);
        if (files.length > 0) {
          const imageFiles = files.filter(f => f.type.startsWith('image/'));
          if (imageFiles.length > 0) {
            for (const file of imageFiles) {
              await processImageFile(file);
            }
          } else {
            alert('Please drop image files.');
          }
        }
      });
    }

    // Drag and drop functionality - on preview container
    if (imagePreviewContainer) {
      imagePreviewContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        imagePreviewContainer.style.borderColor = '#8DD8F9';
        imagePreviewContainer.style.backgroundColor = '#333';
      });

      imagePreviewContainer.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        imagePreviewContainer.style.borderColor = '#444';
        imagePreviewContainer.style.backgroundColor = '#2a2a2a';
      });

      imagePreviewContainer.addEventListener('drop', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        imagePreviewContainer.style.borderColor = '#444';
        imagePreviewContainer.style.backgroundColor = '#2a2a2a';
        
        const files = Array.from(e.dataTransfer.files);
        if (files.length > 0) {
          const imageFiles = files.filter(f => f.type.startsWith('image/'));
          if (imageFiles.length > 0) {
            for (const file of imageFiles) {
              await processImageFile(file);
            }
          } else {
            alert('Please drop image files.');
          }
        }
      });
    }

    // Auto-resize textarea
    if (noteInput) {
      // Set initial height
      noteInput.style.height = '20px';
      noteInput.style.overflowY = 'hidden';
      
      noteInput.addEventListener('input', () => {
        autoResizeTextarea(noteInput);
      });
      
      // Also resize on paste
      noteInput.addEventListener('paste', () => {
        // Use setTimeout to allow paste to complete first
        setTimeout(() => {
          autoResizeTextarea(noteInput);
        }, 0);
      });

      // Add Escape key handler to cancel editing
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && editingCommentId) {
          e.preventDefault();
          cancelEdit();
        }
      });
    }

    // Add note functionality
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        const imagesToSave = pendingImages.length > 0 ? [...pendingImages] : null; // Copy array
        addNote(imagesToSave);
        // Reset textarea height to minimum
        if (noteInput) {
          noteInput.style.height = '20px';
        }
      });
    }
    if (noteInput) {
    noteInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
          const imagesToSave = pendingImages.length > 0 ? [...pendingImages] : null; // Copy array
          addNote(imagesToSave);
          // Reset textarea height to minimum
          noteInput.style.height = '20px';
      }
    });
    }

    // Copy video link functionality
    const copyLinkBtn = document.getElementById('distatsCopyLinkBtn');
    if (copyLinkBtn) {
      copyLinkBtn.addEventListener('click', copyVideoLink);
    }


    // Add video button functionality
    const addVideoBtn = document.getElementById('distatsAddVideoBtn');
    const addVideoModal = document.getElementById('distatsAddVideoModal');
    const closeAddVideoModal = document.getElementById('distatsCloseAddVideoModal');
    
    if (addVideoBtn) {
      addVideoBtn.addEventListener('click', () => {
        if (addVideoModal) {
          addVideoModal.classList.remove('hidden');
          const urlInput = document.getElementById('distatsUrlInput');
          if (urlInput) {
            setTimeout(() => {
              urlInput.focus();
              urlInput.select();
            }, 100);
          }
        }
      });
    }

    // Toggle videos section collapse/expand
    const videosToggle = document.getElementById('distatsVideosToggle');
    const videosCollapseBtn = document.getElementById('distatsVideosCollapseBtn');
    const videosSection = document.getElementById('distatsVideosSection');
    
    function toggleVideosSection() {
      if (videosSection) {
        videosSection.classList.toggle('collapsed');
      }
    }

    if (videosToggle) {
      videosToggle.addEventListener('click', (e) => {
        // Don't toggle if clicking the add button
        if (e.target.closest('.project-add-video-btn')) {
          return;
        }
        toggleVideosSection();
      });
    }

    if (videosCollapseBtn) {
      videosCollapseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleVideosSection();
      });
    }

    // Close add video modal
    if (closeAddVideoModal) {
      closeAddVideoModal.addEventListener('click', () => {
        if (addVideoModal) {
          addVideoModal.classList.add('hidden');
          const urlInput = document.getElementById('distatsUrlInput');
          if (urlInput) {
            urlInput.value = '';
          }
        }
      });
    }

    // Close modal when clicking outside
    if (addVideoModal) {
      addVideoModal.addEventListener('click', (e) => {
        if (e.target === addVideoModal) {
          addVideoModal.classList.add('hidden');
          const urlInput = document.getElementById('distatsUrlInput');
          if (urlInput) {
            urlInput.value = '';
          }
        }
      });
    }

    // URL input functionality
    const urlInput = document.getElementById('distatsUrlInput');
    if (urlInput) {
      urlInput.addEventListener('paste', handleUrlPaste);
      urlInput.addEventListener('input', handleUrlInput);
      
      // Also handle Ctrl+V / Cmd+V as fallback
      urlInput.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'v' && !isProcessingUrl) {
          // Let the paste happen first, then check
          setTimeout(() => {
            const pastedUrl = urlInput.value.trim();
            if (pastedUrl && isValidVideoUrl(pastedUrl)) {
              isProcessingUrl = true;
              try {
                createProjectFromUrl(pastedUrl);
                urlInput.value = '';
                const addVideoModal = document.getElementById('distatsAddVideoModal');
                if (addVideoModal) {
                  addVideoModal.classList.add('hidden');
                }
              } catch (error) {
                console.error('Error creating project from URL:', error);
              } finally {
                setTimeout(() => {
                  isProcessingUrl = false;
                }, 500);
              }
            }
          }, 100);
        }
      });
    }

    // Team selector functionality
    const teamSearchInput = document.getElementById('distatsTeamSearchInput');
    const teamSelectorDropdown = document.getElementById('distatsTeamSelectorDropdown');
    const addTeamBtn = document.getElementById('distatsAddTeamBtn');
    const teamList = document.getElementById('distatsTeamList');
    selectedTeamDisplay = document.getElementById('distatsSelectedTeamDisplay');
    
    // Selected team for current analysis (use global variable)

    // Show/hide dropdown on search input focus
    if (teamSearchInput) {
      teamSearchInput.addEventListener('focus', () => {
        if (teamSelectorDropdown) {
          teamSelectorDropdown.style.display = 'block';
          renderTeamSelector(teamSearchInput.value);
        }
      });

      teamSearchInput.addEventListener('input', (e) => {
        renderTeamSelector(e.target.value);
      });

      teamSearchInput.addEventListener('blur', (e) => {
        // Delay hiding to allow clicks on items
        setTimeout(() => {
          if (teamSelectorDropdown && !teamSelectorDropdown.matches(':hover') && document.activeElement !== teamSearchInput) {
            teamSelectorDropdown.style.display = 'none';
          }
        }, 200);
      });
    }

    // Keep dropdown open when hovering
    if (teamSelectorDropdown) {
      teamSelectorDropdown.addEventListener('mouseenter', () => {
        teamSelectorDropdown.style.display = 'block';
      });
      teamSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== teamSearchInput) {
          teamSelectorDropdown.style.display = 'none';
        }
      });
    }

    if (addTeamBtn) {
      addTeamBtn.addEventListener('click', () => {
        createNewTeam();
      });
    }

    // Event selector functionality
    const eventSearchInput = document.getElementById('distatsEventSearchInput');
    const eventSelectorDropdown = document.getElementById('distatsEventSelectorDropdown');
    const addCustomEventBtn = document.getElementById('distatsAddCustomEventBtn');

    // Show/hide dropdown on search input focus
    if (eventSearchInput) {
      eventSearchInput.addEventListener('focus', () => {
        if (eventSelectorDropdown) {
          eventSelectorDropdown.style.display = 'block';
          renderEventSelector(eventSearchInput.value);
        }
      });

      eventSearchInput.addEventListener('input', (e) => {
        renderEventSelector(e.target.value);
      });

      eventSearchInput.addEventListener('blur', (e) => {
        // Delay hiding to allow clicks on checkboxes
        setTimeout(() => {
          if (eventSelectorDropdown && !eventSelectorDropdown.matches(':hover') && document.activeElement !== eventSearchInput) {
            eventSelectorDropdown.style.display = 'none';
          }
        }, 200);
      });
    }

    // Keep dropdown open when hovering
    if (eventSelectorDropdown) {
      eventSelectorDropdown.addEventListener('mouseenter', () => {
        eventSelectorDropdown.style.display = 'block';
      });
      eventSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== eventSearchInput) {
          eventSelectorDropdown.style.display = 'none';
        }
      });
    }

    if (addCustomEventBtn) {
      addCustomEventBtn.addEventListener('click', () => {
        addCustomEvent();
      });
    }

    // Player selector functionality
    const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
    const playerSelectorDropdown = document.getElementById('distatsPlayerSelectorDropdown');
    const addPlayerBtn = document.getElementById('distatsAddPlayerBtn');
    const playerList = document.getElementById('distatsPlayerList');
    selectedPlayersDisplay = document.getElementById('distatsSelectedPlayersDisplay');

    // Show/hide dropdown on search input focus
    if (playerSearchInput) {
      playerSearchInput.addEventListener('focus', () => {
        if (playerSelectorDropdown) {
          playerSelectorDropdown.style.display = 'block';
          renderPlayerSelector(playerSearchInput.value);
        }
      });

      playerSearchInput.addEventListener('input', (e) => {
        renderPlayerSelector(e.target.value);
      });

      playerSearchInput.addEventListener('blur', (e) => {
        // Delay hiding to allow clicks on checkboxes
        setTimeout(() => {
          if (playerSelectorDropdown && !playerSelectorDropdown.matches(':hover') && document.activeElement !== playerSearchInput) {
            playerSelectorDropdown.style.display = 'none';
          }
        }, 200);
      });
    }

    // Keep dropdown open when hovering
    if (playerSelectorDropdown) {
      playerSelectorDropdown.addEventListener('mouseenter', () => {
        playerSelectorDropdown.style.display = 'block';
      });
      playerSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== playerSearchInput) {
          playerSelectorDropdown.style.display = 'none';
        }
      });
    }

    if (addPlayerBtn) {
      addPlayerBtn.addEventListener('click', () => {
        createNewPlayer();
      });
    }

    // Load custom events on startup
    loadCustomEvents();

    // Zones selector functionality
    const zonesSearchInput = document.getElementById('distatsZonesSearchInput');
    const zonesSelectorDropdown = document.getElementById('distatsZonesSelectorDropdown');

    // Show/hide dropdown on search input focus
    if (zonesSearchInput) {
      zonesSearchInput.addEventListener('focus', () => {
        if (zonesSelectorDropdown) {
          zonesSelectorDropdown.style.display = 'block';
          renderZonesSelector(zonesSearchInput.value);
        }
      });

      zonesSearchInput.addEventListener('input', (e) => {
        renderZonesSelector(e.target.value);
      });

      zonesSearchInput.addEventListener('blur', (e) => {
        // Delay hiding to allow clicks on checkboxes
        setTimeout(() => {
          if (zonesSelectorDropdown && !zonesSelectorDropdown.matches(':hover') && document.activeElement !== zonesSearchInput) {
            zonesSelectorDropdown.style.display = 'none';
          }
        }, 200);
      });
    }

    // Keep dropdown open when hovering
    if (zonesSelectorDropdown) {
      zonesSelectorDropdown.addEventListener('mouseenter', () => {
        zonesSelectorDropdown.style.display = 'block';
      });
      zonesSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== zonesSearchInput) {
          zonesSelectorDropdown.style.display = 'none';
        }
      });
    }

    // Setup collapsible section for analysis controls
    const analysisControlsHeader = document.getElementById('distatsAnalysisControlsHeader');
    const analysisControlsSection = document.getElementById('distatsAnalysisControlsSection');
    const commentPropertiesBtn = document.getElementById('distatsCommentPropertiesBtn');
    
    // Function to toggle comment properties section
    function toggleCommentProperties() {
      if (!analysisControlsSection) return;
      const wasCollapsed = analysisControlsSection.classList.contains('collapsed');
      analysisControlsSection.classList.toggle('collapsed');
      // Update button state
      if (commentPropertiesBtn) {
        if (wasCollapsed) {
          commentPropertiesBtn.classList.add('active');
        } else {
          commentPropertiesBtn.classList.remove('active');
        }
      }
      // If section is being expanded, render the selectors
      if (wasCollapsed) {
        renderTeamSelector('');
        renderPlayerSelector('');
        renderEventSelector('');
      }
    }
    
    if (analysisControlsHeader && analysisControlsSection) {
      // Render selectors on initialization since section is expanded by default
      renderTeamSelector('');
      renderPlayerSelector('');
      renderEventSelector('');
      
      analysisControlsHeader.addEventListener('click', toggleCommentProperties);
    }
    
    // Add click handler to toolbar button
    if (commentPropertiesBtn && analysisControlsSection) {
      commentPropertiesBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleCommentProperties();
      });
      
      // Set initial active state based on section state
      if (!analysisControlsSection.classList.contains('collapsed')) {
        commentPropertiesBtn.classList.add('active');
      }
    }

    // Initialize intensity selector
    const intensityScale = document.getElementById('distatsIntensityScale');
    const intensitySlider = document.getElementById('distatsIntensitySlider');
    const intensityTrack = intensityScale?.querySelector('.intensity-track');
    const intensityLabels = intensityScale?.querySelectorAll('.intensity-label-point');

    function updateIntensitySlider(value) {
      if (!intensitySlider || !intensityTrack) return;
      const percentage = (value / 4) * 100;
      intensitySlider.style.left = `${percentage}%`;
      
      // Update active label
      if (intensityLabels) {
        intensityLabels.forEach((label, index) => {
          if (index === value) {
            label.classList.add('active');
          } else {
            label.classList.remove('active');
          }
        });
      }
    }

    function setIntensity(value) {
      selectedIntensity = value;
      updateIntensitySlider(value);
    }

    // Initialize to Balance (middle)
    if (intensitySlider) {
      updateIntensitySlider(2);
    }

    // Handle clicks on track (but not on slider)
    if (intensityTrack) {
      intensityTrack.addEventListener('click', (e) => {
        // Don't handle click if it was on the slider itself
        if (e.target === intensitySlider || intensitySlider.contains(e.target)) {
          return;
        }
        const rect = intensityTrack.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
        const value = Math.round((percentage / 100) * 4);
        setIntensity(value);
      });
    }

    // Handle clicks on labels
    if (intensityLabels) {
      intensityLabels.forEach((label) => {
        label.addEventListener('click', () => {
          const value = parseInt(label.dataset.value);
          setIntensity(value);
        });
      });
    }

    // Handle slider drag
    if (intensitySlider && intensityTrack) {
      let isDragging = false;

      intensitySlider.addEventListener('mousedown', (e) => {
        isDragging = true;
        e.preventDefault();
      });

      document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const rect = intensityTrack.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
        const value = Math.round((percentage / 100) * 4);
        setIntensity(value);
      });

      document.addEventListener('mouseup', () => {
        isDragging = false;
      });
    }

    // Listen for video player pause events
    listenForVideoPause();

    // Listen for storage changes to sync notes when updated in popup
    try {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (!isExtensionContextValid()) {
          return;
        }
        
        try {
          // Skip updates if we're creating a project to prevent blinking/flickering
          if (isCreatingProject) {
            return;
          }
          
          if (areaName === 'local' && changes.analyses) {
            // Refresh notes display when analyses are updated
            if (currentAnalysisId) {
              updateProjectSelect();
              updateVideosDisplay();
              updateNotesDisplay();
              // Reload timeline markers and refresh video selector if timeline is open
              const timelinePanel = document.getElementById('distatsTimelinePanel');
              if (timelinePanel && !timelinePanel.classList.contains('hidden')) {
                loadTimelineMarkers();
                populateTimelineVideoSelect();
              }
            } else {
              updateProjectSelect();
            }
          }
          // Also update when currentAnalysisId changes (from popup or elsewhere)
          if (areaName === 'local' && changes.currentAnalysisId) {
            const newAnalysisId = changes.currentAnalysisId.newValue;
            if (newAnalysisId !== currentAnalysisId) {
              currentAnalysisId = newAnalysisId;
              updateProjectSelect();
              // If we have a new project ID, load it
              if (newAnalysisId) {
                loadCurrentAnalysis();
              } else {
                // Clear displays if no project
                const projectButtonText = document.getElementById('distatsProjectButtonText');
                if (projectButtonText) {
                  projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
                }
                updateVideosDisplay();
                updateVideoLinkDisplay();
                updateNotesDisplay();
              }
            }
          }
          if (areaName === 'local' && changes.players) {
            // Refresh player list when players are updated (from popup or sidebar)
            renderPlayerSelector(document.getElementById('distatsPlayerSearchInput')?.value || '');
            // Also refresh timeline player list
            const timelinePanel = document.getElementById('distatsTimelinePanel');
            if (timelinePanel && !timelinePanel.classList.contains('hidden')) {
              const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
              renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            }
          }
          
          if (areaName === 'local' && changes.teams) {
            // Refresh timeline teams when teams are updated (from popup or sidebar)
            const timelinePanel = document.getElementById('distatsTimelinePanel');
            if (timelinePanel && !timelinePanel.classList.contains('hidden')) {
              populateTimelineTeamSelect();
            }
          }
          
          // Reload timeline markers if they were updated
          if (areaName === 'local' && currentAnalysisId) {
            const timelineMarkersKey = `timelineMarkers_${currentAnalysisId}`;
            if (changes[timelineMarkersKey]) {
              // Skip if we're currently adding a marker (to prevent duplicate renders)
              if (window._isAddingMarker) {
                return;
              }
              
              // Timeline markers were updated - reload them
              const timelinePanel = document.getElementById('distatsTimelinePanel');
              if (timelinePanel && !timelinePanel.classList.contains('hidden')) {
                // Use setTimeout to debounce and prevent duplicate loads
                clearTimeout(window.timelineMarkersReloadTimeout);
                window.timelineMarkersReloadTimeout = setTimeout(() => {
                loadTimelineMarkers();
                }, 100);
              }
            }
          }
          if (areaName === 'local' && changes.currentAnalysisId) {
            // Refresh when current analysis changes
            const newAnalysisId = changes.currentAnalysisId.newValue;
            // Update button text immediately (like popup does)
            updateProjectSelect();
            // Only reload if it's different from our local ID (changed externally, e.g., from popup)
            // If it's the same, we just set it ourselves, so no need to reload
            // Also check if we're already loading to prevent recursive calls
            if (newAnalysisId !== currentAnalysisId && !isLoadingAnalysis) {
              currentAnalysisId = newAnalysisId;
              // Clear any existing debounce timer
              if (loadAnalysisDebounceTimer) {
                clearTimeout(loadAnalysisDebounceTimer);
              }
              // Debounce rapid changes
              loadAnalysisDebounceTimer = setTimeout(() => {
                // Double-check conditions after debounce
                if (!isLoadingAnalysis && newAnalysisId !== currentAnalysisId) {
                  loadCurrentAnalysis();
                }
                loadAnalysisDebounceTimer = null;
              }, 150);
            }
          }
        } catch (e) {
          console.warn('Error in storage change listener:', e);
        }
      });
    } catch (e) {
      console.warn('Could not set up storage listener:', e);
    }

    // Team modal event listeners
    const distatsTeamModal = document.getElementById('distatsTeamModal');
    const distatsCloseTeamModalBtn = document.getElementById('distatsCloseTeamModal');
    const distatsCancelTeamBtn = document.getElementById('distatsCancelTeamBtn');
    const distatsSaveTeamBtn = document.getElementById('distatsSaveTeamBtn');
    const distatsTeamNameInput = document.getElementById('distatsTeamNameInput');
    
    if (distatsCloseTeamModalBtn) {
      distatsCloseTeamModalBtn.addEventListener('click', closeTeamModal);
    }
    
    if (distatsCancelTeamBtn) {
      distatsCancelTeamBtn.addEventListener('click', closeTeamModal);
    }
    
    if (distatsSaveTeamBtn) {
      distatsSaveTeamBtn.addEventListener('click', saveTeamFromModal);
    }
    
    if (distatsTeamModal) {
      distatsTeamModal.addEventListener('click', (e) => {
        if (e.target === distatsTeamModal) {
          closeTeamModal();
        }
      });
      
      if (distatsTeamNameInput) {
        distatsTeamNameInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            saveTeamFromModal();
          }
        });
      }
    }

    // Player modal event listeners
    const distatsPlayerModal = document.getElementById('distatsPlayerModal');
    const distatsClosePlayerModalBtn = document.getElementById('distatsClosePlayerModal');
    const distatsCancelPlayerBtn = document.getElementById('distatsCancelPlayerBtn');
    const distatsSavePlayerBtn = document.getElementById('distatsSavePlayerBtn');
    
    if (distatsClosePlayerModalBtn) {
      distatsClosePlayerModalBtn.addEventListener('click', closePlayerModal);
    }
    
    if (distatsCancelPlayerBtn) {
      distatsCancelPlayerBtn.addEventListener('click', closePlayerModal);
    }
    
    if (distatsSavePlayerBtn) {
      distatsSavePlayerBtn.addEventListener('click', savePlayerFromModal);
    }
    
    if (distatsPlayerModal) {
      distatsPlayerModal.addEventListener('click', (e) => {
        if (e.target === distatsPlayerModal) {
          closePlayerModal();
        }
      });
      
      // Allow Enter key to save
      const distatsPlayerNameInput = document.getElementById('distatsPlayerNameInput');
      const distatsPlayerNumberInput = document.getElementById('distatsPlayerNumberInput');
      const distatsPlayerTeamSelect = document.getElementById('distatsPlayerTeamSelect');
      
      if (distatsPlayerNameInput) {
        distatsPlayerNameInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            distatsPlayerNumberInput.focus();
          }
        });
      }
      
      if (distatsPlayerNumberInput) {
        distatsPlayerNumberInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            distatsPlayerTeamSelect.focus();
          }
        });
      }
      
      if (distatsPlayerTeamSelect) {
        distatsPlayerTeamSelect.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            savePlayerFromModal();
          }
        });
      }
    }

    // Bulk Import Players from CSV (video-sidebar)
    const distatsToggleImportInstructions = document.getElementById('distatsToggleImportInstructions');
    const distatsImportInstructions = document.getElementById('distatsImportInstructions');
    const distatsPlayerImportFile = document.getElementById('distatsPlayerImportFile');
    const distatsSelectImportFileBtn = document.getElementById('distatsSelectImportFileBtn');
    const distatsImportFileName = document.getElementById('distatsImportFileName');
    const distatsImportPlayersBtn = document.getElementById('distatsImportPlayersBtn');
    const distatsImportResultMessage = document.getElementById('distatsImportResultMessage');

    if (distatsToggleImportInstructions && distatsImportInstructions) {
      distatsToggleImportInstructions.addEventListener('click', () => {
        const isHidden = distatsImportInstructions.style.display === 'none';
        distatsImportInstructions.style.display = isHidden ? 'block' : 'none';
        distatsToggleImportInstructions.textContent = isHidden ? '×' : '?';
      });
    }

    if (distatsSelectImportFileBtn && distatsPlayerImportFile) {
      distatsSelectImportFileBtn.addEventListener('click', () => {
        distatsPlayerImportFile.click();
      });
    }

    if (distatsPlayerImportFile) {
      distatsPlayerImportFile.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          distatsImportFileName.textContent = file.name;
          distatsImportPlayersBtn.style.display = 'inline-block';
          distatsImportResultMessage.style.display = 'none';
        } else {
          distatsImportFileName.textContent = '';
          distatsImportPlayersBtn.style.display = 'none';
        }
      });
    }

    if (distatsImportPlayersBtn) {
      distatsImportPlayersBtn.addEventListener('click', () => {
        const file = distatsPlayerImportFile.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
          const csvText = e.target.result;
          parseAndImportPlayersDistats(csvText);
        };
        reader.onerror = () => {
          showDistatsImportResult('Error reading file.', 'error');
        };
        reader.readAsText(file);
      });
    }

    function parseAndImportPlayersDistats(csvText) {
      const lines = csvText.split(/\r?\n/).filter(line => line.trim());
      if (lines.length < 2) {
        showDistatsImportResult('File must have a header row and at least one data row.', 'error');
        return;
      }

      const header = parseCSVLineDistats(lines[0]).map(h => h.toLowerCase().trim());
      const nameIdx = header.findIndex(h => h === 'name' || h === 'fullname' || h === 'full name' || h === 'player');
      const numberIdx = header.findIndex(h => h === 'number' || h === 'no' || h === 'num' || h === '#');
      const positionIdx = header.findIndex(h => h === 'position' || h === 'pos');
      const teamIdx = header.findIndex(h => h === 'team' || h === 'club');

      if (nameIdx === -1) {
        showDistatsImportResult('CSV must have a "name" column.', 'error');
        return;
      }

      const validPositions = ['GK', 'CB', 'LB', 'RB', 'LWB', 'RWB', 'CDM', 'CM', 'CAM', 'LM', 'RM', 'LW', 'RW', 'CF', 'ST'];

      chrome.storage.local.get(['players', 'teams', 'analyses'], (result) => {
        const existingPlayers = result.players || [];
        const globalTeams = result.teams || [];
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);

        // Build a map of team names (case-insensitive lookup)
        const teamNameMap = new Map();
        globalTeams.forEach(team => {
          const name = typeof team === 'string' ? team : (team.name || '');
          if (name) teamNameMap.set(name.toLowerCase(), name);
        });

        const newPlayers = [];
        const duplicatePlayers = [];
        const newTeams = [];
        const errors = [];

        for (let i = 1; i < lines.length; i++) {
          const values = parseCSVLineDistats(lines[i]);
          if (values.length === 0 || values.every(v => !v.trim())) continue;

          const name = nameIdx >= 0 && values[nameIdx] ? values[nameIdx].trim() : '';
          const number = numberIdx >= 0 && values[numberIdx] ? values[numberIdx].trim() : '';
          let position = positionIdx >= 0 && values[positionIdx] ? values[positionIdx].trim().toUpperCase() : '';
          const teamInput = teamIdx >= 0 && values[teamIdx] ? values[teamIdx].trim() : '';

          if (!name) {
            errors.push(`Row ${i + 1}: Missing name`);
            continue;
          }

          if (position && !validPositions.includes(position)) position = '';

          // Handle team - create if doesn't exist
          let teamName = '';
          if (teamInput) {
            const matchedTeam = teamNameMap.get(teamInput.toLowerCase());
            if (matchedTeam) {
              teamName = matchedTeam;
            } else {
              // Team doesn't exist - create it
              teamName = teamInput;
              teamNameMap.set(teamInput.toLowerCase(), teamName);
              
              // Check if we already queued this team for creation
              const alreadyQueued = newTeams.some(t => t.name.toLowerCase() === teamInput.toLowerCase());
              if (!alreadyQueued) {
                newTeams.push({
                  id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                  name: teamName,
                  homeColor: '#FFFFFF',
                  awayColor: '#000000',
                  homeDesign: 'solid',
                  awayDesign: 'solid',
                  homeSecondColor: '#000000',
                  awaySecondColor: '#FFFFFF',
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                });
              }
            }
          }

          const playerData = {
            fullName: name,
            number: number,
            position: position,
            team: teamName
          };

          // Check for potential duplicate (at least 2 of 3 fields match: name, number, team)
          const existingPlayer = existingPlayers.find(p => {
            const nameMatch = p.fullName.toLowerCase() === name.toLowerCase();
            const numberMatch = p.number === number && number !== '';
            const teamMatch = p.team === teamName && teamName !== '';
            
            const matches = [nameMatch, numberMatch, teamMatch].filter(Boolean).length;
            return matches >= 2;
          });

          if (existingPlayer) {
            // Determine what's different
            const changes = [];
            if (existingPlayer.fullName.toLowerCase() !== name.toLowerCase()) {
              changes.push({ field: 'name', from: existingPlayer.fullName, to: name });
            }
            if (existingPlayer.number !== number) {
              changes.push({ field: 'number', from: existingPlayer.number || '-', to: number || '-' });
            }
            if (existingPlayer.team !== teamName) {
              changes.push({ field: 'team', from: existingPlayer.team || '-', to: teamName || '-' });
            }
            if (existingPlayer.position !== position && position) {
              changes.push({ field: 'position', from: existingPlayer.position || '-', to: position });
            }
            
            duplicatePlayers.push({ existing: existingPlayer, newData: playerData, changes });
          } else {
            newPlayers.push({
              id: Date.now().toString() + '_' + Math.random().toString(36).substr(2, 9),
              ...playerData
            });
          }
        }

        // Function to complete the import
        const completeImport = (updateDuplicates) => {
          if (updateDuplicates && duplicatePlayers.length > 0) {
            duplicatePlayers.forEach(dup => {
              dup.existing.fullName = dup.newData.fullName;
              dup.existing.number = dup.newData.number;
              dup.existing.position = dup.newData.position;
              dup.existing.team = dup.newData.team;
            });
          }

          // Combine: existing (possibly updated) + new players
          const allPlayers = [...existingPlayers, ...newPlayers];
          // Combine: existing teams + new teams
          const allTeams = [...globalTeams, ...newTeams];
          
          // Attach new teams to current project
          if (newTeams.length > 0 && analysis) {
            if (!analysis.attachedTeamIds) {
              analysis.attachedTeamIds = [];
            }
            newTeams.forEach(team => {
              if (!analysis.attachedTeamIds.includes(team.id)) {
                analysis.attachedTeamIds.push(team.id);
              }
            });
          }
          
          if (newPlayers.length > 0 || (updateDuplicates && duplicatePlayers.length > 0) || newTeams.length > 0) {
            const saveData = { players: allPlayers, teams: allTeams };
            if (analysis) {
              const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
              if (analysisIndex !== -1) {
                analyses[analysisIndex] = analysis;
                saveData.analyses = analyses;
              }
            }
            
            chrome.storage.local.set(saveData, () => {
              let msg = '';
              if (newTeams.length > 0) {
                msg += `Created ${newTeams.length} new team(s). `;
              }
              if (newPlayers.length > 0) {
                msg += `Imported ${newPlayers.length} new player(s).`;
              }
              if (updateDuplicates && duplicatePlayers.length > 0) {
                msg += msg ? ' ' : '';
                msg += `Updated ${duplicatePlayers.length} existing player(s).`;
              } else if (!updateDuplicates && duplicatePlayers.length > 0) {
                msg += msg ? ' ' : '';
                msg += `Skipped ${duplicatePlayers.length} duplicate(s).`;
              }
              if (errors.length > 0) {
                msg += ` ${errors.length} error(s).`;
              }
              showDistatsImportResult(msg, 'success');
              
              // Refresh UI
              if (newTeams.length > 0) {
                renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
              }
              renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
              updateSelectedPlayersDisplay();
              
              distatsPlayerImportFile.value = '';
              distatsImportFileName.textContent = '';
              distatsImportPlayersBtn.style.display = 'none';
            });
          } else if (newPlayers.length === 0 && duplicatePlayers.length > 0 && !updateDuplicates) {
            showDistatsImportResult(`Skipped ${duplicatePlayers.length} duplicate player(s). No new players imported.`, 'error');
            distatsPlayerImportFile.value = '';
            distatsImportFileName.textContent = '';
            distatsImportPlayersBtn.style.display = 'none';
          } else {
            let msg = 'No players imported.';
            if (errors.length > 0) msg += ` Errors: ${errors.slice(0, 3).join('; ')}`;
            showDistatsImportResult(msg, 'error');
          }
        };

        // If there are duplicates, show custom modal
        if (duplicatePlayers.length > 0) {
          showDuplicatePlayersModal(duplicatePlayers, completeImport);
        } else {
          // No duplicates, just complete the import
          completeImport(false);
        }
      });
    }
    
    // Custom modal for duplicate players confirmation
    function showDuplicatePlayersModal(duplicatePlayers, callback) {
      // Remove any existing modal
      const existingModal = document.getElementById('distatsDuplicateModal');
      if (existingModal) existingModal.remove();
      
      const countText = window.i18n && window.i18n.t 
        ? window.i18n.t('modals.duplicateCount', { count: duplicatePlayers.length })
        : `Found ${duplicatePlayers.length} existing player(s) to update:`;
      
      const titleText = window.i18n && window.i18n.t 
        ? window.i18n.t('modals.duplicatesFound')
        : 'Update Players';
      
      const questionText = window.i18n && window.i18n.t 
        ? window.i18n.t('modals.duplicateUpdateQuestion')
        : 'Do you want to update these existing players with the new data?';
      
      const skipText = window.i18n && window.i18n.t 
        ? window.i18n.t('modals.skipDuplicates')
        : 'Skip';
      
      const updateText = window.i18n && window.i18n.t 
        ? window.i18n.t('modals.updatePlayers')
        : 'Update Players';
      
      // Build list HTML showing what will change
      const listItems = duplicatePlayers.slice(0, 8).map(d => {
        const changesHtml = d.changes && d.changes.length > 0 
          ? d.changes.map(c => 
              `<span style="display: inline-block; margin-right: 8px; font-size: 11px;">
                <span style="color: #6e7681;">${c.field}:</span> 
                <span style="color: #f85149; text-decoration: line-through;">${c.from}</span> 
                <span style="color: #3fb950;">→ ${c.to}</span>
              </span>`
            ).join('')
          : '';
        
        return `<div style="padding: 6px 0; border-bottom: 1px solid #21262d;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="color: #c9d1d9; font-weight: 500;">${d.existing.fullName}</span>
            <span style="color: #6e7681;">#${d.existing.number || '-'}</span>
            ${d.existing.team ? `<span style="color: #6e7681; font-size: 12px;">(${d.existing.team})</span>` : ''}
          </div>
          ${changesHtml ? `<div style="margin-top: 4px;">${changesHtml}</div>` : ''}
        </div>`;
      }).join('');
      
      const moreText = duplicatePlayers.length > 8 
        ? `<div style="padding: 6px 0; color: #6e7681; font-style: italic;">...and ${duplicatePlayers.length - 8} more</div>` 
        : '';
      
      const modal = document.createElement('div');
      modal.id = 'distatsDuplicateModal';
      modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 100000;';
      modal.innerHTML = `
        <div style="background: #161b22; border: 1px solid #30363d; border-radius: 12px; max-width: 520px; width: 90%; box-shadow: 0 8px 32px rgba(0,0,0,0.4);">
          <div style="display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid #21262d;">
            <h3 style="margin: 0; font-size: 16px; color: #c9d1d9; font-weight: 600;">${titleText}</h3>
            <button id="distatsDuplicateCloseBtn" style="background: none; border: none; color: #8b949e; cursor: pointer; font-size: 20px; padding: 0; line-height: 1;">&times;</button>
          </div>
          <div style="padding: 20px;">
            <div style="display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px;">
              <div style="flex-shrink: 0; width: 40px; height: 40px; background: rgba(63, 185, 80, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3fb950" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>
                </svg>
              </div>
              <div style="flex: 1;">
                <p style="margin: 0 0 8px 0; font-size: 14px; color: #c9d1d9; font-weight: 500;">${countText}</p>
                <div style="background: #0d1117; border: 1px solid #21262d; border-radius: 6px; padding: 10px 12px; max-height: 180px; overflow-y: auto; font-size: 13px; color: #8b949e;">
                  ${listItems}${moreText}
                </div>
              </div>
            </div>
            <p style="margin: 0 0 20px 0; font-size: 13px; color: #8b949e;">${questionText}</p>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="distatsDuplicateSkipBtn" class="modal-btn-secondary" style="padding: 6px 12px; font-size: 12px; border-radius: 6px; cursor: pointer; background: #21262d; color: #c9d1d9; border: 1px solid #30363d;">${skipText}</button>
              <button id="distatsDuplicateUpdateBtn" class="modal-btn-primary" style="padding: 6px 12px; font-size: 12px; border-radius: 6px; cursor: pointer; background: #238636; color: #fff; border: 1px solid #238636;">${updateText}</button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      const closeBtn = modal.querySelector('#distatsDuplicateCloseBtn');
      const skipBtn = modal.querySelector('#distatsDuplicateSkipBtn');
      const updateBtn = modal.querySelector('#distatsDuplicateUpdateBtn');
      
      const cleanup = () => {
        modal.remove();
      };
      
      closeBtn.addEventListener('click', () => {
        cleanup();
        callback(false);
      });
      
      skipBtn.addEventListener('click', () => {
        cleanup();
        callback(false);
      });
      
      updateBtn.addEventListener('click', () => {
        cleanup();
        callback(true);
      });
      
      // Close on backdrop click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          cleanup();
          callback(false);
        }
      });
    }

    function parseCSVLineDistats(line) {
      const result = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if ((char === ',' || char === ';') && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    }

    function showDistatsImportResult(message, type) {
      if (!distatsImportResultMessage) return;
      distatsImportResultMessage.textContent = message;
      distatsImportResultMessage.style.display = 'block';
      distatsImportResultMessage.style.color = type === 'success' ? '#3fb950' : '#f85149';
    }

    // Custom Event modal event listeners
    const distatsCustomEventModal = document.getElementById('distatsCustomEventModal');
    const distatsCloseCustomEventModalBtn = document.getElementById('distatsCloseCustomEventModal');
    const distatsCancelCustomEventBtn = document.getElementById('distatsCancelCustomEventBtn');
    const distatsSaveCustomEventBtn = document.getElementById('distatsSaveCustomEventBtn');
    const distatsCustomEventNameInput = document.getElementById('distatsCustomEventNameInput');
    
    if (distatsCloseCustomEventModalBtn) {
      distatsCloseCustomEventModalBtn.addEventListener('click', closeCustomEventModal);
    }
    
    if (distatsCancelCustomEventBtn) {
      distatsCancelCustomEventBtn.addEventListener('click', closeCustomEventModal);
    }
    
    if (distatsSaveCustomEventBtn) {
      distatsSaveCustomEventBtn.addEventListener('click', saveCustomEventFromModal);
    }
    
    if (distatsCustomEventModal) {
      distatsCustomEventModal.addEventListener('click', (e) => {
        if (e.target === distatsCustomEventModal) {
          closeCustomEventModal();
        }
      });
      
      if (distatsCustomEventNameInput) {
        distatsCustomEventNameInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            saveCustomEventFromModal();
          }
        });
      }
    }

    // Delete confirmation modal event listeners
    const distatsDeleteConfirmModal = document.getElementById('distatsDeleteConfirmModal');
    const distatsCloseDeleteConfirmModalBtn = document.getElementById('distatsCloseDeleteConfirmModal');
    const distatsCancelDeleteBtn = document.getElementById('distatsCancelDeleteBtn');
    const distatsConfirmDeleteBtn = document.getElementById('distatsConfirmDeleteBtn');
    
    if (distatsCloseDeleteConfirmModalBtn) {
      distatsCloseDeleteConfirmModalBtn.addEventListener('click', closeDeleteConfirmModal);
    }
    
    if (distatsCancelDeleteBtn) {
      distatsCancelDeleteBtn.addEventListener('click', closeDeleteConfirmModal);
    }
    
    if (distatsConfirmDeleteBtn) {
      distatsConfirmDeleteBtn.addEventListener('click', confirmDelete);
    }
    
    if (distatsDeleteConfirmModal) {
      distatsDeleteConfirmModal.addEventListener('click', (e) => {
        if (e.target === distatsDeleteConfirmModal) {
          closeDeleteConfirmModal();
        }
      });
    }

    // AI Enhancement Modal handlers
    const distatsAiEnhancementModal = document.getElementById('distatsAiEnhancementModal');
    const distatsCloseAiEnhancementModalBtn = document.getElementById('distatsCloseAiEnhancementModal');
    const distatsStartAiEnhancementBtn = document.getElementById('distatsStartAiEnhancementBtn');
    const distatsOkAiEnhancementBtn = document.getElementById('distatsOkAiEnhancementBtn');


    if (distatsCloseAiEnhancementModalBtn) {
      distatsCloseAiEnhancementModalBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeDistatsAiEnhancementModal();
      });
    }

    if (distatsAiEnhancementModal) {
      // Close modal when clicking on background
      distatsAiEnhancementModal.addEventListener('click', (e) => {
        if (e.target === distatsAiEnhancementModal) {
          closeDistatsAiEnhancementModal();
        }
      });
      
      // Prevent modal content clicks from closing the modal
      const modalContent = distatsAiEnhancementModal.querySelector('.project-modal-content');
      if (modalContent) {
        modalContent.addEventListener('click', (e) => {
          e.stopPropagation();
        });
      }
    }

    if (distatsStartAiEnhancementBtn) {
      distatsStartAiEnhancementBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        startDistatsAiEnhancement();
      });
    }

    if (distatsOkAiEnhancementBtn) {
      // Remove any existing listeners first
      const newOkBtn = distatsOkAiEnhancementBtn.cloneNode(true);
      distatsOkAiEnhancementBtn.parentNode.replaceChild(newOkBtn, distatsOkAiEnhancementBtn);
      newOkBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('OK button clicked');
        closeDistatsAiEnhancementModal();
      });
    } else {
      console.warn('distatsOkAiEnhancementBtn not found');
    }
  }

  // Copy video link to clipboard
  function copyVideoLink() {
    if (currentVideoUrl) {
      navigator.clipboard.writeText(currentVideoUrl).then(() => {
        const btn = document.getElementById('distatsCopyLinkBtn');
        if (btn) {
          const originalText = btn.textContent;
          btn.textContent = '✓';
          btn.style.background = '#03509A';
          setTimeout(() => {
            btn.textContent = originalText;
            btn.style.background = '';
          }, 2000);
        }
      }).catch(err => {
        console.error('Failed to copy link:', err);
        alert('Failed to copy link. Please copy manually: ' + currentVideoUrl);
      });
    }
  }

  // Handle URL paste event
  function handleUrlPaste(event) {
    if (isProcessingUrl) {
      return;
    }
    
    // Use requestAnimationFrame to ensure paste content is in the input
    requestAnimationFrame(() => {
      setTimeout(() => {
        const urlInput = event.target;
        const pastedUrl = urlInput.value.trim();

        if (pastedUrl && isValidVideoUrl(pastedUrl)) {
          isProcessingUrl = true;
          try {
            createProjectFromUrl(pastedUrl);
            urlInput.value = ''; // Clear the input after processing
            const addVideoModal = document.getElementById('distatsAddVideoModal');
            if (addVideoModal) {
              addVideoModal.classList.add('hidden');
            }
          } catch (error) {
            console.error('Error creating project from URL:', error);
          } finally {
            // Reset flag after a short delay to allow async operations to complete
            setTimeout(() => {
              isProcessingUrl = false;
            }, 500);
          }
        }
      }, 50); // Slightly longer delay to ensure paste is complete
    });
  }

  // Handle URL input changes (for typing or programmatic changes)
  let inputTimeout = null;
  function handleUrlInput(event) {
    const urlInput = event.target;
    const url = urlInput.value.trim();

    // Clear any existing timeout
    if (inputTimeout) {
      clearTimeout(inputTimeout);
    }

    // Auto-process URL after user stops typing/pasting for 1 second
    if (url && isValidVideoUrl(url) && !isProcessingUrl) {
      inputTimeout = setTimeout(() => {
        const currentUrl = urlInput.value.trim();
        if (currentUrl === url && isValidVideoUrl(currentUrl) && !isProcessingUrl) {
          isProcessingUrl = true;
          try {
            createProjectFromUrl(currentUrl);
            urlInput.value = '';
            const addVideoModal = document.getElementById('distatsAddVideoModal');
            if (addVideoModal) {
              addVideoModal.classList.add('hidden');
            }
          } catch (error) {
            console.error('Error creating project from URL:', error);
          } finally {
            setTimeout(() => {
              isProcessingUrl = false;
            }, 500);
          }
        }
      }, 1000); // 1 second delay after user stops typing
    }
  }

  // Check if URL is a valid video URL
  function isValidVideoUrl(url) {
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.toLowerCase();

      return hostname.includes('youtube.com') ||
             hostname.includes('youtu.be') ||
             hostname.includes('dailymotion.com') ||
             hostname.includes('twitch.tv');
    } catch (e) {
      return false;
    }
  }

  // Add video to current project or create new project
  function createProjectFromUrl(url) {
    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      // Extract video info from URL
      const videoInfo = extractVideoInfoFromUrl(url);
      if (!videoInfo) {
        alert('Invalid video URL. Please check the URL and try again.');
        return;
      }

      // If we have a current project, add video to it; otherwise create new project
      if (currentAnalysisId) {
        addVideoToCurrentProject(url, videoInfo);
      } else {
        // Temporarily set current video info to the pasted URL
        const originalVideoId = currentVideoId;
        const originalVideoUrl = currentVideoUrl;

        currentVideoId = videoInfo.id;
        currentVideoUrl = url;

        // Try to get video title from current page if we're on the same video
        let projectName = videoInfo.title;
        try {
          // Check if we're on the same video page
          const currentPageVideoId = getCurrentVideoId();
          if (currentPageVideoId === videoInfo.id) {
            // We're on the same video, try to get the actual title from the page
            const actualTitle = getVideoTitle();
            if (actualTitle && actualTitle !== `${platform} Video`) {
              projectName = actualTitle;
            }
          }
          // If we're on a different page, we'll use a descriptive default below
        } catch (e) {
        }

        // If we still have a generic title, use a descriptive default with video ID
        if (projectName === videoInfo.title && videoInfo.id) {
          const platformName = videoInfo.platform.charAt(0).toUpperCase() + videoInfo.platform.slice(1);
          projectName = `${platformName} Video - ${videoInfo.id}`;
        }

        // Create new project for this URL automatically
        createNewProjectForUrl(projectName, videoInfo.platform);

        // Restore original video info
        currentVideoId = originalVideoId;
        currentVideoUrl = originalVideoUrl;
      }

    } catch (error) {
      console.error('Error creating project from URL:', error);
      alert('Error creating project from URL. Please try again.');
    }
  }

  // Add video to current project
  function addVideoToCurrentProject(url, videoInfo) {
    if (!currentAnalysisId) {
      console.warn('No current project to add video to');
      return;
    }

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'addVideoToCurrentProject')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex === -1) {
          console.warn('Current project not found');
          return;
        }

        const analysis = analyses[analysisIndex];
        
        // Initialize videos array if it doesn't exist
        if (!analysis.videos) {
          analysis.videos = [];
          // Migrate existing video data to videos array
          if (analysis.videoId || analysis.videoUrl) {
            analysis.videos.push({
              videoId: analysis.videoId,
              videoUrl: analysis.videoUrl,
              videoTitle: analysis.videoTitle || 'Video',
              platform: analysis.platform || 'video',
              addedAt: analysis.createdAt || Date.now()
            });
          }
        }

        // Check if this video already exists in the project
        const videoExists = analysis.videos.some(v => 
          v.videoUrl === url || 
          (v.videoId === videoInfo.id && v.platform === videoInfo.platform)
        );

        if (videoExists) {
          alert('This video is already in the current project.');
          return;
        }

        // Try to get video title from current page if we're on the same video
        let videoTitle = videoInfo.title;
        try {
          const currentPageVideoId = getCurrentVideoId();
          if (currentPageVideoId === videoInfo.id) {
            const actualTitle = getVideoTitle();
            if (actualTitle && actualTitle !== `${platform} Video`) {
              videoTitle = actualTitle;
            }
          }
        } catch (e) {
        }

        // Add the new video to the project
        analysis.videos.push({
          videoId: videoInfo.id,
          videoUrl: url,
          videoTitle: videoTitle,
          platform: videoInfo.platform,
          addedAt: Date.now()
        });

        // Update legacy fields to point to the first video (for backward compatibility)
        if (analysis.videos.length === 1) {
          analysis.videoId = videoInfo.id;
          analysis.videoUrl = url;
          analysis.platform = videoInfo.platform;
          analysis.videoTitle = videoTitle;
        }

        chrome.storage.local.set({ analyses: analyses }, () => {
          if (handleStorageError(null, 'addVideoToCurrentProject-set')) {
            return;
          }

          
          // Update displays
          updateProjectSelect();
          updateVideosDisplay();
          updateVideoLinkDisplay();
          
          // Close modal and show success message
          const addVideoModal = document.getElementById('distatsAddVideoModal');
          const urlInput = document.getElementById('distatsUrlInput');
          if (urlInput) {
            urlInput.value = '';
            urlInput.placeholder = 'Video added successfully!';
            setTimeout(() => {
              urlInput.placeholder = 'Paste video URL here to add to project...';
              if (addVideoModal) {
                addVideoModal.classList.add('hidden');
              }
            }, 2000);
          } else if (addVideoModal) {
            addVideoModal.classList.add('hidden');
          }
        });
      });
    } catch (e) {
      handleStorageError(e, 'addVideoToCurrentProject');
    }
  }

  // Extract video information from URL
  function extractVideoInfoFromUrl(url) {
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.toLowerCase();
      let videoId = null;
      let platform = null;

      if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
        platform = 'youtube';
        if (hostname.includes('youtu.be')) {
          videoId = urlObj.pathname.slice(1);
        } else {
          const urlParams = new URLSearchParams(urlObj.search);
          videoId = urlParams.get('v');
        }
      } else if (hostname.includes('dailymotion.com')) {
        platform = 'dailymotion';
        const match = url.match(/dailymotion\.com\/video\/([^/?]+)/);
        videoId = match ? match[1] : null;
      } else if (hostname.includes('twitch.tv')) {
        platform = 'twitch';
        // Match both /videos/ (plural) and /video/ (singular) patterns
        // Also handle URLs with channel name: twitch.tv/channelname/video/123456
        const match = url.match(/twitch\.tv\/(?:[^\/]+\/)?(?:videos|video)\/(\d+)/);
        videoId = match ? match[1] : null;
      }

      if (videoId && platform) {
        return {
          id: videoId,
          platform: platform,
          url: url,
          title: `${platform.charAt(0).toUpperCase() + platform.slice(1)} Video`
        };
      }

      return null;
    } catch (e) {
      return null;
    }
  }

  // Create new project specifically for URL (modified version of createNewProject)
  function createNewProjectForUrl(projectTitle, videoPlatform) {
    // Use the provided title directly, no prompt
    const analysisName = projectTitle && projectTitle.trim() !== '' 
      ? projectTitle.trim() 
      : 'New Video Project';

    const analysisId = 'analysis_' + Date.now();
    const date = new Date();

    // Use the provided platform or default to 'video'
    const projectPlatform = videoPlatform || 'video';

    const newAnalysis = {
      id: analysisId,
      name: analysisName,
      date: date.toLocaleDateString(),
      videoId: currentVideoId,
      videoUrl: currentVideoUrl,
      videoTitle: analysisName, // Use the project name as video title
      platform: projectPlatform,
      videos: [{
        videoId: currentVideoId,
        videoUrl: currentVideoUrl,
        videoTitle: analysisName,
        platform: projectPlatform,
        addedAt: Date.now()
      }],
      notes: [],
      teams: [], // Initialize teams array
      createdAt: Date.now()
    };

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      // Set flag to prevent storage listener from firing
      isCreatingProject = true;
      
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'createNewProjectForUrl')) {
          isCreatingProject = false;
          return;
        }

        const analyses = result.analyses || [];
        analyses.push(newAnalysis);

        chrome.storage.local.set({
          analyses: analyses,
          currentAnalysisId: analysisId
        }, () => {
          if (handleStorageError(null, 'createNewProjectForUrl-set')) {
            isCreatingProject = false;
            return;
          }

          currentAnalysisId = analysisId;
          // Directly update displays without calling loadCurrentAnalysis to avoid switching to old project
          updateProjectSelect();
          updateVideosDisplay();
          updateVideoLinkDisplay();
          updateProjectNameDisplay();
          updateNotesDisplay();
          renderTeamSelector('');
          updateSelectedTeamDisplay();
          
          // Clear flag after a short delay to allow updates to complete
          setTimeout(() => {
            isCreatingProject = false;
          }, 300);
          
          // Fetch and save real video title after a delay
          setTimeout(() => {
            updateVideoTitleInAnalysis();
          }, 2000);

          // Show success message
          const urlInput = document.getElementById('distatsUrlInput');
          if (urlInput) {
            urlInput.placeholder = 'Project created successfully!';
            setTimeout(() => {
              urlInput.placeholder = 'Paste video URL here to create new project...';
            }, 3000);
          }
        });
      });
    } catch (e) {
      isCreatingProject = false;
      handleStorageError(e, 'createNewProjectForUrl');
    }
  }

  // Toggle sidebar visibility
  function toggle() {
    sidebarVisible = !sidebarVisible;

    if (sidebarVisible) {
      show();
    } else {
      hide();
    }
  }

  // Show sidebar
  function show() {
    const sidebar = document.getElementById('distats');
    const toggleBtn = document.getElementById('distatsToggleBtn');

    sidebar.classList.remove('hidden');
    toggleBtn.classList.add('hidden');
    sidebarVisible = true;
  }

  // Hide sidebar
  function hide() {
    const sidebar = document.getElementById('distats');
    const toggleBtn = document.getElementById('distatsToggleBtn');

    sidebar.classList.add('hidden');
    toggleBtn.classList.remove('hidden');
    sidebarVisible = false;

  }


  // Listen for video player pause events (platform-agnostic)
  // Note: Auto-insertion of timestamps removed - users can manually add timestamps
  function listenForVideoPause() {
    // Removed automatic timestamp insertion on pause
    // Users can manually type timestamps or add notes with timestamps
  }

  // Get current video time (platform-agnostic)
  function getCurrentVideoTime() {
    try {
      // Universal method: look for video element
      let video = document.querySelector('video');
      if (video && !isNaN(video.currentTime) && video.currentTime > 0) {
        return video.currentTime;
      }

      // Platform-specific methods
      if (platform === 'youtube') {
        if (window.yt && window.yt.player && window.yt.player.getCurrentTime) {
          const time = window.yt.player.getCurrentTime();
          if (time && time > 0) {
            return time;
        }
        }
      } else if (platform === 'dailymotion') {
        // Dailymotion uses a video element, but might be nested or not ready
        // Try multiple selectors in order of specificity
        const selectors = [
          'video.dmp_VideoPlayer video',
          'div[data-testid="player-container"] video',
          'div.dmp_PlayerContainer video',
          'div.dmp_Player video',
          'video[class*="dmp"]',
          'video'
        ];
        
        // First, try all video elements and check each one
        const allVideos = document.querySelectorAll('video');
        for (const vid of allVideos) {
          if (vid && !isNaN(vid.currentTime) && vid.currentTime >= 0) {
            // Check if this video is actually playing or has loaded data
            if (vid.readyState >= 1 || vid.currentTime > 0 || vid.duration > 0) {
              return vid.currentTime;
            }
          }
        }
        
        // Try specific selectors
        for (const selector of selectors) {
          video = document.querySelector(selector);
          if (video) {
            const time = video.currentTime;
            if (!isNaN(time) && time >= 0) {
              return time;
            }
          }
        }
        
        // Try to get from Dailymotion player API if available
        if (window.dmp && window.dmp.player) {
          try {
            const time = window.dmp.player.currentTime;
            if (time !== undefined && !isNaN(time) && time >= 0) {
              return time;
            }
          } catch (e) {
            // Silently fail - API might not be available
          }
        }
        
        // Try window.player if available (another possible Dailymotion API)
        if (window.player && typeof window.player.getCurrentTime === 'function') {
          try {
            const time = window.player.getCurrentTime();
            if (time !== undefined && !isNaN(time) && time >= 0) {
              return time;
            }
          } catch (e) {
            // Silently fail
          }
        }
        
        // Don't try iframe - it will always fail due to CORS and just creates noise in console
        // Iframe approach removed to avoid CORS errors
        
        console.warn('Could not get Dailymotion video time. Available video elements:', allVideos.length);
      } else if (platform === 'twitch') {
        // Twitch video element should work
        video = document.querySelector('video');
        if (video && !isNaN(video.currentTime) && video.currentTime > 0) {
          return video.currentTime;
        }
      }

      return null;
    } catch (e) {
      console.warn('Could not get video current time:', e);
      return null;
    }
  }

  // Format time as MM:SS or HH:MM:SS
  function formatTimecode(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    } else {
      return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
  }

  // Add a note
  function addNote(imageData = null) {
    const noteInput = document.getElementById('distatsNoteInput');
    if (!noteInput) {
      console.error('noteInput element not found!');
      return;
    }
    const content = noteInput.value.trim();
    const hasImages = imageData && (Array.isArray(imageData) ? imageData.length > 0 : true);

    if (!content && !hasImages) {
      return;
    }

    if (!currentAnalysisId) {
      // Show message that project needs to be created first
      showErrorModal('Please create a project first by clicking the "+ Project" button.');
      return;
    }

    // Add new note to analysis
    addNoteToAnalysis(content, imageData).then(() => {
      // After save completes, clear pending images and preview
      hideImagePreview();
    });
    noteInput.value = '';
    noteInput.focus();
    
    // Clear selected events, zones, and intensity after sending
    selectedEvents = [];
    selectedZones = [];
    selectedPlayers = [];
    selectedTeams = [];
    selectedIntensity = null;
    updateSelectedEventsDisplay();
    updateSelectedZonesDisplay();
    updateSelectedPlayersDisplay();
    // Reset intensity slider to Balance (middle)
    const intensitySlider = document.getElementById('distatsIntensitySlider');
    if (intensitySlider) {
      intensitySlider.style.left = '50%';
      const intensityLabels = document.querySelectorAll('.intensity-label-point');
      intensityLabels.forEach((label, index) => {
        if (index === 2) {
          label.classList.add('active');
        } else {
          label.classList.remove('active');
        }
      });
    }
    const zonesSearchInput = document.getElementById('distatsZonesSearchInput');
    const zonesSelectorDropdown = document.getElementById('distatsZonesSelectorDropdown');
    if (zonesSearchInput) zonesSearchInput.value = '';
    if (zonesSelectorDropdown) zonesSelectorDropdown.style.display = 'none';
    const eventSearchInput = document.getElementById('distatsEventSearchInput');
    const eventSelectorDropdown = document.getElementById('distatsEventSelectorDropdown');
    if (eventSearchInput) eventSearchInput.value = '';
    if (eventSelectorDropdown) eventSelectorDropdown.style.display = 'none';
  }

  // Check for existing project for current video
  function checkForExistingProject() {
    // Ensure we have the current video URL and ID
    if (!currentVideoUrl) {
      currentVideoUrl = window.location.href;
    }
    if (!currentVideoId) {
      getCurrentVideoId();
    }

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'checkForExistingProject')) {
          return;
        }

        const analyses = result.analyses || [];
        
        // Check if there's already a project for this video
        const normalizedCurrentUrl = normalizeUrlForComparison(currentVideoUrl);
        const existingProject = analyses.find(a => {
          // Check legacy videoUrl field
          if (a.videoUrl && normalizeUrlForComparison(a.videoUrl) === normalizedCurrentUrl) {
            return true;
          }
          // Check videoId and platform match
          if (a.videoId === currentVideoId && a.platform === platform) {
            return true;
          }
          // Check videos array for matching video
          if (a.videos && Array.isArray(a.videos) && a.videos.length > 0) {
            return a.videos.some(v => {
              if (!v.videoUrl) return false;
              const normalizedVideoUrl = normalizeUrlForComparison(v.videoUrl);
              return normalizedVideoUrl === normalizedCurrentUrl || 
                     (v.videoId === currentVideoId && v.platform === platform);
            });
          }
          return false;
        });

        if (existingProject) {
          const useExisting = confirm(
            `A project "${existingProject.name}" already exists for this video.\n\n` +
            `Click OK to use it, or Cancel to create a new project.`
          );
          
          if (useExisting) {
            // Switch to existing project
            currentAnalysisId = existingProject.id;
            // Show export buttons when project is selected
            const exportProjectDropdownItem = document.getElementById('distatsExportProjectDropdownItem');
            if (exportProjectDropdownItem) {
              exportProjectDropdownItem.style.display = existingProject.id ? 'flex' : 'none';
            }
            const exportNotesDropdownItem = document.getElementById('distatsExportNotesDropdownItem');
            if (exportNotesDropdownItem) {
              exportNotesDropdownItem.style.display = existingProject.id ? 'flex' : 'none';
            }
            try {
              chrome.storage.local.set({ currentAnalysisId: existingProject.id }, () => {
                if (handleStorageError(null, 'setCurrentAnalysisId')) {
                  return;
                }
                loadCurrentAnalysis();
                updateNotesDisplay();
              });
            } catch (e) {
              handleStorageError(e, 'setCurrentAnalysisId');
            }
            return;
          }
        }

        // Create new project
        createNewProject();
      });
    } catch (e) {
      handleStorageError(e, 'checkForExistingProject');
    }
  }

  // Create new project for current video
  function createNewProject() {
    // Ensure we have the current video URL and ID
    if (!currentVideoUrl) {
      currentVideoUrl = window.location.href;
    }
    if (!currentVideoId) {
      getCurrentVideoId();
    }

    const videoTitle = getVideoTitle();
    const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
    
    // Use video title as default project name
    const defaultName = videoTitle && videoTitle !== `${platform} Video`
      ? videoTitle
      : `${platformName} Video - ${new Date().toLocaleDateString()}`;

    const analysisName = prompt('Enter project name:', defaultName);

    if (!analysisName || analysisName.trim() === '') {
      return;
    }

    const analysisId = 'analysis_' + Date.now();
    const date = new Date();

    const newAnalysis = {
      id: analysisId,
      name: analysisName.trim(),
      date: date.toLocaleDateString(),
      videoId: currentVideoId,
      videoUrl: currentVideoUrl || window.location.href,
      videoTitle: videoTitle || `${platformName} Video`,
      platform: platform,
      videos: [{
        videoId: currentVideoId,
        videoUrl: currentVideoUrl || window.location.href,
        videoTitle: videoTitle || `${platformName} Video`,
        platform: platform,
        addedAt: Date.now()
      }],
      notes: [],
      createdAt: Date.now()
    };

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      // Set flag to prevent storage listener from firing
      isCreatingProject = true;
      
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'createNewProject')) {
          isCreatingProject = false;
          return;
        }

        const analyses = result.analyses || [];
        analyses.push(newAnalysis);

        chrome.storage.local.set({
          analyses: analyses,
          currentAnalysisId: analysisId
        }, () => {
          if (handleStorageError(null, 'createNewProject-set')) {
            isCreatingProject = false;
            return;
          }
          currentAnalysisId = analysisId;
          // Directly update displays without calling loadCurrentAnalysis to avoid switching to old project
          updateProjectSelect();
          updateVideosDisplay();
          updateVideoLinkDisplay();
          updateProjectNameDisplay();
          updateNotesDisplay();
          
          // Clear flag after a short delay to allow updates to complete
          setTimeout(() => {
            isCreatingProject = false;
          }, 300);
          
          // Fetch and save real video title after a delay
          setTimeout(() => {
            updateVideoTitleInAnalysis();
          }, 2000);
        });
      });
    } catch (e) {
      isCreatingProject = false;
      handleStorageError(e, 'createNewProject');
    }
  }

  // Rename current project
  function renameCurrentProject() {
    if (!currentAnalysisId) {
      console.warn('No project to rename');
      return;
    }

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'renameCurrentProject')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        
        if (analysis) {
          const newName = prompt('Enter new name:', analysis.name);
          
          if (newName && newName.trim() !== '' && newName.trim() !== analysis.name) {
            analysis.name = newName.trim();
            chrome.storage.local.set({ analyses: analyses }, () => {
              if (handleStorageError(null, 'renameCurrentProject-set')) {
                return;
              }
              updateProjectSelect(analyses, currentAnalysisId);
            });
          }
        }
      });
    } catch (e) {
      handleStorageError(e, 'renameCurrentProject');
    }
  }

  // Delete current project
  function deleteCurrentProject() {
    if (!currentAnalysisId) {
      console.warn('No project to delete');
      return;
    }

    // Confirm deletion
    const confirmDelete = confirm('Are you sure you want to delete this project? This action cannot be undone.');
    if (!confirmDelete) {
      return;
    }

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
        if (handleStorageError(null, 'deleteCurrentProject')) {
          return;
        }

        const analyses = result.analyses || [];
        const projectToDelete = analyses.find(a => a.id === currentAnalysisId);
        
        if (!projectToDelete) {
          console.warn('Project not found:', currentAnalysisId);
          return;
        }

        // Remove the project from analyses
        const updatedAnalyses = analyses.filter(a => a.id !== currentAnalysisId);
        
        // Determine what to set as currentAnalysisId
        let newCurrentAnalysisId = null;
        
        // If there are other projects, try to find one for the same video
        if (updatedAnalyses.length > 0) {
          const projectForThisVideo = updatedAnalyses.find(a => 
            a.videoUrl === currentVideoUrl || 
            (a.videoId === currentVideoId && a.platform === platform)
          );
          
          if (projectForThisVideo) {
            newCurrentAnalysisId = projectForThisVideo.id;
          } else {
            // Use the most recent project
            const sortedAnalyses = [...updatedAnalyses].sort((a, b) => 
              (b.createdAt || 0) - (a.createdAt || 0)
            );
            newCurrentAnalysisId = sortedAnalyses[0].id;
          }
        }

        // Update storage
        chrome.storage.local.set({
          analyses: updatedAnalyses,
          currentAnalysisId: newCurrentAnalysisId
        }, () => {
          if (handleStorageError(null, 'deleteCurrentProject-set')) {
            return;
          }

          // Refresh displays
          if (newCurrentAnalysisId) {
            // Directly update without calling loadCurrentAnalysis to avoid recursion
            currentAnalysisId = newCurrentAnalysisId;
            chrome.storage.local.get(['analyses'], (result) => {
              const analyses = result.analyses || [];
              const analysis = analyses.find(a => a.id === newCurrentAnalysisId);
              if (analysis) {
                if (analysis.videoUrl) {
                  currentVideoUrl = analysis.videoUrl;
                }
                if (analysis.videoId) {
                  currentVideoId = analysis.videoId;
                }
                updateProjectSelect();
                updateVideosDisplay();
                updateVideoLinkDisplay();
                updateNotesDisplay();
              }
            });
          } else {
            // No projects left
            currentAnalysisId = null;
            updateProjectSelect();
            updateVideosDisplay();
            updateVideoLinkDisplay();
            updateProjectNameDisplay();
            updateNotesDisplay();
          }

        });
      });
    } catch (e) {
      handleStorageError(e, 'deleteCurrentProject');
    }
  }

  // Helper functions to translate event categories and events (same as in editor.js)
  function translateEventCategory(categoryName) {
    if (!window.i18n || !window.i18n.t) return categoryName;
    
    const categoryMap = {
      'Possession phases': 'events.categories.possessionPhases',
      'Ball progression events': 'events.categories.ballProgressionEvents',
      'Chance creation events': 'events.categories.chanceCreationEvents',
      'Defensive structure events': 'events.categories.defensiveStructureEvents',
      'Transition events': 'events.categories.transitionEvents',
      'Set-piece tactical events': 'events.categories.setPieceTacticalEvents',
      'Structural / off-ball tactical events': 'events.categories.structuralOffBallTacticalEvents',
      'Error / critical moment events': 'events.categories.errorCriticalMomentEvents',
      'Protocol recordings': 'events.categories.protocolRecordings',
      'Custom': 'modals.addCustomEvent'
    };
    
    const key = categoryMap[categoryName];
    if (key) {
      const translated = window.i18n.t(key);
      return translated !== key ? translated : categoryName;
    }
    return categoryName;
  }

  function translateEventName(eventName) {
    if (!window.i18n || !window.i18n.t) return eventName;
    
    const eventMap = {
      'Build-up': 'events.possessionPhases.buildUp',
      'Consolidation / Middle third possession': 'events.possessionPhases.consolidationMiddleThirdPossession',
      'Final third attack': 'events.possessionPhases.finalThirdAttack',
      'Counterattack': 'events.possessionPhases.counterattack',
      'Transition defense': 'events.possessionPhases.transitionDefense',
      'Set-piece attack': 'events.possessionPhases.setPieceAttack',
      'Set-piece defense': 'events.possessionPhases.setPieceDefense',
      'Progressive pass': 'events.ballProgressionEvents.progressivePass',
      'Line-breaking pass': 'events.ballProgressionEvents.lineBreakingPass',
      'Third-man combination': 'events.ballProgressionEvents.thirdManCombination',
      'Switch of play': 'events.ballProgressionEvents.switchOfPlay',
      'Carry that bypasses a line': 'events.ballProgressionEvents.carryThatBypassesALine',
      'Successful dribble forward': 'events.ballProgressionEvents.successfulDribbleForward',
      'Inside-channel progression': 'events.ballProgressionEvents.insideChannelProgression',
      'Half-space entry': 'events.ballProgressionEvents.halfSpaceEntry',
      'Final third entry': 'events.ballProgressionEvents.finalThirdEntry',
      'Penalty box entry': 'events.ballProgressionEvents.penaltyBoxEntry',
      'Shot': 'events.chanceCreationEvents.shot',
      'Shot on target': 'events.chanceCreationEvents.shotOnTarget',
      'Assist / key pass': 'events.chanceCreationEvents.assistKeyPass',
      'Cutback': 'events.chanceCreationEvents.cutback',
      'Through ball': 'events.chanceCreationEvents.throughBall',
      'Cross (successful)': 'events.chanceCreationEvents.crossSuccessful',
      'Cross (unsuccessful)': 'events.chanceCreationEvents.crossUnsuccessful',
      'Deep completion (dangerous pass inside 20m, no shot)': 'events.chanceCreationEvents.deepCompletion',
      '1v1 attacking win': 'events.chanceCreationEvents.oneVOneAttackingWin',
      '1v1 attacking loss': 'events.chanceCreationEvents.oneVOneAttackingLoss',
      'Pressing action': 'events.defensiveStructureEvents.pressingAction',
      'Pressing trap triggered': 'events.defensiveStructureEvents.pressingTrapTriggered',
      'Ball recovery (high)': 'events.defensiveStructureEvents.ballRecoveryHigh',
      'Ball recovery (mid)': 'events.defensiveStructureEvents.ballRecoveryMid',
      'Ball recovery (low)': 'events.defensiveStructureEvents.ballRecoveryLow',
      'Counterpress success': 'events.defensiveStructureEvents.counterpressSuccess',
      'Counterpress failure': 'events.defensiveStructureEvents.counterpressFailure',
      'Defensive line broken': 'events.defensiveStructureEvents.defensiveLineBroken',
      'Block shot': 'events.defensiveStructureEvents.blockShot',
      'Interception': 'events.defensiveStructureEvents.interception',
      'Tackle/Duel won': 'events.defensiveStructureEvents.tackleDuelWon',
      'Tackle/Duel lost': 'events.defensiveStructureEvents.tackleDuelLost',
      '1v1 defensive win': 'events.defensiveStructureEvents.oneVOneDefensiveWin',
      '1v1 defensive loss': 'events.defensiveStructureEvents.oneVOneDefensiveLoss',
      'Positive transition (winning the ball)': 'events.transitionEvents.positiveTransitionWinningTheBall',
      'Negative transition (losing the ball)': 'events.transitionEvents.negativeTransitionLosingTheBall',
      'Counterattack start': 'events.transitionEvents.counterattackStart',
      'Dangerous turnover': 'events.transitionEvents.dangerousTurnover',
      'Turnover leading to chance': 'events.transitionEvents.turnoverLeadingToChance',
      'Recovery leading to chance': 'events.transitionEvents.recoveryLeadingToChance',
      'Corner attack': 'events.setPieceTacticalEvents.cornerAttack',
      'Corner defense': 'events.setPieceTacticalEvents.cornerDefense',
      'Free kick (crossing)': 'events.setPieceTacticalEvents.freeKickCrossing',
      'Free kick (shooting)': 'events.setPieceTacticalEvents.freeKickShooting',
      'Throw-in routine (only if structured, e.g., long throw)': 'events.setPieceTacticalEvents.throwInRoutine',
      'Second ball win': 'events.setPieceTacticalEvents.secondBallWin',
      'Second ball loss': 'events.setPieceTacticalEvents.secondBallLoss',
      'Set-piece chance created': 'events.setPieceTacticalEvents.setPieceChanceCreated',
      'Overload created (right)': 'events.structuralOffBallTacticalEvents.overloadCreatedRight',
      'Overload created (left)': 'events.structuralOffBallTacticalEvents.overloadCreatedLeft',
      'Overload created (central)': 'events.structuralOffBallTacticalEvents.overloadCreatedCentral',
      'Overload lost': 'events.structuralOffBallTacticalEvents.overloadLost',
      'Bad spacing / poor distances': 'events.structuralOffBallTacticalEvents.badSpacingPoorDistances',
      'Line height shift (too high)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooHigh',
      'Line height shift (too low)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooLow',
      'Offside trap activated (successful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedSuccessful',
      'Offside trap activated (unsuccessful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedUnsuccessful',
      'Numerical superiority achieved': 'events.structuralOffBallTacticalEvents.numericalSuperiorityAchieved',
      'Numerical superiority lost': 'events.structuralOffBallTacticalEvents.numericalSuperiorityLost',
      'Error leading to shot': 'events.errorCriticalMomentEvents.errorLeadingToShot',
      'Error leading to goal': 'events.errorCriticalMomentEvents.errorLeadingToGoal',
      'Poor clearance': 'events.errorCriticalMomentEvents.poorClearance',
      'Bad decision under pressure': 'events.errorCriticalMomentEvents.badDecisionUnderPressure',
      'Miscommunication': 'events.errorCriticalMomentEvents.miscommunication',
      'Failed press': 'events.errorCriticalMomentEvents.failedPress',
      'Goal': 'events.protocolRecordings.goal',
      'Assist': 'events.protocolRecordings.assist',
      'Substitution': 'events.protocolRecordings.substitution',
      'Penalty': 'events.protocolRecordings.penalty',
      'Red card': 'events.protocolRecordings.redCard',
      'Yellow card': 'events.protocolRecordings.yellowCard'
    };
    
    const key = eventMap[eventName];
    if (key) {
      const translated = window.i18n.t(key);
      return translated !== key ? translated : eventName;
    }
    return eventName;
  }

  // Event data structure
  const EVENT_CATEGORIES = [
    {
      name: 'Possession phases',
      events: [
        'Build-up',
        'Consolidation / Middle third possession',
        'Final third attack',
        'Counterattack',
        'Transition defense',
        'Set-piece attack',
        'Set-piece defense'
      ]
    },
    {
      name: 'Ball progression events',
      events: [
        'Progressive pass',
        'Line-breaking pass',
        'Third-man combination',
        'Switch of play',
        'Carry that bypasses a line',
        'Successful dribble forward',
        'Inside-channel progression',
        'Half-space entry',
        'Final third entry',
        'Penalty box entry'
      ]
    },
    {
      name: 'Chance creation events',
      events: [
        'Shot',
        'Shot on target',
        'Assist / key pass',
        'Cutback',
        'Through ball',
        'Cross (successful)',
        'Cross (unsuccessful)',
        'Deep completion (dangerous pass inside 20m, no shot)',
        '1v1 attacking win',
        '1v1 attacking loss'
      ]
    },
    {
      name: 'Defensive structure events',
      events: [
        'Pressing action',
        'Pressing trap triggered',
        'Ball recovery (high)',
        'Ball recovery (mid)',
        'Ball recovery (low)',
        'Counterpress success',
        'Counterpress failure',
        'Defensive line broken',
        'Block shot',
        'Interception',
        'Tackle/Duel won',
        'Tackle/Duel lost',
        '1v1 defensive win',
        '1v1 defensive loss'
      ]
    },
    {
      name: 'Transition events',
      events: [
        'Positive transition (winning the ball)',
        'Negative transition (losing the ball)',
        'Counterattack start',
        'Dangerous turnover',
        'Turnover leading to chance',
        'Recovery leading to chance'
      ]
    },
    {
      name: 'Set-piece tactical events',
      events: [
        'Corner attack',
        'Corner defense',
        'Free kick (crossing)',
        'Free kick (shooting)',
        'Throw-in routine (only if structured, e.g., long throw)',
        'Second ball win',
        'Second ball loss',
        'Set-piece chance created'
      ]
    },
    {
      name: 'Structural / off-ball tactical events',
      events: [
        'Overload created (right)',
        'Overload created (left)',
        'Overload created (central)',
        'Overload lost',
        'Bad spacing / poor distances',
        'Line height shift (too high)',
        'Line height shift (too low)',
        'Offside trap activated (successful)',
        'Offside trap activated (unsuccessful)',
        'Numerical superiority achieved',
        'Numerical superiority lost'
      ]
    },
    {
      name: 'Error / critical moment events',
      events: [
        'Error leading to shot',
        'Error leading to goal',
        'Poor clearance',
        'Bad decision under pressure',
        'Miscommunication',
        'Failed press'
      ]
    },
    {
      name: 'Protocol recordings',
      events: [
        'Goal',
        'Assist',
        'Substitution',
        'Penalty',
        'Red card',
        'Yellow card'
      ]
    }
  ];

  // Global custom events storage (shared across all analyses)
  // Format: [{name: 'Event Name', category: 'Category Name'}, ...]
  let customEvents = [];

  // Load custom events from storage
  function loadCustomEvents() {
    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['customEvents'], (result) => {
        if (handleStorageError(null, 'loadCustomEvents')) {
          return;
        }
        const loadedEvents = result.customEvents || [];
        // Migrate old format (array of strings) to new format (array of objects)
        customEvents = loadedEvents.map(event => {
          if (typeof event === 'string') {
            // Old format: just a string, assign to 'Custom' category
            return { name: event, category: 'Custom' };
          }
          // New format: already an object
          return event;
        });
        saveCustomEvents(); // Save migrated format
        renderEventSelector();
        loadCategoriesForCustomEventModal();
      });
    } catch (e) {
      handleStorageError(e, 'loadCustomEvents');
      customEvents = [];
    }
  }

  // Save custom events to storage
  function saveCustomEvents() {
    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.set({ customEvents: customEvents }, () => {
        if (handleStorageError(null, 'saveCustomEvents')) {
          return;
        }
      });
    } catch (e) {
      handleStorageError(e, 'saveCustomEvents');
    }
  }

  // Get all events (standard + custom)
  function getAllEvents() {
    const allEvents = [];
    EVENT_CATEGORIES.forEach(category => {
      category.events.forEach(event => {
        allEvents.push(event);
      });
    });
    customEvents.forEach(eventObj => {
      const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
      allEvents.push(eventName);
    });
    return allEvents;
  }

  // Load categories for custom event modal
  function loadCategoriesForCustomEventModal() {
    const categorySelect = document.getElementById('distatsCustomEventCategorySelect');
    if (!categorySelect) return;
    
    const selectCategoryText = window.i18n && window.i18n.t ? window.i18n.t('modals.selectCategory') : 'Select category...';
    categorySelect.innerHTML = `<option value="">${selectCategoryText}</option>`;
    
    EVENT_CATEGORIES.forEach(category => {
      const option = document.createElement('option');
      option.value = category.name;
      option.textContent = translateEventCategory(category.name);
      categorySelect.appendChild(option);
    });
    
    // Add "Custom" as an option
    const customOption = document.createElement('option');
    customOption.value = 'Custom';
    const customText = window.i18n && window.i18n.t ? window.i18n.t('modals.addCustomEvent') : 'Custom';
    customOption.textContent = customText;
    categorySelect.appendChild(customOption);
  }

  // Render event selector
  function renderEventSelector(searchTerm = '') {
    const dropdown = document.getElementById('distatsEventSelectorDropdown');
    const categoriesDiv = document.getElementById('distatsEventCategories');
    if (!dropdown || !categoriesDiv) {
      console.warn('Event selector elements not found');
      return;
    }

    categoriesDiv.innerHTML = '';

    const searchLower = searchTerm.toLowerCase().trim();
    let totalEventsRendered = 0;

    // Group custom events by category first
    const customEventsByCategory = {};
    customEvents.forEach(eventObj => {
      const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
      const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
      
      if (!customEventsByCategory[category]) {
        customEventsByCategory[category] = [];
      }
      customEventsByCategory[category].push(eventName);
    });

    // Get all standard category names
    const standardCategoryNames = EVENT_CATEGORIES.map(cat => cat.name);

    EVENT_CATEGORIES.forEach(category => {
      // Filter standard events based on search term
      const filteredStandardEvents = searchTerm 
        ? category.events.filter(event => event.toLowerCase().includes(searchLower))
        : category.events; // Show all events when no search term

      // Get custom events for this category
      const customEventsInCategory = customEventsByCategory[category.name] || [];
      const filteredCustomEvents = searchTerm
        ? customEventsInCategory.filter(event => event.toLowerCase().includes(searchLower))
        : customEventsInCategory;

      // Combine standard and custom events
      const allEventsInCategory = [...filteredStandardEvents, ...filteredCustomEvents];

      // Skip category only if search term exists and no matches found
      if (searchTerm && allEventsInCategory.length === 0) return;

      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'event-category';

      const categoryName = document.createElement('div');
      categoryName.className = 'event-category-name';
      categoryName.textContent = translateEventCategory(category.name);
      categoryDiv.appendChild(categoryName);

      // Render standard events
      filteredStandardEvents.forEach(event => {
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        // Create a safe ID by replacing special characters
        const safeId = `event-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
        checkbox.id = safeId;
        checkbox.value = event;
        checkbox.checked = selectedEvents.includes(event);
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedEvents.includes(event)) {
              selectedEvents.push(event);
            }
          } else {
            selectedEvents = selectedEvents.filter(e => e !== event);
          }
          updateSelectedEventsDisplay();
        });

        const label = document.createElement('label');
        label.htmlFor = safeId;
        label.textContent = translateEventName(event);

        eventItem.appendChild(checkbox);
        eventItem.appendChild(label);
        categoryDiv.appendChild(eventItem);
        totalEventsRendered++;
      });

      // Render custom events in this category (with edit/delete buttons)
      filteredCustomEvents.forEach(event => {
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';
        eventItem.style.display = 'flex';
        eventItem.style.alignItems = 'center';
        eventItem.style.padding = '4px 8px';
        eventItem.style.borderRadius = '4px';
        
        eventItem.addEventListener('mouseenter', () => {
          eventItem.style.background = '#21262d';
        });
        eventItem.addEventListener('mouseleave', () => {
          eventItem.style.background = 'transparent';
        });

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        // Create a safe ID by replacing special characters
        const safeId = `distats-event-custom-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
        checkbox.id = safeId;
        checkbox.value = event;
        checkbox.checked = selectedEvents.includes(event);
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedEvents.includes(event)) {
              selectedEvents.push(event);
            }
          } else {
            selectedEvents = selectedEvents.filter(e => e !== event);
          }
          updateSelectedEventsDisplay();
        });

        const label = document.createElement('label');
        label.htmlFor = safeId;
        label.textContent = translateEventName(event);
        label.style.flex = '1';
        label.style.cursor = 'pointer';
        label.style.fontSize = '13px';
        label.style.color = '#c9d1d9';

        const editBtn = document.createElement('button');
        editBtn.textContent = '✎';
        editBtn.style.background = 'transparent';
        editBtn.style.border = 'none';
        editBtn.style.color = '#8b949e';
        editBtn.style.cursor = 'pointer';
        editBtn.style.padding = '2px 6px';
        editBtn.style.marginLeft = '4px';
        editBtn.style.fontSize = '12px';
        const editEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.editEvent')
          : 'Edit event';
        editBtn.title = editEventText;
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          renameCustomEvent(event);
        });
        
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.style.background = 'transparent';
        deleteBtn.style.border = 'none';
        deleteBtn.style.color = '#8b949e';
        deleteBtn.style.cursor = 'pointer';
        deleteBtn.style.padding = '2px 6px';
        deleteBtn.style.marginLeft = '2px';
        deleteBtn.style.fontSize = '16px';
        const deleteEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.deleteEvent')
          : 'Delete event';
        deleteBtn.title = deleteEventText;
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          deleteCustomEvent(event);
        });

        eventItem.appendChild(checkbox);
        eventItem.appendChild(label);
        eventItem.appendChild(editBtn);
        eventItem.appendChild(deleteBtn);
        categoryDiv.appendChild(eventItem);
      });

      if (allEventsInCategory.length > 0) {
        categoriesDiv.appendChild(categoryDiv);
        totalEventsRendered += filteredCustomEvents.length;
      }
    });
    
    // Render custom events that are in categories that don't exist in standard categories
    Object.keys(customEventsByCategory).forEach(categoryName => {
      // Skip if this category is already rendered (it's a standard category)
      if (standardCategoryNames.includes(categoryName)) {
        return;
      }

      const categoryEvents = customEventsByCategory[categoryName];
      const filteredCustom = searchTerm
        ? categoryEvents.filter(event => event.toLowerCase().includes(searchLower))
        : categoryEvents;

      if (filteredCustom.length > 0) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'event-category';

        const categoryNameDiv = document.createElement('div');
        categoryNameDiv.className = 'event-category-name';
        categoryNameDiv.textContent = categoryName;
        categoryDiv.appendChild(categoryNameDiv);

        filteredCustom.forEach(event => {
          const eventItem = document.createElement('div');
          eventItem.className = 'event-item';
          eventItem.style.display = 'flex';
          eventItem.style.alignItems = 'center';
          eventItem.style.padding = '4px 8px';
          eventItem.style.borderRadius = '4px';
          
          eventItem.addEventListener('mouseenter', () => {
            eventItem.style.background = '#21262d';
          });
          eventItem.addEventListener('mouseleave', () => {
            eventItem.style.background = 'transparent';
          });

          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          // Create a safe ID by replacing special characters
          const safeId = `distats-event-custom-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
          checkbox.id = safeId;
          checkbox.value = event;
          checkbox.checked = selectedEvents.includes(event);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedEvents.includes(event)) {
                selectedEvents.push(event);
              }
            } else {
              selectedEvents = selectedEvents.filter(e => e !== event);
            }
            updateSelectedEventsDisplay();
          });

          const label = document.createElement('label');
          label.htmlFor = safeId;
          label.textContent = event;
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';

          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          const editEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.editEvent')
          : 'Edit event';
        editBtn.title = editEventText;
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            renameCustomEvent(event);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          const deleteEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.deleteEvent')
          : 'Delete event';
        deleteBtn.title = deleteEventText;
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteCustomEvent(event);
          });

          eventItem.appendChild(checkbox);
          eventItem.appendChild(label);
          eventItem.appendChild(editBtn);
          eventItem.appendChild(deleteBtn);
          categoryDiv.appendChild(eventItem);
        });

        categoriesDiv.appendChild(categoryDiv);
        totalEventsRendered += filteredCustom.length;
      }
    });
  }

  // Update selected events display
  // Zones categories
  const ZONES_CATEGORIES = [
    {
      name: 'Defensive third',
      zones: [1, 2, 3, 4, 5, 6]
    },
    {
      name: 'Middle third',
      zones: [7, 8, 9, 10, 11, 12]
    },
    {
      name: 'Attacking third',
      zones: [13, 14, 15, 16, 17, 18]
    }
  ];

  // Render zones selector
  function renderZonesSelector(searchTerm = '') {
    const dropdown = document.getElementById('distatsZonesSelectorDropdown');
    const categoriesDiv = document.getElementById('distatsZonesCategories');
    if (!dropdown || !categoriesDiv) {
      console.warn('Zones selector elements not found');
      return;
    }

    categoriesDiv.innerHTML = '';

    const searchLower = searchTerm.toLowerCase().trim();

    ZONES_CATEGORIES.forEach(category => {
      // Filter zones based on search term
      const filteredZones = searchTerm
        ? category.zones.filter(zone => zone.toString().includes(searchLower) || category.name.toLowerCase().includes(searchLower))
        : category.zones; // Show all zones when no search term

      // Skip category only if search term exists and no matches found
      if (searchTerm && filteredZones.length === 0) return;

      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'zones-category';

      const categoryName = document.createElement('div');
      categoryName.className = 'zones-category-name';
      categoryName.textContent = category.name;
      categoryDiv.appendChild(categoryName);

      filteredZones.forEach(zoneNumber => {
        const zoneItem = document.createElement('div');
        zoneItem.className = 'zones-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `distats-zone-${zoneNumber}`;
        checkbox.value = zoneNumber;
        checkbox.checked = selectedZones.includes(zoneNumber);
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedZones.includes(zoneNumber)) {
              selectedZones.push(zoneNumber);
            }
          } else {
            selectedZones = selectedZones.filter(z => z !== zoneNumber);
          }
          updateSelectedZonesDisplay();
        });

        const label = document.createElement('label');
        label.htmlFor = `distats-zone-${zoneNumber}`;
        label.textContent = `Zone ${zoneNumber}`;

        zoneItem.appendChild(checkbox);
        zoneItem.appendChild(label);
        categoryDiv.appendChild(zoneItem);
      });

      categoriesDiv.appendChild(categoryDiv);
    });
  }

  function updateSelectedEventsDisplay() {
    const display = document.getElementById('distatsSelectedEventsDisplay');
    if (!display) return;

    display.innerHTML = '';

    selectedEvents.forEach(event => {
      const tag = document.createElement('div');
      tag.className = 'event-tag';
      tag.innerHTML = `
        <span>${event}</span>
        <span class="event-tag-remove" data-event="${event}">×</span>
      `;
      
      const removeBtn = tag.querySelector('.event-tag-remove');
      removeBtn.addEventListener('click', () => {
        selectedEvents = selectedEvents.filter(e => e !== event);
        updateSelectedEventsDisplay();
        renderEventSelector(document.getElementById('distatsEventSearchInput')?.value || '');
      });

      display.appendChild(tag);
    });
  }

  function updateSelectedZonesDisplay() {
    const display = document.getElementById('distatsSelectedZonesDisplay');
    if (!display) return;

    display.innerHTML = '';

    // Sort zones numerically
    const sortedZones = [...selectedZones].sort((a, b) => a - b);

    sortedZones.forEach(zone => {
      const tag = document.createElement('div');
      tag.className = 'zone-tag';
      tag.innerHTML = `
        <span>Zone ${zone}</span>
        <span class="zone-tag-remove" data-zone="${zone}">×</span>
      `;
      
      const removeBtn = tag.querySelector('.zone-tag-remove');
      removeBtn.addEventListener('click', () => {
        selectedZones = selectedZones.filter(z => z !== zone);
        updateSelectedZonesDisplay();
        const zonesSearchInput = document.getElementById('distatsZonesSearchInput');
        if (zonesSearchInput) {
          renderZonesSelector(zonesSearchInput.value);
        }
      });

      display.appendChild(tag);
    });
  }

  // Custom Event modal management
  let currentEditingEventName = null;

  function openCustomEventModal(eventName = null) {
    const customEventModal = document.getElementById('distatsCustomEventModal');
    const customEventModalTitle = customEventModal ? customEventModal.querySelector('h3') : null;
    const customEventNameInput = document.getElementById('distatsCustomEventNameInput');
    const customEventCategorySelect = document.getElementById('distatsCustomEventCategorySelect');
    
    if (!customEventModal || !customEventNameInput || !customEventCategorySelect) {
      console.error('Custom event modal elements not found');
      return;
    }

    currentEditingEventName = eventName;
    
    if (eventName) {
      // Editing existing event
      if (customEventModalTitle) {
        const editEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.editCustomEvent')
          : 'Edit Custom Event';
        customEventModalTitle.textContent = editEventText;
      }
      customEventNameInput.value = eventName;
      
      // Find the event and set its category
      const eventObj = customEvents.find(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name === eventName;
      });
      if (eventObj) {
        const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
        customEventCategorySelect.value = category;
      } else {
        customEventCategorySelect.value = 'Custom';
      }
    } else {
      // Creating new event
      if (customEventModalTitle) {
        const addEventText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('modals.addCustomEvent')
          : 'Add Custom Event';
        customEventModalTitle.textContent = addEventText;
      }
      customEventNameInput.value = '';
      customEventCategorySelect.value = '';
    }
    
    loadCategoriesForCustomEventModal();
    customEventModal.classList.remove('hidden');
    customEventNameInput.focus();
  }

  function closeCustomEventModal() {
    const customEventModal = document.getElementById('distatsCustomEventModal');
    if (customEventModal) {
      customEventModal.classList.add('hidden');
      currentEditingEventName = null;
    }
  }

  function saveCustomEventFromModal() {
    const customEventNameInput = document.getElementById('distatsCustomEventNameInput');
    const customEventCategorySelect = document.getElementById('distatsCustomEventCategorySelect');
    
    if (!customEventNameInput || !customEventCategorySelect) {
      return;
    }
    
    const eventName = customEventNameInput.value.trim();
    const category = customEventCategorySelect.value.trim();
    
    if (!eventName) {
      showErrorModal('Please enter an event name.');
      return;
    }
    
    if (!category) {
      showErrorModal('Please select a category.');
      return;
    }
    
    if (currentEditingEventName) {
      // Editing existing event
      const eventIndex = customEvents.findIndex(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name === currentEditingEventName;
      });
      
      if (eventIndex !== -1) {
        // Check if new name already exists (and it's not the same event)
        const allEvents = getAllEvents();
        if (eventName !== currentEditingEventName && allEvents.includes(eventName)) {
          showErrorModal('This event name already exists.');
          return;
        }
        
        // Update the event
        customEvents[eventIndex] = { name: eventName, category: category };
        saveCustomEvents();
        
        // Update selectedEvents if the renamed event was selected
        if (selectedEvents.includes(currentEditingEventName)) {
          selectedEvents = selectedEvents.map(e => e === currentEditingEventName ? eventName : e);
          updateSelectedEventsDisplay();
        }
        
        closeCustomEventModal();
        renderEventSelector(document.getElementById('distatsEventSearchInput')?.value || '');
      }
    } else {
      // Creating new event
    // Check if event already exists
    const allEvents = getAllEvents();
      if (allEvents.includes(eventName)) {
        showErrorModal('This event already exists.');
      return;
    }

      customEvents.push({ name: eventName, category: category });
    saveCustomEvents();
      closeCustomEventModal();
    renderEventSelector(document.getElementById('distatsEventSearchInput')?.value || '');
    
    // Auto-select the newly added custom event
      if (!selectedEvents.includes(eventName)) {
        selectedEvents.push(eventName);
      updateSelectedEventsDisplay();
      renderEventSelector(document.getElementById('distatsEventSearchInput')?.value || '');
    }
    }
  }

  function renameCustomEvent(oldEventName, newEventName = null) {
    // If newEventName is provided, it's being called from saveCustomEventFromModal
    // Otherwise, it's being called from the edit button, so open the modal
    if (!newEventName) {
      openCustomEventModal(oldEventName);
      return;
    }
    
    // This function is now handled by saveCustomEventFromModal
    // Keeping for backward compatibility but shouldn't be called directly
  }

  function deleteCustomEvent(eventName) {
    showDeleteConfirmModal(`Are you sure you want to delete the custom event "${eventName}"? This will remove the event from all notes.`, () => {
      // Remove from custom events array
      customEvents = customEvents.filter(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name !== eventName;
      });
      saveCustomEvents();
      
      // Remove from selectedEvents if it was selected
      if (selectedEvents.includes(eventName)) {
        selectedEvents = selectedEvents.filter(e => e !== eventName);
        updateSelectedEventsDisplay();
      }
      
      // Update all notes in all analyses that reference this event
      if (!isExtensionContextValid()) {
        return;
      }
      
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'deleteCustomEvent')) {
          return;
        }
        
        const analyses = result.analyses || [];
        let updated = false;
        
        analyses.forEach(analysis => {
          if (analysis.notes) {
            analysis.notes.forEach(note => {
              if (note.events && Array.isArray(note.events)) {
                const eventIndex = note.events.indexOf(eventName);
                if (eventIndex !== -1) {
                  note.events.splice(eventIndex, 1);
                  // If events array is now empty, set it to null
                  if (note.events.length === 0) {
                    note.events = null;
                  }
                  updated = true;
                }
              }
            });
          }
        });
        
        if (updated) {
          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'deleteCustomEvent-set')) {
              return;
            }
          });
        }
      });
      
      renderEventSelector(document.getElementById('distatsEventSearchInput')?.value || '');
    });
  }

  function addCustomEvent() {
    openCustomEventModal();
  }


  // Team selector functions
  function renderTeamSelector(searchQuery = '') {
    const teamList = document.getElementById('distatsTeamList');
    if (!teamList) return;
    
    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      if (handleStorageError(null, 'renderTeamSelector')) {
        return;
      }
      
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      // Use global teams storage, fallback to analysis.teams for backward compatibility
      const globalTeams = result.teams || [];
      const analysisTeams = analysis ? (analysis.teams || []) : [];
      // Merge global teams with analysis teams (global takes precedence)
      const teamsMap = new Map();
      // First add analysis teams (for backward compatibility)
      analysisTeams.forEach(team => {
        const teamName = getTeamName(team);
        if (teamName) teamsMap.set(teamName.toLowerCase(), team);
      });
      // Then add global teams (overwrites duplicates)
      globalTeams.forEach(team => {
        const teamName = typeof team === 'string' ? team : (team.name || '');
        if (teamName) teamsMap.set(teamName.toLowerCase(), team);
      });
      const teams = Array.from(teamsMap.values());
      const currentSelectedTeam = analysis ? (analysis.selectedTeam || null) : null;
      
      // Filter teams by search query
      const filteredTeams = teams.filter(team => {
        const teamName = getTeamName(team);
        const searchLower = searchQuery.toLowerCase();
        return teamName.toLowerCase().includes(searchLower);
      });
      
      teamList.innerHTML = '';
      
      // Add "No team" option
      const noTeamItem = document.createElement('div');
      noTeamItem.style.display = 'flex';
      noTeamItem.style.alignItems = 'center';
      noTeamItem.style.padding = '4px 8px';
      noTeamItem.style.cursor = 'pointer';
      noTeamItem.style.borderRadius = '4px';
      
      noTeamItem.addEventListener('mouseenter', () => {
        noTeamItem.style.background = '#21262d';
      });
      noTeamItem.addEventListener('mouseleave', () => {
        noTeamItem.style.background = 'transparent';
      });
      
      const noTeamLabel = document.createElement('label');
      noTeamLabel.style.flex = '1';
      noTeamLabel.style.cursor = 'pointer';
      noTeamLabel.style.fontSize = '13px';
      noTeamLabel.style.color = '#c9d1d9';
      noTeamLabel.textContent = 'No team';
      
      if (!currentSelectedTeam || currentSelectedTeam === '') {
        noTeamLabel.style.color = '#1f6feb';
        noTeamLabel.style.fontWeight = '500';
      }
      
      noTeamLabel.addEventListener('click', () => {
        selectedTeam = null;
        selectedTeams = [];
        saveSelectedTeam(null);
        updateSelectedTeamDisplay();
        const teamSearchInput = document.getElementById('distatsTeamSearchInput');
        renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
      });
      
      noTeamItem.appendChild(noTeamLabel);
      teamList.appendChild(noTeamItem);
      
      if (filteredTeams.length === 0 && searchQuery) {
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.style.textAlign = 'center';
        emptyMsg.textContent = 'No teams found';
        teamList.appendChild(emptyMsg);
        return;
      }
      
      filteredTeams.forEach(team => {
        const teamName = getTeamName(team);
        const userTeam = analysis ? (analysis.userTeam || null) : null;
        const isUserTeam = userTeam === teamName;
        
        const teamItem = document.createElement('div');
        teamItem.style.display = 'flex';
        teamItem.style.alignItems = 'center';
        teamItem.style.padding = '4px 8px';
        teamItem.style.cursor = 'pointer';
        teamItem.style.borderRadius = '4px';
        
        teamItem.addEventListener('mouseenter', () => {
          teamItem.style.background = '#21262d';
        });
        teamItem.addEventListener('mouseleave', () => {
          teamItem.style.background = 'transparent';
        });
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.value = teamName;
        checkbox.dataset.teamName = teamName;
        // Check if team is selected (compare by name)
        const isSelected = selectedTeams.some(t => getTeamName(t) === teamName) || 
                          (currentSelectedTeam && getTeamName(currentSelectedTeam) === teamName);
        checkbox.checked = isSelected;
        checkbox.style.marginRight = '8px';
        checkbox.style.cursor = 'pointer';
        
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            // Add team object (not just name) to selectedTeams
            if (!selectedTeams.some(t => getTeamName(t) === teamName)) {
              selectedTeams.push(team);
            }
          } else {
            selectedTeams = selectedTeams.filter(t => getTeamName(t) !== teamName);
          }
          updateSelectedTeamDisplay();
        });
        
        const label = document.createElement('label');
        label.style.flex = '1';
        label.style.cursor = 'pointer';
        label.style.fontSize = '13px';
        label.style.color = '#c9d1d9';
        label.style.display = 'flex';
        label.style.alignItems = 'center';
        label.style.gap = '6px';
        
        // Add star icon if this is the user's team
        if (isUserTeam) {
          const starIcon = document.createElement('span');
          starIcon.textContent = '★';
          starIcon.style.color = '#fbbf24';
          starIcon.style.fontSize = '14px';
          label.appendChild(starIcon);
        }
        
        const teamNameSpan = document.createElement('span');
        teamNameSpan.textContent = teamName;
        label.appendChild(teamNameSpan);
        
        if (isSelected) {
          teamNameSpan.style.color = '#1f6feb';
          teamNameSpan.style.fontWeight = '500';
        }
        
        label.addEventListener('click', () => {
          checkbox.checked = !checkbox.checked;
          checkbox.dispatchEvent(new Event('change'));
        });
        
        const myTeamBtn = document.createElement('button');
        myTeamBtn.textContent = isUserTeam ? '★' : '☆';
        myTeamBtn.style.background = 'transparent';
        myTeamBtn.style.border = 'none';
        myTeamBtn.style.color = isUserTeam ? '#fbbf24' : '#8b949e';
        myTeamBtn.style.cursor = 'pointer';
        myTeamBtn.style.padding = '2px 6px';
        myTeamBtn.style.marginLeft = '4px';
        myTeamBtn.style.fontSize = '14px';
        const removeMyTeamText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.removeAsMyTeam')
          : 'Remove as My Team';
        const setMyTeamText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.setAsMyTeam')
          : 'Set as My Team';
        myTeamBtn.title = isUserTeam ? removeMyTeamText : setMyTeamText;
        myTeamBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (isUserTeam) {
            saveUserTeam(null);
          } else {
            saveUserTeam(teamName);
          }
        });
        
        const editBtn = document.createElement('button');
        editBtn.textContent = '✎';
        editBtn.style.background = 'transparent';
        editBtn.style.border = 'none';
        editBtn.style.color = '#8b949e';
        editBtn.style.cursor = 'pointer';
        editBtn.style.padding = '2px 6px';
        editBtn.style.marginLeft = '4px';
        editBtn.style.fontSize = '12px';
        editBtn.title = 'Edit team';
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const teamNameToEdit = getTeamName(team);
          renameSelectedTeam(teamNameToEdit);
        });
        
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.style.background = 'transparent';
        deleteBtn.style.border = 'none';
        deleteBtn.style.color = '#8b949e';
        deleteBtn.style.cursor = 'pointer';
        deleteBtn.style.padding = '2px 6px';
        deleteBtn.style.marginLeft = '2px';
        deleteBtn.style.fontSize = '16px';
        deleteBtn.title = 'Delete team';
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const teamNameToDelete = getTeamName(team);
          deleteSelectedTeam(teamNameToDelete);
        });
        
        teamItem.appendChild(checkbox);
        teamItem.appendChild(label);
        teamItem.appendChild(myTeamBtn);
        teamItem.appendChild(editBtn);
        teamItem.appendChild(deleteBtn);
        teamList.appendChild(teamItem);
      });
    });
  }

  function updateSelectedTeamDisplay() {
    if (!selectedTeamDisplay) return;
    
    chrome.storage.local.get(['analyses', 'players'], (result) => {
      if (handleStorageError(null, 'updateSelectedTeamDisplay')) {
        return;
      }
      
      const analyses = result.analyses || [];
      const players = result.players || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const currentSelectedTeam = analysis ? (analysis.selectedTeam || null) : null;
      
      selectedTeamDisplay.innerHTML = '';
      
      // Get all teams from selected players
      const selectedPlayerObjects = players.filter(p => selectedPlayers.includes(p.id));
      const teamsFromPlayers = [...new Set(selectedPlayerObjects.map(p => p.team).filter(t => t && t.trim() !== ''))];
      
      // Combine manually selected teams with teams from players
      const allTeams = new Set();
      if (currentSelectedTeam) {
        const teamName = getTeamName(currentSelectedTeam);
        if (teamName) allTeams.add(teamName);
      }
      selectedTeams.forEach(team => {
        const teamName = getTeamName(team);
        if (teamName) allTeams.add(teamName);
      });
      teamsFromPlayers.forEach(team => {
        const teamName = typeof team === 'string' ? team : (team?.name || team);
        if (teamName && teamName.trim() !== '') allTeams.add(teamName);
      });
      
      if (allTeams.size > 0) {
        Array.from(allTeams).forEach(teamName => {
          const tag = document.createElement('span');
          tag.className = 'selected-team-tag';
          tag.style.display = 'inline-block';
          tag.style.background = '#21262d';
          tag.style.color = '#c9d1d9';
          tag.style.padding = '4px 8px';
          tag.style.borderRadius = '12px';
          tag.style.fontSize = '12px';
          tag.style.marginRight = '6px';
          tag.style.marginBottom = '4px';
          tag.textContent = teamName;
          
          const removeBtn = document.createElement('span');
          removeBtn.textContent = ' ×';
          removeBtn.style.cursor = 'pointer';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.color = '#8b949e';
          removeBtn.addEventListener('click', () => {
            // If this is the manually selected team, clear it
            if (team === currentSelectedTeam) {
              selectedTeam = null;
              saveSelectedTeam(null);
            }
            // Remove from selectedTeams array
            selectedTeams = selectedTeams.filter(t => t !== team);
            // Remove all players from this team from selection
            const playersToRemove = selectedPlayerObjects.filter(p => p.team === team).map(p => p.id);
            selectedPlayers = selectedPlayers.filter(id => !playersToRemove.includes(id));
            updateSelectedPlayersDisplay();
            const teamSearchInput = document.getElementById('distatsTeamSearchInput');
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
          });
          
          tag.appendChild(removeBtn);
          selectedTeamDisplay.appendChild(tag);
        });
      } else if (currentSelectedTeam) {
        // Show manually selected team even if no players
        const teamName = getTeamName(currentSelectedTeam);
        if (teamName) {
          const tag = document.createElement('span');
          tag.className = 'selected-team-tag';
          tag.style.display = 'inline-block';
          tag.style.background = '#21262d';
          tag.style.color = '#c9d1d9';
          tag.style.padding = '4px 8px';
          tag.style.borderRadius = '12px';
          tag.style.fontSize = '12px';
          tag.style.marginBottom = '4px';
          tag.textContent = teamName;
          
          const removeBtn = document.createElement('span');
          removeBtn.textContent = ' ×';
          removeBtn.style.cursor = 'pointer';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.color = '#8b949e';
          removeBtn.addEventListener('click', () => {
            selectedTeam = null;
            saveSelectedTeam(null);
            updateSelectedTeamDisplay();
            const teamSearchInput = document.getElementById('distatsTeamSearchInput');
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
          });
          
          tag.appendChild(removeBtn);
          selectedTeamDisplay.appendChild(tag);
        }
      }
    });
  }

  // Load teams dropdown for current analysis
  function loadTeamsDropdown() {
    // This function is now replaced by renderTeamSelector, but keeping for backward compatibility
    renderTeamSelector('');
    updateSelectedTeamDisplay();
    
    const teamSelect = document.getElementById('distatsTeamSelect');
    if (!teamSelect) return;

    if (!currentAnalysisId) {
      teamSelect.innerHTML = '<option value="">No team</option>';
      updateTeamButtonsState();
      return;
    }

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'loadTeamsDropdown')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);

        if (analysis) {
          const teams = analysis.teams || [];
          const selectedTeam = analysis.selectedTeam || null;
          teamSelect.innerHTML = '<option value="">No team</option>';
          
          teams.forEach(team => {
            const option = document.createElement('option');
            const teamName = getTeamName(team);
            option.value = teamName;
            option.textContent = teamName;
            teamSelect.appendChild(option);
          });
          
          // Restore selected team
          if (selectedTeam && teams.some(t => getTeamName(t) === selectedTeam)) {
            teamSelect.value = selectedTeam;
          }
        } else {
          teamSelect.innerHTML = '<option value="">No team</option>';
        }
        
        updateTeamButtonsState();
      });
    } catch (e) {
      handleStorageError(e, 'loadTeamsDropdown');
    }
  }

  // Update team buttons state (enable/disable based on selection)
  function updateTeamButtonsState() {
    const teamSelect = document.getElementById('distatsTeamSelect');
    const renameBtn = document.getElementById('distatsRenameTeamBtn');
    const deleteBtn = document.getElementById('distatsDeleteTeamBtn');
    
    const hasSelection = teamSelect && teamSelect.value && teamSelect.value !== '';
    
    if (renameBtn) {
      renameBtn.disabled = !hasSelection;
    }
    if (deleteBtn) {
      deleteBtn.disabled = !hasSelection;
    }
  }

  // Save selected team to analysis
  function saveSelectedTeam(teamName) {
    if (!currentAnalysisId) return;

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'saveSelectedTeam')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          analyses[analysisIndex].selectedTeam = teamName || null;
          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'saveSelectedTeam-set')) {
              return;
            }
            updateSelectedTeamDisplay();
          });
        }
      });
    } catch (e) {
      handleStorageError(e, 'saveSelectedTeam');
    }
  }

  function saveUserTeam(teamName) {
    if (!currentAnalysisId) return;

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'saveUserTeam')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          analyses[analysisIndex].userTeam = teamName || null;
          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'saveUserTeam-set')) {
              return;
            }
            updateSelectedTeamDisplay();
            const teamSearchInput = document.getElementById('distatsTeamSearchInput');
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
          });
        }
      });
    } catch (e) {
      handleStorageError(e, 'saveUserTeam');
    }
  }

  // Team modal management
  let currentEditingTeamName = null;

  // Helper functions for team data structure (backward compatible)
  function getTeamName(team) {
    return typeof team === 'string' ? team : (team?.name || '');
  }
  
  function getTeamObject(teamName, teams) {
    if (!teams || !Array.isArray(teams)) return null;
    const team = teams.find(t => getTeamName(t) === teamName);
    if (!team) return null;
    return typeof team === 'string' ? { name: team, homeColor: '#FFFFFF', awayColor: '#000000' } : team;
  }
  
  function ensureTeamObject(team) {
    if (typeof team === 'string') {
      return { name: team, homeColor: '#FFFFFF', awayColor: '#000000', formation: '', squad: {} };
    }
    return {
      name: team.name || '',
      homeColor: team.homeColor || '#FFFFFF',
      awayColor: team.awayColor || '#000000',
      formation: team.formation || '',
      squad: team.squad || {}
    };
  }

  // Draw t-shirt preview on canvas
  function drawTshirtPreview(canvas, color, number = '10') {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    const centerX = width / 2;
    const centerY = height / 2;
    const shirtWidth = width * 0.7;
    const shirtHeight = height * 0.8;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;
    
    ctx.save();
    
    ctx.fillStyle = color || '#FFFFFF';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    
    ctx.beginPath();
    const collarWidth = shirtWidth * 0.4;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;
    
    ctx.moveTo(startX, startY + shirtHeight * 0.1);
    ctx.quadraticCurveTo(startX + shoulderWidth, startY, startX + shoulderWidth, startY + shirtHeight * 0.05);
    ctx.quadraticCurveTo(centerX, startY + shirtHeight * 0.2, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.05);
    ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth, startY, startX + shirtWidth, startY + shirtHeight * 0.1);
    ctx.lineTo(startX + shirtWidth + shirtWidth * 0.15, startY + shirtHeight * 0.3);
    ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.4);
    ctx.lineTo(startX + shirtWidth, startY + shirtHeight);
    ctx.quadraticCurveTo(centerX, startY + shirtHeight + shirtHeight * 0.05, startX, startY + shirtHeight);
    ctx.lineTo(startX, startY + shirtHeight * 0.4);
    ctx.lineTo(startX - shirtWidth * 0.15, startY + shirtHeight * 0.3);
    ctx.closePath();
    
    ctx.fill();
    ctx.stroke();
    
    // Draw number
    const hex = (color || '#FFFFFF').replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
    
    ctx.fillStyle = textColor;
    ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(number, centerX, centerY + shirtHeight * 0.1);
    
    ctx.restore();
  }

  // Update t-shirt previews
  function updateTshirtPreviews() {
    const homeColorInput = document.getElementById('distatsTeamHomeColorInput');
    const awayColorInput = document.getElementById('distatsTeamAwayColorInput');
    const homePreview = document.getElementById('distatsTeamHomeTshirtPreview');
    const awayPreview = document.getElementById('distatsTeamAwayTshirtPreview');
    
    if (homeColorInput && homePreview) {
      drawTshirtPreview(homePreview, homeColorInput.value, '10');
    }
    if (awayColorInput && awayPreview) {
      drawTshirtPreview(awayPreview, awayColorInput.value, '10');
    }
  }

  // Load and populate formation selector
  function loadFormationSelector() {
    const formationSelect = document.getElementById('distatsTeamFormationSelect');
    if (!formationSelect) return;

    // Clear all options and optgroups, keeping only the first option
    const firstOption = formationSelect.options[0];
    formationSelect.innerHTML = '';
    if (firstOption) {
      formationSelect.appendChild(firstOption);
    }

    // Built-in formations (same as in editor.js and popup.js)
    const builtInFormations = [
      { value: '4-3-3', name: '4-3-3', group: 'Back-four systems' },
      { value: '4-2-3-1', name: '4-2-3-1', group: 'Back-four systems' },
      { value: '4-4-2', name: '4-4-2 (Flat)', group: 'Back-four systems' },
      { value: '4-1-2-1-2', name: '4-1-2-1-2', group: 'Back-four systems' },
      { value: '4-1-4-1', name: '4-1-4-1', group: 'Back-four systems' },
      { value: '4-5-1', name: '4-5-1', group: 'Back-four systems' },
      { value: '4-3-2-1', name: '4-3-2-1', group: 'Back-four systems' },
      { value: '4-1-2-3', name: '4-1-2-3', group: 'Back-four systems' },
      { value: '3-5-2', name: '3-5-2', group: 'Back-three systems' },
      { value: '3-4-3', name: '3-4-3', group: 'Back-three systems' },
      { value: '3-4-1-2', name: '3-4-1-2', group: 'Back-three systems' },
      { value: '3-3-3-1', name: '3-3-3-1', group: 'Back-three systems' },
      { value: '3-2-4-1', name: '3-2-4-1', group: 'Back-three systems' },
      { value: '5-3-2', name: '5-3-2', group: 'Back-five systems' },
      { value: '5-4-1', name: '5-4-1', group: 'Back-five systems' },
      { value: '5-2-3', name: '5-2-3', group: 'Back-five systems' },
      { value: '4-3-1-2', name: '4-3-1-2', group: 'Less common' },
      { value: '4-2-1-3', name: '4-2-1-3', group: 'Less common' },
      { value: '4-6-0', name: '4-6-0 (False 9)', group: 'Less common' },
      { value: '3-6-1', name: '3-6-1', group: 'Less common' }
    ];

    // Group formations by category
    const groups = {};
    builtInFormations.forEach(f => {
      if (!groups[f.group]) {
        groups[f.group] = [];
      }
      groups[f.group].push(f);
    });

    // Add optgroups and options
    Object.keys(groups).forEach(groupName => {
      const optgroup = document.createElement('optgroup');
      // Translate group label
      let translatedGroupName = groupName;
      if (window.i18n && typeof window.i18n.t === 'function') {
        const groupMap = {
          'Back-four systems': 'editor.backFourSystems',
          'Back-three systems': 'editor.backThreeSystems',
          'Back-five systems': 'editor.backFiveSystems',
          'Less common': 'editor.lessCommon',
          'Custom Formations': 'editor.customFormations'
        };
        const key = groupMap[groupName];
        if (key) {
          const translated = window.i18n.t(key);
          translatedGroupName = translated !== key ? translated : groupName;
        }
      }
      optgroup.label = translatedGroupName;
      groups[groupName].forEach(f => {
        const option = document.createElement('option');
        option.value = f.value;
        option.textContent = f.name;
        optgroup.appendChild(option);
      });
      formationSelect.appendChild(optgroup);
    });

    // Load custom formations from storage
    chrome.storage.local.get(['customFormations'], (result) => {
      const customFormations = result.customFormations || {};
      const customKeys = Object.keys(customFormations);
      
      if (customKeys.length > 0) {
        const customGroup = document.createElement('optgroup');
        const customFormationsText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.customFormations')
          : 'Custom Formations';
        customGroup.label = customFormationsText;
        customKeys.sort().forEach(key => {
          const formation = customFormations[key];
          const option = document.createElement('option');
          option.value = key;
          option.textContent = formation.name || key;
          customGroup.appendChild(option);
        });
        formationSelect.appendChild(customGroup);
      }
    });
  }

  function openTeamModal(teamName = null) {
    const teamModal = document.getElementById('distatsTeamModal');
    const teamModalTitle = document.getElementById('distatsTeamModalTitle');
    const teamNameInput = document.getElementById('distatsTeamNameInput');
    const teamHomeColorInput = document.getElementById('distatsTeamHomeColorInput');
    const teamAwayColorInput = document.getElementById('distatsTeamAwayColorInput');
    const teamFormationSelect = document.getElementById('distatsTeamFormationSelect');
    const teamPlayersSection = document.getElementById('distatsTeamPlayersSection');
    const teamPlayersList = document.getElementById('distatsTeamPlayersList');
    
    if (!teamModal || !teamNameInput || !teamHomeColorInput || !teamAwayColorInput) {
      console.error('Team modal elements not found');
      return;
    }

    // Load formations into selector
    loadFormationSelector();

    currentEditingTeamName = teamName;
    
    // Reset squad assignments
    currentSquadAssignments = {};
    
    if (teamName) {
      // Editing existing team
      const editTeamText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.editTeam')
        : 'Edit Team';
      teamModalTitle.textContent = editTeamText;
      teamNameInput.value = teamName;
      
      // Load team colors and squad from both analysis and global storage
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        if (handleStorageError(null, 'openTeamModal')) return;
        const analyses = result.analyses || [];
        const globalTeams = result.teams || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        
        let teamData = null;
        
        // First try to find team in analysis.teams
        if (analysis && analysis.teams) {
          const teamObj = getTeamObject(teamName, analysis.teams);
          if (teamObj) {
            teamData = ensureTeamObject(teamObj);
          }
        }
        
        // If not found in analysis, try global teams storage
        if (!teamData) {
          const globalTeamObj = globalTeams.find(t => {
            const tName = typeof t === 'string' ? t : (t.name || '');
            return tName === teamName;
          });
          if (globalTeamObj) {
            teamData = typeof globalTeamObj === 'string' ? { name: globalTeamObj } : ensureTeamObject(globalTeamObj);
          }
        }
        
        if (teamData) {
          teamHomeColorInput.value = teamData.homeColor || '#FFFFFF';
          teamAwayColorInput.value = teamData.awayColor || '#000000';
          if (teamFormationSelect && teamData.formation) {
            teamFormationSelect.value = teamData.formation;
          }
          // Load squad assignments
          if (teamData.squad) {
            currentSquadAssignments = { ...teamData.squad };
          }
          // Render squad formation
          setTimeout(() => {
            renderSquadFormation(teamData.formation || '', teamName, currentSquadAssignments);
          }, 50);
        } else {
          teamHomeColorInput.value = '#FFFFFF';
          teamAwayColorInput.value = '#000000';
          if (teamFormationSelect) {
            teamFormationSelect.value = '';
          }
          renderSquadFormation('', teamName, {});
        }
        updateTshirtPreviews();
      });
      
      // Show and populate players section
      if (teamPlayersSection && teamPlayersList) {
        teamPlayersSection.style.display = 'block';
        teamPlayersList.innerHTML = '';
        
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const teamPlayers = players.filter(p => p.team === teamName);
          
          if (teamPlayers.length > 0) {
            // Sort players by number
            teamPlayers.sort((a, b) => {
              const numA = parseInt(a.number) || 0;
              const numB = parseInt(b.number) || 0;
              return numA - numB;
            });
            
            teamPlayers.forEach(player => {
              const playerItem = document.createElement('div');
              playerItem.style.display = 'flex';
              playerItem.style.alignItems = 'center';
              playerItem.style.padding = '8px 12px';
              playerItem.style.marginBottom = '6px';
              playerItem.style.background = '#0d1117';
              playerItem.style.borderRadius = '4px';
              playerItem.style.border = '1px solid #21262d';
              
              const playerText = document.createElement('span');
              playerText.style.flex = '1';
              playerText.style.fontSize = '13px';
              playerText.style.color = '#c9d1d9';
              const displayText = player.number ? 
                `#${player.number} ${player.fullName || ''}`.trim() : 
                (player.fullName || 'Unnamed');
              playerText.textContent = displayText;
              playerItem.appendChild(playerText);
              
              const editBtn = document.createElement('button');
              editBtn.textContent = '✎';
              editBtn.style.background = 'transparent';
              editBtn.style.border = 'none';
              editBtn.style.color = '#8b949e';
              editBtn.style.cursor = 'pointer';
              editBtn.style.padding = '4px 8px';
              editBtn.style.marginLeft = '8px';
              editBtn.style.fontSize = '12px';
              const editPlayerText = (window.i18n && typeof window.i18n.t === 'function')
                ? window.i18n.t('editor.editPlayer')
                : 'Edit player';
              editBtn.title = editPlayerText;
              editBtn.addEventListener('click', () => {
                closeTeamModal();
                editPlayer(player.id);
              });
              playerItem.appendChild(editBtn);
              
              const removeFromTeamBtn = document.createElement('button');
              removeFromTeamBtn.textContent = '×';
              removeFromTeamBtn.style.background = 'transparent';
              removeFromTeamBtn.style.border = 'none';
              removeFromTeamBtn.style.color = '#8b949e';
              removeFromTeamBtn.style.cursor = 'pointer';
              removeFromTeamBtn.style.padding = '4px 8px';
              removeFromTeamBtn.style.marginLeft = '4px';
              removeFromTeamBtn.style.fontSize = '16px';
              const removeFromTeamText = (window.i18n && typeof window.i18n.t === 'function')
                ? window.i18n.t('editor.removeFromTeam')
                : 'Remove from team';
              removeFromTeamBtn.title = removeFromTeamText;
              removeFromTeamBtn.addEventListener('click', () => {
                removePlayerFromTeam(player.id);
                // Refresh the team modal
                setTimeout(() => {
                  openTeamModal(teamName);
                }, 100);
              });
              playerItem.appendChild(removeFromTeamBtn);
              
              teamPlayersList.appendChild(playerItem);
            });
          } else {
            const noPlayersMsg = document.createElement('div');
            noPlayersMsg.style.padding = '8px';
            noPlayersMsg.style.fontSize = '12px';
            noPlayersMsg.style.color = '#8b949e';
            noPlayersMsg.style.fontStyle = 'italic';
            const noPlayersText = (window.i18n && typeof window.i18n.t === 'function')
              ? window.i18n.t('editor.noPlayersAttachedToTeam')
              : 'No players attached to this team';
            noPlayersMsg.textContent = noPlayersText;
            teamPlayersList.appendChild(noPlayersMsg);
          }
        });
      }
    } else {
      // Creating new team
      const addTeamText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.addTeam')
        : 'Add Team';
      teamModalTitle.textContent = addTeamText;
      teamNameInput.value = '';
      if (teamFormationSelect) {
        teamFormationSelect.value = '';
      }
      
      // Hide players section and squad section for new teams
      if (teamPlayersSection) {
        teamPlayersSection.style.display = 'none';
      }
      const squadSection = document.getElementById('distatsTeamSquadSection');
      if (squadSection) {
        squadSection.style.display = 'none';
      }
    }
    
    // Set up color input listeners using direct property assignment (replaces any previous handler)
    const homeColorInput = document.getElementById('distatsTeamHomeColorInput');
    const awayColorInput = document.getElementById('distatsTeamAwayColorInput');
    
    if (homeColorInput) {
      homeColorInput.oninput = updateTshirtPreviews;
      homeColorInput.onchange = updateTshirtPreviews;
    }
    if (awayColorInput) {
      awayColorInput.oninput = updateTshirtPreviews;
      awayColorInput.onchange = updateTshirtPreviews;
    }
    
    // Update previews
    updateTshirtPreviews();
    
    teamModal.classList.remove('hidden');
    teamNameInput.focus();
  }

  function closeTeamModal() {
    const teamModal = document.getElementById('distatsTeamModal');
    if (teamModal) {
      teamModal.classList.add('hidden');
      currentEditingTeamName = null;
    }
  }

  function saveTeamFromModal() {
    const teamNameInput = document.getElementById('distatsTeamNameInput');
    
    if (!teamNameInput) {
      return;
    }

    const teamName = teamNameInput.value.trim();
    
    if (!teamName) {
      showErrorModal('Please enter a team name.');
      return;
    }
    
    // Get current values from inputs
    const homeColorInput = document.getElementById('distatsTeamHomeColorInput');
    const awayColorInput = document.getElementById('distatsTeamAwayColorInput');
    const formationSelect = document.getElementById('distatsTeamFormationSelect');
    
    const homeColor = homeColorInput ? homeColorInput.value : '#FFFFFF';
    const awayColor = awayColorInput ? awayColorInput.value : '#000000';
    const formation = formationSelect ? formationSelect.value : '';
    
    console.log('Saving team:', { teamName, homeColor, awayColor, formation });
    
    if (currentEditingTeamName) {
      // Renaming existing team
      if (teamName === currentEditingTeamName) {
        // Just update colors and formation without renaming
        renameTeam(currentEditingTeamName, teamName, homeColor, awayColor, formation);
        return;
      }
      
      renameTeam(currentEditingTeamName, teamName, homeColor, awayColor, formation);
    } else {
      // Creating new team
      createTeam(teamName, homeColor, awayColor, formation);
    }
  }

  function renameTeam(oldTeamName, newTeamName, homeColor = '#FFFFFF', awayColor = '#000000', formation = '') {
    if (!currentAnalysisId) {
      return;
    }

    if (!isExtensionContextValid()) {
      showErrorModal('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'players', 'teams'], (result) => {
        if (handleStorageError(null, 'renameTeam')) {
          return;
        }

        const analyses = result.analyses || [];
        const players = result.players || [];
        const globalTeams = result.teams || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          
          if (!analysis.teams) {
            analysis.teams = [];
          }

          // Check if new name already exists (only if actually renaming, not just updating)
          if (oldTeamName !== newTeamName) {
            const teamExistsInAnalysis = analysis.teams.some(t => getTeamName(t) === newTeamName);
            const teamExistsInGlobal = globalTeams.some(t => {
              const teamName = typeof t === 'string' ? t : (t.name || '');
              return teamName === newTeamName;
            });
            if (teamExistsInAnalysis || teamExistsInGlobal) {
              showErrorModal('This team name already exists.');
              return;
            }
          }

          // Update team in analysis.teams array with colors
          const teamIndex = analysis.teams.findIndex(t => getTeamName(t) === oldTeamName);
          if (teamIndex !== -1) {
            const oldTeam = analysis.teams[teamIndex];
            const oldTeamObj = ensureTeamObject(oldTeam);
            const teamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              formation: formation || ''
            };
            // Preserve existing design and second colors if they exist
            if (oldTeamObj.homeDesign) {
              teamData.homeDesign = oldTeamObj.homeDesign;
            }
            if (oldTeamObj.awayDesign) {
              teamData.awayDesign = oldTeamObj.awayDesign;
            }
            if (oldTeamObj.homeSecondColor) {
              teamData.homeSecondColor = oldTeamObj.homeSecondColor;
            }
            if (oldTeamObj.awaySecondColor) {
              teamData.awaySecondColor = oldTeamObj.awaySecondColor;
            }
            // Save squad assignments
            if (currentSquadAssignments && Object.keys(currentSquadAssignments).length > 0) {
              teamData.squad = { ...currentSquadAssignments };
            } else if (oldTeamObj.squad) {
              // Keep existing squad if not modified
              teamData.squad = oldTeamObj.squad;
            }
            analysis.teams[teamIndex] = teamData;
          }

          // Update team in global teams storage
          const globalTeamIndex = globalTeams.findIndex(t => {
            const teamName = typeof t === 'string' ? t : (t.name || '');
            return teamName === oldTeamName;
          });
          if (globalTeamIndex !== -1) {
            const oldGlobalTeam = globalTeams[globalTeamIndex];
            const oldGlobalTeamObj = typeof oldGlobalTeam === 'string' ? { name: oldGlobalTeam } : oldGlobalTeam;
            const globalTeamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              formation: formation || ''
            };
            // Preserve existing design and second colors if they exist
            if (oldGlobalTeamObj.homeDesign) {
              globalTeamData.homeDesign = oldGlobalTeamObj.homeDesign;
            }
            if (oldGlobalTeamObj.awayDesign) {
              globalTeamData.awayDesign = oldGlobalTeamObj.awayDesign;
            }
            if (oldGlobalTeamObj.homeSecondColor) {
              globalTeamData.homeSecondColor = oldGlobalTeamObj.homeSecondColor;
            }
            if (oldGlobalTeamObj.awaySecondColor) {
              globalTeamData.awaySecondColor = oldGlobalTeamObj.awaySecondColor;
            }
            globalTeams[globalTeamIndex] = globalTeamData;
          } else if (oldTeamName === newTeamName) {
            // If team doesn't exist in global storage but we're just updating colors, add it
            const teamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              formation: formation || ''
            };
            globalTeams.push(teamData);
          }

          // Update selectedTeam if it was the renamed team
          if (analysis.selectedTeam === oldTeamName) {
            analysis.selectedTeam = newTeamName;
          }
          // Update userTeam if it was the renamed team
          if (analysis.userTeam === oldTeamName) {
            analysis.userTeam = newTeamName;
          }

          // Update all notes that reference this team across all analyses
          analyses.forEach(a => {
            if (a.notes) {
              a.notes.forEach(note => {
                if (note.team === oldTeamName) {
                  note.team = newTeamName;
                }
              });
            }
          });

          analyses[analysisIndex] = analysis;

          // Update all players that belong to this team
          players.forEach(player => {
            if (player.team === oldTeamName) {
              player.team = newTeamName;
            }
          });

          chrome.storage.local.set({ analyses: analyses, players: players, teams: globalTeams }, () => {
            if (handleStorageError(null, 'renameTeam-set')) {
              return;
            }
            console.log('Team updated:', { oldTeamName, newTeamName, homeColor, awayColor, formation });
            closeTeamModal();
            const teamSearchInput = document.getElementById('distatsTeamSearchInput');
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            updateSelectedTeamDisplay();
            const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
            renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            updateNotesDisplay(); // Refresh notes to show updated data
          });
        }
      });
    } catch (e) {
      handleStorageError(e, 'renameTeam');
    }
  }

  function createTeam(teamName, homeColor = '#FFFFFF', awayColor = '#000000', formation = '') {
    if (!currentAnalysisId) {
      showErrorModal('Please select or create a project first.');
      return;
    }

    if (!isExtensionContextValid()) {
      showErrorModal('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        if (handleStorageError(null, 'createTeam')) {
          return;
        }

        const analyses = result.analyses || [];
        const globalTeams = result.teams || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          
          // Initialize teams array if it doesn't exist
          if (!analysis.teams) {
            analysis.teams = [];
          }

          // Check if team already exists in analysis or global storage
          const teamExistsInAnalysis = analysis.teams.some(t => getTeamName(t) === teamName);
          const teamExistsInGlobal = globalTeams.some(t => {
            const tName = typeof t === 'string' ? t : (t.name || '');
            return tName === teamName;
          });
          if (teamExistsInAnalysis || teamExistsInGlobal) {
            showErrorModal('This team already exists.');
            return;
          }

          // Add new team as object with colors, formation, and unique ID
          const teamId = `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          const teamData = {
            id: teamId,
            name: teamName,
            homeColor: homeColor,
            awayColor: awayColor,
            formation: formation || '',
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          
          // Add to analysis teams (for backward compatibility)
          analysis.teams.push(teamData);
          
          // Add to global teams storage
          globalTeams.push(teamData);
          
          // Auto-attach team to this project since it was created from this project
          if (!analysis.attachedTeamIds) {
            analysis.attachedTeamIds = [];
          }
          if (!analysis.attachedTeamIds.includes(teamId)) {
            analysis.attachedTeamIds.push(teamId);
          }
          
          // Set as selected team
          analysis.selectedTeam = teamName;
          analyses[analysisIndex] = analysis;

          chrome.storage.local.set({ analyses: analyses, teams: globalTeams }, () => {
            if (handleStorageError(null, 'createTeam-set')) {
              return;
            }
            console.log('Team created:', { teamName, homeColor, awayColor, formation });
            selectedTeam = teamName;
            saveSelectedTeam(teamName);
            closeTeamModal();
            const teamSearchInput = document.getElementById('distatsTeamSearchInput');
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            updateSelectedTeamDisplay();
          });
        }
      });
    } catch (e) {
      handleStorageError(e, 'createTeam');
    }
  }

  // Rename selected team
  function renameSelectedTeam(teamName = null) {
    if (!teamName) {
      showErrorModal('Please select a team to rename.');
      return;
    }
    openTeamModal(teamName);
  }

  // Delete selected team
  function deleteSelectedTeam(teamName = null) {
    if (!currentAnalysisId) {
      showErrorModal('Please select or create a project first.');
      return;
    }

    chrome.storage.local.get(['analyses'], (result) => {
      if (handleStorageError(null, 'deleteSelectedTeam-get')) {
        return;
      }

      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (!analysis) {
        return;
      }

      const teamToDelete = teamName || analysis.selectedTeam;

      if (!teamToDelete) {
        showErrorModal('Please select a team to delete.');
        return;
      }

      showDeleteConfirmModal(`Are you sure you want to delete the team "${teamToDelete}"? This will remove the team from all notes.`, () => {
        if (!isExtensionContextValid()) {
          alert('Extension context invalidated. Please reload the page.');
          return;
        }

        try {
          chrome.storage.local.get(['teams'], (teamsResult) => {
            if (handleStorageError(null, 'deleteSelectedTeam-get-teams')) {
              return;
            }
            
            const globalTeams = teamsResult.teams || [];
            const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

            if (analysisIndex !== -1) {
              const analysis = analyses[analysisIndex];
              
              // Remove team from global teams storage
              const updatedGlobalTeams = globalTeams.filter(t => {
                const existingName = typeof t === 'string' ? t : (t.name || '');
                return existingName !== teamToDelete;
              });

              // Remove team from analysis.teams (for backward compatibility)
              if (analysis.teams) {
                analysis.teams = analysis.teams.filter(t => getTeamName(t) !== teamToDelete);
              }

              // Clear selectedTeam if it was the deleted team
              if (analysis.selectedTeam === teamToDelete) {
                analysis.selectedTeam = null;
              }
              // Clear userTeam if it was the deleted team
              if (analysis.userTeam === teamToDelete) {
                analysis.userTeam = null;
              }

              // Remove team from all notes in all analyses
              analyses.forEach(a => {
                if (a.notes) {
                  a.notes.forEach(note => {
                    if (note.team === teamToDelete) {
                      note.team = null;
                    }
                    if (note.teams && Array.isArray(note.teams)) {
                      note.teams = note.teams.filter(t => t !== teamToDelete);
                    }
                  });
                }
              });

              analyses[analysisIndex] = analysis;

              chrome.storage.local.set({ analyses: analyses, teams: updatedGlobalTeams }, () => {
                if (handleStorageError(null, 'deleteSelectedTeam-set')) {
                  return;
                }
                console.log('Team deleted from global storage:', teamToDelete);
                const teamSearchInput = document.getElementById('distatsTeamSearchInput');
                renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
                updateSelectedTeamDisplay();
              });
            }
          });
        } catch (e) {
          handleStorageError(e, 'deleteSelectedTeam');
        }
      });
    });
  }

  // Create new team
  function createNewTeam() {
    openTeamModal();
  }


  // Error modal function
  function showErrorModal(message) {
    // Create a simple error modal if it doesn't exist
    let errorModal = document.getElementById('distatsErrorModal');
    if (!errorModal) {
      errorModal = document.createElement('div');
      errorModal.id = 'distatsErrorModal';
      errorModal.className = 'project-modal hidden';
      errorModal.innerHTML = `
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3>Notice</h3>
            <button class="close-modal-btn" id="distatsCloseErrorModal">×</button>
          </div>
          <div class="project-modal-body">
            <p id="distatsErrorModalMessage" style="
              color: #8b949e;
              margin: 0 0 20px 0;
              font-size: 14px;
              line-height: 1.5;
              word-wrap: break-word;
            "></p>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="distatsOkErrorBtn" class="create-new-project-btn">OK</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(errorModal);
      
      const distatsCloseErrorModalBtn = document.getElementById('distatsCloseErrorModal');
      const distatsOkErrorBtn = document.getElementById('distatsOkErrorBtn');
      
      if (distatsCloseErrorModalBtn) {
        distatsCloseErrorModalBtn.addEventListener('click', () => {
          errorModal.classList.add('hidden');
        });
      }
      
      if (distatsOkErrorBtn) {
        distatsOkErrorBtn.addEventListener('click', () => {
          errorModal.classList.add('hidden');
        });
      }
      
      errorModal.addEventListener('click', (e) => {
        if (e.target === errorModal) {
          errorModal.classList.add('hidden');
        }
      });
    }
    
    const errorMessage = document.getElementById('distatsErrorModalMessage');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
    errorModal.classList.remove('hidden');
  }

  // Player management functions
  function renderPlayerSelector(searchQuery = '') {
    const playerList = document.getElementById('distatsPlayerList');
    if (!playerList) return;
    
    chrome.storage.local.get(['players', 'analyses'], (result) => {
      if (handleStorageError(null, 'renderPlayerSelector')) {
      return;
    }

      const players = result.players || [];
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const teams = analysis ? (analysis.teams || []) : [];
      
      // Filter players by search query
      const filteredPlayers = players.filter(player => {
        const searchLower = searchQuery.toLowerCase();
        const fullName = (player.fullName || '').toLowerCase();
        const number = (player.number || '').toString();
        const team = (player.team || '').toLowerCase();
        return fullName.includes(searchLower) || 
               number.includes(searchLower) || 
               team.includes(searchLower);
      });
      
      playerList.innerHTML = '';
      
      if (filteredPlayers.length === 0) {
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.style.textAlign = 'center';
        emptyMsg.textContent = searchQuery ? 'No players found' : 'No players created yet';
        playerList.appendChild(emptyMsg);
      return;
    }

      // Group by team
      const playersByTeam = {};
      filteredPlayers.forEach(player => {
        const team = player.team || 'No team';
        if (!playersByTeam[team]) {
          playersByTeam[team] = [];
        }
        playersByTeam[team].push(player);
      });
      
      // Sort teams
      const sortedTeams = Object.keys(playersByTeam).sort();
      
      sortedTeams.forEach((team, teamIndex) => {
        const teamDiv = document.createElement('div');
        teamDiv.style.marginBottom = teamIndex < sortedTeams.length - 1 ? '12px' : '0';
        
        const teamLabel = document.createElement('div');
        teamLabel.style.fontSize = '11px';
        teamLabel.style.color = '#8b949e';
        teamLabel.style.marginBottom = '6px';
        teamLabel.style.fontWeight = '500';
        teamLabel.textContent = team;
        teamDiv.appendChild(teamLabel);
        
        playersByTeam[team].sort((a, b) => {
          const numA = parseInt(a.number) || 0;
          const numB = parseInt(b.number) || 0;
          return numA - numB;
        }).forEach(player => {
          const playerItem = document.createElement('div');
          playerItem.style.display = 'flex';
          playerItem.style.alignItems = 'center';
          playerItem.style.padding = '6px 8px';
          playerItem.style.cursor = 'pointer';
          playerItem.style.borderRadius = '4px';
          playerItem.style.marginBottom = '2px';
          
          playerItem.addEventListener('mouseenter', () => {
            playerItem.style.background = '#21262d';
          });
          playerItem.addEventListener('mouseleave', () => {
            playerItem.style.background = 'transparent';
          });
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = player.id;
          checkbox.checked = selectedPlayers.includes(player.id);
          checkbox.style.marginRight = '8px';
          checkbox.style.cursor = 'pointer';
          
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedPlayers.includes(player.id)) {
                selectedPlayers.push(player.id);
              }
            } else {
              selectedPlayers = selectedPlayers.filter(id => id !== player.id);
            }
            updateSelectedPlayersDisplay();
          });
          
          const label = document.createElement('label');
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          
          const displayText = player.number ? 
            `#${player.number} ${player.fullName || ''}`.trim() : 
            (player.fullName || 'Unnamed');
          label.textContent = displayText;
          
          label.addEventListener('click', () => {
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
          });
          
          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit player';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editPlayer(player.id);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete player';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deletePlayer(player.id);
          });
          
          playerItem.appendChild(checkbox);
          playerItem.appendChild(label);
          playerItem.appendChild(editBtn);
          playerItem.appendChild(deleteBtn);
          teamDiv.appendChild(playerItem);
        });
        
        playerList.appendChild(teamDiv);
      });
    });
  }

  function updateSelectedPlayersDisplay() {
    if (!selectedPlayersDisplay) return;
    
    if (selectedPlayers.length === 0) {
      selectedPlayersDisplay.innerHTML = '';
      selectedPlayersDisplay.style.display = 'none';
      updateSelectedTeamDisplay();
      return;
    }
    
    selectedPlayersDisplay.style.display = 'flex';

    chrome.storage.local.get(['players'], (result) => {
      if (handleStorageError(null, 'updateSelectedPlayersDisplay')) {
        return;
      }
      
      const players = result.players || [];
      const selectedPlayerObjects = players.filter(p => selectedPlayers.includes(p.id));
      
      selectedPlayersDisplay.innerHTML = '';
      
      const label = document.createElement('div');
      label.style.fontSize = '11px';
      label.style.color = '#8b949e';
      label.style.marginBottom = '4px';
      const selectedPlayersText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('editor.selectedPlayers')
        : 'Selected players:';
      label.textContent = selectedPlayersText;
      selectedPlayersDisplay.appendChild(label);
      
      selectedPlayerObjects.forEach(player => {
        const tag = document.createElement('span');
        tag.className = 'selected-player-tag';
        tag.style.display = 'inline-block';
        tag.style.background = '#21262d';
        tag.style.color = '#c9d1d9';
        tag.style.padding = '4px 8px';
        tag.style.borderRadius = '12px';
        tag.style.fontSize = '12px';
        tag.style.marginRight = '6px';
        tag.style.marginBottom = '4px';
        
        const displayText = player.number ? 
          `#${player.number} ${player.fullName || ''}`.trim() : 
          (player.fullName || 'Unnamed');
        tag.textContent = displayText;
        
        const removeBtn = document.createElement('span');
        removeBtn.textContent = ' ×';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.marginLeft = '4px';
        removeBtn.style.color = '#8b949e';
        removeBtn.addEventListener('click', () => {
          selectedPlayers = selectedPlayers.filter(id => id !== player.id);
          updateSelectedPlayersDisplay();
          const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
          renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        });
        
        tag.appendChild(removeBtn);
        selectedPlayersDisplay.appendChild(tag);
      });
      
      // Update teams display based on selected players
      updateSelectedTeamDisplay();
    });
  }

  // Player modal management
  let currentEditingPlayerId = null;

  function openPlayerModal(playerId = null) {
    const playerModal = document.getElementById('distatsPlayerModal');
    const playerModalTitle = document.getElementById('distatsPlayerModalTitle');
    const playerNameInput = document.getElementById('distatsPlayerNameInput');
    const playerNumberInput = document.getElementById('distatsPlayerNumberInput');
    const playerTeamSelect = document.getElementById('distatsPlayerTeamSelect');
    const playerPositionSelect = document.getElementById('distatsPlayerPositionSelect');
    
    if (!playerModal || !playerNameInput || !playerNumberInput || !playerTeamSelect) {
      console.error('Player modal elements not found');
      return;
    }
    
    currentEditingPlayerId = playerId;
    
    if (playerId) {
      // Editing existing player
      const editPlayerText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.editPlayer')
        : 'Edit Player';
      playerModalTitle.textContent = editPlayerText;
      chrome.storage.local.get(['players', 'analyses'], (result) => {
        if (handleStorageError(null, 'openPlayerModal')) {
          return;
        }
        const players = result.players || [];
        const player = players.find(p => p.id === playerId);
        if (player) {
          playerNameInput.value = player.fullName || '';
          playerNumberInput.value = player.number || '';
          if (playerPositionSelect) {
            playerPositionSelect.value = player.position || '';
          }
          loadTeamsForPlayerModal(player.team || '');
        }
      });
    } else {
      // Creating new player
      const addPlayerText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.addPlayer')
        : 'Add Player';
      playerModalTitle.textContent = addPlayerText;
      playerNameInput.value = '';
      playerNumberInput.value = '';
      if (playerPositionSelect) {
        playerPositionSelect.value = '';
      }
      loadTeamsForPlayerModal('');
    }
    
    playerModal.classList.remove('hidden');
    playerNameInput.focus();
  }

  function closePlayerModal() {
    const playerModal = document.getElementById('distatsPlayerModal');
    if (playerModal) {
      playerModal.classList.add('hidden');
      currentEditingPlayerId = null;
    }
  }

  function loadTeamsForPlayerModal(selectedTeam = '') {
    const playerTeamSelect = document.getElementById('distatsPlayerTeamSelect');
    if (!playerTeamSelect) return;
    
    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      if (handleStorageError(null, 'loadTeamsForPlayerModal')) {
        return;
      }

      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      // Use global teams storage, fallback to analysis.teams for backward compatibility
      const globalTeams = result.teams || [];
      const analysisTeams = analysis ? (analysis.teams || []) : [];
      // Merge global teams with analysis teams (global takes precedence)
      const teamsMap = new Map();
      // First add analysis teams (for backward compatibility)
      analysisTeams.forEach(team => {
        const teamName = getTeamName(team);
        if (teamName) teamsMap.set(teamName.toLowerCase(), team);
      });
      // Then add global teams (overwrites duplicates)
      globalTeams.forEach(team => {
        const teamName = typeof team === 'string' ? team : (team.name || '');
        if (teamName) teamsMap.set(teamName.toLowerCase(), team);
      });
      const teams = Array.from(teamsMap.values());
      
      const selectTeamOptionText = (window.i18n && typeof window.i18n.t === 'function')
        ? window.i18n.t('modals.selectTeam')
        : 'Select team...';
      playerTeamSelect.innerHTML = `<option value="">${selectTeamOptionText}</option>`;
      
      if (teams.length === 0) {
        const option = document.createElement('option');
        option.value = '';
        const noTeamsAvailableText = (window.i18n && typeof window.i18n.t === 'function')
          ? window.i18n.t('editor.noTeamsAvailableCreateFirst')
          : 'No teams available - create a team first';
        option.textContent = noTeamsAvailableText;
        option.disabled = true;
        playerTeamSelect.appendChild(option);
        return;
      }
      
      teams.forEach(team => {
        const option = document.createElement('option');
        const teamName = getTeamName(team);
        option.value = teamName;
        option.textContent = teamName;
        if (teamName === selectedTeam) {
          option.selected = true;
        }
        playerTeamSelect.appendChild(option);
      });
    });
  }

  function savePlayerFromModal() {
    const playerNameInput = document.getElementById('distatsPlayerNameInput');
    const playerNumberInput = document.getElementById('distatsPlayerNumberInput');
    const playerTeamSelect = document.getElementById('distatsPlayerTeamSelect');
    const playerPositionSelect = document.getElementById('distatsPlayerPositionSelect');
    
    if (!playerNameInput || !playerNumberInput || !playerTeamSelect) {
            return;
          }

    const fullName = playerNameInput.value.trim();
    const number = playerNumberInput.value.trim();
    const team = playerTeamSelect.value;
    const position = playerPositionSelect ? playerPositionSelect.value : '';


    if (!fullName) {
      alert('Please enter player name.');
              return;
            }

    if (!number) {
      alert('Please enter player number.');
      return;
    }

    if (!team) {
      showErrorModal('Please select a team.');
      return;
    }
    
    if (currentEditingPlayerId) {
      // Editing existing player
      chrome.storage.local.get(['players'], (result) => {
        if (handleStorageError(null, 'savePlayerFromModal-edit')) {
          return;
        }
        const players = result.players || [];

        // Check if number is already taken by another player in the same team
        const duplicatePlayer = players.find(p =>
          p.id !== currentEditingPlayerId &&
          p.number === number &&
          p.team === team
        );
        if (duplicatePlayer) {
          showErrorModal(`Player number ${number} is already taken by ${duplicatePlayer.fullName || duplicatePlayer.name || 'another player'} in team ${team}. Please choose a different number.`);
          return;
        }

        const player = players.find(p => p.id === currentEditingPlayerId);
        if (player) {
          player.fullName = fullName;
          player.number = number;
          player.team = team;
          player.position = position;
          
          chrome.storage.local.set({ players: players }, () => {
            if (handleStorageError(null, 'savePlayerFromModal-edit-set')) {
              return;
            }
            closePlayerModal();
            const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
            renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            updateSelectedPlayersDisplay();
            updateSelectedTeamDisplay();
          });
        }
      });
    } else {
      // Creating new player
      chrome.storage.local.get(['players'], (result) => {
        if (handleStorageError(null, 'savePlayerFromModal-create')) {
          return;
        }
        const players = result.players || [];

        // Check if number is already taken by another player in the same team
        const duplicatePlayer = players.find(p => p.number === number && p.team === team);
        if (duplicatePlayer) {
          showErrorModal(`Player number ${number} is already taken by ${duplicatePlayer.fullName || duplicatePlayer.name || 'another player'} in team ${team}. Please choose a different number.`);
          return;
        }

        const newPlayer = {
          id: Date.now().toString(),
          fullName: fullName,
          number: number,
          team: team,
          position: position
        };

        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          if (handleStorageError(null, 'savePlayerFromModal-create-set')) {
            return;
          }
          
          // Automatically add player to selected players
          if (!selectedPlayers.includes(newPlayer.id)) {
            selectedPlayers.push(newPlayer.id);
          }
          
          closePlayerModal();
          const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
          renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
          updateSelectedPlayersDisplay();
        });
      });
    }
  }

  function createNewPlayer() {
    if (!currentAnalysisId) {
      showErrorModal('Please select or create a project first.');
      return;
    }
    
    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      if (handleStorageError(null, 'createNewPlayer')) {
        return;
      }
      
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];
      
      // Get teams that are attached to this project
      let availableTeams = [];
      
      if (attachedTeamIds.length > 0) {
        // Filter global teams by attached IDs
        availableTeams = globalTeams.filter(team => {
          const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
          return attachedTeamIds.includes(teamId);
        });
      }
      
      // Fallback: if no attached teams, check analysis.teams for backward compatibility
      if (availableTeams.length === 0 && analysis && analysis.teams && analysis.teams.length > 0) {
        availableTeams = analysis.teams;
      }
      
      if (availableTeams.length === 0) {
        showErrorModal('Please create at least one team before adding players.');
        return;
      }
      
      openPlayerModal();
    });
  }

  function editPlayer(playerId) {
    openPlayerModal(playerId);
  }


  function deletePlayer(playerId) {
    chrome.storage.local.get(['players'], (result) => {
      if (handleStorageError(null, 'deletePlayer')) {
        return;
      }
      
      const players = result.players || [];
      const playerToDelete = players.find(p => p.id === playerId);
      if (!playerToDelete) return;
      
      const displayText = playerToDelete.number ? 
        `#${playerToDelete.number} ${playerToDelete.fullName || ''}`.trim() : 
        (playerToDelete.fullName || 'Unnamed');
      
      showDeleteConfirmModal(`Are you sure you want to delete player "${displayText}"?`, () => {
        const updatedPlayers = players.filter(p => p.id !== playerId);
        chrome.storage.local.set({ players: updatedPlayers }, () => {
          if (handleStorageError(null, 'deletePlayer-set')) {
            return;
          }
          selectedPlayers = selectedPlayers.filter(id => id !== playerId);
          const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
          renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
          updateSelectedPlayersDisplay();
          updateSelectedTeamDisplay();
        });
      });
    });
  }

  function removePlayerFromTeam(playerId) {
    chrome.storage.local.get(['players'], (result) => {
      if (handleStorageError(null, 'removePlayerFromTeam')) {
        return;
      }
      
      const players = result.players || [];
      const player = players.find(p => p.id === playerId);
      if (!player) return;
      
      player.team = '';
      chrome.storage.local.set({ players: players }, () => {
        if (handleStorageError(null, 'removePlayerFromTeam-set')) {
          return;
        }
        const playerSearchInput = document.getElementById('distatsPlayerSearchInput');
        renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        updateSelectedPlayersDisplay();
        updateSelectedTeamDisplay();
      });
    });
  }

  // Create new analysis (with prompt - for manual creation)
  function createNewAnalysis(callback) {
    const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
    const videoTitle = getVideoTitle();
    const defaultName = videoTitle && videoTitle !== `${platform} Video`
      ? `${videoTitle} - ${new Date().toLocaleDateString()}`
      : `${platformName} Analysis - ${new Date().toLocaleDateString()}`;
    
    const analysisName = prompt('Enter analysis name:', defaultName);

    if (!analysisName || analysisName.trim() === '') {
      return;
    }
    
    // Ensure we have the current video URL
    if (!currentVideoUrl) {
      currentVideoUrl = window.location.href;
    }

    const analysisId = 'analysis_' + Date.now();
    const date = new Date();

    const newAnalysis = {
      id: analysisId,
      name: analysisName.trim(),
      date: date.toLocaleDateString(),
      videoId: currentVideoId,
      videoUrl: currentVideoUrl || window.location.href,
      videoTitle: getVideoTitle(),
      platform: platform,
      videos: [{
        videoId: currentVideoId,
        videoUrl: currentVideoUrl || window.location.href,
        videoTitle: getVideoTitle(),
        platform: platform,
        addedAt: Date.now()
      }],
      notes: [],
      teams: [], // Initialize teams array
      createdAt: Date.now()
    };

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'createNewAnalysis')) {
          return;
        }

        const analyses = result.analyses || [];
        analyses.push(newAnalysis);

        chrome.storage.local.set({
          analyses: analyses,
          currentAnalysisId: analysisId
        }, () => {
          if (handleStorageError(null, 'createNewAnalysis-set')) {
            return;
          }
          currentAnalysisId = analysisId;
          if (callback) callback();
        });
      });
    } catch (e) {
      handleStorageError(e, 'createNewAnalysis');
    }
  }

  // Add note to current analysis
  async function addNoteToAnalysis(content, imageData = null) {
    // Normalize imageData to array
    let imagesArray = null;
    if (imageData) {
      if (Array.isArray(imageData)) {
        imagesArray = imageData;
      } else {
        imagesArray = [imageData];
      }
    }
    if (!currentAnalysisId) {
      console.error('No current analysis');
      return;
    }

    // Get current video time and format as timecode
    // For Dailymotion, the video might not be ready immediately, so we'll try multiple times
    let videoTime = getCurrentVideoTime();
    
    // If Dailymotion and no time found, wait a bit and retry (video might be loading)
    // Use Promise-based approach instead of async/await
    const getVideoTimePromise = new Promise((resolve) => {
      if (platform === 'dailymotion' && (videoTime === null || videoTime === undefined)) {
        // Try a few times with short delays
        let attempt = 0;
        const tryGetTime = () => {
          videoTime = getCurrentVideoTime();
          if (videoTime !== null && videoTime !== undefined) {
            resolve(videoTime);
          } else if (attempt < 3) {
            attempt++;
            setTimeout(tryGetTime, 200);
          } else {
            resolve(null);
          }
        };
        tryGetTime();
      } else {
        resolve(videoTime);
      }
    });
    
    return getVideoTimePromise.then((finalVideoTime) => {
      videoTime = finalVideoTime;
    
      const timecode = videoTime !== null && videoTime !== undefined 
        ? formatTimecode(videoTime) 
        : null;

      // Check if content is HTML (has [HTML_CONTENT] tags) - don't add timecode prefix for HTML
      const isHtmlContent = content && content.includes('[HTML_CONTENT]') && content.includes('[/HTML_CONTENT]');
      let noteContent;
      if (isHtmlContent) {
        // For HTML content, don't add timecode prefix - keep as-is
        noteContent = content;
      } else {
        // Include timecode in note content if available
        noteContent = timecode 
          ? `[${timecode}] ${content || ''}`
          : (content || '');
      }

      if (!isExtensionContextValid()) {
        alert('Extension context invalidated. Please reload the page.');
        return Promise.reject(new Error('Extension context invalidated'));
      }

      return new Promise((resolve, reject) => {
        chrome.storage.local.get(['analyses'], (result) => {
          if (handleStorageError(null, 'addNoteToAnalysis')) {
            reject(new Error('Failed to get analyses'));
            return;
          }

          const analyses = result.analyses || [];
          const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

          if (analysisIndex !== -1) {
          // Store which video this note belongs to (only if on a video page)
          const currentPagePlatform = platform || detectPlatform();
          let noteVideoUrl = null;
          let noteVideoId = null;
          let notePlatform = null;
          
          // Only set video info if we're actually on a video page (check for video ID)
          if (currentPagePlatform !== 'unknown') {
            // ALWAYS refresh currentVideoId and currentVideoUrl from the current page
            // This ensures we get the correct video even if user switched tabs
            getCurrentVideoId(); // This will update both currentVideoId and currentVideoUrl
            
            // Force refresh from current page
            const currentPageUrl = window.location.href;
            
            // Get fresh video ID from current page
            let freshVideoId = null;
            if (currentPagePlatform === 'youtube') {
              const urlParams = new URLSearchParams(new URL(currentPageUrl).search);
              freshVideoId = urlParams.get('v');
            } else if (currentPagePlatform === 'dailymotion') {
              const match = currentPageUrl.match(/dailymotion\.com\/video\/([^/?]+)/);
              freshVideoId = match ? match[1] : null;
            } else if (currentPagePlatform === 'twitch') {
              const match = currentPageUrl.match(/twitch\.tv\/videos\/(\d+)/);
              freshVideoId = match ? match[1] : null;
            }
            
            // Only set video info if we actually have a video ID (i.e., we're on a video page)
            const actualVideoId = freshVideoId || currentVideoId;
            if (actualVideoId) {
              noteVideoUrl = currentPageUrl;
              noteVideoId = actualVideoId;
              notePlatform = currentPagePlatform;
            }
            // If no video ID found, leave all as null (not on a video page)
          }
          
          
          // Get video title - try from videos array first, then from current page, then fallback
          let noteVideoTitle = null;
          const analysis = analyses[analysisIndex];
          
          // Only try to find video if we have video info (i.e., we're on a video page)
          if (noteVideoUrl && notePlatform) {
            // Try to find video in videos array - use more robust matching
            if (analysis.videos && analysis.videos.length > 0) {
              // Normalize URLs for comparison
              const normalizeUrlForMatch = (url) => {
                try {
                  const urlObj = new URL(url);
                  urlObj.hash = '';
                  urlObj.searchParams.delete('t');
                  urlObj.searchParams.delete('start');
                  return urlObj.toString();
                } catch {
                  return url.split('#')[0].split('?')[0];
                }
              };
              
              const normalizedNoteUrl = normalizeUrlForMatch(noteVideoUrl);
              
              const matchingVideo = analysis.videos.find(v => {
                if (!v) return false;
                
                // CRITICAL: Platform must match first to avoid cross-platform mismatches
                if (v.platform !== notePlatform) {
                  return false; // Don't match videos from different platforms
                }
                
                // Try URL match first (most reliable)
                if (v.videoUrl) {
                  const normalizedVideoUrl = normalizeUrlForMatch(v.videoUrl);
                  if (normalizedVideoUrl === normalizedNoteUrl) {
                    return true;
                  }
                }
                
                // Try ID + platform match (platform already checked above)
                if (v.videoId && noteVideoId && v.videoId === noteVideoId) {
                  return true;
                }
                
                return false;
              });
              
              if (matchingVideo && matchingVideo.videoTitle) {
                noteVideoTitle = matchingVideo.videoTitle;
              }
            }
          }
          
          // If not found in videos array and we're on a video page, try to get from current page
          if (!noteVideoTitle && notePlatform && notePlatform !== 'unknown') {
            noteVideoTitle = getVideoTitle();
            
            // If it's just a generic title, DON'T fall back to analysis.videoTitle
            // because that might be from a different video (e.g., YouTube when we're on Twitch)
            // Only use a generic platform name
            if (noteVideoTitle === `${notePlatform} Video` || noteVideoTitle === 'Video') {
              const platformName = notePlatform.charAt(0).toUpperCase() + notePlatform.slice(1);
              noteVideoTitle = `${platformName} Video`;
            }
          }
          
          // If we're not on a video page, don't set videoTitle at all (leave it null)
          
          // Get selected events (already stored in selectedEvents array)
          const eventsToSave = selectedEvents.length > 0 ? [...selectedEvents] : null;

          // Get selected zones (already stored in selectedZones array)
          const zonesToSave = selectedZones.length > 0 ? [...selectedZones] : null;

          // Get selected players
          const playersToSave = selectedPlayers.length > 0 ? [...selectedPlayers] : null;

          // Get selected intensity
          const intensityToSave = selectedIntensity !== null ? selectedIntensity : null;

          // Collect all teams: manually selected teams + teams from players
          const processNoteSave = () => {
            chrome.storage.local.get(['players'], (playerResult) => {
              if (handleStorageError(null, 'addNoteToAnalysis-getPlayers')) {
                processNoteSave();
                return;
              }
              
              const players = playerResult.players || [];
              const selectedPlayerObjects = playersToSave ? players.filter(p => playersToSave.includes(p.id)) : [];
              const teamsFromPlayers = [...new Set(selectedPlayerObjects.map(p => p.team).filter(t => t && t.trim() !== ''))];
              
              // Combine all teams
              const allTeams = new Set();
              if (selectedTeam) allTeams.add(selectedTeam);
              selectedTeams.forEach(team => allTeams.add(team));
              teamsFromPlayers.forEach(team => allTeams.add(team));
              
              const teamsToSave = allTeams.size > 0 ? Array.from(allTeams) : null;
              
              // Check if content is HTML (has [HTML_CONTENT] tags)
              const isHtmlContent = noteContent && noteContent.includes('[HTML_CONTENT]') && noteContent.includes('[/HTML_CONTENT]');
              let finalContent = noteContent;
              if (isHtmlContent) {
                // Extract HTML content between tags
                const htmlMatch = noteContent.match(/\[HTML_CONTENT\](.*?)\[\/HTML_CONTENT\]/s);
                if (htmlMatch) {
                  finalContent = htmlMatch[1];
                }
              }
              
              const noteData = {
            id: `note_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // Unique ID for editing
            content: finalContent, // Save with timecode in content (or HTML if HTML_CONTENT)
            text: finalContent,     // Also save as 'text' for popup compatibility
            timestamp: Date.now(),
            videoTime: videoTime,   // Also save raw time for seeking
            videoUrl: noteVideoUrl, // Store which video this note belongs to
            videoId: noteVideoId,   // Store video ID for matching
            platform: notePlatform, // Store platform for matching (use detected platform)
            videoTitle: noteVideoTitle, // Store video title for display
            teams: teamsToSave, // Store teams array (null if no teams selected)
            team: teamsToSave && teamsToSave.length > 0 ? teamsToSave[0] : null, // Keep single team for backward compatibility
            events: eventsToSave, // Store events array (null if no events selected)
            zones: zonesToSave, // Store zones array (null if no zones selected)
            players: playersToSave, // Store players array (null if no players selected)
            intensity: intensityToSave, // Store intensity (0-4, null if not selected)
            isHtmlContent: isHtmlContent // Flag to indicate HTML content
          };
          
          // Add images if present (store as array)
          if (imagesArray && imagesArray.length > 0) {
            // Validate all images before storing
            const validImages = imagesArray.filter(img => {
              if (!img) return false;
              const isValid = typeof img === 'string' && 
                (img.startsWith('data:image/') || img.startsWith('blob:'));
              if (!isValid) {
                console.warn('Skipping invalid image data in sidebar:', typeof img, img ? img.substring(0, 50) : 'null');
              }
              return isValid;
            });
            
            if (validImages.length > 0) {
              noteData.images = validImages;
              // Also keep single image for backward compatibility
              noteData.image = validImages[0];
            } else {
              console.error('No valid images to store in sidebar');
            }
          }
          
          analyses[analysisIndex].notes.push(noteData);

          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'addNoteToAnalysis-set')) {
              reject(new Error('Failed to save note'));
              return;
            }
            updateNotesDisplay();
            
            // Clear selected teams after saving
            selectedTeams = [];
            
            resolve();
          });
          });
          };
          
          processNoteSave();
        } else {
          reject(new Error('Analysis not found'));
        }
      });
      });
    }).catch((e) => {
      handleStorageError(e, 'addNoteToAnalysis');
      throw e; // Re-throw to allow addNote to handle it
    });
  }

  // Delete confirmation modal management
  let pendingDeleteAction = null;

  function showDeleteConfirmModal(message, onConfirm) {
    const deleteConfirmModal = document.getElementById('distatsDeleteConfirmModal');
    const deleteConfirmMessage = document.getElementById('distatsDeleteConfirmMessage');
    
    if (!deleteConfirmModal || !deleteConfirmMessage) {
      console.error('Delete confirmation modal elements not found');
      // Fallback to system confirm
      if (confirm(message)) {
        onConfirm();
      }
      return;
    }
    
    deleteConfirmMessage.textContent = message;
    pendingDeleteAction = onConfirm;
    deleteConfirmModal.classList.remove('hidden');
  }

  function closeDeleteConfirmModal() {
    const deleteConfirmModal = document.getElementById('distatsDeleteConfirmModal');
    if (deleteConfirmModal) {
      deleteConfirmModal.classList.add('hidden');
      pendingDeleteAction = null;
    }
  }

  function confirmDelete() {
    if (pendingDeleteAction) {
      pendingDeleteAction();
      closeDeleteConfirmModal();
    }
  }


  // Delete a note in sidebar
  function deleteNoteIn(noteElement, note) {
    if (!currentAnalysisId || !note || !note.timestamp) {
      console.warn('Cannot delete: missing analysis ID or note timestamp');
      return;
    }
    
    if (!isExtensionContextValid()) {
      showErrorModal('Extension context invalidated. Please reload the page.');
      return;
    }
    
    showDeleteConfirmModal('Are you sure you want to delete this note?', () => {
    chrome.storage.local.get(['analyses'], (result) => {
      if (handleStorageError(null, 'deleteNoteIn')) {
        return;
      }
      
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
      
      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        // Find and remove the note by timestamp
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === note.timestamp);
        
        if (noteIndex !== -1) {
          analysis.notes.splice(noteIndex, 1);
          
          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'deleteNoteIn-set')) {
              return;
            }
            // Remove note from DOM
            noteElement.remove();
            // Update notes display in case list is now empty
            if (analysis.notes.length === 0) {
              updateNotesDisplay();
            }
          });
        }
      }
      });
    });
  }

  // Edit a note in sidebar
  function editNoteIn(noteElement, note) {
    if (!currentAnalysisId || !note || !note.timestamp) {
      console.warn('Cannot edit: missing analysis ID or note timestamp');
      return;
    }
    
    // Find the content element
    const contentElement = noteElement.querySelector('.content');
    if (!contentElement) {
      return;
    }
    
    // Get the original text from note (most reliable source)
    // If both exist and are the same, use only one to avoid duplication
    let originalText = '';
    if (note.text && note.content) {
      // Both exist - use text if they're different, otherwise use text (avoid duplication)
      originalText = note.text.trim();
      // If content is different and longer, it might be the updated version
      if (note.content.trim() !== note.text.trim() && note.content.trim().length > note.text.trim().length) {
        originalText = note.content.trim();
      }
    } else {
      originalText = (note.text || note.content || '').trim();
    }
    
    // Check for duplicate text within the message itself
    if (originalText.length > 0) {
      const messageLength = originalText.length;
      const halfLength = Math.floor(messageLength / 2);
      const firstHalf = originalText.substring(0, halfLength);
      const secondHalf = originalText.substring(halfLength);
      // Check if message is exactly duplicated (first half == second half)
      if (firstHalf === secondHalf && messageLength % 2 === 0) {
        console.warn('Detected duplicated message text when editing, using only first half');
        originalText = firstHalf;
      }
    }
    
    // Remove timecode pattern [HH:MM:SS] or [MM:SS] from the beginning for editing
    // But keep the rest of the text intact
    const currentText = originalText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
    
    startEditingNoteIn(contentElement, noteElement, note, currentText);
  }

  // Start editing mode in sidebar
  function startEditingNoteIn(contentElement, noteElement, note, currentText) {
    // Hide existing attribute displays while editing
    const teamElement = noteElement.querySelector('.message-team');
    const eventsElement = noteElement.querySelector('.message-events');
    const zonesElement = noteElement.querySelector('.message-zones');
    const intensityElement = noteElement.querySelector('.message-intensity');
    if (teamElement) teamElement.style.display = 'none';
    if (eventsElement) eventsElement.style.display = 'none';
    if (zonesElement) zonesElement.style.display = 'none';
    if (intensityElement) intensityElement.style.display = 'none';
    
    // Hide existing images while editing (we'll show them in edit mode with controls)
    const imageContainers = noteElement.querySelectorAll('.message-image-container');
    imageContainers.forEach(container => {
      container.style.display = 'none';
    });
    
    // Create textarea for editing
    const textarea = document.createElement('textarea');
    textarea.className = 'distats-note-edit-input';
    textarea.value = currentText;
    textarea.rows = Math.max(3, currentText.split('\n').length);
    textarea.style.width = '100%';
    textarea.style.padding = '8px';
    textarea.style.border = '2px solid #8DD8F9';
    textarea.style.borderRadius = '4px';
    textarea.style.fontSize = '13px';
    textarea.style.fontFamily = 'inherit';
    textarea.style.background = '#1a1a1a';
    textarea.style.color = '#fff';
    textarea.style.resize = 'vertical';
    textarea.style.marginBottom = '8px';
    
    // Replace content element with textarea
    const parent = contentElement.parentNode;
    parent.replaceChild(textarea, contentElement);
    textarea.focus();
    textarea.select();
    
    // Remove existing edit actions if any
    const existingEditActions = noteElement.querySelector('.distats-note-edit-actions');
    if (existingEditActions) {
      existingEditActions.remove();
    }
    
    // Create edit container for comment properties
    const editContainer = document.createElement('div');
    editContainer.className = 'distats-note-edit-container';
    editContainer.style.marginTop = '12px';
    editContainer.style.paddingTop = '12px';
    editContainer.style.borderTop = '1px solid #30363d';
    
    // Store edited values in noteElement dataset for access during save
    let editSelectedTeam = note.team || null;
    let editSelectedEvents = note.events ? [...note.events] : [];
    let editSelectedZones = note.zones ? [...note.zones] : [];
    // Initialize selected players - convert names to IDs if needed
    let editSelectedPlayers = note.players ? [...note.players] : [];
    
    // IMMEDIATE synchronous deduplication to remove any existing duplicates
    if (editSelectedPlayers.length > 0) {
      const immediateDeduped = [];
      const seenImmediate = new Set();
      editSelectedPlayers.forEach(ref => {
        if (!seenImmediate.has(ref)) {
          seenImmediate.add(ref);
          immediateDeduped.push(ref);
        }
      });
      editSelectedPlayers = immediateDeduped;
    }
    
    // Convert player names to IDs asynchronously and deduplicate
    if (editSelectedPlayers.length > 0) {
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const convertedPlayers = [];
        const seenIds = new Set();
        
        editSelectedPlayers.forEach(playerRef => {
          // Check if it's an ID (starts with 'player_')
          if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
            const player = players.find(p => p.id === playerRef);
            if (player && !seenIds.has(playerRef)) {
              convertedPlayers.push(playerRef);
              seenIds.add(playerRef);
            }
          } else if (typeof playerRef === 'string') {
            // It's a name string - try to find by name and convert to ID
            const playerNameLower = playerRef.toLowerCase().trim();
            // Skip if it looks like message text
            if (playerNameLower.length > 100 || playerNameLower.includes('!') || playerNameLower.includes('?') || playerNameLower.includes('.')) {
              return; // Skip invalid player names
            }
            const matched = players.find(p => {
              const fullName = (p.fullName || '').toLowerCase();
              const name = (p.name || '').toLowerCase();
              const surname = (p.surname || '').toLowerCase();
              return fullName === playerNameLower || 
                     name === playerNameLower || 
                     surname === playerNameLower ||
                     fullName.includes(playerNameLower) ||
                     playerNameLower.includes(fullName);
            });
            if (matched && !seenIds.has(matched.id)) {
              convertedPlayers.push(matched.id);
              seenIds.add(matched.id);
            } else if (!matched && !convertedPlayers.includes(playerRef)) {
              // Keep as-is if not found (will be filtered out in display)
              // Only add if not already in the array
              convertedPlayers.push(playerRef);
            }
          } else if (!convertedPlayers.includes(playerRef)) {
            convertedPlayers.push(playerRef);
          }
        });
        editSelectedPlayers = convertedPlayers;
        // Update display after converting
        updateSelectedPlayersDisplayEdit();
        renderEditPlayers(playersSearchInput.value);
      });
    }
    
    let editSelectedIntensity = note.intensity !== null && note.intensity !== undefined ? note.intensity : null;
    
    // Team selector for editing
    const editTeamContainer = document.createElement('div');
    editTeamContainer.className = 'distats-note-edit-team';
    editTeamContainer.style.marginBottom = '12px';
    editTeamContainer.style.position = 'relative';
    
    const teamLabel = document.createElement('label');
    const teamLabelText = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('sidebar.team') + ':'
      : 'Team:';
    teamLabel.textContent = teamLabelText;
    teamLabel.style.display = 'block';
    teamLabel.style.fontSize = '12px';
    teamLabel.style.color = '#8b949e';
    teamLabel.style.marginBottom = '4px';
    
    // Team selector header with search input and create button
    const teamSelectorHeader = document.createElement('div');
    teamSelectorHeader.style.display = 'flex';
    teamSelectorHeader.style.gap = '4px';
    teamSelectorHeader.style.marginBottom = '4px';
    
    const teamSearchInput = document.createElement('input');
    teamSearchInput.type = 'text';
    teamSearchInput.className = 'distats-note-edit-team-search';
    teamSearchInput.placeholder = 'Search teams...';
    teamSearchInput.style.flex = '1';
    teamSearchInput.style.padding = '6px 10px';
    teamSearchInput.style.background = '#161b22';
    teamSearchInput.style.border = '1px solid #30363d';
    teamSearchInput.style.borderRadius = '6px';
    teamSearchInput.style.color = '#c9d1d9';
    teamSearchInput.style.fontSize = '13px';
    
    const addTeamBtn = document.createElement('button');
    addTeamBtn.className = 'add-team-btn';
    addTeamBtn.textContent = '+';
    addTeamBtn.title = 'Add new team';
    addTeamBtn.style.width = '32px';
    addTeamBtn.style.height = '32px';
    addTeamBtn.style.padding = '0';
    addTeamBtn.style.background = '#21262d';
    addTeamBtn.style.border = '1px solid #30363d';
    addTeamBtn.style.borderRadius = '6px';
    addTeamBtn.style.color = '#c9d1d9';
    addTeamBtn.style.cursor = 'pointer';
    addTeamBtn.style.fontSize = '16px';
    addTeamBtn.style.display = 'flex';
    addTeamBtn.style.alignItems = 'center';
    addTeamBtn.style.justifyContent = 'center';
    
    teamSelectorHeader.appendChild(teamSearchInput);
    teamSelectorHeader.appendChild(addTeamBtn);
    
    // Team dropdown
    const teamDropdown = document.createElement('div');
    teamDropdown.className = 'distats-note-edit-team-dropdown';
    teamDropdown.style.display = 'none';
    teamDropdown.style.position = 'absolute';
    teamDropdown.style.top = '100%';
    teamDropdown.style.left = '0';
    teamDropdown.style.right = '0';
    teamDropdown.style.background = '#161b22';
    teamDropdown.style.border = '1px solid #30363d';
    teamDropdown.style.borderRadius = '6px';
    teamDropdown.style.maxHeight = '200px';
    teamDropdown.style.overflowY = 'auto';
    teamDropdown.style.zIndex = '1000';
    teamDropdown.style.marginTop = '4px';
    teamDropdown.style.boxShadow = '0 8px 24px rgba(0,0,0,0.3)';
    
    const teamList = document.createElement('div');
    teamList.className = 'distats-note-edit-team-list';
    teamDropdown.appendChild(teamList);
    
    // Display currently selected team
    const selectedTeamDisplay = document.createElement('div');
    selectedTeamDisplay.className = 'distats-note-edit-selected-team';
    selectedTeamDisplay.style.marginTop = '4px';
    selectedTeamDisplay.style.fontSize = '12px';
    selectedTeamDisplay.style.color = '#8b949e';
    
    const updateSelectedTeamDisplay = () => {
      selectedTeamDisplay.innerHTML = '';
      if (editSelectedTeam) {
        const tag = document.createElement('span');
        tag.style.display = 'inline-flex';
        tag.style.alignItems = 'center';
        tag.style.gap = '4px';
        tag.style.background = '#21262d';
        tag.style.border = '1px solid #30363d';
        tag.style.borderRadius = '4px';
        tag.style.padding = '2px 6px';
        
        const teamNameSpan = document.createElement('span');
        teamNameSpan.textContent = editSelectedTeam;
        tag.appendChild(teamNameSpan);
        
        const removeBtn = document.createElement('span');
        removeBtn.textContent = '×';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.color = '#8b949e';
        removeBtn.style.fontSize = '14px';
        removeBtn.style.lineHeight = '1';
        removeBtn.style.marginLeft = '4px';
        removeBtn.title = 'Remove team';
        removeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          editSelectedTeam = null;
          noteElement.dataset.editTeam = '';
          updateSelectedTeamDisplay();
        });
        
        tag.appendChild(removeBtn);
        selectedTeamDisplay.appendChild(tag);
      }
    };
    updateSelectedTeamDisplay();
    
    // Render team selector function
    const renderEditTeamSelector = (searchQuery = '') => {
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        // Use global teams storage, fallback to analysis.teams for backward compatibility
        const globalTeams = result.teams || [];
        const analysisTeams = analysis ? (analysis.teams || []) : [];
        // Merge global teams with analysis teams (global takes precedence)
        const teamsMap = new Map();
        // First add analysis teams (for backward compatibility)
        analysisTeams.forEach(team => {
          const teamName = getTeamName(team);
          if (teamName) teamsMap.set(teamName.toLowerCase(), team);
        });
        // Then add global teams (overwrites duplicates)
        globalTeams.forEach(team => {
          const teamName = typeof team === 'string' ? team : (team.name || '');
          if (teamName) teamsMap.set(teamName.toLowerCase(), team);
        });
        const teams = Array.from(teamsMap.values());
        
        // Filter teams by search query
        const filteredTeams = teams.filter(team => {
          const searchLower = searchQuery.toLowerCase();
          const teamName = getTeamName(team);
          return teamName.toLowerCase().includes(searchLower);
        });
        
        teamList.innerHTML = '';
        
        // Add "No team" option
        const noTeamItem = document.createElement('div');
        noTeamItem.style.display = 'flex';
        noTeamItem.style.alignItems = 'center';
        noTeamItem.style.padding = '4px 8px';
        noTeamItem.style.cursor = 'pointer';
        noTeamItem.style.borderRadius = '4px';
        
        noTeamItem.addEventListener('mouseenter', () => {
          noTeamItem.style.background = '#21262d';
        });
        noTeamItem.addEventListener('mouseleave', () => {
          noTeamItem.style.background = 'transparent';
        });
        
        const noTeamLabel = document.createElement('label');
        noTeamLabel.style.flex = '1';
        noTeamLabel.style.cursor = 'pointer';
        noTeamLabel.style.fontSize = '13px';
        noTeamLabel.style.color = editSelectedTeam === null ? '#1f6feb' : '#c9d1d9';
        noTeamLabel.style.fontWeight = editSelectedTeam === null ? '500' : 'normal';
        noTeamLabel.textContent = 'No team';
        
        noTeamLabel.addEventListener('click', () => {
          editSelectedTeam = null;
          noteElement.dataset.editTeam = '';
          updateSelectedTeamDisplay();
          renderEditTeamSelector(teamSearchInput.value);
        });
        
        noTeamItem.appendChild(noTeamLabel);
        teamList.appendChild(noTeamItem);
        
        if (filteredTeams.length === 0 && searchQuery) {
          const emptyMsg = document.createElement('div');
          emptyMsg.style.padding = '10px';
          emptyMsg.style.color = '#8b949e';
          emptyMsg.style.textAlign = 'center';
          emptyMsg.textContent = 'No teams found';
          teamList.appendChild(emptyMsg);
          return;
        }
        
        filteredTeams.forEach(team => {
          const teamName = getTeamName(team);
          
          const teamItem = document.createElement('div');
          teamItem.style.display = 'flex';
          teamItem.style.alignItems = 'center';
          teamItem.style.padding = '4px 8px';
          teamItem.style.cursor = 'pointer';
          teamItem.style.borderRadius = '4px';
          
          teamItem.addEventListener('mouseenter', () => {
            teamItem.style.background = '#21262d';
          });
          teamItem.addEventListener('mouseleave', () => {
            teamItem.style.background = 'transparent';
          });
          
          const label = document.createElement('label');
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = editSelectedTeam === teamName ? '#1f6feb' : '#c9d1d9';
          label.style.fontWeight = editSelectedTeam === teamName ? '500' : 'normal';
          label.textContent = teamName;
          
          label.addEventListener('click', () => {
            editSelectedTeam = teamName;
            noteElement.dataset.editTeam = teamName;
            updateSelectedTeamDisplay();
            renderEditTeamSelector(teamSearchInput.value);
            teamDropdown.style.display = 'none';
          });
          
          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit team';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            renameSelectedTeam(teamName);
            // Refresh the selector after editing
            setTimeout(() => {
              renderEditTeamSelector(teamSearchInput.value);
            }, 500);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete team';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            if (confirm(`Are you sure you want to delete the team "${teamName}"? This will remove it from all projects and notes.`)) {
              deleteSelectedTeam(teamName);
              // Refresh the selector after deletion
              setTimeout(() => {
                renderEditTeamSelector(teamSearchInput.value);
                // Clear selection if deleted team was selected
                if (editSelectedTeam === teamName) {
                  editSelectedTeam = null;
                  noteElement.dataset.editTeam = '';
                  updateSelectedTeamDisplay();
                }
                // Keep dropdown open
                teamDropdown.style.display = 'block';
              }, 500);
            }
          });
          
          teamItem.appendChild(label);
          teamItem.appendChild(editBtn);
          teamItem.appendChild(deleteBtn);
          teamList.appendChild(teamItem);
        });
      });
    };
    
    // Event listeners for team selector
    teamSearchInput.addEventListener('focus', () => {
      teamDropdown.style.display = 'block';
      renderEditTeamSelector(teamSearchInput.value);
    });
    
    teamSearchInput.addEventListener('input', (e) => {
      renderEditTeamSelector(e.target.value);
    });
    
    teamSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!teamDropdown.matches(':hover') && document.activeElement !== teamSearchInput) {
          teamDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    teamDropdown.addEventListener('mouseenter', () => {
      teamDropdown.style.display = 'block';
    });
    
    teamDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== teamSearchInput) {
        teamDropdown.style.display = 'none';
      }
    });
    
    // Create team button handler
    addTeamBtn.addEventListener('click', () => {
      createNewTeam();
      // Listen for team creation completion
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['analyses'], (result) => {
          const analyses = result.analyses || [];
          const analysis = analyses.find(a => a.id === currentAnalysisId);
          const teams = analysis ? (analysis.teams || []) : [];
          // If teams count increased, refresh
          if (teams.length > (window.lastTeamCount || 0)) {
            window.lastTeamCount = teams.length;
            renderEditTeamSelector(teamSearchInput.value);
            teamDropdown.style.display = 'block';
          }
        });
      }, 500);
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    editTeamContainer.appendChild(teamLabel);
    editTeamContainer.appendChild(teamSelectorHeader);
    editTeamContainer.appendChild(selectedTeamDisplay);
    editTeamContainer.appendChild(teamDropdown);
    editContainer.appendChild(editTeamContainer);
    
    // Initial render
    renderEditTeamSelector('');
    
    // Events selector for editing (simplified - using same structure as popup)
    const editEventsContainer = document.createElement('div');
    editEventsContainer.className = 'distats-note-edit-events';
    editEventsContainer.style.marginBottom = '12px';
    editEventsContainer.style.position = 'relative';
    
    const eventsLabel = document.createElement('label');
    eventsLabel.textContent = 'Events:';
    eventsLabel.style.display = 'block';
    eventsLabel.style.fontSize = '12px';
    eventsLabel.style.color = '#8b949e';
    eventsLabel.style.marginBottom = '4px';
    
    // Event selector header with search input and create button
    const eventSelectorHeader = document.createElement('div');
    eventSelectorHeader.style.display = 'flex';
    eventSelectorHeader.style.gap = '4px';
    eventSelectorHeader.style.marginBottom = '4px';
    
    const eventsSearchInput = document.createElement('input');
    eventsSearchInput.type = 'text';
    eventsSearchInput.className = 'distats-note-edit-events-search';
    eventsSearchInput.placeholder = 'Search events...';
    eventsSearchInput.style.flex = '1';
    eventsSearchInput.style.padding = '6px 10px';
    eventsSearchInput.style.background = '#161b22';
    eventsSearchInput.style.border = '1px solid #30363d';
    eventsSearchInput.style.borderRadius = '6px';
    eventsSearchInput.style.color = '#c9d1d9';
    eventsSearchInput.style.fontSize = '13px';
    
    const addEventBtn = document.createElement('button');
    addEventBtn.className = 'add-custom-event-btn';
    addEventBtn.textContent = '+';
    addEventBtn.title = 'Add custom event';
    addEventBtn.style.width = '32px';
    addEventBtn.style.height = '32px';
    addEventBtn.style.padding = '0';
    addEventBtn.style.background = '#21262d';
    addEventBtn.style.border = '1px solid #30363d';
    addEventBtn.style.borderRadius = '6px';
    addEventBtn.style.color = '#c9d1d9';
    addEventBtn.style.cursor = 'pointer';
    addEventBtn.style.fontSize = '16px';
    addEventBtn.style.display = 'flex';
    addEventBtn.style.alignItems = 'center';
    addEventBtn.style.justifyContent = 'center';
    
    eventSelectorHeader.appendChild(eventsSearchInput);
    eventSelectorHeader.appendChild(addEventBtn);
    
    const eventsDropdown = document.createElement('div');
    eventsDropdown.className = 'distats-note-edit-events-dropdown';
    eventsDropdown.style.display = 'none';
    eventsDropdown.style.maxHeight = '200px';
    eventsDropdown.style.overflowY = 'auto';
    eventsDropdown.style.background = '#161b22';
    eventsDropdown.style.border = '1px solid #30363d';
    eventsDropdown.style.borderRadius = '6px';
    eventsDropdown.style.padding = '8px';
    eventsDropdown.style.marginTop = '4px';
    eventsDropdown.style.position = 'relative';
    eventsDropdown.style.zIndex = '1000';
    
    const selectedEventsDisplay = document.createElement('div');
    selectedEventsDisplay.className = 'distats-note-edit-selected-events';
    selectedEventsDisplay.style.marginTop = '4px';
    selectedEventsDisplay.style.marginBottom = '4px';
    selectedEventsDisplay.style.fontSize = '12px';
    selectedEventsDisplay.style.color = '#8b949e';
    
    const updateSelectedEventsDisplay = () => {
      selectedEventsDisplay.innerHTML = '';
      if (editSelectedEvents.length > 0) {
        const label = document.createElement('span');
        label.textContent = 'Selected: ';
        label.style.fontWeight = '500';
        selectedEventsDisplay.appendChild(label);
        editSelectedEvents.forEach(event => {
          const tag = document.createElement('span');
          tag.textContent = event;
          tag.style.background = '#21262d';
          tag.style.border = '1px solid #30363d';
          tag.style.borderRadius = '4px';
          tag.style.padding = '2px 6px';
          tag.style.marginLeft = '4px';
          tag.style.cursor = 'pointer';
          tag.style.display = 'inline-flex';
          tag.style.alignItems = 'center';
          tag.style.gap = '4px';
          tag.title = 'Click to remove';
          
          const removeBtn = document.createElement('span');
          removeBtn.textContent = '×';
          removeBtn.style.color = '#8b949e';
          removeBtn.style.fontSize = '14px';
          removeBtn.style.lineHeight = '1';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.cursor = 'pointer';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editSelectedEvents = editSelectedEvents.filter(e => e !== event);
            updateSelectedEventsDisplay();
            renderEditEvents(eventsSearchInput.value);
          });
          
          tag.appendChild(removeBtn);
          selectedEventsDisplay.appendChild(tag);
        });
      }
    };
    updateSelectedEventsDisplay();
    
    const renderEditEvents = (searchTerm = '') => {
      eventsDropdown.innerHTML = '';
      const searchLower = searchTerm.toLowerCase().trim();
      
      EVENT_CATEGORIES.forEach(category => {
        const filteredEvents = searchTerm
          ? category.events.filter(event => event.toLowerCase().includes(searchLower))
          : category.events;
        
        if (searchTerm && filteredEvents.length === 0) return;
        
        const categoryDiv = document.createElement('div');
        categoryDiv.style.marginBottom = '12px';
        
        const categoryName = document.createElement('div');
        categoryName.textContent = category.name;
        categoryName.style.fontSize = '11px';
        categoryName.style.fontWeight = '600';
        categoryName.style.color = '#8b949e';
        categoryName.style.textTransform = 'uppercase';
        categoryName.style.marginBottom = '4px';
        categoryDiv.appendChild(categoryName);
        
        filteredEvents.forEach(event => {
          const eventItem = document.createElement('div');
          eventItem.style.display = 'flex';
          eventItem.style.alignItems = 'center';
          eventItem.style.gap = '8px';
          eventItem.style.padding = '4px 0';
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = event;
          checkbox.checked = editSelectedEvents.includes(event);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!editSelectedEvents.includes(event)) {
                editSelectedEvents.push(event);
              }
            } else {
              editSelectedEvents = editSelectedEvents.filter(e => e !== event);
            }
            updateSelectedEventsDisplay();
          });
          
          const label = document.createElement('label');
          label.textContent = translateEventName(event);
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          label.style.cursor = 'pointer';
          label.style.flex = '1';
          
          eventItem.appendChild(checkbox);
          eventItem.appendChild(label);
          categoryDiv.appendChild(eventItem);
        });
        
        eventsDropdown.appendChild(categoryDiv);
      });
    };
    
    eventsSearchInput.addEventListener('focus', () => {
      eventsDropdown.style.display = 'block';
      renderEditEvents(eventsSearchInput.value);
    });
    
    eventsSearchInput.addEventListener('input', (e) => {
      renderEditEvents(e.target.value);
    });
    
    eventsSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!eventsDropdown.matches(':hover') && document.activeElement !== eventsSearchInput) {
          eventsDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    eventsDropdown.addEventListener('mouseenter', () => {
      eventsDropdown.style.display = 'block';
    });
    
    eventsDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== eventsSearchInput) {
        eventsDropdown.style.display = 'none';
      }
    });
    
    // Create event button handler
    addEventBtn.addEventListener('click', () => {
      addCustomEvent();
      // Listen for event creation completion
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['customEvents'], (result) => {
          const customEvents = result.customEvents || [];
          // If events count increased, refresh
          if (customEvents.length > (window.lastEventCount || 0)) {
            window.lastEventCount = customEvents.length;
            renderEditEvents(eventsSearchInput.value);
            eventsDropdown.style.display = 'block';
          }
        });
      }, 500);
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    renderEditEvents();
    
    editEventsContainer.appendChild(eventsLabel);
    editEventsContainer.appendChild(eventSelectorHeader);
    editEventsContainer.appendChild(selectedEventsDisplay);
    editEventsContainer.appendChild(eventsDropdown);
    editContainer.appendChild(editEventsContainer);
    
    // Zones selector for editing (simplified)
    const editZonesContainer = document.createElement('div');
    editZonesContainer.className = 'distats-note-edit-zones';
    editZonesContainer.style.marginBottom = '12px';
    editZonesContainer.style.position = 'relative';
    
    const zonesLabel = document.createElement('label');
    zonesLabel.textContent = 'Zones:';
    zonesLabel.style.display = 'block';
    zonesLabel.style.fontSize = '12px';
    zonesLabel.style.color = '#8b949e';
    zonesLabel.style.marginBottom = '4px';
    
    const zonesSearchInput = document.createElement('input');
    zonesSearchInput.type = 'text';
    zonesSearchInput.className = 'distats-note-edit-zones-search';
    zonesSearchInput.placeholder = 'Search zones...';
    zonesSearchInput.style.width = '100%';
    zonesSearchInput.style.padding = '6px 10px';
    zonesSearchInput.style.background = '#161b22';
    zonesSearchInput.style.border = '1px solid #30363d';
    zonesSearchInput.style.borderRadius = '6px';
    zonesSearchInput.style.color = '#c9d1d9';
    zonesSearchInput.style.fontSize = '13px';
    
    const zonesDropdown = document.createElement('div');
    zonesDropdown.className = 'distats-note-edit-zones-dropdown';
    zonesDropdown.style.display = 'none';
    zonesDropdown.style.maxHeight = '200px';
    zonesDropdown.style.overflowY = 'auto';
    zonesDropdown.style.background = '#161b22';
    zonesDropdown.style.border = '1px solid #30363d';
    zonesDropdown.style.borderRadius = '6px';
    zonesDropdown.style.padding = '8px';
    zonesDropdown.style.marginTop = '4px';
    zonesDropdown.style.position = 'relative';
    zonesDropdown.style.zIndex = '1000';
    
    const selectedZonesDisplay = document.createElement('div');
    selectedZonesDisplay.className = 'distats-note-edit-selected-zones';
    selectedZonesDisplay.style.marginTop = '4px';
    selectedZonesDisplay.style.marginBottom = '4px';
    selectedZonesDisplay.style.fontSize = '12px';
    selectedZonesDisplay.style.color = '#8b949e';
    
    const updateSelectedZonesDisplay = () => {
      selectedZonesDisplay.innerHTML = '';
      if (editSelectedZones.length > 0) {
        const label = document.createElement('span');
        label.textContent = 'Selected: ';
        label.style.fontWeight = '500';
        selectedZonesDisplay.appendChild(label);
        const sortedZones = [...editSelectedZones].sort((a, b) => a - b);
        sortedZones.forEach(zone => {
          const tag = document.createElement('span');
          tag.textContent = `Zone ${zone}`;
          tag.style.background = '#21262d';
          tag.style.border = '1px solid #30363d';
          tag.style.borderRadius = '4px';
          tag.style.padding = '2px 6px';
          tag.style.marginLeft = '4px';
          tag.style.cursor = 'pointer';
          tag.style.display = 'inline-flex';
          tag.style.alignItems = 'center';
          tag.style.gap = '4px';
          tag.title = 'Click to remove';
          
          const removeBtn = document.createElement('span');
          removeBtn.textContent = '×';
          removeBtn.style.color = '#8b949e';
          removeBtn.style.fontSize = '14px';
          removeBtn.style.lineHeight = '1';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.cursor = 'pointer';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editSelectedZones = editSelectedZones.filter(z => z !== zone);
            updateSelectedZonesDisplay();
            renderEditZones(zonesSearchInput.value);
          });
          
          tag.appendChild(removeBtn);
          selectedZonesDisplay.appendChild(tag);
        });
      }
    };
    updateSelectedZonesDisplay();
    
    const renderEditZones = (searchTerm = '') => {
      zonesDropdown.innerHTML = '';
      const searchLower = searchTerm.toLowerCase().trim();
      
      ZONES_CATEGORIES.forEach(category => {
        const filteredZones = searchTerm
          ? category.zones.filter(zone => zone.toString().includes(searchLower) || category.name.toLowerCase().includes(searchLower))
          : category.zones;
        
        if (searchTerm && filteredZones.length === 0) return;
        
        const categoryDiv = document.createElement('div');
        categoryDiv.style.marginBottom = '12px';
        
        const categoryName = document.createElement('div');
        categoryName.textContent = category.name;
        categoryName.style.fontSize = '11px';
        categoryName.style.fontWeight = '600';
        categoryName.style.color = '#8b949e';
        categoryName.style.textTransform = 'uppercase';
        categoryName.style.marginBottom = '4px';
        categoryDiv.appendChild(categoryName);
        
        filteredZones.forEach(zoneNumber => {
          const zoneItem = document.createElement('div');
          zoneItem.style.display = 'flex';
          zoneItem.style.alignItems = 'center';
          zoneItem.style.gap = '8px';
          zoneItem.style.padding = '4px 0';
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = zoneNumber;
          checkbox.checked = editSelectedZones.includes(zoneNumber);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!editSelectedZones.includes(zoneNumber)) {
                editSelectedZones.push(zoneNumber);
              }
            } else {
              editSelectedZones = editSelectedZones.filter(z => z !== zoneNumber);
            }
            updateSelectedZonesDisplay();
          });
          
          const label = document.createElement('label');
          label.textContent = `Zone ${zoneNumber}`;
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          label.style.cursor = 'pointer';
          label.style.flex = '1';
          
          zoneItem.appendChild(checkbox);
          zoneItem.appendChild(label);
          categoryDiv.appendChild(zoneItem);
        });
        
        zonesDropdown.appendChild(categoryDiv);
      });
    };
    
    zonesSearchInput.addEventListener('focus', () => {
      zonesDropdown.style.display = 'block';
      renderEditZones(zonesSearchInput.value);
    });
    
    zonesSearchInput.addEventListener('input', (e) => {
      renderEditZones(e.target.value);
    });
    
    zonesSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!zonesDropdown.matches(':hover') && document.activeElement !== zonesSearchInput) {
          zonesDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    zonesDropdown.addEventListener('mouseenter', () => {
      zonesDropdown.style.display = 'block';
    });
    
    zonesDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== zonesSearchInput) {
        zonesDropdown.style.display = 'none';
      }
    });
    
    renderEditZones();
    
    editZonesContainer.appendChild(zonesLabel);
    editZonesContainer.appendChild(zonesSearchInput);
    editZonesContainer.appendChild(selectedZonesDisplay);
    editZonesContainer.appendChild(zonesDropdown);
    editContainer.appendChild(editZonesContainer);
    
    // Players selector for editing (simplified - will need to load from storage)
    const editPlayersContainer = document.createElement('div');
    editPlayersContainer.className = 'distats-note-edit-players';
    editPlayersContainer.style.marginBottom = '12px';
    editPlayersContainer.style.position = 'relative';
    
    const playersLabel = document.createElement('label');
    playersLabel.textContent = 'Players:';
    playersLabel.style.display = 'block';
    playersLabel.style.fontSize = '12px';
    playersLabel.style.color = '#8b949e';
    playersLabel.style.marginBottom = '4px';
    
    // Player selector header with search input and create button
    const playerSelectorHeader = document.createElement('div');
    playerSelectorHeader.style.display = 'flex';
    playerSelectorHeader.style.gap = '4px';
    playerSelectorHeader.style.marginBottom = '4px';
    
    const playersSearchInput = document.createElement('input');
    playersSearchInput.type = 'text';
    playersSearchInput.className = 'distats-note-edit-players-search';
    playersSearchInput.placeholder = 'Search players...';
    playersSearchInput.style.flex = '1';
    playersSearchInput.style.padding = '6px 10px';
    playersSearchInput.style.background = '#161b22';
    playersSearchInput.style.border = '1px solid #30363d';
    playersSearchInput.style.borderRadius = '6px';
    playersSearchInput.style.color = '#c9d1d9';
    playersSearchInput.style.fontSize = '13px';
    
    const addPlayerBtn = document.createElement('button');
    addPlayerBtn.className = 'add-player-btn';
    addPlayerBtn.textContent = '+';
    addPlayerBtn.title = 'Add new player';
    addPlayerBtn.style.width = '32px';
    addPlayerBtn.style.height = '32px';
    addPlayerBtn.style.padding = '0';
    addPlayerBtn.style.background = '#21262d';
    addPlayerBtn.style.border = '1px solid #30363d';
    addPlayerBtn.style.borderRadius = '6px';
    addPlayerBtn.style.color = '#c9d1d9';
    addPlayerBtn.style.cursor = 'pointer';
    addPlayerBtn.style.fontSize = '16px';
    addPlayerBtn.style.display = 'flex';
    addPlayerBtn.style.alignItems = 'center';
    addPlayerBtn.style.justifyContent = 'center';
    
    playerSelectorHeader.appendChild(playersSearchInput);
    playerSelectorHeader.appendChild(addPlayerBtn);
    
    const selectedPlayersDisplayEdit = document.createElement('div');
    selectedPlayersDisplayEdit.className = 'distats-note-edit-selected-players';
    selectedPlayersDisplayEdit.style.marginTop = '4px';
    selectedPlayersDisplayEdit.style.marginBottom = '4px';
    selectedPlayersDisplayEdit.style.fontSize = '12px';
    selectedPlayersDisplayEdit.style.color = '#8b949e';
    
    let isUpdatingDisplay = false;
    const updateSelectedPlayersDisplayEdit = () => {
      // Prevent concurrent updates
      if (isUpdatingDisplay) {
        return;
      }
      isUpdatingDisplay = true;
      
      // Clear display completely
      selectedPlayersDisplayEdit.innerHTML = '';
      
      // First, deduplicate the array synchronously (simple reference-based deduplication)
      // This handles both IDs and names
      const uniqueRefs = [];
      const seenRefs = new Set();
      editSelectedPlayers.forEach(ref => {
        if (!seenRefs.has(ref)) {
          seenRefs.add(ref);
          uniqueRefs.push(ref);
        }
      });
      editSelectedPlayers = uniqueRefs;
      
      if (editSelectedPlayers.length > 0) {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const selectedPlayerObjects = [];
          const playerNames = [];
          
          // Handle both IDs and names, and deduplicate by player ID
          const seenPlayerIds = new Set();
          const processedRefs = [];
          
          editSelectedPlayers.forEach(playerRef => {
            if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
              const player = players.find(p => p.id === playerRef);
              if (player && !seenPlayerIds.has(player.id)) {
                selectedPlayerObjects.push(player);
                seenPlayerIds.add(player.id);
                processedRefs.push(player.id);
              } else if (!player) {
                // Invalid ID, skip it
              }
            } else if (typeof playerRef === 'string') {
              // It's a name string - try to find by name
              const playerNameLower = playerRef.toLowerCase().trim();
              const player = players.find(p => {
                const fullName = (p.fullName || '').toLowerCase();
                const name = (p.name || '').toLowerCase();
                const surname = (p.surname || '').toLowerCase();
                return fullName === playerNameLower || 
                       name === playerNameLower || 
                       surname === playerNameLower ||
                       fullName.includes(playerNameLower) ||
                       playerNameLower.includes(fullName);
              });
              if (player && !seenPlayerIds.has(player.id)) {
                selectedPlayerObjects.push(player);
                seenPlayerIds.add(player.id);
                processedRefs.push(player.id);
              } else if (player && seenPlayerIds.has(player.id)) {
                // Duplicate - skip
              } else if (playerRef.length < 100 && !playerRef.includes('!') && !playerRef.includes('?') && !playerRef.includes('.')) {
                // Valid name but not found - keep as fallback (only if not already seen)
                const nameLower = playerRef.toLowerCase().trim();
                if (!playerNames.some(n => n.toLowerCase().trim() === nameLower)) {
                  playerNames.push(playerRef);
                  processedRefs.push(playerRef);
                }
              }
            }
          });
          
          // Update editSelectedPlayers to remove duplicates
          editSelectedPlayers = processedRefs;
          
          // Final deduplication of selectedPlayerObjects by ID
          const uniquePlayerObjects = [];
          const uniquePlayerIds = new Set();
          selectedPlayerObjects.forEach(player => {
            if (!uniquePlayerIds.has(player.id)) {
              uniquePlayerIds.add(player.id);
              uniquePlayerObjects.push(player);
            }
          });
          
          // Clear display again before rendering (in case of race conditions)
          selectedPlayersDisplayEdit.innerHTML = '';
          
          if (uniquePlayerObjects.length > 0 || playerNames.length > 0) {
            const label = document.createElement('span');
            label.textContent = 'Selected: ';
            selectedPlayersDisplayEdit.appendChild(label);
            
            // Display matched players - ensure no duplicates by using a Set to track displayed IDs
            const displayedPlayerIds = new Set();
            uniquePlayerObjects.forEach(player => {
              // Skip if we've already displayed this player
              if (displayedPlayerIds.has(player.id)) {
                return;
              }
              displayedPlayerIds.add(player.id);
              
              const tag = document.createElement('span');
              tag.textContent = player.number ? 
                `#${player.number} ${player.fullName || ''}`.trim() : 
                (player.fullName || 'Unnamed');
              tag.style.background = '#21262d';
              tag.style.color = '#c9d1d9';
              tag.style.padding = '4px 8px';
              tag.style.borderRadius = '12px';
              tag.style.fontSize = '12px';
              tag.style.marginRight = '6px';
              tag.style.marginBottom = '4px';
              tag.style.display = 'inline-block';
              
              const removeBtn = document.createElement('span');
              removeBtn.textContent = ' ×';
              removeBtn.style.cursor = 'pointer';
              removeBtn.style.marginLeft = '4px';
              removeBtn.style.color = '#8b949e';
              removeBtn.addEventListener('click', () => {
                editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
                updateSelectedPlayersDisplayEdit();
                renderEditPlayers(playersSearchInput.value);
              });
              
              tag.appendChild(removeBtn);
              selectedPlayersDisplayEdit.appendChild(tag);
            });
            
            // Display unmatched player names (fallback) - also deduplicate
            const displayedNames = new Set();
            playerNames.forEach(playerName => {
              const nameLower = playerName.toLowerCase().trim();
              if (displayedNames.has(nameLower)) {
                return;
              }
              displayedNames.add(nameLower);
              
              const tag = document.createElement('span');
              tag.textContent = playerName;
              tag.style.background = '#21262d';
              tag.style.color = '#c9d1d9';
              tag.style.padding = '4px 8px';
              tag.style.borderRadius = '12px';
              tag.style.fontSize = '12px';
              tag.style.marginRight = '6px';
              tag.style.marginBottom = '4px';
              tag.style.display = 'inline-block';
              
              const removeBtn = document.createElement('span');
              removeBtn.textContent = ' ×';
              removeBtn.style.cursor = 'pointer';
              removeBtn.style.marginLeft = '4px';
              removeBtn.style.color = '#8b949e';
              removeBtn.addEventListener('click', () => {
                editSelectedPlayers = editSelectedPlayers.filter(ref => ref !== playerName);
                updateSelectedPlayersDisplayEdit();
                renderEditPlayers(playersSearchInput.value);
              });
              
              tag.appendChild(removeBtn);
              selectedPlayersDisplayEdit.appendChild(tag);
            });
          }
          
          isUpdatingDisplay = false;
        });
      } else {
        isUpdatingDisplay = false;
      }
    };
    
    const playersDropdown = document.createElement('div');
    playersDropdown.className = 'distats-note-edit-players-dropdown';
    playersDropdown.style.display = 'none';
    playersDropdown.style.position = 'relative';
    playersDropdown.style.background = '#161b22';
    playersDropdown.style.border = '1px solid #30363d';
    playersDropdown.style.borderRadius = '6px';
    playersDropdown.style.maxHeight = '200px';
    playersDropdown.style.overflowY = 'auto';
    playersDropdown.style.zIndex = '1000';
    playersDropdown.style.width = '100%';
    playersDropdown.style.marginTop = '4px';
    
    const renderEditPlayers = (searchQuery = '') => {
      chrome.storage.local.get(['players', 'analyses'], (result) => {
        const players = result.players || [];
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        const teams = analysis ? (analysis.teams || []) : [];
        
        const filteredPlayers = players.filter(player => {
          const searchLower = searchQuery.toLowerCase();
          const fullName = (player.fullName || '').toLowerCase();
          const number = (player.number || '').toString();
          const team = (player.team || '').toLowerCase();
          return fullName.includes(searchLower) || 
                 number.includes(searchLower) || 
                 team.includes(searchLower);
        });
        
        playersDropdown.innerHTML = '';
        
        if (filteredPlayers.length === 0) {
          const emptyMsg = document.createElement('div');
          emptyMsg.style.padding = '10px';
          emptyMsg.style.color = '#8b949e';
          emptyMsg.style.textAlign = 'center';
          emptyMsg.textContent = searchQuery ? 'No players found' : 'No players created yet';
          playersDropdown.appendChild(emptyMsg);
          return;
        }
        
        const playersByTeam = {};
        filteredPlayers.forEach(player => {
          const team = player.team || 'No team';
          if (!playersByTeam[team]) {
            playersByTeam[team] = [];
          }
          playersByTeam[team].push(player);
        });
        
        const sortedTeams = Object.keys(playersByTeam).sort();
        
        sortedTeams.forEach(team => {
          const teamDiv = document.createElement('div');
          teamDiv.style.marginBottom = '8px';
          
          const teamLabel = document.createElement('div');
          teamLabel.style.fontSize = '11px';
          teamLabel.style.color = '#8b949e';
          teamLabel.style.marginBottom = '4px';
          teamLabel.style.padding = '4px 8px';
          teamLabel.textContent = team;
          teamDiv.appendChild(teamLabel);
          
          playersByTeam[team].sort((a, b) => {
            const numA = parseInt(a.number) || 0;
            const numB = parseInt(b.number) || 0;
            return numA - numB;
          }).forEach(player => {
            const playerItem = document.createElement('div');
            playerItem.style.display = 'flex';
            playerItem.style.alignItems = 'center';
            playerItem.style.padding = '4px 8px';
            playerItem.style.cursor = 'pointer';
            
            playerItem.addEventListener('mouseenter', () => {
              playerItem.style.background = '#21262d';
            });
            playerItem.addEventListener('mouseleave', () => {
              playerItem.style.background = 'transparent';
            });
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = player.id;
            // Check if player is selected (by ID or by name match)
            const isSelected = editSelectedPlayers.includes(player.id) || 
                              editSelectedPlayers.some(ref => {
                                if (typeof ref === 'string' && !ref.startsWith('player_')) {
                                  // It's a name - check if it matches this player
                                  const refLower = ref.toLowerCase().trim();
                                  const fullName = (player.fullName || '').toLowerCase();
                                  const name = (player.name || '').toLowerCase();
                                  const surname = (player.surname || '').toLowerCase();
                                  return fullName === refLower || 
                                         name === refLower || 
                                         surname === refLower ||
                                         fullName.includes(refLower) ||
                                         refLower.includes(fullName);
                                }
                                return false;
                              });
            checkbox.checked = isSelected;
            checkbox.style.marginRight = '8px';
            checkbox.style.cursor = 'pointer';
            
            checkbox.addEventListener('change', (e) => {
              if (e.target.checked) {
                if (!editSelectedPlayers.includes(player.id)) {
                  // Remove any name-based references to this player
                  editSelectedPlayers = editSelectedPlayers.filter(ref => {
                    if (typeof ref === 'string' && !ref.startsWith('player_')) {
                      const refLower = ref.toLowerCase().trim();
                      const fullName = (player.fullName || '').toLowerCase();
                      const name = (player.name || '').toLowerCase();
                      const surname = (player.surname || '').toLowerCase();
                      const matches = fullName === refLower || 
                                     name === refLower || 
                                     surname === refLower ||
                                     fullName.includes(refLower) ||
                                     refLower.includes(fullName);
                      return !matches; // Remove matching name references
                    }
                    return ref !== player.id; // Remove old ID if present
                  });
                  editSelectedPlayers.push(player.id);
                }
              } else {
                editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
              }
              updateSelectedPlayersDisplayEdit();
            });
            
            const label = document.createElement('label');
            label.style.flex = '1';
            label.style.cursor = 'pointer';
            label.style.fontSize = '13px';
            label.style.color = '#c9d1d9';
            
            const displayText = player.number ? 
              `#${player.number} ${player.fullName || ''}`.trim() : 
              (player.fullName || 'Unnamed');
            label.textContent = displayText;
            
            label.addEventListener('click', () => {
              checkbox.checked = !checkbox.checked;
              checkbox.dispatchEvent(new Event('change'));
            });
            
            const editBtn = document.createElement('button');
            editBtn.textContent = '✎';
            editBtn.style.background = 'transparent';
            editBtn.style.border = 'none';
            editBtn.style.color = '#8b949e';
            editBtn.style.cursor = 'pointer';
            editBtn.style.padding = '2px 6px';
            editBtn.style.marginLeft = '4px';
            editBtn.style.fontSize = '12px';
            editBtn.title = 'Edit player';
            editBtn.addEventListener('click', (e) => {
              e.stopPropagation();
              editPlayer(player.id);
              // Refresh the dropdown after editing
              setTimeout(() => {
                renderEditPlayers(playersSearchInput.value);
                updateSelectedPlayersDisplayEdit();
              }, 500);
            });
            
            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = '×';
            deleteBtn.style.background = 'transparent';
            deleteBtn.style.border = 'none';
            deleteBtn.style.color = '#8b949e';
            deleteBtn.style.cursor = 'pointer';
            deleteBtn.style.padding = '2px 6px';
            deleteBtn.style.marginLeft = '2px';
            deleteBtn.style.fontSize = '16px';
            deleteBtn.title = 'Delete player';
            deleteBtn.addEventListener('click', (e) => {
              e.stopPropagation();
              if (confirm(`Are you sure you want to delete ${player.fullName || 'this player'}?`)) {
                deletePlayer(player.id);
                // Remove from selected if it was selected
                editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
                // Refresh the dropdown after deletion
                setTimeout(() => {
                  renderEditPlayers(playersSearchInput.value);
                  updateSelectedPlayersDisplayEdit();
                }, 500);
              }
            });
            
            playerItem.appendChild(checkbox);
            playerItem.appendChild(label);
            playerItem.appendChild(editBtn);
            playerItem.appendChild(deleteBtn);
            teamDiv.appendChild(playerItem);
          });
          
          playersDropdown.appendChild(teamDiv);
        });
      });
    };
    
    playersSearchInput.addEventListener('focus', () => {
      playersDropdown.style.display = 'block';
      renderEditPlayers(playersSearchInput.value);
    });
    
    playersSearchInput.addEventListener('input', (e) => {
      renderEditPlayers(e.target.value);
    });
    
    playersSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!playersDropdown.matches(':hover') && document.activeElement !== playersSearchInput) {
          playersDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    playersDropdown.addEventListener('mouseenter', () => {
      playersDropdown.style.display = 'block';
    });
    
    playersDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== playersSearchInput) {
        playersDropdown.style.display = 'none';
      }
    });
    
    // Create player button handler
    addPlayerBtn.addEventListener('click', () => {
      createNewPlayer();
      // Listen for player creation completion
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          // If players count increased, refresh
          if (players.length > (window.lastPlayerCount || 0)) {
            window.lastPlayerCount = players.length;
            renderEditPlayers(playersSearchInput.value);
            playersDropdown.style.display = 'block';
          }
        });
      }, 500);
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    renderEditPlayers();
    updateSelectedPlayersDisplayEdit();
    
    editPlayersContainer.appendChild(playersLabel);
    editPlayersContainer.appendChild(playerSelectorHeader);
    editPlayersContainer.appendChild(selectedPlayersDisplayEdit);
    editPlayersContainer.appendChild(playersDropdown);
    editContainer.appendChild(editPlayersContainer);
    
    // Intensity selector for editing
    const editIntensityContainer = document.createElement('div');
    editIntensityContainer.className = 'distats-note-edit-intensity';
    editIntensityContainer.style.marginBottom = '12px';
    
    const intensityLabel = document.createElement('label');
    intensityLabel.textContent = 'Intensity:';
    intensityLabel.style.display = 'block';
    intensityLabel.style.fontSize = '12px';
    intensityLabel.style.color = '#8b949e';
    intensityLabel.style.marginBottom = '4px';
    
    const intensityScale = document.createElement('div');
    intensityScale.className = 'distats-note-edit-intensity-scale';
    intensityScale.style.position = 'relative';
    intensityScale.style.width = '100%';
    intensityScale.style.height = '60px';
    
    const intensityTrack = document.createElement('div');
    intensityTrack.className = 'distats-note-edit-intensity-track';
    intensityTrack.style.position = 'relative';
    intensityTrack.style.width = '100%';
    intensityTrack.style.height = '8px';
    intensityTrack.style.background = 'linear-gradient(to right, #1f6feb 0%, #58a6ff 25%, #c9d1d9 50%, #f85149 75%, #da3633 100%)';
    intensityTrack.style.borderRadius = '4px';
    intensityTrack.style.cursor = 'pointer';
    
    const intensitySlider = document.createElement('div');
    intensitySlider.className = 'distats-note-edit-intensity-slider';
    intensitySlider.style.position = 'absolute';
    intensitySlider.style.top = '-6px';
    intensitySlider.style.width = '20px';
    intensitySlider.style.height = '20px';
    intensitySlider.style.background = '#ffffff';
    intensitySlider.style.border = '2px solid #30363d';
    intensitySlider.style.borderRadius = '50%';
    intensitySlider.style.cursor = 'grab';
    intensitySlider.style.transform = 'translateX(-50%)';
    intensitySlider.style.transition = 'border-color 0.15s ease, box-shadow 0.15s ease';
    intensitySlider.style.zIndex = '10';
    intensitySlider.style.userSelect = 'none';
    
    // Set initial position
    const initialIntensity = editSelectedIntensity !== null ? editSelectedIntensity : 2;
    intensitySlider.style.left = `${(initialIntensity / 4) * 100}%`;
    
    const intensityLabels = document.createElement('div');
    intensityLabels.className = 'distats-note-edit-intensity-labels';
    intensityLabels.style.display = 'flex';
    intensityLabels.style.justifyContent = 'space-between';
    intensityLabels.style.marginTop = '12px';
    
    const labelTexts = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
    labelTexts.forEach((text, index) => {
      const label = document.createElement('span');
      label.textContent = text;
      label.className = 'distats-note-edit-intensity-label-point';
      label.dataset.value = index;
      label.style.fontSize = '11px';
      label.style.color = '#8b949e';
      label.style.cursor = 'pointer';
      label.style.userSelect = 'none';
      label.style.transition = 'color 0.15s ease';
      label.style.flex = '1';
      label.style.textAlign = 'center';
      
      if (index === initialIntensity) {
        label.style.color = '#c9d1d9';
        label.style.fontWeight = '600';
      }
      
      label.addEventListener('click', () => {
        editSelectedIntensity = index;
        intensitySlider.style.left = `${(index / 4) * 100}%`;
        labelTexts.forEach((t, i) => {
          const l = intensityLabels.querySelector(`[data-value="${i}"]`);
          if (l) {
            l.style.color = i === index ? '#c9d1d9' : '#8b949e';
            l.style.fontWeight = i === index ? '600' : 'normal';
          }
        });
      });
      
      intensityLabels.appendChild(label);
    });
    
    let isDragging = false;
    intensityTrack.addEventListener('mousedown', (e) => {
      isDragging = true;
      intensitySlider.style.cursor = 'grabbing';
      const rect = intensityTrack.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percent = Math.max(0, Math.min(1, x / rect.width));
      const value = Math.round(percent * 4);
      editSelectedIntensity = value;
      intensitySlider.style.left = `${(value / 4) * 100}%`;
      labelTexts.forEach((t, i) => {
        const l = intensityLabels.querySelector(`[data-value="${i}"]`);
        if (l) {
          l.style.color = i === value ? '#c9d1d9' : '#8b949e';
          l.style.fontWeight = i === value ? '600' : 'normal';
        }
      });
    });
    
    document.addEventListener('mousemove', (e) => {
      if (isDragging) {
        const rect = intensityTrack.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percent = Math.max(0, Math.min(1, x / rect.width));
        const value = Math.round(percent * 4);
        editSelectedIntensity = value;
        intensitySlider.style.left = `${(value / 4) * 100}%`;
        labelTexts.forEach((t, i) => {
          const l = intensityLabels.querySelector(`[data-value="${i}"]`);
          if (l) {
            l.style.color = i === value ? '#c9d1d9' : '#8b949e';
            l.style.fontWeight = i === value ? '600' : 'normal';
          }
        });
      }
    });
    
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        intensitySlider.style.cursor = 'grab';
      }
    });
    
    intensityScale.appendChild(intensityTrack);
    intensityScale.appendChild(intensitySlider);
    intensityScale.appendChild(intensityLabels);
    editIntensityContainer.appendChild(intensityLabel);
    editIntensityContainer.appendChild(intensityScale);
    editContainer.appendChild(editIntensityContainer);
    
    // Store edited values in noteElement for access during save
    noteElement.dataset.editTeam = editSelectedTeam || '';
    noteElement.dataset.editEvents = JSON.stringify(editSelectedEvents);
    noteElement.dataset.editZones = JSON.stringify(editSelectedZones);
    noteElement.dataset.editPlayers = JSON.stringify(editSelectedPlayers);
    noteElement.dataset.editIntensity = editSelectedIntensity !== null ? editSelectedIntensity.toString() : '';
    
    // Helper function to update dataset when team changes
    const updateTeamDataset = () => {
      noteElement.dataset.editTeam = editSelectedTeam || '';
    };
    
    // Get current images from note and normalize to object format
    const rawImages = note.images ? 
      (Array.isArray(note.images) ? [...note.images] : [note.images]) : 
      (note.image ? [note.image] : []);
    
    // Normalize images to consistent object format for editing
    const currentImages = rawImages.map(img => {
      if (typeof img === 'object' && img !== null) {
        // Already an object, ensure it has required fields
        return {
          imageData: img.imageData || img,
          slidesData: img.slidesData || null,
          originalSrc: img.originalSrc || null
        };
      } else {
        // String format, convert to object
        return {
          imageData: img,
          slidesData: null,
          originalSrc: null
        };
      }
    });
    
    // Store edited images in noteElement for access during save
    noteElement.dataset.editedImages = JSON.stringify(currentImages);
    
    // Create images editing section
    const editImagesContainer = document.createElement('div');
    editImagesContainer.className = 'distats-note-edit-images';
    editImagesContainer.style.marginTop = '12px';
    editImagesContainer.style.paddingTop = '12px';
    editImagesContainer.style.borderTop = '1px solid #30363d';
    
    const editImagesHeader = document.createElement('div');
    editImagesHeader.style.display = 'flex';
    editImagesHeader.style.justifyContent = 'space-between';
    editImagesHeader.style.alignItems = 'center';
    editImagesHeader.style.marginBottom = '8px';
    
    const editImagesTitle = document.createElement('span');
    editImagesTitle.textContent = 'Attached Images:';
    editImagesTitle.style.color = '#c9d1d9';
    editImagesTitle.style.fontSize = '13px';
    editImagesTitle.style.fontWeight = '500';
    
    const editImagesActions = document.createElement('div');
    editImagesActions.style.display = 'flex';
    editImagesActions.style.gap = '8px';
    
    const addImageBtn = document.createElement('button');
    addImageBtn.className = 'input-icon-button';
    addImageBtn.title = 'Add image';
    addImageBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
        <circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
    `;
    addImageBtn.addEventListener('click', () => {
      const imageInput = document.getElementById('distatsImageInput');
      if (imageInput) {
        imageInput.click();
        const originalOnChange = imageInput.onchange;
        imageInput.onchange = async (e) => {
          const files = Array.from(e.target.files);
          if (files.length > 0) {
            for (const file of files) {
              // Process image file (similar to how it's done in setupEventListeners)
              const compressedImage = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                  const img = new Image();
                  img.onload = () => {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    let width = img.width;
                    let height = img.height;
                    const maxWidth = 1200;
                    const maxHeight = 1200;
                    if (width > maxWidth || height > maxHeight) {
                      if (width > height) {
                        height = (height * maxWidth) / width;
                        width = maxWidth;
                      } else {
                        width = (width * maxHeight) / height;
                        height = maxHeight;
                      }
                    }
                    canvas.width = width;
                    canvas.height = height;
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', 0.95));
                  };
                  img.onerror = reject;
                  img.src = e.target.result;
                };
                reader.onerror = reject;
                reader.readAsDataURL(file);
              });
              
              const newImages = JSON.parse(noteElement.dataset.editedImages || '[]');
              const imageObj = {
                imageData: compressedImage,
                slidesData: null,
                originalSrc: null
              };
              newImages.push(imageObj);
              noteElement.dataset.editedImages = JSON.stringify(newImages);
              updateEditImagesDisplay(editImagesList, noteElement);
            }
          }
          e.target.value = '';
          imageInput.onchange = originalOnChange;
        };
      }
    });
    
    const deleteAllImagesBtn = document.createElement('button');
    deleteAllImagesBtn.className = 'input-icon-button';
    deleteAllImagesBtn.title = 'Delete all images';
    deleteAllImagesBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="3 6 5 6 21 6"></polyline>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        <line x1="10" y1="11" x2="10" y2="17"></line>
        <line x1="14" y1="11" x2="14" y2="17"></line>
      </svg>
    `;
    deleteAllImagesBtn.style.display = currentImages.length > 0 ? 'block' : 'none';
    deleteAllImagesBtn.addEventListener('click', () => {
      if (confirm('Delete all images?')) {
        noteElement.dataset.editedImages = JSON.stringify([]);
        updateEditImagesDisplay(editImagesList, noteElement);
      }
    });
    
    editImagesActions.appendChild(addImageBtn);
    if (currentImages.length > 0) {
      editImagesActions.appendChild(deleteAllImagesBtn);
    }
    
    editImagesHeader.appendChild(editImagesTitle);
    editImagesHeader.appendChild(editImagesActions);
    
    const editImagesList = document.createElement('div');
    editImagesList.className = 'distats-note-edit-images-list';
    editImagesList.style.display = 'flex';
    editImagesList.style.flexWrap = 'wrap';
    editImagesList.style.gap = '8px';
    
    // Function to update images display
    function updateEditImagesDisplay(container, noteEl) {
      container.innerHTML = '';
      const editedImagesRaw = noteEl.getAttribute('data-edited-images') || noteEl.dataset.editedImages || '[]';
      const editedImages = JSON.parse(editedImagesRaw);
      
      if (editedImages.length === 0) {
        deleteAllImagesBtn.style.display = 'none';
      } else {
        deleteAllImagesBtn.style.display = 'block';
      }
      
      editedImages.forEach((imgData, index) => {
        // Extract actual image data - handle both string and object formats
        const actualImageData = typeof imgData === 'object' && imgData !== null ? (imgData.imageData || imgData) : imgData;
        const existingSlidesData = typeof imgData === 'object' && imgData !== null ? imgData.slidesData : null;
        const originalImageSrc = typeof imgData === 'object' && imgData !== null ? imgData.originalSrc : null;
        
        // Skip if no valid image data
        if (!actualImageData || (typeof actualImageData !== 'string')) {
          console.warn('Skipping invalid image data at index', index);
          return;
        }
        
        const imageItem = document.createElement('div');
        imageItem.style.position = 'relative';
        imageItem.style.display = 'inline-block';
        imageItem.style.marginBottom = '8px';
        
        const img = document.createElement('img');
        img.src = actualImageData;
        img.style.maxWidth = '150px';
        img.style.maxHeight = '150px';
        img.style.width = 'auto';
        img.style.height = 'auto';
        img.style.borderRadius = '6px';
        img.style.border = '1px solid #30363d';
        img.style.cursor = 'pointer';
        img.style.display = 'block';
        img.style.objectFit = 'contain';
        img.alt = `Attached image ${index + 1}`;
        
        // Add error handling for failed image loads
        img.onerror = function() {
          console.error('Failed to load image in edit mode:', index);
          this.style.display = 'none';
          const errorDiv = document.createElement('div');
          errorDiv.textContent = 'Failed to load image';
          errorDiv.style.color = '#8b949e';
          errorDiv.style.fontSize = '12px';
          errorDiv.style.padding = '8px';
          errorDiv.style.border = '1px solid #30363d';
          errorDiv.style.borderRadius = '6px';
          errorDiv.style.minWidth = '150px';
          errorDiv.style.minHeight = '150px';
          errorDiv.style.display = 'flex';
          errorDiv.style.alignItems = 'center';
          errorDiv.style.justifyContent = 'center';
          imageItem.appendChild(errorDiv);
        };
        
        const imageIndex = index;
        const noteElementRef = noteElement;
        img.addEventListener('click', () => {
          openEditorWindowWithImage(actualImageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            const currentImagesRaw = noteElementRef.getAttribute('data-edited-images') || noteElementRef.dataset.editedImages || '[]';
            const currentImages = JSON.parse(currentImagesRaw);
            if (imageIndex >= 0 && imageIndex < currentImages.length) {
              const updatedImages = [...currentImages];
              const originalImageObj = currentImages[imageIndex];
              if (typeof originalImageObj === 'object' && originalImageObj !== null) {
                updatedImages[imageIndex] = {
                  ...originalImageObj,
                  imageData: modifiedImageData,
                  slidesData: slidesData || originalImageObj.slidesData || null,
                  originalSrc: savedOriginalImageSrc || originalImageObj.originalSrc || null
                };
              } else {
                updatedImages[imageIndex] = {
                  imageData: modifiedImageData,
                  slidesData: slidesData || null,
                  originalSrc: savedOriginalImageSrc || null
                };
              }
              const updatedImagesJson = JSON.stringify(updatedImages);
              noteElementRef.setAttribute('data-edited-images', updatedImagesJson);
              noteElementRef.dataset.editedImages = updatedImagesJson;
              updateEditImagesDisplay(editImagesList, noteElementRef);
            }
          }, existingSlidesData, originalImageSrc);
        });
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'message-delete-btn';
        deleteBtn.style.position = 'absolute';
        deleteBtn.style.top = '4px';
        deleteBtn.style.right = '4px';
        deleteBtn.innerHTML = '×';
        deleteBtn.title = 'Delete image';
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const imagesRaw = noteEl.getAttribute('data-edited-images') || noteEl.dataset.editedImages || '[]';
          const images = JSON.parse(imagesRaw);
          images.splice(index, 1);
          const updatedJson = JSON.stringify(images);
          noteEl.setAttribute('data-edited-images', updatedJson);
          noteEl.dataset.editedImages = updatedJson;
          updateEditImagesDisplay(container, noteEl);
        });
        
        imageItem.appendChild(img);
        imageItem.appendChild(deleteBtn);
        container.appendChild(imageItem);
      });
    }
    
    updateEditImagesDisplay(editImagesList, noteElement);
    editImagesContainer.appendChild(editImagesHeader);
    editImagesContainer.appendChild(editImagesList);
    editContainer.appendChild(editImagesContainer);
    
    // Create save/cancel buttons
    const editActions = document.createElement('div');
    editActions.className = 'distats-note-edit-actions';
    editActions.style.display = 'flex';
    editActions.style.gap = '8px';
    editActions.style.marginTop = '8px';
    
    const saveBtn = document.createElement('button');
    saveBtn.className = 'distats-note-save-btn';
    saveBtn.textContent = 'Save';
    saveBtn.style.padding = '6px 12px';
    saveBtn.style.border = '1px solid #03509A';
    saveBtn.style.borderRadius = '4px';
    saveBtn.style.background = '#03509A';
    saveBtn.style.color = 'white';
    saveBtn.style.cursor = 'pointer';
    saveBtn.style.fontSize = '13px';
    saveBtn.addEventListener('click', () => {
      // Update stored values from UI
      noteElement.dataset.editTeam = editSelectedTeam || '';
      noteElement.dataset.editEvents = JSON.stringify(editSelectedEvents);
      noteElement.dataset.editZones = JSON.stringify(editSelectedZones);
      noteElement.dataset.editPlayers = JSON.stringify(editSelectedPlayers);
      noteElement.dataset.editIntensity = editSelectedIntensity !== null ? editSelectedIntensity.toString() : '';
      saveEditedNoteIn(noteElement, note, textarea.value.trim(), textarea, contentElement, editContainer);
    });
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'distats-note-cancel-btn';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.padding = '6px 12px';
    cancelBtn.style.border = '1px solid #555';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.background = '#2a2a2a';
    cancelBtn.style.color = '#fff';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.style.fontSize = '13px';
    cancelBtn.addEventListener('click', () => {
      // Restore original content element
      parent.replaceChild(contentElement, textarea);
      editActions.remove();
      editContainer.remove();
      // Restore hidden elements
      if (teamElement) teamElement.style.display = '';
      if (eventsElement) eventsElement.style.display = '';
      if (zonesElement) zonesElement.style.display = '';
      if (intensityElement) intensityElement.style.display = '';
    });
    
    editActions.appendChild(saveBtn);
    editActions.appendChild(cancelBtn);
    
    // Insert edit container before edit actions
    noteElement.appendChild(editContainer);
    noteElement.appendChild(editActions);
    
    // Save on Enter (Ctrl/Cmd+Enter)
    textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        noteElement.dataset.editTeam = editSelectedTeam || '';
        noteElement.dataset.editEvents = JSON.stringify(editSelectedEvents);
        noteElement.dataset.editZones = JSON.stringify(editSelectedZones);
        noteElement.dataset.editPlayers = JSON.stringify(editSelectedPlayers);
        noteElement.dataset.editIntensity = editSelectedIntensity !== null ? editSelectedIntensity.toString() : '';
        saveEditedNoteIn(noteElement, note, textarea.value.trim(), textarea, contentElement, editContainer);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        parent.replaceChild(contentElement, textarea);
        editActions.remove();
        editContainer.remove();
        // Restore hidden elements
        if (teamElement) teamElement.style.display = '';
        if (eventsElement) eventsElement.style.display = '';
        if (zonesElement) zonesElement.style.display = '';
        if (intensityElement) intensityElement.style.display = '';
        // Restore hidden images
        imageContainers.forEach(container => {
          container.style.display = '';
        });
      }
    });
  }

  // Save edited note in sidebar
  function saveEditedNoteIn(noteElement, note, newText, textarea, originalElement, editContainer) {
    if (!currentAnalysisId || !note || !note.timestamp) {
      return;
    }
    
    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }
    
    chrome.storage.local.get(['analyses'], (result) => {
      if (handleStorageError(null, 'saveEditedNoteIn')) {
        return;
      }
      
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
      
      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === note.timestamp);
        
        if (noteIndex !== -1) {
          const updatedNote = analysis.notes[noteIndex];
          
          // Preserve timecode if it exists
          const timecodeMatch = (updatedNote.content || updatedNote.text || '').match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/);
          const timecode = timecodeMatch ? timecodeMatch[0] : '';
          
          // Check for duplicate text in newText before saving
          let cleanedNewText = newText.trim();
          if (cleanedNewText.length > 0) {
            const messageLength = cleanedNewText.length;
            const halfLength = Math.floor(messageLength / 2);
            const firstHalf = cleanedNewText.substring(0, halfLength);
            const secondHalf = cleanedNewText.substring(halfLength);
            // Check if message is exactly duplicated (first half == second half)
            if (firstHalf === secondHalf && messageLength % 2 === 0) {
              console.warn('Detected duplicated message text when saving, using only first half');
              cleanedNewText = firstHalf;
            }
          }
          
          const updatedText = timecode ? `${timecode} ${cleanedNewText}` : cleanedNewText;
          
          // Update note text (set both to same value to avoid duplication)
          updatedNote.text = updatedText;
          updatedNote.content = updatedText;
          
          // Update comment properties from dataset
          const editTeam = noteElement.dataset.editTeam || '';
          const editEvents = noteElement.dataset.editEvents ? JSON.parse(noteElement.dataset.editEvents) : [];
          const editZones = noteElement.dataset.editZones ? JSON.parse(noteElement.dataset.editZones) : [];
          const editPlayers = noteElement.dataset.editPlayers ? JSON.parse(noteElement.dataset.editPlayers) : [];
          const editIntensity = noteElement.dataset.editIntensity !== '' ? parseInt(noteElement.dataset.editIntensity) : null;
          
          // Update teams
          if (editTeam) {
            updatedNote.team = editTeam;
            updatedNote.teams = [editTeam];
          } else {
            updatedNote.team = null;
            updatedNote.teams = null;
          }
          
          // Update events
          if (editEvents && editEvents.length > 0) {
            updatedNote.events = editEvents;
          } else {
            updatedNote.events = null;
          }
          
          // Update zones
          if (editZones && editZones.length > 0) {
            updatedNote.zones = editZones;
          } else {
            updatedNote.zones = null;
          }
          
          // Update players
          if (editPlayers && editPlayers.length > 0) {
            updatedNote.players = editPlayers;
          } else {
            updatedNote.players = null;
          }
          
          // Update intensity
          updatedNote.intensity = editIntensity;
          
          // Update images from edited images dataset
          const editedImagesRaw = noteElement.dataset.editedImages || '[]';
          const editedImages = JSON.parse(editedImagesRaw);
          if (editedImages && editedImages.length > 0) {
            // Extract imageData from objects, or use string directly
            const imageDataArray = editedImages.map(img => {
              if (typeof img === 'object' && img !== null) {
                return img.imageData || img;
              }
              return img;
            });
            updatedNote.images = imageDataArray;
            updatedNote.image = imageDataArray[0]; // Keep single image for backward compatibility
          } else {
            updatedNote.images = null;
            updatedNote.image = null;
          }
          
          chrome.storage.local.set({ analyses: analyses }, () => {
            if (handleStorageError(null, 'saveEditedNoteIn-set')) {
              return;
            }
            
            // Update display
            const parent = textarea.parentNode;
            originalElement.textContent = updatedText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
            parent.replaceChild(originalElement, textarea);
            
            // Remove edit actions and container
            const editActions = noteElement.querySelector('.distats-note-edit-actions');
            if (editActions) {
              editActions.remove();
            }
            if (editContainer) {
              editContainer.remove();
            }
            
            // Update notes display to refresh all attributes
            updateNotesDisplay();
          });
        }
      }
    });
  }

  // Update notes display
  function updateNotesDisplay() {
    const notesList = document.getElementById('distatsNotesList');
    if (!notesList) return;

    if (!currentAnalysisId) {
      // No project selected - show message to create one
      notesList.innerHTML = `
        <div style="color: #999; font-style: italic; text-align: center; padding: 40px 20px;">
          <div style="margin-bottom: 15px; font-size: 14px;">No project selected for this video.</div>
          <div style="font-size: 12px;">Click "+ Project" button above to create a project for this video.</div>
        </div>
      `;
      return;
    }

    if (!isExtensionContextValid()) {
      notesList.innerHTML = `
        <div style="color: #ff6b6b; text-align: center; padding: 20px;">
          Extension context invalidated. Please reload the page.
        </div>
      `;
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'updateNotesDisplay')) {
          notesList.innerHTML = `
            <div style="color: #ff6b6b; text-align: center; padding: 20px;">
              Error loading notes. Please reload the page.
            </div>
          `;
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);

        if (analysis) {
        notesList.innerHTML = '';

        if (analysis.notes.length === 0) {
          notesList.innerHTML = `
            <div style="color: #666; font-style: italic; text-align: center; padding: 20px;">
              No notes yet. Type a note below to get started.
            </div>
          `;
          return;
        }

        // Sort notes by timestamp (oldest first) to ensure consistent order
        const sortedNotes = [...(analysis.notes || [])].sort((a, b) => {
          const timeA = a.timestamp || 0;
          const timeB = b.timestamp || 0;
          return timeA - timeB;
        });

        // Get videos from the project to match notes to videos
        let videos = [];
        if (analysis.videos && analysis.videos.length > 0) {
          videos = analysis.videos;
        } else if (analysis.videoUrl) {
          // Migrate legacy structure
          videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
        }

        sortedNotes.forEach((note, index) => {
          const noteElement = document.createElement('div');
          noteElement.className = 'chat-message';

          // Get note content and extract timecode if present
          // If both exist and are the same, use only one to avoid duplication
          let noteContent = '';
          if (note.text && note.content) {
            // Both exist - use text if they're different, otherwise use text (avoid duplication)
            noteContent = note.text.trim();
            // If content is different and longer, it might be the updated version
            if (note.content.trim() !== note.text.trim() && note.content.trim().length > note.text.trim().length) {
              noteContent = note.content.trim();
            }
          } else {
            noteContent = (note.text || note.content || '').trim();
          }
          
          // Check for duplicate text within the message itself
          if (noteContent.length > 0) {
            const messageLength = noteContent.length;
            const halfLength = Math.floor(messageLength / 2);
            const firstHalf = noteContent.substring(0, halfLength);
            const secondHalf = noteContent.substring(halfLength);
            // Check if message is exactly duplicated (first half == second half)
            if (firstHalf === secondHalf && messageLength % 2 === 0) {
              console.warn('Detected duplicated message text in sidebar, using only first half');
              noteContent = firstHalf;
            }
          }
          
          let displayContent = noteContent;
          let timecodeSeconds = note.videoTime;

          // Try to extract timecode from content (format: [HH:MM:SS] or [MM:SS])
          const timecodeMatch = noteContent.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]\s*(.*)$/);
          if (timecodeMatch) {
            // timecodeMatch[1] = hours (if HH:MM:SS) or minutes (if MM:SS)
            // timecodeMatch[2] = minutes (if HH:MM:SS) or seconds (if MM:SS)
            // timecodeMatch[3] = seconds (if HH:MM:SS) or undefined (if MM:SS)
            // timecodeMatch[4] = text after timecode
            if (timecodeMatch[3] !== undefined) {
              // Format: [HH:MM:SS]
              const hours = parseInt(timecodeMatch[1]);
              const minutes = parseInt(timecodeMatch[2]);
              const seconds = parseInt(timecodeMatch[3]);
              timecodeSeconds = hours * 3600 + minutes * 60 + seconds;
            } else {
              // Format: [MM:SS]
              const minutes = parseInt(timecodeMatch[1]);
              const seconds = parseInt(timecodeMatch[2]);
              timecodeSeconds = minutes * 60 + seconds;
            }
            displayContent = timecodeMatch[4] || ''; // Get text after timecode
          }

          // Find which video this note belongs to
          // Only try to find video if note has video information (videoUrl, videoId, or videoTitle)
          let noteVideo = null;
          const hasVideoInfo = note.videoUrl || (note.videoId && note.platform) || note.videoTitle;
          
          if (hasVideoInfo) {
            if (note.videoUrl) {
              noteVideo = videos.find(v => v.videoUrl === note.videoUrl);
            } else if (note.videoId && note.platform) {
              noteVideo = videos.find(v => v.videoId === note.videoId && v.platform === note.platform);
            }
            
            // If still no match but note has videoTitle stored directly, use it
            if (!noteVideo && note.videoTitle) {
              noteVideo = {
                videoUrl: note.videoUrl || null,
                videoId: note.videoId || null,
                platform: note.platform || null,
                videoTitle: note.videoTitle
              };
            }
          }
          // If note has no video info at all, don't try to match with current video

          // Add images if present
          const noteImages = note.images || (note.image ? [note.image] : null);
          if (noteImages && noteImages.length > 0) {
            noteImages.forEach((imgData, imgIndex) => {
              if (!imgData) return; // Skip invalid image data
              
              // Extract image data from stored image object
              let actualImageData = typeof imgData === 'object' ? imgData.imageData : imgData;
              const existingSlidesData = typeof imgData === 'object' ? imgData.slidesData : null;
              const originalImageSrc = typeof imgData === 'object' ? imgData.originalSrc : null;
              
              if (!actualImageData) return; // Skip if no image data
              
              // Validate image data format
              const isValidDataUrl = typeof actualImageData === 'string' && 
                (actualImageData.startsWith('data:image/') || actualImageData.startsWith('blob:'));
              
              if (!isValidDataUrl) {
                console.warn('Invalid image data format at index', imgIndex, 'Type:', typeof actualImageData, 'Length:', actualImageData ? actualImageData.length : 0);
                // Try to fix if it's a base64 string without data URL prefix
                if (typeof actualImageData === 'string' && actualImageData.length > 100) {
                  // Assume it's a JPEG if no prefix
                  actualImageData = 'data:image/jpeg;base64,' + actualImageData;
                } else {
                  return; // Skip invalid data
                }
              }
              
              const imageContainer = document.createElement('div');
              imageContainer.className = 'message-image-container';
              
              const img = document.createElement('img');
              // Use original background if available, otherwise use actualImageData
              const backgroundToUse = originalImageSrc || actualImageData;
              
              // Use actualImageData directly - it should already be merged with drawings for preview
              // The actualImageData is the merged image (with drawings), originalImageSrc is the clean background for editor
              img.src = actualImageData;
              img.className = 'message-image';
              img.alt = `Attached image ${imgIndex + 1}`;
              img.style.display = 'block';
              img.style.maxWidth = '100%';
              img.style.maxHeight = '300px';
              img.style.width = 'auto';
              img.style.height = 'auto';
              img.style.borderRadius = '8px';
              img.style.cursor = 'pointer';
              
              // Add error handling
              img.onerror = function() {
                console.error('Failed to load image:', imgIndex, 'Data length:', imgData ? imgData.length : 0, 'Starts with:', imgData ? imgData.substring(0, 50) : 'null');
                this.style.display = 'none';
                const errorDiv = document.createElement('div');
                errorDiv.textContent = 'Failed to load image';
                errorDiv.style.color = '#999';
                errorDiv.style.fontSize = '12px';
                errorDiv.style.padding = '8px';
                imageContainer.appendChild(errorDiv);
              };
              
              // Add load handler for debugging
              img.onload = function() {
              };
              
              // Add click handler to open editor
              img.addEventListener('click', () => {
                openImageEditorIn(actualImageData, note, imgIndex, existingSlidesData, originalImageSrc);
              });
              
              imageContainer.appendChild(img);
              noteElement.appendChild(imageContainer);
            });
          }

          // Create timestamp element with proper event listener
          if (timecodeSeconds !== null && timecodeSeconds !== undefined) {
            const timecode = formatTimecode(timecodeSeconds);
            const timestampElement = document.createElement('a');
            timestampElement.className = 'timecode-link';
            timestampElement.href = '#';
            timestampElement.textContent = timecode;
            timestampElement.title = noteVideo 
              ? `Click to open ${noteVideo.videoTitle || 'video'} at ${timecode}`
              : `Click to jump to ${timecode}`;
            
            // Add click event listener
            timestampElement.addEventListener('click', (e) => {
              e.preventDefault();
              e.stopPropagation();
              
              
              // CRITICAL: Only seek in current video if it's EXACTLY the same video
              // Use strict matching: video ID + platform must match
              let isCurrentVideo = false;
              if (noteVideo && noteVideo.videoId && noteVideo.platform) {
                if (currentVideoId && platform) {
                  isCurrentVideo = (noteVideo.videoId === currentVideoId && noteVideo.platform === platform);
                }
              }
              
              // If it's the current video, seek in place
              if (isCurrentVideo) {
                if (typeof window.distatsSeekToTime === 'function') {
              window.distatsSeekToTime(timecodeSeconds);
                }
                return;
              }
              
              // DIFFERENT video - ALWAYS open new tab with correct video
              if (noteVideo && noteVideo.videoUrl) {
                const videoUrl = noteVideo.videoUrl;
                let urlWithTime = '';
                
                try {
                  const url = new URL(videoUrl);
                  const hostname = url.hostname.toLowerCase();
                  
                  if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
                    url.searchParams.delete('t');
                    url.searchParams.delete('start');
                    url.searchParams.set('t', Math.floor(timecodeSeconds));
                    urlWithTime = url.toString();
                  } else if (hostname.includes('dailymotion.com')) {
                    url.hash = `#t=${Math.floor(timecodeSeconds)}`;
                    urlWithTime = url.toString();
                  } else if (hostname.includes('twitch.tv')) {
                    const hours = Math.floor(timecodeSeconds / 3600);
                    const minutes = Math.floor((timecodeSeconds % 3600) / 60);
                    const secs = Math.floor(timecodeSeconds % 60);
                    const twitchTime = `${hours}h${minutes}m${secs}s`;
                    url.searchParams.set('t', twitchTime);
                    urlWithTime = url.toString();
                  } else {
                    url.searchParams.set('t', Math.floor(timecodeSeconds));
                    urlWithTime = url.toString();
                  }
                  
                  // ALWAYS open in new tab for different video
                  window.open(urlWithTime, '_blank');
                } catch (error) {
                  console.error('Error constructing video URL with time:', error);
                  // Fallback: open video URL without time
                  window.open(videoUrl, '_blank');
                }
              } else {
                // No video info - this shouldn't happen, but try to seek in current video as fallback
                console.warn('⚠️ No video info in note, seeking in current video as fallback');
                if (typeof window.distatsSeekToTime === 'function') {
                  window.distatsSeekToTime(timecodeSeconds);
                }
              }
            });
            
            noteElement.appendChild(timestampElement);
          }

          // Add team information if present
          if (note.team && note.team.trim && note.team.trim() !== '') {
            const teamElement = document.createElement('div');
            teamElement.className = 'message-team';
            teamElement.textContent = `Team: ${note.team}`;
            teamElement.style.color = '#8b949e';
            teamElement.style.fontSize = '12px';
            teamElement.style.marginTop = '4px';
            teamElement.style.marginBottom = '4px';
            noteElement.appendChild(teamElement);
          }

          // Add video information if present
          if (noteVideo && noteVideo.videoTitle) {
            const videoElement = document.createElement('div');
            videoElement.className = 'message-video';
            const maxTitleLength = 40;
            const truncatedTitle = noteVideo.videoTitle.length > maxTitleLength 
              ? noteVideo.videoTitle.substring(0, maxTitleLength) + '...' 
              : noteVideo.videoTitle;
            videoElement.textContent = `Video: ${truncatedTitle}`;
            videoElement.style.color = '#6e7681';
            videoElement.style.fontSize = '11px';
            videoElement.style.marginTop = '4px';
            videoElement.style.marginBottom = '4px';
            videoElement.style.fontStyle = 'italic';
            noteElement.appendChild(videoElement);
          } else if (note.videoTitle) {
            // Fallback: use videoTitle from note if available
            const videoElement = document.createElement('div');
            videoElement.className = 'message-video';
            const maxTitleLength = 40;
            const truncatedTitle = note.videoTitle.length > maxTitleLength 
              ? note.videoTitle.substring(0, maxTitleLength) + '...' 
              : note.videoTitle;
            videoElement.textContent = `Video: ${truncatedTitle}`;
            videoElement.style.color = '#6e7681';
            videoElement.style.fontSize = '11px';
            videoElement.style.marginTop = '4px';
            videoElement.style.marginBottom = '4px';
            videoElement.style.fontStyle = 'italic';
            noteElement.appendChild(videoElement);
          }

          // Add players information if present
          if (note.players && Array.isArray(note.players) && note.players.length > 0) {
            chrome.storage.local.get(['players'], (result) => {
              if (handleStorageError(null, 'displayNote-players')) {
                return;
              }
              
              const players = result.players || [];
              const selectedPlayerObjects = [];
              const playerNames = [];
              
              // Handle both IDs and names (for backward compatibility and AI extraction)
              note.players.forEach(playerRef => {
                // Check if it's an ID (starts with 'player_')
                if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
                  const player = players.find(p => p.id === playerRef);
                  if (player) {
                    selectedPlayerObjects.push(player);
                  }
                } else if (typeof playerRef === 'string') {
                  // It's a name string - try to find by name
                  const playerNameLower = playerRef.toLowerCase().trim();
                  const player = players.find(p => {
                    const fullName = (p.fullName || '').toLowerCase();
                    const name = (p.name || '').toLowerCase();
                    const surname = (p.surname || '').toLowerCase();
                    return fullName === playerNameLower || 
                           name === playerNameLower || 
                           surname === playerNameLower ||
                           fullName.includes(playerNameLower) ||
                           playerNameLower.includes(fullName);
                  });
                  if (player) {
                    selectedPlayerObjects.push(player);
                  } else {
                    // If not found, use the name as-is (fallback)
                    // But skip if it looks like message text (too long or contains punctuation that suggests it's not a name)
                    if (playerRef.length < 100 && !playerRef.includes('!') && !playerRef.includes('?') && !playerRef.includes('.')) {
                      playerNames.push(playerRef);
                    }
                  }
                }
              });
              
              if (selectedPlayerObjects.length > 0 || playerNames.length > 0) {
                const playersElement = document.createElement('div');
                playersElement.className = 'message-players';
                playersElement.style.color = '#8b949e';
                playersElement.style.fontSize = '12px';
                playersElement.style.marginTop = '4px';
                playersElement.style.marginBottom = '4px';
                playersElement.style.display = 'flex';
                playersElement.style.flexWrap = 'wrap';
                playersElement.style.gap = '6px';
                
                const playersLabel = document.createElement('span');
                playersLabel.textContent = 'Players: ';
                playersLabel.style.fontWeight = '500';
                playersElement.appendChild(playersLabel);
                
                // Display matched players
                selectedPlayerObjects.forEach((player, index) => {
                  const playerTag = document.createElement('span');
                  const displayText = player.number ? 
                    `#${player.number} ${player.fullName || ''}`.trim() : 
                    (player.fullName || 'Unnamed');
                  playerTag.textContent = displayText;
                  playerTag.style.background = '#21262d';
                  playerTag.style.padding = '2px 6px';
                  playerTag.style.borderRadius = '4px';
                  playersElement.appendChild(playerTag);
                });
                
                // Display unmatched player names (fallback)
                playerNames.forEach((playerName, index) => {
                  const playerTag = document.createElement('span');
                  playerTag.textContent = playerName;
                  playerTag.style.background = '#21262d';
                  playerTag.style.padding = '2px 6px';
                  playerTag.style.borderRadius = '4px';
                  playersElement.appendChild(playerTag);
                });
                
                noteElement.appendChild(playersElement);
              }
            });
          }

          // Add events information if present
          if (note.events && Array.isArray(note.events) && note.events.length > 0) {
            const eventsElement = document.createElement('div');
            eventsElement.className = 'message-events';
            eventsElement.style.color = '#8b949e';
            eventsElement.style.fontSize = '12px';
            eventsElement.style.marginTop = '4px';
            eventsElement.style.marginBottom = '4px';
            eventsElement.style.display = 'flex';
            eventsElement.style.flexWrap = 'wrap';
            eventsElement.style.gap = '6px';
            
            const eventsLabel = document.createElement('span');
            eventsLabel.textContent = 'Events: ';
            eventsLabel.style.fontWeight = '500';
            eventsElement.appendChild(eventsLabel);
            
            note.events.forEach((event) => {
              const eventTag = document.createElement('span');
              eventTag.textContent = event;
              eventTag.style.background = '#21262d';
              eventTag.style.border = '1px solid #30363d';
              eventTag.style.borderRadius = '4px';
              eventTag.style.padding = '2px 6px';
              eventsElement.appendChild(eventTag);
            });
            
            noteElement.appendChild(eventsElement);
          }

          // Add zones information if present
          if (note.zones && Array.isArray(note.zones) && note.zones.length > 0) {
            const zonesElement = document.createElement('div');
            zonesElement.className = 'message-zones';
            zonesElement.style.color = '#8b949e';
            zonesElement.style.fontSize = '12px';
            zonesElement.style.marginTop = '4px';
            zonesElement.style.marginBottom = '4px';
            zonesElement.style.display = 'flex';
            zonesElement.style.flexWrap = 'wrap';
            zonesElement.style.gap = '6px';
            
            const zonesLabel = document.createElement('span');
            zonesLabel.textContent = 'Zones: ';
            zonesLabel.style.fontWeight = '500';
            zonesElement.appendChild(zonesLabel);
            
            // Sort zones numerically
            const sortedZones = [...note.zones].sort((a, b) => a - b);
            
            sortedZones.forEach((zone) => {
              const zoneTag = document.createElement('span');
              zoneTag.textContent = `Zone ${zone}`;
              zoneTag.style.background = '#21262d';
              zoneTag.style.border = '1px solid #30363d';
              zoneTag.style.borderRadius = '4px';
              zoneTag.style.padding = '2px 6px';
              zonesElement.appendChild(zoneTag);
            });
            
            noteElement.appendChild(zonesElement);
          }

          // Add intensity information if present
          if (note.intensity !== null && note.intensity !== undefined) {
            const intensityElement = document.createElement('div');
            intensityElement.className = 'message-intensity';
            intensityElement.style.color = '#8b949e';
            intensityElement.style.fontSize = '12px';
            intensityElement.style.marginTop = '4px';
            intensityElement.style.marginBottom = '4px';
            intensityElement.style.display = 'flex';
            intensityElement.style.alignItems = 'center';
            intensityElement.style.gap = '8px';
            
            const intensityLabel = document.createElement('span');
            intensityLabel.textContent = 'Intensity: ';
            intensityLabel.style.fontWeight = '500';
            intensityElement.appendChild(intensityLabel);
            
            const intensityValue = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'][note.intensity] || 'Unknown';
            const intensityTag = document.createElement('span');
            intensityTag.textContent = intensityValue;
            
            // Color based on intensity value
            const colors = ['#1f6feb', '#58a6ff', '#c9d1d9', '#f85149', '#da3633'];
            intensityTag.style.background = colors[note.intensity] || '#21262d';
            intensityTag.style.border = '1px solid #30363d';
            intensityTag.style.borderRadius = '4px';
            intensityTag.style.padding = '2px 6px';
            intensityTag.style.color = '#ffffff';
            intensityElement.appendChild(intensityTag);
            
            noteElement.appendChild(intensityElement);
          }

          // Add note content (without timecode if it was extracted)
          const contentElement = document.createElement('div');
          contentElement.className = 'content';
          contentElement.textContent = displayContent;
          noteElement.appendChild(contentElement);

          // Add note actions (edit/delete buttons)
          const noteActions = document.createElement('div');
          noteActions.className = 'message-actions';
          
          // Mark checkbox for enhancement - always visible on the right side
          const markCheckboxContainer = document.createElement('div');
          markCheckboxContainer.className = 'distats-message-mark-checkbox-container';
          
          const markCheckbox = document.createElement('input');
          markCheckbox.type = 'checkbox';
          markCheckbox.className = 'distats-message-mark-checkbox';
          markCheckbox.dataset.noteTimestamp = note.timestamp;
          markCheckbox.title = 'Mark for enhancement';
          
          markCheckboxContainer.appendChild(markCheckbox);
          noteActions.appendChild(markCheckboxContainer);
          
          // Edit button
          const editBtn = document.createElement('button');
          editBtn.className = 'message-edit-btn';
          editBtn.innerHTML = '✎';
          editBtn.title = 'Edit message';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editNoteIn(noteElement, note);
          });
          
          // Delete button
          const deleteBtn = document.createElement('button');
          deleteBtn.className = 'message-delete-btn';
          deleteBtn.innerHTML = '×';
          deleteBtn.title = 'Delete message';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteNoteIn(noteElement, note);
          });
          
          noteActions.appendChild(editBtn);
          noteActions.appendChild(deleteBtn);
          noteElement.appendChild(noteActions);

          notesList.appendChild(noteElement);
        });

        // Scroll to bottom
        notesList.scrollTop = notesList.scrollHeight;
      }
    });
    } catch (e) {
      handleStorageError(e, 'updateNotesDisplay');
      notesList.innerHTML = `
        <div style="color: #ff6b6b; text-align: center; padding: 20px;">
          Error loading notes. Please reload the page.
        </div>
      `;
    }
  }

  // Seek to specific time in video (platform-agnostic)
  window.distatsSeekToTime = function(seconds) {
    
    try {
      // Try to find video element
      let video = document.querySelector('video');
      
      // Platform-specific video element finding
      if (platform === 'youtube') {
        // Try multiple YouTube selectors
        const selectors = [
          '#movie_player video',
          '.html5-video-player video',
          'ytd-player video',
          'video.html5-main-video',
          'video'
        ];
        
        for (const selector of selectors) {
          video = document.querySelector(selector);
          if (video) {
            break;
          }
        }
        
        // If still no video, try YouTube's player API
        if (!video) {
          try {
            // Try to access YouTube player through various methods
            const moviePlayer = document.querySelector('#movie_player');
            if (moviePlayer) {
              // Try to get player from YouTube's internal API
              if (window.yt && window.yt.player) {
                const player = window.yt.player.getPlayerByElement(moviePlayer);
                if (player && typeof player.seekTo === 'function') {
                  player.seekTo(seconds, true);
                  if (typeof player.playVideo === 'function') {
                    player.playVideo();
                  }
                  return;
                }
              }
              
              // Try accessing video through movie player
              const moviePlayerVideo = moviePlayer.querySelector('video');
              if (moviePlayerVideo) {
                video = moviePlayerVideo;
              }
            }
          } catch (e) {
            console.warn('YouTube API seek failed:', e);
          }
        }
        
        // Last resort: wait a bit and try again (YouTube might be loading)
        if (!video) {
          setTimeout(() => {
            const retryVideo = document.querySelector('video');
            if (retryVideo) {
              retryVideo.currentTime = seconds;
              retryVideo.play();
            }
          }, 500);
        }
      } else if (!video && platform === 'dailymotion') {
        // Dailymotion also uses iframe
        const iframe = document.querySelector('iframe[src*="dailymotion"]');
        if (iframe && iframe.contentWindow) {
          iframe.contentWindow.postMessage({
            method: 'seek',
            value: seconds
          }, '*');
          return;
        }
      }
      
      // Universal method: use video element
      if (video) {
        // Ensure video is ready
        if (video.readyState >= 2) { // HAVE_CURRENT_DATA or higher
          video.currentTime = seconds;
          
          // Try to play (might be paused)
          const playPromise = video.play();
          if (playPromise !== undefined) {
            playPromise
              .then(() => {
              })
              .catch(error => {
                // Video is seeked but not playing - user can click play
              });
          }
        } else {
          // Video not ready yet, wait for it
          video.addEventListener('loadeddata', () => {
            video.currentTime = seconds;
            video.play().catch(() => {});
          }, { once: true });
          
          // Also try immediately in case it loads quickly
          video.currentTime = seconds;
        }
      } else {
        console.warn('Could not find video element on', platform);
        // Fallback: try multiple times with delays
        let retries = 0;
        const maxRetries = 3;
        const retryInterval = setInterval(() => {
          retries++;
          const videoRetry = document.querySelector('video');
          if (videoRetry) {
            videoRetry.currentTime = seconds;
            videoRetry.play().catch(e => console.log('Play prevented:', e));
            clearInterval(retryInterval);
          } else if (retries >= maxRetries) {
            clearInterval(retryInterval);
            console.warn('Could not find video after', maxRetries, 'retries');
          }
        }, 500);
      }
    } catch (e) {
      console.error('Error seeking to time:', e);
    }
  };

  // Get current video ID and URL (platform-specific)
  function getCurrentVideoId() {
    const url = window.location.href;
    currentVideoUrl = url; // Store full URL
    
    if (platform === 'youtube') {
      const urlParams = new URLSearchParams(window.location.search);
      currentVideoId = urlParams.get('v');
    } else if (platform === 'dailymotion') {
      const match = url.match(/dailymotion\.com\/video\/([^/?]+)/);
      currentVideoId = match ? match[1] : null;
    } else if (platform === 'twitch') {
      // Match both /videos/ (plural) and /video/ (singular) patterns
      // Also handle URLs with channel name: twitch.tv/channelname/video/123456
      const match = url.match(/twitch\.tv\/(?:[^\/]+\/)?(?:videos|video)\/(\d+)/);
      currentVideoId = match ? match[1] : null;
    }
    
    
    // Update video link display
    updateVideoLinkDisplay();
    
    return currentVideoId;
  }

  // Update video link display
  function updateVideoLinkDisplay() {
    const videoLinkSection = document.getElementById('distatsVideoLinkSection');
    const videoLink = document.getElementById('distatsVideoLink');
    const videoLinkTitle = videoLink ? videoLink.querySelector('.distats-video-link-title') : null;
    
    if (videoLinkSection && videoLink && currentVideoUrl) {
      videoLink.href = currentVideoUrl;
      
      // Try to get saved video title from analysis first
      if (!isExtensionContextValid()) {
        // Fallback to page title if extension context is invalid
      const title = getVideoTitle();
      let displayText = '';
        if (title && title !== `${platform} Video`) {
          const maxLength = 35;
          displayText = title.length > maxLength
            ? title.substring(0, maxLength) + '...'
            : title;
        } else {
          const maxLength = 35;
          displayText = currentVideoUrl.length > maxLength
            ? currentVideoUrl.substring(0, maxLength) + '...'
            : currentVideoUrl;
        }
        if (videoLinkTitle) {
          videoLinkTitle.textContent = displayText;
        }
        videoLink.title = currentVideoUrl;
        videoLinkSection.style.display = 'flex';
        return;
      }
      
      try {
        chrome.storage.local.get(['analyses'], (result) => {
          if (handleStorageError(null, 'updateVideoLinkDisplay')) {
            return;
          }
          
          const analyses = result.analyses || [];
          let savedTitle = null;
          
          // Get saved video title from current analysis
          if (currentAnalysisId) {
            const analysis = analyses.find(a => a.id === currentAnalysisId);
            if (analysis && analysis.videoTitle) {
              // Only use saved title if it's not a placeholder
              if (analysis.videoTitle !== `${analysis.platform || platform} Video`) {
                savedTitle = analysis.videoTitle;
              }
            }
          }
          
          // Determine display text: prioritize saved title, then page title, then URL
          let displayText = '';
          const maxLength = 35;
          
          if (savedTitle) {
            // Use saved title from analysis
            displayText = savedTitle.length > maxLength
              ? savedTitle.substring(0, maxLength) + '...'
              : savedTitle;
          } else {
            // Fallback to page title
            const title = getVideoTitle();
      if (title && title !== `${platform} Video`) {
              displayText = title.length > maxLength
                ? title.substring(0, maxLength) + '...'
                : title;
      } else {
              // Fallback to URL
        displayText = currentVideoUrl.length > maxLength 
          ? currentVideoUrl.substring(0, maxLength) + '...'
          : currentVideoUrl;
            }
      }
      
      // Update title span to show the video title
      if (videoLinkTitle) {
        videoLinkTitle.textContent = displayText;
      }
      videoLink.title = currentVideoUrl; // Full URL in tooltip
      
      videoLinkSection.style.display = 'flex';
        });
      } catch (e) {
        handleStorageError(e, 'updateVideoLinkDisplay');
        // Fallback to page title on error
        const title = getVideoTitle();
        let displayText = '';
        if (title && title !== `${platform} Video`) {
          const maxLength = 35;
          displayText = title.length > maxLength
            ? title.substring(0, maxLength) + '...'
            : title;
        } else {
          const maxLength = 35;
          displayText = currentVideoUrl.length > maxLength
            ? currentVideoUrl.substring(0, maxLength) + '...'
            : currentVideoUrl;
        }
        if (videoLinkTitle) {
          videoLinkTitle.textContent = displayText;
        }
        videoLink.title = currentVideoUrl;
        videoLinkSection.style.display = 'flex';
      }
    }
  }

  // Update videos list display
  function updateVideosDisplay() {
    const videosSection = document.getElementById('distatsVideosSection');
    const videosList = document.getElementById('distatsVideosList');
    
    if (!videosSection || !videosList) {
      return;
    }

    if (!currentAnalysisId) {
      videosSection.style.display = 'none';
      return;
    }

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'updateVideosDisplay')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);

        if (!analysis) {
          videosSection.style.display = 'none';
          return;
        }

        // Get videos from videos array or legacy structure
        let videos = [];
        if (analysis.videos && analysis.videos.length > 0) {
          videos = analysis.videos;
          console.log('updateVideosDisplay: Found', videos.length, 'videos in analysis.videos array:', videos.map(v => ({ url: v.videoUrl, title: v.videoTitle, id: v.videoId })));
        } else if (analysis.videoUrl) {
          // Migrate legacy structure
          videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
          console.log('updateVideosDisplay: Migrated legacy video structure, found 1 video');
        } else {
          // No videos is a valid state (project might be created without videos initially)
          // Initialize empty videos array if it doesn't exist
          if (!analysis.videos) {
            analysis.videos = [];
          }
          // Only log debug info, not a warning
          console.debug('updateVideosDisplay: No videos found in analysis', {
            analysisId: analysis?.id || 'unknown',
            hasVideosArray: Array.isArray(analysis.videos),
            videosLength: analysis.videos?.length || 0,
            hasLegacyVideoUrl: !!analysis.videoUrl
          });
        }

        if (videos.length === 0) {
          videosSection.style.display = 'none';
          return;
        }

        // Display videos list
        videosList.innerHTML = '';
        console.log('updateVideosDisplay: Displaying', videos.length, 'videos');
        videos.forEach((video, index) => {
          const videoItem = document.createElement('div');
          videoItem.className = 'project-video-item';
          
          const videoLink = document.createElement('a');
          videoLink.href = video.videoUrl;
          videoLink.className = 'project-video-item-link';
          videoLink.title = video.videoUrl;
          videoLink.style.cursor = 'pointer';
          
          // Add click handler to open video and bring to front
          videoLink.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (video.videoUrl) {
              window.open(video.videoUrl, '_blank');
            }
          });
          
          const videoTitle = document.createElement('span');
          videoTitle.className = 'project-video-item-title';
          let titleText = video.videoTitle || 'Video';
          
          // Try to decode if it looks like base64 (contains only base64 characters and is long)
          if (titleText && /^[A-Za-z0-9+/=]+$/.test(titleText) && titleText.length > 20) {
            try {
              const decoded = atob(titleText);
              // Check if decoded string looks like valid text (not binary)
              if (decoded && /^[\x20-\x7E\s]+$/.test(decoded)) {
                titleText = decoded;
                // Update the title in storage
                video.videoTitle = decoded;
                chrome.storage.local.get(['analyses'], (result) => {
                  const analyses = result.analyses || [];
                  const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
                  if (analysisIndex !== -1) {
                    const videoIndex = analyses[analysisIndex].videos.findIndex(v => 
                      v.videoUrl === video.videoUrl || 
                      (v.videoId === video.videoId && v.platform === video.platform)
                    );
                    if (videoIndex !== -1) {
                      analyses[analysisIndex].videos[videoIndex].videoTitle = decoded;
                      chrome.storage.local.set({ analyses: analyses });
                    }
                  }
                });
              }
            } catch (e) {
              // Not valid base64, use as-is
            }
          }
          
          videoTitle.textContent = titleText;
          
          const deleteBtn = document.createElement('button');
          deleteBtn.className = 'project-video-item-delete';
          deleteBtn.innerHTML = '×';
          deleteBtn.title = 'Remove video from project';
          deleteBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            removeVideoFromProject(video.videoUrl, video.videoId, video.platform);
          });
          
          videoLink.appendChild(videoTitle);
          videoItem.appendChild(videoLink);
          videoItem.appendChild(deleteBtn);
          videosList.appendChild(videoItem);
        });

        videosSection.style.display = 'block';
      });
    } catch (e) {
      handleStorageError(e, 'updateVideosDisplay');
    }
  }

  // Remove video from project
  function removeVideoFromProject(videoUrl, videoId, videoPlatform) {
    if (!currentAnalysisId) {
      return;
    }

    const confirmRemove = confirm('Are you sure you want to remove this video from the project?');
    if (!confirmRemove) {
      return;
    }

    if (!isExtensionContextValid()) {
      alert('Extension context invalidated. Please reload the page.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'removeVideoFromProject')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex === -1) {
          return;
        }

        const analysis = analyses[analysisIndex];
        
        // Initialize videos array if needed
        if (!analysis.videos) {
          if (analysis.videoUrl) {
            analysis.videos = [{
              videoId: analysis.videoId,
              videoUrl: analysis.videoUrl,
              videoTitle: analysis.videoTitle || 'Video',
              platform: analysis.platform || 'video',
              addedAt: analysis.createdAt || Date.now()
            }];
          } else {
            analysis.videos = [];
          }
        }

        // Remove the video
        analysis.videos = analysis.videos.filter(v => 
          !(v.videoUrl === videoUrl || (v.videoId === videoId && v.platform === videoPlatform))
        );

        // Update legacy fields if videos array is not empty
        if (analysis.videos.length > 0) {
          const firstVideo = analysis.videos[0];
          analysis.videoId = firstVideo.videoId;
          analysis.videoUrl = firstVideo.videoUrl;
          analysis.platform = firstVideo.platform;
          analysis.videoTitle = firstVideo.videoTitle;
        } else {
          // No videos left
          analysis.videoId = null;
          analysis.videoUrl = null;
          analysis.platform = null;
          analysis.videoTitle = null;
        }

        chrome.storage.local.set({ analyses: analyses }, () => {
          if (handleStorageError(null, 'removeVideoFromProject-set')) {
            return;
          }

          // Update displays
          updateVideosDisplay();
          updateVideoLinkDisplay();
        });
      });
    } catch (e) {
      handleStorageError(e, 'removeVideoFromProject');
    }
  }

  // Update project selector dropdown
  function updateProjectSelect() {
    const projectSelect = document.getElementById('distatsProjectSelect');
    if (!projectSelect) {
      return;
    }

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
        if (handleStorageError(null, 'updateProjectSelect')) {
          return;
        }

        const analyses = result.analyses || [];
        const currentId = result.currentAnalysisId;

        // Update export buttons visibility
        const exportProjectDropdownItem = document.getElementById('distatsExportProjectDropdownItem');
        if (exportProjectDropdownItem) {
          exportProjectDropdownItem.style.display = currentId ? 'flex' : 'none';
        }
        const exportNotesDropdownItem = document.getElementById('distatsExportNotesDropdownItem');
        if (exportNotesDropdownItem) {
          exportNotesDropdownItem.style.display = currentId ? 'flex' : 'none';
        }

        // Update project button text
        const projectButtonText = document.getElementById('distatsProjectButtonText');
        if (!projectButtonText) return;

        // Update button text based on selected project
        if (analyses.length === 0) {
          projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
          return;
        }

        // Find selected analysis
        const selectedAnalysis = analyses.find(a => a.id === currentId);
        if (selectedAnalysis) {
          projectButtonText.textContent = selectedAnalysis.name;
        } else {
          projectButtonText.textContent = window.i18n ? window.i18n.t('project.selectProject') : 'Select project';
        }
      });
    } catch (e) {
      handleStorageError(e, 'updateProjectSelect');
    }
  }

  // Get video title (platform-specific)
  function getVideoTitle() {
    try {
      // Auto-detect platform from URL if not set
      let detectedPlatform = platform;
      if (!detectedPlatform) {
        const url = window.location.href;
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
          detectedPlatform = 'youtube';
        } else if (url.includes('dailymotion.com')) {
          detectedPlatform = 'dailymotion';
        } else if (url.includes('twitch.tv')) {
          detectedPlatform = 'twitch';
        }
      }
      
      if (detectedPlatform === 'youtube') {
        // Try multiple selectors for YouTube (they change frequently)
        let titleElement = document.querySelector('h1.ytd-watch-metadata yt-formatted-string');
        if (!titleElement) {
          titleElement = document.querySelector('h1.ytd-video-primary-info-renderer');
        }
        if (!titleElement) {
          titleElement = document.querySelector('h1.title.style-scope.ytd-video-primary-info-renderer');
        }
        if (!titleElement) {
          titleElement = document.querySelector('h1.ytd-watch-metadata');
        }
        if (!titleElement) {
          // Try meta tag as fallback
          const metaTitle = document.querySelector('meta[property="og:title"]');
          if (metaTitle) {
            const title = metaTitle.getAttribute('content');
            if (title && !title.includes(' - YouTube')) {
              return title;
            }
          }
        }
        return titleElement ? titleElement.textContent.trim() : 'YouTube Video';
      } else if (detectedPlatform === 'dailymotion') {
        // Try multiple selectors for Dailymotion title
        let titleElement = document.querySelector('h1[data-testid="video-title"]');
        if (!titleElement) {
          titleElement = document.querySelector('h1.dmp_VideoTitle');
        }
        if (!titleElement) {
          titleElement = document.querySelector('h1');
        }
        if (!titleElement) {
          // Try meta tags
          const metaTitle = document.querySelector('meta[property="og:title"]');
          if (metaTitle) {
            const title = metaTitle.getAttribute('content');
            if (title && !title.includes(' - Dailymotion')) {
              return title.trim();
            }
          }
        }
        if (titleElement) {
          const title = titleElement.textContent || titleElement.innerText;
          return title ? title.trim() : 'Dailymotion Video';
        }
        return 'Dailymotion Video';
      } else if (detectedPlatform === 'twitch') {

        // Common UI elements to exclude (video controls, navigation, etc.)
        const excludedTexts = [
          'Browse', 'Home', 'Following', 'Browse Channels', 'Watch', 'Subscribe', 'Follow',
          'Twitch', 'Twitch Video', 'Click to unmute', 'Click to mute', 'Unmute', 'Mute',
          'Click to play', 'Play', 'Pause', 'Fullscreen', 'Theater mode', 'Settings',
          'Volume', 'Chat', 'Share', 'Report', 'Block'
        ];

        // PRIORITY 1: Try data-a-target="stream-title" and "vod-title" FIRST (most reliable)
        // This is the actual title element on the page
        const allStreamTitles = document.querySelectorAll('[data-a-target="stream-title"], [data-a-target="vod-title"]');

        // PRIORITY 1.5: Try other common Twitch title selectors for VOD pages
        if (allStreamTitles.length === 0) {
          // For VOD pages, try additional selectors that might contain the title
          const vodSelectors = [
            '[data-a-target="video-title"]',
            '[data-a-target*="title"]', // Any data-a-target containing "title"
            '[class*="video-title"]',
            '[class*="vod-title"]',
            'h1:not([class*="hidden"]):not([class*="player"]):not([class*="control"])',
            'h2:not([class*="hidden"]):not([class*="player"]):not([class*="control"])',
            // Try meta tags for VOD titles
            'meta[name="twitter:title"]',
            'meta[name="og:title"]'
          ];

          for (const selector of vodSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const elem of elements) {
              // Skip if element is a button or control element
              if (elem.tagName === 'BUTTON' ||
                  elem.getAttribute('role') === 'button' ||
                  elem.closest('button') ||
                  elem.closest('[role="button"]') ||
                  elem.closest('[class*="player"]') ||
                  elem.closest('[class*="control"]') ||
                  elem.closest('nav') ||
                  elem.closest('[data-a-target="channel-header"]')) {
                continue;
              }

              let title = null;

              // For meta tags, get the content attribute
              if (elem.tagName === 'META') {
                title = elem.getAttribute('content');
              } else {
                title = elem.textContent || elem.innerText;
              }

              if (title && title.trim()) {
                // Clean and validate the title
                let cleanTitle = title.trim()
                  .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
                  .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
                  .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
                  .trim();

                // Validate the title - exclude common UI elements
                const isExcluded = excludedTexts.some(excluded =>
                  cleanTitle === excluded ||
                  cleanTitle.toLowerCase() === excluded.toLowerCase() ||
                  cleanTitle.toLowerCase().includes(excluded.toLowerCase())
                );

                // Additional validation: title should be reasonably long and not look like a UI control
                const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(cleanTitle);

                if (cleanTitle &&
                    !isExcluded &&
                    !looksLikeControl &&
                    cleanTitle !== 'Twitch' &&
                    cleanTitle !== 'Twitch Video' &&
                    !cleanTitle.includes('Watch') &&
                    !cleanTitle.includes('Subscribe') &&
                    !cleanTitle.includes('Follow') &&
                    cleanTitle.length > 5) { // Increased minimum length to 5 to avoid short UI text
                  return cleanTitle;
                }
              }
            }
          }
        }

        for (const elem of allStreamTitles) {
          // Skip if element is a button or control element
          if (elem.tagName === 'BUTTON' || 
              elem.getAttribute('role') === 'button' ||
              elem.closest('button') ||
              elem.closest('[role="button"]') ||
              elem.closest('[class*="player"]') ||
              elem.closest('[class*="control"]')) {
            continue;
          }
          
          // Try multiple ways to get text from the element
          let title = null;
          
          // Method 1: Direct text content
          title = elem.textContent || elem.innerText;
          
          // Method 2: If no direct text, try to get from all text nodes recursively
          if (!title || title.trim() === '') {
            const walker = document.createTreeWalker(
              elem,
              NodeFilter.SHOW_TEXT,
              null,
              false
            );
            const textNodes = [];
            let node;
            while (node = walker.nextNode()) {
              const text = node.textContent?.trim();
              if (text && text.length > 0) {
                textNodes.push(text);
              }
            }
            if (textNodes.length > 0) {
              title = textNodes.join(' ').trim();
            }
          }
          
          // Method 3: Try first child element (but skip buttons/controls)
          if (!title || title.trim() === '') {
            const firstChild = elem.firstElementChild;
            if (firstChild && firstChild.tagName !== 'BUTTON' && firstChild.getAttribute('role') !== 'button') {
              title = firstChild.textContent || firstChild.innerText;
              // If first child also has children, try to get deeper
              if ((!title || title.trim() === '') && firstChild.children.length > 0) {
                title = Array.from(firstChild.children)
                  .filter(child => child.tagName !== 'BUTTON' && child.getAttribute('role') !== 'button')
                  .map(child => child.textContent || child.innerText)
                  .filter(text => text && text.trim())
                  .join(' ')
                  .trim();
              }
            }
          }
          
          // Method 4: Try all direct children (excluding buttons/controls)
          if (!title || title.trim() === '') {
            const childrenText = Array.from(elem.children)
              .filter(child => child.tagName !== 'BUTTON' && 
                             child.getAttribute('role') !== 'button' &&
                             !child.closest('button'))
              .map(child => child.textContent || child.innerText)
              .filter(text => text && text.trim())
              .join(' ')
              .trim();
            if (childrenText) {
              title = childrenText;
            }
          }
          
          // Method 5: Try aria-label or title attribute (but only if not a control)
          if ((!title || title.trim() === '') && 
              elem.getAttribute('role') !== 'button' &&
              !elem.closest('button')) {
            title = elem.getAttribute('aria-label') || elem.getAttribute('title');
          }
          
          // Clean and validate the title
          if (title && title.trim()) {
            // Remove common Twitch UI elements that might be in the text
            let cleanTitle = title.trim()
              .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
              .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
              .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
              .trim();
            
            // Validate the title - exclude common UI elements
            const isExcluded = excludedTexts.some(excluded => 
              cleanTitle === excluded || 
              cleanTitle.toLowerCase() === excluded.toLowerCase() ||
              cleanTitle.toLowerCase().includes(excluded.toLowerCase())
            );
            
            // Additional validation: title should be reasonably long and not look like a UI control
            const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(cleanTitle);
            
            if (cleanTitle && 
                !isExcluded &&
                !looksLikeControl &&
                cleanTitle !== 'Twitch' && 
                cleanTitle !== 'Twitch Video' && 
                !cleanTitle.includes('Watch') && 
                !cleanTitle.includes('Subscribe') &&
                !cleanTitle.includes('Follow') &&
                cleanTitle.length > 5) { // Increased minimum length to 5 to avoid short UI text
              return cleanTitle;
            }
          }
        }
        
        // PRIORITY 2: Try class-based selectors for Twitch title (fallback)
        // These are the actual title elements on modern Twitch pages
        const classBasedSelectors = [
          // Original selectors
          '.CoreText-sc-1txzju1-0.haaXAy',
          '.CoreText-sc-1txzju1-0',
          '[class*="CoreText-sc-1txzju1-0"][class*="haaXAy"]',
          '[class*="CoreText-sc-1txzju1-0"]',
          '.ScTitleText-sc-d9mj2s-0',
          '[class*="ScTitleText-sc-d9mj2s-0"]',
          'h1[class*="CoreText"]',
          'h2[class*="CoreText"]',
          'h1[class*="TitleText"]',
          'h2[class*="TitleText"]',

          // Additional selectors for VOD pages
          '[class*="video-title"]',
          '[class*="vod-title"]',
          'h1:not([class*="hidden"]):not([class*="player"]):not([class*="control"]):not([class*="nav"])',
          'h2:not([class*="hidden"]):not([class*="player"]):not([class*="control"]):not([class*="nav"])',
          'h3:not([class*="hidden"]):not([class*="player"]):not([class*="control"]):not([class*="nav"])',
          '[data-test-selector="video-title"]',
          '[data-test-selector*="title"]',
          // Try elements that might contain video information
          '.channel-info-content h1',
          '.channel-info-content h2',
          '.video-info h1',
          '.video-info h2',
          '.metadata-layout h1',
          '.metadata-layout h2'
        ];
        
        for (const selector of classBasedSelectors) {
          const elements = document.querySelectorAll(selector);
          for (const elem of elements) {
            // Skip if this element is inside a navigation, button, or player controls
            if (elem.closest('nav') || 
                elem.closest('button') || 
                elem.closest('[role="button"]') || 
                elem.closest('a[href*="/directory"]') ||
                elem.closest('[class*="player"]') ||
                elem.closest('[class*="control"]')) {
              continue;
            }
            
            let title = elem.textContent || elem.innerText;
            
            // If element has no direct text, try to get from children
            if (!title || title.trim() === '') {
              const childText = Array.from(elem.children)
                .filter(child => child.tagName !== 'BUTTON' && child.getAttribute('role') !== 'button')
                .map(child => child.textContent || child.innerText)
                .filter(text => text && text.trim())
                .join(' ')
                .trim();
              if (childText) {
                title = childText;
              }
            }
            
            // Use TreeWalker to get all text nodes if still empty
            if (!title || title.trim() === '') {
              const walker = document.createTreeWalker(
                elem,
                NodeFilter.SHOW_TEXT,
                null,
                false
              );
              const textNodes = [];
              let node;
              while (node = walker.nextNode()) {
                const text = node.textContent?.trim();
                if (text && text.length > 0) {
                  textNodes.push(text);
                }
              }
              if (textNodes.length > 0) {
                title = textNodes.join(' ').trim();
              }
            }
            
            // Check if title is excluded
            const isExcluded = excludedTexts.some(excluded => 
              title && (title.trim() === excluded || 
                       title.trim().toLowerCase() === excluded.toLowerCase() ||
                       title.trim().toLowerCase().includes(excluded.toLowerCase()))
            );
            
            // Additional validation: title should not look like a UI control
            const looksLikeControl = title && /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(title.trim());
            
            if (title && title.trim() && 
                !isExcluded &&
                !looksLikeControl &&
                title.trim() !== 'Twitch' && 
                title.trim() !== 'Twitch Video' && 
                !title.trim().includes('Watch') && 
                !title.trim().includes('Subscribe') &&
                !title.trim().includes('Follow') &&
                title.trim().length > 5) { // Increased minimum length
              return title.trim();
            }
          }
        }
        
        // PRIORITY 3: Try meta tags (fallback, less accurate)
        // Try multiple meta tag selectors
        const metaSelectors = [
          'meta[property="og:title"]',
          'meta[name="twitter:title"]',
          'meta[name="title"]',
          'meta[property="title"]'
        ];

        for (const selector of metaSelectors) {
          const metaTitle = document.querySelector(selector);
          if (metaTitle) {
            let title = metaTitle.getAttribute('content') || metaTitle.getAttribute('value');
            if (title && title.trim() && title.trim() !== 'Twitch' && title.trim() !== 'Twitch Video') {
              // Clean up common Twitch suffixes
              title = title.trim()
                .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
                .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
                .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
                .trim();

              // Check if title is excluded
              const isExcluded = excludedTexts.some(excluded =>
                title === excluded ||
                title.toLowerCase() === excluded.toLowerCase() ||
                title.toLowerCase().includes(excluded.toLowerCase())
              );

              // Check if looks like a control
              const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(title);

              if (title && title.length > 5 && !isExcluded && !looksLikeControl) {
                return title;
              }
            }
          }
        }
        
        // PRIORITY 4: Try <title> tag (last resort)
        const titleMeta = document.querySelector('title');
        if (titleMeta) {
          const title = titleMeta.textContent || titleMeta.innerText;
          if (title && title.trim() && !title.includes(' - Twitch') && title.trim() !== 'Twitch' && title.trim() !== 'Twitch Video') {
            // For VOD pages, the title might be structured differently
            // URL pattern: https://www.twitch.tv/channel/video/id
            const urlMatch = window.location.href.match(/twitch\.tv\/([^\/]+)\/video\/(\d+)/);
            if (urlMatch) {
              // This is a VOD page - try to extract title from the page title
              // Format might be "Video Title - Channel - Twitch" or similar
              let cleanTitle = title.trim();

              // Remove common suffixes
              cleanTitle = cleanTitle
                .replace(/\s*-\s*Twitch\s*$/, '')
                .replace(/\s*-\s*[^-]*\s*$/, '') // Remove last part after dash (usually channel name)
                .trim();

              // Check if title is excluded
              const isExcluded = excludedTexts.some(excluded =>
                cleanTitle === excluded ||
                cleanTitle.toLowerCase() === excluded.toLowerCase() ||
                cleanTitle.toLowerCase().includes(excluded.toLowerCase())
              );

              // Check if looks like a control
              const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(cleanTitle);

              if (cleanTitle && cleanTitle !== 'Twitch' && cleanTitle !== 'Twitch Video' && !isExcluded && !looksLikeControl && cleanTitle.length > 3) {
                return cleanTitle;
              }
            } else {
              // Regular processing for non-VOD pages
              const cleanTitle = title.trim().replace(/\s*-\s*Twitch\s*$/, '').trim();

              // Check if title is excluded
              const isExcluded = excludedTexts.some(excluded =>
                cleanTitle === excluded ||
                cleanTitle.toLowerCase() === excluded.toLowerCase() ||
                cleanTitle.toLowerCase().includes(excluded.toLowerCase())
              );

              // Check if looks like a control
              const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(cleanTitle);

              if (cleanTitle && cleanTitle !== 'Twitch' && cleanTitle !== 'Twitch Video' && !isExcluded && !looksLikeControl && cleanTitle.length > 5) {
                return cleanTitle;
              }
            }
          }
        }
        
        // Enhanced debugging - log what we actually found
        const debugInfo = {
          ogTitle: document.querySelector('meta[property="og:title"]')?.getAttribute('content'),
          twitterTitle: document.querySelector('meta[name="twitter:title"]')?.getAttribute('content'),
          pageTitle: document.querySelector('title')?.textContent,
          url: window.location.href,
          classBasedElements: [
            ...Array.from(document.querySelectorAll('[class*="CoreText-sc-1txzju1-0"]')).slice(0, 5),
            ...Array.from(document.querySelectorAll('[class*="ScTitleText-sc-d9mj2s-0"]')).slice(0, 5),
            ...Array.from(document.querySelectorAll('[class*="CoreText"]')).slice(0, 5),
            ...Array.from(document.querySelectorAll('[class*="TitleText"]')).slice(0, 5),
            ...Array.from(document.querySelectorAll('[class*="video-title"]')).slice(0, 3),
            ...Array.from(document.querySelectorAll('[class*="vod-title"]')).slice(0, 3)
          ].slice(0, 15).map(el => ({
            tag: el.tagName,
            text: el.textContent?.substring(0, 100),
            classes: el.className,
            dataTarget: el.getAttribute('data-a-target'),
            innerHTML: el.innerHTML?.substring(0, 150)
          })),
          allH1Elements: Array.from(document.querySelectorAll('h1')).slice(0, 10).map(h => ({
            text: h.textContent?.substring(0, 100),
            classes: h.className,
            dataTarget: h.getAttribute('data-a-target'),
            innerHTML: h.innerHTML?.substring(0, 150)
          })),
          allH2Elements: Array.from(document.querySelectorAll('h2')).slice(0, 10).map(h => ({
            text: h.textContent?.substring(0, 100),
            classes: h.className,
            dataTarget: h.getAttribute('data-a-target'),
            innerHTML: h.innerHTML?.substring(0, 150)
          })),
          streamTitleElements: Array.from(document.querySelectorAll('[data-a-target="stream-title"]')).map(el => ({
            tag: el.tagName,
            text: el.textContent?.substring(0, 100),
            innerHTML: el.innerHTML?.substring(0, 100)
          })),
          vodTitleElements: Array.from(document.querySelectorAll('[data-a-target="vod-title"]')).map(el => ({
            tag: el.tagName,
            text: el.textContent?.substring(0, 100)
          })),
          allDataTargetElements: Array.from(document.querySelectorAll('[data-a-target]')).filter(el =>
            el.getAttribute('data-a-target').includes('title')
          ).slice(0, 10).map(el => ({
            dataTarget: el.getAttribute('data-a-target'),
            tag: el.tagName,
            text: el.textContent?.substring(0, 100),
            classes: el.className
          })),
          h2Elements: Array.from(document.querySelectorAll('h2')).slice(0, 5).map(h => ({
            text: h.textContent?.substring(0, 50),
            classes: h.className,
            dataTarget: h.getAttribute('data-a-target')
          })),
          h1Elements: Array.from(document.querySelectorAll('h1')).slice(0, 5).map(h => ({
            text: h.textContent?.substring(0, 50),
            classes: h.className,
            dataTarget: h.getAttribute('data-a-target')
          }))
        };
        console.warn('Could not find Twitch title from any source. Available elements:', JSON.stringify(debugInfo, null, 2));
        
        // Last resort: try to get any meaningful text from the page
        // Look for any element with "title" in class name or data attribute
        const titleCandidates = document.querySelectorAll('[class*="title" i], [data-a-target*="title" i], [aria-label*="title" i]');
        for (const candidate of titleCandidates) {
          // Skip navigation elements, buttons, and player controls
          if (candidate.closest('nav') ||
              candidate.closest('button') ||
              candidate.closest('[role="button"]') ||
              candidate.closest('[class*="player"]') ||
              candidate.closest('[class*="control"]')) {
            continue;
          }

          const text = candidate.textContent || candidate.innerText || candidate.getAttribute('aria-label');

          // Check if text is excluded
          const isExcluded = excludedTexts.some(excluded =>
            text && (text.trim() === excluded ||
                     text.trim().toLowerCase() === excluded.toLowerCase() ||
                     text.trim().toLowerCase().includes(excluded.toLowerCase()))
          );

          // Check if looks like a control
          const looksLikeControl = text && /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(text.trim());

          if (text && text.trim().length > 5 && text.trim().length < 200 &&
              !isExcluded &&
              !looksLikeControl &&
              !text.includes('Twitch') && !text.includes('Watch') &&
              !text.includes('Subscribe') && !text.includes('Follow')) {
            return text.trim();
          }
        }

        // Additional last resort: Look for any prominent text elements that might be titles
        // This is specifically for VOD pages where the title might not be in standard locations
        const additionalSelectors = [
          'h3:not([class*="hidden"]):not([class*="player"]):not([class*="control"]):not([class*="nav"])',
          'h4:not([class*="hidden"]):not([class*="player"]):not([class*="control"]):not([class*="nav"])',
          '.channel-info-content p:first-child',
          '.video-info p:first-child',
          '[data-a-target="video-metadata"] p:first-child',
          '[data-a-target="video-description"] p:first-child'
        ];

        for (const selector of additionalSelectors) {
          const elements = document.querySelectorAll(selector);
          for (const elem of elements) {
            if (elem.closest('nav') ||
                elem.closest('button') ||
                elem.closest('[role="button"]') ||
                elem.closest('[class*="player"]') ||
                elem.closest('[class*="control"]')) {
              continue;
            }

            const text = elem.textContent || elem.innerText;

            // Check if text is excluded
            const isExcluded = excludedTexts.some(excluded =>
              text && (text.trim() === excluded ||
                       text.trim().toLowerCase() === excluded.toLowerCase() ||
                       text.trim().toLowerCase().includes(excluded.toLowerCase()))
            );

            // Check if looks like a control
            const looksLikeControl = text && /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(text.trim());

            if (text && text.trim().length > 5 && text.trim().length < 200 &&
                !isExcluded &&
                !looksLikeControl &&
                !text.includes('Twitch') && !text.includes('Watch') &&
                !text.includes('Subscribe') && !text.includes('Follow')) {
              return text.trim();
            }
          }
        }
        
        return 'Twitch Video';
      }
      
      // Fallback: try to get from meta tags
      const metaTitle = document.querySelector('meta[property="og:title"]');
      if (metaTitle) {
        const title = metaTitle.getAttribute('content');
        if (title) {
          return title.trim();
        }
      }
      
      return detectedPlatform ? `${detectedPlatform} Video` : 'Video';
    } catch (e) {
      console.warn('Error getting video title:', e);
      return platform ? `${platform} Video` : 'Video';
    }
  }

  // Normalize URL for comparison (remove time parameters and fragments)
  function normalizeUrlForComparison(url) {
    if (!url) return '';
    try {
      const urlObj = new URL(url);
      urlObj.searchParams.delete('t');
      urlObj.searchParams.delete('start');
      urlObj.searchParams.delete('time');
      urlObj.hash = '';
      return urlObj.toString();
    } catch {
      return url.split('?')[0].split('#')[0];
    }
  }

  // Update video title in analysis from the actual page
  function updateVideoTitleInAnalysis() {
    if (!currentAnalysisId) {
      return;
    }

    // Get the real video title from the page
    const realVideoTitle = getVideoTitle();
    // Don't update if we can't get a real title or if it's just a default placeholder
    const excludedTitles = [
      'Browse', 'Home', 'Following', 'Browse Channels', 'Video', 'Twitch Video', 'YouTube Video', 'Dailymotion Video',
      'Click to unmute', 'Click to mute', 'Unmute', 'Mute', 'Click to play', 'Play', 'Pause', 'Fullscreen',
      'Theater mode', 'Settings', 'Volume', 'Chat', 'Share', 'Report', 'Block'
    ];
    const isExcludedTitle = excludedTitles.some(excluded => 
      realVideoTitle === excluded || 
      realVideoTitle === `${platform} Video` ||
      realVideoTitle?.toLowerCase() === excluded.toLowerCase() ||
      realVideoTitle?.toLowerCase().includes(excluded.toLowerCase())
    );
    
    // Check if title looks like a UI control
    const looksLikeControl = realVideoTitle && /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(realVideoTitle.trim());
    
    if (!realVideoTitle || 
        isExcludedTitle ||
        looksLikeControl ||
        realVideoTitle.trim().length < 5) { // Increased minimum length
      return; // Don't update if we can't get a real title
    }

    if (!isExtensionContextValid()) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        if (handleStorageError(null, 'updateVideoTitleInAnalysis')) {
          return;
        }

        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          let needsUpdate = false;
          
          // Update videoTitle in videos array for the current video only
          if (analysis.videos && analysis.videos.length > 0) {
            // Find the video matching current video URL or ID (with normalized URL comparison)
            const currentVideoUrl = window.location.href;
            const normalizedCurrentUrl = normalizeUrlForComparison(currentVideoUrl);
            const currentVideoId = getCurrentVideoId();
            const currentPlatform = platform || (currentVideoUrl.includes('twitch.tv') ? 'twitch' : 
                                                      currentVideoUrl.includes('youtube.com') || currentVideoUrl.includes('youtu.be') ? 'youtube' :
                                                      currentVideoUrl.includes('dailymotion.com') ? 'dailymotion' : 'video');
            
            const videoIndex = analysis.videos.findIndex(v => {
              const normalizedVideoUrl = normalizeUrlForComparison(v.videoUrl);
              return normalizedVideoUrl === normalizedCurrentUrl || 
                     (v.videoId === currentVideoId && v.platform === currentPlatform);
            });
            
            if (videoIndex !== -1) {
              const existingTitle = analysis.videos[videoIndex].videoTitle;
              // Only update if:
              // 1. The new title is different AND
              // 2. The existing title is a default/placeholder OR the new title is clearly better (longer, more descriptive)
              const isExistingTitleDefault = !existingTitle || 
                                             existingTitle === 'Video' ||
                                             existingTitle === 'Twitch Video' ||
                                             existingTitle === 'YouTube Video' ||
                                             existingTitle === 'Dailymotion Video' ||
                                             existingTitle.length < 5;
              
              if (existingTitle !== realVideoTitle && 
                  (isExistingTitleDefault || realVideoTitle.length > existingTitle.length)) {
                analysis.videos[videoIndex].videoTitle = realVideoTitle;
                needsUpdate = true;
                console.log(`Updated video title from "${existingTitle}" to "${realVideoTitle}"`);
              } else if (existingTitle !== realVideoTitle) {
                console.log(`Skipped updating video title: existing "${existingTitle}" seems better than "${realVideoTitle}"`);
              }
            }
          }
          
          // Update legacy videoTitle field only if this is the first video or if it matches current video
          if (analysis.videos && analysis.videos.length > 0) {
            const currentVideoUrl = window.location.href;
            const normalizedCurrentUrl = normalizeUrlForComparison(currentVideoUrl);
            const isFirstVideo = analysis.videos[0] && 
                                 (normalizeUrlForComparison(analysis.videos[0].videoUrl) === normalizedCurrentUrl);
            
            if (isFirstVideo && analysis.videoTitle !== realVideoTitle) {
              analysis.videoTitle = realVideoTitle;
              needsUpdate = true;
            }
          } else if (analysis.videoTitle !== realVideoTitle) {
            // No videos array, update legacy field
            analysis.videoTitle = realVideoTitle;
            needsUpdate = true;
          }
          
          if (needsUpdate) {
            chrome.storage.local.set({ analyses: analyses }, () => {
              if (handleStorageError(null, 'updateVideoTitleInAnalysis-set')) {
                return;
              }
              // Update displays
              updateVideoLinkDisplay();
              updateVideosDisplay();
              // Refresh timeline video selector if timeline is open
              const timelinePanel = document.getElementById('distatsTimelinePanel');
              if (timelinePanel && !timelinePanel.classList.contains('hidden')) {
                populateTimelineVideoSelect();
              }
            });
          }
        }
      });
    } catch (e) {
      handleStorageError(e, 'updateVideoTitleInAnalysis');
    }
  }

  // Load current analysis
  function loadCurrentAnalysis() {
    // Prevent recursive calls
    if (isLoadingAnalysis) {
      return;
    }
    
    isLoadingAnalysis = true;
    
    // Ensure we have current video info
    if (!currentVideoUrl) {
      currentVideoUrl = window.location.href;
    }
    if (!currentVideoId) {
      currentVideoId = getCurrentVideoId();
    }
    
    // Normalize current URL for comparison
    const normalizedCurrentUrl = normalizeUrlForComparison(currentVideoUrl);

    if (!isExtensionContextValid()) {
      console.warn('Extension context invalidated in loadCurrentAnalysis');
      isLoadingAnalysis = false;
      return;
    }

    try {
      chrome.storage.local.get(['currentAnalysisId', 'analyses'], (result) => {
        if (handleStorageError(null, 'loadCurrentAnalysis')) {
          isLoadingAnalysis = false;
          return;
        }

        const analyses = result.analyses || [];
        const savedAnalysisId = result.currentAnalysisId;

        // Priority 1: Use savedAnalysisId if it exists (user's explicit choice)
        if (savedAnalysisId) {
          const savedAnalysis = analyses.find(a => a.id === savedAnalysisId);
          if (savedAnalysis) {
            // User selected this project, use it even if video doesn't match
            // Only update storage if the ID actually changed
            if (currentAnalysisId !== savedAnalysisId) {
              currentAnalysisId = savedAnalysisId;
              
              // Update video info if the project has video URL
              if (savedAnalysis.videoUrl) {
                currentVideoUrl = savedAnalysis.videoUrl;
              }
              // Update video ID if available
              if (savedAnalysis.videoId) {
                currentVideoId = savedAnalysis.videoId;
              }
              
              updateProjectSelect();
              updateVideosDisplay();
              updateVideoLinkDisplay();
              updateNotesDisplay();
              // Initialize selected team from analysis
              selectedTeam = savedAnalysis.selectedTeam || null;
              renderTeamSelector('');
              updateSelectedTeamDisplay();
              renderPlayerSelector('');
              updateSelectedPlayersDisplay();
              renderEventSelector('');
              updateSelectedEventsDisplay();
              renderZonesSelector('');
              updateSelectedZonesDisplay();
              
              // Fetch and save real video title after a delay to ensure page is loaded
              setTimeout(() => {
                updateVideoTitleInAnalysis();
              }, 2000);
            } else {
              // ID is already set, just refresh displays
              updateProjectSelect();
              updateVideosDisplay();
              updateVideoLinkDisplay();
              updateNotesDisplay();
              renderTeamSelector('');
              updateSelectedTeamDisplay();
              renderPlayerSelector('');
              updateSelectedPlayersDisplay();
              renderEventSelector('');
              updateSelectedEventsDisplay();
              renderZonesSelector('');
              updateSelectedZonesDisplay();
            }
            isLoadingAnalysis = false;
            return;
          } else {
            // Saved analysis doesn't exist anymore, clear it
            currentAnalysisId = null;
            chrome.storage.local.set({ currentAnalysisId: null }, () => {
              handleStorageError(null, 'loadCurrentAnalysis-clear');
            });
            // Update project select to hide dropdown if no projects
            updateProjectSelect();
          }
        }

        // Priority 2: If no savedAnalysisId, look for a project matching this video
        const normalizedCurrentUrl = normalizeUrlForComparison(currentVideoUrl);
        const projectForThisVideo = analyses.find(a => {
          // Check legacy videoUrl field
          if (a.videoUrl && normalizeUrlForComparison(a.videoUrl) === normalizedCurrentUrl) {
            return true;
          }
          // Check videoId and platform match
          if (a.videoId === currentVideoId && a.platform === platform) {
            return true;
          }
          // Check videos array for matching video
          if (a.videos && Array.isArray(a.videos) && a.videos.length > 0) {
            return a.videos.some(v => {
              if (!v.videoUrl) return false;
              const normalizedVideoUrl = normalizeUrlForComparison(v.videoUrl);
              return normalizedVideoUrl === normalizedCurrentUrl || 
                     (v.videoId === currentVideoId && v.platform === platform);
            });
          }
          return false;
        });

        if (projectForThisVideo) {
          // Use the project for this video
          // Check if current video is in the project's videos array, if not add it
          const videoInProject = projectForThisVideo.videos && projectForThisVideo.videos.some(v => {
            if (!v.videoUrl) return false;
            const normalizedVideoUrl = normalizeUrlForComparison(v.videoUrl);
            return normalizedVideoUrl === normalizedCurrentUrl || 
                   (v.videoId === currentVideoId && v.platform === platform);
          });
          
          // If video is not in project, add it
          if (!videoInProject && currentVideoUrl && currentVideoId) {
            // Initialize videos array if needed
            if (!projectForThisVideo.videos) {
              projectForThisVideo.videos = [];
            }
            
            // Get video title
            const videoTitle = getVideoTitle();
            const finalTitle = videoTitle && videoTitle !== `${platform} Video` ? videoTitle : `${platform} Video`;
            
            // Add current video to project
            projectForThisVideo.videos.push({
              videoId: currentVideoId,
              videoUrl: currentVideoUrl,
              videoTitle: finalTitle,
              platform: platform,
              addedAt: Date.now()
            });
            
            // Update storage with the new video
            const analysisIndex = analyses.findIndex(a => a.id === projectForThisVideo.id);
            if (analysisIndex !== -1) {
              analyses[analysisIndex] = projectForThisVideo;
              chrome.storage.local.set({ analyses: analyses }, () => {
                handleStorageError(null, 'loadCurrentAnalysis-addVideo');
              });
            }
          }
          
          // Only update storage if the ID actually changed
          if (currentAnalysisId !== projectForThisVideo.id) {
            currentAnalysisId = projectForThisVideo.id;
            if (projectForThisVideo.videoUrl) {
              currentVideoUrl = projectForThisVideo.videoUrl;
            }
            // Update button text immediately
            const projectButtonText = document.getElementById('distatsProjectButtonText');
            if (projectButtonText) {
              projectButtonText.textContent = projectForThisVideo.name;
            }
            // Update currentAnalysisId in storage first
            chrome.storage.local.set({ currentAnalysisId: projectForThisVideo.id }, () => {
              handleStorageError(null, 'loadCurrentAnalysis-set');
              // Update displays after storage is set
              updateProjectSelect();
              updateVideosDisplay();
              updateVideoLinkDisplay();
              updateProjectNameDisplay();
              updateNotesDisplay();
              // Initialize selected team from analysis
              selectedTeam = projectForThisVideo.selectedTeam || null;
              renderTeamSelector('');
              updateSelectedTeamDisplay();
              renderPlayerSelector('');
              updateSelectedPlayersDisplay();
              renderEventSelector('');
              updateSelectedEventsDisplay();
              renderZonesSelector('');
              updateSelectedZonesDisplay();
              
              // Reload timeline markers and video selector for new analysis
              loadTimelineMarkers();
              populateTimelineVideoSelect();
              populateTimelineTeamSelect();
              
              // Fetch and save real video title after a delay to ensure page is loaded
              setTimeout(() => {
                updateVideoTitleInAnalysis();
              }, 2000);
              
              isLoadingAnalysis = false;
            });
          } else {
            // ID is already set, but check if current video needs to be added
            // Check if current video is in the project's videos array, if not add it
            const videoInProject = projectForThisVideo.videos && projectForThisVideo.videos.some(v => {
              if (!v.videoUrl) return false;
              const normalizedVideoUrl = normalizeUrlForComparison(v.videoUrl);
              return normalizedVideoUrl === normalizedCurrentUrl || 
                     (v.videoId === currentVideoId && v.platform === platform);
            });
            
            // If video is not in project, add it
            if (!videoInProject && currentVideoUrl && currentVideoId) {
              // Initialize videos array if needed
              if (!projectForThisVideo.videos) {
                projectForThisVideo.videos = [];
              }
              
              // Get video title
              const videoTitle = getVideoTitle();
              const finalTitle = videoTitle && videoTitle !== `${platform} Video` ? videoTitle : `${platform} Video`;
              
              // Add current video to project
              projectForThisVideo.videos.push({
                videoId: currentVideoId,
                videoUrl: currentVideoUrl,
                videoTitle: finalTitle,
                platform: platform,
                addedAt: Date.now()
              });
              
              // Update storage with the new video
              const analysisIndex = analyses.findIndex(a => a.id === projectForThisVideo.id);
              if (analysisIndex !== -1) {
                analyses[analysisIndex] = projectForThisVideo;
                chrome.storage.local.set({ analyses: analyses }, () => {
                  handleStorageError(null, 'loadCurrentAnalysis-addVideo-existing');
                  updateVideosDisplay();
                });
              }
            }
            
            // ID is already set, just refresh displays
            updateProjectSelect();
            updateVideosDisplay();
            updateVideoLinkDisplay();
            updateProjectNameDisplay();
            updateNotesDisplay();
            renderTeamSelector('');
            updateSelectedTeamDisplay();
            renderPlayerSelector('');
            updateSelectedPlayersDisplay();
            
            // Reload timeline markers and video selector (in case videos changed)
            loadTimelineMarkers();
            populateTimelineVideoSelect();
            isLoadingAnalysis = false;
          }
        } else {
          // No project found for this video
          // But check if there's a savedAnalysisId that we should use anyway
          if (savedAnalysisId) {
            // There's a saved project ID, use it even if video doesn't match
            const savedAnalysis = analyses.find(a => a.id === savedAnalysisId);
            if (savedAnalysis) {
              currentAnalysisId = savedAnalysisId;
              const projectButtonText = document.getElementById('distatsProjectButtonText');
              if (projectButtonText) {
                projectButtonText.textContent = savedAnalysis.name;
              }
              updateProjectSelect();
              updateVideosDisplay();
              updateVideoLinkDisplay();
              updateProjectNameDisplay();
              updateNotesDisplay();
              renderTeamSelector('');
              updateSelectedTeamDisplay();
              renderPlayerSelector('');
              updateSelectedPlayersDisplay();
              isLoadingAnalysis = false;
              return;
            }
          }
          
          // No matching project and no valid saved project
          if (currentAnalysisId !== null) {
            currentAnalysisId = null;
            updateProjectSelect();
            updateVideosDisplay();
            updateVideoLinkDisplay();
            updateProjectNameDisplay();
            updateNotesDisplay();
            renderTeamSelector('');
            updateSelectedTeamDisplay();
            renderPlayerSelector('');
            updateSelectedPlayersDisplay();
          } else {
            // No project and no currentAnalysisId - make sure dropdown is hidden
            updateProjectSelect();
            renderTeamSelector('');
            updateSelectedTeamDisplay();
            renderPlayerSelector('');
            updateSelectedPlayersDisplay();
          }
          isLoadingAnalysis = false;
        }
      });
    } catch (e) {
      handleStorageError(e, 'loadCurrentAnalysis');
      isLoadingAnalysis = false;
    }
  }

  // HTML escape utility
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Helper function to get video duration
  function getVideoDuration() {
    try {
      const video = document.querySelector('video');
      if (video && !isNaN(video.duration) && video.duration > 0) {
        return video.duration;
      }
      
      // Platform-specific methods
      if (platform === 'youtube') {
        const player = document.getElementById('movie_player');
        if (player && typeof player.getDuration === 'function') {
          const duration = player.getDuration();
          if (duration && duration > 0) return duration;
        }
      }
      
      return 0;
    } catch (err) {
      console.error('Error getting video duration:', err);
      return 0;
    }
  }

  // Helper function to check if video is paused
  function isVideoPaused() {
    try {
      const video = document.querySelector('video');
      if (video) {
        return video.paused;
      }
      
      // Platform-specific
      if (platform === 'youtube') {
        const player = document.getElementById('movie_player');
        if (player && typeof player.getPlayerState === 'function') {
          // YT player states: -1 unstarted, 0 ended, 1 playing, 2 paused, 3 buffering, 5 video cued
          const state = player.getPlayerState();
          return state !== 1;
        }
      }
      
      return true;
    } catch (err) {
      return true;
    }
  }

  // Helper function to seek video
  function seekVideo(timeSeconds) {
    try {
      const video = document.querySelector('video');
      if (video) {
        video.currentTime = timeSeconds;
        return true;
      }
      
      // Platform-specific
      if (platform === 'youtube') {
        const player = document.getElementById('movie_player');
        if (player && typeof player.seekTo === 'function') {
          player.seekTo(timeSeconds, true);
          return true;
        }
      }
      
      return false;
    } catch (err) {
      console.error('Error seeking video:', err);
      return false;
    }
  }

  // Compress image data URL
  function compressImageDataUrl(dataUrl, maxWidth = 1920, maxHeight = 1080, quality = 0.85) {
    return new Promise((resolve, reject) => {
      try {
        const img = new Image();
        img.onload = () => {
          // Calculate new dimensions while maintaining aspect ratio
          let width = img.width;
          let height = img.height;
          
          if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width = Math.floor(width * ratio);
            height = Math.floor(height * ratio);
          }
          
          // Create canvas and draw resized image
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          // Convert to compressed JPEG (smaller than PNG)
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        };
        img.onerror = () => reject(new Error('Failed to load image for compression'));
        img.src = dataUrl;
      } catch (err) {
        reject(new Error('Failed to compress image: ' + err.message));
      }
    });
  }

  // Capture screenshot from video element
  function captureVideoScreenshot() {
    return new Promise((resolve, reject) => {
      try {
        // Get video element
        const video = document.querySelector('video');
        if (!video) {
          reject(new Error('Video element not found'));
          return;
        }

        // Check if video is ready
        if (video.readyState < 2) {
          // Wait for video to be ready
          const checkReady = () => {
            if (video.readyState >= 2) {
              captureFrame();
            } else {
              setTimeout(checkReady, 100);
            }
          };
          checkReady();
          return;
        }

        captureFrame();

        function captureFrame() {
          try {
            // Create canvas
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth || video.clientWidth;
            canvas.height = video.videoHeight || video.clientHeight;
            
            // Draw video frame to canvas
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // Convert to data URL (PNG for initial capture)
            const imageData = canvas.toDataURL('image/png');
            
            // Compress the image to reduce storage size
            compressImageDataUrl(imageData, 1920, 1080, 0.85).then(compressed => {
              resolve(compressed);
            }).catch(err => {
              // If compression fails, use original (but this might cause quota issues)
              console.warn('Compression failed, using original:', err);
              resolve(imageData);
            });
          } catch (err) {
            reject(new Error('Failed to capture video frame: ' + err.message));
          }
        }
      } catch (err) {
        reject(new Error('Failed to capture screenshot: ' + err.message));
      }
    });
  }

  // Wait for video to be ready after seeking
  function waitForVideoReady(targetTime, maxWait = 3000) {
    return new Promise((resolve, reject) => {
      const video = document.querySelector('video');
      if (!video) {
        reject(new Error('Video element not found'));
        return;
      }

      const startTime = Date.now();
      const checkReady = () => {
        const elapsed = Date.now() - startTime;
        
        if (elapsed > maxWait) {
          reject(new Error('Video did not become ready in time'));
          return;
        }

        // Check if video is at target time (within 0.1s tolerance) and ready
        const currentTime = video.currentTime || 0;
        const timeDiff = Math.abs(currentTime - targetTime);
        
        if (video.readyState >= 2 && timeDiff < 0.5) {
          // Give it a small delay to ensure frame is rendered
          setTimeout(() => resolve(), 100);
        } else {
          setTimeout(checkReady, 50);
        }
      };

      checkReady();
    });
  }

  // Listen for messages from popup and timeline
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Timeline-related messages (use request.type)
    if (request.type === 'getPlaybackState') {
      console.log('Content script: Received getPlaybackState request');
      try {
        const duration = getVideoDuration();
        const currentTime = getCurrentVideoTime() || 0;
        const paused = isVideoPaused();
        const response = { duration, currentTime, paused };
        console.log('Content script: Sending playback state:', response);
        sendResponse(response);
      } catch (err) {
        console.error('Content script: Error getting playback state:', err);
        sendResponse({ error: err.message });
      }
      return true; // Keep channel open for async response
    }
    
    if (request.type === 'getCurrentTime') {
      try {
        const currentTime = getCurrentVideoTime() || 0;
        const paused = isVideoPaused();
        sendResponse({ currentTime, paused });
      } catch (err) {
        console.error('Content script: Error getting current time:', err);
        sendResponse({ error: err.message });
      }
      return true; // Keep channel open
    }
    
    if (request.type === 'seekTo') {
      try {
        const success = seekVideo(request.time);
        sendResponse({ success });
      } catch (err) {
        console.error('Content script: Error seeking:', err);
        sendResponse({ success: false, error: err.message });
      }
      return true; // Keep channel open
    }
    
    // -related messages (use request.action)
    if (request.action === 'show') {
      show();
      sendResponse({success: true});
      return false;
    } else if (request.action === 'toggle') {
      toggle();
      sendResponse({visible: sidebarVisible});
      return false;
    } else if (request.action === 'openTimeline') {
      // Open timeline panel from popup
      const timelinePanel = document.getElementById('distatsTimelinePanel');
      const openTimelineBtn = document.getElementById('distatsOpenTimelineBtn');
      if (timelinePanel && openTimelineBtn) {
        const isHidden = timelinePanel.classList.contains('hidden');
        if (isHidden) {
          timelinePanel.classList.remove('hidden');
          // Ensure panel is within viewport
          setTimeout(() => {
            constrainTimelinePanelToViewport();
          }, 0);
          initTimelinePanel();
        }
        sendResponse({success: true});
      } else {
        sendResponse({success: false, error: 'Timeline panel not found'});
      }
      return false;
    } else if (request.action === 'seekToTime' && typeof request.seconds === 'number') {
      // Seek to a specific time in the video
      if (window.distatsSeekToTime) {
        window.distatsSeekToTime(request.seconds);
        sendResponse({success: true});
      } else {
        sendResponse({success: false, error: 'Seek function not available'});
      }
      return false;
    } else if (request.action === 'ping') {
      // Simple ping to check if content script is ready
      console.log('Content script: Received ping');
      sendResponse({ready: true, distatsReady: window.distatsContentScriptReady});
      return true;
    } else if (request.action === 'getVideoTitle') {
        // Get video title from the current page
      
      // Common UI elements to exclude (same as in getVideoTitle function)
      const excludedTexts = [
        'Browse', 'Home', 'Following', 'Browse Channels', 'Watch', 'Subscribe', 'Follow', 
        'Twitch', 'Twitch Video', 'Click to unmute', 'Click to mute', 'Unmute', 'Mute',
        'Click to play', 'Play', 'Pause', 'Fullscreen', 'Theater mode', 'Settings',
        'Volume', 'Chat', 'Share', 'Report', 'Block'
      ];
      
      const isValidTitle = (title) => {
        if (!title || !title.trim()) return false;
        
        const cleanTitle = title.trim();
        
        // Check if title is excluded
        const isExcluded = excludedTexts.some(excluded => 
          cleanTitle === excluded || 
          cleanTitle.toLowerCase() === excluded.toLowerCase() ||
          cleanTitle.toLowerCase().includes(excluded.toLowerCase())
        );
        
        // Check if looks like a control
        const looksLikeControl = /^(click|press|tap|select|choose|enable|disable|turn|switch|set|adjust|change|show|hide|open|close|start|stop|play|pause|mute|unmute|volume|fullscreen|theater|settings|chat|share|report|block|follow|subscribe|watch|browse|home|following)/i.test(cleanTitle);
        
        return cleanTitle.length > 5 && 
               !isExcluded && 
               !looksLikeControl &&
               cleanTitle !== 'Twitch Video' &&
               cleanTitle !== 'YouTube Video' &&
               cleanTitle !== 'Dailymotion Video';
      };
      
      // For Twitch, try to wait a bit for dynamic content to load
      if (platform === 'twitch' || window.location.href.includes('twitch.tv')) {
        // Try multiple times with increasing delays for Twitch (heavily JS-based)
        let attempts = 0;
        const maxAttempts = 5;
        const delays = [0, 1000, 3000, 5000, 8000]; // Progressive delays
        
        const tryGetTitle = () => {
          attempts++;
          const title = getVideoTitle();
          
          if (title && isValidTitle(title)) {
            sendResponse({title: title});
            return;
          }
          
          if (attempts < maxAttempts) {
            setTimeout(tryGetTitle, delays[attempts]);
          } else {
            // Return default title if we can't get a valid one
            const defaultTitle = platform === 'twitch' ? 'Twitch Video' : 
                                platform === 'youtube' ? 'YouTube Video' : 
                                platform === 'dailymotion' ? 'Dailymotion Video' : 'Video';
            sendResponse({title: defaultTitle});
          }
        };
        
        tryGetTitle();
        return true; // Keep channel open for async response
      } else {
        const title = getVideoTitle();
        if (title && isValidTitle(title)) {
          sendResponse({title: title});
        } else {
          // Return default title if we can't get a valid one
          const defaultTitle = platform === 'twitch' ? 'Twitch Video' : 
                              platform === 'youtube' ? 'YouTube Video' : 
                              platform === 'dailymotion' ? 'Dailymotion Video' : 'Video';
          sendResponse({title: defaultTitle});
        }
        return true; // Keep channel open for async response
      }
    } else if (request.action === 'requestAutocapture') {
      // Editor requesting autocapture - open modal
      if (window.openAutocaptureModal) {
        window.openAutocaptureModal();
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: 'Autocapture modal not initialized' });
      }
      return false;
    } else if (request.action === 'loadProject' && request.projectId) {
      // Load a specific project in the sidebar
      currentAnalysisId = request.projectId;
      chrome.storage.local.set({ currentAnalysisId: request.projectId }, () => {
        // Ensure storage is updated before loading
        chrome.storage.local.get(['analyses'], (result) => {
          const analyses = result.analyses || [];
          const analysis = analyses.find(a => a.id === request.projectId);
          
          if (analysis) {
            // Directly load the project without going through loadCurrentAnalysis logic
            // This ensures we use the project the user selected
            currentAnalysisId = request.projectId;
            if (analysis.videoUrl) {
              currentVideoUrl = analysis.videoUrl;
            }
            if (analysis.videoId) {
              currentVideoId = analysis.videoId;
            }
            updateVideoLinkDisplay();
            updateProjectNameDisplay();
            updateNotesDisplay();
            
            // Fetch and save real video title after a delay to ensure page is loaded
            setTimeout(() => {
              updateVideoTitleInAnalysis();
            }, 2000);
          } else {
            // Fallback to loadCurrentAnalysis if project not found
            loadCurrentAnalysis();
            updateNotesDisplay();
          }
          
          sendResponse({success: true, projectId: request.projectId});
        });
      });
      return true; // Keep channel open for async response
    }
    
    // Unhandled message - return false to let other listeners handle it
    return false;
  });

  // Initialize sidebar when page loads
  function initialize() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', create);
    } else {
      create();
    }

    // Wait for video player to be ready
    const checkVideoReady = () => {
      const video = document.querySelector('video');
      if (video || document.querySelector('#movie_player')) {
        // Fetch and save real video title after video is ready
        if (currentAnalysisId) {
          setTimeout(() => {
            updateVideoTitleInAnalysis();
          }, 3000); // Wait a bit longer for title to load
        }
      } else {
        setTimeout(checkVideoReady, 1000);
      }
    };
    checkVideoReady();
  }

  // Image Editor Functions
  function openImageEditorIn(imageSrc, noteData, imageIndex, slidesData = null, originalImageSrc = null) {
    // Send message to popup to open editor
    chrome.runtime.sendMessage({
      action: 'openImageEditor',
      imageSrc: imageSrc,
      noteTimestamp: noteData ? noteData.timestamp : null,
      imageIndex: imageIndex,
      slidesData: slidesData,
      originalImageSrc: originalImageSrc
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error opening editor:', chrome.runtime.lastError);
        // Try to open extension window instead
        chrome.runtime.sendMessage({
          action: 'focusExtensionWindow'
        });
      }
    });
  }

  // Note: All message handling is done in the listener above

  function processEditorSavedPayload(payload) {
    if (!payload) {
      return false;
    }
    const { callbackContext, callbackId, imageData, slidesData, canvasRotation } = payload;
    if (callbackContext !== 'sidebar') {
      return false;
    }

    window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};

    if (callbackId && window.pendingEditorCallbacks[callbackId]) {
      const callback = window.pendingEditorCallbacks[callbackId];
      delete window.pendingEditorCallbacks[callbackId];
      try {
        console.log(': Executing callback with slidesData:', {
          slidesDataLength: slidesData ? slidesData.length : 0,
          firstSlideDrawings: slidesData && slidesData[0] ? (slidesData[0].drawings ? slidesData[0].drawings.length : 0) : 0,
          hasOriginalSrc: !!payload.originalImageSrc,
          canvasRotation: canvasRotation || 0
        });
        callback(imageData, slidesData, payload.originalImageSrc, canvasRotation || 0);
      } catch (error) {
        console.error(': Error executing callback via storage payload:', error);
      }
    } else {
      updateNotesDisplay();
    }

    chrome.storage.local.remove(['editorSavedPayload', 'pendingEditorImageSrc', 'pendingEditorCallbackId', 'pendingEditorCallbackContext']);
    return true;
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') {
      return;
    }
    if (changes.editorSavedPayload && changes.editorSavedPayload.newValue) {
      processEditorSavedPayload(changes.editorSavedPayload.newValue);
    }
  });

  // In case payload exists before listener attached, process it on init
  chrome.storage.local.get(['editorSavedPayload'], (result) => {
    if (result.editorSavedPayload) {
      processEditorSavedPayload(result.editorSavedPayload);
    }
  });

  // ============================================================
  // SQUAD ASSIGNMENT FUNCTIONS
  // ============================================================
  
  // Formation positions data
  const SQUAD_FORMATIONS = {
    '4-3-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 20, y: 80, role: 'FWD', label: 'LW'},
        {x: 50, y: 80, role: 'FWD', label: 'ST'},
        {x: 80, y: 80, role: 'FWD', label: 'RW'}
      ]
    },
    '4-2-3-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 40, y: 50, role: 'MID', label: 'CDM'},
        {x: 60, y: 50, role: 'MID', label: 'CDM'},
        {x: 30, y: 70, role: 'MID', label: 'LM'},
        {x: 50, y: 70, role: 'MID', label: 'CAM'},
        {x: 70, y: 70, role: 'MID', label: 'RM'},
        {x: 50, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-4-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 20, y: 55, role: 'MID', label: 'LM'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RM'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '3-5-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 15, y: 55, role: 'MID', label: 'LWB'},
        {x: 35, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 65, y: 55, role: 'MID', label: 'CM'},
        {x: 85, y: 55, role: 'MID', label: 'RWB'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '4-1-2-1-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 50, y: 45, role: 'MID', label: 'CDM'},
        {x: 35, y: 60, role: 'MID', label: 'CM'},
        {x: 65, y: 60, role: 'MID', label: 'CM'},
        {x: 50, y: 72, role: 'MID', label: 'CAM'},
        {x: 40, y: 85, role: 'FWD', label: 'ST'},
        {x: 60, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '5-3-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 15, y: 30, role: 'DEF', label: 'LWB'},
        {x: 35, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 65, y: 30, role: 'DEF', label: 'CB'},
        {x: 85, y: 30, role: 'DEF', label: 'RWB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    }
  };

  // Current squad assignments while editing
  let currentSquadAssignments = {};
  let currentSquadPositionIndex = null;

  function getFormationPositions(formationName) {
    if (SQUAD_FORMATIONS[formationName]) {
      return SQUAD_FORMATIONS[formationName].positions;
    }
    return [
      {x: 50, y: 10, role: 'GK', label: 'GK'},
      {x: 20, y: 30, role: 'DEF', label: 'DEF'},
      {x: 40, y: 30, role: 'DEF', label: 'DEF'},
      {x: 60, y: 30, role: 'DEF', label: 'DEF'},
      {x: 80, y: 30, role: 'DEF', label: 'DEF'},
      {x: 30, y: 55, role: 'MID', label: 'MID'},
      {x: 50, y: 55, role: 'MID', label: 'MID'},
      {x: 70, y: 55, role: 'MID', label: 'MID'},
      {x: 35, y: 80, role: 'FWD', label: 'FWD'},
      {x: 50, y: 80, role: 'FWD', label: 'FWD'},
      {x: 65, y: 80, role: 'FWD', label: 'FWD'}
    ];
  }

  function renderSquadFormation(formationName, teamName, squad = {}) {
    const container = document.getElementById('distatsTeamSquadFormation');
    const section = document.getElementById('distatsTeamSquadSection');
    
    if (!container || !section) return;
    
    if (!formationName) {
      section.style.display = 'none';
      return;
    }
    
    section.style.display = 'block';
    container.innerHTML = '';
    currentSquadAssignments = { ...squad };
    
    const positions = getFormationPositions(formationName);
    
    chrome.storage.local.get(['players'], (result) => {
      if (handleStorageError(null, 'renderSquadFormation')) return;
      const players = result.players || [];
      const teamPlayers = players.filter(p => p.team === teamName);
      
      positions.forEach((pos, index) => {
        const assignedPlayerId = currentSquadAssignments[index];
        const assignedPlayer = assignedPlayerId ? teamPlayers.find(p => p.id === assignedPlayerId) : null;
        
        const slot = document.createElement('div');
        slot.className = 'squad-position-slot';
        slot.style.cssText = `
          position: absolute;
          left: ${pos.x}%;
          top: ${pos.y}%;
          transform: translate(-50%, -50%);
          width: 50px;
          text-align: center;
          cursor: pointer;
        `;
        slot.dataset.positionIndex = index;
        
        const circle = document.createElement('div');
        circle.style.cssText = `
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: ${assignedPlayer ? '#1f6feb' : 'rgba(255,255,255,0.2)'};
          border: 2px solid ${assignedPlayer ? '#58a6ff' : 'rgba(255,255,255,0.4)'};
          margin: 0 auto 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: bold;
          color: ${assignedPlayer ? '#fff' : 'rgba(255,255,255,0.7)'};
          transition: all 0.2s ease;
        `;
        circle.textContent = assignedPlayer ? (assignedPlayer.number || '?') : pos.label;
        
        const label = document.createElement('div');
        label.style.cssText = `
          font-size: 10px;
          color: #fff;
          text-shadow: 0 1px 2px rgba(0,0,0,0.8);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 60px;
        `;
        label.textContent = assignedPlayer ? (assignedPlayer.fullName || 'Unknown').split(' ').pop() : pos.label;
        
        slot.appendChild(circle);
        slot.appendChild(label);
        
        slot.addEventListener('mouseenter', () => {
          circle.style.transform = 'scale(1.1)';
          circle.style.boxShadow = '0 0 10px rgba(88, 166, 255, 0.5)';
        });
        slot.addEventListener('mouseleave', () => {
          circle.style.transform = 'scale(1)';
          circle.style.boxShadow = 'none';
        });
        
        slot.addEventListener('click', () => {
          openSquadPlayerPopup(index, pos.label, teamName);
        });
        
        container.appendChild(slot);
      });
    });
  }

  function openSquadPlayerPopup(positionIndex, positionLabel, teamName) {
    const popup = document.getElementById('distatsSquadPlayerPopup');
    const title = document.getElementById('distatsSquadPlayerPopupTitle');
    const positionInfo = document.getElementById('distatsSquadPlayerPopupPosition');
    const playerList = document.getElementById('distatsSquadPlayerList');
    
    if (!popup || !playerList) return;
    
    currentSquadPositionIndex = positionIndex;
    title.textContent = 'Assign Player';
    positionInfo.textContent = `Position: ${positionLabel}`;
    playerList.innerHTML = '';
    
    chrome.storage.local.get(['players'], (result) => {
      if (handleStorageError(null, 'openSquadPlayerPopup')) return;
      const players = result.players || [];
      const teamPlayers = players.filter(p => p.team === teamName);
      
      if (teamPlayers.length === 0) {
        playerList.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">No players in this team</div>';
      } else {
        teamPlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
        
        teamPlayers.forEach(player => {
          const isAssigned = Object.values(currentSquadAssignments).includes(player.id);
          const isCurrentPosition = currentSquadAssignments[positionIndex] === player.id;
          
          const playerItem = document.createElement('div');
          playerItem.style.cssText = `
            display: flex;
            align-items: center;
            padding: 10px 12px;
            margin-bottom: 4px;
            background: ${isCurrentPosition ? '#1f6feb' : '#0d1117'};
            border: 1px solid ${isCurrentPosition ? '#58a6ff' : '#21262d'};
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.15s ease;
            opacity: ${isAssigned && !isCurrentPosition ? '0.5' : '1'};
          `;
          
          const numberSpan = document.createElement('span');
          numberSpan.style.cssText = `
            width: 28px;
            height: 28px;
            background: ${isCurrentPosition ? 'rgba(255,255,255,0.2)' : '#21262d'};
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: bold;
            color: #c9d1d9;
            margin-right: 10px;
          `;
          numberSpan.textContent = player.number || '?';
          
          const nameSpan = document.createElement('span');
          nameSpan.style.cssText = 'flex: 1; font-size: 13px; color: #c9d1d9;';
          nameSpan.textContent = player.fullName || 'Unknown';
          
          const posSpan = document.createElement('span');
          posSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
          posSpan.textContent = player.position || '';
          
          playerItem.appendChild(numberSpan);
          playerItem.appendChild(nameSpan);
          playerItem.appendChild(posSpan);
          
          playerItem.addEventListener('mouseenter', () => {
            if (!isCurrentPosition) {
              playerItem.style.borderColor = '#30363d';
              playerItem.style.background = '#161b22';
            }
          });
          playerItem.addEventListener('mouseleave', () => {
            if (!isCurrentPosition) {
              playerItem.style.borderColor = '#21262d';
              playerItem.style.background = '#0d1117';
            }
          });
          
          playerItem.addEventListener('click', () => {
            Object.keys(currentSquadAssignments).forEach(key => {
              if (currentSquadAssignments[key] === player.id) {
                delete currentSquadAssignments[key];
              }
            });
            currentSquadAssignments[positionIndex] = player.id;
            closeSquadPlayerPopup();
            const formationSelect = document.getElementById('distatsTeamFormationSelect');
            renderSquadFormation(formationSelect?.value, teamName, currentSquadAssignments);
          });
          
          playerList.appendChild(playerItem);
        });
      }
      
      popup.classList.remove('hidden');
    });
  }

  function closeSquadPlayerPopup() {
    const popup = document.getElementById('distatsSquadPlayerPopup');
    if (popup) {
      popup.classList.add('hidden');
      currentSquadPositionIndex = null;
    }
  }

  // Squad popup event listeners
  const closeSquadPopupBtn = document.getElementById('distatsCloseSquadPlayerPopup');
  const clearSquadPositionBtn = document.getElementById('distatsClearSquadPosition');
  const squadPlayerPopup = document.getElementById('distatsSquadPlayerPopup');
  
  if (closeSquadPopupBtn) {
    closeSquadPopupBtn.addEventListener('click', closeSquadPlayerPopup);
  }
  
  if (clearSquadPositionBtn) {
    clearSquadPositionBtn.addEventListener('click', () => {
      if (currentSquadPositionIndex !== null) {
        delete currentSquadAssignments[currentSquadPositionIndex];
        closeSquadPlayerPopup();
        const formationSelect = document.getElementById('distatsTeamFormationSelect');
        const teamNameInput = document.getElementById('distatsTeamNameInput');
        renderSquadFormation(formationSelect?.value, currentEditingTeamName || teamNameInput?.value, currentSquadAssignments);
      }
    });
  }
  
  if (squadPlayerPopup) {
    squadPlayerPopup.addEventListener('click', (e) => {
      if (e.target === squadPlayerPopup) {
        closeSquadPlayerPopup();
      }
    });
  }

  // Formation selector change handler for squad
  const distatsTeamFormationSelect = document.getElementById('distatsTeamFormationSelect');
  if (distatsTeamFormationSelect) {
    distatsTeamFormationSelect.addEventListener('change', (e) => {
      const teamName = currentEditingTeamName || document.getElementById('distatsTeamNameInput')?.value;
      currentSquadAssignments = {};
      renderSquadFormation(e.target.value, teamName, currentSquadAssignments);
    });
  }

  // ============================================================
  // TIMELINE FLOATING PANEL FUNCTIONS
  // ============================================================
  
  let timelineMarkers = [];
  let timelineUpdateInterval = null;
  let selectedTimelineVideo = null; // Track selected video for filtering markers
  
  // Ensure timeline panel is within viewport bounds
  function constrainTimelinePanelToViewport() {
    const panel = document.getElementById('distatsTimelinePanel');
    if (!panel) return;
    
    const panelRect = panel.getBoundingClientRect();
    const panelWidth = panelRect.width;
    const panelHeight = panelRect.height;
    
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    // Get current position
    let currentLeft = panel.offsetLeft;
    let currentTop = panel.offsetTop;
    
    // If position is not set (NaN or undefined), use default
    if (isNaN(currentLeft) || currentLeft === undefined) {
      currentLeft = 50;
    }
    if (isNaN(currentTop) || currentTop === undefined) {
      currentTop = 100;
    }
    
    // Constrain to viewport bounds
    const minVisible = 50;
    const constrainedLeft = Math.max(-(panelWidth - minVisible), Math.min(currentLeft, viewportWidth - minVisible));
    const constrainedTop = Math.max(0, Math.min(currentTop, viewportHeight - minVisible));
    
    // Only update if position needs correction
    if (constrainedLeft !== currentLeft || constrainedTop !== currentTop) {
      panel.style.left = `${constrainedLeft}px`;
      panel.style.top = `${constrainedTop}px`;
    }
  }
  
  // Make timeline panel draggable
  function makeTimelinePanelDraggable() {
    const panel = document.getElementById('distatsTimelinePanel');
    const header = document.getElementById('distatsTimelinePanelHeader');
    
    if (!panel || !header) return;
    
    // Ensure panel is within bounds on initialization
    constrainTimelinePanelToViewport();
    
    // Also check on window resize
    window.addEventListener('resize', constrainTimelinePanelToViewport);
    
    let isDragging = false;
    let startX, startY, startLeft, startTop;
    
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.timeline-panel-btn')) return; // Don't drag when clicking buttons
      
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      
      // Get current position, handling cases where it might be outside viewport
      const rect = panel.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      
      document.addEventListener('mousemove', onDrag);
      document.addEventListener('mouseup', stopDrag);
    });
    
    function onDrag(e) {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      // Calculate new position
      let newLeft = startLeft + dx;
      let newTop = startTop + dy;
      
      // Get panel dimensions
      const panelRect = panel.getBoundingClientRect();
      const panelWidth = panelRect.width;
      const panelHeight = panelRect.height;
      
      // Get viewport dimensions
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      
      // Constrain to viewport bounds
      // Keep at least 50px of the panel visible on each side
      const minVisible = 50;
      newLeft = Math.max(-(panelWidth - minVisible), Math.min(newLeft, viewportWidth - minVisible));
      newTop = Math.max(0, Math.min(newTop, viewportHeight - minVisible));
      
      panel.style.left = `${newLeft}px`;
      panel.style.top = `${newTop}px`;
    }
    
    function stopDrag() {
      isDragging = false;
      document.removeEventListener('mousemove', onDrag);
      document.removeEventListener('mouseup', stopDrag);
      
      // Ensure panel is still within bounds after drag ends
      constrainTimelinePanelToViewport();
    }
  }
  
  // Initialize timeline panel
  function initTimelinePanel() {
    console.log('Initializing Timeline Panel');
    
    // Update project name
    updateTimelineProjectName();
    
    // Populate selectors
    populateTimelineVideoSelect();
    populateTimelineTeamSelect();
    
    // Setup team selector
    setupTimelineTeamSelector();

    // Setup player selector
    setupTimelinePlayerSelector();
    renderTimelinePlayerSelector();

    // Load and render quick events
    loadAndRenderQuickEvents();
    
    // Setup edit events modal
    setupTimelineEventsModal();
    
    // Load markers for current video
    loadTimelineMarkers();
    
    // Setup timeline bar click handler
    setupTimelineBarHandler();
    
    // Setup manual time input
    setupTimelineManualTime();
    
    // Start time update interval
    startTimelineUpdates();
  }
  
  // Quick events for timeline - now team-specific
  // Structure: { "Team A": ["Goal", "Shot"], "Team B": ["Foul", "Offside"] }
  let timelineQuickEvents = {};
  
  // Teams selected to show in quick events
  let selectedTimelineTeams = new Set();
  
  // Players selected for timeline events
  let selectedTimelinePlayers = [];
  
  function loadAndRenderQuickEvents() {
    if (!currentAnalysisId) {
      renderQuickEventButtons();
      return;
    }
    
    const storageKey = `timelineQuickEvents_${currentAnalysisId}`;
    chrome.storage.local.get([storageKey], (result) => {
      if (result[storageKey]) {
        // Check if it's old format (array) or new format (object)
        if (Array.isArray(result[storageKey])) {
          // Migration: Convert old array format to new object format
          // Put old events on the first team (if available), otherwise create a default entry
          const defaultEvents = result[storageKey].length > 0 
            ? result[storageKey] 
            : ['Goal', 'Shot', 'Corner', 'Foul', 'Offside', 'Free kick'];
          
          if (timelineTeamsCache && timelineTeamsCache.length > 0) {
            // Put events on first team only
            timelineQuickEvents = {};
            timelineQuickEvents[timelineTeamsCache[0].name] = [...defaultEvents];
          } else {
            // Fallback: use a default team name
            timelineQuickEvents = { 'Default': defaultEvents };
          }
          // Save migrated format
          saveQuickEvents();
        } else {
          // New format (object) - use as is, only show teams that have events
        timelineQuickEvents = result[storageKey];
        }
      } else {
        // No stored events - start with empty object
        // Events will be added when user selects a team and adds events
        timelineQuickEvents = {};
      }
      // Only load selected teams if teams cache is already populated
      // Otherwise it will be called after teams are loaded in populateTimelineTeamSelect
      if (timelineTeamsCache && timelineTeamsCache.length > 0) {
        loadSelectedTimelineTeams();
      }
      renderQuickEventButtons();
    });
  }
  
  function loadSelectedTimelineTeams() {
    if (!currentAnalysisId) {
      selectedTimelineTeams = new Set();
      if (timelineTeamsCache && timelineTeamsCache.length > 0) {
        // Select first team by default
        selectedTimelineTeams = new Set([timelineTeamsCache[0].name]);
      }
      renderTimelineTeamSelector();
      renderQuickEventButtons();
      return;
    }
    
    const storageKey = `selectedTimelineTeams_${currentAnalysisId}`;
    chrome.storage.local.get([storageKey], (result) => {
      if (result[storageKey] && Array.isArray(result[storageKey])) {
        // Filter to only include teams that exist in cache
        const validTeams = result[storageKey].filter(teamName => 
          timelineTeamsCache.some(t => t.name === teamName)
        );
        selectedTimelineTeams = new Set(validTeams);
        
        // If no valid teams, select first team by default
        if (validTeams.length === 0 && timelineTeamsCache.length > 0) {
          selectedTimelineTeams = new Set([timelineTeamsCache[0].name]);
          saveSelectedTimelineTeams();
        }
      } else {
        // Default: select first team if available
        if (timelineTeamsCache && timelineTeamsCache.length > 0) {
          selectedTimelineTeams = new Set([timelineTeamsCache[0].name]);
          saveSelectedTimelineTeams();
        } else {
          selectedTimelineTeams = new Set();
        }
      }
      renderTimelineTeamSelector();
      renderQuickEventButtons();
      // Update player selector to show players from selected teams
      const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
      if (playerSearchInput) {
        renderTimelinePlayerSelector(playerSearchInput.value || '');
      }
    });
  }
  
  function saveSelectedTimelineTeams() {
    if (!currentAnalysisId) return;
    const storageKey = `selectedTimelineTeams_${currentAnalysisId}`;
    chrome.storage.local.set({ [storageKey]: Array.from(selectedTimelineTeams) });
  }
  
  function saveQuickEvents() {
    if (!currentAnalysisId) return;
    const storageKey = `timelineQuickEvents_${currentAnalysisId}`;
    chrome.storage.local.set({ [storageKey]: timelineQuickEvents });
  }
  
  function renderQuickEventButtons() {
    const container = document.getElementById('distatsTimelineQuickEvents');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (selectedTimelineTeams.size === 0) {
      // No teams selected
      return;
    }
    
    // Check if timelineQuickEvents is old format (array) - should not happen after migration, but handle it
    if (Array.isArray(timelineQuickEvents)) {
      // Fallback: render as before - use first selected team
      const firstTeam = Array.from(selectedTimelineTeams)[0];
    timelineQuickEvents.forEach(eventName => {
      const btn = document.createElement('button');
      btn.className = 'timeline-quick-event-btn';
      btn.textContent = eventName;
      btn.addEventListener('click', () => {
          addTimelineMarker(firstTeam, eventName);
        });
        container.appendChild(btn);
      });
      return;
    }
    
    // New format: show events for all selected teams, grouped by team
    const selectedTeamsArray = Array.from(selectedTimelineTeams);
    const teamsWithEvents = selectedTeamsArray.filter(teamName => {
      const events = timelineQuickEvents[teamName];
      return Array.isArray(events) && events.length > 0;
    });
    
    if (teamsWithEvents.length === 0) {
          return;
        }
        
    teamsWithEvents.forEach(teamName => {
      const events = timelineQuickEvents[teamName] || [];
      if (events.length === 0) return;
      
      // Create team group container
      const teamGroup = document.createElement('div');
      teamGroup.className = 'timeline-quick-events-team-group';
      
      // Create team label with color indicator
      const teamLabel = document.createElement('div');
      teamLabel.className = 'timeline-quick-events-team-label';
      
      // Find team color
      const team = timelineTeamsCache.find(t => t.name === teamName);
      const teamColor = team ? (team.homeColor || '#8b949e') : '#8b949e';
      
      const colorIndicator = document.createElement('span');
      colorIndicator.className = 'timeline-quick-events-team-color';
      colorIndicator.style.background = teamColor;
      colorIndicator.style.width = '12px';
      colorIndicator.style.height = '12px';
      colorIndicator.style.borderRadius = '3px';
      colorIndicator.style.display = 'inline-block';
      colorIndicator.style.marginRight = '6px';
      colorIndicator.style.verticalAlign = 'middle';
      
      const labelText = document.createElement('span');
      labelText.textContent = teamName;
      labelText.style.fontSize = '11px';
      labelText.style.fontWeight = '500';
      labelText.style.color = '#8b949e';
      
      teamLabel.appendChild(colorIndicator);
      teamLabel.appendChild(labelText);
      teamGroup.appendChild(teamLabel);
      
      // Create buttons container
      const buttonsContainer = document.createElement('div');
      buttonsContainer.className = 'timeline-quick-events-team-buttons';
      
      events.forEach(eventName => {
        const btn = document.createElement('button');
        btn.className = 'timeline-quick-event-btn';
        btn.textContent = eventName;
        btn.addEventListener('click', () => {
          // Pass selected players to the marker
          addTimelineMarker(teamName, eventName, [...selectedTimelinePlayers]);
      });
        buttonsContainer.appendChild(btn);
      });
      
      teamGroup.appendChild(buttonsContainer);
      container.appendChild(teamGroup);
    });
  }
  
  function setupTimelineEventsModal() {
    const editBtn = document.getElementById('distatsTimelineEditEventsBtn');
    const modal = document.getElementById('distatsTimelineEventsModal');
    const closeBtn = document.getElementById('distatsCloseTimelineEventsModal');
    const eventSearchInput = document.getElementById('distatsTimelineEventSearchInput');
    const eventSelectorDropdown = document.getElementById('distatsTimelineEventSelectorDropdown');
    const addCustomEventBtn = document.getElementById('distatsTimelineAddCustomEventBtn');
    const modalTeamSelect = document.getElementById('distatsTimelineModalTeamSelect');
    
    // Populate team selector in modal
    function populateModalTeamSelect() {
      if (!modalTeamSelect) return;
      
      modalTeamSelect.innerHTML = '<option value="">Select team...</option>';
      
      // Only show teams that are currently selected in the main selector
      const selectedTeamsArray = Array.from(selectedTimelineTeams);
      
      if (selectedTeamsArray.length > 0) {
        selectedTeamsArray.forEach(teamName => {
          const option = document.createElement('option');
          option.value = teamName;
          option.textContent = teamName;
          modalTeamSelect.appendChild(option);
        });
        
        // Auto-select first team
        modalTeamSelect.value = selectedTeamsArray[0];
      } else if (timelineTeamsCache && timelineTeamsCache.length > 0) {
        // If no teams selected, show all teams
        timelineTeamsCache.forEach(team => {
          const option = document.createElement('option');
          option.value = team.name;
          option.textContent = team.name;
          modalTeamSelect.appendChild(option);
        });
        
        // Auto-select first team
        modalTeamSelect.value = timelineTeamsCache[0].name;
      }
    }
    
    // Handle team selection change in modal
    if (modalTeamSelect) {
      modalTeamSelect.addEventListener('change', () => {
        renderEventsModalList();
      });
    }
    
    if (editBtn) {
      editBtn.addEventListener('click', () => {
        populateModalTeamSelect();
        renderEventsModalList();
        renderTimelineEventSelector('');
        if (modal) {
          modal.classList.remove('hidden');
          setTimeout(() => {
            if (eventSearchInput) {
              eventSearchInput.focus();
            }
          }, 100);
        }
      });
    }
    
    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
        if (eventSelectorDropdown) {
          eventSelectorDropdown.style.display = 'none';
        }
      });
    }
    
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
          if (eventSelectorDropdown) {
            eventSelectorDropdown.style.display = 'none';
          }
        }
      });
    }
    
    // Event search input
    if (eventSearchInput) {
      eventSearchInput.addEventListener('focus', () => {
        if (eventSelectorDropdown) {
          eventSelectorDropdown.style.display = 'block';
          renderTimelineEventSelector(eventSearchInput.value);
        }
      });
      
      eventSearchInput.addEventListener('input', (e) => {
        renderTimelineEventSelector(e.target.value);
        if (eventSelectorDropdown) {
          eventSelectorDropdown.style.display = 'block';
        }
      });
      
      eventSearchInput.addEventListener('blur', (e) => {
        setTimeout(() => {
          if (eventSelectorDropdown && !eventSelectorDropdown.matches(':hover') && document.activeElement !== eventSearchInput) {
            eventSelectorDropdown.style.display = 'none';
          }
        }, 200);
      });
    }
    
    // Keep dropdown open when hovering
    if (eventSelectorDropdown) {
      eventSelectorDropdown.addEventListener('mouseenter', () => {
        eventSelectorDropdown.style.display = 'block';
      });
      eventSelectorDropdown.addEventListener('mouseleave', () => {
        if (document.activeElement !== eventSearchInput) {
          eventSelectorDropdown.style.display = 'none';
        }
      });
    }
    
    // Add custom event button
    if (addCustomEventBtn) {
      addCustomEventBtn.addEventListener('click', () => {
        openCustomEventModalForTimeline();
      });
    }
  }
  
  function renderTimelineEventSelector(searchTerm = '') {
    const dropdown = document.getElementById('distatsTimelineEventSelectorDropdown');
    const categoriesDiv = document.getElementById('distatsTimelineEventCategories');
    if (!dropdown || !categoriesDiv) {
      console.warn('Timeline event selector elements not found');
      return;
    }
    
    categoriesDiv.innerHTML = '';
    
    const searchLower = searchTerm.toLowerCase().trim();
    
    // Group custom events by category
    const customEventsByCategory = {};
    customEvents.forEach(eventObj => {
      const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
      const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
      
      if (!customEventsByCategory[category]) {
        customEventsByCategory[category] = [];
      }
      customEventsByCategory[category].push(eventName);
    });
    
    EVENT_CATEGORIES.forEach(category => {
      const filteredStandardEvents = searchTerm 
        ? category.events.filter(event => event.toLowerCase().includes(searchLower))
        : category.events;
      
      const customEventsInCategory = customEventsByCategory[category.name] || [];
      const filteredCustomEvents = searchTerm
        ? customEventsInCategory.filter(event => event.toLowerCase().includes(searchLower))
        : customEventsInCategory;
      
      const allEventsInCategory = [...filteredStandardEvents, ...filteredCustomEvents];
      
      if (searchTerm && allEventsInCategory.length === 0) return;
      
      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'event-category';
      
      const categoryName = document.createElement('div');
      categoryName.className = 'event-category-name';
      categoryName.textContent = category.name;
      categoryDiv.appendChild(categoryName);
      
      // Render standard events
      filteredStandardEvents.forEach(event => {
        const eventItem = createTimelineEventItem(event, false);
        categoryDiv.appendChild(eventItem);
      });
      
      // Render custom events with edit/delete buttons
      filteredCustomEvents.forEach(event => {
        const eventItem = createTimelineEventItem(event, true);
        categoryDiv.appendChild(eventItem);
      });
      
      categoriesDiv.appendChild(categoryDiv);
    });
    
    // Add custom category for events not in standard categories
    const customCategoryEvents = Object.keys(customEventsByCategory).filter(catName => 
      !EVENT_CATEGORIES.some(c => c.name === catName)
    ).flatMap(catName => customEventsByCategory[catName]);
    
    const filteredCustomCategory = searchTerm
      ? customCategoryEvents.filter(event => event.toLowerCase().includes(searchLower))
      : customCategoryEvents;
    
    if (filteredCustomCategory.length > 0) {
      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'event-category';
      
      const categoryName = document.createElement('div');
      categoryName.className = 'event-category-name';
      categoryName.textContent = 'Custom';
      categoryDiv.appendChild(categoryName);
      
      filteredCustomCategory.forEach(event => {
        const eventItem = createTimelineEventItem(event, true);
        categoryDiv.appendChild(eventItem);
      });
      
      categoriesDiv.appendChild(categoryDiv);
    }
  }
  
  function createTimelineEventItem(event, isCustom) {
    const eventItem = document.createElement('div');
    eventItem.className = 'event-item';
    eventItem.style.cursor = 'pointer';
    eventItem.style.padding = '6px 8px';
    eventItem.style.borderRadius = '4px';
    eventItem.style.display = 'flex';
    eventItem.style.alignItems = 'center';
    eventItem.style.justifyContent = 'space-between';
    
    eventItem.addEventListener('mouseenter', () => {
      eventItem.style.background = '#21262d';
    });
    eventItem.addEventListener('mouseleave', () => {
      eventItem.style.background = 'transparent';
    });
    
    const label = document.createElement('span');
    label.textContent = translateEventName(event);
    label.style.flex = '1';
    label.style.fontSize = '13px';
    label.style.color = '#c9d1d9';
    
    eventItem.appendChild(label);
    
    // Click to add event
    eventItem.addEventListener('click', (e) => {
      if (e.target.closest('.event-item-edit') || e.target.closest('.event-item-delete')) {
        return; // Don't add if clicking edit/delete
      }
      
      // Get selected team from modal team selector
      const modalTeamSelect = document.getElementById('distatsTimelineModalTeamSelect');
      const selectedTeam = modalTeamSelect?.value;
      
      if (!selectedTeam) {
        alert('Please select a team first in the modal');
        return;
      }
      
      // Initialize team's events array if it doesn't exist
      if (!timelineQuickEvents[selectedTeam]) {
        timelineQuickEvents[selectedTeam] = [];
      }
      
      // Check if event already exists for this team
      if (timelineQuickEvents[selectedTeam].includes(event)) {
        alert('This event is already in the quick list for this team');
        return;
      }
      
      // Add event to selected team
      timelineQuickEvents[selectedTeam].push(event);
      saveQuickEvents();
      renderQuickEventButtons();
      renderEventsModalList();
      
      // Clear search
      const searchInput = document.getElementById('distatsTimelineEventSearchInput');
      if (searchInput) {
        searchInput.value = '';
        renderTimelineEventSelector('');
      }
    });
    
    // Add edit/delete buttons for custom events
    if (isCustom) {
      const buttonsContainer = document.createElement('div');
      buttonsContainer.style.display = 'flex';
      buttonsContainer.style.gap = '4px';
      
      const editBtn = document.createElement('button');
      editBtn.textContent = '✎';
      editBtn.className = 'event-item-edit';
      editBtn.style.background = 'transparent';
      editBtn.style.border = 'none';
      editBtn.style.color = '#8b949e';
      editBtn.style.cursor = 'pointer';
      editBtn.style.padding = '2px 4px';
      editBtn.style.fontSize = '11px';
      editBtn.style.lineHeight = '1';
      editBtn.title = 'Edit event';
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openCustomEventModalForTimeline(event);
      });
      
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '×';
      deleteBtn.className = 'event-item-delete';
      deleteBtn.style.background = 'transparent';
      deleteBtn.style.border = 'none';
      deleteBtn.style.color = '#8b949e';
      deleteBtn.style.cursor = 'pointer';
      deleteBtn.style.padding = '2px 4px';
      deleteBtn.style.fontSize = '12px';
      deleteBtn.style.lineHeight = '1';
      deleteBtn.title = 'Delete event';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteCustomEvent(event);
        renderTimelineEventSelector(document.getElementById('distatsTimelineEventSearchInput')?.value || '');
      });
      
      buttonsContainer.appendChild(editBtn);
      buttonsContainer.appendChild(deleteBtn);
      eventItem.appendChild(buttonsContainer);
    }
    
    return eventItem;
  }
  
  function openCustomEventModalForTimeline(eventName = null) {
    // Use the same custom event modal as comment properties
    openCustomEventModal(eventName);
    
    // Refresh timeline event selector when modal closes
    const customEventModal = document.getElementById('distatsCustomEventModal');
    if (customEventModal) {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            if (customEventModal.classList.contains('hidden')) {
              // Modal was closed, refresh timeline selector
              setTimeout(() => {
                const searchInput = document.getElementById('distatsTimelineEventSearchInput');
                if (searchInput) {
                  renderTimelineEventSelector(searchInput.value);
                }
              }, 100);
            }
          }
        });
      });
      observer.observe(customEventModal, { attributes: true });
    }
  }
  
  function renderEventsModalList() {
    const list = document.getElementById('distatsTimelineEventsModalList');
    if (!list) return;
    
    list.innerHTML = '';
    
    // Get selected team from modal team selector
    const modalTeamSelect = document.getElementById('distatsTimelineModalTeamSelect');
    const selectedTeam = modalTeamSelect?.value;
    
    if (!selectedTeam) {
      list.innerHTML = '<div style="color: #8b949e; font-size: 12px; text-align: center; padding: 20px;">Please select a team first</div>';
      return;
    }
    
    // Check if old format (array) - should not happen after migration
    if (Array.isArray(timelineQuickEvents)) {
    if (timelineQuickEvents.length === 0) {
        list.innerHTML = '<div style="color: #8b949e; font-size: 12px; text-align: center; padding: 20px;">No events added for this team</div>';
      return;
    }
    
    timelineQuickEvents.forEach((eventName, index) => {
      const item = document.createElement('div');
      item.className = 'timeline-events-modal-item';
      item.innerHTML = `
        <span>${eventName}</span>
        <button class="timeline-events-modal-remove" title="Remove">×</button>
      `;
      
      item.querySelector('button').addEventListener('click', () => {
        timelineQuickEvents.splice(index, 1);
          saveQuickEvents();
          renderQuickEventButtons();
          renderEventsModalList();
        });
        
        list.appendChild(item);
      });
      return;
    }
    
    // New format: only show events for the selected team
    const events = timelineQuickEvents[selectedTeam] || [];
    
    if (events.length === 0) {
      list.innerHTML = '<div style="color: #8b949e; font-size: 12px; text-align: center; padding: 20px;">No events added for this team</div>';
      return;
    }
    
    // Find team color
    const team = timelineTeamsCache.find(t => t.name === selectedTeam);
    const teamColor = team ? (team.homeColor || '#8b949e') : '#8b949e';
    
    // Create team header
    const teamHeader = document.createElement('div');
    teamHeader.style.display = 'flex';
    teamHeader.style.alignItems = 'center';
    teamHeader.style.gap = '8px';
    teamHeader.style.marginBottom = '8px';
    teamHeader.style.paddingBottom = '6px';
    teamHeader.style.borderBottom = '1px solid #21262d';
    
    const colorIndicator = document.createElement('span');
    colorIndicator.style.width = '12px';
    colorIndicator.style.height = '12px';
    colorIndicator.style.borderRadius = '3px';
    colorIndicator.style.background = teamColor;
    colorIndicator.style.flexShrink = '0';
    
    const teamNameSpan = document.createElement('span');
    teamNameSpan.textContent = selectedTeam;
    teamNameSpan.style.fontSize = '12px';
    teamNameSpan.style.fontWeight = '600';
    teamNameSpan.style.color = '#c9d1d9';
    
    teamHeader.appendChild(colorIndicator);
    teamHeader.appendChild(teamNameSpan);
    list.appendChild(teamHeader);
    
    // Add events for this team
    events.forEach((eventName, eventIndex) => {
      const item = document.createElement('div');
      item.className = 'timeline-events-modal-item';
      item.innerHTML = `
        <span>${eventName}</span>
        <button class="timeline-events-modal-remove" title="Remove">×</button>
      `;
      
      item.querySelector('button').addEventListener('click', () => {
        // Remove event from this specific team
        timelineQuickEvents[selectedTeam].splice(eventIndex, 1);
        // If team has no more events, remove the team entry
        if (timelineQuickEvents[selectedTeam].length === 0) {
          delete timelineQuickEvents[selectedTeam];
        }
        saveQuickEvents();
        renderQuickEventButtons();
        renderEventsModalList();
      });
      
      list.appendChild(item);
    });
  }
  
  function populateTimelineEventSelect() {
    const eventSelect = document.getElementById('distatsTimelineAddEventSelect');
    if (!eventSelect) {
      console.warn('Timeline: Event select element not found');
      return;
    }
    
    eventSelect.innerHTML = '<option value="">Add event...</option>';
    
    // Check if EVENT_CATEGORIES is available
    if (typeof EVENT_CATEGORIES === 'undefined') {
      console.error('Timeline: EVENT_CATEGORIES not defined');
      return;
    }
    
    // Load custom events and combine with standard events
    chrome.storage.local.get(['customEvents'], (result) => {
      const customEventsData = result.customEvents || [];
      
      // Add standard events by category
      EVENT_CATEGORIES.forEach(category => {
        const optgroup = document.createElement('optgroup');
        optgroup.label = category.name;
        
        category.events.forEach(event => {
          const option = document.createElement('option');
          option.value = event;
          option.textContent = event;
          optgroup.appendChild(option);
        });
        
        // Add custom events in this category
        customEventsData.forEach(customEvent => {
          const eventName = typeof customEvent === 'string' ? customEvent : customEvent.name;
          const eventCategory = typeof customEvent === 'string' ? 'Custom' : (customEvent.category || 'Custom');
          
          if (eventCategory === category.name) {
            const option = document.createElement('option');
            option.value = eventName;
            option.textContent = eventName;
            optgroup.appendChild(option);
          }
        });
        
        if (optgroup.children.length > 0) {
          eventSelect.appendChild(optgroup);
        }
      });
      
      // Add custom category for events not in standard categories
      const customCategoryEvents = customEventsData.filter(e => {
        const category = typeof e === 'string' ? 'Custom' : (e.category || 'Custom');
        return !EVENT_CATEGORIES.some(c => c.name === category);
      });
      
      if (customCategoryEvents.length > 0) {
        const customOptgroup = document.createElement('optgroup');
        customOptgroup.label = 'Custom';
        
        customCategoryEvents.forEach(customEvent => {
          const eventName = typeof customEvent === 'string' ? customEvent : customEvent.name;
          const option = document.createElement('option');
          option.value = eventName;
          option.textContent = eventName;
          customOptgroup.appendChild(option);
        });
        
        eventSelect.appendChild(customOptgroup);
      }
    });
  }
  
  // Timeline team data cache
  let timelineTeamsCache = [];
  
  // Store video select change handler to avoid duplicates
  let timelineVideoSelectHandler = null;
  
  function populateTimelineVideoSelect() {
    const videoSelect = document.getElementById('distatsTimelineVideoSelect');
    
    if (!videoSelect) return;
    
    // Remove old change listener if it exists
    if (timelineVideoSelectHandler) {
      videoSelect.removeEventListener('change', timelineVideoSelectHandler);
      timelineVideoSelectHandler = null;
    }
    
    // Reset
    videoSelect.innerHTML = '<option value="">All videos</option>';
    selectedTimelineVideo = null;
    
    if (!currentAnalysisId) return;
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (!analysis || !analysis.videos || analysis.videos.length === 0) {
        return;
      }
      
      // Populate video options - use same format as sidebar
      analysis.videos.forEach(video => {
        const option = document.createElement('option');
        option.value = video.videoUrl || '';
        let videoTitle = video.videoTitle || 'Video';
        
        // Try to decode if it looks like base64 (contains only base64 characters and is long)
        if (videoTitle && /^[A-Za-z0-9+/=]+$/.test(videoTitle) && videoTitle.length > 20) {
          try {
            const decoded = atob(videoTitle);
            // Check if decoded string looks like valid text (not binary)
            if (decoded && /^[\x20-\x7E\s]+$/.test(decoded)) {
              videoTitle = decoded;
              console.log('Decoded base64 video title:', videoTitle);
              // Update the title in storage
              video.videoTitle = videoTitle;
              chrome.storage.local.set({ analyses: analyses }, () => {
                if (!chrome.runtime.lastError) {
                  console.log('Fixed corrupted video title in storage');
                }
              });
            }
          } catch (e) {
            // Not valid base64, use as-is
          }
        }
        
        // Use full title (same as sidebar) - CSS will handle truncation with text-overflow
        option.textContent = videoTitle;
        option.title = videoTitle; // Full title in tooltip
        option.dataset.videoId = video.videoId || '';
        option.dataset.platform = video.platform || '';
        videoSelect.appendChild(option);
      });
      
      // Add change listener to filter markers (store reference to avoid duplicates)
      timelineVideoSelectHandler = (e) => {
        selectedTimelineVideo = e.target.value || null;
        renderTimelineMarkers();
        renderTimelineMarkersOnBar();
      };
      videoSelect.addEventListener('change', timelineVideoSelectHandler);
    });
  }
  
  function populateTimelineTeamSelect() {
    if (!currentAnalysisId) return;
    
    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      // Use global teams storage, fallback to analysis.teams for backward compatibility
      const globalTeams = result.teams || [];
      const analysisTeams = analysis ? (analysis.teams || []) : [];
      
      // Merge global teams with analysis teams (global takes precedence)
      const teamsMap = new Map();
      // First add analysis teams (for backward compatibility)
      analysisTeams.forEach(team => {
        const teamName = getTeamName(team);
        if (teamName) teamsMap.set(teamName.toLowerCase(), ensureTeamObject(team));
      });
      // Then add global teams (overwrites duplicates)
      globalTeams.forEach(team => {
        const teamName = typeof team === 'string' ? team : (team.name || '');
        if (teamName) teamsMap.set(teamName.toLowerCase(), ensureTeamObject(team));
      });
      
      timelineTeamsCache = Array.from(teamsMap.values());
      
      if (timelineTeamsCache.length === 0) {
        return;
      }
      
      // Load selected teams and render selector now that teams are available
      loadSelectedTimelineTeams();
      
      // Reload quick events now that teams are available (this will also render buttons)
      loadAndRenderQuickEvents();
      
      // Re-render player list after teams are loaded
      const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
      if (playerSearchInput) {
        renderTimelinePlayerSelector(playerSearchInput.value || '');
      }
    });
  }
  
  function renderTimelineTeamSelector() {
    const tagsContainer = document.getElementById('distatsTimelineTeamTagsContainer');
    const dropdown = document.getElementById('distatsTimelineTeamDropdown');
    const input = document.getElementById('distatsTimelineTeamSelectorInput');
    
    if (!tagsContainer || !dropdown || !input) return;
    
    // Render tags for selected teams
    tagsContainer.innerHTML = '';
    selectedTimelineTeams.forEach(teamName => {
      const team = timelineTeamsCache.find(t => t.name === teamName);
      if (!team) return;
      
      const teamColor = team.homeColor || '#8b949e';
      
      const tag = document.createElement('div');
      tag.className = 'timeline-team-tag';
      
      const colorIndicator = document.createElement('span');
      colorIndicator.className = 'timeline-team-tag-color';
      colorIndicator.style.background = teamColor;
      
      const tagText = document.createElement('span');
      tagText.textContent = teamName;
      tagText.className = 'timeline-team-tag-text';
      
      const removeBtn = document.createElement('button');
      removeBtn.className = 'timeline-team-tag-remove';
      removeBtn.innerHTML = '×';
      removeBtn.title = 'Remove team';
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        selectedTimelineTeams.delete(teamName);
        saveSelectedTimelineTeams();
        renderTimelineTeamSelector();
        renderQuickEventButtons();
        // Re-render player selector to show players from selected teams
        const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
        renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
      });
      
      tag.appendChild(colorIndicator);
      tag.appendChild(tagText);
      tag.appendChild(removeBtn);
      tagsContainer.appendChild(tag);
    });
    
    // Render dropdown items
    dropdown.innerHTML = '';
    if (!timelineTeamsCache || timelineTeamsCache.length === 0) {
      const noTeams = document.createElement('div');
      noTeams.className = 'timeline-team-dropdown-empty';
      noTeams.textContent = 'No teams available';
      noTeams.style.padding = '8px 12px';
      noTeams.style.color = '#8b949e';
      noTeams.style.fontSize = '12px';
      dropdown.appendChild(noTeams);
      return;
    }
    
    timelineTeamsCache.forEach(team => {
      const teamName = team.name;
      const teamColor = team.homeColor || '#8b949e';
      const isSelected = selectedTimelineTeams.has(teamName);
      
      const item = document.createElement('div');
      item.className = 'timeline-team-dropdown-item';
      if (isSelected) {
        item.classList.add('selected');
  }
  
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = isSelected;
      checkbox.style.marginRight = '8px';
      checkbox.style.cursor = 'pointer';
      
      const colorIndicator = document.createElement('span');
      colorIndicator.className = 'timeline-team-dropdown-color';
      colorIndicator.style.background = teamColor;
      colorIndicator.style.width = '12px';
      colorIndicator.style.height = '12px';
      colorIndicator.style.borderRadius = '3px';
      colorIndicator.style.marginRight = '6px';
      colorIndicator.style.flexShrink = '0';
      
      const label = document.createElement('span');
      label.textContent = teamName;
      label.style.fontSize = '12px';
      label.style.color = '#c9d1d9';
      
      item.appendChild(checkbox);
      item.appendChild(colorIndicator);
      item.appendChild(label);
      
      // Handle checkbox click separately
      checkbox.addEventListener('click', (e) => {
        e.stopPropagation();
        if (checkbox.checked) {
          selectedTimelineTeams.add(teamName);
          item.classList.add('selected');
        } else {
          selectedTimelineTeams.delete(teamName);
          item.classList.remove('selected');
        }
        saveSelectedTimelineTeams();
        renderTimelineTeamSelector();
        renderQuickEventButtons();
        // Re-render player selector to show players from selected teams
        const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
        renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
      });
      
      // Handle clicking on the item (but not the checkbox)
      item.addEventListener('click', (e) => {
        // Don't handle if clicking directly on checkbox (it's already handled above)
        if (e.target === checkbox) {
          return;
        }
        e.stopPropagation();
        if (checkbox.checked) {
          selectedTimelineTeams.delete(teamName);
          checkbox.checked = false;
          item.classList.remove('selected');
        } else {
          selectedTimelineTeams.add(teamName);
          checkbox.checked = true;
          item.classList.add('selected');
        }
        saveSelectedTimelineTeams();
        renderTimelineTeamSelector();
        renderQuickEventButtons();
        // Re-render player selector to show players from selected teams
        const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
        renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
      });
      
      dropdown.appendChild(item);
    });
  }
  
  function setupTimelineTeamSelector() {
    const input = document.getElementById('distatsTimelineTeamSelectorInput');
    const dropdown = document.getElementById('distatsTimelineTeamDropdown');
    const teamSelector = document.querySelector('.timeline-team-selector');
    
    if (!input || !dropdown) return;
    
    // Function to adjust spacing based on actual dropdown height
    function adjustSpacing(isOpen) {
      if (teamSelector) {
        if (isOpen && dropdown.style.display !== 'none') {
          // Calculate actual dropdown height + spacing
          const dropdownHeight = dropdown.offsetHeight || 0;
          const spacing = 8; // Small gap between dropdown and next section
          const totalMargin = dropdownHeight + spacing;
          teamSelector.style.marginBottom = `${totalMargin}px`;
        } else {
          // Restore normal margin
          teamSelector.style.marginBottom = '';
        }
      }
    }
    
    // Function to toggle dropdown visibility and spacing
    function toggleDropdown(show) {
      if (show) {
        dropdown.style.display = 'block';
        // Use setTimeout to ensure dropdown is rendered before calculating height
        setTimeout(() => {
          adjustSpacing(true);
        }, 0);
      } else {
        dropdown.style.display = 'none';
        adjustSpacing(false);
      }
    }
    
    // Open dropdown on input click
    input.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = dropdown.style.display !== 'none';
      toggleDropdown(!isOpen);
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !dropdown.contains(e.target)) {
        toggleDropdown(false);
      }
    });
    
    // Prevent closing when clicking inside dropdown
    dropdown.addEventListener('click', (e) => {
      e.stopPropagation();
    });
  }
  
  function setupTimelinePlayerSelector() {
    const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
    const playerSelectorDropdown = document.getElementById('distatsTimelinePlayerSelectorDropdown');
    const addPlayerBtn = document.getElementById('distatsTimelineAddPlayerBtn');
    const playerList = document.getElementById('distatsTimelinePlayerList');
    const selectedPlayersDisplay = document.getElementById('distatsTimelineSelectedPlayersDisplay');
    const playerSelector = document.querySelector('.timeline-player-selector');

    if (!playerSearchInput || !playerSelectorDropdown || !playerList || !selectedPlayersDisplay) return;

    // Function to adjust spacing based on actual dropdown height
    function adjustSpacing(isOpen) {
      if (playerSelector) {
        if (isOpen && playerSelectorDropdown.style.display !== 'none') {
          // Calculate actual dropdown height + minimal spacing
          setTimeout(() => {
            const dropdownHeight = playerSelectorDropdown.offsetHeight || 0;
            const spacing = 4; // Minimal gap between dropdown and next section
            const totalMargin = dropdownHeight + spacing;
            playerSelector.style.marginBottom = `${totalMargin}px`;
          }, 50); // Slightly longer delay to ensure content is rendered
        } else {
          // Restore normal margin
          playerSelector.style.marginBottom = '';
        }
      }
    }

    // Function to toggle dropdown visibility and spacing
    function toggleDropdown(show) {
      if (show) {
        playerSelectorDropdown.style.display = 'block';
        renderTimelinePlayerSelector(playerSearchInput.value);
        // Use setTimeout to ensure dropdown is rendered before calculating height
        setTimeout(() => {
          adjustSpacing(true);
        }, 0);
      } else {
        playerSelectorDropdown.style.display = 'none';
        adjustSpacing(false);
      }
    }
    
    // Show dropdown on search input focus
    playerSearchInput.addEventListener('focus', () => {
      toggleDropdown(true);
    });

    // Also show dropdown on click
    playerSearchInput.addEventListener('click', () => {
      toggleDropdown(true);
    });

    playerSearchInput.addEventListener('input', (e) => {
      // Show dropdown when typing
      toggleDropdown(true);
    });

    playerSearchInput.addEventListener('blur', (e) => {
      setTimeout(() => {
        if (!playerSelectorDropdown.matches(':hover') && document.activeElement !== playerSearchInput) {
          toggleDropdown(false);
        }
      }, 200);
    });

    // Keep dropdown open when hovering (don't adjust spacing on hover)
    playerSelectorDropdown.addEventListener('mouseenter', () => {
      playerSelectorDropdown.style.display = 'block';
    });

    playerSelectorDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== playerSearchInput) {
        playerSelectorDropdown.style.display = 'none';
        adjustSpacing(false);
      }
    });
    
    if (addPlayerBtn) {
      addPlayerBtn.addEventListener('click', () => {
        createNewPlayerForTimeline();
      });
    }
    
    // Initial render - don't show dropdown by default
    if (playerSelectorDropdown) {
      playerSelectorDropdown.style.display = 'none';
    }
    // Don't render players initially - only show when user interacts
    // renderTimelinePlayerSelector('');
    updateTimelineSelectedPlayersDisplay();
  }
  
  function renderTimelinePlayerSelector(searchQuery = '') {
    const playerList = document.getElementById('distatsTimelinePlayerList');
    const playerSelectorDropdown = document.getElementById('distatsTimelinePlayerSelectorDropdown');
    const playerSelector = document.querySelector('.timeline-player-selector');
    
    if (!playerList) return;
    
    // Always show the player list (not just in dropdown)
    // The player list should be visible even when dropdown is closed
    // Note: The playerList is inside the dropdown, but we want it visible
    // So we'll show the dropdown if there are players to display
    if (playerSelectorDropdown) {
      // Check if we have players after filtering (will be checked in the async callback)
      // For now, just ensure the list container is ready
    }
    
    chrome.storage.local.get(['players', 'analyses'], (result) => {
      const players = result.players || [];
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      // Filter players by selected teams - REQUIRED
      const selectedTeamsArray = Array.from(selectedTimelineTeams);
      let filteredPlayers = [];
      
      console.log('renderTimelinePlayerSelector called:', {
        selectedTimelineTeamsSize: selectedTimelineTeams.size,
        selectedTeamsArray: selectedTeamsArray,
        currentAnalysisId: currentAnalysisId,
        totalPlayers: players.length
      });
      
      if (selectedTeamsArray.length === 0) {
        // No teams selected - show message
        playerList.innerHTML = '';
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.textAlign = 'center';
        emptyMsg.style.fontSize = '12px';
        emptyMsg.textContent = 'Select teams above to see their players';
        playerList.appendChild(emptyMsg);
        return;
      }
      
      // Filter by selected teams - use simple string comparison like sidebar does
      filteredPlayers = players.filter(player => {
        // Get player team as string (handle both string and object formats)
        const playerTeam = typeof player.team === 'string' ? player.team : (player.team?.name || '');
        
        // Check if player's team matches any selected team (exact match)
        return selectedTeamsArray.includes(playerTeam);
      });
      
      // Debug logging
      const allPlayerTeams = [...new Set(players.map(p => typeof p.team === 'string' ? p.team : (p.team?.name || '')))];
      console.log('Timeline Player Filtering:', {
        selectedTeams: selectedTeamsArray,
        totalPlayers: players.length,
        filteredCount: filteredPlayers.length,
        allPlayerTeams: allPlayerTeams,
        samplePlayers: players.slice(0, 10).map(p => {
          const pt = typeof p.team === 'string' ? p.team : (p.team?.name || '');
          return {
            name: p.fullName,
            team: p.team,
            teamType: typeof p.team,
            playerTeamString: pt,
            matches: selectedTeamsArray.includes(pt)
          };
        }),
        matches: selectedTeamsArray.some(st => allPlayerTeams.includes(st)),
        selectedTeamsInPlayerTeams: selectedTeamsArray.filter(st => allPlayerTeams.includes(st))
      });
      
      // Filter by search query
      if (searchQuery && searchQuery.trim()) {
        const searchLower = searchQuery.toLowerCase().trim();
        filteredPlayers = filteredPlayers.filter(player => {
          const fullName = (player.fullName || '').toLowerCase();
          const number = (player.number || '').toString();
          const lastName = (player.lastName || '').toLowerCase();
          const firstName = (player.firstName || '').toLowerCase();
          return fullName.includes(searchLower) || 
                 number.includes(searchLower) ||
                 lastName.includes(searchLower) ||
                 firstName.includes(searchLower);
        });
      }
      
      playerList.innerHTML = '';
      
      // Don't control dropdown visibility here - let event handlers manage it
      // Just adjust spacing if dropdown is already visible
      if (playerSelectorDropdown && playerSelectorDropdown.style.display === 'block') {
        // Adjust spacing after rendering - minimal margin since dropdown overlays
        setTimeout(() => {
          if (playerSelector && playerSelectorDropdown.offsetHeight > 0) {
            const dropdownHeight = playerSelectorDropdown.offsetHeight || 0;
            // Use minimal margin since dropdown is absolutely positioned and overlays
            const totalMargin = Math.min(dropdownHeight * 0.3 + 4, 60); // Cap at 60px max
            playerSelector.style.marginBottom = `${totalMargin}px`;
          }
        }, 0);
      }
      
      if (filteredPlayers.length === 0) {
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.style.textAlign = 'center';
        emptyMsg.style.fontSize = '12px';
        if (searchQuery && searchQuery.trim()) {
          emptyMsg.textContent = `No players found matching "${searchQuery}" in selected team${selectedTeamsArray.length > 1 ? 's' : ''}: ${selectedTeamsArray.join(', ')}`;
        } else {
          // Show more helpful message with available teams from players
          const availableTeams = [...new Set(players.map(p => {
            const pt = typeof p.team === 'string' ? p.team : (p.team?.name || 'No team');
            return pt;
          }))];
          emptyMsg.innerHTML = `No players found in selected team${selectedTeamsArray.length > 1 ? 's' : ''}: ${selectedTeamsArray.join(', ')}<br><small style="color: #6e7681; margin-top: 4px; display: block;">Available teams in players: ${availableTeams.length > 0 ? availableTeams.join(', ') : 'None'}</small>`;
        }
        playerList.appendChild(emptyMsg);
        return;
      }
      
      // Group by team
      const playersByTeam = {};
      filteredPlayers.forEach(player => {
        const team = typeof player.team === 'string' ? player.team : (player.team?.name || 'No team');
        if (!playersByTeam[team]) {
          playersByTeam[team] = [];
        }
        playersByTeam[team].push(player);
      });
      
      // Sort teams
      const sortedTeams = Object.keys(playersByTeam).sort();
      
      sortedTeams.forEach(team => {
        // Render players directly without team grouping div to match team dropdown style
        playersByTeam[team].sort((a, b) => {
          const numA = parseInt(a.number) || 0;
          const numB = parseInt(b.number) || 0;
          return numA - numB;
        }).forEach(player => {
          const playerItem = document.createElement('div');
          playerItem.className = 'timeline-player-dropdown-item';
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = player.id;
          checkbox.checked = selectedTimelinePlayers.includes(player.id);
          
          checkbox.addEventListener('click', (e) => {
            e.stopPropagation();
          });
          
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedTimelinePlayers.includes(player.id)) {
                selectedTimelinePlayers.push(player.id);
              }
            } else {
              selectedTimelinePlayers = selectedTimelinePlayers.filter(id => id !== player.id);
            }
            updateTimelineSelectedPlayersDisplay();
            const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
            renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
          });
          
          const label = document.createElement('span');
          const displayText = player.number ? 
            `#${player.number} ${player.fullName || ''}`.trim() : 
            (player.fullName || 'Unnamed');
          label.textContent = displayText;
          
          label.addEventListener('click', (e) => {
            e.stopPropagation();
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
          });
          
          playerItem.addEventListener('click', (e) => {
            // Don't toggle if clicking directly on checkbox or label (they handle it)
            if (e.target === checkbox || e.target === label || e.target === playerItem) {
              if (e.target === playerItem) {
                checkbox.checked = !checkbox.checked;
                checkbox.dispatchEvent(new Event('change'));
              }
              return;
            }
          });
          
          playerItem.appendChild(checkbox);
          playerItem.appendChild(label);
          playerList.appendChild(playerItem);
        });
      });
      
      // Dropdown visibility is already handled above in the visibility check
      // No need to force show here - it will show when input is focused
    });
  }
  
  function updateTimelineSelectedPlayersDisplay() {
    const selectedPlayersDisplay = document.getElementById('distatsTimelineSelectedPlayersDisplay');
    if (!selectedPlayersDisplay) return;
    
    if (selectedTimelinePlayers.length === 0) {
      selectedPlayersDisplay.innerHTML = '';
      selectedPlayersDisplay.style.display = 'none';
      return;
    }
    
    selectedPlayersDisplay.style.display = 'flex';
    
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const selectedPlayerObjects = players.filter(p => selectedTimelinePlayers.includes(p.id));
      
      selectedPlayersDisplay.innerHTML = '';
      
      selectedPlayerObjects.forEach(player => {
        const tag = document.createElement('span');
        tag.className = 'selected-player-tag';
        
        const displayText = player.number ? 
          `#${player.number} ${player.fullName || ''}`.trim() : 
          (player.fullName || 'Unnamed');
        tag.textContent = displayText;
        
        const removeBtn = document.createElement('span');
        removeBtn.className = 'remove-btn';
        removeBtn.textContent = ' ×';
        removeBtn.addEventListener('click', () => {
          selectedTimelinePlayers = selectedTimelinePlayers.filter(id => id !== player.id);
          updateTimelineSelectedPlayersDisplay();
          const playerSearchInput = document.getElementById('distatsTimelinePlayerSearchInput');
          renderTimelinePlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        });
        
        tag.appendChild(removeBtn);
        selectedPlayersDisplay.appendChild(tag);
      });
    });
  }
  
  function createNewPlayerForTimeline() {
    // Use the same player modal as in popup
    if (typeof openPlayerModal === 'function') {
      openPlayerModal();
    } else {
      // Fallback: show alert
      alert('Please create players from the main interface first');
    }
  }
  
  function updateTimelineProjectName() {
    const projectNameEl = document.getElementById('distatsTimelineProjectName');
    if (!projectNameEl) return;
    
    if (currentAnalysisId) {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        if (analysis) {
          projectNameEl.textContent = analysis.name || 'Unnamed Project';
        } else {
          projectNameEl.textContent = 'No project';
        }
      });
    } else {
      projectNameEl.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project selected';
    }
  }
  
  function startTimelineUpdates() {
    // Clear any existing interval
    if (timelineUpdateInterval) {
      clearInterval(timelineUpdateInterval);
    }
    
    // Update immediately
    updateTimelineTime();
    
    // Update every 250ms
    timelineUpdateInterval = setInterval(updateTimelineTime, 250);
  }
  
  function updateTimelineTime() {
    const video = document.querySelector('video');
    if (!video) return;
    
    const currentTime = video.currentTime || 0;
    const duration = video.duration || 0;
    
    // Update time displays
    const currentTimeEl = document.getElementById('distatsTimelineCurrentTime');
    const durationEl = document.getElementById('distatsTimelineDuration');
    
    if (currentTimeEl) {
      currentTimeEl.textContent = formatTimelineTime(currentTime);
    }
    if (durationEl) {
      durationEl.textContent = formatTimelineTime(duration);
    }
    
    // Update playhead position
    const playhead = document.getElementById('distatsTimelinePlayhead');
    const progress = document.getElementById('distatsTimelineProgress');
    
    if (playhead && progress && duration > 0) {
      const percent = (currentTime / duration) * 100;
      playhead.style.left = `${percent}%`;
      progress.style.width = `${percent}%`;
    }
  }
  
  function formatTimelineTime(seconds) {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
  
  function parseTimelineTime(timeStr) {
    if (!timeStr) return 0;
    
    const parts = timeStr.split(':').map(p => parseInt(p, 10) || 0);
    
    if (parts.length === 3) {
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    } else if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    } else {
      return parts[0] || 0;
    }
  }
  
  function setupTimelineBarHandler() {
    const timelineBar = document.getElementById('distatsTimelineBar');
    if (!timelineBar) return;
    
    timelineBar.addEventListener('click', (e) => {
      const video = document.querySelector('video');
      if (!video || !video.duration) return;
      
      const rect = timelineBar.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const percent = clickX / rect.width;
      const seekTime = percent * video.duration;
      
      video.currentTime = seekTime;
      updateTimelineTime();
    });
  }
  
  function setupTimelineManualTime() {
    const manualTimeInput = document.getElementById('distatsTimelineManualTime');
    const gotoBtn = document.getElementById('distatsTimelineGotoTime');
    
    if (gotoBtn && manualTimeInput) {
      gotoBtn.addEventListener('click', () => {
        const video = document.querySelector('video');
        if (!video) return;
        
        const seconds = parseTimelineTime(manualTimeInput.value);
        if (seconds >= 0 && seconds <= video.duration) {
          video.currentTime = seconds;
          updateTimelineTime();
        }
      });
      
      manualTimeInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          gotoBtn.click();
        }
      });
    }
  }
  
  function addTimelineMarker(team, eventType, players = null) {
    const video = document.querySelector('video');
    if (!video) {
      console.log('No video found');
      return;
    }
    
    if (!currentAnalysisId) {
      alert('Please select a project first');
      return;
    }
    
    // Use provided players or get from selected timeline players
    const markerPlayers = players !== null ? players : [...selectedTimelinePlayers];
    
    // Get video title from analysis
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const videos = analysis ? (analysis.videos || []) : [];
      const currentVideoUrl = window.location.href;
      
      // Find current video to get its title
      let videoTitle = null;
      const currentVideo = videos.find(v => v.videoUrl === currentVideoUrl);
      if (currentVideo && currentVideo.videoTitle) {
        videoTitle = currentVideo.videoTitle;
      } else {
        // Fallback: try to get from page title
        const pageTitle = getVideoTitle();
        if (pageTitle && pageTitle !== `${platform} Video`) {
          videoTitle = pageTitle;
        }
      }
      
      const marker = {
        id: `marker_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        time: video.currentTime,
        team: team,
        event: eventType,
        players: markerPlayers, // Array of player IDs
        videoUrl: currentVideoUrl,
        videoTitle: videoTitle,
        createdAt: Date.now()
      };
      
      timelineMarkers.push(marker);
      
      // Convert marker to comment and add to analysis.notes
      convertTimelineMarkerToComment(marker, analysis, analyses);
      
      // Save both markers and analyses together
      const storageKey = `timelineMarkers_${currentAnalysisId}`;
      
      // Set a flag to prevent duplicate rendering from storage listener
      window._isAddingMarker = true;
      
      chrome.storage.local.set({ 
        [storageKey]: timelineMarkers,
        analyses: analyses 
      }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error saving marker:', chrome.runtime.lastError);
          window._isAddingMarker = false;
        } else {
          // Only render the timeline bar immediately, let storage listener handle list after delay
          renderTimelineMarkersOnBar();
      console.log('Added timeline marker:', marker);
          
          // Clear flag after a short delay to allow storage listener to process
          setTimeout(() => {
            window._isAddingMarker = false;
            // Manually trigger render after flag is cleared
            renderTimelineMarkers();
          }, 300);
        }
      });
    });
  }
  
  function convertTimelineMarkerToComment(marker, analysis, analyses) {
    if (!marker || !analysis) return;
    
    // Check if comment already exists for this marker (by marker.id)
    const existingNote = analysis.notes?.find(note => note.markerId === marker.id);
    if (existingNote) {
      // Update existing comment
      existingNote.team = marker.team;
      existingNote.players = marker.players || [];
      existingNote.events = [marker.event];
      existingNote.videoTime = marker.time;
      existingNote.timestamp = marker.createdAt;
      existingNote.videoUrl = marker.videoUrl;
      existingNote.videoTitle = marker.videoTitle;
      
      // Generate text from event and players
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const playerNames = (marker.players || []).map(playerId => {
          const player = players.find(p => p.id === playerId);
          if (!player) return null;
          return player.number ? `#${player.number} ${player.fullName || ''}`.trim() : (player.fullName || 'Unnamed');
        }).filter(Boolean);
        
        if (playerNames.length > 0) {
          existingNote.text = `${marker.event} by ${playerNames.join(', ')}`;
        } else {
          existingNote.text = marker.event;
        }
        
        // Don't save here - let the caller handle saving to avoid duplicate storage triggers
      });
      return;
    }
    
    // Create new comment from marker
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const playerNames = (marker.players || []).map(playerId => {
        const player = players.find(p => p.id === playerId);
        if (!player) return null;
        return player.number ? `#${player.number} ${player.fullName || ''}`.trim() : (player.fullName || 'Unnamed');
      }).filter(Boolean);
      
      let commentText = marker.event;
      if (playerNames.length > 0) {
        commentText = `${marker.event} by ${playerNames.join(', ')}`;
      }
      
      const comment = {
        id: `comment_${marker.id}`,
        markerId: marker.id, // Link back to marker
        text: commentText,
        team: marker.team,
        players: marker.players || [],
        events: [marker.event],
        videoTime: marker.time,
        timestamp: marker.createdAt,
        videoUrl: marker.videoUrl,
        videoTitle: marker.videoTitle,
        source: 'timeline' // Distinguish from manual comments
      };
      
      // Initialize notes array if it doesn't exist
      if (!analysis.notes) {
        analysis.notes = [];
      }
      
      // Add comment to analysis
      analysis.notes.push(comment);
      
      // Don't save here - let the caller handle saving to avoid duplicate storage triggers
    });
  }
  
  function loadTimelineMarkers() {
    if (!currentAnalysisId) {
      timelineMarkers = [];
      renderTimelineMarkers();
      renderTimelineMarkersOnBar();
      return;
    }
    
    const storageKey = `timelineMarkers_${currentAnalysisId}`;
    chrome.storage.local.get([storageKey], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error loading timeline markers:', chrome.runtime.lastError);
        timelineMarkers = [];
      } else {
        // Load all markers (not filtered by video)
        const loadedMarkers = result[storageKey] || [];
        
        // Ensure all markers have players field (for backward compatibility)
        timelineMarkers = loadedMarkers.map(marker => {
          // Create a new object to ensure all fields are preserved
          const cleanMarker = {
            ...marker,
            players: marker.players || [] // Ensure players array exists
          };
          return cleanMarker;
        });
        
        console.log('Loaded timeline markers:', timelineMarkers.length, 'markers for analysis', currentAnalysisId);
      }
      
      // Sort by time
      timelineMarkers.sort((a, b) => a.time - b.time);
      
      // Remove duplicates by ID before rendering
      const seenIds = new Set();
      const uniqueMarkers = [];
      timelineMarkers.forEach(marker => {
        if (!seenIds.has(marker.id)) {
          seenIds.add(marker.id);
          uniqueMarkers.push(marker);
        } else {
          console.warn('Duplicate marker found and removed:', marker.id);
        }
      });
      
      // Update timelineMarkers if duplicates were found
      if (uniqueMarkers.length < timelineMarkers.length) {
        timelineMarkers = uniqueMarkers;
        // Save cleaned markers back to storage
        saveTimelineMarkers();
      }
      
      renderTimelineMarkers();
      renderTimelineMarkersOnBar();
    });
  }
  
  function saveTimelineMarkers() {
    if (!currentAnalysisId) {
      console.warn('Cannot save timeline markers: no currentAnalysisId');
      return;
    }
    
    const storageKey = `timelineMarkers_${currentAnalysisId}`;
    
    // Save all markers (timelineMarkers now contains all markers from all videos)
    chrome.storage.local.set({ [storageKey]: timelineMarkers }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error saving timeline markers:', chrome.runtime.lastError);
      } else {
        console.log('Timeline markers saved:', timelineMarkers.length, 'markers');
      }
    });
  }
  
  function deleteTimelineMarker(markerId) {
    timelineMarkers = timelineMarkers.filter(m => m.id !== markerId);
    saveTimelineMarkers();
    
    // Also delete corresponding comment from analysis.notes
    if (currentAnalysisId) {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        if (analysis && analysis.notes) {
          analysis.notes = analysis.notes.filter(note => note.markerId !== markerId);
          chrome.storage.local.set({ analyses: analyses });
        }
      });
    }
    
    renderTimelineMarkers();
    renderTimelineMarkersOnBar();
  }
  
  function renderTimelineMarkers() {
    const listEl = document.getElementById('distatsTimelineMarkersList');
    const countEl = document.getElementById('distatsTimelineMarkerCount');
    
    if (!listEl) return;
    
    // Filter markers by selected video
    let filteredMarkers = timelineMarkers;
    if (selectedTimelineVideo) {
      const normalizedSelectedUrl = normalizeVideoUrl(selectedTimelineVideo);
      filteredMarkers = timelineMarkers.filter(m => {
        const normalizedMarkerUrl = normalizeVideoUrl(m.videoUrl);
        return normalizedMarkerUrl === normalizedSelectedUrl;
      });
    }
    
    if (countEl) {
      countEl.textContent = filteredMarkers.length;
    }
    
    if (filteredMarkers.length === 0) {
      listEl.innerHTML = '<div class="timeline-no-markers">No markers found. Select a team and event, then click an event button to add a marker.</div>';
      return;
    }
    
    listEl.innerHTML = '';
    
    // Get videos from analysis to match markers to videos
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const videos = analysis ? (analysis.videos || []) : [];
      
      // Sort by time (most recent first for display)
      const sortedMarkers = [...filteredMarkers].sort((a, b) => b.time - a.time);
      
      // Load players first for all markers
      chrome.storage.local.get(['players'], (playersResult) => {
        const allPlayers = playersResult.players || [];
      
      sortedMarkers.forEach(marker => {
        // Find team color from cache
        const team = timelineTeamsCache.find(t => t.name === marker.team);
        const teamColor = team ? (team.homeColor || '#8b949e') : '#8b949e';
        const teamName = marker.team || 'Unknown';
        const eventName = marker.event || 'Event';
        
        // Find video for this marker
        let markerVideo = null;
        if (marker.videoUrl) {
          markerVideo = videos.find(v => v.videoUrl === marker.videoUrl);
        }
        
        // Get video title
        let videoTitle = null;
        if (markerVideo && markerVideo.videoTitle) {
          videoTitle = markerVideo.videoTitle;
        } else if (marker.videoTitle) {
          videoTitle = marker.videoTitle;
        }
          
          // Get player names
          let playerNamesText = '';
          if (marker.players && marker.players.length > 0) {
            const playerNames = marker.players.map(playerId => {
              const player = allPlayers.find(p => p.id === playerId);
              if (!player) return null;
              return player.number ? `#${player.number} ${player.fullName || ''}`.trim() : (player.fullName || 'Unnamed');
            }).filter(Boolean);
            
            if (playerNames.length > 0) {
              playerNamesText = playerNames.join(', ');
            }
        }
        
        const item = document.createElement('div');
        item.className = 'timeline-marker-item';
        
        let markerInfoHTML = `
          <div class="marker-color" style="background: ${teamColor}"></div>
          <div class="marker-info">
            <div class="marker-event">${eventName}</div>
            <div class="marker-team">${teamName}</div>
              ${playerNamesText ? `<div class="marker-players" style="font-size: 10px; color: #6e7681; margin-top: 2px;">${playerNamesText}</div>` : ''}
        `;
        
        if (videoTitle) {
          const maxTitleLength = 30;
          const truncatedTitle = videoTitle.length > maxTitleLength 
            ? videoTitle.substring(0, maxTitleLength) + '...' 
            : videoTitle;
          markerInfoHTML += `<div class="marker-video">${truncatedTitle}</div>`;
        }
        
        markerInfoHTML += `
          </div>
          <div class="marker-time">${formatTimelineTime(marker.time)}</div>
          <button class="marker-delete" title="Delete marker">×</button>
        `;
        
        item.innerHTML = markerInfoHTML;
        
        // Click to open video at timestamp
        item.addEventListener('click', (e) => {
          if (e.target.closest('.marker-delete')) return;
          
          if (!marker.videoUrl) {
            console.warn('Marker has no video URL');
            return;
          }
          
          // Construct URL with timestamp
          let urlWithTime = '';
          try {
            const url = new URL(marker.videoUrl);
            const hostname = url.hostname.toLowerCase();
            
            if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
              url.searchParams.delete('t');
              url.searchParams.delete('start');
              url.searchParams.set('t', Math.floor(marker.time));
              urlWithTime = url.toString();
            } else if (hostname.includes('dailymotion.com')) {
              url.hash = `#t=${Math.floor(marker.time)}`;
              urlWithTime = url.toString();
            } else if (hostname.includes('twitch.tv')) {
              const hours = Math.floor(marker.time / 3600);
              const minutes = Math.floor((marker.time % 3600) / 60);
              const secs = Math.floor(marker.time % 60);
              const twitchTime = `${hours}h${minutes}m${secs}s`;
              url.searchParams.set('t', twitchTime);
              urlWithTime = url.toString();
            } else {
              // Generic fallback
              url.searchParams.set('t', Math.floor(marker.time));
              urlWithTime = url.toString();
            }
            
            // Open in new tab
            window.open(urlWithTime, '_blank');
          } catch (error) {
            console.error('Error constructing video URL with time:', error);
            // Fallback: open video URL without time
            window.open(marker.videoUrl, '_blank');
          }
        });
        
        // Delete button
        item.querySelector('.marker-delete').addEventListener('click', (e) => {
          e.stopPropagation();
          deleteTimelineMarker(marker.id);
        });
        
        listEl.appendChild(item);
        });
      });
    });
  }
  
  function renderTimelineMarkersOnBar() {
    const markersBar = document.getElementById('distatsTimelineMarkersBar');
    if (!markersBar) return;
    
    markersBar.innerHTML = '';
    
    const video = document.querySelector('video');
    if (!video || !video.duration) return;
    
    // Determine which video to show markers for
    const currentVideoUrl = window.location.href;
    const normalizedCurrentUrl = normalizeVideoUrl(currentVideoUrl);
    const targetVideoUrl = selectedTimelineVideo ? selectedTimelineVideo : currentVideoUrl;
    const normalizedTargetUrl = normalizeVideoUrl(targetVideoUrl);
    
    // Filter markers for the target video
    const markersToShow = timelineMarkers.filter(marker => {
      const normalizedMarkerUrl = normalizeVideoUrl(marker.videoUrl);
      return normalizedMarkerUrl === normalizedTargetUrl;
    });
    
    markersToShow.forEach(marker => {
      const percent = (marker.time / video.duration) * 100;
      // Find team color from cache
      const team = timelineTeamsCache.find(t => t.name === marker.team);
      const teamColor = team ? (team.homeColor || '#8b949e') : '#8b949e';
      
      const normalizedMarkerUrl = normalizeVideoUrl(marker.videoUrl);
      
      const dot = document.createElement('div');
      dot.className = 'timeline-marker-dot';
      dot.style.left = `${percent}%`;
      dot.innerHTML = `<div class="timeline-marker-dot-inner" style="background: ${teamColor}"></div>`;
      
      dot.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // If marker is for current video, seek in place
        if (normalizedMarkerUrl === normalizedCurrentUrl) {
          video.currentTime = marker.time;
          updateTimelineTime();
        } else {
          // Otherwise, open video URL at timestamp
          if (!marker.videoUrl) return;
          
          let urlWithTime = '';
          try {
            const url = new URL(marker.videoUrl);
            const hostname = url.hostname.toLowerCase();
            
            if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
              url.searchParams.delete('t');
              url.searchParams.delete('start');
              url.searchParams.set('t', Math.floor(marker.time));
              urlWithTime = url.toString();
            } else if (hostname.includes('dailymotion.com')) {
              url.hash = `#t=${Math.floor(marker.time)}`;
              urlWithTime = url.toString();
            } else if (hostname.includes('twitch.tv')) {
              const hours = Math.floor(marker.time / 3600);
              const minutes = Math.floor((marker.time % 3600) / 60);
              const secs = Math.floor(marker.time % 60);
              const twitchTime = `${hours}h${minutes}m${secs}s`;
              url.searchParams.set('t', twitchTime);
              urlWithTime = url.toString();
            } else {
              url.searchParams.set('t', Math.floor(marker.time));
              urlWithTime = url.toString();
            }
            
            window.open(urlWithTime, '_blank');
          } catch (error) {
            console.error('Error constructing video URL with time:', error);
            window.open(marker.videoUrl, '_blank');
          }
        }
      });
      
      markersBar.appendChild(dot);
    });
  }
  
  // ========== AI ANALYSIS FUNCTIONS (copied from popup.js) ==========
  
  // Load OpenAI API key from storage
  function loadOpenAIKey() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['openai_api_key'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(result.openai_api_key || null);
        }
      });
    });
  }

  function validateAPIKey(key) {
    if (!key || typeof key !== 'string') {
      return false;
    }
    return key.trim().startsWith('sk-') && key.trim().length >= 20;
  }

  // Data Collection Function
  async function collectAnalysisData(analysisId) {
    return new Promise((resolve, reject) => {
      if (!analysisId) {
        reject(new Error('No analysis ID provided'));
        return;
      }

      chrome.storage.local.get(['analyses', `timelineMarkers_${analysisId}`], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === analysisId);

        if (!analysis) {
          reject(new Error('Analysis not found'));
          return;
        }

        const timelineMarkers = result[`timelineMarkers_${analysisId}`] || [];

        // Collect tactical editor schemes and regular images from notes
        const tacticalSchemes = [];
        const regularImages = [];
        if (analysis.notes) {
          analysis.notes.forEach(note => {
            if (note.images && Array.isArray(note.images)) {
              note.images.forEach(image => {
                if (typeof image === 'object' && image.slidesData && Array.isArray(image.slidesData) && image.slidesData.length > 0) {
                  tacticalSchemes.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    slidesData: image.slidesData,
                    slides: image.slidesData || []
                  });
                } else if (typeof image === 'string' || (typeof image === 'object' && image.imageData)) {
                  regularImages.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    imageData: typeof image === 'string' ? image : image.imageData
                  });
                }
              });
            } else if (note.image) {
              if (typeof note.image === 'string') {
                regularImages.push({
                  timestamp: note.timestamp,
                  videoTime: note.videoTime,
                  timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                  imageData: note.image
                });
              }
            }
          });
        }

        const data = {
          analysis: {
            id: analysis.id,
            name: analysis.name,
            date: analysis.date,
            createdAt: analysis.createdAt,
            videos: analysis.videos || []
          },
          notes: analysis.notes || [],
          timelineMarkers: timelineMarkers,
          tacticalSchemes: tacticalSchemes,
          regularImages: regularImages,
          userTeam: analysis.userTeam || null
        };

        resolve(data);
      });
    });
  }

  // Helper function to get zone number from field position (9-zone system for tactical schemes)
  function getZoneNumber(x, y, canvasWidth = 1000, canvasHeight = 600) {
    const relX = (x / canvasWidth) * 100;
    const relY = (y / canvasHeight) * 100;
    
    let zoneX = 1; // left
    if (relX >= 33 && relX < 67) zoneX = 2; // center
    else if (relX >= 67) zoneX = 3; // right
    
    let zoneY = 1; // defensive
    if (relY >= 33 && relY < 67) zoneY = 2; // midfield
    else if (relY >= 67) zoneY = 3; // attacking
    
    return (zoneY - 1) * 3 + zoneX; // Zone 1-9
  }

  // Helper to get zones for a shape
  function getZonesForShape(shape, canvasWidth = 1000, canvasHeight = 600) {
    const zones = new Set();
    const points = [
      {x: shape.startX, y: shape.startY},
      {x: shape.endX, y: shape.startY},
      {x: shape.startX, y: shape.endY},
      {x: shape.endX, y: shape.endY},
      {x: (shape.startX + shape.endX) / 2, y: (shape.startY + shape.endY) / 2}
    ];
    points.forEach(p => {
      zones.add(getZoneNumber(p.x, p.y, canvasWidth, canvasHeight));
    });
    return Array.from(zones).sort((a, b) => a - b);
  }

  // Zone Analysis Functions (same as in popup.js)
  function analyzeZonePatterns(data) {
    const zoneData = {
      byTeam: new Map(),
      overall: {
        zones: new Map(),
        transitions: []
      }
    };

    const initZoneStats = () => ({
      totalEvents: 0,
      attackingEvents: 0,
      defensiveEvents: 0,
      errors: 0,
      goals: 0,
      shots: 0,
      dangerousAttacks: 0,
      recoveries: 0,
      pressingActions: 0,
      events: [],
      coverageScore: 0,
      productivityScore: 0
    });

    const isAttackingEvent = (event) => {
      const attackingKeywords = ['attack', 'shot', 'goal', 'assist', 'cross', 'cutback', 'through ball', 'final third', 'penalty box', 'progressive pass', 'carry', 'dribble'];
      return attackingKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isDefensiveEvent = (event) => {
      const defensiveKeywords = ['defense', 'defensive', 'pressing', 'recovery', 'tackle', 'interception', 'block', 'clearance', 'transition defense'];
      return defensiveKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isErrorEvent = (event) => {
      const errorKeywords = ['error', 'poor', 'bad decision', 'miscommunication', 'failed'];
      return errorKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    // Process notes
    if (data.notes && Array.isArray(data.notes)) {
      data.notes.forEach(note => {
        const teams = [];
        if (note.team) teams.push(note.team);
        if (note.teams && Array.isArray(note.teams)) teams.push(...note.teams);
        if (teams.length === 0) teams.push('Unknown');

        teams.forEach(team => {
          if (!zoneData.byTeam.has(team)) {
            zoneData.byTeam.set(team, {
              zones: new Map(),
              transitions: []
            });
          }
          const teamData = zoneData.byTeam.get(team);

          if (note.zones && Array.isArray(note.zones)) {
            note.zones.forEach(zoneStr => {
              const zoneMatch = zoneStr.toString().match(/(\d+)/);
              if (zoneMatch) {
                const zoneNum = parseInt(zoneMatch[1]);
                if (zoneNum >= 1 && zoneNum <= 18) {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  zoneStats.events.push({
                    type: 'note',
                    event: note.events ? note.events.join(', ') : 'General note',
                    text: note.text || note.content || ''
                  });

                  const eventText = (note.events || []).join(' ').toLowerCase() + ' ' + (note.text || note.content || '').toLowerCase();
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    if (eventText.includes('goal')) zoneStats.goals++;
                    if (eventText.includes('shot')) zoneStats.shots++;
                    if (eventText.includes('dangerous') || eventText.includes('chance')) zoneStats.dangerousAttacks++;
                    zoneStats.productivityScore += 2;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    if (eventText.includes('recovery')) zoneStats.recoveries++;
                    if (eventText.includes('pressing')) zoneStats.pressingActions++;
                    zoneStats.coverageScore += 2;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                }
              }
            });
          }

          if (note.events && Array.isArray(note.events) && note.zones && note.zones.length >= 2) {
            const zones = note.zones.map(z => {
              const match = z.toString().match(/(\d+)/);
              return match ? parseInt(match[1]) : null;
            }).filter(z => z !== null && z >= 1 && z <= 18);
            
            if (zones.length >= 2) {
              for (let i = 0; i < zones.length - 1; i++) {
                teamData.transitions.push({
                  from: zones[i],
                  to: zones[i + 1],
                  event: note.events.join(', '),
                  type: 'note'
                });
              }
            }
          }
        });
      });
    }

    // Process tactical schemes
    if (data.tacticalSchemes && Array.isArray(data.tacticalSchemes)) {
      data.tacticalSchemes.forEach(scheme => {
        if (scheme.slidesData && Array.isArray(scheme.slidesData)) {
          scheme.slidesData.forEach(slide => {
            if (slide.drawings && Array.isArray(slide.drawings)) {
              const canvasWidth = 1000;
              const canvasHeight = 600;

              const zones = slide.drawings.filter(d => ['circle', 'oval', 'rectangle', 'triangle'].includes(d.type));
              zones.forEach(zone => {
                const zoneNums = getZonesForShape(zone, canvasWidth, canvasHeight);
                const team = zone.team || 'Unknown';
                
                if (!zoneData.byTeam.has(team)) {
                  zoneData.byTeam.set(team, {
                    zones: new Map(),
                    transitions: []
                  });
                }
                const teamData = zoneData.byTeam.get(team);

                const convert9to18Zones = (zones9) => {
                  return zones9.map(zone9 => {
                    if (zone9 < 1 || zone9 > 9) return null;
                    const row = Math.floor((zone9 - 1) / 3);
                    const col = ((zone9 - 1) % 3);
                    return row * 6 + col * 2 + 1;
                  }).filter(z => z !== null);
                };
                const zoneNums18 = convert9to18Zones(zoneNums);
                
                zoneNums18.forEach(zoneNum => {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  
                  const eventName = zone.eventName || '';
                  const eventText = eventName.toLowerCase();
                  
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    zoneStats.productivityScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    zoneStats.coverageScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                  
                  zoneStats.events.push({
                    type: 'scheme',
                    event: eventName,
                    filled: zone.fillOpacity > 0
                  });
                });
              });

              const movements = slide.drawings.filter(d => ['arrow', 'line', 'curve', 'animpath'].includes(d.type));
              movements.forEach(movement => {
                const startZone9 = getZoneNumber(movement.startX, movement.startY, canvasWidth, canvasHeight);
                const endZone9 = getZoneNumber(movement.endX, movement.endY, canvasWidth, canvasHeight);
                const convert9to18 = (zone9) => {
                  if (zone9 < 1 || zone9 > 9) return null;
                  const row = Math.floor((zone9 - 1) / 3);
                  const col = ((zone9 - 1) % 3);
                  return row * 6 + col * 2 + 1;
                };
                const startZone = convert9to18(startZone9);
                const endZone = convert9to18(endZone9);
                const team = movement.team || 'Unknown';
                
                if (startZone && endZone && startZone !== endZone && startZone >= 1 && startZone <= 18 && endZone >= 1 && endZone <= 18) {
                  if (!zoneData.byTeam.has(team)) {
                    zoneData.byTeam.set(team, {
                      zones: new Map(),
                      transitions: []
                    });
                  }
                  const teamData = zoneData.byTeam.get(team);
                  
                  teamData.transitions.push({
                    from: startZone,
                    to: endZone,
                    event: movement.eventName || 'Movement',
                    type: 'scheme'
                  });
                }
              });
            }
          });
        }
      });
    }

    zoneData.byTeam.forEach((teamData, team) => {
      teamData.zones.forEach((stats, zoneNum) => {
        if (!zoneData.overall.zones.has(zoneNum)) {
          zoneData.overall.zones.set(zoneNum, initZoneStats());
        }
        const overallStats = zoneData.overall.zones.get(zoneNum);
        overallStats.totalEvents += stats.totalEvents;
        overallStats.attackingEvents += stats.attackingEvents;
        overallStats.defensiveEvents += stats.defensiveEvents;
        overallStats.errors += stats.errors;
        overallStats.goals += stats.goals;
        overallStats.shots += stats.shots;
        overallStats.dangerousAttacks += stats.dangerousAttacks;
        overallStats.recoveries += stats.recoveries;
        overallStats.pressingActions += stats.pressingActions;
        overallStats.coverageScore += stats.coverageScore;
        overallStats.productivityScore += stats.productivityScore;
      });
      zoneData.overall.transitions.push(...teamData.transitions);
    });

    return zoneData;
  }

  function calculateZoneStatistics(zoneData) {
    const stats = {
      byTeam: new Map(),
      overall: {
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      }
    };

    zoneData.byTeam.forEach((teamData, team) => {
      const teamStats = {
        zones: [],
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      };

      const zoneArray = Array.from(teamData.zones.entries()).map(([zoneNum, zoneStats]) => ({
        zone: zoneNum,
        ...zoneStats
      }));

      teamStats.zones = zoneArray;
      teamStats.mostActiveZones = [...zoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
      teamStats.mostProductiveZones = [...zoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
      teamStats.mostCoveredZones = [...zoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
      teamStats.mostVulnerableZones = [...zoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
        .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

      const transitionMap = new Map();
      teamData.transitions.forEach(trans => {
        const key = `${trans.from}->${trans.to}`;
        if (!transitionMap.has(key)) {
          transitionMap.set(key, { from: trans.from, to: trans.to, count: 0, events: [] });
        }
        transitionMap.get(key).count++;
        transitionMap.get(key).events.push(trans.event);
      });
      teamStats.transitionPatterns = Array.from(transitionMap.values())
        .sort((a, b) => b.count - a.count).slice(0, 5);

      stats.byTeam.set(team, teamStats);
    });

    const overallZoneArray = Array.from(zoneData.overall.zones.entries()).map(([zoneNum, zoneStats]) => ({
      zone: zoneNum,
      ...zoneStats
    }));

    stats.overall.mostActiveZones = [...overallZoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
    stats.overall.mostProductiveZones = [...overallZoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
    stats.overall.mostCoveredZones = [...overallZoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
    stats.overall.mostVulnerableZones = [...overallZoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
      .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

    const overallTransitionMap = new Map();
    zoneData.overall.transitions.forEach(trans => {
      const key = `${trans.from}->${trans.to}`;
      if (!overallTransitionMap.has(key)) {
        overallTransitionMap.set(key, { from: trans.from, to: trans.to, count: 0 });
      }
      overallTransitionMap.get(key).count++;
    });
    stats.overall.transitionPatterns = Array.from(overallTransitionMap.values())
      .sort((a, b) => b.count - a.count).slice(0, 5);

    return stats;
  }

  function identifyGamePlan(zoneStats, events) {
    const gamePlan = {
      primaryAttackZones: [],
      primaryDefenseZones: [],
      buildUpPattern: '',
      finishingPattern: '',
      transitionStyle: ''
    };

    gamePlan.primaryAttackZones = zoneStats.mostProductiveZones
      .filter(z => z.attackingEvents > 0)
      .map(z => z.zone);

    gamePlan.primaryDefenseZones = zoneStats.mostCoveredZones
      .filter(z => z.defensiveEvents > 0)
      .map(z => z.zone);

    const defensiveZones = zoneStats.zones.filter(z => z.zone >= 1 && z.zone <= 6 && z.totalEvents > 0);
    const midfieldZones = zoneStats.zones.filter(z => z.zone >= 7 && z.zone <= 12 && z.totalEvents > 0);
    if (defensiveZones.length > 0 && midfieldZones.length > 0) {
      gamePlan.buildUpPattern = `Builds from defensive zones (${defensiveZones.map(z => z.zone).join(', ')}) through midfield (${midfieldZones.map(z => z.zone).join(', ')})`;
    }

    const attackingZones = zoneStats.zones.filter(z => z.zone >= 13 && z.zone <= 18 && z.attackingEvents > 0);
    if (attackingZones.length > 0) {
      gamePlan.finishingPattern = `Finishes in attacking zones: ${attackingZones.map(z => z.zone).join(', ')}`;
    }

    const forwardTransitions = zoneStats.transitionPatterns.filter(t => t.from < t.to);
    const backwardTransitions = zoneStats.transitionPatterns.filter(t => t.from > t.to);
    if (forwardTransitions.length > backwardTransitions.length) {
      gamePlan.transitionStyle = 'Forward-pressing, counter-attacking style';
    } else if (backwardTransitions.length > forwardTransitions.length) {
      gamePlan.transitionStyle = 'Possession-based, build-up style';
    } else {
      gamePlan.transitionStyle = 'Balanced transition style';
    }

    return gamePlan;
  }

  function compareTeams(team1Data, team2Data) {
    const comparisons = {
      attackComparison: [],
      defenseComparison: [],
      tacticalMatchups: [],
      exploitationOpportunities: []
    };

    const team1AttackZones = team1Data.mostProductiveZones.map(z => z.zone);
    const team2DefenseZones = team2Data.mostCoveredZones.map(z => z.zone);
    const team2VulnerableZones = team2Data.mostVulnerableZones.map(z => z.zone);

    team1AttackZones.forEach(zone => {
      if (team2VulnerableZones.includes(zone)) {
        comparisons.exploitationOpportunities.push({
          type: 'attack',
          team1Zone: zone,
          team2Vulnerability: zone,
          description: `Team 1's strength in zone ${zone} matches Team 2's vulnerability`
        });
      }
    });

    const team1DefenseZones = team1Data.mostCoveredZones.map(z => z.zone);
    const team2AttackZones = team2Data.mostProductiveZones.map(z => z.zone);

    team2AttackZones.forEach(zone => {
      if (team1DefenseZones.includes(zone)) {
        comparisons.tacticalMatchups.push({
          type: 'defense',
          zone: zone,
          description: `Team 1's defensive strength in zone ${zone} will face Team 2's attacking strength`
        });
      }
    });

    return comparisons;
  }

  // Helper function to describe a drawing in tactical terms (simplified version)
  function describeDrawing(drawing, index, canvasWidth = 1000, canvasHeight = 600, allDrawings = []) {
    if (!drawing || !drawing.type) return null;
    
    const getZoneInfo = (x, y) => {
      const zoneNum = getZoneNumber(x, y, canvasWidth, canvasHeight);
      const zoneNames = {
        1: 'Zone 1 (left defensive)', 2: 'Zone 2 (center defensive)', 3: 'Zone 3 (right defensive)',
        4: 'Zone 4 (left midfield)', 5: 'Zone 5 (center midfield)', 6: 'Zone 6 (right midfield)',
        7: 'Zone 7 (left attacking)', 8: 'Zone 8 (center attacking)', 9: 'Zone 9 (right attacking)'
      };
      return zoneNames[zoneNum] || `Zone ${zoneNum}`;
    };

    const type = drawing.type;
    if (['circle', 'oval', 'rectangle', 'triangle'].includes(type)) {
      const centerX = (drawing.startX + drawing.endX) / 2;
      const centerY = (drawing.startY + drawing.endY) / 2;
      const zones = getZonesForShape(drawing, canvasWidth, canvasHeight);
      let desc = `${type} ZONE at ${getZoneInfo(centerX, centerY)}`;
      if (drawing.fillOpacity > 0) desc += ` (filled)`;
      if (drawing.eventName) desc += ` - Event: ${drawing.eventName}`;
      return desc;
    } else if (['arrow', 'line', 'curve'].includes(type)) {
      const startZone = getZoneInfo(drawing.startX, drawing.startY);
      const endZone = getZoneInfo(drawing.endX, drawing.endY);
      let desc = `${type} from ${startZone} to ${endZone}`;
      if (drawing.eventName) desc += ` - Event: ${drawing.eventName}`;
      return desc;
    }
    return `${type} drawing`;
  }

  // formatDataForAI is now in ai-analysis-utils.js - use window.aiAnalysisUtils.formatDataForAI
  // Removed local implementation to use unified version

  // OpenAI API Integration
  async function callOpenAIAnalysis(prompt, apiKey) {
    const model = 'gpt-4o-mini';
    
    try {
      const proxyFetch = window.aiAnalysisUtils?.proxyFetch || fetch;
      const response = await proxyFetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model,
          messages: [
            {
              role: 'system',
              content: window.aiAnalysisUtils.getSystemPrompt()
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          throw new Error('Invalid API key. Please check your OpenAI API key.');
        } else if (response.status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        } else if (response.status === 500 || response.status === 503) {
          throw new Error('OpenAI service is temporarily unavailable. Please try again later.');
        } else {
          throw new Error(errorData.error?.message || `API error: ${response.status}`);
        }
      }

      const data = await response.json();
      if (data.choices && data.choices.length > 0 && data.choices[0].message) {
        return data.choices[0].message.content;
      } else {
        throw new Error('Unexpected response format from OpenAI API');
      }
    } catch (error) {
      if (error.message) {
        throw error;
      } else if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your internet connection.');
      } else {
        throw new Error('An unexpected error occurred while calling OpenAI API.');
      }
    }
  }

  // Store current analysis data for citation previews
  let currentAnalysisDataForPreview = null;
  let originalAIAnalysisText = null; // Store original text for saving

  // Escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Format note for inline display
  function formatNoteInline(note) {
    if (!note) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Note not found</div>';
    }

    const timecode = note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null;
    const timecodeStr = timecode ? timecode[0] : (note.videoTime ? `[${Math.floor(note.videoTime / 60)}:${String(Math.floor(note.videoTime % 60)).padStart(2, '0')}]` : '');
    
    // If both exist and are the same, use only one to avoid duplication
    let noteText = '';
    if (note.text && note.content) {
      // Both exist - use text if they're different, otherwise use text (avoid duplication)
      noteText = note.text.trim();
      // If content is different and longer, it might be the updated version
      if (note.content.trim() !== note.text.trim() && note.content.trim().length > note.text.trim().length) {
        noteText = note.content.trim();
      }
    } else {
      noteText = (note.text || note.content || '').trim();
    }
    
    // Check for duplicate text within the message itself
    if (noteText.length > 0) {
      const messageLength = noteText.length;
      const halfLength = Math.floor(messageLength / 2);
      const firstHalf = noteText.substring(0, halfLength);
      const secondHalf = noteText.substring(halfLength);
      // Check if message is exactly duplicated (first half == second half)
      if (firstHalf === secondHalf && messageLength % 2 === 0) {
        console.warn('Detected duplicated message text in formatNoteInline, using only first half');
        noteText = firstHalf;
      }
    }
    
    const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Note ${timecodeStr}</div>`;
    
    if (cleanText && cleanText.trim().length > 0) {
      html += `<div style="color: #c9d1d9; margin-bottom: 12px; white-space: pre-wrap; line-height: 1.6; font-size: 13px;">${escapeHtml(cleanText)}</div>`;
    } else {
      html += `<div style="color: #8b949e; font-style: italic; margin-bottom: 12px;">(No text content)</div>`;
    }
    
    const metadata = [];
    if (note.team || (note.teams && note.teams.length > 0)) {
      metadata.push(`Team: ${note.team || note.teams.join(', ')}`);
    }
    if (note.players && note.players.length > 0) {
      const playerNames = note.players.map(p => typeof p === 'string' ? p : (p.name || p.id)).join(', ');
      metadata.push(`Players: ${playerNames}`);
    }
    if (note.events && note.events.length > 0) {
      metadata.push(`Events: ${note.events.join(' • ')}`);
    }
    if (note.zones && note.zones.length > 0) {
      metadata.push(`Zones: ${note.zones.join(', ')}`);
    }
    if (note.intensity !== null && note.intensity !== undefined) {
      const intensityLabels = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
      metadata.push(`Intensity: ${intensityLabels[note.intensity] || note.intensity}`);
    }
    
    if (metadata.length > 0) {
      html += `<div style="font-size: 12px; color: #8b949e; margin-top: 8px; padding-top: 8px; border-top: 1px solid #21262d;">${metadata.join(' • ')}</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Format marker for inline display
  function formatMarkerInline(marker) {
    if (!marker) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Marker not found</div>';
    }

    const minutes = Math.floor(marker.time / 60);
    const seconds = Math.floor(marker.time % 60);
    const timecodeStr = `[${minutes}:${String(seconds).padStart(2, '0')}]`;

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Timeline Marker ${timecodeStr}</div>`;
    
    const metadata = [];
    if (marker.team) {
      metadata.push(`Team: ${marker.team}`);
    }
    if (marker.eventType) {
      metadata.push(`Event: ${marker.eventType}`);
    }
    
    if (metadata.length > 0) {
      html += `<div style="color: #c9d1d9; margin-bottom: 8px; font-size: 13px;">${metadata.join(' • ')}</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Format image for inline display
  function formatImageInline(image) {
    if (!image) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Image not found</div>';
    }

    const timecode = image.timecode ? image.timecode[0] : (image.videoTime ? `[${Math.floor(image.videoTime / 60)}:${String(Math.floor(image.videoTime % 60)).padStart(2, '0')}]` : '');

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Image ${timecode}</div>`;
    
    if (image.imageData) {
      html += `<img src="${image.imageData}" style="max-width: 100%; border-radius: 6px; margin-top: 8px; border: 1px solid #21262d;" alt="Image">`;
    } else {
      html += `<div style="color: #8b949e; font-style: italic;">No image data available</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Parse citations and convert to clickable links
  function parseCitations(text, analysisData) {
    if (!text || !analysisData) {
      console.warn('parseCitations: Missing text or analysisData', { hasText: !!text, hasData: !!analysisData });
      return text;
    }

    console.log('parseCitations: Starting with', {
      textLength: text.length,
      notesCount: analysisData.notes ? analysisData.notes.length : 0,
      schemesCount: analysisData.tacticalSchemes ? analysisData.tacticalSchemes.length : 0,
      markersCount: analysisData.timelineMarkers ? analysisData.timelineMarkers.length : 0,
      imagesCount: analysisData.regularImages ? analysisData.regularImages.length : 0
    });

    const citationPattern = /\(([^)]+)\)/g;
    
    // Debug: Find all parentheses in text
    const allMatches = [...text.matchAll(citationPattern)];
    console.log('parseCitations: Found', allMatches.length, 'parentheses in text');
    if (allMatches.length > 0) {
      console.log('parseCitations: First few matches:', allMatches.slice(0, 5).map(m => m[1]));
    }
    
    const citationPatterns = {
      note: /(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Note)\s+(\d+)/i,
      scheme: /(?:Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Schema|Esquema)\s+(\d+)/i,
      marker: /(?:Timeline\s+Marker|Маркер|Marker|Marcador|Marqueur|Marcatore|Marcador)\s+(\d+)|(?:Marker|Маркер|Marker|Marcador|Marqueur|Marcatore|Marcador)\s+(\d+)/i,
      image: /(?:Image|Изображение|Slika|Bild|Obraz|Imagen|Image|Immagine|Imagem)\s+(\d+)/i
    };
    
    return text.replace(citationPattern, (match, citationText) => {
      // Check if this looks like a citation (contains Note, Scheme, Marker, Image or their translations)
      if (!/(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Marker|Маркер|Marcador|Marqueur|Marcatore|Image|Изображение|Slika|Bild|Obraz|Imagen|Immagine|Imagem)/i.test(citationText)) {
        return match; // Not a citation, return as-is
      }
      
      console.log('parseCitations: Found potential citation:', citationText);
      
      citationText = citationText.replace(/;/g, ',');
      let items = citationText.split(',').map(item => item.trim());
      const citationItems = [];

      const notesMatch = citationText.match(/(?:Notes?|Заметки?|Napomene?|Notizen?|Notatki?|Notas?)\s+(\d+(?:\s*,\s*\d+)*)/i);
      if (notesMatch) {
        const numbers = notesMatch[1].split(',').map(n => n.trim());
        items = numbers.map(n => {
          if (/Заметк/i.test(citationText)) return `Заметка ${n}`;
          if (/Napomen/i.test(citationText)) return `Napomena ${n}`;
          if (/Notiz/i.test(citationText)) return `Notiz ${n}`;
          if (/Notatk/i.test(citationText)) return `Notatka ${n}`;
          return `Note ${n}`;
        });
      }

      items.forEach(item => {
        const noteMatch = item.match(citationPatterns.note);
        const schemeMatch = item.match(citationPatterns.scheme);
        const markerMatch = item.match(citationPatterns.marker);
        const imageMatch = item.match(citationPatterns.image);

        if (noteMatch) {
          const noteIndex = parseInt(noteMatch[1]) - 1;
          if (analysisData.notes && analysisData.notes[noteIndex]) {
            citationItems.push({ type: 'note', index: noteIndex, number: noteMatch[1] });
          }
        } else if (schemeMatch) {
          const schemeIndex = parseInt(schemeMatch[1]) - 1;
          if (analysisData.tacticalSchemes && analysisData.tacticalSchemes[schemeIndex]) {
            citationItems.push({ type: 'scheme', index: schemeIndex, number: schemeMatch[1] });
          }
        } else if (markerMatch) {
          const markerIndex = parseInt(markerMatch[1] || markerMatch[2]) - 1;
          if (analysisData.timelineMarkers && analysisData.timelineMarkers[markerIndex]) {
            citationItems.push({ type: 'marker', index: markerIndex, number: markerMatch[1] || markerMatch[2] });
          }
        } else if (imageMatch) {
          const imageIndex = parseInt(imageMatch[1]) - 1;
          if (analysisData.regularImages && analysisData.regularImages[imageIndex]) {
            citationItems.push({ type: 'image', index: imageIndex, number: imageMatch[1] });
          }
        }
      });

      if (citationItems.length === 0) {
        console.log('parseCitations: No valid citations found for:', citationText);
        return match; // No valid citations found, return as-is
      }

      console.log('parseCitations: Created citation link with items:', citationItems);
      
      if (citationItems.length === 1) {
        const citationId = `citation-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const item = citationItems[0];
        const citationLabel = match.replace(/[()]/g, '');
        const blockId = `citation-block-${citationId}`;
        return `<span class="ai-citation-link" data-citation-id="${citationId}" data-block-id="${blockId}" data-items='${JSON.stringify(citationItems)}' style="color: #58a6ff; text-decoration: underline; cursor: pointer; border-bottom: 1px dotted #58a6ff; margin: 0 2px;">(${citationLabel})</span><div id="${blockId}" class="ai-citation-block collapsed" data-items='${JSON.stringify(citationItems)}'></div>`;
      } else {
        const baseId = Date.now();
        const links = citationItems.map((item, idx) => {
          const citationId = `${baseId}-${idx}-${Math.random().toString(36).substr(2, 9)}`;
          const blockId = `citation-block-${citationId}`;
          let itemText = '';
          const itemPattern = new RegExp(`(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Marker|Маркер|Marcador|Marqueur|Marcatore|Image|Изображение|Slika|Bild|Obraz|Imagen|Immagine|Imagem)\\s+${item.number}`, 'i');
          const itemMatch = citationText.match(itemPattern);
          if (itemMatch) {
            itemText = itemMatch[0];
          } else {
            const typeLabels = { note: 'Note', scheme: 'Scheme', marker: 'Marker', image: 'Image' };
            itemText = `${typeLabels[item.type] || 'Note'} ${item.number}`;
          }
          return {
            link: `<span class="ai-citation-link" data-citation-id="${citationId}" data-block-id="${blockId}" data-items='${JSON.stringify([item])}' style="color: #58a6ff; text-decoration: underline; cursor: pointer; border-bottom: 1px dotted #58a6ff; margin: 0 2px;">${itemText}</span>`,
            block: `<div id="${blockId}" class="ai-citation-block collapsed" data-items='${JSON.stringify([item])}'></div>`
          };
        });
        const linkTexts = links.map(l => l.link).join(', ');
        const blocks = links.map(l => l.block).join('');
        return `(${linkTexts})${blocks}`;
      }
    });
    
    console.log('parseCitations: Processed', citationCount, 'parentheses, found', (result.match(/ai-citation-link/g) || []).length, 'citation links');
    return result;
  }

  // Toggle citation block and populate content
  async function toggleCitationBlock(citationLink, blockElement, items) {
    if (!currentAnalysisDataForPreview) {
      console.warn('No analysis data available');
      return;
    }

    const isCollapsed = blockElement.classList.contains('collapsed');
    
    if (isCollapsed) {
      blockElement.classList.remove('collapsed');
      
      if (!blockElement.dataset.populated) {
        let contentHTML = '';
        
        for (let idx = 0; idx < items.length; idx++) {
          const item = items[idx];
          
          if (idx > 0) {
            contentHTML += '<hr style="border: none; border-top: 1px solid #21262d; margin: 16px 0;">';
          }

          if (item.type === 'note') {
            const note = currentAnalysisDataForPreview.notes && currentAnalysisDataForPreview.notes[item.index];
            if (note) {
              contentHTML += formatNoteInline(note);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Note ${item.number} - Not Found</div>`;
            }
          } else if (item.type === 'marker') {
            const marker = currentAnalysisDataForPreview.timelineMarkers && currentAnalysisDataForPreview.timelineMarkers[item.index];
            if (marker) {
              contentHTML += formatMarkerInline(marker);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Marker ${item.number} - Not Found</div>`;
            }
          } else if (item.type === 'image') {
            const image = currentAnalysisDataForPreview.regularImages && currentAnalysisDataForPreview.regularImages[item.index];
            if (image) {
              contentHTML += formatImageInline(image);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Image ${item.number} - Not Found</div>`;
            }
          }
        }
        
        blockElement.innerHTML = contentHTML;
        blockElement.dataset.populated = 'true';
      }
    } else {
      blockElement.classList.add('collapsed');
    }
  }

  // Show AI Analysis Results
  function showAIAnalysisResults(results, error = null) {
    // Create or show modal
    let modal = document.getElementById('distatsAIAnalysisModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'distatsAIAnalysisModal';
      modal.className = 'ai-analysis-modal';
      // Use same structure and classes as popup for consistency
      modal.className = 'project-modal hidden';
      modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 10000; display: none; align-items: center; justify-content: center;';
      modal.innerHTML = `
        <div class="project-modal-content" style="max-width: 800px; max-height: 90vh;">
          <div class="project-modal-header">
            <h3>AI Analysis</h3>
            <button id="distatsCloseAIModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body" style="max-height: calc(90vh - 180px); overflow-y: auto;">
            <div id="distatsAIAnalysisLoading" style="display: none; text-align: center; padding: 40px;">
              <div class="loading-spinner" style="margin: 0 auto 16px; width: 32px; height: 32px; border-width: 3px;"></div>
              <p style="color: #8b949e;">Analyzing your data...</p>
            </div>
            <div id="distatsAIAnalysisError" style="display: none; color: #da3633; padding: 20px; text-align: center;">
              <p id="distatsAIAnalysisErrorMessage"></p>
              <button id="distatsRetryAIAnalysisBtn" class="create-new-project-btn" style="margin-top: 16px;">Retry</button>
            </div>
            <div id="distatsAIAnalysisContent" style="display: none;">
              <div id="distatsAIAnalysisResults" style="color: #c9d1d9; line-height: 1.6; white-space: pre-wrap; font-size: 14px;"></div>
            </div>
          </div>
          <div class="project-modal-footer" style="padding: 16px; border-top: 1px solid #21262d; display: flex; gap: 8px; justify-content: flex-end;">
            <button id="distatsSaveAiAnalysisBtn" class="ai-save-note-btn" style="display: none;">Save as Note</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      
      // Prevent clicks on modal content from closing the modal
      const modalContent = modal.querySelector('.project-modal-content');
      if (modalContent) {
        modalContent.addEventListener('click', (e) => {
          e.stopPropagation();
        });
      }
      
      // Add CSS for citation blocks
      if (!document.getElementById('distatsAICitationStyles')) {
        const style = document.createElement('style');
        style.id = 'distatsAICitationStyles';
        style.textContent = `
          .ai-citation-link {
            color: #58a6ff !important;
            text-decoration: underline !important;
            cursor: pointer !important;
            border-bottom: 1px dotted #58a6ff !important;
            transition: color 0.2s ease;
          }
          .ai-citation-link:hover {
            color: #79c0ff !important;
            border-bottom-color: #79c0ff !important;
          }
          .ai-citation-block {
            display: none;
            margin: 0;
            padding: 0;
            border: none;
            border-radius: 0;
            background: transparent;
            overflow: hidden;
            transition: opacity 0.2s ease;
            opacity: 0;
          }
          .ai-citation-block:not(.collapsed) {
            display: block;
            opacity: 1;
            padding: 16px;
            margin-top: 16px;
            margin-bottom: 16px;
            border: 1px solid #21262d;
            border-radius: 6px;
            background: #161b22;
            line-height: normal;
            max-height: 500px;
            overflow-y: auto;
          }
          .ai-citation-block.collapsed {
            display: none;
            opacity: 0;
            padding: 0;
            margin: 0;
            border: none;
            line-height: 0;
            height: 0;
          }
          .ai-citation-block hr {
            border: none;
            border-top: 1px solid #21262d;
            margin: 16px 0;
          }
        `;
        document.head.appendChild(style);
      }
    }
    
    // Always attach/update event handlers (even if modal already exists)
    // Use data attribute to track if handlers are already attached
    if (!modal.dataset.handlersAttached) {
      const closeBtn = document.getElementById('distatsCloseAIModal');
      if (closeBtn) {
        closeBtn.addEventListener('mouseenter', () => {
          closeBtn.style.color = '#f85149';
        });
        closeBtn.addEventListener('mouseleave', () => {
          closeBtn.style.color = '#c9d1d9';
        });
        closeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          modal.style.display = 'none';
          modal.classList.add('hidden');
        });
      }
      
      // Retry button handler
      const retryBtn = document.getElementById('distatsRetryAIAnalysisBtn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => {
          // Show the focus modal again so user can adjust their question if needed
          showAIAnalysisFocusModal();
        });
      }
      
      // Save button handler (same as popup)
      const saveBtn = document.getElementById('distatsSaveAiAnalysisBtn');
      if (saveBtn) {
        saveBtn.addEventListener('click', () => {
          const resultsDiv = document.getElementById('distatsAIAnalysisResults');
          if (!resultsDiv || !originalAIAnalysisText) {
            console.warn('No AI analysis results available');
            return;
          }

          // Get HTML from resultsDiv which already has clickable citation links
          let analysisHtml = resultsDiv.innerHTML;
          
          // Wrap content in a container div for proper styling
          analysisHtml = `<div style="color: #c9d1d9; line-height: 1.6; white-space: pre-wrap;">${analysisHtml}</div>`;
          
          // Add header with styling
          const headerHtml = '<div style="font-size: 12px; font-weight: 600; color: #58a6ff; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid #21262d;">AI Analysis</div>';
          
          const fullAnalysisText = headerHtml + analysisHtml;
          
          // Save as note using addNoteToAnalysis
          // The function will handle HTML content detection via [HTML_CONTENT] tags
          const messageToSave = `[HTML_CONTENT]${fullAnalysisText}[/HTML_CONTENT]`;
          
          // Use addNoteToAnalysis to save (it will detect HTML content from tags)
          addNoteToAnalysis(messageToSave, null).then(() => {
            // Close modal after save
            modal.style.display = 'none';
            modal.classList.add('hidden');
          }).catch((error) => {
            console.error('Error saving AI analysis:', error);
            alert('Error saving AI analysis: ' + error.message);
          });
        });
      }
      
      modal.dataset.handlersAttached = 'true';
    }

    const loadingDiv = document.getElementById('distatsAIAnalysisLoading');
    const errorDiv = document.getElementById('distatsAIAnalysisError');
    const errorMessageDiv = document.getElementById('distatsAIAnalysisErrorMessage');
    const contentDiv = document.getElementById('distatsAIAnalysisContent');
    const resultsDiv = document.getElementById('distatsAIAnalysisResults');

    if (error) {
      if (loadingDiv) loadingDiv.style.display = 'none';
      if (errorDiv) {
        errorDiv.style.display = 'block';
        if (errorMessageDiv) errorMessageDiv.textContent = error;
      }
      if (contentDiv) contentDiv.style.display = 'none';
    } else if (results) {
      // Store original text with markdown preserved for saving (same as popup)
      originalAIAnalysisText = results;
      
      if (loadingDiv) loadingDiv.style.display = 'none';
      if (errorDiv) errorDiv.style.display = 'none';
      if (contentDiv) {
        contentDiv.style.display = 'block';
        if (!resultsDiv) {
          console.error('resultsDiv not found');
          return;
        }
        
        // Strip markdown formatting (same as popup)
        let cleanedResults = results
          .replace(/\*\*(.*?)\*\*/g, '$1') // Remove **bold**
          .replace(/\*(.*?)\*/g, '$1') // Remove *italic* (but not in citations)
          .replace(/__(.*?)__/g, '$1') // Remove __underline__
          .replace(/_(.*?)_/g, '$1') // Remove _italic_
          .replace(/###\s*(.*?)$/gm, '$1') // Remove ### headers
          .replace(/##\s*(.*?)$/gm, '$1') // Remove ## headers
          .replace(/#\s*(.*?)$/gm, '$1'); // Remove # headers
        
        // Parse citations and convert to clickable links with inline blocks (same as popup)
        console.log('About to parse citations, cleanedResults length:', cleanedResults.length);
        console.log('Sample of cleanedResults:', cleanedResults.substring(0, 500));
        console.log('currentAnalysisDataForPreview:', currentAnalysisDataForPreview);
        const parsedResults = parseCitations(cleanedResults, currentAnalysisDataForPreview);
        console.log('After parseCitations, parsedResults length:', parsedResults.length);
        console.log('Sample of parsedResults:', parsedResults.substring(0, 500));
        console.log('Has citation links?', parsedResults.includes('ai-citation-link'));
        
        // Format headers - but preserve citation HTML that parseCitations already added
        // Split by lines but be careful not to break citation HTML that spans or contains newlines
        // First, let's format headers while preserving citation HTML
        let formattedResults = parsedResults;
        
        // Process line by line, but preserve HTML from citations
        const lines = formattedResults.split('\n');
        const processedLines = [];
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          const trimmed = line.trim();
          
          // Skip empty lines
          if (!trimmed) {
            processedLines.push('');
            continue;
          }
          
          // Check if line has HTML (from citations) - if so, preserve it
          const hasHTML = line.includes('<') && line.includes('>');
          
          if (hasHTML) {
            // Line has HTML (citations) - preserve as-is
            processedLines.push(line);
            continue;
          }
          
          // No HTML, check if it's a header
          const isMainHeader = /^(ТАКТИЧЕСКИЕ ИНСАЙТЫ|TACTICAL INSIGHTS|TAKTIČKI UVIDI|TAKTISCHE EINSICHTEN|WGLĄDY TAKTYCZNE|PERSPECTIVAS TÁCTICAS|APERÇUS TACTIQUES|SPUNTI TATTICI|PERSPECTIVAS TÁTICAS|Тактический анализ|TACTICAL ANALYSIS)/i.test(trimmed);
          const isFindingsHeader = /^(КЛЮЧЕВЫЕ НАХОДКИ|KEY FINDINGS|KLJUČNI NALAZI|WICHTIGE ERKENNTNISSE|KLUCZOWE USTALENIA|HALLAZGOS CLAVE|CONSTATATIONS CLÉS|RISULTATI CHIAVE|DESCOBERTAS CHAVE)/i.test(trimmed);
          const isSummaryHeader = /^(РЕЗЮМЕ|SUMMARY|REZIME|ZUSAMMENFASSUNG|PODSUMOWANIE|RESUMEN|RÉSUMÉ|RIEPILOGO|RESUMO|Общие выводы|CONCLUSIONS|GENERAL CONCLUSIONS)/i.test(trimmed);
          const isSuggestionsHeader = /^(ПРЕДЛОЖЕНИЯ|SUGGESTIONS|PREDLOZI|EMPFEHLUNGEN|SUGERENCJE|SUGERENCIAS|SUGGESTIONS|SUGGERIMENTI|SUGESTÕES|Рекомендации|RECOMMENDATIONS)/i.test(trimmed);
          
          if ((isMainHeader || isFindingsHeader || isSummaryHeader || isSuggestionsHeader) && trimmed.length < 200) {
            // Format as section header
            processedLines.push(`<div style="font-size: 12px; font-weight: 600; color: #58a6ff; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 24px; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid #21262d;">${escapeHtml(trimmed)}</div>`);
          } else if (/^(КОМАНДА|TEAM|TIM|MANNSCHAFT|DRUŻYNA|EQUIPO|ÉQUIPE|SQUADRA|TIME)\s+\d+:/i.test(trimmed) && trimmed.length < 150) {
            // Format team headers
            processedLines.push(`<div style="font-size: 13px; font-weight: 600; color: #58a6ff; margin-top: 20px; margin-bottom: 12px;">${escapeHtml(trimmed)}</div>`);
          } else if (/^\d+\.\s/.test(trimmed) && trimmed.length < 200) {
            // Format numbered items
            processedLines.push(`<div style="font-size: 13px; font-weight: 600; color: #c9d1d9; margin-top: 16px; margin-bottom: 8px;">${escapeHtml(trimmed)}</div>`);
          } else {
            // Regular text line - escape HTML for safety
            processedLines.push(escapeHtml(trimmed));
          }
        }
        
        // Set innerHTML directly (same as popup) - white-space: pre-wrap will handle line breaks
        resultsDiv.innerHTML = processedLines.join('\n');
        
        // Add click handlers to citation links
        resultsDiv.querySelectorAll('.ai-citation-link').forEach(link => {
          link.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            const blockId = link.dataset.blockId;
            let items = JSON.parse(link.dataset.items);
            const blockElement = document.getElementById(blockId);
            
            if (blockElement) {
              if (blockElement.dataset.items) {
                items = JSON.parse(blockElement.dataset.items);
              }
              await toggleCitationBlock(link, blockElement, items);
            }
          });
        });
        
        // Show Save button (same as popup)
        const saveBtn = document.getElementById('distatsSaveAiAnalysisBtn');
        if (saveBtn) {
          saveBtn.style.display = 'block';
        }
        
        // Show footer
        const footer = modal.querySelector('.project-modal-footer');
        if (footer) {
          footer.style.display = 'flex';
        }
      }
    } else {
      // Hide footer when there's an error
      const footer = modal.querySelector('.project-modal-footer');
      if (footer) {
        footer.style.display = 'none';
      }
    }

    modal.style.display = 'flex';
    modal.classList.remove('hidden');
  }

  // Trigger AI Analysis
  // ========== AI ENHANCEMENT FUNCTIONS ==========
  
  function openDistatsAiEnhancementModal() {
    const modal = document.getElementById('distatsAiEnhancementModal');
    if (!modal) {
      console.error('distatsAiEnhancementModal not found');
      return;
    }
    
    // Reset modal state
    const progressDiv = document.getElementById('distatsEnhancementProgress');
    const resultsDiv = document.getElementById('distatsEnhancementResults');
    const errorDiv = document.getElementById('distatsEnhancementError');
    const startBtn = document.getElementById('distatsStartAiEnhancementBtn');
    const okBtn = document.getElementById('distatsOkAiEnhancementBtn');
    const footer = modal.querySelector('.project-modal-footer');
    const scopeSelect = document.getElementById('distatsEnhancementScopeSelect');
    
    if (progressDiv) progressDiv.style.display = 'none';
    if (resultsDiv) resultsDiv.style.display = 'none';
    if (errorDiv) {
      errorDiv.style.display = 'none';
      errorDiv.textContent = '';
    }
    if (startBtn) {
      startBtn.disabled = false;
      startBtn.style.display = 'block';
    }
    if (okBtn) {
      okBtn.style.display = 'none';
    }
    if (footer) footer.style.display = 'flex';
    if (scopeSelect) {
      scopeSelect.value = 'all';
    }
    
    modal.classList.remove('hidden');
  }

  function closeDistatsAiEnhancementModal() {
    const modal = document.getElementById('distatsAiEnhancementModal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  // Helper function to resolve an extracted team name to an existing team in the library
  // Returns the canonical team name if found, or null if no match
  function resolveDistatsToExistingTeam(teamName, teams) {
    if (!teamName || typeof teamName !== 'string') return null;
    const trimmedName = teamName.trim();
    if (trimmedName.length === 0) return null;
    
    const teamNameLower = trimmedName.toLowerCase();
    
    // First try exact match (case-insensitive)
    let exactMatch = teams.find(t => {
      const existingName = typeof t === 'string' ? t : (t.name || '');
      return existingName.toLowerCase() === teamNameLower;
    });
    
    if (exactMatch) {
      return typeof exactMatch === 'string' ? exactMatch : (exactMatch.name || null);
    }
    
    // Try fuzzy match: existing team name contains extracted name or vice versa
    let fuzzyMatches = teams.filter(t => {
      const existingName = typeof t === 'string' ? t : (t.name || '');
      const existingLower = existingName.toLowerCase();
      return existingLower.includes(teamNameLower) || teamNameLower.includes(existingLower);
    });
    
    if (fuzzyMatches.length > 0) {
      // Prefer the shortest match (more specific) or first match
      fuzzyMatches.sort((a, b) => {
        const nameA = typeof a === 'string' ? a : (a.name || '');
        const nameB = typeof b === 'string' ? b : (b.name || '');
        return nameA.length - nameB.length;
      });
      const bestMatch = fuzzyMatches[0];
      return typeof bestMatch === 'string' ? bestMatch : (bestMatch.name || null);
    }
    
    return null;
  }

  // Helper function to resolve an extracted player name to an existing player in the library
  // Returns the player object if found, or null if no match
  function resolveDistatsToExistingPlayer(playerName, players) {
    if (!playerName || typeof playerName !== 'string') return null;
    const trimmedName = playerName.trim();
    if (trimmedName.length === 0) return null;
    
    // Skip if it looks like message text (too long, contains sentence-ending punctuation)
    if (trimmedName.length > 100 || trimmedName.includes('!') || trimmedName.includes('?') || trimmedName.includes('.')) {
      return null;
    }
    
    const playerNameLower = trimmedName.toLowerCase();
    
    // Try to match by fullName, name, surname, or partial match
    const matched = players.find(p => {
      const fullName = (p.fullName || '').toLowerCase();
      const name = (p.name || '').toLowerCase();
      const surname = (p.surname || '').toLowerCase();
      return fullName === playerNameLower || 
             name === playerNameLower || 
             surname === playerNameLower ||
             fullName.includes(playerNameLower) ||
             playerNameLower.includes(fullName);
    });
    
    return matched || null;
  }

  // Helper function to create a team from unresolved list (always creates, doesn't check existence)
  async function createDistatsTeamFromUnresolved(teamName) {
    return new Promise((resolve) => {
      if (!teamName || typeof teamName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = teamName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['teams'], (result) => {
        const teams = result.teams || [];
        
        // Create new team
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: trimmedName,
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        chrome.storage.local.set({ teams: teams }, () => {
          console.log('Created team from unresolved:', trimmedName);
          resolve(newTeam);
        });
      });
    });
  }

  // Helper function to create a player from unresolved list (always creates, doesn't check existence)
  async function createDistatsPlayerFromUnresolved(playerName) {
    return new Promise((resolve) => {
      if (!playerName || typeof playerName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Create new player
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: '',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          console.log('Created player from unresolved:', trimmedName);
          resolve(newPlayer);
        });
      });
    });
  }

  // Helper function to create a team and attach it to specified comments
  async function createDistatsTeamAndAttachToComments(teamName, commentRefs) {
    return new Promise((resolve) => {
      if (!teamName || typeof teamName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = teamName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['teams', 'analyses'], (result) => {
        const teams = result.teams || [];
        const analyses = result.analyses || [];
        
        // Create new team
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: trimmedName,
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        
        // Track which projects need this team attached
        const projectsToAttach = new Set();
        
        // Attach team to all referenced comments
        if (commentRefs && commentRefs.length > 0) {
          commentRefs.forEach(ref => {
            const analysisIndex = analyses.findIndex(a => a.id === ref.analysisId);
            if (analysisIndex !== -1) {
              const analysis = analyses[analysisIndex];
              projectsToAttach.add(analysisIndex);
              
              const noteIndex = analysis.notes.findIndex(n => n.timestamp === ref.timestamp);
              if (noteIndex !== -1) {
                const note = analysis.notes[noteIndex];
                // Add team to note.teams array
                if (!note.teams) {
                  note.teams = [];
                }
                if (!note.teams.includes(trimmedName)) {
                  note.teams.push(trimmedName);
                }
                // Update note.team for backward compatibility
                if (!note.team) {
                  note.team = trimmedName;
                }
              }
            }
          });
        }
        
        // Auto-attach team to all projects that reference it
        projectsToAttach.forEach(analysisIndex => {
          const analysis = analyses[analysisIndex];
          if (!analysis.attachedTeamIds) {
            analysis.attachedTeamIds = [];
          }
          if (!analysis.attachedTeamIds.includes(newTeam.id)) {
            analysis.attachedTeamIds.push(newTeam.id);
          }
        });
        
        chrome.storage.local.set({ teams: teams, analyses: analyses }, () => {
          console.log('Created team and attached to comments:', trimmedName, commentRefs);
          resolve(newTeam);
        });
      });
    });
  }

  // Helper function to create a player and attach it to specified comments
  async function createDistatsPlayerAndAttachToComments(playerName, commentRefs) {
    return new Promise((resolve) => {
      if (!playerName || typeof playerName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['players', 'analyses', 'teams'], (result) => {
        const players = result.players || [];
        const analyses = result.analyses || [];
        const teams = result.teams || [];
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Collect teams from all referenced comments to auto-assign team to player
        // Check both: teams already attached to comments AND teams extracted from the same comments
        const teamsFromComments = [];
        if (commentRefs && commentRefs.length > 0) {
          commentRefs.forEach(ref => {
            const analysisIndex = analyses.findIndex(a => a.id === ref.analysisId);
            if (analysisIndex !== -1) {
              const noteIndex = analyses[analysisIndex].notes.findIndex(n => n.timestamp === ref.timestamp);
              if (noteIndex !== -1) {
                const note = analyses[analysisIndex].notes[noteIndex];
                // First, check for teams already attached to the comment
                if (note.teams && Array.isArray(note.teams) && note.teams.length > 0) {
                  note.teams.forEach(team => {
                    if (team && typeof team === 'string' && team.trim()) {
                      teamsFromComments.push(team.trim());
                    }
                  });
                } else if (note.team && typeof note.team === 'string' && note.team.trim()) {
                  teamsFromComments.push(note.team.trim());
                }
                
                // Also check extracted teams from the same comment (resolve to existing teams)
                if (ref.extractedTeams && Array.isArray(ref.extractedTeams) && ref.extractedTeams.length > 0) {
                  ref.extractedTeams.forEach(teamName => {
                    if (teamName && typeof teamName === 'string' && teamName.trim()) {
                      // Try to resolve to existing team
                      const resolvedTeam = resolveDistatsToExistingTeam(teamName.trim(), teams);
                      if (resolvedTeam) {
                        teamsFromComments.push(resolvedTeam);
                      } else {
                        // If not resolved, still use the extracted name (might be created later)
                        teamsFromComments.push(teamName.trim());
                      }
                    }
                  });
                }
              }
            }
          });
        }
        
        // Determine the team to assign: use the most common team, or first if tie
        let assignedTeam = '';
        if (teamsFromComments.length > 0) {
          const teamCounts = {};
          teamsFromComments.forEach(team => {
            teamCounts[team] = (teamCounts[team] || 0) + 1;
          });
          const sortedTeams = Object.entries(teamCounts).sort((a, b) => b[1] - a[1]);
          assignedTeam = sortedTeams[0][0]; // Most common team
        }
        
        // Create new player
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: assignedTeam,
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        
        // Track which projects need this player and their team attached
        const projectsToAttach = new Set();
        
        // Attach player to all referenced comments
        if (commentRefs && commentRefs.length > 0) {
          commentRefs.forEach(ref => {
            const analysisIndex = analyses.findIndex(a => a.id === ref.analysisId);
            if (analysisIndex !== -1) {
              const analysis = analyses[analysisIndex];
              projectsToAttach.add(analysisIndex);
              
              const noteIndex = analysis.notes.findIndex(n => n.timestamp === ref.timestamp);
              if (noteIndex !== -1) {
                const note = analysis.notes[noteIndex];
                // Add player ID to note.players array
                if (!note.players) {
                  note.players = [];
                }
                if (!note.players.includes(newPlayer.id)) {
                  note.players.push(newPlayer.id);
                }
              }
            }
          });
        }
        
        // Auto-attach player's team to all projects that reference the player
        if (assignedTeam && assignedTeam.trim()) {
          projectsToAttach.forEach(analysisIndex => {
            const analysis = analyses[analysisIndex];
            if (!analysis.attachedTeamIds) {
              analysis.attachedTeamIds = [];
            }
            // Find team ID by name
            const teamObj = teams.find(t => {
              const tName = typeof t === 'string' ? t : (t.name || '');
              return tName === assignedTeam.trim();
            });
            if (teamObj) {
              const teamId = typeof teamObj === 'string' ? teamObj : (teamObj.id || teamObj.name || '');
              if (teamId && !analysis.attachedTeamIds.includes(teamId)) {
                analysis.attachedTeamIds.push(teamId);
              }
            }
          });
        }
        
        chrome.storage.local.set({ players: players, analyses: analyses }, () => {
          console.log('Created player and attached to comments:', trimmedName, commentRefs, assignedTeam ? `(team: ${assignedTeam})` : '');
          resolve(newPlayer);
        });
      });
    });
  }

    // Helper function to add a team to global storage if it doesn't exist
  async function ensureDistatsTeamExists(teamName) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['teams'], (result) => {
        const teams = result.teams || [];
        const teamNameLower = teamName.toLowerCase().trim();
        
        // Check if team already exists
        const exists = teams.some(t => {
          const existingName = typeof t === 'string' ? t : (t.name || '');
          return existingName.toLowerCase() === teamNameLower;
        });
        
        if (exists) {
          resolve();
          return;
        }
        
        // Add new team to global storage
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: teamName.trim(),
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        chrome.storage.local.set({ teams: teams }, () => {
          console.log('Auto-added team to global storage:', teamName);
          resolve();
        });
      });
    });
  }
  
  // Helper function to add a player to global storage if it doesn't exist
  async function ensureDistatsPlayerExists(playerName) {
    return new Promise((resolve) => {
      // Validate player name - skip if it looks like message text
      if (!playerName || typeof playerName !== 'string') {
        resolve();
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve();
        return;
      }
      // Skip if it looks like message text (too long, contains sentence-ending punctuation)
      if (trimmedName.length > 100 || trimmedName.includes('!') || trimmedName.includes('?') || trimmedName.includes('.')) {
        console.warn('Skipping invalid player name (looks like message text):', trimmedName);
        resolve();
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const playerNameLower = trimmedName.toLowerCase();
        
        // Check if player already exists (by full name or parts)
        const exists = players.some(p => {
          const fullName = (p.fullName || '').toLowerCase();
          const name = (p.name || '').toLowerCase();
          const surname = (p.surname || '').toLowerCase();
          return fullName === playerNameLower || 
                 name === playerNameLower || 
                 surname === playerNameLower ||
                 fullName.includes(playerNameLower) ||
                 playerNameLower.includes(fullName);
        });
        
        if (exists) {
          resolve();
          return;
        }
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Add new player to global storage
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: '',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          console.log('Auto-added player to global storage:', trimmedName);
          resolve();
        });
      });
    });
  }

async function updateDistatsCommentProperties(comment, extractedProperties, analysisId) {
    return new Promise(async (resolve, reject) => {
      chrome.storage.local.get(['analyses', 'teams', 'players'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const teams = result.teams || [];
        const players = result.players || [];
        const analysisIndex = analyses.findIndex(a => a.id === analysisId);
        
        if (analysisIndex === -1) {
          reject(new Error('Analysis not found'));
          return;
        }

        const analysis = analyses[analysisIndex];
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === comment.timestamp);
        
        if (noteIndex === -1) {
          reject(new Error('Comment not found'));
          return;
        }

        const note = analysis.notes[noteIndex];
        
        // Track unresolved items
        const unresolvedTeams = [];
        const unresolvedPlayers = [];
        
        // Process teams - resolve to existing teams only, do not create new ones
        const resolvedTeams = [];
        if (extractedProperties.teams && extractedProperties.teams.length > 0) {
          extractedProperties.teams.forEach(teamName => {
            const canonicalName = resolveDistatsToExistingTeam(teamName, teams);
            if (canonicalName) {
              // Only add if not already in resolved list
              if (!resolvedTeams.includes(canonicalName)) {
                resolvedTeams.push(canonicalName);
              }
            } else {
              // Team not found in library - add to unresolved
              const trimmedName = (teamName || '').trim();
              if (trimmedName && !unresolvedTeams.includes(trimmedName)) {
                unresolvedTeams.push(trimmedName);
              }
            }
          });
          
          // Only update note if we have resolved teams
          if (resolvedTeams.length > 0) {
            note.teams = resolvedTeams;
            note.team = resolvedTeams[0]; // Keep backward compatibility
            
            // Auto-attach resolved teams to the project
            if (!analysis.attachedTeamIds) {
              analysis.attachedTeamIds = [];
            }
            resolvedTeams.forEach(teamName => {
              // Find team ID by name
              const teamObj = teams.find(t => {
                const tName = typeof t === 'string' ? t : (t.name || '');
                return tName === teamName;
              });
              if (teamObj) {
                const teamId = typeof teamObj === 'string' ? teamObj : (teamObj.id || teamObj.name || '');
                if (teamId && !analysis.attachedTeamIds.includes(teamId)) {
                  analysis.attachedTeamIds.push(teamId);
                }
              }
            });
          }
        }
        
        // Process players - resolve to existing players only, do not create new ones
        const resolvedPlayerIds = [];
        const teamsFromPlayers = new Set(); // Track teams from resolved players
        if (extractedProperties.players && extractedProperties.players.length > 0) {
          extractedProperties.players.forEach(playerName => {
            const matchedPlayer = resolveDistatsToExistingPlayer(playerName, players);
            if (matchedPlayer) {
              // Only add if not already in resolved list
              if (!resolvedPlayerIds.includes(matchedPlayer.id)) {
                resolvedPlayerIds.push(matchedPlayer.id);
              }
              // Track player's team for auto-attachment
              if (matchedPlayer.team && matchedPlayer.team.trim()) {
                teamsFromPlayers.add(matchedPlayer.team.trim());
              }
            } else {
              // Player not found in library - add to unresolved
              const trimmedName = (playerName || '').trim();
              // Skip if it looks like message text
              if (trimmedName && trimmedName.length <= 100 && 
                  !trimmedName.includes('!') && !trimmedName.includes('?') && !trimmedName.includes('.') &&
                  !unresolvedPlayers.includes(trimmedName)) {
                unresolvedPlayers.push(trimmedName);
              }
            }
          });
          
          // Only update note if we have resolved players
          if (resolvedPlayerIds.length > 0) {
            note.players = resolvedPlayerIds;
            
            // Auto-attach teams from resolved players to the project
            if (!analysis.attachedTeamIds) {
              analysis.attachedTeamIds = [];
            }
            teamsFromPlayers.forEach(teamName => {
              // Find team ID by name
              const teamObj = teams.find(t => {
                const tName = typeof t === 'string' ? t : (t.name || '');
                return tName === teamName;
              });
              if (teamObj) {
                const teamId = typeof teamObj === 'string' ? teamObj : (teamObj.id || teamObj.name || '');
                if (teamId && !analysis.attachedTeamIds.includes(teamId)) {
                  analysis.attachedTeamIds.push(teamId);
                }
              }
            });
          }
        }
        
        // Update events
        if (extractedProperties.events && extractedProperties.events.length > 0) {
          note.events = extractedProperties.events;
        }
        
        // Update zones
        if (extractedProperties.zones && extractedProperties.zones.length > 0) {
          note.zones = extractedProperties.zones;
        }
        
        // Update intensity
        if (extractedProperties.intensity !== null && extractedProperties.intensity !== undefined) {
          note.intensity = extractedProperties.intensity;
        }
        
        // Save updated analysis
        chrome.storage.local.set({ analyses: analyses }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            // Resolve with unresolved items so caller can aggregate them
            resolve({ unresolvedTeams, unresolvedPlayers });
          }
        });
      });
    });
  }

  async function processDistatsCommentsEnhancement(comments, skipExisting, apiKey) {
    const progressDiv = document.getElementById('distatsEnhancementProgress');
    const progressText = document.getElementById('distatsEnhancementProgressText');
    const progressCount = document.getElementById('distatsEnhancementProgressCount');
    const progressBar = document.getElementById('distatsEnhancementProgressBar');
    const resultsDiv = document.getElementById('distatsEnhancementResults');
    const successCount = document.getElementById('distatsEnhancementSuccessCount');
    const errorCount = document.getElementById('distatsEnhancementErrorCount');
    const errorDetails = document.getElementById('distatsEnhancementErrorDetails');
    const startBtn = document.getElementById('distatsStartAiEnhancementBtn');
    
    let processed = 0;
    let succeeded = 0;
    let failed = 0;
    const errors = [];
    
    // Track unresolved items with their associated comments
    // Maps: itemName -> [{analysisId, timestamp}]
    const unresolvedTeamsMap = new Map();
    const unresolvedPlayersMap = new Map();
    
    // Filter comments
    const commentsToProcess = comments.filter(comment => {
      if (!comment.text && !comment.content) return false;
      if (skipExisting) {
        const hasProperties = (comment.teams && comment.teams.length > 0) ||
                             (comment.team) ||
                             (comment.players && comment.players.length > 0) ||
                             (comment.events && comment.events.length > 0) ||
                             (comment.zones && comment.zones.length > 0) ||
                             (comment.intensity !== null && comment.intensity !== undefined);
        return !hasProperties;
      }
      return true;
    });
    
    const total = commentsToProcess.length;
    
    if (total === 0) {
      if (resultsDiv) {
        resultsDiv.style.display = 'block';
        if (successCount) successCount.textContent = 'No comments to enhance.';
      }
      if (startBtn) {
        startBtn.disabled = false;
        startBtn.style.display = 'none';
      }
      return;
    }
    
    // Show progress
    if (progressDiv) progressDiv.style.display = 'block';
    if (startBtn) {
      startBtn.disabled = true;
      startBtn.style.display = 'none';
    }
    
    // Process each comment
    for (let i = 0; i < commentsToProcess.length; i++) {
      const comment = commentsToProcess[i];
      const commentText = (comment.text || comment.content || '').replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
      
      // Increment processed counter (for progress display)
      processed++;
      
      if (!commentText.trim()) {
        // Update progress even for empty comments
        if (progressCount) progressCount.textContent = `${processed} / ${total}`;
        if (progressBar) progressBar.style.width = `${(processed / total) * 100}%`;
        if (progressText) progressText.textContent = `Enhancing comment ${processed} of ${total}...`;
        continue;
      }
      
      try {
        // Update progress
        if (progressCount) progressCount.textContent = `${processed} / ${total}`;
        if (progressBar) progressBar.style.width = `${(processed / total) * 100}%`;
        if (progressText) progressText.textContent = `Enhancing comment ${processed} of ${total}...`;
        
        // Extract properties
        const extracted = await window.aiAnalysisUtils.extractCommentProperties(commentText, apiKey, 'auto');
        
        // Update comment and get unresolved items
        const result = await updateDistatsCommentProperties(comment, extracted, comment.analysisId || currentAnalysisId);
        
        // Aggregate unresolved items with comment references (include extracted teams for player-team linking)
        const commentRef = { 
          analysisId: comment.analysisId || currentAnalysisId, 
          timestamp: comment.timestamp,
          extractedTeams: extracted.teams || [] // Store extracted teams for this comment
        };
        if (result && result.unresolvedTeams) {
          result.unresolvedTeams.forEach(t => {
            if (!unresolvedTeamsMap.has(t)) {
              unresolvedTeamsMap.set(t, []);
            }
            unresolvedTeamsMap.get(t).push(commentRef);
          });
        }
        if (result && result.unresolvedPlayers) {
          result.unresolvedPlayers.forEach(p => {
            if (!unresolvedPlayersMap.has(p)) {
              unresolvedPlayersMap.set(p, []);
            }
            unresolvedPlayersMap.get(p).push(commentRef);
          });
        }
        
        succeeded++;
      } catch (error) {
        failed++;
        errors.push({
          comment: commentText.substring(0, 50) + (commentText.length > 50 ? '...' : ''),
          error: error.message
        });
        console.error('Error enhancing comment:', error);
      }
    }
    
    // Show results
    if (progressDiv) progressDiv.style.display = 'none';
    if (resultsDiv) {
      resultsDiv.style.display = 'block';
      if (successCount) {
        successCount.textContent = `Successfully enhanced ${succeeded} comment${succeeded !== 1 ? 's' : ''}.`;
      }
      if (failed > 0) {
        if (errorCount) {
          errorCount.style.display = 'block';
          errorCount.textContent = `Failed to enhance ${failed} comment${failed !== 1 ? 's' : ''}.`;
        }
        if (errorDetails) {
          errorDetails.innerHTML = errors.map(e => 
            `<div style="margin-bottom: 4px;"><strong>${e.comment}:</strong> ${e.error}</div>`
          ).join('');
        }
      }
      
      // Show unresolved teams and players with interactive create options
      const unresolvedSection = document.getElementById('distatsEnhancementUnresolvedSection');
      const unresolvedTeamsList = document.getElementById('distatsEnhancementUnresolvedTeamsList');
      const unresolvedTeamsItems = document.getElementById('distatsEnhancementUnresolvedTeamsItems');
      const unresolvedPlayersList = document.getElementById('distatsEnhancementUnresolvedPlayersList');
      const unresolvedPlayersItems = document.getElementById('distatsEnhancementUnresolvedPlayersItems');
      const createAllBtn = document.getElementById('distatsCreateAllUnresolvedBtn');
      const skipBtn = document.getElementById('distatsSkipUnresolvedBtn');
      
      const hasUnresolvedTeams = unresolvedTeamsMap.size > 0;
      const hasUnresolvedPlayers = unresolvedPlayersMap.size > 0;
      
      if (unresolvedSection && (hasUnresolvedTeams || hasUnresolvedPlayers)) {
        unresolvedSection.style.display = 'block';
        
        // Render unresolved teams
        if (unresolvedTeamsList && unresolvedTeamsItems) {
          if (hasUnresolvedTeams) {
            unresolvedTeamsList.style.display = 'block';
            unresolvedTeamsItems.innerHTML = '';
            const teamsArray = Array.from(unresolvedTeamsMap.keys());
            teamsArray.forEach((teamName, index) => {
              const commentRefs = unresolvedTeamsMap.get(teamName);
              const itemDiv = document.createElement('div');
              itemDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; padding: 4px 8px; background: #161b22; border-radius: 4px;';
              itemDiv.innerHTML = `
                <input type="checkbox" id="distatsUnresolvedTeam_${index}" data-team-name="${teamName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' checked style="cursor: pointer; width: 14px; height: 14px;">
                <label for="distatsUnresolvedTeam_${index}" style="flex: 1; font-size: 12px; color: #c9d1d9; cursor: pointer;">${teamName} <span style="color: #6e7681; font-size: 10px;">(${commentRefs.length} comment${commentRefs.length > 1 ? 's' : ''})</span></label>
                <button class="distats-create-single-team-btn" data-team-name="${teamName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' style="padding: 2px 8px; background: #238636; color: #fff; border: none; border-radius: 3px; font-size: 10px; cursor: pointer;">Create</button>
              `;
              unresolvedTeamsItems.appendChild(itemDiv);
            });
          } else {
            unresolvedTeamsList.style.display = 'none';
          }
        }
        
        // Render unresolved players
        if (unresolvedPlayersList && unresolvedPlayersItems) {
          if (hasUnresolvedPlayers) {
            unresolvedPlayersList.style.display = 'block';
            unresolvedPlayersItems.innerHTML = '';
            const playersArray = Array.from(unresolvedPlayersMap.keys());
            playersArray.forEach((playerName, index) => {
              const commentRefs = unresolvedPlayersMap.get(playerName);
              const itemDiv = document.createElement('div');
              itemDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; padding: 4px 8px; background: #161b22; border-radius: 4px;';
              itemDiv.innerHTML = `
                <input type="checkbox" id="distatsUnresolvedPlayer_${index}" data-player-name="${playerName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' checked style="cursor: pointer; width: 14px; height: 14px;">
                <label for="distatsUnresolvedPlayer_${index}" style="flex: 1; font-size: 12px; color: #c9d1d9; cursor: pointer;">${playerName} <span style="color: #6e7681; font-size: 10px;">(${commentRefs.length} comment${commentRefs.length > 1 ? 's' : ''})</span></label>
                <button class="distats-create-single-player-btn" data-player-name="${playerName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' style="padding: 2px 8px; background: #238636; color: #fff; border: none; border-radius: 3px; font-size: 10px; cursor: pointer;">Create</button>
              `;
              unresolvedPlayersItems.appendChild(itemDiv);
            });
          } else {
            unresolvedPlayersList.style.display = 'none';
          }
        }
        
        // Add event listeners for individual create buttons
        document.querySelectorAll('.distats-create-single-team-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const teamName = e.target.dataset.teamName;
            const commentRefs = JSON.parse(e.target.dataset.commentRefs || '[]');
            await createDistatsTeamAndAttachToComments(teamName, commentRefs);
            e.target.closest('div').remove();
            // Check if any teams left
            if (unresolvedTeamsItems.children.length === 0) {
              unresolvedTeamsList.style.display = 'none';
            }
            checkAndHideDistatsUnresolvedSection();
            updateNotesDisplay();
          });
        });
        
        document.querySelectorAll('.distats-create-single-player-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const playerName = e.target.dataset.playerName;
            const commentRefs = JSON.parse(e.target.dataset.commentRefs || '[]');
            await createDistatsPlayerAndAttachToComments(playerName, commentRefs);
            e.target.closest('div').remove();
            // Check if any players left
            if (unresolvedPlayersItems.children.length === 0) {
              unresolvedPlayersList.style.display = 'none';
            }
            checkAndHideDistatsUnresolvedSection();
            updateNotesDisplay();
          });
        });
        
        // Create All Selected button handler
        if (createAllBtn) {
          createAllBtn.onclick = async () => {
            createAllBtn.disabled = true;
            createAllBtn.textContent = 'Creating...';
            
            // Create selected teams
            const teamCheckboxes = document.querySelectorAll('#distatsEnhancementUnresolvedTeamsItems input[type="checkbox"]:checked');
            for (const checkbox of teamCheckboxes) {
              const teamName = checkbox.dataset.teamName;
              const commentRefs = JSON.parse(checkbox.dataset.commentRefs || '[]');
              await createDistatsTeamAndAttachToComments(teamName, commentRefs);
              checkbox.closest('div').remove();
            }
            
            // Create selected players
            const playerCheckboxes = document.querySelectorAll('#distatsEnhancementUnresolvedPlayersItems input[type="checkbox"]:checked');
            for (const checkbox of playerCheckboxes) {
              const playerName = checkbox.dataset.playerName;
              const commentRefs = JSON.parse(checkbox.dataset.commentRefs || '[]');
              await createDistatsPlayerAndAttachToComments(playerName, commentRefs);
              checkbox.closest('div').remove();
            }
            
            createAllBtn.disabled = false;
            createAllBtn.textContent = 'Create All Selected';
            
            // Check if any items left
            if (unresolvedTeamsItems.children.length === 0) {
              unresolvedTeamsList.style.display = 'none';
            }
            if (unresolvedPlayersItems.children.length === 0) {
              unresolvedPlayersList.style.display = 'none';
            }
            checkAndHideDistatsUnresolvedSection();
            updateNotesDisplay();
          };
        }
        
        // Skip button handler
        if (skipBtn) {
          skipBtn.onclick = () => {
            unresolvedSection.style.display = 'none';
          };
        }
        
        function checkAndHideDistatsUnresolvedSection() {
          const hasTeams = unresolvedTeamsList && unresolvedTeamsList.style.display !== 'none' && unresolvedTeamsItems.children.length > 0;
          const hasPlayers = unresolvedPlayersList && unresolvedPlayersList.style.display !== 'none' && unresolvedPlayersItems.children.length > 0;
          if (!hasTeams && !hasPlayers) {
            unresolvedSection.style.display = 'none';
          }
        }
      } else if (unresolvedSection) {
        unresolvedSection.style.display = 'none';
      }
    }
    
    // Hide start button and show OK button after completion
    if (startBtn) {
      startBtn.disabled = false;
      startBtn.style.display = 'none';
    }
    const okBtn = document.getElementById('distatsOkAiEnhancementBtn');
    if (okBtn) {
      okBtn.style.display = 'block';
    }
    
    // Refresh UI to show updated properties
    if (currentAnalysisId) {
      updateNotesDisplay();
    }
  }

  async function startDistatsAiEnhancement() {
    const scopeSelect = document.getElementById('distatsEnhancementScopeSelect');
    const skipExisting = document.getElementById('distatsEnhancementSkipExisting');
    const errorDiv = document.getElementById('distatsEnhancementError');
    
    if (!currentAnalysisId) {
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Please select a project first.';
      }
      return;
    }
    
    // Get API key
    let apiKey;
    try {
      apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
    } catch (error) {
      console.error('Error loading API key:', error);
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Error loading API key. Please check your AI Settings.';
      }
      return;
    }
    
    if (!apiKey) {
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Please configure your OpenAI API key in AI Settings first.';
      }
      return;
    }
    
    // Get comments to enhance
    chrome.storage.local.get(['analyses'], (result) => {
      if (chrome.runtime.lastError) {
        if (errorDiv) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = 'Error loading comments: ' + chrome.runtime.lastError.message;
        }
        return;
      }
      
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (!analysis || !analysis.notes) {
        if (errorDiv) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = 'No comments found in current project.';
        }
        return;
      }
      
      let comments = analysis.notes.map(note => ({
        ...note,
        analysisId: currentAnalysisId
      }));
      
      // Filter for marked comments if scope is "marked"
      const scope = scopeSelect ? scopeSelect.value : 'all';
      if (scope === 'marked') {
        // Get all marked comment timestamps
        const markedCheckboxes = document.querySelectorAll('.distats-message-mark-checkbox:checked');
        const markedTimestamps = Array.from(markedCheckboxes).map(cb => cb.dataset.noteTimestamp);
        
        if (markedTimestamps.length === 0) {
          if (errorDiv) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = 'Please mark at least one comment to enhance.';
          }
          return;
        }
        
        // Filter comments to only include marked ones
        comments = comments.filter(comment => markedTimestamps.includes(String(comment.timestamp)));
      }
      
      const skipExistingValue = skipExisting && skipExisting.checked;
      
      processDistatsCommentsEnhancement(comments, skipExistingValue, apiKey);
    });
  }


  // Show AI Analysis Focus Modal - asks the coach what they want to analyze
  function showAIAnalysisFocusModal() {
    // Create or show modal
    let modal = document.getElementById('distatsAIAnalysisFocusModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'distatsAIAnalysisFocusModal';
      modal.className = 'project-modal hidden';
      modal.innerHTML = `
        <div class="project-modal-content" style="max-width: 500px;">
          <div class="project-modal-header">
            <h3 data-i18n="ai.analysisFocusTitle">What would you like to analyze?</h3>
            <button id="distatsCloseAIFocusModal" class="close-modal-btn">&times;</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #8b949e; margin-bottom: 16px; font-size: 13px; line-height: 1.5;" data-i18n="ai.analysisFocusDescription">
              Describe what you want the AI to focus on. For example: "What are the defensive weaknesses of Team X?" or "How can we improve our attacking patterns in the final third?"
            </p>
            <textarea 
              id="distatsAIFocusInput" 
              class="url-input-modal" 
              placeholder="Enter your analysis question or focus area... (optional)"
              data-i18n-placeholder="ai.analysisFocusPlaceholder"
              style="width: 100%; min-height: 100px; padding: 12px; font-size: 14px; resize: vertical; line-height: 1.5; background: #0d1117; border: 1px solid #30363d; border-radius: 6px; color: #c9d1d9;"
            ></textarea>
            <p style="color: #6e7681; margin-top: 12px; font-size: 12px; line-height: 1.4;" data-i18n="ai.analysisFocusHint">
              Leave empty for a general comprehensive analysis of all aspects.
            </p>
            <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: 20px;">
              <button id="distatsSkipFocusBtn" class="modal-btn-secondary" data-i18n="ai.skipAndAnalyze">
                Skip & General Analysis
              </button>
              <button id="distatsStartFocusedAnalysisBtn" class="modal-btn-primary" data-i18n="ai.startFocusedAnalysis">
                Start Analysis
              </button>
            </div>
          </div>
        </div>
      `;
      
      // Append to sidebar container instead of body for proper scoping
      const sidebarContainer = document.getElementById('distats-sidebar-container');
      if (sidebarContainer) {
        sidebarContainer.appendChild(modal);
      } else {
        document.body.appendChild(modal);
      }
      
      // Apply translations
      if (window.applyTranslationsToElement) {
        window.applyTranslationsToElement(modal);
      }
      
      // Close button handler
      const closeBtn = document.getElementById('distatsCloseAIFocusModal');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          modal.classList.add('hidden');
        });
      }
      
      // Skip button handler - starts general analysis
      const skipBtn = document.getElementById('distatsSkipFocusBtn');
      if (skipBtn) {
        skipBtn.addEventListener('click', () => {
          modal.classList.add('hidden');
          triggerAIAnalysis(null); // No focus - general analysis
        });
      }
      
      // Start focused analysis button handler
      const startBtn = document.getElementById('distatsStartFocusedAnalysisBtn');
      if (startBtn) {
        startBtn.addEventListener('click', () => {
          const focusInput = document.getElementById('distatsAIFocusInput');
          const focus = focusInput ? focusInput.value.trim() : null;
          modal.classList.add('hidden');
          triggerAIAnalysis(focus || null); // Pass focus or null if empty
        });
      }
      
      // Close on outside click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
        }
      });
      
      // Allow Enter key to submit (Ctrl+Enter for multiline)
      const focusInput = document.getElementById('distatsAIFocusInput');
      if (focusInput) {
        focusInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            const focus = focusInput.value.trim();
            modal.classList.add('hidden');
            triggerAIAnalysis(focus || null);
          }
        });
      }
    }
    
    // Reset input and show modal
    const focusInput = document.getElementById('distatsAIFocusInput');
    if (focusInput) {
      focusInput.value = '';
    }
    
    modal.classList.remove('hidden');
    
    // Focus on the input
    setTimeout(() => {
      const input = document.getElementById('distatsAIFocusInput');
      if (input) {
        input.focus();
      }
    }, 100);
  }

  async function triggerAIAnalysis(analysisFocus = null) {
    console.log('triggerAIAnalysis called, currentAnalysisId:', currentAnalysisId, 'analysisFocus:', analysisFocus);
    
    if (!currentAnalysisId) {
      alert('Please select a project first.');
      return;
    }

    let apiKey;
    try {
      apiKey = await loadOpenAIKey();
    } catch (error) {
      console.error('Error loading API key:', error);
      showAPISettingsModal();
      return;
    }

    if (!apiKey) {
      showAPISettingsModal();
      return;
    }

    let selectedLanguage = 'auto';
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['ai_analysis_language'], resolve);
      });
      selectedLanguage = result.ai_analysis_language || 'auto';
      console.log('AI Analysis - Loaded language preference:', selectedLanguage);
    } catch (error) {
      console.error('Error loading language preference:', error);
      selectedLanguage = 'auto'; // fallback to auto
    }

    // Validate language setting
    const validLanguages = ['auto', 'en', 'ru', 'sr', 'de', 'pl', 'es', 'fr', 'it', 'pt'];
    if (!validLanguages.includes(selectedLanguage)) {
      console.warn('Invalid language setting detected:', selectedLanguage, '- falling back to auto');
      selectedLanguage = 'auto';
    }

    // Show modal with loading state
    showAIAnalysisResults(null, null);
    const loadingDiv = document.getElementById('distatsAIAnalysisLoading');
    if (loadingDiv) {
      loadingDiv.style.display = 'block';
      loadingDiv.innerHTML = `
        <div style="text-align: center; color: #8b949e; padding: 40px;">
          <div style="margin: 0 auto 16px; width: 32px; height: 32px; border: 3px solid #21262d; border-top-color: #58a6ff; border-radius: 50%; animation: spin 1s linear infinite;"></div>
          <p>Analyzing your data...</p>
        </div>
        <style>
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        </style>
      `;
    }

    try {
      console.log('Collecting analysis data for:', currentAnalysisId);
      const analysisData = await collectAnalysisData(currentAnalysisId);
      console.log('Analysis data collected:', {
        notes: analysisData.notes.length,
        markers: analysisData.timelineMarkers.length,
        schemes: analysisData.tacticalSchemes.length,
        images: analysisData.regularImages.length
      });
      
      // Store for citation previews (same structure as popup expects)
      currentAnalysisDataForPreview = {
        notes: analysisData.notes || [],
        timelineMarkers: analysisData.timelineMarkers || [],
        tacticalSchemes: analysisData.tacticalSchemes || [],
        regularImages: analysisData.regularImages || []
      };
      
      console.log('Stored analysis data for citations:', {
        notes: currentAnalysisDataForPreview.notes.length,
        markers: currentAnalysisDataForPreview.timelineMarkers.length,
        schemes: currentAnalysisDataForPreview.tacticalSchemes.length,
        images: currentAnalysisDataForPreview.regularImages.length
      });
      
      if (analysisData.notes.length === 0 && analysisData.timelineMarkers.length === 0 && 
          analysisData.tacticalSchemes.length === 0 && analysisData.regularImages.length === 0) {
        showAIAnalysisResults(null, 'No data to analyze. Please add some notes, timeline markers, tactical schemes, or images first.');
        return;
      }

      // Retrieve relevant historical comments from comments database for RAG
      let historicalComments = [];
      try {
        if (window.aiAnalysisUtils && window.aiAnalysisUtils.retrieveRelevantComments) {
          historicalComments = await window.aiAnalysisUtils.retrieveRelevantComments(analysisData, 20);
          console.log('Retrieved historical comments for RAG:', historicalComments.length);
        }
      } catch (error) {
        console.warn('Error retrieving historical comments, proceeding without RAG:', error);
        // Continue without historical comments if retrieval fails
      }

      console.log('Formatting data for AI with language:', selectedLanguage);
      const prompt = window.aiAnalysisUtils.formatDataForAI(analysisData, selectedLanguage, historicalComments, analysisFocus);
      console.log('Calling OpenAI API...');
      const results = await callOpenAIAnalysis(prompt, apiKey);
      console.log('AI analysis complete, showing results...');
      showAIAnalysisResults(results);
    } catch (error) {
      console.error('AI Analysis error:', error);
      showAIAnalysisResults(null, error.message || 'An error occurred during analysis.');
    }
  }

  // Show API Settings Modal (floating window)
  function showAPISettingsModal() {
    // Create or show modal
    let modal = document.getElementById('distatsAPISettingsModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'distatsAPISettingsModal';
      modal.className = 'project-modal hidden';
      modal.innerHTML = `
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3>AI Analysis Settings</h3>
            <button id="distatsCloseAPISettingsModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #c9d1d9; margin-bottom: 16px; font-size: 13px;">Configure your OpenAI API key and analysis preferences. Your key is stored locally and never shared.</p>
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;">API Key:</label>
              <input 
                type="password"
                id="distatsApiKeyInput" 
                class="url-input-modal" 
                placeholder="sk-..."
                style="width: 100%; padding: 8px 12px; font-family: monospace;"
              />
            </div>
            <div style="margin-bottom: 16px;">
              <label style="display: block; margin-bottom: 6px; font-size: 13px; color: #c9d1d9;">Analysis Language:</label>
              <select id="distatsApiKeyLanguageSelect" class="url-input-modal" style="width: 100%; padding: 8px 12px;">
                <option value="auto">Auto-detect (same as notes)</option>
                <option value="en">English</option>
                <option value="sr">Serbian (Srpski)</option>
                <option value="ru">Russian (Русский)</option>
                <option value="de">German (Deutsch)</option>
                <option value="pl">Polish (Polski)</option>
                <option value="es">Spanish (Español)</option>
                <option value="fr">French (Français)</option>
                <option value="it">Italian (Italiano)</option>
                <option value="pt">Portuguese (Português)</option>
              </select>
            </div>
            <div id="distatsApiKeyError" style="color: #da3633; font-size: 12px; margin-bottom: 12px; display: none;"></div>
            <div id="distatsApiKeySuccess" style="color: #3fb950; font-size: 12px; margin-bottom: 12px; display: none;"></div>
            <div style="display: flex; gap: 8px; justify-content: flex-end;">
              <button id="distatsDeleteApiKeyBtn" class="create-new-project-btn" style="background: transparent; border: 1px solid #30363d; color: #c9d1d9; display: none;">Delete Key</button>
              <button id="distatsSaveApiKeyBtn" class="create-new-project-btn">Save Settings</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      
      // Close button handler
      document.getElementById('distatsCloseAPISettingsModal').addEventListener('click', () => {
        modal.classList.add('hidden');
      });
      
      // Close on background click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
        }
      });
      
      // Save button handler
      const saveBtn = document.getElementById('distatsSaveApiKeyBtn');
      const deleteBtn = document.getElementById('distatsDeleteApiKeyBtn');
      const apiKeyInput = document.getElementById('distatsApiKeyInput');
      const languageSelect = document.getElementById('distatsApiKeyLanguageSelect');
      const errorDiv = document.getElementById('distatsApiKeyError');
      const successDiv = document.getElementById('distatsApiKeySuccess');
      
      if (saveBtn && apiKeyInput) {
        saveBtn.addEventListener('click', async () => {
          const apiKey = apiKeyInput.value.trim();
          const language = languageSelect ? languageSelect.value : 'auto';
          
          errorDiv.style.display = 'none';
          successDiv.style.display = 'none';
          
          if (apiKey && !validateAPIKey(apiKey)) {
            errorDiv.textContent = 'Invalid API key format. Please enter a valid OpenAI API key (starts with sk-).';
            errorDiv.style.display = 'block';
            return;
          }
          
          try {
            const dataToSave = {};
            if (apiKey) {
              dataToSave.openai_api_key = apiKey;
            }
            if (language) {
              dataToSave.ai_analysis_language = language;
            }
            
            await new Promise((resolve, reject) => {
              chrome.storage.local.set(dataToSave, () => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve();
                }
              });
            });
            
            successDiv.textContent = 'Settings saved successfully!';
            successDiv.style.display = 'block';
            
            // Update placeholder if key was saved
            if (apiKey) {
              apiKeyInput.value = '';
              apiKeyInput.placeholder = 'API key is set (enter new key to update)';
              if (deleteBtn) deleteBtn.style.display = 'block';
            }
            
            setTimeout(() => {
              successDiv.style.display = 'none';
            }, 2000);
          } catch (error) {
            errorDiv.textContent = 'Error saving settings: ' + error.message;
            errorDiv.style.display = 'block';
          }
        });
      }
      
      if (deleteBtn) {
        deleteBtn.addEventListener('click', async () => {
          try {
            await new Promise((resolve, reject) => {
              chrome.storage.local.remove(['openai_api_key'], () => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve();
                }
              });
            });
            
            apiKeyInput.value = '';
            apiKeyInput.placeholder = 'sk-...';
            deleteBtn.style.display = 'none';
            successDiv.textContent = 'API key deleted successfully!';
            successDiv.style.display = 'block';
            errorDiv.style.display = 'none';
            
            setTimeout(() => {
              successDiv.style.display = 'none';
            }, 2000);
          } catch (error) {
            errorDiv.textContent = 'Error deleting API key: ' + error.message;
            errorDiv.style.display = 'block';
          }
        });
      }
    }

    // Load current settings
    const apiKeyInput = document.getElementById('distatsApiKeyInput');
    const languageSelect = document.getElementById('distatsApiKeyLanguageSelect');
    const deleteBtn = document.getElementById('distatsDeleteApiKeyBtn');
    const errorDiv = document.getElementById('distatsApiKeyError');
    const successDiv = document.getElementById('distatsApiKeySuccess');
    
    if (errorDiv) errorDiv.style.display = 'none';
    if (successDiv) successDiv.style.display = 'none';
    if (apiKeyInput) apiKeyInput.value = '';

    // Load both API key and language preference
    Promise.all([
      loadOpenAIKey(),
      new Promise((resolve) => {
        chrome.storage.local.get(['ai_analysis_language'], (result) => {
          resolve(result.ai_analysis_language || 'auto');
        });
      })
    ]).then(([key, language]) => {
      if (key) {
        if (apiKeyInput) {
          apiKeyInput.placeholder = 'API key is set (enter new key to update)';
        }
        if (deleteBtn) deleteBtn.style.display = 'block';
      } else {
        if (apiKeyInput) {
          apiKeyInput.placeholder = 'sk-...';
        }
        if (deleteBtn) deleteBtn.style.display = 'none';
      }
      
      if (languageSelect) {
        languageSelect.value = language;
      }
      
      modal.classList.remove('hidden');
      if (apiKeyInput) apiKeyInput.focus();
    }).catch(err => {
      console.error('Error loading settings:', err);
      if (languageSelect) {
        languageSelect.value = 'auto';
      }
      modal.classList.remove('hidden');
      if (apiKeyInput) apiKeyInput.focus();
    });
  }

  // ========== END AI ANALYSIS FUNCTIONS ==========

  // ========== HIGHLIGHT CREATOR FUNCTIONS ==========

  // Global state for highlight creator
  let highlightCreatorState = {
    isRecording: false,
    isCancelled: false,
    mediaRecorder: null,
    recordedChunks: [],
    canvas: null,
    ctx: null,
    stream: null,
    videoBlob: null,
    mimeType: null
  };

  // Parse time string to seconds (supports MM:SS, HH:MM:SS, and milliseconds like MM:SS.mmm)
  function parseTimeToSeconds(timeStr) {
    if (!timeStr || typeof timeStr !== 'string') return null;
    
    const trimmed = timeStr.trim();
    
    // Check for milliseconds (format: X:XX.XXX or X:XX:XX.XXX)
    let mainPart = trimmed;
    let milliseconds = 0;
    
    if (trimmed.includes('.')) {
      const dotParts = trimmed.split('.');
      mainPart = dotParts[0];
      const msStr = dotParts[1] || '0';
      // Pad or truncate to 3 digits
      const msPadded = msStr.padEnd(3, '0').substring(0, 3);
      milliseconds = parseInt(msPadded, 10) / 1000;
    }
    
    const parts = mainPart.split(':').map(p => parseInt(p, 10));
    
    // Validate parts are numbers
    if (parts.some(p => isNaN(p) || p < 0)) return null;
    
    let totalSeconds = 0;
    
    if (parts.length === 2) {
      // MM:SS format
      const [mins, secs] = parts;
      if (secs >= 60) return null;
      totalSeconds = mins * 60 + secs;
    } else if (parts.length === 3) {
      // HH:MM:SS format
      const [hours, mins, secs] = parts;
      if (mins >= 60 || secs >= 60) return null;
      totalSeconds = hours * 3600 + mins * 60 + secs;
    } else {
      return null;
    }
    
    return totalSeconds + milliseconds;
  }

  // Format seconds to time string (with optional milliseconds)
  function formatSecondsToTime(seconds, includeMs = false) {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.round((seconds % 1) * 1000);
    
    let result;
    if (hours > 0) {
      result = `${hours}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
      result = `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    // Include milliseconds if requested or if there are significant milliseconds
    if (includeMs && ms > 0) {
      result += `.${ms.toString().padStart(3, '0')}`;
    }
    
    return result;
  }

  // Parse time frame string (e.g., "1:11-1:21") to {start, end} in seconds
  function parseTimeFrame(frameStr) {
    if (!frameStr || typeof frameStr !== 'string') return null;
    
    const trimmed = frameStr.trim();
    if (!trimmed) return null;
    
    // Split by dash, handling potential spaces
    const parts = trimmed.split('-').map(p => p.trim());
    if (parts.length !== 2) return null;
    
    const start = parseTimeToSeconds(parts[0]);
    const end = parseTimeToSeconds(parts[1]);
    
    if (start === null || end === null) return null;
    if (start >= end) return null;
    
    return { start, end, original: trimmed };
  }

  // Parse multiple time frames from input (newline or comma separated)
  function parseTimeFrames(input) {
    if (!input || typeof input !== 'string') return [];
    
    // Split by newlines or commas
    const lines = input.split(/[\n,]/).map(line => line.trim()).filter(line => line);
    
    const frames = [];
    const errors = [];
    
    for (const line of lines) {
      const frame = parseTimeFrame(line);
      if (frame) {
        frames.push(frame);
      } else if (line) {
        errors.push(line);
      }
    }
    
    return { frames, errors };
  }

  // Validate time frames against video duration
  function validateTimeFrames(frames, videoDuration) {
    const validFrames = [];
    const invalidFrames = [];
    
    for (const frame of frames) {
      if (frame.end <= videoDuration) {
        validFrames.push(frame);
      } else {
        invalidFrames.push({
          ...frame,
          reason: `End time exceeds video duration (${formatSecondsToTime(videoDuration)})`
        });
      }
    }
    
    return { validFrames, invalidFrames };
  }

  // Wait for video to seek and be ready
  function waitForVideoSeek(video, targetTime, maxWait = 5000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      
      const onSeeked = () => {
        video.removeEventListener('seeked', onSeeked);
        // Small delay to ensure frame is rendered
        setTimeout(resolve, 100);
      };
      
      const checkTimeout = () => {
        if (Date.now() - startTime > maxWait) {
          video.removeEventListener('seeked', onSeeked);
          reject(new Error('Video seek timeout'));
          return;
        }
        
        if (Math.abs(video.currentTime - targetTime) < 0.5 && video.readyState >= 2) {
          video.removeEventListener('seeked', onSeeked);
          setTimeout(resolve, 100);
        } else {
          setTimeout(checkTimeout, 50);
        }
      };
      
      video.addEventListener('seeked', onSeeked);
      video.currentTime = targetTime;
      
      // Also check periodically in case seeked event doesn't fire
      setTimeout(checkTimeout, 100);
    });
  }

  // Create highlight video from time frames
  async function createHighlightVideo(timeFrames, onProgress) {
    const video = document.querySelector('video');
    if (!video) {
      throw new Error('Video element not found');
    }

    // Check if video can be captured (CORS check)
    try {
      const testCanvas = document.createElement('canvas');
      testCanvas.width = 10;
      testCanvas.height = 10;
      const testCtx = testCanvas.getContext('2d');
      testCtx.drawImage(video, 0, 0, 10, 10);
      testCanvas.toDataURL(); // This will throw if CORS blocks it
    } catch (e) {
      throw new Error('Cannot capture video due to cross-origin restrictions. This feature works best with videos that allow canvas capture.');
    }

    // Initialize canvas with video dimensions
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');

    // Store in state
    highlightCreatorState.canvas = canvas;
    highlightCreatorState.ctx = ctx;
    highlightCreatorState.recordedChunks = [];

    // Create stream from canvas
    const stream = canvas.captureStream(30); // 30 fps
    highlightCreatorState.stream = stream;

    // Initialize MediaRecorder - prefer MP4 if supported, fallback to WebM
    let mimeType;
    if (MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = 'video/mp4';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
      mimeType = 'video/webm;codecs=vp9';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8')) {
      mimeType = 'video/webm;codecs=vp8';
    } else {
      mimeType = 'video/webm';
    }

    // Store the mime type for later use
    highlightCreatorState.mimeType = mimeType;

    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: mimeType,
      videoBitsPerSecond: 5000000 // 5 Mbps for good quality
    });

    highlightCreatorState.mediaRecorder = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        highlightCreatorState.recordedChunks.push(event.data);
      }
    };

    // Store original video state
    const wasPlaying = !video.paused;
    const originalTime = video.currentTime;

    // Pause video for controlled capture
    video.pause();

    try {
      // Start recording
      mediaRecorder.start(100); // Collect data every 100ms
      highlightCreatorState.isRecording = true;

      // Process each segment
      for (let i = 0; i < timeFrames.length; i++) {
        if (highlightCreatorState.isCancelled) {
          throw new Error('Recording cancelled');
        }

        const frame = timeFrames[i];
        const segmentDuration = frame.end - frame.start;
        
        // Report progress
        if (onProgress) {
          onProgress({
            type: 'segment_start',
            current: i + 1,
            total: timeFrames.length,
            segment: frame
          });
        }

        // Seek to start of segment
        await waitForVideoSeek(video, frame.start);

        // Play video and capture frames
        video.play();

        // Capture frames until end time or cancellation
        await new Promise((resolve, reject) => {
          const frameInterval = 1000 / 30; // 30 fps
          let lastFrameTime = 0;

          const captureLoop = () => {
            if (highlightCreatorState.isCancelled) {
              video.pause();
              reject(new Error('Recording cancelled'));
              return;
            }

            const currentTime = video.currentTime;

            // Check if we've reached end of segment
            if (currentTime >= frame.end) {
              video.pause();
              resolve();
              return;
            }

            // Capture frame to canvas
            const now = performance.now();
            if (now - lastFrameTime >= frameInterval) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              lastFrameTime = now;
            }

            // Continue loop
            requestAnimationFrame(captureLoop);
          };

          captureLoop();
        });

        // Small pause between segments
        await new Promise(resolve => setTimeout(resolve, 100));

        // Report segment complete
        if (onProgress) {
          onProgress({
            type: 'segment_complete',
            current: i + 1,
            total: timeFrames.length,
            segment: frame
          });
        }
      }

      // Stop recording
      return new Promise((resolve, reject) => {
        mediaRecorder.onstop = () => {
          const blob = new Blob(highlightCreatorState.recordedChunks, { type: mimeType });
          highlightCreatorState.videoBlob = blob;
          highlightCreatorState.isRecording = false;

          // Restore video state
          video.currentTime = originalTime;
          if (wasPlaying) {
            video.play().catch(() => {});
          }

          resolve(blob);
        };

        mediaRecorder.onerror = (event) => {
          reject(new Error('MediaRecorder error: ' + event.error));
        };

        mediaRecorder.stop();
      });

    } catch (error) {
      // Cleanup on error
      highlightCreatorState.isRecording = false;
      if (mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }
      
      // Restore video state
      video.currentTime = originalTime;
      if (wasPlaying) {
        video.play().catch(() => {});
      }

      throw error;
    }
  }

  // Create highlight video with images support (enhanced version)
  async function createHighlightVideoWithImages(items, onProgress) {
    const video = document.querySelector('video');
    if (!video) {
      throw new Error('Video element not found');
    }

    // Check if we have any video segments
    const hasSegments = items.some(item => item.type === 'segment');
    
    if (hasSegments) {
      // Check if video can be captured (CORS check)
      try {
        const testCanvas = document.createElement('canvas');
        testCanvas.width = 10;
        testCanvas.height = 10;
        const testCtx = testCanvas.getContext('2d');
        testCtx.drawImage(video, 0, 0, 10, 10);
        testCanvas.toDataURL();
      } catch (e) {
        throw new Error('Cannot capture video due to cross-origin restrictions. This feature works best with videos that allow canvas capture.');
      }
    }

    // Initialize canvas with video dimensions
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');

    // Store in state
    highlightCreatorState.canvas = canvas;
    highlightCreatorState.ctx = ctx;
    highlightCreatorState.recordedChunks = [];

    // Create stream from canvas
    const stream = canvas.captureStream(30); // 30 fps

    // Initialize MediaRecorder - prefer MP4 if supported, fallback to WebM
    let mimeType;
    if (MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = 'video/mp4';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
      mimeType = 'video/webm;codecs=vp9';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8')) {
      mimeType = 'video/webm;codecs=vp8';
    } else {
      mimeType = 'video/webm';
    }

    highlightCreatorState.mimeType = mimeType;
    highlightCreatorState.stream = stream;

    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: mimeType,
      videoBitsPerSecond: 5000000
    });

    highlightCreatorState.mediaRecorder = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        highlightCreatorState.recordedChunks.push(event.data);
      }
    };

    // Store original video state
    const wasPlaying = !video.paused;
    const originalTime = video.currentTime;

    // Pause video for controlled capture
    video.pause();

    try {
      // Start recording
      mediaRecorder.start(100);
      highlightCreatorState.isRecording = true;

      // Process each item
      for (let i = 0; i < items.length; i++) {
        if (highlightCreatorState.isCancelled) {
          throw new Error('Recording cancelled');
        }

        const item = items[i];
        
        // Report progress
        if (onProgress) {
          onProgress({
            type: 'item_start',
            current: i + 1,
            total: items.length,
            item: item
          });
        }

        if (item.type === 'segment') {
          // Process video segment
          const segmentDuration = item.end - item.start;
          
          // Seek to start of segment
          await waitForVideoSeek(video, item.start);

          // Play video and capture frames
          video.play();

          // Capture frames until end time or cancellation
          await new Promise((resolve, reject) => {
            const frameRate = 30;
            const frameInterval = 1000 / frameRate;
            let lastDrawTime = 0;
            let animationFrameId = null;

            const captureFrame = (timestamp) => {
              if (highlightCreatorState.isCancelled) {
                cancelAnimationFrame(animationFrameId);
                video.pause();
                reject(new Error('Recording cancelled'));
                return;
              }

              if (video.currentTime >= item.end) {
                cancelAnimationFrame(animationFrameId);
                video.pause();
                resolve();
                return;
              }

              if (timestamp - lastDrawTime >= frameInterval) {
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                lastDrawTime = timestamp;
              }

              animationFrameId = requestAnimationFrame(captureFrame);
            };

            animationFrameId = requestAnimationFrame(captureFrame);

            // Timeout safety
            const maxTime = (segmentDuration + 5) * 1000;
            setTimeout(() => {
              if (animationFrameId) {
                cancelAnimationFrame(animationFrameId);
                video.pause();
                resolve();
              }
            }, maxTime);
          });

        } else if (item.type === 'image') {
          // Process image
          const duration = (item.duration || 3) * 1000; // Convert to milliseconds
          
          // Load the image
          const img = await loadImage(item.imageData);
          
          // Calculate dimensions to fit/fill canvas while maintaining aspect ratio
          const imgAspect = img.width / img.height;
          const canvasAspect = canvas.width / canvas.height;
          let drawWidth, drawHeight, drawX, drawY;
          
          if (imgAspect > canvasAspect) {
            // Image is wider - fit to width
            drawWidth = canvas.width;
            drawHeight = canvas.width / imgAspect;
            drawX = 0;
            drawY = (canvas.height - drawHeight) / 2;
          } else {
            // Image is taller - fit to height
            drawHeight = canvas.height;
            drawWidth = canvas.height * imgAspect;
            drawX = (canvas.width - drawWidth) / 2;
            drawY = 0;
          }
          
          // Draw image frames for the specified duration
          const frameRate = 30;
          const totalFrames = Math.ceil((duration / 1000) * frameRate);
          const frameInterval = duration / totalFrames;
          
          for (let frame = 0; frame < totalFrames; frame++) {
            if (highlightCreatorState.isCancelled) {
              throw new Error('Recording cancelled');
            }
            
            // Clear canvas with black background
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Draw image centered
            ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
            
            // Wait for next frame
            await new Promise(resolve => setTimeout(resolve, frameInterval));
          }
        } else if (item.type === 'gif') {
          // Process animated GIF with proper frame decoding
          const duration = (item.duration || 3) * 1000; // Convert to milliseconds
          
          try {
            // Decode GIF frames
            const frames = await decodeGifFrames(item.imageData);
            
            if (!frames || frames.length === 0) {
              // Fallback: treat as static image
              const gifImg = await loadImage(item.imageData);
              const imgAspect = gifImg.width / gifImg.height;
              const canvasAspect = canvas.width / canvas.height;
              let drawWidth, drawHeight, drawX, drawY;
              
              if (imgAspect > canvasAspect) {
                drawWidth = canvas.width;
                drawHeight = canvas.width / imgAspect;
                drawX = 0;
                drawY = (canvas.height - drawHeight) / 2;
              } else {
                drawHeight = canvas.height;
                drawWidth = canvas.height * imgAspect;
                drawX = (canvas.width - drawWidth) / 2;
                drawY = 0;
              }
              
              const frameRate = 30;
              const totalFrames = Math.ceil((duration / 1000) * frameRate);
              const frameInterval = duration / totalFrames;
              
              for (let f = 0; f < totalFrames; f++) {
                if (highlightCreatorState.isCancelled) throw new Error('Recording cancelled');
                ctx.fillStyle = '#000000';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(gifImg, drawX, drawY, drawWidth, drawHeight);
                await new Promise(resolve => setTimeout(resolve, frameInterval));
              }
            } else {
              // Successfully decoded frames - render animation
              const firstFrame = frames[0].image;
              const imgAspect = firstFrame.width / firstFrame.height;
              const canvasAspect = canvas.width / canvas.height;
              let drawWidth, drawHeight, drawX, drawY;
              
              if (imgAspect > canvasAspect) {
                drawWidth = canvas.width;
                drawHeight = canvas.width / imgAspect;
                drawX = 0;
                drawY = (canvas.height - drawHeight) / 2;
              } else {
                drawHeight = canvas.height;
                drawWidth = canvas.height * imgAspect;
                drawX = (canvas.width - drawWidth) / 2;
                drawY = 0;
              }
              
              // Loop through frames for the specified duration
              let elapsedTime = 0;
              let frameIndex = 0;
              
              while (elapsedTime < duration) {
                if (highlightCreatorState.isCancelled) throw new Error('Recording cancelled');
                
                const currentFrame = frames[frameIndex];
                const frameDelay = currentFrame.delay || 100;
                
                // Clear canvas with black background
                ctx.fillStyle = '#000000';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // Draw the current frame
                ctx.drawImage(currentFrame.image, drawX, drawY, drawWidth, drawHeight);
                
                // Wait for frame delay
                await new Promise(resolve => setTimeout(resolve, frameDelay));
                
                elapsedTime += frameDelay;
                frameIndex = (frameIndex + 1) % frames.length;
              }
            }
          } catch (gifError) {
            console.error('Error rendering GIF:', gifError);
            // If GIF fails, try to render as static image
            try {
              const gifImg = await loadImage(item.imageData);
              ctx.fillStyle = '#000000';
              ctx.fillRect(0, 0, canvas.width, canvas.height);
              const imgAspect = gifImg.width / gifImg.height;
              const canvasAspect = canvas.width / canvas.height;
              let dw, dh, dx, dy;
              if (imgAspect > canvasAspect) {
                dw = canvas.width; dh = canvas.width / imgAspect; dx = 0; dy = (canvas.height - dh) / 2;
              } else {
                dh = canvas.height; dw = canvas.height * imgAspect; dx = (canvas.width - dw) / 2; dy = 0;
              }
              ctx.drawImage(gifImg, dx, dy, dw, dh);
              await new Promise(resolve => setTimeout(resolve, (item.duration || 3) * 1000));
            } catch (e) {
              console.error('Failed to render GIF as static image:', e);
            }
          }
        }

        // Report item complete
        if (onProgress) {
          onProgress({
            type: 'item_complete',
            current: i + 1,
            total: items.length
          });
        }
      }

      // Stop recording and return blob
      return new Promise((resolve, reject) => {
        mediaRecorder.onstop = () => {
          const blob = new Blob(highlightCreatorState.recordedChunks, { type: mimeType });
          highlightCreatorState.videoBlob = blob;
          highlightCreatorState.isRecording = false;

          // Restore video state
          video.currentTime = originalTime;
          if (wasPlaying) {
            video.play().catch(() => {});
          }

          resolve(blob);
        };

        mediaRecorder.onerror = (event) => {
          reject(new Error('MediaRecorder error: ' + event.error));
        };

        mediaRecorder.stop();
      });

    } catch (error) {
      // Cleanup on error
      highlightCreatorState.isRecording = false;
      if (mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }
      
      // Restore video state
      video.currentTime = originalTime;
      if (wasPlaying) {
        video.play().catch(() => {});
      }

      throw error;
    }
  }

  // Helper function to load an image
  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = src;
    });
  }

  // ========== GIF PARSING UTILITIES ==========
  
  // Check if a file is an animated GIF (has multiple frames)
  async function isAnimatedGif(file) {
    if (file.type !== 'image/gif') return false;
    
    try {
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      
      // Check GIF signature
      if (data[0] !== 0x47 || data[1] !== 0x49 || data[2] !== 0x46) {
        return false;
      }
      
      // Count image blocks - animated GIFs have multiple
      let frameCount = 0;
      let i = 6; // Skip header
      
      // Skip logical screen descriptor
      const hasGlobalColorTable = (data[10] & 0x80) !== 0;
      const globalColorTableSize = hasGlobalColorTable ? 3 * Math.pow(2, (data[10] & 0x07) + 1) : 0;
      i = 13 + globalColorTableSize;
      
      while (i < data.length) {
        const blockType = data[i];
        
        if (blockType === 0x21) {
          // Extension block
          i += 2;
          // Skip sub-blocks
          while (data[i] !== 0 && i < data.length) {
            i += data[i] + 1;
          }
          i++; // Skip terminator
        } else if (blockType === 0x2C) {
          // Image descriptor - found a frame
          frameCount++;
          if (frameCount > 1) return true; // More than one frame = animated
          
          i += 9; // Skip image descriptor
          const packed = data[i];
          const hasLocalColorTable = (packed & 0x80) !== 0;
          const localColorTableSize = hasLocalColorTable ? 3 * Math.pow(2, (packed & 0x07) + 1) : 0;
          i += 1 + localColorTableSize;
          i++; // Skip LZW minimum code size
          
          // Skip image data sub-blocks
          while (data[i] !== 0 && i < data.length) {
            i += data[i] + 1;
          }
          i++; // Skip terminator
        } else if (blockType === 0x3B) {
          break;
        } else {
          i++;
        }
      }
      
      return frameCount > 1;
    } catch (e) {
      console.error('Error checking if GIF is animated:', e);
      return false;
    }
  }

  // Full GIF decoder with LZW decompression
  function decodeGif(data) {
    let pos = 0;
    
    const read = (n) => {
      const result = data.subarray(pos, pos + n);
      pos += n;
      return result;
    };
    
    const readByte = () => data[pos++];
    const readWord = () => data[pos++] | (data[pos++] << 8);
    
    // Read header
    const header = String.fromCharCode(...read(6));
    if (header !== 'GIF87a' && header !== 'GIF89a') {
      throw new Error('Invalid GIF header');
    }
    
    // Logical screen descriptor
    const width = readWord();
    const height = readWord();
    const packed = readByte();
    const bgColorIndex = readByte();
    readByte(); // Pixel aspect ratio
    
    const hasGlobalColorTable = (packed & 0x80) !== 0;
    const globalColorTableSize = hasGlobalColorTable ? Math.pow(2, (packed & 0x07) + 1) : 0;
    
    // Global color table
    let globalColorTable = null;
    if (hasGlobalColorTable) {
      globalColorTable = [];
      for (let i = 0; i < globalColorTableSize; i++) {
        globalColorTable.push([readByte(), readByte(), readByte()]);
      }
    }
    
    const frames = [];
    let gce = null; // Graphics Control Extension
    
    // Create canvas for compositing frames
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    // Previous frame for disposal
    let previousImageData = null;
    
    while (pos < data.length) {
      const blockType = readByte();
      
      if (blockType === 0x21) {
        // Extension
        const extType = readByte();
        
        if (extType === 0xF9) {
          // Graphics Control Extension
          const blockSize = readByte();
          const gcePacked = readByte();
          const delay = readWord();
          const transparentIndex = readByte();
          readByte(); // Block terminator
          
          gce = {
            disposalMethod: (gcePacked >> 2) & 0x07,
            transparentFlag: (gcePacked & 0x01) !== 0,
            delay: delay * 10, // Convert centiseconds to milliseconds
            transparentIndex: transparentIndex
          };
        } else {
          // Skip other extensions
          while (true) {
            const size = readByte();
            if (size === 0) break;
            pos += size;
          }
        }
      } else if (blockType === 0x2C) {
        // Image descriptor
        const left = readWord();
        const top = readWord();
        const frameWidth = readWord();
        const frameHeight = readWord();
        const imgPacked = readByte();
        
        const hasLocalColorTable = (imgPacked & 0x80) !== 0;
        const interlaced = (imgPacked & 0x40) !== 0;
        const localColorTableSize = hasLocalColorTable ? Math.pow(2, (imgPacked & 0x07) + 1) : 0;
        
        // Local color table
        let colorTable = globalColorTable;
        if (hasLocalColorTable) {
          colorTable = [];
          for (let i = 0; i < localColorTableSize; i++) {
            colorTable.push([readByte(), readByte(), readByte()]);
          }
        }
        
        // LZW decode
        const minCodeSize = readByte();
        const imageData = lzwDecode(minCodeSize, readSubBlocks());
        
        // Handle disposal method from previous frame
        const disposal = gce ? gce.disposalMethod : 0;
        
        if (frames.length > 0) {
          if (disposal === 2) {
            // Restore to background
            ctx.fillStyle = globalColorTable ? 
              `rgb(${globalColorTable[bgColorIndex][0]},${globalColorTable[bgColorIndex][1]},${globalColorTable[bgColorIndex][2]})` : 
              'rgba(0,0,0,0)';
            ctx.fillRect(0, 0, width, height);
          } else if (disposal === 3 && previousImageData) {
            // Restore to previous
            ctx.putImageData(previousImageData, 0, 0);
          }
          // disposal 0 or 1: do not dispose, keep current canvas
        }
        
        // Save current state if next frame might need it
        if (disposal === 3) {
          previousImageData = ctx.getImageData(0, 0, width, height);
        }
        
        // Draw frame pixels
        const pixels = ctx.getImageData(left, top, frameWidth, frameHeight);
        const transparentIndex = gce && gce.transparentFlag ? gce.transparentIndex : -1;
        
        let srcIndex = 0;
        for (let y = 0; y < frameHeight; y++) {
          const destY = interlaced ? deinterlace(y, frameHeight) : y;
          for (let x = 0; x < frameWidth; x++) {
            const colorIndex = imageData[srcIndex++];
            if (colorIndex !== transparentIndex && colorTable && colorTable[colorIndex]) {
              const color = colorTable[colorIndex];
              const destIndex = (destY * frameWidth + x) * 4;
              pixels.data[destIndex] = color[0];
              pixels.data[destIndex + 1] = color[1];
              pixels.data[destIndex + 2] = color[2];
              pixels.data[destIndex + 3] = 255;
            }
          }
        }
        
        ctx.putImageData(pixels, left, top);
        
        // Save frame
        frames.push({
          imageData: ctx.getImageData(0, 0, width, height),
          delay: gce ? Math.max(gce.delay, 20) : 100
        });
        
        gce = null; // Reset for next frame
      } else if (blockType === 0x3B) {
        // Trailer
        break;
      } else if (blockType === 0x00) {
        // Skip null bytes
        continue;
      } else {
        // Unknown block, try to skip
        break;
      }
    }
    
    function readSubBlocks() {
      const chunks = [];
      while (true) {
        const size = readByte();
        if (size === 0) break;
        chunks.push(read(size));
      }
      // Concatenate all chunks
      const totalLength = chunks.reduce((sum, c) => sum + c.length, 0);
      const result = new Uint8Array(totalLength);
      let offset = 0;
      for (const chunk of chunks) {
        result.set(chunk, offset);
        offset += chunk.length;
      }
      return result;
    }
    
    function deinterlace(y, height) {
      const passes = [
        { start: 0, step: 8 },
        { start: 4, step: 8 },
        { start: 2, step: 4 },
        { start: 1, step: 2 }
      ];
      let row = 0;
      for (const pass of passes) {
        for (let i = pass.start; i < height; i += pass.step) {
          if (row === y) return i;
          row++;
        }
      }
      return y;
    }
    
    return { width, height, frames };
  }
  
  // LZW decoder for GIF
  function lzwDecode(minCodeSize, data) {
    const clearCode = 1 << minCodeSize;
    const eoiCode = clearCode + 1;
    
    let codeSize = minCodeSize + 1;
    let codeMask = (1 << codeSize) - 1;
    let nextCode = eoiCode + 1;
    
    // Initialize code table
    let codeTable = [];
    for (let i = 0; i < clearCode; i++) {
      codeTable[i] = [i];
    }
    
    const output = [];
    let bitBuffer = 0;
    let bitCount = 0;
    let dataIndex = 0;
    
    const readCode = () => {
      while (bitCount < codeSize && dataIndex < data.length) {
        bitBuffer |= data[dataIndex++] << bitCount;
        bitCount += 8;
      }
      const code = bitBuffer & codeMask;
      bitBuffer >>= codeSize;
      bitCount -= codeSize;
      return code;
    };
    
    let prevCode = -1;
    
    while (dataIndex < data.length || bitCount >= codeSize) {
      const code = readCode();
      
      if (code === clearCode) {
        // Reset
        codeSize = minCodeSize + 1;
        codeMask = (1 << codeSize) - 1;
        nextCode = eoiCode + 1;
        codeTable = [];
        for (let i = 0; i < clearCode; i++) {
          codeTable[i] = [i];
        }
        prevCode = -1;
        continue;
      }
      
      if (code === eoiCode) {
        break;
      }
      
      let entry;
      if (code < nextCode) {
        entry = codeTable[code];
      } else if (code === nextCode && prevCode >= 0) {
        entry = [...codeTable[prevCode], codeTable[prevCode][0]];
      } else {
        // Invalid code
        break;
      }
      
      if (entry) {
        output.push(...entry);
        
        if (prevCode >= 0 && nextCode < 4096) {
          codeTable[nextCode++] = [...codeTable[prevCode], entry[0]];
          
          if (nextCode > codeMask && codeSize < 12) {
            codeSize++;
            codeMask = (1 << codeSize) - 1;
          }
        }
      }
      
      prevCode = code;
    }
    
    return output;
  }

  // Extract and decode GIF frames
  async function decodeGifFrames(imageDataUrl) {
    try {
      const response = await fetch(imageDataUrl);
      const arrayBuffer = await response.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      
      const gif = decodeGif(data);
      
      // Convert ImageData frames to canvas images
      const frames = [];
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = gif.width;
      tempCanvas.height = gif.height;
      const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
      
      for (const frame of gif.frames) {
        tempCtx.putImageData(frame.imageData, 0, 0);
        const dataUrl = tempCanvas.toDataURL('image/png');
        const img = await loadImage(dataUrl);
        frames.push({
          image: img,
          delay: frame.delay
        });
      }
      
      return frames;
    } catch (e) {
      console.error('Error decoding GIF:', e);
      return null;
    }
  }

  // Extract frame delays from GIF binary data (lightweight, no decoding)
  function extractGifDelays(data) {
    const delays = [];
    let i = 6; // Skip header "GIF89a" or "GIF87a"
    
    // Skip logical screen descriptor
    const hasGlobalColorTable = (data[10] & 0x80) !== 0;
    const globalColorTableSize = hasGlobalColorTable ? 3 * Math.pow(2, (data[10] & 0x07) + 1) : 0;
    i = 13 + globalColorTableSize;
    
    let currentDelay = 100; // Default delay
    
    while (i < data.length) {
      const blockType = data[i];
      
      if (blockType === 0x21) {
        // Extension block
        const extType = data[i + 1];
        
        if (extType === 0xF9) {
          // Graphics Control Extension
          const blockSize = data[i + 2];
          if (blockSize >= 4) {
            // Delay time is at offset 3-4 (in centiseconds)
            const delayCs = data[i + 4] | (data[i + 5] << 8);
            currentDelay = delayCs * 10; // Convert to milliseconds
            if (currentDelay < 20) currentDelay = 100; // Some GIFs use 0 or very low values
          }
          i += 2 + 1 + blockSize + 1; // Extension header + block + terminator
        } else {
          // Other extension - skip
          i += 2;
          while (data[i] !== 0 && i < data.length) {
            i += data[i] + 1;
          }
          i++; // Skip terminator
        }
      } else if (blockType === 0x2C) {
        // Image descriptor - this is a frame
        delays.push(currentDelay);
        currentDelay = 100; // Reset for next frame
        
        i += 9; // Skip image descriptor header
        
        // Check for local color table
        const packed = data[i];
        const hasLocalColorTable = (packed & 0x80) !== 0;
        const localColorTableSize = hasLocalColorTable ? 3 * Math.pow(2, (packed & 0x07) + 1) : 0;
        i += 1 + localColorTableSize;
        
        // Skip LZW minimum code size
        i++;
        
        // Skip image data sub-blocks
        while (data[i] !== 0 && i < data.length) {
          i += data[i] + 1;
        }
        i++; // Skip terminator
      } else if (blockType === 0x3B) {
        // Trailer - end of GIF
        break;
      } else {
        i++;
      }
    }
    
    return delays;
  }

  // ========== END GIF PARSING UTILITIES ==========

  // Download the recorded video
  function downloadHighlightVideo(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `highlight_${Date.now()}.webm`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Reset highlight creator state
  function resetHighlightCreatorState() {
    highlightCreatorState.isRecording = false;
    highlightCreatorState.isCancelled = false;
    highlightCreatorState.recordedChunks = [];
    highlightCreatorState.videoBlob = null;
    highlightCreatorState.mimeType = null;
    
    if (highlightCreatorState.stream) {
      highlightCreatorState.stream.getTracks().forEach(track => track.stop());
      highlightCreatorState.stream = null;
    }
    
    highlightCreatorState.canvas = null;
    highlightCreatorState.ctx = null;
    highlightCreatorState.mediaRecorder = null;
  }

  // Cancel ongoing recording
  function cancelHighlightRecording() {
    highlightCreatorState.isCancelled = true;
    
    if (highlightCreatorState.mediaRecorder && highlightCreatorState.mediaRecorder.state !== 'inactive') {
      highlightCreatorState.mediaRecorder.stop();
    }
  }

  // Make highlight panel draggable
  function makeHighlightPanelDraggable() {
    const panel = document.getElementById('distatsHighlightCreatorPanel');
    const header = document.getElementById('distatsHighlightPanelHeader');
    
    if (!panel || !header) return;
    
    let isDragging = false;
    let startX, startY, startLeft, startTop;
    
    // Helper function to keep panel within viewport bounds
    function constrainToViewport() {
      const panelRect = panel.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      
      let needsUpdate = false;
      let newLeft = panelRect.left;
      let newTop = panelRect.top;
      
      // Keep at least 100px of panel visible horizontally
      const minVisibleX = 100;
      if (panelRect.right < minVisibleX) {
        newLeft = minVisibleX - panelRect.width;
        needsUpdate = true;
      } else if (panelRect.left > viewportWidth - minVisibleX) {
        newLeft = viewportWidth - minVisibleX;
        needsUpdate = true;
      }
      
      // Keep header always visible (at least 50px from top, and not below viewport)
      const minTop = 0;
      const maxTop = viewportHeight - 60; // Keep at least header visible
      if (panelRect.top < minTop) {
        newTop = minTop;
        needsUpdate = true;
      } else if (panelRect.top > maxTop) {
        newTop = maxTop;
        needsUpdate = true;
      }
      
      if (needsUpdate) {
        panel.style.transform = 'none';
        panel.style.left = newLeft + 'px';
        panel.style.top = newTop + 'px';
        panel.style.right = 'auto';
      }
    }
    
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.highlight-panel-btn')) return; // Don't drag when clicking buttons
      
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      
      // Remove transform and use actual position
      const rect = panel.getBoundingClientRect();
      panel.style.transform = 'none';
      panel.style.left = rect.left + 'px';
      panel.style.top = rect.top + 'px';
      panel.style.right = 'auto';
      
      startLeft = rect.left;
      startTop = rect.top;
      
      document.addEventListener('mousemove', onDrag);
      document.addEventListener('mouseup', stopDrag);
    });
    
    function onDrag(e) {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      let newLeft = startLeft + dx;
      let newTop = startTop + dy;
      
      const panelRect = panel.getBoundingClientRect();
      const panelWidth = panelRect.width;
      
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      
      // Keep at least 100px of panel visible horizontally
      const minVisibleX = 100;
      newLeft = Math.max(minVisibleX - panelWidth, Math.min(newLeft, viewportWidth - minVisibleX));
      
      // Keep header always visible
      const minTop = 0;
      const maxTop = viewportHeight - 60;
      newTop = Math.max(minTop, Math.min(newTop, maxTop));
      
      panel.style.left = newLeft + 'px';
      panel.style.top = newTop + 'px';
    }
    
    function stopDrag() {
      isDragging = false;
      document.removeEventListener('mousemove', onDrag);
      document.removeEventListener('mouseup', stopDrag);
    }
    
    // Constrain panel on window resize
    window.addEventListener('resize', constrainToViewport);
    
    // Also constrain when panel becomes visible
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if (!panel.classList.contains('hidden')) {
            setTimeout(constrainToViewport, 10);
          }
        }
      });
    });
    observer.observe(panel, { attributes: true });
  }

  // Setup highlight creator event listeners
  function setupHighlightCreatorListeners() {
    const openBtn = document.getElementById('distatsCreateHighlightsBtn');
    const panel = document.getElementById('distatsHighlightCreatorPanel');
    const closeBtn = document.getElementById('distatsHighlightClose');
    const minimizeBtn = document.getElementById('distatsHighlightMinimize');
    const cancelBtn = document.getElementById('distatsHighlightCancelBtn');
    const createBtn = document.getElementById('distatsHighlightCreateBtn');
    const downloadMp4Btn = document.getElementById('distatsHighlightDownloadMp4Btn');
    const downloadWebmBtn = document.getElementById('distatsHighlightDownloadWebmBtn');
    const formatNote = document.getElementById('distatsHighlightFormatNote');
    const timeFramesInput = document.getElementById('distatsHighlightTimeFrames');
    const parsedPreview = document.getElementById('distatsHighlightParsedPreview');
    const segmentsList = document.getElementById('distatsHighlightSegmentsList');
    const errorDiv = document.getElementById('distatsHighlightError');
    const progressDiv = document.getElementById('distatsHighlightProgress');
    const progressText = document.getElementById('distatsHighlightProgressText');
    const progressCount = document.getElementById('distatsHighlightProgressCount');
    const progressBar = document.getElementById('distatsHighlightProgressBar');
    const currentSegmentDiv = document.getElementById('distatsHighlightCurrentSegment');
    const completeDiv = document.getElementById('distatsHighlightComplete');
    const footer = document.getElementById('distatsHighlightFooter');

    if (!openBtn || !panel) return;

    // Make panel draggable
    makeHighlightPanelDraggable();

    // Get additional UI elements for new features
    const disclaimerCheckbox = document.getElementById('distatsHighlightDisclaimerCheckbox');
    const simpleContent = document.getElementById('distatsHighlightSimpleContent');
    const advancedContent = document.getElementById('distatsHighlightAdvancedContent');
    const simpleModeBtn = document.getElementById('distatsHighlightSimpleMode');
    const advancedModeBtn = document.getElementById('distatsHighlightAdvancedMode');
    const setStartBtn = document.getElementById('distatsHighlightSetStart');
    const setEndBtn = document.getElementById('distatsHighlightSetEnd');
    const addSegmentBtn = document.getElementById('distatsHighlightAddSegment');
    const currentTimeDisplay = document.getElementById('distatsHighlightCurrentTimeValue');
    const timelineList = document.getElementById('distatsHighlightTimelineList');
    const timelineSummary = document.getElementById('distatsHighlightTimelineSummary');
    const totalDurationDisplay = document.getElementById('distatsHighlightTotalDuration');
    
    // State for timeline editor
    let timelineItems = [];
    let currentMode = 'simple';
    let pendingStartTime = null;
    let currentTimeUpdateInterval = null;
    
    // Hidden file input for images
    let imageInput = document.getElementById('distatsHighlightImageInput');
    if (!imageInput) {
      imageInput = document.createElement('input');
      imageInput.type = 'file';
      imageInput.id = 'distatsHighlightImageInput';
      imageInput.accept = 'image/*';
      imageInput.style.display = 'none';
      document.body.appendChild(imageInput);
    }
    
    // Index for where to insert image
    let pendingImageInsertIndex = -1;

    // Reset panel to initial state
    function resetPanel() {
      resetHighlightCreatorState();
      
      if (timeFramesInput) timeFramesInput.value = '';
      if (parsedPreview) parsedPreview.style.display = 'none';
      if (segmentsList) segmentsList.innerHTML = '';
      if (errorDiv) {
        errorDiv.style.display = 'none';
        errorDiv.textContent = '';
      }
      if (progressDiv) progressDiv.style.display = 'none';
      if (progressBar) progressBar.style.width = '0%';
      if (completeDiv) completeDiv.style.display = 'none';
      if (footer) footer.style.display = 'flex';
      
      // Reset disclaimer checkbox
      if (disclaimerCheckbox) {
        disclaimerCheckbox.checked = false;
      }
      
      // Reset create button (disabled until disclaimer is checked)
      if (createBtn) {
        createBtn.disabled = true;
        createBtn.style.opacity = '0.5';
        createBtn.style.cursor = 'not-allowed';
        createBtn.textContent = window.i18n ? window.i18n.t('highlights.createVideo') : 'Create Video';
      }
      
      // Reset mode to simple
      currentMode = 'simple';
      if (simpleModeBtn) {
        simpleModeBtn.classList.add('active');
        simpleModeBtn.style.background = '#21262d';
        simpleModeBtn.style.color = '#c9d1d9';
      }
      if (advancedModeBtn) {
        advancedModeBtn.classList.remove('active');
        advancedModeBtn.style.background = 'transparent';
        advancedModeBtn.style.color = '#8b949e';
      }
      if (simpleContent) simpleContent.style.display = 'block';
      if (advancedContent) advancedContent.style.display = 'none';
      
      // Reset timeline
      timelineItems = [];
      pendingStartTime = null;
      renderTimeline();
      
      // Start updating current time display
      startCurrentTimeUpdate();
    }
    
    // Update current time display
    function startCurrentTimeUpdate() {
      if (currentTimeUpdateInterval) {
        clearInterval(currentTimeUpdateInterval);
      }
      currentTimeUpdateInterval = setInterval(() => {
        const time = getCurrentVideoTime();
        if (currentTimeDisplay && time !== null) {
          currentTimeDisplay.textContent = formatSecondsToTime(time, true); // Show milliseconds
        }
      }, 100); // Update more frequently for smoother millisecond display
    }
    
    function stopCurrentTimeUpdate() {
      if (currentTimeUpdateInterval) {
        clearInterval(currentTimeUpdateInterval);
        currentTimeUpdateInterval = null;
      }
    }
    
    // Disclaimer checkbox handler
    if (disclaimerCheckbox) {
      disclaimerCheckbox.addEventListener('change', () => {
        if (createBtn) {
          if (disclaimerCheckbox.checked) {
            createBtn.disabled = false;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
          } else {
            createBtn.disabled = true;
            createBtn.style.opacity = '0.5';
            createBtn.style.cursor = 'not-allowed';
          }
        }
      });
    }
    
    // Mode toggle handlers
    function setMode(mode) {
      currentMode = mode;
      if (mode === 'simple') {
        if (simpleModeBtn) {
          simpleModeBtn.classList.add('active');
          simpleModeBtn.style.background = '#21262d';
          simpleModeBtn.style.color = '#c9d1d9';
        }
        if (advancedModeBtn) {
          advancedModeBtn.classList.remove('active');
          advancedModeBtn.style.background = 'transparent';
          advancedModeBtn.style.color = '#8b949e';
        }
        if (simpleContent) simpleContent.style.display = 'block';
        if (advancedContent) advancedContent.style.display = 'none';
        if (parsedPreview) parsedPreview.style.display = 'none';
      } else {
        if (advancedModeBtn) {
          advancedModeBtn.classList.add('active');
          advancedModeBtn.style.background = '#21262d';
          advancedModeBtn.style.color = '#c9d1d9';
        }
        if (simpleModeBtn) {
          simpleModeBtn.classList.remove('active');
          simpleModeBtn.style.background = 'transparent';
          simpleModeBtn.style.color = '#8b949e';
        }
        if (simpleContent) simpleContent.style.display = 'none';
        if (advancedContent) advancedContent.style.display = 'block';
        if (parsedPreview) parsedPreview.style.display = 'none';
        
        // Convert textarea content to timeline items if switching from simple mode
        if (timeFramesInput && timeFramesInput.value.trim()) {
          const { frames } = parseTimeFrames(timeFramesInput.value);
          if (frames.length > 0) {
            timelineItems = frames.map(f => ({
              type: 'segment',
              start: f.start,
              end: f.end,
              original: f.original
            }));
            renderTimeline();
          }
        }
      }
    }
    
    if (simpleModeBtn) {
      simpleModeBtn.addEventListener('click', () => setMode('simple'));
    }
    if (advancedModeBtn) {
      advancedModeBtn.addEventListener('click', () => setMode('advanced'));
    }
    
    // Timestamp capture buttons (Simple mode)
    if (setStartBtn) {
      setStartBtn.addEventListener('click', () => {
        const time = getCurrentVideoTime();
        if (time === null) {
          if (errorDiv) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = window.i18n ? window.i18n.t('highlights.noVideo') : 'No video found';
          }
          return;
        }
        pendingStartTime = time;
        const formattedTime = formatSecondsToTime(time, true); // Include milliseconds
        
        // Show feedback
        setStartBtn.style.background = '#238636';
        setStartBtn.style.borderColor = '#238636';
        setTimeout(() => {
          setStartBtn.style.background = '#21262d';
          setStartBtn.style.borderColor = '#30363d';
        }, 300);
        
        // If textarea is empty or ends with a complete segment, start new line
        if (timeFramesInput) {
          const value = timeFramesInput.value.trim();
          if (value === '') {
            timeFramesInput.value = formattedTime + '-';
          } else {
            // Check if last line is complete (has both start and end)
            const lines = value.split('\n');
            const lastLine = lines[lines.length - 1].trim();
            if (lastLine.includes('-') && lastLine.split('-')[1].trim() !== '') {
              timeFramesInput.value = value + '\n' + formattedTime + '-';
            } else {
              // Replace incomplete last line
              lines[lines.length - 1] = formattedTime + '-';
              timeFramesInput.value = lines.join('\n');
            }
          }
          // Scroll to bottom
          timeFramesInput.scrollTop = timeFramesInput.scrollHeight;
          // Trigger input event to update preview
          timeFramesInput.dispatchEvent(new Event('input'));
        }
      });
    }
    
    if (setEndBtn) {
      setEndBtn.addEventListener('click', () => {
        const time = getCurrentVideoTime();
        if (time === null) {
          if (errorDiv) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = window.i18n ? window.i18n.t('highlights.noVideo') : 'No video found';
          }
          return;
        }
        const formattedTime = formatSecondsToTime(time, true); // Include milliseconds
        
        // Show feedback
        setEndBtn.style.background = '#238636';
        setEndBtn.style.borderColor = '#238636';
        setTimeout(() => {
          setEndBtn.style.background = '#21262d';
          setEndBtn.style.borderColor = '#30363d';
        }, 300);
        
        if (timeFramesInput) {
          const value = timeFramesInput.value.trim();
          if (value === '') {
            // No start time set, add a default 10-second segment ending at current time
            const startTime = Math.max(0, time - 10);
            timeFramesInput.value = formatSecondsToTime(startTime, true) + '-' + formattedTime;
          } else {
            // Check if last line needs an end time
            const lines = value.split('\n');
            const lastLine = lines[lines.length - 1].trim();
            if (lastLine.endsWith('-')) {
              lines[lines.length - 1] = lastLine + formattedTime;
              timeFramesInput.value = lines.join('\n');
            } else if (!lastLine.includes('-')) {
              // Last line is just a start time, add end
              lines[lines.length - 1] = lastLine + '-' + formattedTime;
              timeFramesInput.value = lines.join('\n');
            } else {
              // Last line is complete, start new segment ending at current time
              const startTime = Math.max(0, time - 10);
              timeFramesInput.value = value + '\n' + formatSecondsToTime(startTime) + '-' + formattedTime;
            }
          }
          timeFramesInput.scrollTop = timeFramesInput.scrollHeight;
          timeFramesInput.dispatchEvent(new Event('input'));
        }
        pendingStartTime = null;
      });
    }
    
    if (addSegmentBtn) {
      addSegmentBtn.addEventListener('click', () => {
        if (timeFramesInput) {
          const value = timeFramesInput.value.trim();
          if (value !== '' && !value.endsWith('\n')) {
            timeFramesInput.value = value + '\n';
          }
          timeFramesInput.focus();
        }
      });
    }
    
    // Timeline editor functions (Advanced mode)
    function renderTimeline() {
      if (!timelineList) return;
      
      if (timelineItems.length === 0) {
        timelineList.innerHTML = `<div class="highlight-timeline-empty" style="text-align: center; padding: 50px 20px; color: #6e7681; font-size: 13px;" data-i18n="highlights.timelineEmpty">
          ${window.i18n ? window.i18n.t('highlights.timelineEmpty') : 'No items yet. Add segments in Simple Mode first, then switch here to add images.'}
        </div>`;
        if (timelineSummary) timelineSummary.style.display = 'none';
        return;
      }
      
      let html = '';
      let totalDuration = 0;
      
      timelineItems.forEach((item, index) => {
        if (item.type === 'segment') {
          const duration = item.end - item.start;
          totalDuration += duration;
          html += `
            <div class="highlight-timeline-item" data-index="${index}" draggable="true">
              <div class="highlight-timeline-item-icon segment">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polygon points="5 3 19 12 5 21 5 3"/>
                </svg>
              </div>
              <div class="highlight-timeline-item-content">
                <div class="highlight-timeline-item-title">${window.i18n ? window.i18n.t('highlights.videoSegment') : 'Video Segment'} ${index + 1}</div>
                <div class="highlight-timeline-item-details">${formatSecondsToTime(item.start, true)} → ${formatSecondsToTime(item.end, true)} (${formatSecondsToTime(duration, true)})</div>
              </div>
              <div class="highlight-timeline-item-actions">
                <button class="highlight-timeline-item-btn delete" data-action="delete" data-index="${index}" title="${window.i18n ? window.i18n.t('common.delete') : 'Delete'}">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg>
                </button>
              </div>
            </div>
            <div class="highlight-add-image-divider" data-insert-index="${index + 1}">
              <button data-action="add-image" data-insert-index="${index + 1}">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="12" y1="5" x2="12" y2="19"/>
                  <line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                ${window.i18n ? window.i18n.t('highlights.addImage') : 'Add Image'}
              </button>
            </div>
          `;
        } else if (item.type === 'image') {
          totalDuration += item.duration || 3;
          html += `
            <div class="highlight-timeline-item" data-index="${index}" draggable="true">
              <div class="highlight-timeline-item-icon image">
                <img src="${item.imageData}" alt="Image">
              </div>
              <div class="highlight-timeline-item-content">
                <div class="highlight-timeline-item-title">${window.i18n ? window.i18n.t('highlights.imageSlide') : 'Image Slide'}</div>
                <div class="highlight-timeline-item-details">${window.i18n ? window.i18n.t('highlights.duration') : 'Duration'}: ${item.duration || 3}s</div>
              </div>
              <div class="highlight-timeline-item-duration">
                <input type="number" min="1" max="30" value="${item.duration || 3}" data-action="duration" data-index="${index}" title="${window.i18n ? window.i18n.t('highlights.durationSeconds') : 'Duration (seconds)'}">
                <span style="font-size: 10px; color: #6e7681;">s</span>
              </div>
              <div class="highlight-timeline-item-actions">
                <button class="highlight-timeline-item-btn delete" data-action="delete" data-index="${index}" title="${window.i18n ? window.i18n.t('common.delete') : 'Delete'}">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg>
                </button>
              </div>
            </div>
            <div class="highlight-add-image-divider" data-insert-index="${index + 1}">
              <button data-action="add-image" data-insert-index="${index + 1}">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="12" y1="5" x2="12" y2="19"/>
                  <line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                ${window.i18n ? window.i18n.t('highlights.addImage') : 'Add Image'}
              </button>
            </div>
          `;
        } else if (item.type === 'gif') {
          totalDuration += item.duration || 3;
          const frameInfo = item.frameCount ? `${item.frameCount} ${window.i18n ? window.i18n.t('highlights.frames') : 'frames'}` : '';
          html += `
            <div class="highlight-timeline-item" data-index="${index}" draggable="true">
              <div class="highlight-timeline-item-icon gif">
                <img src="${item.imageData}" alt="GIF">
                <div class="gif-badge">GIF</div>
              </div>
              <div class="highlight-timeline-item-content">
                <div class="highlight-timeline-item-title">${window.i18n ? window.i18n.t('highlights.gifAnimation') : 'GIF Animation'}</div>
                <div class="highlight-timeline-item-details">${window.i18n ? window.i18n.t('highlights.duration') : 'Duration'}: ${item.duration || 3}s ${frameInfo ? '• ' + frameInfo : ''}</div>
              </div>
              <div class="highlight-timeline-item-duration">
                <input type="number" min="1" max="60" value="${item.duration || 3}" data-action="duration" data-index="${index}" title="${window.i18n ? window.i18n.t('highlights.durationSeconds') : 'Duration (seconds)'}">
                <span style="font-size: 10px; color: #6e7681;">s</span>
              </div>
              <div class="highlight-timeline-item-actions">
                <button class="highlight-timeline-item-btn delete" data-action="delete" data-index="${index}" title="${window.i18n ? window.i18n.t('common.delete') : 'Delete'}">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg>
                </button>
              </div>
            </div>
            <div class="highlight-add-image-divider" data-insert-index="${index + 1}">
              <button data-action="add-image" data-insert-index="${index + 1}">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="12" y1="5" x2="12" y2="19"/>
                  <line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                ${window.i18n ? window.i18n.t('highlights.addImage') : 'Add Image'}
              </button>
            </div>
          `;
        }
      });
      
      timelineList.innerHTML = html;
      
      // Update summary
      if (timelineSummary && totalDurationDisplay) {
        timelineSummary.style.display = 'block';
        totalDurationDisplay.textContent = formatSecondsToTime(totalDuration, true);
      }
      
      // Add event listeners for timeline items
      setupTimelineItemListeners();
    }
    
    function setupTimelineItemListeners() {
      if (!timelineList) return;
      
      // Delete buttons
      timelineList.querySelectorAll('[data-action="delete"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const index = parseInt(e.currentTarget.dataset.index);
          timelineItems.splice(index, 1);
          renderTimeline();
        });
      });
      
      // Duration inputs for images
      timelineList.querySelectorAll('[data-action="duration"]').forEach(input => {
        input.addEventListener('change', (e) => {
          const index = parseInt(e.target.dataset.index);
          const value = Math.max(1, Math.min(30, parseInt(e.target.value) || 3));
          timelineItems[index].duration = value;
          e.target.value = value;
          renderTimeline();
        });
      });
      
      // Add image buttons
      timelineList.querySelectorAll('[data-action="add-image"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          pendingImageInsertIndex = parseInt(e.currentTarget.dataset.insertIndex);
          imageInput.click();
        });
      });
      
      // Drag and drop
      const items = timelineList.querySelectorAll('.highlight-timeline-item');
      items.forEach(item => {
        item.addEventListener('dragstart', handleDragStart);
        item.addEventListener('dragend', handleDragEnd);
        item.addEventListener('dragover', handleDragOver);
        item.addEventListener('drop', handleDrop);
        item.addEventListener('dragleave', handleDragLeave);
      });
    }
    
    let draggedIndex = null;
    
    function handleDragStart(e) {
      draggedIndex = parseInt(e.target.dataset.index);
      e.target.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    }
    
    function handleDragEnd(e) {
      e.target.classList.remove('dragging');
      draggedIndex = null;
    }
    
    function handleDragOver(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      e.currentTarget.classList.add('drag-over');
    }
    
    function handleDragLeave(e) {
      e.currentTarget.classList.remove('drag-over');
    }
    
    function handleDrop(e) {
      e.preventDefault();
      e.currentTarget.classList.remove('drag-over');
      
      const targetIndex = parseInt(e.currentTarget.dataset.index);
      if (draggedIndex !== null && draggedIndex !== targetIndex) {
        const item = timelineItems.splice(draggedIndex, 1)[0];
        timelineItems.splice(targetIndex, 0, item);
        renderTimeline();
      }
    }
    
    // Image file input handler
    if (imageInput) {
      imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        try {
          // Check if this is an animated GIF
          const isGif = await isAnimatedGif(file);
          
          const reader = new FileReader();
          reader.onload = async (event) => {
            const imageData = event.target.result;
            let newItem;
            
            if (isGif) {
              // Animated GIF detected - get frame count for display
              try {
                // Fetch frame delays to get frame count (lightweight operation)
                const response = await fetch(imageData);
                const arrayBuffer = await response.arrayBuffer();
                const data = new Uint8Array(arrayBuffer);
                const frameDelays = extractGifDelays(data);
                const frameCount = frameDelays.length;
                
                if (frameCount > 1) {
                  // Calculate natural GIF duration from frame delays
                  const naturalDuration = frameDelays.reduce((sum, d) => sum + d, 0) / 1000;
                  
                  newItem = {
                    type: 'gif',
                    imageData: imageData,
                    duration: Math.max(3, Math.ceil(naturalDuration)), // At least 3 seconds or natural duration
                    frameCount: frameCount,
                    naturalDuration: naturalDuration
                  };
                } else {
                  // Single frame GIF, treat as image
                  newItem = {
                    type: 'image',
                    imageData: imageData,
                    duration: 3
                  };
                }
              } catch (gifError) {
                console.error('Error processing GIF:', gifError);
                // Fallback to treating as animated GIF anyway
                newItem = {
                  type: 'gif',
                  imageData: imageData,
                  duration: 3
                };
              }
            } else {
              // Regular image
              newItem = {
                type: 'image',
                imageData: imageData,
                duration: 3
              };
            }
            
            if (pendingImageInsertIndex >= 0 && pendingImageInsertIndex <= timelineItems.length) {
              timelineItems.splice(pendingImageInsertIndex, 0, newItem);
            } else {
              timelineItems.push(newItem);
            }
            pendingImageInsertIndex = -1;
            renderTimeline();
          };
          reader.readAsDataURL(file);
        } catch (error) {
          console.error('Error processing file:', error);
        }
        e.target.value = ''; // Reset input
      });
    }

    // Open panel
    openBtn.addEventListener('click', () => {
      const isHidden = panel.classList.contains('hidden');
      if (isHidden) {
        resetPanel();
        panel.classList.remove('hidden');
        // Center the panel on open
        panel.style.left = '50%';
        panel.style.top = '50%';
        panel.style.transform = 'translate(-50%, -50%)';
        startCurrentTimeUpdate();
      } else {
        panel.classList.add('hidden');
        stopCurrentTimeUpdate();
      }
    });

    // Close panel
    const closePanel = () => {
      if (highlightCreatorState.isRecording) {
        cancelHighlightRecording();
      }
      panel.classList.add('hidden');
      stopCurrentTimeUpdate();
      resetPanel();
    };

    if (closeBtn) closeBtn.addEventListener('click', closePanel);
    if (cancelBtn) cancelBtn.addEventListener('click', closePanel);

    // Minimize panel
    if (minimizeBtn) {
      minimizeBtn.addEventListener('click', () => {
        panel.classList.toggle('minimized');
        minimizeBtn.textContent = panel.classList.contains('minimized') ? '+' : '−';
      });
    }

    // Update preview when input changes
    if (timeFramesInput) {
      timeFramesInput.addEventListener('input', () => {
        const input = timeFramesInput.value;
        const { frames, errors } = parseTimeFrames(input);

        if (frames.length > 0) {
          parsedPreview.style.display = 'block';
          
          let html = '';
          frames.forEach((frame, index) => {
            const duration = frame.end - frame.start;
            html += `<div style="display: flex; justify-content: space-between; padding: 3px 0; border-bottom: 1px solid #21262d; font-size: 11px;">
              <span>${index + 1}. ${formatSecondsToTime(frame.start, true)} → ${formatSecondsToTime(frame.end, true)}</span>
              <span style="color: #8b949e;">${formatSecondsToTime(duration, true)}</span>
            </div>`;
          });
          
          const totalDuration = frames.reduce((sum, f) => sum + (f.end - f.start), 0);
          html += `<div style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #30363d; font-weight: 500; font-size: 11px;">
            <span>${window.i18n ? window.i18n.t('highlights.totalSegments') : 'Total'}: ${frames.length}</span>
            <span style="float: right;">${formatSecondsToTime(totalDuration, true)}</span>
          </div>`;
          
          segmentsList.innerHTML = html;
          errorDiv.style.display = 'none';
        } else {
          parsedPreview.style.display = 'none';
        }

        if (errors.length > 0) {
          // Check if errors are just incomplete entries (waiting for end time)
          const incompleteEntries = errors.filter(e => e.endsWith('-') || (e.includes('-') && e.split('-')[1].trim() === ''));
          const realErrors = errors.filter(e => !e.endsWith('-') && !(e.includes('-') && e.split('-')[1].trim() === ''));
          
          if (incompleteEntries.length > 0 && realErrors.length === 0) {
            // Only incomplete entries - show helpful hint, not an error
            errorDiv.style.display = 'block';
            errorDiv.style.background = 'rgba(88, 166, 255, 0.1)';
            errorDiv.style.color = '#58a6ff';
            errorDiv.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 6px;"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>${window.i18n ? window.i18n.t('highlights.addEndTime') : 'Now add the end time by clicking "Set End" or typing it manually'}`;
          } else if (realErrors.length > 0) {
            // Real errors - show as error
            errorDiv.style.display = 'block';
            errorDiv.style.background = 'rgba(218, 54, 51, 0.1)';
            errorDiv.style.color = '#da3633';
            const needsRange = realErrors.some(e => !e.includes('-'));
            if (needsRange) {
              errorDiv.innerHTML = `<strong>${window.i18n ? window.i18n.t('highlights.invalidFormats') : 'Invalid'}:</strong> "${realErrors.join('", "')}"<br><span style="font-size: 10px;">${window.i18n ? window.i18n.t('highlights.formatHint') : 'Format: START-END (e.g., 1:30-2:45)'}</span>`;
            } else {
              errorDiv.innerHTML = `<strong>${window.i18n ? window.i18n.t('highlights.invalidFormats') : 'Invalid formats'}:</strong><br>${realErrors.map(e => `"${e}"`).join(', ')}`;
            }
          } else {
            errorDiv.style.display = 'none';
          }
        } else if (frames.length === 0 && input.trim()) {
          // Check if input is just waiting for end time
          const trimmedInput = input.trim();
          if (trimmedInput.endsWith('-')) {
            errorDiv.style.display = 'block';
            errorDiv.style.background = 'rgba(88, 166, 255, 0.1)';
            errorDiv.style.color = '#58a6ff';
            errorDiv.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 6px;"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>${window.i18n ? window.i18n.t('highlights.addEndTime') : 'Now add the end time by clicking "Set End" or typing it manually'}`;
          } else {
            errorDiv.style.display = 'block';
            errorDiv.style.background = 'rgba(218, 54, 51, 0.1)';
            errorDiv.style.color = '#da3633';
            errorDiv.innerHTML = `${window.i18n ? window.i18n.t('highlights.noValidFrames') : 'No valid time frames found.'}<br><span style="font-size: 10px;">${window.i18n ? window.i18n.t('highlights.formatHint') : 'Format: START-END (e.g., 1:30-2:45)'}</span>`;
          }
        } else {
          errorDiv.style.display = 'none';
        }
      });
    }

    // Create video button
    if (createBtn) {
      createBtn.addEventListener('click', async () => {
        // Check disclaimer
        if (disclaimerCheckbox && !disclaimerCheckbox.checked) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = window.i18n ? window.i18n.t('highlights.pleaseAcceptDisclaimer') : 'Please accept the disclaimer to continue';
          return;
        }
        
        let itemsToProcess = [];
        
        if (currentMode === 'advanced') {
          // Use timeline items
          if (timelineItems.length === 0) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = window.i18n ? window.i18n.t('highlights.noItemsInTimeline') : 'Please add at least one item to the timeline';
            return;
          }
          itemsToProcess = [...timelineItems];
        } else {
          // Simple mode - parse from textarea
          const input = timeFramesInput.value;
          const { frames, errors } = parseTimeFrames(input);

          if (frames.length === 0) {
            errorDiv.style.display = 'block';
            errorDiv.innerHTML = `${window.i18n ? window.i18n.t('highlights.enterTimeFrames') : 'Please enter at least one valid time frame'}<br><span style="font-size: 10px;">${window.i18n ? window.i18n.t('highlights.formatHint') : 'Format: START-END (e.g., 1:30-2:45)'}</span>`;
            return;
          }
          
          // Convert frames to timeline items format
          itemsToProcess = frames.map(f => ({
            type: 'segment',
            start: f.start,
            end: f.end,
            original: f.original
          }));
        }

        // Get video duration for validation
        const video = document.querySelector('video');
        if (!video) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = window.i18n ? window.i18n.t('highlights.noVideo') : 'No video found on this page';
          return;
        }

        const videoDuration = video.duration;
        
        // Validate segment items
        const segmentItems = itemsToProcess.filter(item => item.type === 'segment');
        const segmentFrames = segmentItems.map(item => ({ start: item.start, end: item.end, original: item.original }));
        const { validFrames, invalidFrames } = validateTimeFrames(segmentFrames, videoDuration);

        // Check if we have any valid segments (images and GIFs don't need video validation)
        const hasImages = itemsToProcess.some(item => item.type === 'image' || item.type === 'gif');
        if (validFrames.length === 0 && !hasImages) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = window.i18n ? window.i18n.t('highlights.allFramesInvalid') : 'All time frames exceed video duration';
          return;
        }

        if (invalidFrames.length > 0) {
          const skipped = invalidFrames.map(f => f.original).join(', ');
          console.warn('Skipping invalid time frames:', skipped);
        }
        
        // Build final items list with validated segments
        const validOriginals = new Set(validFrames.map(f => f.original));
        const finalItems = itemsToProcess.filter(item => {
          if (item.type === 'image' || item.type === 'gif') return true;
          return validOriginals.has(item.original);
        });

        // Start recording
        errorDiv.style.display = 'none';
        progressDiv.style.display = 'block';
        createBtn.disabled = true;
        createBtn.textContent = window.i18n ? window.i18n.t('highlights.recording') : 'Recording...';

        try {
          // Use enhanced video creation with images support
          const blob = await createHighlightVideoWithImages(finalItems, (progress) => {
            if (progress.type === 'item_start') {
              progressCount.textContent = `${progress.current} / ${progress.total}`;
              progressBar.style.width = `${((progress.current - 1) / progress.total) * 100}%`;
              if (progress.item.type === 'segment') {
                currentSegmentDiv.textContent = `${window.i18n ? window.i18n.t('highlights.recordingSegment') : 'Recording'}: ${formatSecondsToTime(progress.item.start, true)} → ${formatSecondsToTime(progress.item.end, true)}`;
              } else if (progress.item.type === 'gif') {
                currentSegmentDiv.textContent = `${window.i18n ? window.i18n.t('highlights.renderingGif') : 'Rendering GIF animation'}...`;
              } else {
                currentSegmentDiv.textContent = `${window.i18n ? window.i18n.t('highlights.renderingImage') : 'Rendering image'}...`;
              }
            } else if (progress.type === 'item_complete') {
              progressBar.style.width = `${(progress.current / progress.total) * 100}%`;
            }
          });

          // Show completion UI
          progressDiv.style.display = 'none';
          footer.style.display = 'none';
          completeDiv.style.display = 'block';

          // Store blob for download
          highlightCreatorState.videoBlob = blob;

          // Show only the button for the format that was actually recorded
          const isMP4 = highlightCreatorState.mimeType && highlightCreatorState.mimeType.includes('mp4');
          
          if (isMP4) {
            // Recorded in MP4 (Safari) - show only MP4 button
            if (downloadMp4Btn) {
              downloadMp4Btn.style.display = 'inline-flex';
              downloadMp4Btn.style.background = '#238636';
              downloadMp4Btn.style.borderColor = '#238636';
              downloadMp4Btn.style.color = 'white';
            }
            if (downloadWebmBtn) {
              downloadWebmBtn.style.display = 'none';
            }
            if (formatNote) {
              formatNote.textContent = window.i18n ? window.i18n.t('highlights.recordedMp4Note') : 'Recorded in MP4 format';
            }
          } else {
            // Recorded in WebM (Chrome/Firefox) - show only WebM button
            if (downloadWebmBtn) {
              downloadWebmBtn.style.display = 'inline-flex';
              downloadWebmBtn.style.background = '#238636';
              downloadWebmBtn.style.borderColor = '#238636';
              downloadWebmBtn.style.color = 'white';
            }
            if (downloadMp4Btn) {
              downloadMp4Btn.style.display = 'none';
            }
            if (formatNote) {
              formatNote.textContent = window.i18n ? window.i18n.t('highlights.recordedWebmNote') : 'WebM format - opens with VLC, Chrome, or Firefox';
            }
          }

        } catch (error) {
          console.error('Highlight creation error:', error);
          errorDiv.style.display = 'block';
          errorDiv.textContent = error.message || (window.i18n ? window.i18n.t('highlights.recordingFailed') : 'Failed to create highlight video');
          progressDiv.style.display = 'none';
          createBtn.disabled = false;
          createBtn.textContent = window.i18n ? window.i18n.t('highlights.createVideo') : 'Create Video';
        }
      });
    }

    // Download MP4 button
    if (downloadMp4Btn) {
      downloadMp4Btn.addEventListener('click', () => {
        if (highlightCreatorState.videoBlob) {
          const now = new Date();
          const timestamp = `${now.getFullYear()}${(now.getMonth()+1).toString().padStart(2,'0')}${now.getDate().toString().padStart(2,'0')}_${now.getHours().toString().padStart(2,'0')}${now.getMinutes().toString().padStart(2,'0')}`;
          downloadHighlightVideo(highlightCreatorState.videoBlob, `highlights_${timestamp}.mp4`);
        }
      });
    }

    // Download WebM button
    if (downloadWebmBtn) {
      downloadWebmBtn.addEventListener('click', () => {
        if (highlightCreatorState.videoBlob) {
          const now = new Date();
          const timestamp = `${now.getFullYear()}${(now.getMonth()+1).toString().padStart(2,'0')}${now.getDate().toString().padStart(2,'0')}_${now.getHours().toString().padStart(2,'0')}${now.getMinutes().toString().padStart(2,'0')}`;
          downloadHighlightVideo(highlightCreatorState.videoBlob, `highlights_${timestamp}.webm`);
        }
      });
    }
  }

  // ========== END HIGHLIGHT CREATOR FUNCTIONS ==========

  // Start initialization
  initialize();

})();

