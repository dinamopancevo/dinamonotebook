// Export Preview Modal
// Provides preview and editing capabilities before exporting notes to PDF/HTML

const ExportPreview = (function() {
  'use strict';

  // State
  let modal = null;
  let currentFormat = 'pdf';
  let currentProjectData = null;
  let editedNotes = [];
  let excludedNoteIds = new Set();
  let selectedNoteIndex = -1;
  let zoomLevel = 100;
  let previewIframe = null;
  let isGenerating = false;
  let markedNoteTimestamps = []; // Timestamps of notes marked in chat
  let exportScope = 'all'; // 'all' or 'marked'

  // Options
  let pdfOptions = {
    pageSize: 'a4',
    orientation: 'portrait',
    includeMetadata: true,
    includeTimelineMarkers: true
  };

  let htmlOptions = {
    theme: 'dark',
    animationSpeed: 1.0,
    autoPlayAnimations: false,
    includeInteractiveControls: true
  };

  /**
   * Create the modal HTML structure
   */
  function createModalHTML() {
    return `
    <div class="export-preview-modal" id="exportPreviewModal">
      <div class="export-preview-container">
        <!-- Header -->
        <div class="export-preview-header">
          <span class="export-preview-title">Export Notes</span>
          <button class="export-preview-close" id="exportPreviewClose">&times;</button>
        </div>

        <!-- Format Selector -->
        <div class="export-format-selector">
          <button class="format-btn active" data-format="pdf" id="formatPdfBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 6px; vertical-align: middle;">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="16" y1="13" x2="8" y2="13"/>
              <line x1="16" y1="17" x2="8" y2="17"/>
              <polyline points="10 9 9 9 8 9"/>
            </svg>
            PDF
          </button>
          <button class="format-btn" data-format="html" id="formatHtmlBtn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 6px; vertical-align: middle;">
              <polyline points="16 18 22 12 16 6"/>
              <polyline points="8 6 2 12 8 18"/>
            </svg>
            HTML
          </button>
          
          <div class="export-scope-selector">
            <label for="exportScopeSelect" data-i18n="export.scope">Notes:</label>
            <select id="exportScopeSelect">
              <option value="all" data-i18n="export.allNotes">All notes in project</option>
              <option value="marked" data-i18n="export.markedNotes">Marked notes only</option>
            </select>
          </div>
          
          <div class="format-options" id="pdfOptions">
            <div class="format-option">
              <label for="exportPageSize">Page:</label>
              <select id="exportPageSize">
                <option value="a4">A4</option>
                <option value="letter">Letter</option>
                <option value="a3">A3</option>
              </select>
            </div>
            <div class="format-option">
              <label for="exportOrientation">Orientation:</label>
              <select id="exportOrientation">
                <option value="portrait">Portrait</option>
                <option value="landscape">Landscape</option>
              </select>
            </div>
            <div class="format-option">
              <input type="checkbox" id="exportIncludeMetadata" checked>
              <label for="exportIncludeMetadata" title="Includes: Team names, Events (Goal, Corner, etc.), Zones, and Timeline markers">Include metadata (Teams, Events, Zones)</label>
            </div>
          </div>
          
          <div class="format-options" id="htmlOptions" style="display: none;">
            <div class="format-option">
              <label for="exportTheme">Theme:</label>
              <select id="exportTheme">
                <option value="dark">Dark</option>
                <option value="light">Light</option>
              </select>
            </div>
            <div class="format-option">
              <input type="checkbox" id="exportAutoPlay">
              <label for="exportAutoPlay">Auto-play animations</label>
            </div>
            <div class="format-option">
              <input type="checkbox" id="exportInteractiveControls" checked>
              <label for="exportInteractiveControls">Interactive controls</label>
            </div>
          </div>
        </div>

        <!-- Main Content -->
        <div class="export-preview-content">
          <!-- Left Panel - Note List -->
          <div class="export-notes-panel">
            <div class="export-notes-header">
              <span class="export-notes-title">Notes (<span id="exportNoteCount">0</span>)</span>
              <div class="export-notes-actions">
                <button class="export-action-btn" id="selectAllNotesBtn" title="Select all">All</button>
                <button class="export-action-btn" id="deselectAllNotesBtn" title="Deselect all">None</button>
              </div>
            </div>
            <div class="export-notes-list" id="exportNotesList">
              <!-- Notes will be rendered here -->
            </div>
          </div>

          <!-- Right Panel - Preview -->
          <div class="export-preview-panel">
            <div class="export-preview-toolbar">
              <div class="preview-zoom-controls">
                <button class="zoom-btn" id="zoomOutBtn">-</button>
                <span class="zoom-level" id="zoomLevel">100%</span>
                <button class="zoom-btn" id="zoomInBtn">+</button>
                <button class="zoom-btn" id="zoomResetBtn">Reset</button>
              </div>
              <div class="preview-page-info" id="previewPageInfo">
                <!-- Page info will be shown here -->
              </div>
            </div>
            <div class="export-preview-iframe-container" id="previewContainer">
              <iframe id="exportPreviewIframe" class="export-preview-iframe"></iframe>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="export-preview-footer">
          <div class="export-stats" id="exportStats">
            <!-- Stats will be shown here -->
          </div>
          <div class="export-actions">
            <button class="export-cancel-btn" id="exportCancelBtn">Cancel</button>
            <button class="export-download-btn" id="exportDownloadBtn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
              </svg>
              Download
            </button>
          </div>
        </div>

        <!-- Loading Overlay -->
        <div class="export-loading" id="exportLoading" style="display: none;">
          <div class="export-loading-spinner"></div>
          <div class="export-loading-text" id="exportLoadingText">Generating preview...</div>
        </div>
      </div>
    </div>
    `;
  }

  /**
   * Initialize the modal
   */
  function init() {
    if (modal) return;

    // Inject CSS if not already present
    if (!document.getElementById('exportPreviewStyles')) {
      const link = document.createElement('link');
      link.id = 'exportPreviewStyles';
      link.rel = 'stylesheet';
      link.href = typeof chrome !== 'undefined' && chrome.runtime 
        ? chrome.runtime.getURL('export-preview.css')
        : 'export-preview.css';
      document.head.appendChild(link);
    }

    // Create modal element
    const container = document.createElement('div');
    container.innerHTML = createModalHTML();
    modal = container.firstElementChild;
    document.body.appendChild(modal);

    // Cache elements
    previewIframe = document.getElementById('exportPreviewIframe');

    // Bind events
    bindEvents();
  }

  /**
   * Bind event handlers
   */
  function bindEvents() {
    // Close button
    document.getElementById('exportPreviewClose').addEventListener('click', close);
    document.getElementById('exportCancelBtn').addEventListener('click', close);

    // Modal stays open - close only via X or explicit buttons (not on outside click)

    // Escape key to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.classList.contains('visible')) {
        close();
      }
    });

    // Format buttons
    document.getElementById('formatPdfBtn').addEventListener('click', () => setFormat('pdf'));
    document.getElementById('formatHtmlBtn').addEventListener('click', () => setFormat('html'));

    // Scope selector
    document.getElementById('exportScopeSelect').addEventListener('change', (e) => {
      setScope(e.target.value);
    });

    // PDF Options
    document.getElementById('exportPageSize').addEventListener('change', (e) => {
      pdfOptions.pageSize = e.target.value;
      updatePreview();
    });
    document.getElementById('exportOrientation').addEventListener('change', (e) => {
      pdfOptions.orientation = e.target.value;
      updatePreview();
    });
    document.getElementById('exportIncludeMetadata').addEventListener('change', (e) => {
      pdfOptions.includeMetadata = e.target.checked;
      updatePreview();
    });

    // HTML Options
    document.getElementById('exportTheme').addEventListener('change', (e) => {
      htmlOptions.theme = e.target.value;
      updatePreview();
    });
    document.getElementById('exportAutoPlay').addEventListener('change', (e) => {
      htmlOptions.autoPlayAnimations = e.target.checked;
      updatePreview();
    });
    document.getElementById('exportInteractiveControls').addEventListener('change', (e) => {
      htmlOptions.includeInteractiveControls = e.target.checked;
      updatePreview();
    });

    // Zoom controls
    document.getElementById('zoomInBtn').addEventListener('click', () => setZoom(zoomLevel + 25));
    document.getElementById('zoomOutBtn').addEventListener('click', () => setZoom(zoomLevel - 25));
    document.getElementById('zoomResetBtn').addEventListener('click', () => setZoom(100));

    // Select/deselect all
    document.getElementById('selectAllNotesBtn').addEventListener('click', selectAllNotes);
    document.getElementById('deselectAllNotesBtn').addEventListener('click', deselectAllNotes);

    // Download button
    document.getElementById('exportDownloadBtn').addEventListener('click', downloadExport);
  }

  /**
   * Collect marked note timestamps from chat
   */
  function collectMarkedTimestamps() {
    // Try sidebar checkboxes first, then popup checkboxes
    let checkboxes = document.querySelectorAll('.distats-message-mark-checkbox:checked');
    if (checkboxes.length === 0) {
      checkboxes = document.querySelectorAll('.message-mark-checkbox:checked');
    }
    
    return Array.from(checkboxes).map(cb => cb.dataset.noteTimestamp).filter(Boolean);
  }

  /**
   * Set export scope
   */
  function setScope(scope) {
    exportScope = scope;
    
    // Filter notes based on scope
    if (scope === 'marked' && markedNoteTimestamps.length > 0) {
      // Exclude notes that are not in markedNoteTimestamps
      excludedNoteIds.clear();
      editedNotes.forEach((note, index) => {
        const noteTimestamp = String(note.timestamp || note.createdAt || '');
        if (!markedNoteTimestamps.includes(noteTimestamp)) {
          excludedNoteIds.add(index);
        }
      });
    } else if (scope === 'all') {
      // Include all notes
      excludedNoteIds.clear();
    }
    
    // Update UI
    renderNotesList();
    updateStats();
    updatePreview();
  }

  /**
   * Open the export preview modal
   * @param {string} analysisId - Project ID to export
   */
  async function open(analysisId) {
    init();

    // Show modal
    modal.classList.add('visible');
    showLoading('Loading project data...');

    try {
      // Collect marked timestamps from chat BEFORE loading data
      markedNoteTimestamps = collectMarkedTimestamps();
      
      // Update scope selector state
      const scopeSelect = document.getElementById('exportScopeSelect');
      if (scopeSelect) {
        // If there are marked notes, default to 'marked' scope
        if (markedNoteTimestamps.length > 0) {
          scopeSelect.value = 'marked';
          exportScope = 'marked';
        } else {
          scopeSelect.value = 'all';
          exportScope = 'all';
        }
        
        // Disable 'marked' option if no notes are marked
        const markedOption = scopeSelect.querySelector('option[value="marked"]');
        if (markedOption) {
          if (markedNoteTimestamps.length === 0) {
            markedOption.disabled = true;
            markedOption.textContent = (markedOption.textContent || 'Marked notes only') + ' (none marked)';
          } else {
            markedOption.disabled = false;
            markedOption.textContent = `Marked notes only (${markedNoteTimestamps.length})`;
          }
        }
      }
      
      // Load project data
      currentProjectData = await ExportGenerator.collectProjectData(analysisId);
      
      // Initialize edited notes from original
      editedNotes = JSON.parse(JSON.stringify(currentProjectData.notes || []));
      excludedNoteIds.clear();
      selectedNoteIndex = -1;
      
      // Apply initial scope filtering
      if (exportScope === 'marked' && markedNoteTimestamps.length > 0) {
        editedNotes.forEach((note, index) => {
          const noteTimestamp = String(note.timestamp || note.createdAt || '');
          if (!markedNoteTimestamps.includes(noteTimestamp)) {
            excludedNoteIds.add(index);
          }
        });
      }

      // Render notes list
      renderNotesList();

      // Update stats
      updateStats();

      // Generate initial preview
      await updatePreview();

      hideLoading();
    } catch (error) {
      console.error('Error loading project data:', error);
      hideLoading();
      alert('Error loading project: ' + error.message);
      close();
    }
  }

  /**
   * Close the modal
   */
  function close() {
    if (modal) {
      modal.classList.remove('visible');
    }
    currentProjectData = null;
    editedNotes = [];
    excludedNoteIds.clear();
    selectedNoteIndex = -1;
    markedNoteTimestamps = [];
    exportScope = 'all';
  }

  /**
   * Set export format
   */
  function setFormat(format) {
    currentFormat = format;
    
    // Update button states
    document.getElementById('formatPdfBtn').classList.toggle('active', format === 'pdf');
    document.getElementById('formatHtmlBtn').classList.toggle('active', format === 'html');
    
    // Show/hide options
    document.getElementById('pdfOptions').style.display = format === 'pdf' ? 'flex' : 'none';
    document.getElementById('htmlOptions').style.display = format === 'html' ? 'flex' : 'none';

    // Update preview
    updatePreview();
  }

  /**
   * Set zoom level
   */
  function setZoom(level) {
    zoomLevel = Math.min(Math.max(level, 25), 200);
    document.getElementById('zoomLevel').textContent = zoomLevel + '%';
    
    if (previewIframe) {
      previewIframe.style.transform = `scale(${zoomLevel / 100})`;
      previewIframe.style.width = `${100 / (zoomLevel / 100)}%`;
      previewIframe.style.height = `${100 / (zoomLevel / 100)}%`;
    }
  }

  /**
   * Render the notes list
   */
  function renderNotesList() {
    const container = document.getElementById('exportNotesList');
    const countEl = document.getElementById('exportNoteCount');
    
    const includedCount = editedNotes.filter((_, i) => !excludedNoteIds.has(i)).length;
    countEl.textContent = `${includedCount}/${editedNotes.length}`;

    container.innerHTML = editedNotes.map((note, index) => {
      const isExcluded = excludedNoteIds.has(index);
      const isSelected = selectedNoteIndex === index;
      const timecode = note.videoTime ? formatTimecode(note.videoTime) : '';
      const text = (note.text || note.content || '').replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
      
      // Check if this note is marked in chat
      const noteTimestamp = String(note.timestamp || note.createdAt || '');
      const isMarkedInChat = markedNoteTimestamps.includes(noteTimestamp);
      
      // Count images and schemes
      let imageCount = 0;
      let schemeCount = 0;
      if (note.images && Array.isArray(note.images)) {
        note.images.forEach(img => {
          if (typeof img === 'object' && img.slidesData) {
            schemeCount++;
          } else {
            imageCount++;
          }
        });
      } else if (note.image) {
        imageCount = 1;
      }

      // Metadata tags
      const tags = [];
      if (note.team || (note.teams && note.teams.length > 0)) {
        tags.push(note.team || note.teams[0]);
      }
      if (note.events && note.events.length > 0) {
        tags.push(...note.events.slice(0, 2));
      }

      return `
        <div class="export-note-item ${isExcluded ? 'excluded' : ''} ${isSelected ? 'selected' : ''} ${isMarkedInChat ? 'marked-in-chat' : ''}" 
             data-index="${index}"
             draggable="true">
          <div class="export-note-header">
            <div class="export-note-info">
              <span class="export-note-number">Note ${index + 1}</span>
              ${isMarkedInChat ? '<span class="export-note-marked-badge" title="Marked in chat">&#9733;</span>' : ''}
              ${timecode ? `<span class="export-note-timecode">${escapeHtml(timecode)}</span>` : ''}
            </div>
            <div class="export-note-controls" draggable="false">
              <button class="export-note-btn edit-btn" data-index="${index}" title="Edit" draggable="false">&#9998;</button>
              <label class="export-checkbox-label" draggable="false">
                <input type="checkbox" 
                       class="export-note-checkbox" 
                       data-index="${index}"
                       ${isExcluded ? '' : 'checked'}
                       title="${isExcluded ? 'Click to include' : 'Click to exclude'}"
                       draggable="false">
              </label>
            </div>
          </div>
          <div class="export-note-text" id="noteText-${index}">${escapeHtml(text) || '(No text)'}</div>
          ${tags.length > 0 ? `
            <div class="export-note-meta">
              ${tags.map(t => `<span class="export-note-tag">${escapeHtml(t)}</span>`).join('')}
            </div>
          ` : ''}
          ${schemeCount > 0 ? `<span class="export-scheme-badge">${schemeCount} scheme(s)</span>` : ''}
          ${imageCount > 0 ? `<span class="export-scheme-badge" style="background: #0366d6;">${imageCount} image(s)</span>` : ''}
        </div>
      `;
    }).join('');

    // Bind note item events
    container.querySelectorAll('.export-note-item').forEach(item => {
      const index = parseInt(item.dataset.index);

      // Click to select
      item.addEventListener('click', (e) => {
        if (!e.target.closest('.export-note-btn')) {
          selectNote(index);
        }
      });

      // Drag and drop
      item.addEventListener('dragstart', (e) => handleDragStart(e, index));
      item.addEventListener('dragover', handleDragOver);
      item.addEventListener('dragleave', handleDragLeave);
      item.addEventListener('drop', (e) => handleDrop(e, index));
      item.addEventListener('dragend', handleDragEnd);
    });

    // Bind button events
    container.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        startEditingNote(parseInt(btn.dataset.index));
      });
    });

    container.querySelectorAll('.export-note-checkbox').forEach(checkbox => {
      checkbox.addEventListener('click', (e) => {
        e.stopPropagation();
      });
      checkbox.addEventListener('change', (e) => {
        const index = parseInt(checkbox.dataset.index);
        const noteItem = checkbox.closest('.export-note-item');
        
        // If checked, remove from excluded; if unchecked, add to excluded
        if (checkbox.checked) {
          excludedNoteIds.delete(index);
          if (noteItem) noteItem.classList.remove('excluded');
        } else {
          excludedNoteIds.add(index);
          if (noteItem) noteItem.classList.add('excluded');
        }
        updateStats();
        updatePreview();
      });
    });
  }

  /**
   * Format timecode
   */
  function formatTimecode(seconds) {
    if (!seconds && seconds !== 0) return '';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `[${mins}:${String(secs).padStart(2, '0')}]`;
  }

  /**
   * Escape HTML
   */
  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Select a note
   */
  function selectNote(index) {
    selectedNoteIndex = index;
    renderNotesList();
  }

  /**
   * Start editing a note
   */
  function startEditingNote(index) {
    const textEl = document.getElementById(`noteText-${index}`);
    if (!textEl) return;

    const note = editedNotes[index];
    const currentText = (note.text || note.content || '').replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');

    textEl.innerHTML = `
      <textarea class="export-note-textarea" id="noteTextarea-${index}">${escapeHtml(currentText)}</textarea>
      <div style="margin-top: 8px; display: flex; gap: 8px;">
        <button class="export-action-btn save-edit-btn" data-index="${index}">Save</button>
        <button class="export-action-btn cancel-edit-btn" data-index="${index}">Cancel</button>
      </div>
    `;

    const textarea = document.getElementById(`noteTextarea-${index}`);
    textarea.focus();
    textarea.select();

    // Bind save/cancel
    textEl.querySelector('.save-edit-btn').addEventListener('click', () => saveNoteEdit(index));
    textEl.querySelector('.cancel-edit-btn').addEventListener('click', () => renderNotesList());
  }

  /**
   * Save note edit
   */
  function saveNoteEdit(index) {
    const textarea = document.getElementById(`noteTextarea-${index}`);
    if (!textarea) return;

    const newText = textarea.value;
    const note = editedNotes[index];
    
    // Preserve timecode if present
    const timecodeMatch = (note.text || note.content || '').match(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/);
    const timecode = timecodeMatch ? timecodeMatch[0] : '';
    
    note.text = timecode + newText;
    note.content = timecode + newText;

    renderNotesList();
    updatePreview();
  }

  /**
   * Toggle note exclusion
   */
  function toggleNoteExclusion(index) {
    if (excludedNoteIds.has(index)) {
      excludedNoteIds.delete(index);
    } else {
      excludedNoteIds.add(index);
    }
    renderNotesList();
    updateStats();
    updatePreview();
  }

  /**
   * Select all notes
   */
  function selectAllNotes() {
    excludedNoteIds.clear();
    
    // If in marked scope, also switch to all scope
    const scopeSelect = document.getElementById('exportScopeSelect');
    if (scopeSelect && scopeSelect.value === 'marked') {
      scopeSelect.value = 'all';
      exportScope = 'all';
    }
    
    renderNotesList();
    updateStats();
    updatePreview();
  }

  /**
   * Deselect all notes
   */
  function deselectAllNotes() {
    editedNotes.forEach((_, i) => excludedNoteIds.add(i));
    renderNotesList();
    updateStats();
    updatePreview();
  }

  // Drag and drop handlers
  let draggedIndex = null;

  function handleDragStart(e, index) {
    draggedIndex = index;
    e.currentTarget.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
  }

  function handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.classList.add('drag-over');
  }

  function handleDragLeave(e) {
    e.currentTarget.classList.remove('drag-over');
  }

  function handleDrop(e, targetIndex) {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    
    if (draggedIndex !== null && draggedIndex !== targetIndex) {
      // Reorder notes
      const [movedNote] = editedNotes.splice(draggedIndex, 1);
      editedNotes.splice(targetIndex, 0, movedNote);
      
      // Update excluded indices
      const newExcluded = new Set();
      excludedNoteIds.forEach(idx => {
        if (idx === draggedIndex) {
          newExcluded.add(targetIndex);
        } else if (draggedIndex < targetIndex) {
          if (idx > draggedIndex && idx <= targetIndex) {
            newExcluded.add(idx - 1);
          } else {
            newExcluded.add(idx);
          }
        } else {
          if (idx >= targetIndex && idx < draggedIndex) {
            newExcluded.add(idx + 1);
          } else {
            newExcluded.add(idx);
          }
        }
      });
      excludedNoteIds = newExcluded;
      
      renderNotesList();
      updatePreview();
    }
    
    draggedIndex = null;
  }

  function handleDragEnd(e) {
    e.currentTarget.classList.remove('dragging');
    document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
    draggedIndex = null;
  }

  /**
   * Update statistics display
   */
  function updateStats() {
    const statsEl = document.getElementById('exportStats');
    const includedNotes = editedNotes.filter((_, i) => !excludedNoteIds.has(i));
    
    let imageCount = 0;
    let schemeCount = 0;
    
    includedNotes.forEach(note => {
      if (note.images && Array.isArray(note.images)) {
        note.images.forEach(img => {
          if (typeof img === 'object' && img.slidesData) {
            schemeCount++;
          } else {
            imageCount++;
          }
        });
      } else if (note.image) {
        imageCount++;
      }
    });

    statsEl.textContent = `${includedNotes.length} notes, ${schemeCount} schemes, ${imageCount} images`;
  }

  /**
   * Update preview
   */
  async function updatePreview() {
    if (isGenerating) return;
    
    showLoading('Generating preview...');
    isGenerating = true;

    try {
      // Build project data with only included notes
      const exportData = {
        ...currentProjectData,
        notes: editedNotes.filter((_, i) => !excludedNoteIds.has(i))
      };

      if (currentFormat === 'html') {
        // Generate HTML preview
        const html = await ExportGenerator.generateHTML(exportData, htmlOptions);
        
        // Display in iframe
        if (previewIframe) {
          previewIframe.srcdoc = html;
          previewIframe.style.width = '100%';
          previewIframe.style.height = '100%';
          previewIframe.style.minHeight = '600px';
        }

        document.getElementById('previewPageInfo').textContent = 'HTML Preview';
      } else {
        // For PDF, generate HTML preview with PDF-like styling (with rendered schemes)
        const pdfPreviewHtml = await generatePDFPreviewHTML(exportData);
        
        if (previewIframe) {
          previewIframe.srcdoc = pdfPreviewHtml;
          previewIframe.style.width = pdfOptions.orientation === 'landscape' ? '842px' : '595px';
          previewIframe.style.height = pdfOptions.orientation === 'landscape' ? '595px' : '842px';
        }

        // Estimate page count
        const estimatedPages = estimatePageCount(exportData);
        document.getElementById('previewPageInfo').textContent = `Estimated ${estimatedPages} page(s)`;
      }

      // Reset zoom after preview update
      setZoom(100);
      
      hideLoading();
    } catch (error) {
      console.error('Error generating preview:', error);
      hideLoading();
    } finally {
      isGenerating = false;
    }
  }

  /**
   * Generate PDF-like HTML preview with rendered schemes
   */
  async function generatePDFPreviewHTML(data) {
    const bgColor = '#ffffff';
    const textColor = '#000000';
    const isLandscape = pdfOptions.orientation === 'landscape';
    
    // Adjust scheme size based on orientation
    const schemeWidth = isLandscape ? 500 : 400;
    const schemeHeight = isLandscape ? 350 : 300;
    
    // Build video lookup map
    const videos = data.project?.videos || [];
    const videoMap = {};
    videos.forEach(v => {
      if (v.videoId) videoMap[v.videoId] = v.videoTitle || v.videoUrl || 'Video';
      if (v.videoUrl) videoMap[v.videoUrl] = v.videoTitle || v.videoUrl || 'Video';
    });
    
    let html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; 
      background: ${bgColor}; 
      color: ${textColor};
      padding: ${isLandscape ? '20px' : '30px'};
      line-height: 1.4;
      font-size: 9px;
    }
    h1 { font-size: ${isLandscape ? '14px' : '16px'}; text-align: center; margin-bottom: 6px; }
    .date { text-align: center; color: #666; font-size: 8px; margin-bottom: 12px; }
    .note { margin-bottom: 12px; page-break-inside: avoid; }
    .note-header { font-weight: bold; font-size: 9px; margin-bottom: 2px; color: #1a73e8; }
    .note-video { font-size: 7px; color: #888; margin-bottom: 3px; font-style: italic; }
    .note-text { font-size: 8px; margin-bottom: 4px; white-space: pre-wrap; }
    .note-meta { font-size: 7px; color: #666; margin-bottom: 4px; }
    .note-image { max-width: ${isLandscape ? '50%' : '70%'}; margin: 8px auto; display: block; border: 1px solid #ddd; border-radius: 3px; }
    .scheme-container { margin: 8px 0; padding: 6px; background: #f9f9f9; border-radius: 4px; }
    .scheme-label { font-size: 8px; font-weight: bold; color: #333; margin-bottom: 4px; }
    .scheme-slide { max-width: ${isLandscape ? '60%' : '90%'}; height: auto; margin: 4px auto; display: block; border: 1px solid #ddd; border-radius: 3px; }
    .slide-comment { font-size: 7px; color: #666; font-style: italic; margin-top: 2px; text-align: center; }
    hr { border: none; border-top: 1px solid #eee; margin: 8px 0; }
    .page-break { page-break-after: always; border-top: 2px dashed #ccc; margin: 20px 0; padding-top: 12px; }
  </style>
</head>
<body>
  <h1>${escapeHtml(data.project?.name || 'Project Notes')}</h1>
  <div class="date">${escapeHtml(data.project?.date || new Date().toLocaleDateString())}</div>
`;

    const notes = data.notes || [];
    for (let i = 0; i < notes.length; i++) {
      const note = notes[i];
      const timecode = note.videoTime ? formatTimecode(note.videoTime) : '';
      const text = (note.text || note.content || '').replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
      
      // Get video title for this note
      let videoTitle = '';
      if (note.videoTitle) {
        videoTitle = note.videoTitle;
      } else if (note.videoId && videoMap[note.videoId]) {
        videoTitle = videoMap[note.videoId];
      } else if (note.videoUrl && videoMap[note.videoUrl]) {
        videoTitle = videoMap[note.videoUrl];
      }
      
      html += `
  <div class="note">
    <div class="note-header">Note ${i + 1} ${escapeHtml(timecode)}</div>
    ${videoTitle ? `<div class="note-video">From: ${escapeHtml(videoTitle)}</div>` : ''}
    ${text ? `<div class="note-text">${escapeHtml(text)}</div>` : ''}
`;

      // Metadata
      if (pdfOptions.includeMetadata) {
        const meta = [];
        if (note.team || (note.teams && note.teams.length > 0)) {
          meta.push(`Team: ${note.team || note.teams.join(', ')}`);
        }
        if (note.events && note.events.length > 0) {
          meta.push(`Events: ${note.events.join(', ')}`);
        }
        if (meta.length > 0) {
          html += `<div class="note-meta">${escapeHtml(meta.join(' | '))}</div>`;
        }
      }

      // Images and Schemes
      if (note.images && Array.isArray(note.images)) {
        for (const img of note.images) {
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            // Render scheme slides
            html += `<div class="scheme-container">
              <div class="scheme-label">Tactical Scheme (${img.slidesData.length} slide${img.slidesData.length > 1 ? 's' : ''})</div>`;
            
            for (let slideIdx = 0; slideIdx < img.slidesData.length; slideIdx++) {
              const slide = img.slidesData[slideIdx];
              try {
                // Get default background
                const defaultBg = typeof chrome !== 'undefined' && chrome.runtime 
                  ? chrome.runtime.getURL('icons/soccer-145794.svg')
                  : 'icons/soccer-145794.svg';
                
                // Render the slide with appropriate size
                const renderedSlide = await ExportGenerator.renderSchemeSlideToCanvas(slide, defaultBg, schemeWidth, schemeHeight);
                html += `
                <div style="text-align: center;">
                  <div style="font-size: 10px; color: #888; margin-bottom: 4px;">Slide ${slideIdx + 1}</div>
                  <img class="scheme-slide" src="${renderedSlide}" alt="Scheme slide ${slideIdx + 1}">
                  ${slide.comment ? `<div class="slide-comment">${escapeHtml(slide.comment)}</div>` : ''}
                </div>`;
              } catch (error) {
                console.error('Error rendering scheme slide:', error);
                html += `<div style="color: #f44; font-size: 10px;">Error rendering slide ${slideIdx + 1}</div>`;
              }
            }
            html += `</div>`;
          } else {
            // Regular image
            const imageData = typeof img === 'string' ? img : img.imageData;
            if (imageData && imageData.startsWith('data:image/')) {
              html += `<img class="note-image" src="${imageData}" alt="Note image">`;
            }
          }
        }
      } else if (note.image && note.image.startsWith('data:image/')) {
        html += `<img class="note-image" src="${note.image}" alt="Note image">`;
      }

      html += `
  </div>
  <hr>
`;
    }

    // Add timeline markers section
    if (data.timelineMarkers && data.timelineMarkers.length > 0 && pdfOptions.includeTimelineMarkers) {
      // Build player ID to name map with proper display format
      const playerMap = {};
      if (data.players && Array.isArray(data.players)) {
        data.players.forEach(p => {
          if (p.id) {
            // Format: "#number fullName" or just name/id
            const displayName = p.number 
              ? `#${p.number} ${p.fullName || p.name || ''}`.trim()
              : (p.fullName || p.name || p.id);
            playerMap[p.id] = displayName;
          }
        });
      }
      
      html += `
  <div class="page-break"></div>
  <h2 style="font-size: 11px; color: #333; margin-bottom: 8px;">Timeline Markers</h2>
`;
      for (const marker of data.timelineMarkers) {
        const time = formatTimecode(marker.time);
        const event = marker.event || marker.eventType || 'Marker';
        const team = marker.team || '';
        
        // Resolve player IDs to names
        let playersText = '';
        if (marker.players && marker.players.length > 0) {
          const playerNames = marker.players.map(pid => {
            if (typeof pid === 'object') {
              // Player object with properties
              const num = pid.number;
              const name = pid.fullName || pid.name || '';
              return num ? `#${num} ${name}`.trim() : (name || 'Player');
            }
            // Player ID - look up in map
            return playerMap[pid] || `#${pid}`;
          }).filter(Boolean);
          playersText = playerNames.join(', ');
        }
        
        html += `
  <div style="background: #f8f9fa; border-left: 3px solid #dc3545; padding: 6px 8px; margin-bottom: 6px; border-radius: 3px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
      <div>
        <div style="font-weight: 600; color: #dc3545; font-size: 8px;">${escapeHtml(event)}</div>
        ${team ? `<div style="font-size: 7px; color: #333;">${escapeHtml(team)}</div>` : ''}
        ${playersText ? `<div style="font-size: 7px; color: #666;">${escapeHtml(playersText)}</div>` : ''}
        ${marker.videoTitle ? `<div style="font-size: 6px; color: #888; font-style: italic;">${escapeHtml(marker.videoTitle)}</div>` : ''}
      </div>
      <div style="font-family: monospace; font-weight: 600; color: #1a73e8; font-size: 8px;">${escapeHtml(time)}</div>
    </div>
  </div>
`;
      }
    }

    html += `
</body>
</html>`;

    return html;
  }

  /**
   * Estimate page count for PDF
   */
  function estimatePageCount(data) {
    let pages = 1; // Title page
    
    const notes = data.notes || [];
    let currentPageContent = 0;
    const maxContentPerPage = 10; // Simplified estimate

    notes.forEach(note => {
      currentPageContent += 1;
      
      if (note.images && Array.isArray(note.images)) {
        note.images.forEach(img => {
          if (typeof img === 'object' && img.slidesData) {
            pages += img.slidesData.length; // Each slide is a page
          } else {
            currentPageContent += 2;
          }
        });
      } else if (note.image) {
        currentPageContent += 2;
      }

      if (currentPageContent >= maxContentPerPage) {
        pages++;
        currentPageContent = 0;
      }
    });

    if (data.timelineMarkers && data.timelineMarkers.length > 0 && pdfOptions.includeTimelineMarkers) {
      pages++;
    }

    return Math.max(1, pages);
  }

  /**
   * Download the export
   */
  async function downloadExport() {
    if (isGenerating) return;

    const btn = document.getElementById('exportDownloadBtn');
    btn.disabled = true;
    showLoading(`Generating ${currentFormat.toUpperCase()}...`);

    try {
      // Build project data with only included notes
      const exportData = {
        ...currentProjectData,
        notes: editedNotes.filter((_, i) => !excludedNoteIds.has(i))
      };

      const projectName = (currentProjectData.project?.name || 'project').replace(/[^a-z0-9]/gi, '_');
      const timestamp = Date.now();

      if (currentFormat === 'pdf') {
        const pdfBlob = await ExportGenerator.generatePDF(exportData, pdfOptions);
        ExportGenerator.downloadFile(pdfBlob, `${projectName}_notes_${timestamp}.pdf`, 'application/pdf');
      } else {
        const htmlContent = await ExportGenerator.generateHTML(exportData, htmlOptions);
        ExportGenerator.downloadFile(htmlContent, `${projectName}_notes_${timestamp}.html`, 'text/html');
      }

      hideLoading();
      close();
    } catch (error) {
      console.error('Error generating export:', error);
      hideLoading();
      alert('Error generating export: ' + error.message);
    } finally {
      btn.disabled = false;
    }
  }

  /**
   * Show loading overlay
   */
  function showLoading(text) {
    const loading = document.getElementById('exportLoading');
    const loadingText = document.getElementById('exportLoadingText');
    if (loading) {
      loading.style.display = 'flex';
      if (loadingText) loadingText.textContent = text || 'Loading...';
    }
  }

  /**
   * Hide loading overlay
   */
  function hideLoading() {
    const loading = document.getElementById('exportLoading');
    if (loading) {
      loading.style.display = 'none';
    }
  }

  // Public API
  return {
    open,
    close,
    init
  };

})();

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.ExportPreview = ExportPreview;
}
