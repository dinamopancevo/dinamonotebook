// Export Generator for Distats
// Generates PDF and HTML exports of project notes with schemes, pictures, and animations

const ExportGenerator = (function() {
  'use strict';

  // ========== CONSTANTS ==========
  const DEFAULT_PDF_OPTIONS = {
    pageSize: 'a4',
    orientation: 'portrait',
    includeMetadata: true,
    includeTimelineMarkers: true,
    margin: 20
  };

  const DEFAULT_HTML_OPTIONS = {
    theme: 'dark',
    animationSpeed: 1.0,
    autoPlayAnimations: false,
    includeInteractiveControls: true,
    responsive: true
  };

  // Page dimensions in mm
  const PAGE_SIZES = {
    a4: { width: 210, height: 297 },
    letter: { width: 215.9, height: 279.4 },
    a3: { width: 297, height: 420 }
  };

  // ========== UTILITY FUNCTIONS ==========

  /**
   * Convert data URL to blob
   */
  function dataURLtoBlob(dataURL) {
    const parts = dataURL.split(',');
    const mime = parts[0].match(/:(.*?);/)[1];
    const bstr = atob(parts[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
  }

  /**
   * Format timecode from seconds
   */
  function formatTimecode(seconds) {
    if (!seconds && seconds !== 0) return '';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `[${mins}:${String(secs).padStart(2, '0')}]`;
  }

  /**
   * Escape HTML special characters
   */
  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Get default football field background
   */
  function getDefaultBackground() {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      return chrome.runtime.getURL('icons/soccer-145794.svg');
    }
    return 'icons/soccer-145794.svg';
  }

  // ========== SCHEME RENDERING ==========

  /**
   * Render a single scheme slide to canvas
   * @param {Object} slide - Slide data with drawings
   * @param {string} backgroundImage - Background image URL
   * @param {number} width - Canvas width
   * @param {number} height - Canvas height
   * @returns {Promise<string>} - Data URL of rendered image
   */
  async function renderSchemeSlideToCanvas(slide, backgroundImage, width = 800, height = 600) {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      // Use slide's background image if available, otherwise use provided background
      const bgSrc = slide.backgroundImage || backgroundImage || getDefaultBackground();

      // Load and draw background
      const bgImg = new Image();
      bgImg.crossOrigin = 'anonymous';
      
      bgImg.onload = () => {
        // Get original image dimensions for scaling
        const origWidth = bgImg.naturalWidth || bgImg.width;
        const origHeight = bgImg.naturalHeight || bgImg.height;
        
        // Calculate scale factors
        const scaleX = width / origWidth;
        const scaleY = height / origHeight;
        
        // Draw background scaled to fit
        ctx.drawImage(bgImg, 0, 0, width, height);
        
        // Draw all drawings with scaling
        const drawings = slide.drawings || [];
        drawings.forEach(drawing => {
          renderDrawingToContext(ctx, drawing, width, height, scaleX, scaleY);
        });

        resolve(canvas.toDataURL('image/jpeg', 0.95));
      };

      bgImg.onerror = () => {
        // Fill with green field color if background fails
        ctx.fillStyle = '#2d5a27';
        ctx.fillRect(0, 0, width, height);
        
        // Use default scaling (assume original was 800x600 for SVG fields)
        const defaultOrigWidth = 800;
        const defaultOrigHeight = 600;
        const scaleX = width / defaultOrigWidth;
        const scaleY = height / defaultOrigHeight;
        
        // Draw all drawings with scaling
        const drawings = slide.drawings || [];
        drawings.forEach(drawing => {
          renderDrawingToContext(ctx, drawing, width, height, scaleX, scaleY);
        });

        resolve(canvas.toDataURL('image/jpeg', 0.95));
      };

      bgImg.src = bgSrc;
    });
  }

  /**
   * Scale a value by a factor
   */
  function scale(val, factor) {
    return val * factor;
  }

  /**
   * Render a drawing to canvas context
   * @param {CanvasRenderingContext2D} ctx - Canvas context
   * @param {Object} drawing - Drawing object
   * @param {number} canvasWidth - Canvas width
   * @param {number} canvasHeight - Canvas height
   * @param {number} scaleX - X scale factor (default 1)
   * @param {number} scaleY - Y scale factor (default 1)
   */
  function renderDrawingToContext(ctx, drawing, canvasWidth, canvasHeight, scaleX = 1, scaleY = 1) {
    if (!drawing) return;

    ctx.save();
    const opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
    ctx.globalAlpha = Math.min(opacity, 1.0);
    ctx.strokeStyle = drawing.color || '#FF0000';
    ctx.fillStyle = drawing.color || '#FF0000';
    // Scale line width proportionally
    ctx.lineWidth = (drawing.lineWidth || 2) * Math.max(scaleX, scaleY);

    // Apply line style
    if (drawing.lineStyle === 'dashed') {
      ctx.setLineDash([8 * scaleX, 4 * scaleX]);
    } else if (drawing.lineStyle === 'dotted') {
      ctx.setLineDash([2 * scaleX, 2 * scaleX]);
    } else {
      ctx.setLineDash([]);
    }

    // Helper to scale coordinates
    const sx = (x) => x * scaleX;
    const sy = (y) => y * scaleY;
    const sAvg = (val) => val * Math.max(scaleX, scaleY);

    switch (drawing.type) {
      case 'animpath':
        // Draw animation path with arrow
        if (drawing.points && drawing.points.length > 1) {
          ctx.strokeStyle = drawing.color || '#FF0000';
          ctx.lineWidth = (drawing.lineWidth || 3) * 1.5 * sAvg(1);
          ctx.beginPath();
          ctx.moveTo(sx(drawing.points[0].x), sy(drawing.points[0].y));
          for (let i = 1; i < drawing.points.length; i++) {
            ctx.lineTo(sx(drawing.points[i].x), sy(drawing.points[i].y));
          }
          ctx.stroke();

          // Arrowhead
          if (drawing.points.length >= 2) {
            const lastPoint = drawing.points[drawing.points.length - 1];
            const secondLastPoint = drawing.points[drawing.points.length - 2];
            const angle = Math.atan2(
              sy(lastPoint.y) - sy(secondLastPoint.y), 
              sx(lastPoint.x) - sx(secondLastPoint.x)
            );
            const arrowLength = sAvg(12);
            
            ctx.fillStyle = drawing.color || '#FF0000';
            ctx.beginPath();
            ctx.moveTo(sx(lastPoint.x), sy(lastPoint.y));
            ctx.lineTo(
              sx(lastPoint.x) - arrowLength * Math.cos(angle - Math.PI / 6),
              sy(lastPoint.y) - arrowLength * Math.sin(angle - Math.PI / 6)
            );
            ctx.lineTo(
              sx(lastPoint.x) - arrowLength * Math.cos(angle + Math.PI / 6),
              sy(lastPoint.y) - arrowLength * Math.sin(angle + Math.PI / 6)
            );
            ctx.closePath();
            ctx.fill();
          }
        }
        break;

      case 'eraser':
        // Eraser is applied via layer compositing in the editor; skip in export (would need full layer pass to match)
        break;

      case 'freehand':
        // Draw freehand path
        if (drawing.points && drawing.points.length > 1) {
          ctx.strokeStyle = drawing.color || '#FF0000';
          ctx.beginPath();
          ctx.moveTo(sx(drawing.points[0].x), sy(drawing.points[0].y));
          for (let i = 1; i < drawing.points.length; i++) {
            ctx.lineTo(sx(drawing.points[i].x), sy(drawing.points[i].y));
          }
          ctx.stroke();
        }
        break;

      case 'line':
        ctx.beginPath();
        ctx.moveTo(sx(drawing.startX), sy(drawing.startY));
        ctx.lineTo(sx(drawing.endX), sy(drawing.endY));
        ctx.stroke();
        break;

      case 'arrow':
        ctx.beginPath();
        ctx.moveTo(sx(drawing.startX), sy(drawing.startY));
        ctx.lineTo(sx(drawing.endX), sy(drawing.endY));
        ctx.stroke();
        
        // Arrowhead
        if (drawing.endX !== undefined && drawing.endY !== undefined) {
          const angle = Math.atan2(
            sy(drawing.endY) - sy(drawing.startY), 
            sx(drawing.endX) - sx(drawing.startX)
          );
          const arrowLength = sAvg(10);
          ctx.beginPath();
          ctx.moveTo(sx(drawing.endX), sy(drawing.endY));
          ctx.lineTo(
            sx(drawing.endX) - arrowLength * Math.cos(angle - Math.PI / 6),
            sy(drawing.endY) - arrowLength * Math.sin(angle - Math.PI / 6)
          );
          ctx.lineTo(
            sx(drawing.endX) - arrowLength * Math.cos(angle + Math.PI / 6),
            sy(drawing.endY) - arrowLength * Math.sin(angle + Math.PI / 6)
          );
          ctx.closePath();
          ctx.fill();
        }
        break;

      case 'curve':
        if (drawing.controlPoint) {
          ctx.beginPath();
          ctx.moveTo(sx(drawing.startX), sy(drawing.startY));
          ctx.quadraticCurveTo(
            sx(drawing.controlPoint.x), sy(drawing.controlPoint.y), 
            sx(drawing.endX), sy(drawing.endY)
          );
          ctx.stroke();
        }
        break;

      case 'circle':
        const radius = Math.max(
          Math.abs(sx(drawing.endX) - sx(drawing.startX)), 
          Math.abs(sy(drawing.endY) - sy(drawing.startY))
        ) / 2;
        const centerX = (sx(drawing.startX) + sx(drawing.endX)) / 2;
        const centerY = (sy(drawing.startY) + sy(drawing.endY)) / 2;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        if (drawing.fillOpacity > 0) {
          ctx.globalAlpha = drawing.fillOpacity;
          ctx.fillStyle = drawing.fillColor || drawing.color;
          ctx.fill();
        }
        ctx.globalAlpha = opacity;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();
        break;

      case 'rectangle':
        const rectLeft = Math.min(sx(drawing.startX), sx(drawing.endX));
        const rectTop = Math.min(sy(drawing.startY), sy(drawing.endY));
        const rectWidth = Math.abs(sx(drawing.endX) - sx(drawing.startX));
        const rectHeight = Math.abs(sy(drawing.endY) - sy(drawing.startY));
        if (drawing.fillOpacity > 0) {
          ctx.globalAlpha = drawing.fillOpacity;
          ctx.fillStyle = drawing.fillColor || drawing.color;
          ctx.fillRect(rectLeft, rectTop, rectWidth, rectHeight);
        }
        ctx.globalAlpha = opacity;
        ctx.strokeRect(rectLeft, rectTop, rectWidth, rectHeight);
        break;

      case 'ball':
        const ballSize = Math.max(
          Math.abs(sx(drawing.endX) - sx(drawing.startX)), 
          Math.abs(sy(drawing.endY) - sy(drawing.startY))
        );
        const ballX = Math.min(sx(drawing.startX), sx(drawing.endX));
        const ballY = Math.min(sy(drawing.startY), sy(drawing.endY));
        ctx.fillStyle = drawing.color || '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ballX + ballSize / 2, ballY + ballSize / 2, ballSize / 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = sAvg(1);
        ctx.stroke();
        break;

      case 'tshirt':
        renderTshirt(ctx, drawing, scaleX, scaleY);
        break;

      case 'text':
        ctx.font = `${sAvg(drawing.fontSize || 16)}px sans-serif`;
        ctx.fillStyle = drawing.color || '#FFFFFF';
        ctx.fillText(drawing.text || '', sx(drawing.x || drawing.startX || 0), sy(drawing.y || drawing.startY || 0));
        break;

      case 'spray':
        if (drawing.particles && drawing.particles.length > 0) {
          ctx.fillStyle = drawing.color || '#000000';
          const particleSize = sAvg(drawing.particleSize || 2);
          drawing.particles.forEach(particle => {
            ctx.beginPath();
            ctx.arc(sx(particle.x), sy(particle.y), particleSize, 0, Math.PI * 2);
            ctx.fill();
          });
        }
        break;

      case 'oval':
        const radiusXO = Math.abs(sx(drawing.endX) - sx(drawing.startX)) / 2;
        const radiusYO = Math.abs(sy(drawing.endY) - sy(drawing.startY)) / 2;
        const cXO = (sx(drawing.startX) + sx(drawing.endX)) / 2;
        const cYO = (sy(drawing.startY) + sy(drawing.endY)) / 2;
        ctx.beginPath();
        ctx.ellipse(cXO, cYO, radiusXO, radiusYO, 0, 0, Math.PI * 2);
        if (drawing.fillOpacity > 0) {
          ctx.globalAlpha = drawing.fillOpacity;
          ctx.fillStyle = drawing.fillColor || drawing.color;
          ctx.fill();
        }
        ctx.globalAlpha = opacity;
        ctx.beginPath();
        ctx.ellipse(cXO, cYO, radiusXO, radiusYO, 0, 0, Math.PI * 2);
        ctx.stroke();
        break;

      case 'triangle':
        ctx.beginPath();
        ctx.moveTo((sx(drawing.startX) + sx(drawing.endX)) / 2, sy(drawing.startY));
        ctx.lineTo(sx(drawing.startX), sy(drawing.endY));
        ctx.lineTo(sx(drawing.endX), sy(drawing.endY));
        ctx.closePath();
        if (drawing.fillOpacity > 0) {
          ctx.globalAlpha = drawing.fillOpacity;
          ctx.fillStyle = drawing.fillColor || drawing.color;
          ctx.fill();
        }
        ctx.globalAlpha = opacity;
        ctx.beginPath();
        ctx.moveTo((sx(drawing.startX) + sx(drawing.endX)) / 2, sy(drawing.startY));
        ctx.lineTo(sx(drawing.startX), sy(drawing.endY));
        ctx.lineTo(sx(drawing.endX), sy(drawing.endY));
        ctx.closePath();
        ctx.stroke();
        break;

      case 'polygon':
        if (drawing.points && drawing.points.length >= 3) {
          ctx.beginPath();
          ctx.moveTo(sx(drawing.points[0].x), sy(drawing.points[0].y));
          for (let i = 1; i < drawing.points.length; i++) {
            ctx.lineTo(sx(drawing.points[i].x), sy(drawing.points[i].y));
          }
          ctx.closePath();
          if (drawing.fillOpacity > 0) {
            ctx.globalAlpha = drawing.fillOpacity;
            ctx.fillStyle = drawing.fillColor || drawing.color;
            ctx.fill();
          }
          ctx.globalAlpha = opacity;
          ctx.beginPath();
          ctx.moveTo(sx(drawing.points[0].x), sy(drawing.points[0].y));
          for (let i = 1; i < drawing.points.length; i++) {
            ctx.lineTo(sx(drawing.points[i].x), sy(drawing.points[i].y));
          }
          ctx.closePath();
          ctx.stroke();
        }
        break;

      case 'image':
        // Handle embedded images
        if (drawing.imageData || drawing.src) {
          const imgSrc = drawing.imageData || drawing.src;
          const imgEl = new Image();
          imgEl.src = imgSrc;
          // Note: This won't work synchronously, but for now we attempt it
          try {
            const imgX = sx(drawing.x || drawing.startX || 0);
            const imgY = sy(drawing.y || drawing.startY || 0);
            const imgW = sx(drawing.width || Math.abs(drawing.endX - drawing.startX) || 100);
            const imgH = sy(drawing.height || Math.abs(drawing.endY - drawing.startY) || 100);
            ctx.drawImage(imgEl, imgX, imgY, imgW, imgH);
          } catch (e) {
            // Image not loaded yet, skip
          }
        }
        break;

      case 'heatmap':
        // Skip heatmaps for now - they're complex grid-based
        break;
    }

    ctx.restore();
  }

  /**
   * Render t-shirt drawing with scaling
   */
  function renderTshirt(ctx, drawing, scaleX = 1, scaleY = 1) {
    const sx = (x) => x * scaleX;
    const sy = (y) => y * scaleY;
    const sAvg = (val) => val * Math.max(scaleX, scaleY);
    
    const tshirtCenterX = (sx(drawing.startX) + sx(drawing.endX)) / 2;
    const tshirtCenterY = (sy(drawing.startY) + sy(drawing.endY)) / 2;
    const shirtWidth = Math.abs(sx(drawing.endX) - sx(drawing.startX));
    const shirtHeight = Math.abs(sy(drawing.endY) - sy(drawing.startY));
    const startX = tshirtCenterX - shirtWidth / 2;
    const startY = tshirtCenterY - shirtHeight / 2;
    
    const primaryColor = drawing.color || '#FFFFFF';
    const secondColor = drawing.secondColor || '#000000';
    const design = drawing.design || 'solid';
    
    const collarWidth = shirtWidth * 0.35;
    const shoulderWidth = (shirtWidth - collarWidth) / 2;
    const sleeveLength = shirtWidth * 0.18;
    
    // Create t-shirt path
    ctx.beginPath();
    ctx.moveTo(startX, startY + shirtHeight * 0.08);
    ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
    ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
    ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
    ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
    ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
    ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
    const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
    ctx.lineTo(rightBottomX, startY + shirtHeight);
    ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
    ctx.lineTo(startX, startY + shirtHeight * 0.38);
    ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
    ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
    ctx.closePath();
    
    // Fill base color
    ctx.fillStyle = primaryColor;
    ctx.fill();
    
    // Draw outline
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Draw number if available
    if (drawing.number !== undefined && drawing.number !== null && drawing.number !== '') {
      const hex = primaryColor.replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
      const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
      ctx.fillStyle = textColor;
      ctx.font = `bold ${shirtHeight * 0.25}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(drawing.number), tshirtCenterX, tshirtCenterY);
    }
  }

  // ========== PDF GENERATION ==========

  /**
   * Render text to image for Unicode support (Cyrillic, emojis, etc.)
   */
  function renderTextToImage(text, fontSize, fontWeight, maxWidth, textColor = '#000000') {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // Font stack with emoji support
    const fontStack = `${fontWeight} ${fontSize}px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", "Segoe UI Symbol", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif`;
    
    // Set font for measurement
    ctx.font = fontStack;
    
    // Wrap text - handle emojis specially since they can be multi-codepoint
    const lines = [];
    let currentLine = '';
    
    // Split by spaces but keep emojis together
    const segments = text.split(/(\s+)/);
    
    for (const segment of segments) {
      if (segment.trim() === '') {
        currentLine += segment;
        continue;
      }
      
      const testLine = currentLine + segment;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && currentLine.trim()) {
        lines.push(currentLine.trim());
        currentLine = segment;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine.trim()) lines.push(currentLine.trim());
    
    // Size canvas with some extra width to prevent clipping
    const lineHeight = fontSize * 1.4;
    const measuredWidth = Math.max(...lines.map(l => ctx.measureText(l).width));
    canvas.width = Math.min(maxWidth, measuredWidth + fontSize); // Add padding for emojis
    canvas.height = lines.length * lineHeight + fontSize * 0.5;
    
    // Clear and redraw with proper size
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = fontStack;
    ctx.fillStyle = textColor;
    ctx.textBaseline = 'top';
    
    lines.forEach((line, i) => {
      ctx.fillText(line, 0, i * lineHeight);
    });
    
    return {
      dataUrl: canvas.toDataURL('image/png'),
      width: canvas.width,
      height: canvas.height,
      lines: lines.length
    };
  }

  /**
   * Check if text contains non-ASCII characters
   */
  function hasNonAscii(text) {
    return /[^\x00-\x7F]/.test(text);
  }

  /**
   * Generate PDF from project data
   * @param {Object} projectData - Project data with notes, schemes, etc.
   * @param {Object} options - PDF generation options
   * @returns {Promise<Blob>} - PDF blob
   */
  async function generatePDF(projectData, options = {}) {
    const opts = { ...DEFAULT_PDF_OPTIONS, ...options };
    const pageSize = PAGE_SIZES[opts.pageSize] || PAGE_SIZES.a4;
    const isLandscape = opts.orientation === 'landscape';
    
    // Create PDF document
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
      orientation: opts.orientation,
      unit: 'mm',
      format: opts.pageSize
    });

    const pageWidth = isLandscape ? pageSize.height : pageSize.width;
    const pageHeight = isLandscape ? pageSize.width : pageSize.height;
    const margin = opts.margin;
    const contentWidth = pageWidth - (margin * 2);
    const contentHeight = pageHeight - (margin * 2);
    
    // Adjust scheme sizes for landscape
    const schemeImgWidth = isLandscape ? contentWidth * 0.6 : contentWidth * 0.8;
    const schemeImgHeight = schemeImgWidth * 0.75;

    let currentY = margin;
    let pageNumber = 1;
    
    // Build video lookup map
    const videos = projectData.project?.videos || [];
    const videoMap = {};
    videos.forEach(v => {
      if (v.videoId) videoMap[v.videoId] = v.videoTitle || v.videoUrl || 'Video';
      if (v.videoUrl) videoMap[v.videoUrl] = v.videoTitle || v.videoUrl || 'Video';
    });

    // Helper to add text (handles Unicode)
    // Note: fontSize is in points (pt) for jsPDF, convert properly for canvas rendering
    const addText = (text, x, y, fontSize, fontWeight = 'normal', color = '#000000', maxWidth = contentWidth) => {
      if (!text) return 0;
      
      if (hasNonAscii(text)) {
        // Render as image for Unicode support
        // jsPDF uses points: 1pt = 0.352778mm
        // At 96 DPI: 1pt = 96/72 = 1.333 pixels
        // Use 1.5x for good quality (slightly larger for crisp rendering)
        const pixelsPerPoint = 1.5;
        const fontSizePx = fontSize * pixelsPerPoint;
        
        // Convert maxWidth from mm to pixels (jsPDF unit is mm)
        // 1mm = 3.7795 pixels at 96 DPI
        const pixelsPerMm = 3.7795;
        const canvasWidth = maxWidth * pixelsPerMm;
        
        const rendered = renderTextToImage(text, fontSizePx, fontWeight, canvasWidth, color);
        
        // Convert back from pixels to mm for PDF
        const imgWidth = rendered.width / pixelsPerMm;
        const imgHeight = rendered.height / pixelsPerMm;
        
        try {
          doc.addImage(rendered.dataUrl, 'PNG', x, y - fontSize * 0.2, imgWidth, imgHeight);
        } catch (e) {
          console.error('Error adding text image:', e);
        }
        return imgHeight;
      } else {
        // Use native text for ASCII
        doc.setFontSize(fontSize);
        doc.setFont('helvetica', fontWeight === 'bold' ? 'bold' : 'normal');
        const rgbMatch = color.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
        if (rgbMatch) {
          doc.setTextColor(parseInt(rgbMatch[1], 16), parseInt(rgbMatch[2], 16), parseInt(rgbMatch[3], 16));
        } else {
          doc.setTextColor(0);
        }
        const lines = doc.splitTextToSize(text, maxWidth);
        doc.text(lines, x, y);
        doc.setTextColor(0);
        return lines.length * fontSize * 0.4;
      }
    };

    // Add title page
    const projectName = projectData.project?.name || 'Project Notes';
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    if (hasNonAscii(projectName)) {
      // Render title as image for Unicode/emoji support, then center it
      const pixelsPerPoint = 1.5;
      const pixelsPerMm = 3.7795;
      const titleImg = renderTextToImage(projectName, 14 * pixelsPerPoint, 'bold', contentWidth * pixelsPerMm, '#000000');
      const titleWidth = titleImg.width / pixelsPerMm;
      const titleHeight = titleImg.height / pixelsPerMm;
      const titleX = margin + (contentWidth - titleWidth) / 2;
      try {
        doc.addImage(titleImg.dataUrl, 'PNG', titleX, margin + 12, titleWidth, titleHeight);
      } catch (e) {
        // Fallback to native text if image fails
        doc.text(projectName, pageWidth / 2, margin + 15, { align: 'center' });
      }
    } else {
      doc.text(projectName, pageWidth / 2, margin + 15, { align: 'center' });
    }
    
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Date: ${projectData.project?.date || new Date().toLocaleDateString()}`, pageWidth / 2, margin + 25, { align: 'center' });
    
    if (opts.includeMetadata && projectData.project?.videos?.length > 0) {
      doc.setFontSize(7);
      doc.text(`Videos: ${projectData.project.videos.length}`, pageWidth / 2, margin + 32, { align: 'center' });
    }

    currentY = margin + 45;

    // Process notes
    const notes = projectData.notes || [];
    for (let i = 0; i < notes.length; i++) {
      const note = notes[i];
      
      // Check if we need a new page
      if (currentY > pageHeight - margin - 40) {
        doc.addPage();
        pageNumber++;
        currentY = margin;
      }

      // Note header with timecode
      const timecode = note.videoTime ? formatTimecode(note.videoTime) : '';
      const headerText = `Note ${i + 1} ${timecode}`;
      const headerHeight = addText(headerText, margin, currentY, 8, 'bold', '#1a73e8');
      currentY += Math.max(headerHeight, 4);
      
      // Video source
      let videoTitle = '';
      if (note.videoTitle) {
        videoTitle = note.videoTitle;
      } else if (note.videoId && videoMap[note.videoId]) {
        videoTitle = videoMap[note.videoId];
      } else if (note.videoUrl && videoMap[note.videoUrl]) {
        videoTitle = videoMap[note.videoUrl];
      }
      if (videoTitle) {
        const videoHeight = addText(`From: ${videoTitle}`, margin, currentY, 7, 'normal', '#888888');
        currentY += Math.max(videoHeight, 3);
      }

      // Note text
      const noteText = note.text || note.content || '';
      if (noteText) {
        const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
        const textHeight = addText(cleanText, margin, currentY, 9, 'normal', '#000000');
        currentY += Math.max(textHeight, 4) + 2;
      }

      // Metadata
      if (opts.includeMetadata) {
        const metadata = [];
        if (note.team || (note.teams && note.teams.length > 0)) {
          metadata.push(`Team: ${note.team || note.teams.join(', ')}`);
        }
        if (note.events && note.events.length > 0) {
          metadata.push(`Events: ${note.events.join(', ')}`);
        }
        if (metadata.length > 0) {
          const metaHeight = addText(metadata.join(' | '), margin, currentY, 7, 'normal', '#666666');
          currentY += Math.max(metaHeight, 3);
        }
      }

      // Process images and schemes
      if (note.images && Array.isArray(note.images)) {
        for (const img of note.images) {
          // Check if this is a scheme with slides
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            // Render each slide as a separate page
            for (let slideIndex = 0; slideIndex < img.slidesData.length; slideIndex++) {
              doc.addPage();
              pageNumber++;
              currentY = margin;

              doc.setFontSize(9);
              doc.setFont('helvetica', 'bold');
              doc.text(`Scheme - Slide ${slideIndex + 1}/${img.slidesData.length}`, margin, currentY);
              currentY += 6;
              
              // Add video source for scheme
              if (videoTitle) {
                const videoHeight = addText(`From: ${videoTitle}`, margin, currentY, 7, 'normal', '#888888');
                currentY += Math.max(videoHeight, 4);
              }

              try {
                // Adjust canvas size based on orientation
                const canvasWidth = isLandscape ? 800 : 600;
                const canvasHeight = isLandscape ? 500 : 450;
                
                const slideImage = await renderSchemeSlideToCanvas(
                  img.slidesData[slideIndex],
                  getDefaultBackground(),
                  canvasWidth,
                  canvasHeight
                );
                
                // Use landscape-adjusted image size
                const imgWidth = schemeImgWidth;
                const imgHeight = schemeImgHeight;
                const imgX = isLandscape ? margin + (contentWidth - imgWidth) / 2 : margin;
                
                doc.addImage(slideImage, 'JPEG', imgX, currentY, imgWidth, imgHeight);
                currentY += imgHeight + 8;

                // Add slide comment if present (with Unicode support)
                if (img.slidesData[slideIndex].comment) {
                  const commentHeight = addText(img.slidesData[slideIndex].comment, margin, currentY, 10, 'normal', '#333333');
                  currentY += Math.max(commentHeight, 5) + 5;
                }
              } catch (error) {
                console.error('Error rendering scheme slide:', error);
              }
            }
          } else {
            // Regular image
            const imageData = typeof img === 'string' ? img : img.imageData;
            if (imageData && imageData.startsWith('data:image/')) {
              // Check if we need a new page
              if (currentY > pageHeight - margin - 80) {
                doc.addPage();
                pageNumber++;
                currentY = margin;
              }

              try {
                const imgWidth = contentWidth * 0.8;
                const imgHeight = imgWidth * 0.6;
                doc.addImage(imageData, 'JPEG', margin + (contentWidth - imgWidth) / 2, currentY, imgWidth, imgHeight);
                currentY += imgHeight + 10;
              } catch (error) {
                console.error('Error adding image to PDF:', error);
              }
            }
          }
        }
      } else if (note.image) {
        // Legacy single image
        if (note.image.startsWith('data:image/')) {
          if (currentY > pageHeight - margin - 80) {
            doc.addPage();
            pageNumber++;
            currentY = margin;
          }
          try {
            const imgWidth = contentWidth * 0.8;
            const imgHeight = imgWidth * 0.6;
            doc.addImage(note.image, 'JPEG', margin + (contentWidth - imgWidth) / 2, currentY, imgWidth, imgHeight);
            currentY += imgHeight + 10;
          } catch (error) {
            console.error('Error adding image to PDF:', error);
          }
        }
      }

      currentY += 5;
    }

    // Timeline markers section
    if (opts.includeTimelineMarkers && projectData.timelineMarkers && projectData.timelineMarkers.length > 0) {
      doc.addPage();
      pageNumber++;
      currentY = margin;

      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('Timeline Markers', margin, currentY);
      currentY += 8;

      // Build player ID to name map with proper display format
      const playerMap = {};
      if (projectData.players && Array.isArray(projectData.players)) {
        projectData.players.forEach(p => {
          if (p.id) {
            // Format: "#number fullName" or just name/id
            const displayName = p.number 
              ? `#${p.number} ${p.fullName || p.name || ''}`.trim()
              : (p.fullName || p.name || p.id);
            playerMap[p.id] = displayName;
          }
        });
      }
      
      for (const marker of projectData.timelineMarkers) {
        // Check if we need a new page (markers can be tall)
        if (currentY > pageHeight - margin - 30) {
          doc.addPage();
          pageNumber++;
          currentY = margin;
        }

        const time = formatTimecode(marker.time);
        const team = marker.team || '';
        const event = marker.event || marker.eventType || '';
        
        // Event type header
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(220, 53, 69); // Red for event type
        const eventHeight = addText(event || 'Marker', margin, currentY, 8, 'bold', '#dc3545');
        currentY += Math.max(eventHeight, 3);
        doc.setTextColor(0);
        
        // Team info
        if (team) {
          doc.setFontSize(7);
          doc.setFont('helvetica', 'normal');
          const teamHeight = addText(team, margin, currentY, 7);
          currentY += Math.max(teamHeight, 3);
        }
        
        // Players involved
        if (marker.players && marker.players.length > 0) {
          const playerNames = marker.players.map(pid => {
            if (typeof pid === 'object') {
              // Player object with properties
              const num = pid.number;
              const name = pid.fullName || pid.name || '';
              return num ? `#${num} ${name}`.trim() : (name || 'Player');
            }
            // Player ID - look up in map
            return playerMap[pid] || `#${pid}`;
          }).filter(Boolean);
          
          if (playerNames.length > 0) {
            doc.setFontSize(7);
            doc.setTextColor(100);
            const playersText = playerNames.join(', ');
            const playersHeight = addText(playersText, margin, currentY, 7, 'normal', '#666666');
            currentY += Math.max(playersHeight, 3);
            doc.setTextColor(0);
          }
        }
        
        // Video title
        if (marker.videoTitle) {
          doc.setFontSize(7);
          doc.setTextColor(100);
          const videoHeight = addText(`Video: ${marker.videoTitle}`, margin, currentY, 7, 'normal', '#888888');
          currentY += Math.max(videoHeight, 3);
          doc.setTextColor(0);
        }
        
        // Timecode
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(26, 115, 232); // Blue for timecode
        doc.text(time, margin, currentY);
        doc.setTextColor(0);
        currentY += 6;
        
        // Separator
        doc.setDrawColor(200);
        doc.line(margin, currentY, pageWidth - margin, currentY);
        currentY += 6;
      }
    }

    // Add page numbers
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(9);
      doc.setTextColor(128);
      doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
    }

    return doc.output('blob');
  }

  // ========== HTML GENERATION ==========

  /**
   * Generate HTML from project data
   * @param {Object} projectData - Project data with notes, schemes, etc.
   * @param {Object} options - HTML generation options
   * @returns {Promise<string>} - HTML string
   */
  async function generateHTML(projectData, options = {}) {
    const opts = { ...DEFAULT_HTML_OPTIONS, ...options };
    const isDark = opts.theme === 'dark';

    // Render all scheme slides
    const renderedSchemes = [];
    const notes = projectData.notes || [];
    
    for (const note of notes) {
      if (note.images && Array.isArray(note.images)) {
        for (const img of note.images) {
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            const slideImages = [];
            for (const slide of img.slidesData) {
              try {
                const rendered = await renderSchemeSlideToCanvas(slide, getDefaultBackground(), 800, 600);
                slideImages.push({
                  image: rendered,
                  comment: slide.comment || '',
                  drawings: slide.drawings || [],
                  hasAnimations: hasAnimations(slide.drawings || [])
                });
              } catch (e) {
                console.error('Error rendering slide:', e);
              }
            }
            renderedSchemes.push({
              noteTimestamp: note.timestamp,
              slides: slideImages
            });
          }
        }
      }
    }

    // Generate CSS
    const css = generateCSS(isDark, opts.animationSpeed);

    // Generate JavaScript for animations
    const js = generateAnimationJS(opts);

    // Build HTML
    let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(projectData.project?.name || 'Project Notes')}</title>
  <style>${css}</style>
</head>
<body class="${isDark ? 'dark' : 'light'}">
  <div class="container">
    <header class="header">
      <h1>${escapeHtml(projectData.project?.name || 'Project Notes')}</h1>
      <p class="date">${escapeHtml(projectData.project?.date || new Date().toLocaleDateString())}</p>
    </header>

    <main class="content">
`;

    // Build video lookup map for HTML
    const videos = projectData.project?.videos || [];
    const videoMap = {};
    videos.forEach(v => {
      if (v.videoId) videoMap[v.videoId] = v.videoTitle || v.videoUrl || 'Video';
      if (v.videoUrl) videoMap[v.videoUrl] = v.videoTitle || v.videoUrl || 'Video';
    });
    
    // Add notes
    let schemeIndex = 0;
    for (let i = 0; i < notes.length; i++) {
      const note = notes[i];
      const timecode = note.videoTime ? formatTimecode(note.videoTime) : '';
      const noteText = note.text || note.content || '';
      const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
      
      // Get video title for this note
      let videoTitle = '';
      if (note.videoTitle) {
        videoTitle = note.videoTitle;
      } else if (note.videoId && videoMap[note.videoId]) {
        videoTitle = videoMap[note.videoId];
      } else if (note.videoUrl && videoMap[note.videoUrl]) {
        videoTitle = videoMap[note.videoUrl];
      }

      html += `
      <article class="note" id="note-${i}">
        <div class="note-header">
          <span class="note-number">Note ${i + 1}</span>
          ${timecode ? `<span class="timecode">${escapeHtml(timecode)}</span>` : ''}
        </div>
        <div class="note-content">
          ${videoTitle ? `<div class="note-video-source">From: ${escapeHtml(videoTitle)}</div>` : ''}
          ${cleanText ? `<p>${escapeHtml(cleanText)}</p>` : ''}
`;

      // Add metadata
      const metadata = [];
      if (note.team || (note.teams && note.teams.length > 0)) {
        metadata.push(`<span class="meta-team">Team: ${escapeHtml(note.team || note.teams.join(', '))}</span>`);
      }
      if (note.events && note.events.length > 0) {
        metadata.push(`<span class="meta-events">Events: ${escapeHtml(note.events.join(', '))}</span>`);
      }
      if (note.zones && note.zones.length > 0) {
        metadata.push(`<span class="meta-zones">Zones: ${escapeHtml(note.zones.join(', '))}</span>`);
      }
      if (metadata.length > 0) {
        html += `<div class="note-metadata">${metadata.join(' | ')}</div>`;
      }

      // Add images and schemes
      if (note.images && Array.isArray(note.images)) {
        for (const img of note.images) {
          if (typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData)) {
            // Scheme with slides
            const scheme = renderedSchemes[schemeIndex];
            schemeIndex++;
            
            if (scheme && scheme.slides.length > 0) {
              html += `
          <div class="scheme-container" id="scheme-${schemeIndex}">
            <div class="scheme-slides">
`;
              for (let slideIdx = 0; slideIdx < scheme.slides.length; slideIdx++) {
                const slide = scheme.slides[slideIdx];
                html += `
              <div class="slide ${slideIdx === 0 ? 'active' : ''}" data-slide="${slideIdx}">
                <img src="${slide.image}" alt="Slide ${slideIdx + 1}" class="slide-image">
                ${slide.comment ? `<p class="slide-comment">${escapeHtml(slide.comment)}</p>` : ''}
              </div>
`;
              }
              
              html += `
            </div>
`;
              // Slide navigation if multiple slides
              if (scheme.slides.length > 1) {
                html += `
            <div class="slide-nav">
              <button class="nav-btn prev-btn" onclick="prevSlide(${schemeIndex})">&#10094;</button>
              <span class="slide-counter"><span id="current-slide-${schemeIndex}">1</span> / ${scheme.slides.length}</span>
              <button class="nav-btn next-btn" onclick="nextSlide(${schemeIndex})">&#10095;</button>
            </div>
`;
              }

              // Animation controls
              if (opts.includeInteractiveControls && scheme.slides.some(s => s.hasAnimations)) {
                html += `
            <div class="animation-controls">
              <button class="anim-btn" onclick="playAnimation(${schemeIndex})">Play Animation</button>
            </div>
`;
              }

              html += `
          </div>
`;
            }
          } else {
            // Regular image
            const imageData = typeof img === 'string' ? img : img.imageData;
            if (imageData && imageData.startsWith('data:image/')) {
              html += `
          <div class="image-container">
            <img src="${imageData}" alt="Note image" class="note-image">
          </div>
`;
            }
          }
        }
      } else if (note.image && note.image.startsWith('data:image/')) {
        html += `
          <div class="image-container">
            <img src="${note.image}" alt="Note image" class="note-image">
          </div>
`;
      }

      html += `
        </div>
      </article>
`;
    }

    // Timeline markers section
    if (projectData.timelineMarkers && projectData.timelineMarkers.length > 0) {
      // Build player ID to name map with proper display format
      const playerMap = {};
      if (projectData.players && Array.isArray(projectData.players)) {
        projectData.players.forEach(p => {
          if (p.id) {
            // Format: "#number fullName" or just name/id
            const displayName = p.number 
              ? `#${p.number} ${p.fullName || p.name || ''}`.trim()
              : (p.fullName || p.name || p.id);
            playerMap[p.id] = displayName;
          }
        });
      }
      
      html += `
      <section class="timeline-markers">
        <h2>Timeline Markers</h2>
        <div class="markers-list">
`;
      for (const marker of projectData.timelineMarkers) {
        const time = formatTimecode(marker.time);
        const event = marker.event || marker.eventType || 'Marker';
        const team = marker.team || '';
        
        // Resolve player IDs to names
        let playersHtml = '';
        if (marker.players && marker.players.length > 0) {
          const playerNames = marker.players.map(pid => {
            if (typeof pid === 'object') {
              // Player object with properties
              const num = pid.number;
              const name = pid.fullName || pid.name || '';
              return num ? `#${num} ${name}`.trim() : (name || 'Player');
            }
            // Player ID - look up in map
            return playerMap[pid] || `#${pid}`;
          }).filter(Boolean);
          
          if (playerNames.length > 0) {
            playersHtml = `<div class="marker-players">${escapeHtml(playerNames.join(', '))}</div>`;
          }
        }
        
        const videoHtml = marker.videoTitle 
          ? `<div class="marker-video">${escapeHtml(marker.videoTitle)}</div>` 
          : '';
        
        html += `
          <div class="marker">
            <div class="marker-info">
              <div class="marker-event-type">${escapeHtml(event)}</div>
              ${team ? `<div class="marker-team">${escapeHtml(team)}</div>` : ''}
              ${playersHtml}
              ${videoHtml}
            </div>
            <span class="marker-time">${escapeHtml(time)}</span>
          </div>
`;
      }
      html += `
        </div>
      </section>
`;
    }

    html += `
    </main>

    <footer class="footer">
      <p>Generated by Distats - ${new Date().toLocaleString()}</p>
    </footer>
  </div>

  <script>${js}</script>
</body>
</html>`;

    return html;
  }

  /**
   * Check if slide has animations
   */
  function hasAnimations(drawings) {
    return drawings.some(d => 
      (d.type === 'animpath' && d.points && d.points.length > 1) ||
      (d.animationType && d.animationType !== '')
    );
  }

  /**
   * Generate CSS for HTML export
   */
  function generateCSS(isDark, animationSpeed) {
    const bgColor = isDark ? '#0d1117' : '#ffffff';
    const textColor = isDark ? '#c9d1d9' : '#24292f';
    const borderColor = isDark ? '#30363d' : '#d0d7de';
    const headerBg = isDark ? '#161b22' : '#f6f8fa';
    const accentColor = '#58a6ff';

    return `
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
  background-color: ${bgColor};
  color: ${textColor};
  line-height: 1.6;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.header {
  text-align: center;
  padding: 40px 20px;
  border-bottom: 1px solid ${borderColor};
  margin-bottom: 40px;
}

.header h1 {
  font-size: 2.5em;
  margin-bottom: 10px;
}

.date {
  color: ${isDark ? '#8b949e' : '#57606a'};
  font-size: 0.9em;
}

.content {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

.note {
  background: ${headerBg};
  border: 1px solid ${borderColor};
  border-radius: 8px;
  overflow: hidden;
}

.note-header {
  background: ${isDark ? '#21262d' : '#eaeef2'};
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.note-number {
  font-weight: 600;
}

.timecode {
  color: ${accentColor};
  font-family: monospace;
}

.note-content {
  padding: 16px;
}

.note-video-source {
  font-size: 0.85em;
  color: ${isDark ? '#8b949e' : '#57606a'};
  font-style: italic;
  margin-bottom: 8px;
}

.note-content p {
  margin-bottom: 12px;
  white-space: pre-wrap;
}

.note-metadata {
  font-size: 0.85em;
  color: ${isDark ? '#8b949e' : '#57606a'};
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid ${borderColor};
}

.image-container {
  margin: 16px 0;
  text-align: center;
}

.note-image {
  max-width: 100%;
  border-radius: 6px;
  border: 1px solid ${borderColor};
}

.scheme-container {
  margin: 16px 0;
  background: ${isDark ? '#21262d' : '#eaeef2'};
  border-radius: 6px;
  padding: 16px;
}

.scheme-slides {
  position: relative;
  margin-bottom: 12px;
}

.slide {
  display: none;
  text-align: center;
}

.slide.active {
  display: block;
}

.slide-image {
  max-width: 100%;
  border-radius: 6px;
}

.slide-comment {
  margin-top: 12px;
  font-style: italic;
  color: ${isDark ? '#8b949e' : '#57606a'};
}

.slide-nav {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
}

.nav-btn {
  background: ${accentColor};
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1.2em;
}

.nav-btn:hover {
  opacity: 0.9;
}

.slide-counter {
  font-size: 0.9em;
  color: ${isDark ? '#8b949e' : '#57606a'};
}

.animation-controls {
  margin-top: 12px;
  text-align: center;
}

.anim-btn {
  background: ${isDark ? '#238636' : '#2da44e'};
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 1em;
}

.anim-btn:hover {
  opacity: 0.9;
}

.timeline-markers {
  margin-top: 40px;
  padding-top: 40px;
  border-top: 1px solid ${borderColor};
}

.timeline-markers h2 {
  margin-bottom: 20px;
}

.markers-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.marker {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  padding: 12px 16px;
  background: ${headerBg};
  border-radius: 8px;
  border-left: 4px solid #dc3545;
}

.marker-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.marker-event-type {
  font-weight: 600;
  font-size: 1.1em;
  color: #dc3545;
}

.marker-team {
  font-weight: 500;
  color: ${textColor};
}

.marker-players {
  font-size: 0.9em;
  color: ${isDark ? '#8b949e' : '#57606a'};
}

.marker-video {
  font-size: 0.85em;
  color: ${isDark ? '#6e7681' : '#8b949e'};
  font-style: italic;
}

.marker-time {
  font-family: monospace;
  font-size: 1.1em;
  font-weight: 600;
  color: ${accentColor};
  white-space: nowrap;
}

.footer {
  text-align: center;
  padding: 40px 20px;
  margin-top: 40px;
  border-top: 1px solid ${borderColor};
  color: ${isDark ? '#8b949e' : '#57606a'};
  font-size: 0.85em;
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes scaleIn {
  from { transform: scale(0); }
  to { transform: scale(1); }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes slideLeft {
  from { transform: translateX(100%); }
  to { transform: translateX(0); }
}

@keyframes slideRight {
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.animate-fade { animation: fadeIn ${1 / animationSpeed}s ease-out; }
.animate-scale { animation: scaleIn ${0.8 / animationSpeed}s ease-out; }
.animate-spin { animation: spin ${2 / animationSpeed}s linear; }
.animate-slide-left { animation: slideLeft ${0.5 / animationSpeed}s ease-out; }
.animate-slide-right { animation: slideRight ${0.5 / animationSpeed}s ease-out; }
.animate-pulse { animation: pulse ${2 / animationSpeed}s infinite; }

/* Responsive */
@media (max-width: 768px) {
  .header h1 { font-size: 1.8em; }
  .container { padding: 10px; }
  .note-header { flex-direction: column; gap: 8px; text-align: center; }
  .marker { flex-wrap: wrap; }
}
`;
  }

  /**
   * Generate JavaScript for HTML animations
   */
  function generateAnimationJS(options) {
    return `
// Slide navigation
const slideStates = {};

function initSlides() {
  document.querySelectorAll('.scheme-container').forEach((container, index) => {
    slideStates[index + 1] = { current: 0 };
  });
}

function showSlide(schemeId, index) {
  const container = document.querySelector('#scheme-' + schemeId);
  if (!container) return;
  
  const slides = container.querySelectorAll('.slide');
  if (index < 0) index = slides.length - 1;
  if (index >= slides.length) index = 0;
  
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
  
  slideStates[schemeId] = { current: index };
  
  const counter = document.getElementById('current-slide-' + schemeId);
  if (counter) counter.textContent = index + 1;
}

function nextSlide(schemeId) {
  const state = slideStates[schemeId] || { current: 0 };
  showSlide(schemeId, state.current + 1);
}

function prevSlide(schemeId) {
  const state = slideStates[schemeId] || { current: 0 };
  showSlide(schemeId, state.current - 1);
}

function playAnimation(schemeId) {
  const container = document.querySelector('#scheme-' + schemeId);
  if (!container) return;
  
  const activeSlide = container.querySelector('.slide.active');
  if (!activeSlide) return;
  
  const img = activeSlide.querySelector('.slide-image');
  if (!img) return;
  
  // Add animation class
  img.classList.add('animate-fade');
  
  // Remove animation class after completion
  setTimeout(() => {
    img.classList.remove('animate-fade');
  }, 1000);
}

// Auto-play if enabled
${options.autoPlayAnimations ? `
document.addEventListener('DOMContentLoaded', () => {
  initSlides();
  // Auto-play first slide animation
  setTimeout(() => {
    Object.keys(slideStates).forEach(id => {
      playAnimation(parseInt(id));
    });
  }, 1000);
});
` : `
document.addEventListener('DOMContentLoaded', initSlides);
`}
`;
  }

  // ========== COLLECT PROJECT DATA ==========

  /**
   * Collect all project data for export
   * @param {string} analysisId - Project/analysis ID
   * @returns {Promise<Object>} - Complete project data
   */
  async function collectProjectData(analysisId) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(null, (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === analysisId);

        if (!analysis) {
          reject(new Error('Project not found'));
          return;
        }

        // Get timeline markers
        const timelineMarkersKey = `timelineMarkers_${analysisId}`;
        const timelineMarkers = result[timelineMarkersKey] || [];

        // Sort notes by timestamp
        const sortedNotes = [...(analysis.notes || [])].sort((a, b) => {
          return (a.timestamp || 0) - (b.timestamp || 0);
        });

        const data = {
          project: {
            id: analysis.id,
            name: analysis.name,
            date: analysis.date,
            createdAt: analysis.createdAt,
            videos: analysis.videos || []
          },
          notes: sortedNotes,
          timelineMarkers: timelineMarkers,
          players: result.players || [],
          teams: result.teams || []
        };

        resolve(data);
      });
    });
  }

  /**
   * Download file
   * @param {Blob|string} content - File content
   * @param {string} filename - Download filename
   * @param {string} type - MIME type
   */
  function downloadFile(content, filename, type) {
    let blob;
    if (content instanceof Blob) {
      blob = content;
    } else {
      blob = new Blob([content], { type });
    }
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ========== PUBLIC API ==========

  return {
    generatePDF,
    generateHTML,
    collectProjectData,
    downloadFile,
    renderSchemeSlideToCanvas,
    DEFAULT_PDF_OPTIONS,
    DEFAULT_HTML_OPTIONS
  };

})();

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.ExportGenerator = ExportGenerator;
}
