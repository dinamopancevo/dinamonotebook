document.addEventListener('DOMContentLoaded', async () => {
  // Wait for i18n to initialize and translations to load
  const waitForI18n = () => {
    return new Promise((resolve) => {
      const checkI18n = () => {
        if (window.i18n && window.i18n.getCurrentLanguage && window.i18n.t) {
          // Check if translations are actually loaded by trying to get a known key
          const testTranslation = window.i18n.t('common.save');
          // If we get back the key itself (not translated), translations might not be loaded yet
          if (testTranslation === 'common.save') {
            // Translations not loaded yet, wait a bit more
            setTimeout(checkI18n, 100);
            return;
          }
          
          // Translations are loaded, update elements
          if (window.i18n.updateI18nElements) {
            window.i18n.updateI18nElements();
          }
          
          // Register callback for language changes
          window.i18n.onLanguageChange(() => {
            if (window.i18n.updateI18nElements) {
              window.i18n.updateI18nElements();
            }
            // Update dynamic content that uses i18n.t() directly
            updateDynamicI18nContent();
          });
          resolve();
        } else {
          setTimeout(checkI18n, 50);
        }
      };
      checkI18n();
    });
  };
  
  // Function to update dynamic content that uses i18n.t() directly
  const updateDynamicI18nContent = () => {
    // Update project button text if needed
    if (projectButtonText) {
      if (!currentAnalysisId) {
        // No project selected - show translated text
        projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
      } else {
        // Project is selected - reload from storage to get the name
        chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
          const analyses = result.analyses || [];
          const selectedAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
          if (selectedAnalysis) {
            projectButtonText.textContent = selectedAnalysis.name;
          } else {
            // Project ID exists but project not found
            projectButtonText.textContent = window.i18n ? window.i18n.t('project.selectProject') : 'Select project';
          }
        });
      }
    }
  };
  
  await waitForI18n();

  // Migration function to convert old team structure to new attachedTeamIds structure
  function migrateTeamStructure() {
    chrome.storage.local.get(['analyses', 'teams', 'migrationCompleted'], (result) => {
      if (result.migrationCompleted) {
        return; // Migration already completed
      }

      const analyses = result.analyses || [];
      const globalTeams = result.teams || [];
      let needsMigration = false;

      // For each analysis, if it doesn't have attachedTeamIds but has old team data,
      // migrate by attaching all available teams
      analyses.forEach(analysis => {
        if (!analysis.attachedTeamIds && globalTeams.length > 0) {
          analysis.attachedTeamIds = globalTeams.map(team => {
            return typeof team === 'string' ? team : (team.id || team.name || '');
          }).filter(id => id); // Filter out empty IDs
          needsMigration = true;
          console.log('Migrated analysis:', analysis.name, 'with teams:', analysis.attachedTeamIds);
        }
      });

      if (needsMigration) {
        chrome.storage.local.set({
          analyses: analyses,
          migrationCompleted: true
        }, () => {
          console.log('Team structure migration completed');
        });
      } else {
        // Mark as completed even if no migration was needed
        chrome.storage.local.set({ migrationCompleted: true });
      }
    });
  }

  // Run migration
  migrateTeamStructure();

  const videoUrlInput = document.getElementById('videoUrlInput');
  const chatInput = document.getElementById('chatInput');
  const sendButton = document.getElementById('sendButton');
  const chatMessages = document.getElementById('chatMessages');

  // Auto-resize textarea function
  function autoResizeTextarea(textarea) {
    if (!textarea) return;
    // Reset height to auto to get the correct scrollHeight
    textarea.style.height = 'auto';
    // Set height based on scrollHeight, with min and max constraints
    const minHeight = 20; // Minimum height (1 row)
    const maxHeight = 200; // Maximum height (approximately 10 rows)
    const newHeight = Math.min(Math.max(textarea.scrollHeight, minHeight), maxHeight);
    textarea.style.height = newHeight + 'px';
    // Enable scrolling if content exceeds max height
    textarea.style.overflowY = textarea.scrollHeight > maxHeight ? 'auto' : 'hidden';
  }
  const projectButton = document.getElementById('projectButton');
  const projectButtonText = document.getElementById('projectButtonText');
  const projectDropdownArrow = document.getElementById('projectDropdownArrow');
  const projectDropdown = document.getElementById('projectDropdown');
  const createProjectDropdownItem = document.getElementById('createProjectDropdownItem');
  const renameProjectDropdownItem = document.getElementById('renameProjectDropdownItem');
  const deleteProjectDropdownItem = document.getElementById('deleteProjectDropdownItem');
  const projectSelectionModal = document.getElementById('projectSelectionModal');
  const projectList = document.getElementById('projectList');
  const createNewProjectBtn = document.getElementById('createNewProjectBtn');
  const closeProjectModal = document.getElementById('closeProjectModal');
  const projectVideosSection = document.getElementById('projectVideosSection');
  const projectVideosList = document.getElementById('projectVideosList');
  const projectAddVideoBtn = document.getElementById('projectAddVideoBtn');
  const mediaGallery = document.getElementById('mediaGallery');
  const mediaGalleryContent = document.getElementById('mediaGalleryContent');
  const addVideoModal = document.getElementById('addVideoModal');
  const closeAddVideoModal = document.getElementById('closeAddVideoModal');
  const videoUrlLoading = document.getElementById('videoUrlLoading');
  const imageInput = document.getElementById('imageInput');
  const attachImageButton = document.getElementById('attachImageButton');
  const imagePreviewContainer = document.getElementById('imagePreviewContainer');
  
  let pendingVideoUrl = null; // Store URL while user selects project
  let pendingImages = []; // Store compressed image data array
  let isSavingMessage = false; // Flag to prevent clearing chat during save
  
  let currentAnalysisId = null;

  // Compress image to reduce memory usage
  function compressImage(file, maxWidth = 1200, maxHeight = 1200, quality = 0.95) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          // Calculate new dimensions
          if (width > height) {
            if (width > maxWidth) {
              height = (height * maxWidth) / width;
              width = maxWidth;
            }
          } else {
            if (height > maxHeight) {
              width = (width * maxHeight) / height;
              height = maxHeight;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);

          // Convert to base64 with compression
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // Render image with drawings for preview
  function renderImagePreviewWithDrawings(backgroundImageData, drawings) {
    return new Promise((resolve, reject) => {
      if (!drawings || drawings.length === 0) {
        console.log('renderImagePreviewWithDrawings: No drawings, returning background');
        resolve(backgroundImageData);
        return;
      }

      console.log('renderImagePreviewWithDrawings: Rendering', drawings.length, 'drawings on background');
      
      const bgImg = new Image();
      bgImg.onerror = () => {
        console.error('renderImagePreviewWithDrawings: Failed to load background image');
        reject(new Error('Failed to load background image'));
      };
      bgImg.onload = () => {
        console.log('renderImagePreviewWithDrawings: Background loaded, size:', bgImg.width, 'x', bgImg.height);
        const canvas = document.createElement('canvas');
        canvas.width = bgImg.width;
        canvas.height = bgImg.height;
        const ctx = canvas.getContext('2d');
        
        // Draw background
        ctx.drawImage(bgImg, 0, 0);
        
        let drawingsDrawn = 0;
        // Draw drawings (simplified version for preview)
        // Include movement lines (animpath) to show tactical movements in citation previews
        drawings.forEach((drawing, index) => {
          if (!drawing) {
            return;
          }
          
          // Eraser strokes are composited in the editor only; skip in preview
          if (drawing.type === 'eraser') return;
          // Handle movement paths (animpath) - these show tactical movements
          if (drawing.type === 'animpath') {
            if (drawing.points && drawing.points.length > 1) {
              ctx.save();
              const opacity = drawing.opacity !== undefined ? drawing.opacity : 0.8;
              ctx.globalAlpha = Math.min(opacity, 1.0);
              ctx.strokeStyle = drawing.color || '#FF0000';
              ctx.fillStyle = drawing.color || '#FF0000';
              // Make movement lines more visible
              ctx.lineWidth = (drawing.lineWidth || 3) * 1.5;
              ctx.setLineDash([]);
              
              // Draw path
              ctx.beginPath();
              ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
              for (let i = 1; i < drawing.points.length; i++) {
                ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
              }
              ctx.stroke();
              
              // Draw arrowhead at the end to show direction
              if (drawing.points.length >= 2) {
                const lastPoint = drawing.points[drawing.points.length - 1];
                const secondLastPoint = drawing.points[drawing.points.length - 2];
                const angle = Math.atan2(lastPoint.y - secondLastPoint.y, lastPoint.x - secondLastPoint.x);
                const arrowLength = 12;
                
                ctx.beginPath();
                ctx.moveTo(lastPoint.x, lastPoint.y);
                ctx.lineTo(
                  lastPoint.x - arrowLength * Math.cos(angle - Math.PI / 6),
                  lastPoint.y - arrowLength * Math.sin(angle - Math.PI / 6)
                );
                ctx.lineTo(
                  lastPoint.x - arrowLength * Math.cos(angle + Math.PI / 6),
                  lastPoint.y - arrowLength * Math.sin(angle + Math.PI / 6)
                );
                ctx.closePath();
                ctx.fill();
              }
              
              ctx.restore();
              drawingsDrawn++;
            }
            return;
          }
          
          drawingsDrawn++;
          
          ctx.save();
          const opacity = drawing.opacity !== undefined ? drawing.opacity : 1.0;
          ctx.globalAlpha = Math.min(opacity, 1.0);
          ctx.strokeStyle = drawing.color || '#FF0000';
          ctx.fillStyle = drawing.color || '#FF0000';
          ctx.lineWidth = drawing.lineWidth || 2;
          
          // Apply line style
          if (drawing.lineStyle === 'dashed') {
            ctx.setLineDash([8, 4]);
          } else if (drawing.lineStyle === 'dotted') {
            ctx.setLineDash([2, 2]);
          } else {
            ctx.setLineDash([]);
          }
          
          // Draw based on type (simplified for preview)
          switch (drawing.type) {
            case 'line':
              ctx.beginPath();
              ctx.moveTo(drawing.startX, drawing.startY);
              ctx.lineTo(drawing.endX, drawing.endY);
              ctx.stroke();
              break;
            case 'arrow':
              ctx.beginPath();
              ctx.moveTo(drawing.startX, drawing.startY);
              ctx.lineTo(drawing.endX, drawing.endY);
              ctx.stroke();
              
              // Draw arrowhead
              if (drawing.endX !== undefined && drawing.endY !== undefined && drawing.startX !== undefined && drawing.startY !== undefined) {
                const angle = Math.atan2(drawing.endY - drawing.startY, drawing.endX - drawing.startX);
                const arrowLength = 10;
                const arrowWidth = 5;
                
                ctx.beginPath();
                ctx.moveTo(drawing.endX, drawing.endY);
                ctx.lineTo(
                  drawing.endX - arrowLength * Math.cos(angle - Math.PI / 6),
                  drawing.endY - arrowLength * Math.sin(angle - Math.PI / 6)
                );
                ctx.lineTo(
                  drawing.endX - arrowLength * Math.cos(angle + Math.PI / 6),
                  drawing.endY - arrowLength * Math.sin(angle + Math.PI / 6)
                );
                ctx.closePath();
                ctx.fill();
              }
              break;
            case 'curve':
              if (drawing.controlPoint) {
                ctx.beginPath();
                ctx.moveTo(drawing.startX, drawing.startY);
                ctx.quadraticCurveTo(drawing.controlPoint.x, drawing.controlPoint.y, drawing.endX, drawing.endY);
                ctx.stroke();
              }
              break;
            case 'circle':
              const radius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
              const centerX = (drawing.startX + drawing.endX) / 2;
              const centerY = (drawing.startY + drawing.endY) / 2;
              ctx.beginPath();
              ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
              if (drawing.fillOpacity > 0) {
                ctx.globalAlpha = drawing.fillOpacity;
                ctx.fillStyle = drawing.fillColor || drawing.color;
                ctx.fill();
              }
              ctx.globalAlpha = opacity;
              ctx.beginPath();
              ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
              ctx.stroke();
              break;
            case 'ball':
              // Draw simplified ball representation
              const ballSize = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY));
              const ballX = Math.min(drawing.startX, drawing.endX);
              const ballY = Math.min(drawing.startY, drawing.endY);
              ctx.fillStyle = drawing.color || '#FFFFFF';
              ctx.beginPath();
              ctx.arc(ballX + ballSize / 2, ballY + ballSize / 2, ballSize / 2, 0, Math.PI * 2);
              ctx.fill();
              break;
            case 'tshirt':
              // Draw proper t-shirt shape
              const tshirtCenterX = (drawing.startX + drawing.endX) / 2;
              const tshirtCenterY = (drawing.startY + drawing.endY) / 2;
              const shirtWidth = Math.abs(drawing.endX - drawing.startX);
              const shirtHeight = Math.abs(drawing.endY - drawing.startY);
              const startX = tshirtCenterX - shirtWidth / 2;
              const startY = tshirtCenterY - shirtHeight / 2;
              
              const primaryColor = drawing.color || '#FFFFFF';
              const secondColor = drawing.secondColor || '#000000';
              const design = drawing.design || 'solid';
              
              // T-shirt proportions
              const collarWidth = shirtWidth * 0.35;
              const shoulderWidth = (shirtWidth - collarWidth) / 2;
              const sleeveLength = shirtWidth * 0.18;
              
              // Create t-shirt path
              ctx.beginPath();
              ctx.moveTo(startX, startY + shirtHeight * 0.08);
              ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
              ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
              ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
              const rightBottomX = startX + shirtWidth - shirtWidth * 0.03;
              ctx.lineTo(rightBottomX, startY + shirtHeight);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
              ctx.lineTo(startX, startY + shirtHeight * 0.38);
              ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
              ctx.closePath();
              
              // Fill base color
              ctx.fillStyle = primaryColor;
              ctx.fill();
              
              // Apply design pattern (simplified for preview)
              if (design !== 'solid') {
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(startX, startY + shirtHeight * 0.08);
                ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
                ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
                ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
                ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
                ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
                ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
                ctx.lineTo(rightBottomX, startY + shirtHeight);
                ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
                ctx.lineTo(startX, startY + shirtHeight * 0.38);
                ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
                ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
                ctx.closePath();
                ctx.clip();
                
                const extLeft = startX - sleeveLength;
                const extRight = startX + shirtWidth + sleeveLength;
                const extTop = startY;
                const extBottom = startY + shirtHeight;
                const extWidth = extRight - extLeft;
                const extHeight = extBottom - extTop;
                
                ctx.fillStyle = secondColor;
                if (design === 'sleeves') {
                  ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
                  ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
                } else if (design === 'horiz-stripes') {
                  const hStripeHeight = extHeight / 5;
                  for (let i = 1; i < 5; i += 2) {
                    ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
                  }
                } else if (design === 'vert-stripes') {
                  const vStripeWidth = extWidth / 5;
                  for (let i = 1; i < 5; i += 2) {
                    ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
                  }
                }
                ctx.restore();
              }
              
              // Draw outline
              ctx.beginPath();
              ctx.moveTo(startX, startY + shirtHeight * 0.08);
              ctx.quadraticCurveTo(startX + shoulderWidth * 0.5, startY, startX + shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight * 0.15, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.03);
              ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth * 0.5, startY, startX + shirtWidth, startY + shirtHeight * 0.08);
              ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.25);
              ctx.lineTo(startX + shirtWidth + sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.38);
              ctx.lineTo(rightBottomX, startY + shirtHeight);
              ctx.quadraticCurveTo(tshirtCenterX, startY + shirtHeight + shirtHeight * 0.02, startX + shirtWidth * 0.03, startY + shirtHeight);
              ctx.lineTo(startX, startY + shirtHeight * 0.38);
              ctx.lineTo(startX - sleeveLength * 0.6, startY + shirtHeight * 0.35);
              ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.25);
              ctx.closePath();
              ctx.strokeStyle = '#000000';
              ctx.lineWidth = 2;
              ctx.stroke();
              
              // Draw number if available
              if (drawing.number !== undefined && drawing.number !== null && drawing.number !== '') {
                const hex = primaryColor.replace('#', '');
                const r = parseInt(hex.substr(0, 2), 16);
                const g = parseInt(hex.substr(2, 2), 16);
                const b = parseInt(hex.substr(4, 2), 16);
                const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
                const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
                ctx.fillStyle = textColor;
                ctx.font = `bold ${shirtHeight * 0.25}px sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(String(drawing.number), tshirtCenterX, tshirtCenterY);
              }
              break;
            case 'text':
              ctx.font = `${drawing.fontSize || 16}px sans-serif`;
              ctx.fillStyle = drawing.color || '#FFFFFF';
              ctx.fillText(drawing.text || '', drawing.x || 0, drawing.y || 0);
              break;
            case 'spray':
              // Draw spray particles
              if (drawing.particles && drawing.particles.length > 0) {
                ctx.fillStyle = drawing.color || '#000000';
                ctx.globalAlpha = opacity; // Ensure opacity is applied
                const particleSize = drawing.particleSize || 2;
                drawing.particles.forEach(particle => {
                  ctx.beginPath();
                  ctx.arc(particle.x, particle.y, particleSize, 0, Math.PI * 2);
                  ctx.fill();
                });
              }
              break;
            case 'rectangle':
            case 'oval':
            case 'triangle':
            case 'polygon':
            case 'arc':
            case 'cross':
            case 'freehand':
              // Draw basic shape outline
              if (drawing.type === 'rectangle') {
                const rectLeft = Math.min(drawing.startX, drawing.endX);
                const rectTop = Math.min(drawing.startY, drawing.endY);
                const rectWidth = Math.abs(drawing.endX - drawing.startX);
                const rectHeight = Math.abs(drawing.endY - drawing.startY);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fillRect(rectLeft, rectTop, rectWidth, rectHeight);
                }
                ctx.globalAlpha = opacity;
                ctx.strokeRect(rectLeft, rectTop, rectWidth, rectHeight);
              } else if (drawing.type === 'oval') {
                const radiusX = Math.abs(drawing.endX - drawing.startX) / 2;
                const radiusY = Math.abs(drawing.endY - drawing.startY) / 2;
                const centerX = (drawing.startX + drawing.endX) / 2;
                const centerY = (drawing.startY + drawing.endY) / 2;
                ctx.beginPath();
                ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
                ctx.stroke();
              } else if (drawing.type === 'triangle') {
                ctx.beginPath();
                ctx.moveTo((drawing.startX + drawing.endX) / 2, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.closePath();
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo((drawing.startX + drawing.endX) / 2, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.closePath();
                ctx.stroke();
              } else if (drawing.type === 'arc') {
                const radius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
                const centerX = (drawing.startX + drawing.endX) / 2;
                const centerY = (drawing.startY + drawing.endY) / 2;
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, 0, Math.PI);
                if (drawing.fillOpacity > 0) {
                  ctx.globalAlpha = drawing.fillOpacity;
                  ctx.fillStyle = drawing.fillColor || drawing.color;
                  ctx.fill();
                }
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.arc(centerX, centerY, radius, 0, Math.PI);
                ctx.stroke();
              } else if (drawing.type === 'cross') {
                ctx.beginPath();
                ctx.moveTo(drawing.startX, drawing.startY);
                ctx.lineTo(drawing.endX, drawing.endY);
                ctx.moveTo(drawing.endX, drawing.startY);
                ctx.lineTo(drawing.startX, drawing.endY);
                ctx.stroke();
              } else if (drawing.type === 'freehand' && drawing.points && drawing.points.length > 0) {
                ctx.beginPath();
                ctx.moveTo(drawing.points[0].x, drawing.points[0].y);
                for (let i = 1; i < drawing.points.length; i++) {
                  ctx.lineTo(drawing.points[i].x, drawing.points[i].y);
                }
                ctx.stroke();
              }
              break;
          }
          
          ctx.restore();
        });
        
        console.log('renderImagePreviewWithDrawings: Drew', drawingsDrawn, 'drawings out of', drawings.length, 'total');
        const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
        console.log('renderImagePreviewWithDrawings: Generated composite image, length:', dataUrl.length);
        resolve(dataUrl);
      };
      bgImg.onerror = () => {
        console.error('renderImagePreviewWithDrawings: Failed to load background image');
        reject(new Error('Failed to load background image'));
      };
      bgImg.src = backgroundImageData;
    });
  }

  // Handle image preview
  function updateImagePreview() {
    if (!imagePreviewContainer) return;
    
    if (pendingImages.length === 0) {
      imagePreviewContainer.style.display = 'none';
      return;
    }
    
    imagePreviewContainer.style.display = 'flex';
    imagePreviewContainer.innerHTML = ''; // Clear existing previews
    
    pendingImages.forEach((imageObj, index) => {
      if (!imageObj || !imageObj.imageData) {
        console.warn('Invalid image object at index', index, imageObj);
        return; // Skip invalid images
      }

      const previewItem = document.createElement('div');
      previewItem.className = 'image-preview-item';
      previewItem.style.position = 'relative';

      const img = document.createElement('img');
      
      // Get original background and slidesData
      const originalImageSrc = imageObj.originalSrc || imageObj.imageData;
      const slidesData = imageObj.slidesData;
      const drawings = slidesData && slidesData[0] && slidesData[0].drawings ? slidesData[0].drawings : [];
      
      console.log('updateImagePreview: Image', index, {
        hasSlidesData: !!slidesData,
        slidesDataLength: slidesData ? slidesData.length : 0,
        drawingsCount: drawings.length,
        hasOriginalSrc: !!originalImageSrc,
        hasImageData: !!imageObj.imageData
      });
      
      // Use imageData directly - it should already be merged with drawings for preview
      // The imageData is the merged image (with drawings), originalImageSrc is the clean background for editor
      img.src = imageObj.imageData;
      
      console.log('updateImagePreview: Using merged imageData for preview, length:', imageObj.imageData ? imageObj.imageData.length : 0);
      
      img.className = 'image-preview';
      img.alt = `Preview ${index + 1}`;
      img.style.cursor = 'pointer';
      img.title = 'Click to edit in tactical editor';
      
      // Add error handling - but don't hide on error, just log
      // The composite rendering will handle its own errors
      const baseOnError = function() {
        console.error('Failed to load preview image at index', index, 'src length:', this.src ? this.src.length : 0);
        // Only hide if it's the base image, not if it's a composite that failed
        // (composite errors are handled separately)
        if (!drawings || drawings.length === 0) {
          this.style.display = 'none';
        }
      };
      img.onerror = baseOnError;
      
      // Add click handler to open editor
      img.addEventListener('click', () => {
        const originalSrc = imageObj.originalSrc || imageObj.imageData;
        openImageEditor(imageObj.imageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
          // Replace the image in pending images
          pendingImages[index] = { 
            imageData: modifiedImageData, 
            slidesData: slidesData,
            originalSrc: savedOriginalImageSrc || originalSrc
          };
          updateImagePreview();
        }, imageObj.slidesData, originalSrc);
      });
      
      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-image-preview';
      removeBtn.textContent = '×';
      removeBtn.title = 'Remove image';
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        pendingImages.splice(index, 1);
        updateImagePreview();
        // Update attach button visual state (icons don't need text updates)
        // The SVG icon will remain the same
      });
      
      // Append image to DOM first so it can load properly
      previewItem.appendChild(img);
      previewItem.appendChild(removeBtn);
      imagePreviewContainer.appendChild(previewItem);
      
      // Now that image is in DOM, trigger composite rendering if needed
      // (The composite rendering promise will update the src when ready)
    });
  }

  function hideImagePreview() {
    pendingImages = [];
    updateImagePreview();
    if (attachImageButton) {
      attachImageButton.disabled = false;
    }
  }

  // Handle image processing
  async function processImageFile(file) {
    if (!file || !file.type.startsWith('image/')) {
      return;
    }
    
    try {
      if (attachImageButton) {
        attachImageButton.disabled = true;
      }
      const compressedImage = await compressImage(file);
      pendingImages.push({ imageData: compressedImage, slidesData: null });
      updateImagePreview();
      if (attachImageButton) {
        attachImageButton.disabled = false;
      }
    } catch (error) {
      console.error('Error compressing image:', error);
      alert('Error processing image. Please try again.');
      if (attachImageButton) {
        attachImageButton.disabled = false;
      }
    }
  }

  // Handle image attachment
  if (attachImageButton && imageInput) {
    attachImageButton.addEventListener('click', () => {
      imageInput.click();
    });

    imageInput.addEventListener('change', async (e) => {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        for (const file of files) {
          await processImageFile(file);
        }
      }
      // Reset input to allow selecting same file again
      e.target.value = '';
    });
  }

  // Voice input functionality
  const voiceInputButton = document.getElementById('voiceInputButton');
  const voiceInputIcon = document.getElementById('voiceInputIcon');
  const voiceInputPulse = document.getElementById('voiceInputPulse');
  let isRecording = false;
  let isProcessing = false;

  if (voiceInputButton && chatInput) {
    voiceInputButton.addEventListener('click', async () => {
      if (isProcessing) {
        return; // Prevent multiple simultaneous recordings
      }

      if (!isRecording) {
        // Start recording
        try {
          // Check for API key
          const apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
          if (!apiKey) {
            alert('OpenAI API key is required for voice input. Please configure it in AI Analysis Settings.');
            return;
          }

          await window.aiAnalysisUtils.startRecording();
          isRecording = true;
          
          // Update UI
          voiceInputButton.classList.add('recording');
          if (voiceInputIcon) {
            voiceInputIcon.style.color = '#da3633'; // Red color
          }
          if (voiceInputPulse) {
            voiceInputPulse.classList.remove('hidden');
          }
          voiceInputButton.disabled = false;
        } catch (error) {
          console.error('Error starting recording:', error);
          alert(error.message || 'Failed to start recording. Please check microphone permissions.');
          isRecording = false;
        }
      } else {
        // Stop recording and transcribe
        try {
          isRecording = false;
          isProcessing = true;
          
          // Update UI to processing state
          voiceInputButton.classList.remove('recording');
          voiceInputButton.classList.add('processing');
          voiceInputButton.disabled = true;
          if (voiceInputPulse) {
            voiceInputPulse.classList.add('hidden');
          }
          
          // Stop recording
          const audioBlob = await window.aiAnalysisUtils.stopRecording();
          
          // Convert to file
          const audioFile = window.aiAnalysisUtils.convertAudioToFile(audioBlob);
          
          // Get API key
          const apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
          
          // Transcribe
          const transcribedText = await window.aiAnalysisUtils.transcribeAudio(audioFile, apiKey);
          
          // Insert transcribed text into input
          const currentText = chatInput.value.trim();
          if (currentText) {
            chatInput.value = currentText + ' ' + transcribedText;
          } else {
            chatInput.value = transcribedText;
          }
          
          // Auto-resize textarea to fit all text
          autoResizeTextarea(chatInput);
          
          // Focus input
          chatInput.focus();
          // Move cursor to end
          chatInput.setSelectionRange(chatInput.value.length, chatInput.value.length);
          
        } catch (error) {
          console.error('Error transcribing audio:', error);
          alert(error.message || 'Failed to transcribe audio. Please try again.');
        } finally {
          // Reset UI
          isProcessing = false;
          voiceInputButton.classList.remove('recording', 'processing');
          voiceInputButton.disabled = false;
          if (voiceInputIcon) {
            voiceInputIcon.style.color = ''; // Reset to default
          }
        }
      }
    });
  }

  // Handle tactical editor dropdown
  const attachTacticalEditorButton = document.getElementById('attachTacticalEditorButton');
  const tacticalEditorDropdown = document.getElementById('tacticalEditorDropdown');
  const tacticalEditorContainer = attachTacticalEditorButton?.closest('.tactical-editor-dropdown-container');
  
  if (attachTacticalEditorButton && tacticalEditorDropdown) {
    // Function to position dropdown above the button
    const positionDropdown = () => {
      const buttonRect = attachTacticalEditorButton.getBoundingClientRect();
      // Each item is approximately 40px (10px padding top + 10px padding bottom + 20px content)
      // 3 items = 120px, plus some margin
      const estimatedDropdownHeight = 120;
      
      // Position above the button
      tacticalEditorDropdown.style.top = `${buttonRect.top + window.scrollY - estimatedDropdownHeight - 8}px`;
      tacticalEditorDropdown.style.left = `${buttonRect.left + window.scrollX}px`;
    };

    // Toggle dropdown on button click
    attachTacticalEditorButton.addEventListener('click', (e) => {
      e.stopPropagation();
      const isHidden = tacticalEditorDropdown.classList.contains('hidden');
      
      if (isHidden) {
        // Opening dropdown - position it first while still hidden, then show
        positionDropdown();
        tacticalEditorDropdown.classList.remove('hidden');
      } else {
        // Closing dropdown
        tacticalEditorDropdown.classList.add('hidden');
      }
    });

    // Reposition on scroll/resize
    window.addEventListener('scroll', positionDropdown, true);
    window.addEventListener('resize', positionDropdown);

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (tacticalEditorContainer && !tacticalEditorContainer.contains(e.target)) {
        tacticalEditorDropdown.classList.add('hidden');
      }
    });

    // Handle dropdown item clicks
    const dropdownItems = tacticalEditorDropdown.querySelectorAll('.tactical-editor-dropdown-item');
    dropdownItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const type = item.dataset.type;
        let imageUrl;
        
        switch(type) {
          case 'scheme':
            imageUrl = chrome.runtime.getURL('icons/soccer-145794.svg');
            break;
          case 'goal':
            imageUrl = chrome.runtime.getURL('icons/goal.svg');
            break;
          case 'half':
            imageUrl = chrome.runtime.getURL('icons/Half.svg');
            break;
        }
        
        if (imageUrl) {
          tacticalEditorDropdown.classList.add('hidden');
          openImageEditor(imageUrl, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            pendingImages.push({ 
              imageData: modifiedImageData, 
              slidesData: slidesData,
              originalSrc: savedOriginalImageSrc || imageUrl
            });
            updateImagePreview();
          });
        }
      });
    });
  }


  // Drag and drop functionality - on input field
  if (chatInput) {
    chatInput.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      chatInput.style.borderColor = '#8DD8F9';
    });

    chatInput.addEventListener('dragleave', (e) => {
      e.preventDefault();
      e.stopPropagation();
      chatInput.style.borderColor = '#e0e0e0';
    });

    chatInput.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      chatInput.style.borderColor = '#e0e0e0';
      
      const files = Array.from(e.dataTransfer.files);
      if (files.length > 0) {
        const imageFiles = files.filter(f => f.type.startsWith('image/'));
        if (imageFiles.length > 0) {
          for (const file of imageFiles) {
            await processImageFile(file);
          }
        } else {
          alert('Please drop image files.');
        }
      }
    });

    // Auto-resize textarea
    if (chatInput) {
      // Set initial height
      chatInput.style.height = '20px';
      chatInput.style.overflowY = 'hidden';
      
      chatInput.addEventListener('input', () => {
        autoResizeTextarea(chatInput);
      });
      
      // Also resize on paste
      chatInput.addEventListener('paste', () => {
        // Use setTimeout to allow paste to complete first
        setTimeout(() => {
          autoResizeTextarea(chatInput);
        }, 0);
      });
    }
  }

  // Drag and drop functionality - on preview container
  if (imagePreviewContainer) {
    imagePreviewContainer.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      imagePreviewContainer.style.borderColor = '#8DD8F9';
      imagePreviewContainer.style.backgroundColor = '#e8f5e9';
    });

    imagePreviewContainer.addEventListener('dragleave', (e) => {
      e.preventDefault();
      e.stopPropagation();
      imagePreviewContainer.style.borderColor = '#e0e0e0';
      imagePreviewContainer.style.backgroundColor = '#f5f5f5';
    });

    imagePreviewContainer.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      imagePreviewContainer.style.borderColor = '#e0e0e0';
      imagePreviewContainer.style.backgroundColor = '#f5f5f5';
      
      const files = Array.from(e.dataTransfer.files);
      if (files.length > 0) {
        const imageFiles = files.filter(f => f.type.startsWith('image/'));
        if (imageFiles.length > 0) {
          for (const file of imageFiles) {
            await processImageFile(file);
          }
        } else {
          alert('Please drop image files.');
        }
      }
    });
  }

  // Handle URL input
  videoUrlInput.addEventListener('paste', (e) => {
    setTimeout(() => {
      let input = videoUrlInput.value.trim();
      if (input) {
        // Check if it's an iframe embed code
        if (input.includes('<iframe') && input.includes('youtube.com/embed')) {
          console.log('Detected YouTube iframe embed code');
          input = extractUrlFromIframe(input);
        }
        // Check if it's a valid video URL
        if (isYouTubeUrl(input) || isDailymotionUrl(input) || isTwitchUrl(input)) {
          // If addVideoModal is open, add to current project
          if (addVideoModal && !addVideoModal.classList.contains('hidden')) {
            if (currentAnalysisId) {
              addVideoToCurrentProject(input);
              videoUrlInput.value = '';
            } else {
              alert('Please create a project first or select an existing project.');
            }
          } else {
            // Modal is closed, show project selection
            pendingVideoUrl = input;
            if (addVideoModal) {
              addVideoModal.classList.add('hidden');
            }
            showProjectSelectionModal();
          }
        } else {
          // Not a video URL, handle normally
          handleVideoUrl(input);
          if (addVideoModal) {
            addVideoModal.classList.add('hidden');
          }
        }
      }
    }, 10);
  });

  videoUrlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      let input = videoUrlInput.value.trim();
      if (input) {
        // Check if it's an iframe embed code
        if (input.includes('<iframe') && input.includes('youtube.com/embed')) {
          console.log('Detected YouTube iframe embed code');
          input = extractUrlFromIframe(input);
        }
        // Check if it's a valid video URL
        if (isYouTubeUrl(input) || isDailymotionUrl(input) || isTwitchUrl(input)) {
          // If addVideoModal is open, add to current project
          if (addVideoModal && !addVideoModal.classList.contains('hidden')) {
            if (currentAnalysisId) {
              addVideoToCurrentProject(input);
              videoUrlInput.value = '';
            } else {
              alert('Please create a project first or select an existing project.');
            }
          } else {
            // Modal is closed, show project selection
            pendingVideoUrl = input;
            if (addVideoModal) {
              addVideoModal.classList.add('hidden');
            }
            showProjectSelectionModal();
          }
        } else {
          // Not a video URL, handle normally
          handleVideoUrl(input);
          if (addVideoModal) {
            addVideoModal.classList.add('hidden');
          }
        }
      }
    }
  });

  // Extract URL from iframe embed code
  function extractUrlFromIframe(iframeCode) {
    const srcMatch = iframeCode.match(/src=["']([^"']+)["']/);
    if (srcMatch && srcMatch[1]) {
      const embedUrl = srcMatch[1];
      console.log('Extracted embed URL:', embedUrl);
      
      // Extract video ID and si parameter from embed URL
      const videoIdMatch = embedUrl.match(/\/embed\/([^?]+)/);
      const siMatch = embedUrl.match(/[?&]si=([^&]+)/);
      
      if (videoIdMatch && videoIdMatch[1]) {
        const videoId = videoIdMatch[1];
        const siParam = siMatch ? siMatch[1] : null;
        
        // Convert to watch URL
        let watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
        
        // Extract start time if present
        const startMatch = embedUrl.match(/[?&]start=(\d+)/);
        if (startMatch) {
          watchUrl += `&t=${startMatch[1]}`;
      }

        return watchUrl;
      }
    }
    return null;
  }

  // Helper function to normalize video URL (remove time parameters for matching)
  function normalizeVideoUrl(url) {
    try {
      const urlObj = new URL(url);
      // Remove time-related parameters
      urlObj.searchParams.delete('t');
      urlObj.searchParams.delete('start');
      urlObj.searchParams.delete('time_continue');
      urlObj.hash = ''; // Remove hash (used for Dailymotion time)
      return urlObj.toString();
    } catch (e) {
      return url;
    }
  }

  // Helper function to extract video ID from URL
  function extractVideoIdFromUrl(url, platform) {
    try {
      const urlObj = new URL(url);
      if (platform === 'youtube' || urlObj.hostname.includes('youtube.com') || urlObj.hostname.includes('youtu.be')) {
        if (urlObj.hostname.includes('youtu.be')) {
          return urlObj.pathname.substring(1);
        }
        return urlObj.searchParams.get('v');
      } else if (platform === 'dailymotion' || urlObj.hostname.includes('dailymotion.com')) {
        const match = url.match(/dailymotion\.com\/video\/([^/?]+)/);
        return match ? match[1] : null;
      } else if (platform === 'twitch' || urlObj.hostname.includes('twitch.tv')) {
        // Match both /videos/ (plural) and /video/ (singular) patterns
        // Also handle URLs with channel name: twitch.tv/channelname/video/123456
        const match = url.match(/twitch\.tv\/(?:[^\/]+\/)?(?:videos|video)\/(\d+)/);
        return match ? match[1] : null;
      }
    } catch (e) {
      return null;
    }
    return null;
  }

  // Helper function to check if tab with video exists and seek, or open new tab
  function openVideoOrSeek(videoUrl, seconds, callback, targetVideoId = null, targetPlatform = null) {
    const normalizedUrl = normalizeVideoUrl(videoUrl);
    
    // Extract video ID from URL if not provided
    if (!targetVideoId && targetPlatform) {
      targetVideoId = extractVideoIdFromUrl(videoUrl, targetPlatform);
    } else if (!targetVideoId) {
      // Try to detect platform and extract ID
      try {
        const urlObj = new URL(videoUrl);
        if (urlObj.hostname.includes('youtube.com') || urlObj.hostname.includes('youtu.be')) {
          targetPlatform = 'youtube';
          targetVideoId = extractVideoIdFromUrl(videoUrl, 'youtube');
        } else if (urlObj.hostname.includes('dailymotion.com')) {
          targetPlatform = 'dailymotion';
          targetVideoId = extractVideoIdFromUrl(videoUrl, 'dailymotion');
        } else if (urlObj.hostname.includes('twitch.tv')) {
          targetPlatform = 'twitch';
          targetVideoId = extractVideoIdFromUrl(videoUrl, 'twitch');
        }
      } catch (e) {
        // Ignore
      }
    }
    
    console.log('openVideoOrSeek called:', {
      videoUrl,
      targetVideoId,
      targetPlatform,
      seconds
    });
    
    // Check if a tab with this video already exists
    chrome.tabs.query({}, (tabs) => {
      let matchingTab = null;
      
      // STRICT MATCHING: Only match if we have video ID AND platform
      if (targetVideoId && targetPlatform) {
        matchingTab = tabs.find(tab => {
          try {
            const tabUrl = new URL(tab.url);
            const tabVideoId = extractVideoIdFromUrl(tab.url, targetPlatform);
            
            // Must match BOTH video ID and platform
            const platformMatches = 
              (targetPlatform === 'youtube' && (tabUrl.hostname.includes('youtube.com') || tabUrl.hostname.includes('youtu.be'))) ||
              (targetPlatform === 'dailymotion' && tabUrl.hostname.includes('dailymotion.com')) ||
              (targetPlatform === 'twitch' && tabUrl.hostname.includes('twitch.tv'));
            
            if (tabVideoId === targetVideoId && platformMatches) {
              console.log(`✅ STRICT MATCH: Found tab with video ID ${targetVideoId} (${targetPlatform})`);
              return true;
            }
            return false;
          } catch (e) {
            return false;
          }
        });
      }
      
      // If no strict match found, try normalized URL (but only if we don't have video ID)
      if (!matchingTab && !targetVideoId) {
        matchingTab = tabs.find(tab => {
          try {
            const tabUrl = normalizeVideoUrl(tab.url);
            if (tabUrl === normalizedUrl) {
              console.log('Found matching tab by normalized URL (fallback)');
              return true;
            }
            return false;
          } catch (e) {
            return false;
          }
        });
      }
      
      // If we have video ID but no match found, DO NOT use fallback - open new tab
      if (!matchingTab && targetVideoId) {
        console.log(`❌ No matching tab found for video ID ${targetVideoId} (${targetPlatform}), opening new tab`);
      }

      if (matchingTab && matchingTab.id) {
        // Verify tab still exists before using it
        chrome.tabs.get(matchingTab.id, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            // Tab was closed or doesn't exist anymore, open new one
            console.log('Tab no longer exists, opening new tab');
            openNewTabWithTime();
            return;
          }
          
          // Tab exists, activate it and seek
          chrome.tabs.update(matchingTab.id, { active: true }, () => {
            if (chrome.runtime.lastError) {
              // Tab was closed or doesn't exist anymore, open new one
              console.log('Tab no longer exists, opening new tab:', chrome.runtime.lastError.message);
              openNewTabWithTime();
              return;
            }
          
          chrome.windows.update(matchingTab.windowId, { focused: true }, () => {
            if (chrome.runtime.lastError) {
              console.log('Could not focus window:', chrome.runtime.lastError.message);
            }
            
            // Wait a bit for tab to activate, then send seek message
            setTimeout(() => {
              chrome.tabs.sendMessage(matchingTab.id, { 
                action: 'seekToTime', 
                seconds: seconds 
              }, (response) => {
                if (chrome.runtime.lastError) {
                  console.log('Could not send seek message, tab may not be ready:', chrome.runtime.lastError.message);
                  // Fallback: update URL with time parameter
                  let urlWithTime = '';
                  try {
                    const url = new URL(videoUrl);
                    const hostname = url.hostname.toLowerCase();
                    if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
                      url.searchParams.set('t', Math.floor(seconds));
                      urlWithTime = url.toString();
                    } else if (hostname.includes('dailymotion.com')) {
                      url.hash = `#t=${Math.floor(seconds)}`;
                      urlWithTime = url.toString();
                    } else {
                      url.searchParams.set('t', Math.floor(seconds));
                      urlWithTime = url.toString();
                    }
                    chrome.tabs.update(matchingTab.id, { url: urlWithTime }, () => {
                      if (chrome.runtime.lastError) {
                        // Tab was closed, open new one
                        console.log('Tab closed while updating URL, opening new tab');
                        openNewTabWithTime();
                      }
                    });
                  } catch (e) {
                    console.error('Error updating tab URL:', e);
                    // Fallback to opening new tab
                    openNewTabWithTime();
                  }
                } else {
                  console.log('Seeked to time:', seconds);
                }
                if (callback) {
                  callback(matchingTab);
                }
              });
            }, 300);
          });
        });
      });
      } else {
        openNewTabWithTime();
      }
      
      function openNewTabWithTime() {
        // Tab doesn't exist, open new one with time parameter
        let urlWithTime = '';
        try {
          const url = new URL(videoUrl);
          const hostname = url.hostname.toLowerCase();
          if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
            url.searchParams.delete('t');
            url.searchParams.delete('start');
            url.searchParams.set('t', Math.floor(seconds));
            urlWithTime = url.toString();
          } else if (hostname.includes('dailymotion.com')) {
            url.hash = `#t=${Math.floor(seconds)}`;
            urlWithTime = url.toString();
          } else if (hostname.includes('twitch.tv')) {
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = Math.floor(seconds % 60);
            const twitchTime = `${hours}h${minutes}m${secs}s`;
            url.searchParams.set('t', twitchTime);
            urlWithTime = url.toString();
          } else {
            url.searchParams.set('t', Math.floor(seconds));
            urlWithTime = url.toString();
          }
        } catch (e) {
          urlWithTime = videoUrl;
        }
        
        openTabAndActivate(urlWithTime, callback);
      }
    });
  }

  // Helper function to open tab and bring window to front
  function openTabAndActivate(url, callback) {
    chrome.tabs.create({ url: url, active: true }, (tab) => {
      // Bring the window containing this tab to the front
      chrome.windows.update(tab.windowId, { focused: true }, () => {
        if (callback) {
          callback(tab);
        }
      });
    });
  }

  // Function to open video in new tab (removed local file player functionality)
  function openVideoInTab(url, platform) {
    openTabAndActivate(url, (tab) => {
      // Wait for the tab to load, then show the sidebar
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: 'showSidebar' }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('Could not show sidebar (tab not ready yet)');
          } else {
            console.log('Sidebar shown in video tab');
          }
        });
      }, 2000);
    });
  }
        
  // Handle video URL
  function handleVideoUrl(url) {
    if (!url || typeof url !== 'string') {
        return;
      }

    url = url.trim();

    if (isYouTubeUrl(url)) {
      openVideoInTab(url, 'youtube');
      videoUrlInput.value = '';
      if (addVideoModal) {
        addVideoModal.classList.add('hidden');
      }
      return;
    }
    
    if (isDailymotionUrl(url)) {
      openVideoInTab(url, 'dailymotion');
      videoUrlInput.value = '';
      if (addVideoModal) {
        addVideoModal.classList.add('hidden');
      }
      return;
    }
    
    if (isTwitchUrl(url)) {
      openVideoInTab(url, 'twitch');
      videoUrlInput.value = '';
      if (addVideoModal) {
        addVideoModal.classList.add('hidden');
      }
      return;
    }
    
    // If not a recognized video platform, show error
    alert('This URL is not a supported video platform. Please use YouTube, Dailymotion, or Twitch URLs.');
    videoUrlInput.value = '';
    if (addVideoModal) {
      addVideoModal.classList.add('hidden');
    }
  }

  // Check if URL is from YouTube
  function isYouTubeUrl(url) {
    return /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)/.test(url);
  }

  // Check if URL is from Dailymotion
  function isDailymotionUrl(url) {
    return /dailymotion\.com/.test(url);
  }

  // Check if URL is from Twitch
  function isTwitchUrl(url) {
    return /twitch\.tv/.test(url);
    }

  // Handle URL input
  videoUrlInput.addEventListener('paste', (e) => {
    setTimeout(() => {
      let input = videoUrlInput.value.trim();
      if (input) {
        // Check if it's an iframe embed code
        if (input.includes('<iframe') && input.includes('youtube.com/embed')) {
          console.log('Detected YouTube iframe embed code');
          input = extractUrlFromIframe(input);
        }
        // Check if it's a valid video URL
        if (isYouTubeUrl(input) || isDailymotionUrl(input) || isTwitchUrl(input)) {
          pendingVideoUrl = input;
          showProjectSelectionModal();
        } else {
          // Not a video URL, handle normally
        handleVideoUrl(input);
        }
      }
    }, 10);
  });

  videoUrlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      let input = videoUrlInput.value.trim();
      if (input) {
        // Check if it's an iframe embed code
        if (input.includes('<iframe') && input.includes('youtube.com/embed')) {
          console.log('Detected YouTube iframe embed code');
          input = extractUrlFromIframe(input);
        }
        // Check if it's a valid video URL
        if (isYouTubeUrl(input) || isDailymotionUrl(input) || isTwitchUrl(input)) {
          pendingVideoUrl = input;
          showProjectSelectionModal();
        } else {
          // Not a video URL, handle normally
        handleVideoUrl(input);
        }
      }
    }
  });

  // Extract URL from iframe embed code
  function extractUrlFromIframe(iframeCode) {
    const srcMatch = iframeCode.match(/src=["']([^"']+)["']/);
    if (srcMatch && srcMatch[1]) {
      const embedUrl = srcMatch[1];
      console.log('Extracted embed URL:', embedUrl);
      
      // Extract video ID and si parameter from embed URL
      const videoIdMatch = embedUrl.match(/\/embed\/([^?]+)/);
      const siMatch = embedUrl.match(/[?&]si=([^&]+)/);
      
      if (videoIdMatch) {
        const videoId = videoIdMatch[1];
        const siParam = siMatch ? siMatch[1] : null;
        
        // Return as a watch URL so our existing parsing works
        let watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
        if (siParam) {
          watchUrl += `&si=${siParam}`;
        }
        console.log('Converted to watch URL:', watchUrl);
        return watchUrl;
      }
    }
    return iframeCode;
  }

  // Show project selection modal
  function showProjectSelectionModal() {
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      populateProjectList(analyses);
      projectSelectionModal.classList.remove('hidden');
    });
  }

  // Populate project list in modal
  function populateProjectList(analyses) {
    projectList.innerHTML = '';
    
    // If there's a current project, show option to add to it
    if (currentAnalysisId) {
      const currentAnalysis = analyses.find(a => a.id === currentAnalysisId);
      if (currentAnalysis) {
        const addToCurrentItem = document.createElement('div');
        addToCurrentItem.className = 'project-item add-to-current';
        addToCurrentItem.style.background = '#e8f5e9';
        addToCurrentItem.style.border = '2px solid #8DD8F9';
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'project-item-name';
        nameDiv.textContent = `➕ Add to: ${currentAnalysis.name}`;
        nameDiv.style.fontWeight = 'bold';
        nameDiv.style.color = '#2e7d32';
        
        addToCurrentItem.appendChild(nameDiv);
        
        addToCurrentItem.addEventListener('click', () => {
          addVideoToCurrentProject(pendingVideoUrl);
          projectSelectionModal.classList.add('hidden');
          if (addVideoModal) {
            addVideoModal.classList.add('hidden');
          }
          pendingVideoUrl = null;
          videoUrlInput.value = '';
        });
        
        projectList.appendChild(addToCurrentItem);
        
        // Add separator
        const separator = document.createElement('div');
        separator.style.height = '1px';
        separator.style.background = '#e0e0e0';
        separator.style.margin = '10px 0';
        projectList.appendChild(separator);
      }
    }
    
    if (analyses.length === 0) {
      const emptyMsg = document.createElement('p');
      emptyMsg.textContent = window.i18n ? window.i18n.t('project.noProjectsYet') : 'No projects yet. Create a new one below.';
      emptyMsg.style.color = '#999';
      emptyMsg.style.textAlign = 'center';
      emptyMsg.style.padding = '20px';
      projectList.appendChild(emptyMsg);
    } else {
      // Sort by creation date (newest first)
      const sortedAnalyses = [...analyses].sort((a, b) => {
        const dateA = a.createdAt || 0;
        const dateB = b.createdAt || 0;
        return dateB - dateA;
      });

      sortedAnalyses.forEach(analysis => {
        const projectItem = document.createElement('div');
        projectItem.className = 'project-item';
        projectItem.dataset.projectId = analysis.id;
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'project-item-name';
        nameDiv.textContent = analysis.name;
        
        const dateDiv = document.createElement('div');
        dateDiv.className = 'project-item-date';
        dateDiv.textContent = analysis.date || 'No date';
        
        projectItem.appendChild(nameDiv);
        projectItem.appendChild(dateDiv);
        
        projectItem.addEventListener('click', () => {
          // Remove previous selection
          document.querySelectorAll('.project-item').forEach(item => {
            item.classList.remove('selected');
          });
          projectItem.classList.add('selected');
          
          // Open video with selected project
          setTimeout(() => {
            openVideoWithProject(analysis.id);
          }, 200);
        });
        
        projectList.appendChild(projectItem);
      });
    }
  }

  // Handle creating new project from modal
  createNewProjectBtn.addEventListener('click', () => {
    const projectName = prompt('Enter project name:', 'New Video Project');
    if (projectName && projectName.trim()) {
      createProjectAndOpenVideo(projectName.trim());
    }
  });

  // Close modal handlers
  closeProjectModal.addEventListener('click', () => {
    projectSelectionModal.classList.add('hidden');
    if (addVideoModal) {
      addVideoModal.classList.add('hidden');
    }
    pendingVideoUrl = null;
    videoUrlInput.value = '';
  });

  // Close modal when clicking outside
  projectSelectionModal.addEventListener('click', (e) => {
    if (e.target === projectSelectionModal) {
      projectSelectionModal.classList.add('hidden');
      if (addVideoModal) {
        addVideoModal.classList.add('hidden');
      }
      pendingVideoUrl = null;
      videoUrlInput.value = '';
    }
  });

  // Add video to current project (popup)
  // Fetch video title from URL using content script (no host_permissions needed)
  async function fetchVideoTitle(url, platform, videoId) {
    // Use content script for all platforms
    return new Promise((resolve) => {
      // Normalize URL for comparison (remove time parameters)
      const normalizeUrl = (url) => {
        try {
          const urlObj = new URL(url);
          urlObj.searchParams.delete('t');
          urlObj.searchParams.delete('start');
          urlObj.hash = '';
          return urlObj.toString();
        } catch {
          return url.split('?')[0].split('#')[0];
        }
      };
      
      const normalizedUrl = normalizeUrl(url);
      let tabToClose = null; // Track tab we might need to close
      
      // Check if a tab with this video is already open
      chrome.tabs.query({}, (tabs) => {
        const matchingTab = tabs.find(tab => {
          try {
            const tabUrl = normalizeUrl(tab.url);
            return tabUrl === normalizedUrl || tabUrl.includes(normalizedUrl) || normalizedUrl.includes(tabUrl);
          } catch {
            return false;
          }
        });
        
        const tryGetTitle = (tabId, isNewTab = false, attempt = 1) => {
          const maxAttempts = platform === 'twitch' ? 8 : 3;
          // For Twitch, we need much longer waits because the page is heavily JavaScript-based
          const baseWaitTime = isNewTab 
            ? (platform === 'twitch' ? 15000 : platform === 'dailymotion' ? 7000 : 5000)
            : (platform === 'twitch' ? 8000 : platform === 'dailymotion' ? 3000 : 2000);
          // Increase wait time more aggressively for Twitch
          const waitTime = baseWaitTime + (attempt - 1) * (platform === 'twitch' ? 3000 : 2000);
          
          setTimeout(() => {
            chrome.tabs.get(tabId, (tab) => {
              if (chrome.runtime.lastError || !tab) {
                console.warn('Tab not accessible:', chrome.runtime.lastError?.message || 'Unknown error');
                if (isNewTab && tabToClose === tabId) {
                  chrome.tabs.remove(tabId, () => {
                    // Check for errors silently
                    const lastError = chrome.runtime.lastError;
                    if (lastError) {
                      // Ignore - tab might already be closed
                    }
                  });
                }
                resolve(getDefaultTitle(platform));
                return;
              }
              
              // Check if tab is still loading
              if (tab.status !== 'complete') {
                console.log(`Tab ${tabId} still loading (status: ${tab.status}), will retry...`);
                if (attempt < maxAttempts) {
                  tryGetTitle(tabId, isNewTab, attempt + 1);
                } else {
                  console.warn(`Tab ${tabId} never finished loading after ${maxAttempts} attempts`);
                  resolve(getDefaultTitle(platform));
                }
                return;
              }
              
              // For Twitch, try to ping the content script first to see if it's ready
              // We'll send a simple ping message and if it fails, wait longer
              if (platform === 'twitch' && attempt <= 3) {
                chrome.tabs.sendMessage(tabId, { action: 'ping' }, (pingResponse) => {
                  if (chrome.runtime.lastError) {
                    const errorMsg = chrome.runtime.lastError.message || String(chrome.runtime.lastError);
                    if (errorMsg.includes('Receiving end does not exist')) {
                      console.log(`Content script ping failed for Twitch (tab ${tabId}), attempt ${attempt}/${maxAttempts}, will retry...`);
                      if (attempt < maxAttempts) {
                        tryGetTitle(tabId, isNewTab, attempt + 1);
                      } else {
                        console.warn('Content script never responded to ping, using default title');
                        resolve(getDefaultTitle(platform));
                      }
                      return;
                    }
                  }
                  // Ping succeeded, content script is ready, now get the title
                  sendTitleMessage();
                });
              } else {
                // For other platforms or after 3 attempts, just try to get title
                sendTitleMessage();
              }
              
              function sendTitleMessage() {
                // Send message to get title
                console.log(`Sending getVideoTitle message to tab ${tabId} for ${platform} video (attempt ${attempt}/${maxAttempts})`);
                chrome.tabs.sendMessage(tabId, { action: 'getVideoTitle' }, (response) => {
                if (chrome.runtime.lastError) {
                  const errorMsg = chrome.runtime.lastError.message || String(chrome.runtime.lastError);
                  // "Receiving end does not exist" means content script isn't ready - retry
                  if (errorMsg.includes('Receiving end does not exist')) {
                    console.log(`Content script not ready for ${platform} (tab ${tabId}), attempt ${attempt}/${maxAttempts}`);
                    if (attempt < maxAttempts) {
                      // Retry with longer wait
                      tryGetTitle(tabId, isNewTab, attempt + 1);
                    } else {
                      console.warn(`Content script never became ready for ${platform} after ${maxAttempts} attempts, using default title`);
                      // Close new tab if we opened it
                      if (isNewTab && tabToClose === tabId) {
                        chrome.tabs.remove(tabId, () => {
                          if (chrome.runtime.lastError) {
                            // Ignore - tab might already be closed
                          }
                          chrome.runtime.lastError; // Clear the error
                        });
                      }
                      resolve(getDefaultTitle(platform));
                    }
                  } else {
                    console.warn(`Could not get ${platform} title:`, errorMsg);
                    // Close new tab if we opened it
                    if (isNewTab && tabToClose === tabId) {
                      chrome.tabs.remove(tabId, () => {
                        if (chrome.runtime.lastError) {
                          // Ignore - tab might already be closed
                        }
                        chrome.runtime.lastError; // Clear the error
                      });
                    }
                    resolve(getDefaultTitle(platform));
                  }
                } else if (response && response.title) {
                  // Success! Close new tab if we opened it
                  if (isNewTab && tabToClose === tabId) {
                    chrome.tabs.remove(tabId, () => {
                      if (chrome.runtime.lastError) {
                        // Ignore - tab might already be closed
                      }
                      chrome.runtime.lastError; // Clear the error
                    });
                  }
                  // Accept any title, even if it's a default one (better than nothing)
                  console.log(`Got ${platform} video title from tab ${tabId}:`, response.title);
                  resolve(response.title);
                } else {
                  console.warn(`No title in response for ${platform} (tab ${tabId}), response was:`, response);
                  // Close new tab if we opened it
                  if (isNewTab && tabToClose === tabId) {
                    chrome.tabs.remove(tabId, () => {
                      if (chrome.runtime.lastError) {
                        // Ignore - tab might already be closed
                      }
                      chrome.runtime.lastError; // Clear the error
                    });
                  }
                  resolve(getDefaultTitle(platform));
                }
              });
              }
            });
          }, waitTime);
        };
        
        if (matchingTab) {
          // Tab is already open, try to get title from it
          tryGetTitle(matchingTab.id, false);
        } else {
          // Tab not open, open it in background and get title
          chrome.tabs.create({ url: url, active: false }, (tab) => {
            if (chrome.runtime.lastError || !tab || !tab.id) {
              console.warn('Could not create tab:', chrome.runtime.lastError?.message);
              resolve(getDefaultTitle(platform));
              return;
            }
            
            tabToClose = tab.id;
            
            // Wait for tab to load
            const checkTab = () => {
              chrome.tabs.get(tab.id, (tabInfo) => {
                if (chrome.runtime.lastError || !tabInfo) {
                  // Tab might have been closed
                  resolve(getDefaultTitle(platform));
                  return;
                }
                
                if (tabInfo.status === 'complete') {
                  // Tab loaded, try to get title
                  tryGetTitle(tab.id, true);
                } else {
                  // Still loading, check again
                  setTimeout(checkTab, 500);
                }
              });
            };
            
            // Start checking after a short delay (longer for Dailymotion)
            setTimeout(checkTab, 2000);
            
            // Timeout after 12 seconds (longer for Dailymotion which may load slower)
            setTimeout(() => {
              if (tabToClose === tab.id) {
                chrome.tabs.remove(tab.id, () => {
                  // Check for errors silently
                  const lastError = chrome.runtime.lastError;
                  if (lastError) {
                    // Ignore - tab might already be closed
                  }
                });
                tabToClose = null;
              }
              resolve(getDefaultTitle(platform));
            }, 8000);
          });
        }
      });
    });
  }
  
  function getDefaultTitle(platform) {
    const platformNames = {
      youtube: 'YouTube Video',
      dailymotion: 'Dailymotion Video',
      twitch: 'Twitch Video'
    };
    return platformNames[platform] || 'Video';
  }

  // Get fallback thumbnail image URL
  function getFallbackThumbnail() {
    return chrome.runtime.getURL('icons/audience-1866738_1280.jpg');
  }

  // Fetch video thumbnail URL (synchronous for simple URLs, async for API calls)
  async function fetchVideoThumbnail(url, platform, videoId) {
    if (!videoId) {
      return getFallbackThumbnail();
    }
    
    try {
      if (platform === 'youtube') {
        // YouTube thumbnail URLs
        return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
      } else if (platform === 'dailymotion') {
        // Dailymotion thumbnail
        return `https://www.dailymotion.com/thumbnail/video/${videoId}`;
      } else if (platform === 'twitch') {
        // Don't try to fetch Twitch thumbnails - they often return 404
        // Just use the fallback thumbnail immediately
        return getFallbackThumbnail();
      }
    } catch (e) {
      console.warn('Error generating thumbnail URL:', e);
    }
    
    return getFallbackThumbnail();
  }

  async function addVideoToCurrentProject(url) {
    if (!currentAnalysisId || !url) {
      console.warn('No current project or URL to add video to');
      return;
    }

    // Show loading indicator
    if (videoUrlInput) {
      videoUrlInput.disabled = true;
    }
    if (videoUrlLoading) {
      videoUrlLoading.style.display = 'flex';
    }

    try {
      // Extract video info
      let videoId = null;
      let platform = 'video';
      let videoTitle = 'Video';
      
      if (isYouTubeUrl(url)) {
        platform = 'youtube';
        videoId = extractYouTubeId(url);
      } else if (isDailymotionUrl(url)) {
        platform = 'dailymotion';
        const match = url.match(/dailymotion\.com\/video\/([^/?]+)/);
        videoId = match ? match[1] : null;
      } else if (isTwitchUrl(url)) {
        platform = 'twitch';
        // Match both /videos/ (plural) and /video/ (singular) patterns
        // Also handle URLs with channel name: twitch.tv/channelname/video/123456
        const match = url.match(/twitch\.tv\/(?:[^\/]+\/)?(?:videos|video)\/(\d+)/);
        videoId = match ? match[1] : null;
      }

      if (!videoId) {
        console.error('Failed to extract video ID from URL:', url);
        alert('Invalid video URL. Please check the URL and try again.');
        return;
      }

      // Fetch thumbnail (synchronous/quick)
      const videoThumbnail = await fetchVideoThumbnail(url, platform, videoId);
      
      // Start fetching title asynchronously (non-blocking)
      // Use default title for now, will update later if fetch succeeds
      videoTitle = getDefaultTitle(platform);
      
      // Fetch title in background and update if successful
      fetchVideoTitle(url, platform, videoId).then(fetchedTitle => {
        // Clean up the title if it contains Twitch suffixes
        if (fetchedTitle && platform === 'twitch') {
          fetchedTitle = fetchedTitle
            .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
            .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
            .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
            .trim();
        }
        
        if (fetchedTitle && fetchedTitle !== getDefaultTitle(platform) && fetchedTitle.length > 3) {
          console.log('Updating video title in popup:', fetchedTitle, 'for video:', videoId);
          // Update the video title in storage
          chrome.storage.local.get(['analyses'], (result) => {
            const analyses = result.analyses || [];
            const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
            if (analysisIndex !== -1) {
              const analysis = analyses[analysisIndex];
              const videoIndex = analysis.videos.findIndex(v => 
                v.videoUrl === url || (v.videoId === videoId && v.platform === platform)
              );
              if (videoIndex !== -1) {
                console.log('Found video at index:', videoIndex, 'updating title from', analysis.videos[videoIndex].videoTitle, 'to', fetchedTitle);
                analysis.videos[videoIndex].videoTitle = fetchedTitle;
                // Update legacy field if this is the first video
                if (videoIndex === 0 && analysis.videos.length === 1) {
                  analysis.videoTitle = fetchedTitle;
                }
                chrome.storage.local.set({ analyses: analyses }, () => {
                  console.log('Updated video title to:', fetchedTitle);
                  // Refresh displays
                  updateProjectVideos(analysis);
                  updateMediaGallery(analysis);
                });
              } else {
                console.warn('Video not found in analysis.videos array. Videos:', analysis.videos.map(v => ({ id: v.videoId, url: v.videoUrl, platform: v.platform })));
              }
            } else {
              console.warn('Analysis not found:', currentAnalysisId);
            }
          });
        } else {
          console.log('Title not updated. fetchedTitle:', fetchedTitle, 'defaultTitle:', getDefaultTitle(platform), 'length:', fetchedTitle?.length);
        }
      }).catch(err => {
        console.warn('Background title fetch failed:', err);
        // That's okay, we already have the default title
      });

      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex === -1) {
          console.warn('Current project not found');
          // Hide loading indicator
          if (videoUrlInput) {
            videoUrlInput.disabled = false;
          }
          if (videoUrlLoading) {
            videoUrlLoading.style.display = 'none';
          }
          return;
        }

        const analysis = analyses[analysisIndex];
        
        // Initialize videos array if it doesn't exist
        if (!analysis.videos) {
          analysis.videos = [];
          // Migrate existing video data to videos array
          if (analysis.videoId || analysis.videoUrl) {
            analysis.videos.push({
              videoId: analysis.videoId,
              videoUrl: analysis.videoUrl,
              videoTitle: analysis.videoTitle || 'Video',
              platform: analysis.platform || 'video',
              addedAt: analysis.createdAt || Date.now()
            });
          }
        }

        // Check if this video already exists in the project
        console.log('addVideoToCurrentProject: Checking for duplicates. Current videos:', analysis.videos.length);
        console.log('addVideoToCurrentProject: Adding video with URL:', url, 'ID:', videoId, 'Platform:', platform);
        
        const videoExists = analysis.videos.some(v => {
          const urlMatch = v.videoUrl === url;
          const idMatch = v.videoId === videoId && v.platform === platform;
          if (urlMatch || idMatch) {
            console.log('addVideoToCurrentProject: Duplicate found!', { existingUrl: v.videoUrl, existingId: v.videoId, existingPlatform: v.platform });
          }
          return urlMatch || idMatch;
        });

        if (videoExists) {
          console.log('addVideoToCurrentProject: Video already exists, not adding');
          alert('This video is already in the current project.');
          // Hide loading indicator
          if (videoUrlInput) {
            videoUrlInput.disabled = false;
          }
          if (videoUrlLoading) {
            videoUrlLoading.style.display = 'none';
          }
          return;
        }

        // Add the new video to the project
        const newVideo = {
          videoId: videoId,
          videoUrl: url,
          videoTitle: videoTitle,
          videoThumbnail: videoThumbnail,
          platform: platform,
          addedAt: Date.now()
        };
        analysis.videos.push(newVideo);
        console.log('addVideoToCurrentProject: Added video. Total videos now:', analysis.videos.length);
        console.log('addVideoToCurrentProject: New video details:', newVideo);

        // Update legacy fields to point to the first video (for backward compatibility)
        if (analysis.videos.length === 1) {
          analysis.videoId = videoId;
          analysis.videoUrl = url;
          analysis.platform = platform;
          analysis.videoTitle = videoTitle;
        }

        // CRITICAL: Verify videos array before saving
        console.log('addVideoToCurrentProject: Before save - videos count:', analysis.videos.length);
        analysis.videos.forEach((v, idx) => {
          console.log(`  Video ${idx + 1} before save:`, { url: v.videoUrl, id: v.videoId, platform: v.platform });
        });
        
        chrome.storage.local.set({ analyses: analyses }, () => {
          console.log('Video added to project:', videoTitle);
          
          // Verify videos were saved correctly
          chrome.storage.local.get(['analyses'], (verifyResult) => {
            const savedAnalyses = verifyResult.analyses || [];
            const savedAnalysis = savedAnalyses.find(a => a.id === currentAnalysisId);
            if (savedAnalysis) {
              console.log('addVideoToCurrentProject: After save - videos count in storage:', savedAnalysis.videos ? savedAnalysis.videos.length : 'null');
              if (savedAnalysis.videos) {
                savedAnalysis.videos.forEach((v, idx) => {
                  console.log(`  Video ${idx + 1} after save:`, { url: v.videoUrl, id: v.videoId, platform: v.platform });
                });
              }
            }
          });
          
          // Refresh displays
          updateProjectVideos(analysis);
          updateMediaGallery(analysis);
          switchToAnalysis(currentAnalysisId);
          
          // Clear input and close modal
          if (videoUrlInput) {
            videoUrlInput.value = '';
            videoUrlInput.disabled = false;
          }
          if (videoUrlLoading) {
            videoUrlLoading.style.display = 'none';
          }
          if (addVideoModal) {
            addVideoModal.classList.add('hidden');
          }
        });
      });
    } catch (error) {
      console.error('Error adding video:', error);
      // Hide loading indicator on error
      if (videoUrlInput) {
        videoUrlInput.disabled = false;
      }
      if (videoUrlLoading) {
        videoUrlLoading.style.display = 'none';
      }
      alert('Failed to add video. Please try again.');
    }
  }

  // Create project and open video
  async function createProjectAndOpenVideo(projectName) {
    if (!pendingVideoUrl) {
      console.error('No pending video URL');
      return;
    }

    const analysisId = 'analysis_' + Date.now();
    const date = new Date();
    
    // Extract video info first
    let videoId = null;
    let platform = 'video';
    let videoTitle = projectName; // Start with project name as fallback
    
    if (isYouTubeUrl(pendingVideoUrl)) {
      platform = 'youtube';
      videoId = extractYouTubeId(pendingVideoUrl);
    } else if (isDailymotionUrl(pendingVideoUrl)) {
      platform = 'dailymotion';
      const match = pendingVideoUrl.match(/dailymotion\.com\/video\/([^/?]+)/);
      videoId = match ? match[1] : null;
    } else if (isTwitchUrl(pendingVideoUrl)) {
      platform = 'twitch';
      const match = pendingVideoUrl.match(/twitch\.tv\/videos\/(\d+)/);
      videoId = match ? match[1] : null;
    }
    
    // Fetch thumbnail (synchronous/quick)
    const videoThumbnail = await fetchVideoThumbnail(pendingVideoUrl, platform, videoId);
    
    // Use project name as title for now, will update later if fetch succeeds
    if (videoId) {
      videoTitle = projectName; // Use project name as initial title
      
      // Fetch title in background and update if successful
      fetchVideoTitle(pendingVideoUrl, platform, videoId).then(fetchedTitle => {
        // Clean up the title if it contains Twitch suffixes
        if (fetchedTitle && platform === 'twitch') {
          fetchedTitle = fetchedTitle
            .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
            .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
            .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
            .trim();
        }
        
        if (fetchedTitle && fetchedTitle !== 'Video' && fetchedTitle !== 'YouTube Video' && fetchedTitle !== 'Dailymotion Video' && fetchedTitle !== 'Twitch Video' && fetchedTitle.length > 3) {
          // Update the video title in storage
          chrome.storage.local.get(['analyses'], (result) => {
            const analyses = result.analyses || [];
            const analysisIndex = analyses.findIndex(a => a.id === analysisId);
            if (analysisIndex !== -1) {
              const analysis = analyses[analysisIndex];
              analysis.videoTitle = fetchedTitle;
              if (analysis.videos && analysis.videos.length > 0) {
                analysis.videos[0].videoTitle = fetchedTitle;
              }
              chrome.storage.local.set({ analyses: analyses }, () => {
                console.log('Updated project video title to:', fetchedTitle);
                updateAnalysisSelect(analyses, analysisId);
                switchToAnalysis(analysisId);
              });
            }
          });
        }
      }).catch(err => {
        console.warn('Background title fetch failed:', err);
      });
    }
    
    const newAnalysis = {
      id: analysisId,
      name: projectName,
      date: date.toLocaleDateString(),
      videoId: videoId,
      videoUrl: pendingVideoUrl,
      videoTitle: videoTitle,
      platform: platform,
      videos: [{
        videoId: videoId,
        videoUrl: pendingVideoUrl,
        videoTitle: videoTitle,
        videoThumbnail: videoThumbnail,
        platform: platform,
        addedAt: Date.now()
      }],
      notes: [],
      attachedTeamIds: [], // IDs of teams attached to this project
      createdAt: Date.now()
    };

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      analyses.push(newAnalysis);
      chrome.storage.local.set({ 
        analyses: analyses,
        currentAnalysisId: analysisId
      }, () => {
        updateAnalysisSelect(analyses, analysisId);
        switchToAnalysis(analysisId);
        
        // Close modal and open video
        projectSelectionModal.classList.add('hidden');
        
        // Open video and ensure sidebar loads the project
        openVideoWithProjectId(analysisId, pendingVideoUrl);
        if (addVideoModal) {
          addVideoModal.classList.add('hidden');
        }
        pendingVideoUrl = null;
        videoUrlInput.value = '';
      });
    });
  }

  // Open video with selected project
  async function openVideoWithProject(projectId) {
    if (!pendingVideoUrl) {
      console.error('No pending video URL');
      return;
    }

    // Update the project with video URL
    chrome.storage.local.get(['analyses'], async (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === projectId);
      
      if (analysis) {
        // Extract video info
        let videoId = null;
        let platform = 'video';
        let videoTitle = analysis.name || 'Video';
        
        if (isYouTubeUrl(pendingVideoUrl)) {
          platform = 'youtube';
          videoId = extractYouTubeId(pendingVideoUrl);
        } else if (isDailymotionUrl(pendingVideoUrl)) {
          platform = 'dailymotion';
          const match = pendingVideoUrl.match(/dailymotion\.com\/video\/([^/?]+)/);
          videoId = match ? match[1] : null;
        } else if (isTwitchUrl(pendingVideoUrl)) {
          platform = 'twitch';
          const match = pendingVideoUrl.match(/twitch\.tv\/videos\/(\d+)/);
          videoId = match ? match[1] : null;
        }

        // Fetch thumbnail (synchronous/quick)
        const videoThumbnail = await fetchVideoThumbnail(pendingVideoUrl, platform, videoId);
        
        // Use default title for now, will update later if fetch succeeds
        videoTitle = getDefaultTitle(platform);
        
        // Fetch title in background and update if successful
        if (videoId) {
          fetchVideoTitle(pendingVideoUrl, platform, videoId).then(fetchedTitle => {
            // Clean up the title if it contains Twitch suffixes
            if (fetchedTitle && platform === 'twitch') {
              fetchedTitle = fetchedTitle
                .replace(/\s*-\s*[^-]+ on Twitch\s*$/i, '') // Remove " - channelname on Twitch"
                .replace(/\s*-\s*Twitch\s*$/i, '') // Remove " - Twitch"
                .replace(/\s*on Twitch\s*$/i, '') // Remove "on Twitch"
                .trim();
            }
            
            if (fetchedTitle && fetchedTitle !== 'Video' && fetchedTitle !== 'YouTube Video' && fetchedTitle !== 'Dailymotion Video' && fetchedTitle !== 'Twitch Video' && fetchedTitle.length > 3) {
              // Update the video title in storage
              chrome.storage.local.get(['analyses'], (result) => {
                const analyses = result.analyses || [];
                const analysisIndex = analyses.findIndex(a => a.id === projectId);
                if (analysisIndex !== -1) {
                  const analysis = analyses[analysisIndex];
                  const videoIndex = analysis.videos.findIndex(v => 
                    v.videoUrl === pendingVideoUrl || (v.videoId === videoId && v.platform === platform)
                  );
                  if (videoIndex !== -1) {
                    analysis.videos[videoIndex].videoTitle = fetchedTitle;
                    // Update legacy field if this is the first video
                    if (videoIndex === 0 && analysis.videos.length === 1) {
                      analysis.videoTitle = fetchedTitle;
                    }
                    chrome.storage.local.set({ analyses: analyses }, () => {
                      console.log('Updated video title to:', fetchedTitle);
                      updateProjectVideos(analysis);
                      updateMediaGallery(analysis);
                    });
                  }
                }
              });
            }
          }).catch(err => {
            console.warn('Background title fetch failed:', err);
          });
        }

        // Initialize videos array if it doesn't exist
        if (!analysis.videos) {
          analysis.videos = [];
          // Migrate existing video data to videos array
          if (analysis.videoId || analysis.videoUrl) {
            analysis.videos.push({
              videoId: analysis.videoId,
              videoUrl: analysis.videoUrl,
              videoTitle: analysis.videoTitle || 'Video',
              platform: analysis.platform || 'video',
              addedAt: analysis.createdAt || Date.now()
            });
          }
        }

        // Check if video already exists
        const videoExists = analysis.videos.some(v => 
          v.videoUrl === pendingVideoUrl || 
          (v.videoId === videoId && v.platform === platform)
        );

        if (!videoExists) {
          // Add the new video to the project
          analysis.videos.push({
            videoId: videoId,
            videoUrl: pendingVideoUrl,
            videoTitle: videoTitle,
            videoThumbnail: videoThumbnail,
            platform: platform,
            addedAt: Date.now()
          });
        }

        // Update legacy fields to point to the first video (for backward compatibility)
        if (analysis.videos.length > 0) {
          const firstVideo = analysis.videos[0];
          analysis.videoId = firstVideo.videoId;
          analysis.videoUrl = firstVideo.videoUrl;
          analysis.platform = firstVideo.platform;
          analysis.videoTitle = firstVideo.videoTitle;
        }

        chrome.storage.local.set({ 
          analyses: analyses,
          currentAnalysisId: projectId
        }, () => {
          updateAnalysisSelect(analyses, projectId);
          switchToAnalysis(projectId);
          
          // Close modal and open video
          projectSelectionModal.classList.add('hidden');
          
          // Open video and ensure sidebar loads the project
          openVideoWithProjectId(projectId, pendingVideoUrl);
          pendingVideoUrl = null;
          videoUrlInput.value = '';
        });
      }
    });
  }

  // Open video and ensure sidebar loads the correct project
  function openVideoWithProjectId(projectId, url) {
    // First ensure currentAnalysisId is set in storage
    chrome.storage.local.set({ currentAnalysisId: projectId }, () => {
      // Now open the video
      handleVideoUrl(url, projectId);
    });
  }

  function handleVideoUrl(url, projectId = null) {
    // Check if it's a supported video platform URL
    if (isYouTubeUrl(url)) {
      const videoId = extractYouTubeId(url);
      const timestamp = extractTimestamp(url);
      const siParam = extractSiParameter(url);
      console.log('YouTube URL detected:', url);
      console.log('Extracted video ID:', videoId);
      console.log('Extracted timestamp:', timestamp);
      console.log('Extracted si parameter:', siParam);

      if (videoId) {
        console.log('YouTube URL detected for video ID:', videoId, 'timestamp:', timestamp, 'si:', siParam);

        // Open YouTube in new tab with sidebar
        const youtubeUrl = `https://www.youtube.com/watch?v=${videoId}${timestamp ? `&t=${timestamp}` : ''}${siParam ? `&si=${siParam}` : ''}`;
        openTabAndActivate(youtubeUrl, (tab) => {
          // Wait for the tab to load, then activate the sidebar and load project
          setTimeout(() => {
            // First show the sidebar
            chrome.tabs.sendMessage(tab.id, { action: 'showSidebar' }, (response) => {
              if (chrome.runtime.lastError) {
                console.log('Sidebar will be available via toggle button');
              } else {
                console.log('Dinamo Notebook sidebar activated on YouTube');
              }
            });
            
            // Then load the project if specified
            if (projectId) {
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { action: 'loadProject', projectId: projectId }, (response) => {
                  if (chrome.runtime.lastError) {
                    console.log('Could not send loadProject message, sidebar will load from storage');
                  } else {
                    console.log('Project loaded in sidebar:', projectId);
                  }
                });
              }, 1000);
            }
          }, 3000);
        });
        videoUrlInput.value = '';

        return;
      } else {
        console.error('Failed to extract video ID from URL:', url);
        alert('Invalid YouTube URL. Please check the URL and try again.');
        return;
      }
    }
    
    // Check for other video platforms
    if (isDailymotionUrl(url)) {
      openVideoInTab(url, 'dailymotion');
      videoUrlInput.value = '';
      return;
    }
    
    if (isTwitchUrl(url)) {
      openVideoInTab(url, 'twitch');
      videoUrlInput.value = '';
      return;
    }
    
    // If not a recognized video platform, show error
    alert('This URL is not a supported video platform. Please use YouTube, Dailymotion, or Twitch URLs.');
    videoUrlInput.value = '';
  }

  // Check if URL is from Dailymotion
  function isDailymotionUrl(url) {
    return /dailymotion\.com/.test(url);
  }

  // Check if URL is from Twitch
  function isTwitchUrl(url) {
    return /twitch\.tv/.test(url);
  }

  // Open video in new tab with sidebar
  function openVideoInTab(url, platform) {
    console.log(`Opening ${platform} video in new tab:`, url);
    openTabAndActivate(url, (tab) => {
      // Wait for the tab to load, then activate the sidebar
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: 'showSidebar' }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('Sidebar will be available via toggle button');
          } else {
            console.log(`Dinamo Notebook sidebar activated on ${platform}`);
          }
        });
      }, 3000);
    });
  }

  function extractTimestamp(url) {
    // Extract timestamp from URL (e.g., &t=5530s or &t=1h32m10s)
    const timeMatch = url.match(/[?&]t=(\d+)/);
    if (timeMatch) {
      return parseInt(timeMatch[1]);
    }
    const complexTimeMatch = url.match(/[?&]t=((\d+)h)?((\d+)m)?(\d+)s/);
    if (complexTimeMatch) {
      const hours = parseInt(complexTimeMatch[2] || 0);
      const minutes = parseInt(complexTimeMatch[4] || 0);
      const seconds = parseInt(complexTimeMatch[5] || 0);
      return hours * 3600 + minutes * 60 + seconds;
    }
    return null;
  }

  function extractSiParameter(url) {
    // Extract si (share identifier) parameter from URL
    const siMatch = url.match(/[?&]si=([^&]+)/);
    return siMatch ? siMatch[1] : null;
  }

  function isYouTubeUrl(url) {
    return /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)/.test(url);
  }

  function extractYouTubeId(url) {
    // Clean the URL first
    url = url.trim();

    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/)([^&\n?#]+)/,
      /youtube\.com\/.*[?&]v=([^&\n?#]+)/,
      /(?:youtube\.com\/shorts\/)([^&\n?#]+)/
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        const videoId = match[1].substring(0, 11); // Ensure we only take first 11 chars
        if (videoId.length === 11 && /^[a-zA-Z0-9_-]+$/.test(videoId)) {
          return videoId;
        }
      }
    }
    return null;
  }


  // Handle send button
  sendButton.addEventListener('click', () => {
    sendMessage();
  });

  // Handle Enter key (Shift+Enter for new line, Enter to send)
  // Auto-resize textarea
  if (chatInput) {
    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    });
  }

  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Team selector functionality
  const teamSearchInput = document.getElementById('teamSearchInput');
  const teamSelectorDropdown = document.getElementById('teamSelectorDropdown');
  const addTeamBtn = document.getElementById('addTeamBtn');
  const teamList = document.getElementById('teamList');
  const selectedTeamDisplay = document.getElementById('selectedTeamDisplay');
  
  // Selected team for current analysis
  let selectedTeam = null; // Keep for backward compatibility with analysis.selectedTeam
  let selectedTeams = []; // Array for multiple team selection

  // Show/hide dropdown on search input focus
  if (teamSearchInput) {
    teamSearchInput.addEventListener('focus', () => {
      if (teamSelectorDropdown) {
        teamSelectorDropdown.style.display = 'block';
        renderTeamSelector(teamSearchInput.value);
      }
    });

    teamSearchInput.addEventListener('input', (e) => {
      renderTeamSelector(e.target.value);
    });

    teamSearchInput.addEventListener('blur', (e) => {
      // Delay hiding to allow clicks on items
      setTimeout(() => {
        if (teamSelectorDropdown && !teamSelectorDropdown.matches(':hover') && document.activeElement !== teamSearchInput) {
          teamSelectorDropdown.style.display = 'none';
        }
      }, 200);
    });
  }

  // Keep dropdown open when hovering
  if (teamSelectorDropdown) {
    teamSelectorDropdown.addEventListener('mouseenter', () => {
      teamSelectorDropdown.style.display = 'block';
    });
    teamSelectorDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== teamSearchInput) {
        teamSelectorDropdown.style.display = 'none';
      }
    });
  }
  
  if (addTeamBtn) {
    addTeamBtn.addEventListener('click', () => {
      createNewTeam();
    });
  }
  
  // Player selector functionality
  const playerSearchInput = document.getElementById('playerSearchInput');
  const playerSelectorDropdown = document.getElementById('playerSelectorDropdown');
  const addPlayerBtn = document.getElementById('addPlayerBtn');
  const playerList = document.getElementById('playerList');
  const selectedPlayersDisplay = document.getElementById('selectedPlayersDisplay');

  // Selected players for current message
  let selectedPlayers = [];

  // Show/hide dropdown on search input focus
  if (playerSearchInput) {
    playerSearchInput.addEventListener('focus', () => {
      if (playerSelectorDropdown) {
        playerSelectorDropdown.style.display = 'block';
        renderPlayerSelector(playerSearchInput.value);
      }
    });

    playerSearchInput.addEventListener('input', (e) => {
      renderPlayerSelector(e.target.value);
    });

    playerSearchInput.addEventListener('blur', (e) => {
      // Delay hiding to allow clicks on checkboxes
      setTimeout(() => {
        if (playerSelectorDropdown && !playerSelectorDropdown.matches(':hover') && document.activeElement !== playerSearchInput) {
          playerSelectorDropdown.style.display = 'none';
        }
      }, 200);
    });
  }

  // Keep dropdown open when hovering
  if (playerSelectorDropdown) {
    playerSelectorDropdown.addEventListener('mouseenter', () => {
      playerSelectorDropdown.style.display = 'block';
    });
    playerSelectorDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== playerSearchInput) {
        playerSelectorDropdown.style.display = 'none';
      }
    });
  }

  if (addPlayerBtn) {
    addPlayerBtn.addEventListener('click', () => {
      createNewPlayer();
    });
  }

  // Event selector functionality
  const eventSearchInput = document.getElementById('eventSearchInput');
  const eventSelectorDropdown = document.getElementById('eventSelectorDropdown');
  const addCustomEventBtn = document.getElementById('addCustomEventBtn');

  // Show/hide dropdown on search input focus
  if (eventSearchInput) {
    eventSearchInput.addEventListener('focus', () => {
      if (eventSelectorDropdown) {
        eventSelectorDropdown.style.display = 'block';
        renderEventSelector(eventSearchInput.value);
      }
    });

    eventSearchInput.addEventListener('input', (e) => {
      renderEventSelector(e.target.value);
    });

    eventSearchInput.addEventListener('blur', (e) => {
      // Delay hiding to allow clicks on checkboxes
      setTimeout(() => {
        if (eventSelectorDropdown && !eventSelectorDropdown.matches(':hover') && document.activeElement !== eventSearchInput) {
          eventSelectorDropdown.style.display = 'none';
        }
      }, 200);
    });
  }

  // Keep dropdown open when hovering
  if (eventSelectorDropdown) {
    eventSelectorDropdown.addEventListener('mouseenter', () => {
      eventSelectorDropdown.style.display = 'block';
    });
    eventSelectorDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== eventSearchInput) {
        eventSelectorDropdown.style.display = 'none';
      }
    });
  }

  if (addCustomEventBtn) {
    addCustomEventBtn.addEventListener('click', () => {
      addCustomEvent();
    });
  }

  // Selected events for current message
  let selectedEvents = [];

  // Selected zones for current message
  let selectedZones = [];

  // Selected intensity for current message (0-4: Full defense, Defense, Balance, Attack, Full attack)
  let selectedIntensity = null;

  // Load custom events on startup
  loadCustomEvents();

  // Zones selector functionality
  const zonesSearchInput = document.getElementById('zonesSearchInput');
  const zonesSelectorDropdown = document.getElementById('zonesSelectorDropdown');

  // Show/hide dropdown on search input focus
  if (zonesSearchInput) {
    zonesSearchInput.addEventListener('focus', () => {
      if (zonesSelectorDropdown) {
        zonesSelectorDropdown.style.display = 'block';
        renderZonesSelector(zonesSearchInput.value);
      }
    });

    zonesSearchInput.addEventListener('input', (e) => {
      renderZonesSelector(e.target.value);
    });

    zonesSearchInput.addEventListener('blur', (e) => {
      // Delay hiding to allow clicks on checkboxes
      setTimeout(() => {
        if (zonesSelectorDropdown && !zonesSelectorDropdown.matches(':hover') && document.activeElement !== zonesSearchInput) {
          zonesSelectorDropdown.style.display = 'none';
        }
      }, 200);
    });
  }

  // Keep dropdown open when hovering
  if (zonesSelectorDropdown) {
    zonesSelectorDropdown.addEventListener('mouseenter', () => {
      zonesSelectorDropdown.style.display = 'block';
    });
    zonesSelectorDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== zonesSearchInput) {
        zonesSelectorDropdown.style.display = 'none';
      }
    });
  }

  // Setup collapsible section for analysis controls
  const analysisControlsHeader = document.getElementById('analysisControlsHeader');
  const analysisControlsSection = document.getElementById('analysisControlsSection');
  const commentPropertiesButton = document.getElementById('commentPropertiesButton');
  
  // Function to toggle comment properties section
  function toggleCommentProperties() {
    if (!analysisControlsSection) return;
    const wasCollapsed = analysisControlsSection.classList.contains('collapsed');
    analysisControlsSection.classList.toggle('collapsed');
    // Update button state
    if (commentPropertiesButton) {
      if (wasCollapsed) {
        commentPropertiesButton.classList.add('active');
      } else {
        commentPropertiesButton.classList.remove('active');
      }
    }
  }
  
  if (analysisControlsHeader && analysisControlsSection) {
    analysisControlsHeader.addEventListener('click', toggleCommentProperties);
  }
  
  // Add click handler to toolbar button
  if (commentPropertiesButton && analysisControlsSection) {
    commentPropertiesButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleCommentProperties();
    });
    
    // Set initial active state based on section state
    if (!analysisControlsSection.classList.contains('collapsed')) {
      commentPropertiesButton.classList.add('active');
    }
  }

  // Initialize intensity selector
  const intensityScale = document.getElementById('intensityScale');
  const intensitySlider = document.getElementById('intensitySlider');
  const intensityTrack = intensityScale?.querySelector('.intensity-track');
  const intensityLabels = intensityScale?.querySelectorAll('.intensity-label-point');

  function updateIntensitySlider(value) {
    if (!intensitySlider || !intensityTrack) return;
    const percentage = (value / 4) * 100;
    intensitySlider.style.left = `${percentage}%`;
    
    // Update active label
    if (intensityLabels) {
      intensityLabels.forEach((label, index) => {
        if (index === value) {
          label.classList.add('active');
        } else {
          label.classList.remove('active');
        }
      });
    }
  }

  function setIntensity(value) {
    selectedIntensity = value;
    updateIntensitySlider(value);
  }

  // Initialize to Balance (middle)
  if (intensitySlider) {
    updateIntensitySlider(2);
  }

  // Handle clicks on track (but not on slider)
  if (intensityTrack) {
    intensityTrack.addEventListener('click', (e) => {
      // Don't handle click if it was on the slider itself
      if (e.target === intensitySlider || intensitySlider.contains(e.target)) {
        return;
      }
      const rect = intensityTrack.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      const value = Math.round((percentage / 100) * 4);
      setIntensity(value);
    });
  }

  // Handle clicks on labels
  if (intensityLabels) {
    intensityLabels.forEach((label) => {
      label.addEventListener('click', () => {
        const value = parseInt(label.dataset.value);
        setIntensity(value);
      });
    });
  }

  // Handle slider drag
  if (intensitySlider && intensityTrack) {
    let isDragging = false;

    intensitySlider.addEventListener('mousedown', (e) => {
      isDragging = true;
      e.preventDefault();
      e.stopPropagation();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const rect = intensityTrack.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      const value = Math.round((percentage / 100) * 4);
      setIntensity(value);
    });

    document.addEventListener('mouseup', () => {
      isDragging = false;
    });
  }

  // Function to close all dropdowns except the one specified
  function closeAllDropdowns(exceptDropdown = null) {
    const projectDropdown = document.getElementById('projectDropdown');
    const aiAnalysisDropdown = document.getElementById('aiAnalysisDropdown');
    const savingOptionsDropdown = document.getElementById('savingOptionsDropdown');
    
    if (projectDropdown && projectDropdown !== exceptDropdown) {
      projectDropdown.classList.add('hidden');
      projectDropdown.style.display = 'none';
    }
    if (aiAnalysisDropdown && aiAnalysisDropdown !== exceptDropdown) {
      aiAnalysisDropdown.classList.add('hidden');
      aiAnalysisDropdown.style.display = 'none';
    }
    if (savingOptionsDropdown && savingOptionsDropdown !== exceptDropdown) {
      savingOptionsDropdown.classList.add('hidden');
      savingOptionsDropdown.style.display = 'none';
    }
  }

  // Handle project dropdown
  if (projectButton && projectDropdownArrow && projectDropdown) {
    // Function to populate project list in dropdown
    function populateProjectDropdown() {
      return new Promise((resolve) => {
        chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
          const analyses = result.analyses || [];
          const currentId = result.currentAnalysisId;
          
          // Remove existing project list items and separators (keep Create, Rename, Delete)
          const existingItems = projectDropdown.querySelectorAll('.project-list-item, .project-list-separator');
          existingItems.forEach(item => item.remove());
          
          // Add project list items before the action buttons
          if (analyses.length > 0) {
            const sortedAnalyses = [...analyses].sort((a, b) => {
              const dateA = a.createdAt || 0;
              const dateB = b.createdAt || 0;
              return dateB - dateA; // Newest first
            });
            
            sortedAnalyses.forEach(analysis => {
              const projectItem = document.createElement('button');
              projectItem.className = 'project-dropdown-item project-list-item';
              if (analysis.id === currentId) {
                projectItem.style.background = '#21262d';
                projectItem.style.fontWeight = '500';
              }
              // Truncate long project names
              let displayName = analysis.name;
              const maxLength = 40;
              if (displayName.length > maxLength) {
                displayName = displayName.substring(0, maxLength) + '...';
              }
              projectItem.innerHTML = `<span>${displayName}</span>`;
              projectItem.addEventListener('click', () => {
                projectDropdown.classList.add('hidden');
                projectDropdown.style.display = 'none';
                switchToAnalysis(analysis.id);
              });
              // Insert before the first action button (Create Project)
              if (createProjectDropdownItem) {
                projectDropdown.insertBefore(projectItem, createProjectDropdownItem);
              }
            });
            
            // Add separator if there are projects
            if (sortedAnalyses.length > 0 && createProjectDropdownItem) {
              const separator = document.createElement('div');
              separator.className = 'project-list-separator';
              separator.style.cssText = 'height: 1px; background: #21262d; margin: 4px 0;';
              projectDropdown.insertBefore(separator, createProjectDropdownItem);
            }
          }
          resolve();
        });
      });
    }
    
    // Project button click - toggle dropdown with project list
    projectButton.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      const isHidden = projectDropdown.classList.contains('hidden') || projectDropdown.style.display === 'none';
      
      if (isHidden) {
        closeAllDropdowns(projectDropdown);
        await populateProjectDropdown();
        projectDropdown.classList.remove('hidden');
        projectDropdown.style.display = 'block';
        projectDropdown.style.visibility = 'visible';
        projectDropdown.style.opacity = '1';
        projectDropdown.style.zIndex = '10001';
      } else {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
      }
    });

    // Project dropdown arrow click - toggle dropdown
    projectDropdownArrow.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      const isHidden = projectDropdown.classList.contains('hidden') || projectDropdown.style.display === 'none';
      
      if (isHidden) {
        closeAllDropdowns(projectDropdown);
        await populateProjectDropdown();
        projectDropdown.classList.remove('hidden');
        projectDropdown.style.display = 'block';
        projectDropdown.style.visibility = 'visible';
        projectDropdown.style.opacity = '1';
        projectDropdown.style.zIndex = '10001';
      } else {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
      }
    });

    // Dropdown items
    if (createProjectDropdownItem) {
      createProjectDropdownItem.addEventListener('click', () => {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
        createNewAnalysis();
      });
    }

    if (renameProjectDropdownItem) {
      renameProjectDropdownItem.addEventListener('click', () => {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
        if (currentAnalysisId) {
          renameCurrentAnalysis();
        }
      });
    }

    if (manageTeamsDropdownItem) {
      manageTeamsDropdownItem.addEventListener('click', () => {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
        if (currentAnalysisId) {
          openManageTeamsModal();
        }
      });
    }

    if (deleteProjectDropdownItem) {
      deleteProjectDropdownItem.addEventListener('click', () => {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
        if (currentAnalysisId) {
          deleteCurrentAnalysis();
        }
      });
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (projectDropdown && 
          !projectDropdown.contains(e.target) && 
          e.target !== projectDropdownArrow && 
          e.target !== projectButton &&
          !projectDropdownArrow.contains(e.target) &&
          !projectButton.contains(e.target)) {
        projectDropdown.classList.add('hidden');
        projectDropdown.style.display = 'none';
      }
    });
  }

  // Export/Import/Backup handlers
  const savingOptionsButton = document.getElementById('savingOptionsButton');
  const savingOptionsDropdownArrow = document.getElementById('savingOptionsDropdownArrow');
  const savingOptionsDropdown = document.getElementById('savingOptionsDropdown');
  const importProjectDropdownItem = document.getElementById('importProjectDropdownItem');
  const exportProjectDropdownItem = document.getElementById('exportProjectDropdownItem');
  const exportNotesDropdownItem = document.getElementById('exportNotesDropdownItem');
  const backupDropdownItem = document.getElementById('backupDropdownItem');
  const restoreDropdownItem = document.getElementById('restoreDropdownItem');
  
  // Save button click handler - opens dropdown (same as AI button)
  if (savingOptionsButton && savingOptionsDropdown) {
    savingOptionsButton.addEventListener('click', (e) => {
      e.stopPropagation();
      const isHidden = savingOptionsDropdown.classList.contains('hidden') || savingOptionsDropdown.style.display === 'none';
      if (isHidden) {
        closeAllDropdowns(savingOptionsDropdown);
        setTimeout(() => {
          savingOptionsDropdown.classList.remove('hidden');
          savingOptionsDropdown.style.display = 'block';
          savingOptionsDropdown.style.visibility = 'visible';
          savingOptionsDropdown.style.opacity = '1';
          savingOptionsDropdown.style.zIndex = '10001';
        }, 0);
      } else {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
    });
  }
  
  // Saving options dropdown toggle
  if (savingOptionsDropdownArrow && savingOptionsDropdown) {
    savingOptionsDropdownArrow.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const isHidden = savingOptionsDropdown.classList.contains('hidden') || savingOptionsDropdown.style.display === 'none';
      
      if (isHidden) {
        closeAllDropdowns(savingOptionsDropdown);
        // Use setTimeout to ensure closeAllDropdowns completes first
        setTimeout(() => {
          savingOptionsDropdown.classList.remove('hidden');
          savingOptionsDropdown.style.display = 'block';
          savingOptionsDropdown.style.visibility = 'visible';
          savingOptionsDropdown.style.opacity = '1';
          savingOptionsDropdown.style.zIndex = '10001';
        }, 0);
      } else {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (savingOptionsDropdown && 
          !savingOptionsDropdown.contains(e.target) && 
          e.target !== savingOptionsDropdownArrow && 
          e.target !== savingOptionsButton &&
          !savingOptionsDropdownArrow.contains(e.target) &&
          !savingOptionsButton.contains(e.target)) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
    });
  }

  // Get old button references for backward compatibility (for other parts of code)
  // These will be set after the dropdown items are defined
  const importProjectModal = document.getElementById('importProjectModal');
  const restoreBackupModal = document.getElementById('restoreBackupModal');
  const importProjectFileInput = document.getElementById('importProjectFileInput');
  const restoreBackupFileInput = document.getElementById('restoreBackupFileInput');
  const selectImportProjectFileBtn = document.getElementById('selectImportProjectFileBtn');
  const selectRestoreBackupFileBtn = document.getElementById('selectRestoreBackupFileBtn');
  const confirmImportProjectBtn = document.getElementById('confirmImportProjectBtn');
  const confirmRestoreBackupBtn = document.getElementById('confirmRestoreBackupBtn');
  const closeImportProjectModal = document.getElementById('closeImportProjectModal');
  const closeRestoreBackupModal = document.getElementById('closeRestoreBackupModal');
  const importProjectFileName = document.getElementById('importProjectFileName');
  const restoreBackupFileName = document.getElementById('restoreBackupFileName');
  const importProjectError = document.getElementById('importProjectError');
  const restoreBackupError = document.getElementById('restoreBackupError');

  // Export project dropdown item
  if (exportProjectDropdownItem) {
    exportProjectDropdownItem.addEventListener('click', async () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      if (!currentAnalysisId) return;
      try {
        exportProjectDropdownItem.disabled = true;
        await window.backupUtils.exportProject(currentAnalysisId);
        alert('Project exported successfully!');
      } catch (error) {
        console.error('Export error:', error);
        alert('Error exporting project: ' + error.message);
      } finally {
        exportProjectDropdownItem.disabled = false;
      }
    });
  }

  // Export notes (PDF/HTML) dropdown item
  if (exportNotesDropdownItem) {
    exportNotesDropdownItem.addEventListener('click', () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      if (!currentAnalysisId) {
        alert('Please select a project first.');
        return;
      }
      // Open export preview modal
      if (window.ExportPreview) {
        window.ExportPreview.open(currentAnalysisId);
      } else {
        console.error('ExportPreview not loaded');
        alert('Export feature not available. Please reload the extension.');
      }
    });
  }

  // Import project dropdown item
  if (importProjectDropdownItem) {
    importProjectDropdownItem.addEventListener('click', () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      if (importProjectModal) {
        importProjectModal.classList.remove('hidden');
        importProjectFileInput.value = '';
        importProjectFileName.style.display = 'none';
        importProjectError.style.display = 'none';
        confirmImportProjectBtn.disabled = true;
        if (importProjectFileInput) {
          importProjectFileInput.files = null;
        }
      }
    });
  }

  // Backup dropdown item
  if (backupDropdownItem) {
    backupDropdownItem.addEventListener('click', async () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      try {
        backupDropdownItem.disabled = true;
        await window.backupUtils.exportFullBackup();
        alert('Backup created successfully!');
      } catch (error) {
        console.error('Backup error:', error);
        alert('Error creating backup: ' + error.message);
      } finally {
        backupDropdownItem.disabled = false;
      }
    });
  }

  // Restore dropdown item
  if (restoreDropdownItem) {
    restoreDropdownItem.addEventListener('click', () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      if (restoreBackupModal) {
        restoreBackupModal.classList.remove('hidden');
        restoreBackupFileInput.value = '';
        restoreBackupFileName.style.display = 'none';
        restoreBackupError.style.display = 'none';
        confirmRestoreBackupBtn.disabled = true;
        if (restoreBackupFileInput) {
          restoreBackupFileInput.files = null;
        }
      }
    });
  }

  // Backward compatibility variables removed - use dropdown items directly

  // Import project file selection
  if (selectImportProjectFileBtn) {
    selectImportProjectFileBtn.addEventListener('click', () => {
      importProjectFileInput.click();
    });
  }

    if (importProjectFileInput) {
      importProjectFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          importProjectFileName.textContent = file.name;
          importProjectFileName.style.display = 'block';
          importProjectError.style.display = 'none';
          confirmImportProjectBtn.disabled = false;
        } else {
          importProjectFileName.textContent = '';
          importProjectFileName.style.display = 'none';
          confirmImportProjectBtn.disabled = true;
        }
      });
    }

  // Restore backup file selection
  if (selectRestoreBackupFileBtn) {
    selectRestoreBackupFileBtn.addEventListener('click', () => {
      restoreBackupFileInput.click();
    });
  }

    if (restoreBackupFileInput) {
      restoreBackupFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          restoreBackupFileName.textContent = file.name;
          restoreBackupFileName.style.display = 'block';
          restoreBackupError.style.display = 'none';
          confirmRestoreBackupBtn.disabled = false;
        } else {
          restoreBackupFileName.textContent = '';
          restoreBackupFileName.style.display = 'none';
          confirmRestoreBackupBtn.disabled = true;
        }
      });
    }

  // Confirm import project
  if (confirmImportProjectBtn) {
    confirmImportProjectBtn.addEventListener('click', async () => {
      const file = importProjectFileInput.files[0];
      if (!file) return;

      try {
        confirmImportProjectBtn.disabled = true;
        importProjectError.style.display = 'none';
        
        const result = await window.backupUtils.importProject(file, { renameOnConflict: true });
        
        if (result.success) {
          alert(result.message);
          importProjectModal.classList.add('hidden');
          // Reload analyses list
          chrome.storage.local.get(['analyses'], (data) => {
            if (data.analyses) {
              updateAnalysisSelect(data.analyses, result.project.id);
              switchToAnalysis(result.project.id);
            }
          });
        }
      } catch (error) {
        console.error('Import error:', error);
        importProjectError.textContent = error.message || 'Error importing project';
        importProjectError.style.display = 'block';
      } finally {
        confirmImportProjectBtn.disabled = false;
      }
    });
  }

  // Confirm restore backup
  if (confirmRestoreBackupBtn) {
    confirmRestoreBackupBtn.addEventListener('click', async () => {
      const file = restoreBackupFileInput.files[0];
      if (!file) return;

      if (!confirm('Are you sure you want to restore from backup? This will replace all existing data!')) {
        return;
      }

      try {
        confirmRestoreBackupBtn.disabled = true;
        restoreBackupError.style.display = 'none';
        
        const result = await window.backupUtils.importBackup(file);
        
        if (result.success) {
          alert(result.message);
          restoreBackupModal.classList.add('hidden');
          // Reload page or refresh data
          location.reload();
        }
      } catch (error) {
        console.error('Restore error:', error);
        restoreBackupError.textContent = error.message || 'Error restoring backup';
        restoreBackupError.style.display = 'block';
      } finally {
        confirmRestoreBackupBtn.disabled = false;
      }
    });
  }

  // Close modals
  if (closeImportProjectModal) {
    closeImportProjectModal.addEventListener('click', () => {
      importProjectModal.classList.add('hidden');
    });
  }

  if (closeRestoreBackupModal) {
    closeRestoreBackupModal.addEventListener('click', () => {
      restoreBackupModal.classList.add('hidden');
    });
  }


  // Close modals on background click
  if (importProjectModal) {
    importProjectModal.addEventListener('click', (e) => {
      if (e.target === importProjectModal) {
        importProjectModal.classList.add('hidden');
      }
    });
  }

  if (restoreBackupModal) {
    restoreBackupModal.addEventListener('click', (e) => {
      if (e.target === restoreBackupModal) {
        restoreBackupModal.classList.add('hidden');
      }
    });
  }

  // Add video button - show modal
  if (projectAddVideoBtn) {
    projectAddVideoBtn.addEventListener('click', () => {
      if (addVideoModal) {
        addVideoModal.classList.remove('hidden');
        if (videoUrlInput) {
          setTimeout(() => {
            videoUrlInput.focus();
            videoUrlInput.select();
          }, 100);
        }
      }
    });
  }

  // Toggle videos section collapse/expand
  const projectVideosToggle = document.getElementById('projectVideosToggle');
  const projectVideosCollapseBtn = document.getElementById('projectVideosCollapseBtn');
  
  function toggleVideosSection() {
    if (projectVideosSection) {
      projectVideosSection.classList.toggle('collapsed');
    }
  }

  if (projectVideosToggle) {
    projectVideosToggle.addEventListener('click', (e) => {
      // Don't toggle if clicking the add button
      if (e.target.closest('.project-add-video-btn')) {
        return;
      }
      toggleVideosSection();
    });
  }

  if (projectVideosCollapseBtn) {
    projectVideosCollapseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleVideosSection();
    });
  }

  // Close add video modal
  if (closeAddVideoModal) {
    closeAddVideoModal.addEventListener('click', () => {
      if (addVideoModal) {
        addVideoModal.classList.add('hidden');
        if (videoUrlInput) {
          videoUrlInput.value = '';
        }
      }
    });
  }

  // Close modal when clicking outside
  if (addVideoModal) {
    addVideoModal.addEventListener('click', (e) => {
      if (e.target === addVideoModal) {
        addVideoModal.classList.add('hidden');
        if (videoUrlInput) {
          videoUrlInput.value = '';
        }
      }
    });
  }

  // Flag to prevent storage listener from triggering during analysis creation
  let isCreatingAnalysis = false;
  
  function createNewAnalysis() {
    const analysisName = prompt('Enter analysis name:');
    
    if (!analysisName || analysisName.trim() === '') {
      return; // User cancelled or entered empty name
    }
    
    const analysisId = 'analysis_' + Date.now();
    const date = new Date();
    
    const newAnalysis = {
      id: analysisId,
      name: analysisName.trim(),
      date: date.toLocaleDateString(),
      notes: [],
      teams: [], // Initialize teams array
      createdAt: Date.now()
    };
    
    // Set flag to prevent storage listener from firing
    isCreatingAnalysis = true;
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      analyses.push(newAnalysis);
      chrome.storage.local.set({ 
        analyses: analyses,
        currentAnalysisId: analysisId
      }, () => {
        updateAnalysisSelect(analyses, analysisId);
        switchToAnalysis(analysisId);
        // Clear flag after a short delay to allow updates to complete
        setTimeout(() => {
          isCreatingAnalysis = false;
        }, 300);
      });
    });
  }

  // Helper functions to translate event categories and events (same as in editor.js)
  function translateEventCategory(categoryName) {
    if (!window.i18n || !window.i18n.t) return categoryName;
    
    const categoryMap = {
      'Possession phases': 'events.categories.possessionPhases',
      'Ball progression events': 'events.categories.ballProgressionEvents',
      'Chance creation events': 'events.categories.chanceCreationEvents',
      'Defensive structure events': 'events.categories.defensiveStructureEvents',
      'Transition events': 'events.categories.transitionEvents',
      'Set-piece tactical events': 'events.categories.setPieceTacticalEvents',
      'Structural / off-ball tactical events': 'events.categories.structuralOffBallTacticalEvents',
      'Error / critical moment events': 'events.categories.errorCriticalMomentEvents',
      'Protocol recordings': 'events.categories.protocolRecordings',
      'Custom': 'modals.addCustomEvent'
    };
    
    const key = categoryMap[categoryName];
    if (key) {
      const translated = window.i18n.t(key);
      return translated !== key ? translated : categoryName;
    }
    return categoryName;
  }

  function translateEventName(eventName) {
    if (!window.i18n || !window.i18n.t) return eventName;
    
    // Map event names to translation keys (same mapping as editor.js)
    const eventMap = {
      'Build-up': 'events.possessionPhases.buildUp',
      'Consolidation / Middle third possession': 'events.possessionPhases.consolidationMiddleThirdPossession',
      'Final third attack': 'events.possessionPhases.finalThirdAttack',
      'Counterattack': 'events.possessionPhases.counterattack',
      'Transition defense': 'events.possessionPhases.transitionDefense',
      'Set-piece attack': 'events.possessionPhases.setPieceAttack',
      'Set-piece defense': 'events.possessionPhases.setPieceDefense',
      'Progressive pass': 'events.ballProgressionEvents.progressivePass',
      'Line-breaking pass': 'events.ballProgressionEvents.lineBreakingPass',
      'Third-man combination': 'events.ballProgressionEvents.thirdManCombination',
      'Switch of play': 'events.ballProgressionEvents.switchOfPlay',
      'Carry that bypasses a line': 'events.ballProgressionEvents.carryThatBypassesALine',
      'Successful dribble forward': 'events.ballProgressionEvents.successfulDribbleForward',
      'Inside-channel progression': 'events.ballProgressionEvents.insideChannelProgression',
      'Half-space entry': 'events.ballProgressionEvents.halfSpaceEntry',
      'Final third entry': 'events.ballProgressionEvents.finalThirdEntry',
      'Penalty box entry': 'events.ballProgressionEvents.penaltyBoxEntry',
      'Shot': 'events.chanceCreationEvents.shot',
      'Shot on target': 'events.chanceCreationEvents.shotOnTarget',
      'Assist / key pass': 'events.chanceCreationEvents.assistKeyPass',
      'Cutback': 'events.chanceCreationEvents.cutback',
      'Through ball': 'events.chanceCreationEvents.throughBall',
      'Cross (successful)': 'events.chanceCreationEvents.crossSuccessful',
      'Cross (unsuccessful)': 'events.chanceCreationEvents.crossUnsuccessful',
      'Deep completion (dangerous pass inside 20m, no shot)': 'events.chanceCreationEvents.deepCompletion',
      '1v1 attacking win': 'events.chanceCreationEvents.oneVOneAttackingWin',
      '1v1 attacking loss': 'events.chanceCreationEvents.oneVOneAttackingLoss',
      'Pressing action': 'events.defensiveStructureEvents.pressingAction',
      'Pressing trap triggered': 'events.defensiveStructureEvents.pressingTrapTriggered',
      'Ball recovery (high)': 'events.defensiveStructureEvents.ballRecoveryHigh',
      'Ball recovery (mid)': 'events.defensiveStructureEvents.ballRecoveryMid',
      'Ball recovery (low)': 'events.defensiveStructureEvents.ballRecoveryLow',
      'Counterpress success': 'events.defensiveStructureEvents.counterpressSuccess',
      'Counterpress failure': 'events.defensiveStructureEvents.counterpressFailure',
      'Defensive line broken': 'events.defensiveStructureEvents.defensiveLineBroken',
      'Block shot': 'events.defensiveStructureEvents.blockShot',
      'Interception': 'events.defensiveStructureEvents.interception',
      'Tackle/Duel won': 'events.defensiveStructureEvents.tackleDuelWon',
      'Tackle/Duel lost': 'events.defensiveStructureEvents.tackleDuelLost',
      '1v1 defensive win': 'events.defensiveStructureEvents.oneVOneDefensiveWin',
      '1v1 defensive loss': 'events.defensiveStructureEvents.oneVOneDefensiveLoss',
      'Positive transition (winning the ball)': 'events.transitionEvents.positiveTransitionWinningTheBall',
      'Negative transition (losing the ball)': 'events.transitionEvents.negativeTransitionLosingTheBall',
      'Counterattack start': 'events.transitionEvents.counterattackStart',
      'Dangerous turnover': 'events.transitionEvents.dangerousTurnover',
      'Turnover leading to chance': 'events.transitionEvents.turnoverLeadingToChance',
      'Recovery leading to chance': 'events.transitionEvents.recoveryLeadingToChance',
      'Corner attack': 'events.setPieceTacticalEvents.cornerAttack',
      'Corner defense': 'events.setPieceTacticalEvents.cornerDefense',
      'Free kick (crossing)': 'events.setPieceTacticalEvents.freeKickCrossing',
      'Free kick (shooting)': 'events.setPieceTacticalEvents.freeKickShooting',
      'Throw-in routine (only if structured, e.g., long throw)': 'events.setPieceTacticalEvents.throwInRoutine',
      'Second ball win': 'events.setPieceTacticalEvents.secondBallWin',
      'Second ball loss': 'events.setPieceTacticalEvents.secondBallLoss',
      'Set-piece chance created': 'events.setPieceTacticalEvents.setPieceChanceCreated',
      'Overload created (right)': 'events.structuralOffBallTacticalEvents.overloadCreatedRight',
      'Overload created (left)': 'events.structuralOffBallTacticalEvents.overloadCreatedLeft',
      'Overload created (central)': 'events.structuralOffBallTacticalEvents.overloadCreatedCentral',
      'Overload lost': 'events.structuralOffBallTacticalEvents.overloadLost',
      'Bad spacing / poor distances': 'events.structuralOffBallTacticalEvents.badSpacingPoorDistances',
      'Line height shift (too high)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooHigh',
      'Line height shift (too low)': 'events.structuralOffBallTacticalEvents.lineHeightShiftTooLow',
      'Offside trap activated (successful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedSuccessful',
      'Offside trap activated (unsuccessful)': 'events.structuralOffBallTacticalEvents.offsideTrapActivatedUnsuccessful',
      'Numerical superiority achieved': 'events.structuralOffBallTacticalEvents.numericalSuperiorityAchieved',
      'Numerical superiority lost': 'events.structuralOffBallTacticalEvents.numericalSuperiorityLost',
      'Error leading to shot': 'events.errorCriticalMomentEvents.errorLeadingToShot',
      'Error leading to goal': 'events.errorCriticalMomentEvents.errorLeadingToGoal',
      'Poor clearance': 'events.errorCriticalMomentEvents.poorClearance',
      'Bad decision under pressure': 'events.errorCriticalMomentEvents.badDecisionUnderPressure',
      'Miscommunication': 'events.errorCriticalMomentEvents.miscommunication',
      'Failed press': 'events.errorCriticalMomentEvents.failedPress',
      'Goal': 'events.protocolRecordings.goal',
      'Assist': 'events.protocolRecordings.assist',
      'Substitution': 'events.protocolRecordings.substitution',
      'Penalty': 'events.protocolRecordings.penalty',
      'Red card': 'events.protocolRecordings.redCard',
      'Yellow card': 'events.protocolRecordings.yellowCard'
    };
    
    const key = eventMap[eventName];
    if (key) {
      const translated = window.i18n.t(key);
      return translated !== key ? translated : eventName;
    }
    return eventName;
  }

  // Event data structure
  const EVENT_CATEGORIES = [
    {
      name: 'Possession phases',
      events: [
        'Build-up',
        'Consolidation / Middle third possession',
        'Final third attack',
        'Counterattack',
        'Transition defense',
        'Set-piece attack',
        'Set-piece defense'
      ]
    },
    {
      name: 'Ball progression events',
      events: [
        'Progressive pass',
        'Line-breaking pass',
        'Third-man combination',
        'Switch of play',
        'Carry that bypasses a line',
        'Successful dribble forward',
        'Inside-channel progression',
        'Half-space entry',
        'Final third entry',
        'Penalty box entry'
      ]
    },
    {
      name: 'Chance creation events',
      events: [
        'Shot',
        'Shot on target',
        'Assist / key pass',
        'Cutback',
        'Through ball',
        'Cross (successful)',
        'Cross (unsuccessful)',
        'Deep completion (dangerous pass inside 20m, no shot)',
        '1v1 attacking win',
        '1v1 attacking loss'
      ]
    },
    {
      name: 'Defensive structure events',
      events: [
        'Pressing action',
        'Pressing trap triggered',
        'Ball recovery (high)',
        'Ball recovery (mid)',
        'Ball recovery (low)',
        'Counterpress success',
        'Counterpress failure',
        'Defensive line broken',
        'Block shot',
        'Interception',
        'Tackle/Duel won',
        'Tackle/Duel lost',
        '1v1 defensive win',
        '1v1 defensive loss'
      ]
    },
    {
      name: 'Transition events',
      events: [
        'Positive transition (winning the ball)',
        'Negative transition (losing the ball)',
        'Counterattack start',
        'Dangerous turnover',
        'Turnover leading to chance',
        'Recovery leading to chance'
      ]
    },
    {
      name: 'Set-piece tactical events',
      events: [
        'Corner attack',
        'Corner defense',
        'Free kick (crossing)',
        'Free kick (shooting)',
        'Throw-in routine (only if structured, e.g., long throw)',
        'Second ball win',
        'Second ball loss',
        'Set-piece chance created'
      ]
    },
    {
      name: 'Structural / off-ball tactical events',
      events: [
        'Overload created (right)',
        'Overload created (left)',
        'Overload created (central)',
        'Overload lost',
        'Bad spacing / poor distances',
        'Line height shift (too high)',
        'Line height shift (too low)',
        'Offside trap activated (successful)',
        'Offside trap activated (unsuccessful)',
        'Numerical superiority achieved',
        'Numerical superiority lost'
      ]
    },
    {
      name: 'Error / critical moment events',
      events: [
        'Error leading to shot',
        'Error leading to goal',
        'Poor clearance',
        'Bad decision under pressure',
        'Miscommunication',
        'Failed press'
      ]
    },
    {
      name: 'Protocol recordings',
      events: [
        'Goal',
        'Assist',
        'Substitution',
        'Penalty',
        'Red card',
        'Yellow card'
      ]
    }
  ];

  // Global custom events storage (shared across all analyses)
  // Format: [{name: 'Event Name', category: 'Category Name'}, ...]
  let customEvents = [];

  // Load custom events from storage
  function loadCustomEvents() {
    try {
      chrome.storage.local.get(['customEvents'], (result) => {
        const loadedEvents = result.customEvents || [];
        // Migrate old format (array of strings) to new format (array of objects)
        customEvents = loadedEvents.map(event => {
          if (typeof event === 'string') {
            // Old format: just a string, assign to 'Custom' category
            return { name: event, category: 'Custom' };
          }
          // New format: already an object
          return event;
        });
        saveCustomEvents(); // Save migrated format
        renderEventSelector();
        loadCategoriesForCustomEventModal();
      });
    } catch (e) {
      console.error('Error loading custom events:', e);
      customEvents = [];
    }
  }

  // Save custom events to storage
  function saveCustomEvents() {
    try {
      chrome.storage.local.set({ customEvents: customEvents }, () => {
        console.log('Custom events saved');
      });
    } catch (e) {
      console.error('Error saving custom events:', e);
    }
  }

  // Get all events (standard + custom)
  function getAllEvents() {
    const allEvents = [];
    EVENT_CATEGORIES.forEach(category => {
      category.events.forEach(event => {
        allEvents.push(event);
      });
    });
    customEvents.forEach(eventObj => {
      const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
      allEvents.push(eventName);
    });
    return allEvents;
  }

  // Load categories for custom event modal
  function loadCategoriesForCustomEventModal() {
    const categorySelect = document.getElementById('customEventCategorySelect');
    if (!categorySelect) return;
    
    categorySelect.innerHTML = '<option value="">Select category...</option>';
    
    EVENT_CATEGORIES.forEach(category => {
      const option = document.createElement('option');
      option.value = category.name;
      option.textContent = category.name;
      categorySelect.appendChild(option);
    });
    
    // Add "Custom" as an option
    const customOption = document.createElement('option');
    customOption.value = 'Custom';
    customOption.textContent = 'Custom';
    categorySelect.appendChild(customOption);
  }

  // Zones categories
  const ZONES_CATEGORIES = [
    {
      name: 'Defensive third',
      zones: [1, 2, 3, 4, 5, 6]
    },
    {
      name: 'Middle third',
      zones: [7, 8, 9, 10, 11, 12]
    },
    {
      name: 'Attacking third',
      zones: [13, 14, 15, 16, 17, 18]
    }
  ];

  // Render zones selector
  function renderZonesSelector(searchTerm = '') {
    const dropdown = document.getElementById('zonesSelectorDropdown');
    const categoriesDiv = document.getElementById('zonesCategories');
    if (!dropdown || !categoriesDiv) {
      console.warn('Zones selector elements not found');
      return;
    }

    categoriesDiv.innerHTML = '';

    const searchLower = searchTerm.toLowerCase().trim();

    ZONES_CATEGORIES.forEach(category => {
      // Filter zones based on search term
      const filteredZones = searchTerm
        ? category.zones.filter(zone => zone.toString().includes(searchLower) || category.name.toLowerCase().includes(searchLower))
        : category.zones; // Show all zones when no search term

      // Skip category only if search term exists and no matches found
      if (searchTerm && filteredZones.length === 0) return;

      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'zones-category';

      const categoryName = document.createElement('div');
      categoryName.className = 'zones-category-name';
      categoryName.textContent = category.name;
      categoryDiv.appendChild(categoryName);

      filteredZones.forEach(zoneNumber => {
        const zoneItem = document.createElement('div');
        zoneItem.className = 'zones-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `zone-${zoneNumber}`;
        checkbox.value = zoneNumber;
        checkbox.checked = selectedZones.includes(zoneNumber);
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedZones.includes(zoneNumber)) {
              selectedZones.push(zoneNumber);
            }
          } else {
            selectedZones = selectedZones.filter(z => z !== zoneNumber);
          }
          updateSelectedZonesDisplay();
        });

        const label = document.createElement('label');
        label.htmlFor = `zone-${zoneNumber}`;
        label.textContent = `Zone ${zoneNumber}`;

        zoneItem.appendChild(checkbox);
        zoneItem.appendChild(label);
        categoryDiv.appendChild(zoneItem);
      });

      categoriesDiv.appendChild(categoryDiv);
    });
  }

  // Update selected zones display
  function updateSelectedZonesDisplay() {
    const display = document.getElementById('selectedZonesDisplay');
    if (!display) return;

    display.innerHTML = '';

    // Sort zones numerically
    const sortedZones = [...selectedZones].sort((a, b) => a - b);

    sortedZones.forEach(zone => {
      const tag = document.createElement('div');
      tag.className = 'zone-tag';
      tag.innerHTML = `
        <span>Zone ${zone}</span>
        <span class="zone-tag-remove" data-zone="${zone}">×</span>
      `;
      
      const removeBtn = tag.querySelector('.zone-tag-remove');
      removeBtn.addEventListener('click', () => {
        selectedZones = selectedZones.filter(z => z !== zone);
        updateSelectedZonesDisplay();
        renderZonesSelector(document.getElementById('zonesSearchInput')?.value || '');
      });

      display.appendChild(tag);
    });
  }

  // Render event selector
  function renderEventSelector(searchTerm = '') {
    const dropdown = document.getElementById('eventSelectorDropdown');
    const categoriesDiv = document.getElementById('eventCategories');
    if (!dropdown || !categoriesDiv) {
      console.warn('Event selector elements not found');
      return;
    }

    categoriesDiv.innerHTML = '';

    const searchLower = searchTerm.toLowerCase().trim();
    let totalEventsRendered = 0;

    // Group custom events by category first
    const customEventsByCategory = {};
    customEvents.forEach(eventObj => {
      const eventName = typeof eventObj === 'string' ? eventObj : eventObj.name;
      const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
      
      if (!customEventsByCategory[category]) {
        customEventsByCategory[category] = [];
      }
      customEventsByCategory[category].push(eventName);
    });

    // Get all standard category names
    const standardCategoryNames = EVENT_CATEGORIES.map(cat => cat.name);

    EVENT_CATEGORIES.forEach(category => {
      // Filter standard events based on search term
      const filteredStandardEvents = searchTerm 
        ? category.events.filter(event => event.toLowerCase().includes(searchLower))
        : category.events; // Show all events when no search term

      // Get custom events for this category
      const customEventsInCategory = customEventsByCategory[category.name] || [];
      const filteredCustomEvents = searchTerm
        ? customEventsInCategory.filter(event => event.toLowerCase().includes(searchLower))
        : customEventsInCategory;

      // Combine standard and custom events
      const allEventsInCategory = [...filteredStandardEvents, ...filteredCustomEvents];

      // Skip category only if search term exists and no matches found
      if (searchTerm && allEventsInCategory.length === 0) return;

      const categoryDiv = document.createElement('div');
      categoryDiv.className = 'event-category';

      const categoryName = document.createElement('div');
      categoryName.className = 'event-category-name';
      categoryName.textContent = translateEventCategory(category.name);
      categoryDiv.appendChild(categoryName);

      // Render standard events
      filteredStandardEvents.forEach(event => {
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        // Create a safe ID by replacing special characters
        const safeId = `event-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
        checkbox.id = safeId;
        checkbox.value = event;
        checkbox.checked = selectedEvents.includes(event);
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedEvents.includes(event)) {
              selectedEvents.push(event);
            }
          } else {
            selectedEvents = selectedEvents.filter(e => e !== event);
          }
          updateSelectedEventsDisplay();
        });

        const label = document.createElement('label');
        label.htmlFor = safeId;
        label.textContent = translateEventName(event);

        eventItem.appendChild(checkbox);
        eventItem.appendChild(label);
        categoryDiv.appendChild(eventItem);
        totalEventsRendered++;
      });

      // Render custom events in this category (with edit/delete buttons)
      filteredCustomEvents.forEach(event => {
          const eventItem = document.createElement('div');
          eventItem.className = 'event-item';
          eventItem.style.display = 'flex';
          eventItem.style.alignItems = 'center';
          eventItem.style.padding = '4px 8px';
          eventItem.style.borderRadius = '4px';
          
          eventItem.addEventListener('mouseenter', () => {
            eventItem.style.background = '#21262d';
          });
          eventItem.addEventListener('mouseleave', () => {
            eventItem.style.background = 'transparent';
          });

          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          // Create a safe ID by replacing special characters
          const safeId = `event-custom-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
          checkbox.id = safeId;
          checkbox.value = event;
          checkbox.checked = selectedEvents.includes(event);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedEvents.includes(event)) {
                selectedEvents.push(event);
              }
            } else {
              selectedEvents = selectedEvents.filter(e => e !== event);
            }
            updateSelectedEventsDisplay();
          });

          const label = document.createElement('label');
          label.htmlFor = safeId;
          label.textContent = event;
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';

          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit event';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            renameCustomEvent(event);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete event';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteCustomEvent(event);
          });

          eventItem.appendChild(checkbox);
          eventItem.appendChild(label);
          eventItem.appendChild(editBtn);
          eventItem.appendChild(deleteBtn);
          categoryDiv.appendChild(eventItem);
        });

      if (allEventsInCategory.length > 0) {
        categoriesDiv.appendChild(categoryDiv);
        totalEventsRendered += filteredCustomEvents.length;
      }
    });
    
    // Render custom events that are in categories that don't exist in standard categories
    Object.keys(customEventsByCategory).forEach(categoryName => {
      // Skip if this category is already rendered (it's a standard category)
      if (standardCategoryNames.includes(categoryName)) {
        return;
      }

      const categoryEvents = customEventsByCategory[categoryName];
      const filteredCustom = searchTerm
        ? categoryEvents.filter(event => event.toLowerCase().includes(searchLower))
        : categoryEvents;

      if (filteredCustom.length > 0) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'event-category';

        const categoryNameDiv = document.createElement('div');
        categoryNameDiv.className = 'event-category-name';
        categoryNameDiv.textContent = categoryName;
        categoryDiv.appendChild(categoryNameDiv);

        filteredCustom.forEach(event => {
          const eventItem = document.createElement('div');
          eventItem.className = 'event-item';
          eventItem.style.display = 'flex';
          eventItem.style.alignItems = 'center';
          eventItem.style.padding = '4px 8px';
          eventItem.style.borderRadius = '4px';
          
          eventItem.addEventListener('mouseenter', () => {
            eventItem.style.background = '#21262d';
          });
          eventItem.addEventListener('mouseleave', () => {
            eventItem.style.background = 'transparent';
          });

          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          // Create a safe ID by replacing special characters
          const safeId = `event-custom-${event.replace(/[^a-zA-Z0-9]/g, '-')}`;
          checkbox.id = safeId;
          checkbox.value = event;
          checkbox.checked = selectedEvents.includes(event);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedEvents.includes(event)) {
                selectedEvents.push(event);
              }
            } else {
              selectedEvents = selectedEvents.filter(e => e !== event);
            }
            updateSelectedEventsDisplay();
          });

          const label = document.createElement('label');
          label.htmlFor = safeId;
          label.textContent = event;
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';

          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit event';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            renameCustomEvent(event);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete event';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteCustomEvent(event);
          });

          eventItem.appendChild(checkbox);
          eventItem.appendChild(label);
          eventItem.appendChild(editBtn);
          eventItem.appendChild(deleteBtn);
          categoryDiv.appendChild(eventItem);
        });

        categoriesDiv.appendChild(categoryDiv);
        totalEventsRendered += filteredCustom.length;
      }
    });
    
    console.log(`Rendered ${totalEventsRendered} events`);
  }

  // Update selected events display
  function updateSelectedEventsDisplay() {
    const display = document.getElementById('selectedEventsDisplay');
    if (!display) return;

    display.innerHTML = '';

    selectedEvents.forEach(event => {
      const tag = document.createElement('div');
      tag.className = 'event-tag';
      tag.innerHTML = `
        <span>${event}</span>
        <span class="event-tag-remove" data-event="${event}">×</span>
      `;
      
      const removeBtn = tag.querySelector('.event-tag-remove');
      removeBtn.addEventListener('click', () => {
        selectedEvents = selectedEvents.filter(e => e !== event);
        updateSelectedEventsDisplay();
        renderEventSelector(document.getElementById('eventSearchInput')?.value || '');
      });

      display.appendChild(tag);
    });
  }

  // Custom Event modal management
  let currentEditingEventName = null;

  function openCustomEventModal(eventName = null) {
    const customEventModal = document.getElementById('customEventModal');
    const customEventModalTitle = customEventModal ? customEventModal.querySelector('h3') : null;
    const customEventNameInput = document.getElementById('customEventNameInput');
    const customEventCategorySelect = document.getElementById('customEventCategorySelect');
    
    if (!customEventModal || !customEventNameInput || !customEventCategorySelect) {
      console.error('Custom event modal elements not found');
      return;
    }

    currentEditingEventName = eventName;
    
    if (eventName) {
      // Editing existing event
      if (customEventModalTitle) {
        customEventModalTitle.textContent = 'Edit Custom Event';
      }
      customEventNameInput.value = eventName;
      
      // Find the event and set its category
      const eventObj = customEvents.find(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name === eventName;
      });
      if (eventObj) {
        const category = typeof eventObj === 'string' ? 'Custom' : (eventObj.category || 'Custom');
        customEventCategorySelect.value = category;
      } else {
        customEventCategorySelect.value = 'Custom';
      }
    } else {
      // Creating new event
      if (customEventModalTitle) {
        customEventModalTitle.textContent = 'Add Custom Event';
      }
      customEventNameInput.value = '';
      customEventCategorySelect.value = '';
    }
    
    customEventModal.classList.remove('hidden');
    customEventNameInput.focus();
  }

  function closeCustomEventModal() {
    const customEventModal = document.getElementById('customEventModal');
    if (customEventModal) {
      customEventModal.classList.add('hidden');
      currentEditingEventName = null;
    }
  }

  function saveCustomEventFromModal() {
    const customEventNameInput = document.getElementById('customEventNameInput');
    const customEventCategorySelect = document.getElementById('customEventCategorySelect');
    
    if (!customEventNameInput || !customEventCategorySelect) {
      return;
    }
    
    const eventName = customEventNameInput.value.trim();
    const category = customEventCategorySelect.value.trim();
    
    if (!eventName) {
      showErrorModal('Please enter an event name.');
      return;
    }
    
    if (!category) {
      showErrorModal('Please select a category.');
      return;
    }
    
    if (currentEditingEventName) {
      // Editing existing event
      const eventIndex = customEvents.findIndex(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name === currentEditingEventName;
      });
      
      if (eventIndex !== -1) {
        // Check if new name already exists (and it's not the same event)
        const allEvents = getAllEvents();
        if (eventName !== currentEditingEventName && allEvents.includes(eventName)) {
          showErrorModal('This event name already exists.');
          return;
        }
        
        // Update the event
        customEvents[eventIndex] = { name: eventName, category: category };
        saveCustomEvents();
        
        // Update selectedEvents if the renamed event was selected
        if (selectedEvents.includes(currentEditingEventName)) {
          selectedEvents = selectedEvents.map(e => e === currentEditingEventName ? eventName : e);
          updateSelectedEventsDisplay();
        }
        
        closeCustomEventModal();
        renderEventSelector(document.getElementById('eventSearchInput')?.value || '');
      }
    } else {
      // Creating new event
    // Check if event already exists
    const allEvents = getAllEvents();
      if (allEvents.includes(eventName)) {
        showErrorModal('This event already exists.');
      return;
    }

      customEvents.push({ name: eventName, category: category });
    saveCustomEvents();
      closeCustomEventModal();
    renderEventSelector(document.getElementById('eventSearchInput')?.value || '');
    
    // Auto-select the newly added custom event
      if (!selectedEvents.includes(eventName)) {
        selectedEvents.push(eventName);
      updateSelectedEventsDisplay();
      renderEventSelector(document.getElementById('eventSearchInput')?.value || '');
      }
    }
  }

  function renameCustomEvent(oldEventName, newEventName = null) {
    // If newEventName is provided, it's being called from saveCustomEventFromModal
    // Otherwise, it's being called from the edit button, so open the modal
    if (!newEventName) {
      openCustomEventModal(oldEventName);
      return;
    }
    
    // This function is now handled by saveCustomEventFromModal
    // Keeping for backward compatibility but shouldn't be called directly
  }

  function deleteCustomEvent(eventName) {
    showDeleteConfirmModal(`Are you sure you want to delete the custom event "${eventName}"? This will remove the event from all notes.`, () => {
      // Remove from custom events array
      customEvents = customEvents.filter(e => {
        const name = typeof e === 'string' ? e : e.name;
        return name !== eventName;
      });
      saveCustomEvents();
    
      // Remove from selectedEvents if it was selected
      if (selectedEvents.includes(eventName)) {
        selectedEvents = selectedEvents.filter(e => e !== eventName);
        updateSelectedEventsDisplay();
      }
      
      // Update all notes in all analyses that reference this event
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        let updated = false;
        
        analyses.forEach(analysis => {
          if (analysis.notes) {
            analysis.notes.forEach(note => {
              if (note.events && Array.isArray(note.events)) {
                const eventIndex = note.events.indexOf(eventName);
                if (eventIndex !== -1) {
                  note.events.splice(eventIndex, 1);
                  // If events array is now empty, set it to null
                  if (note.events.length === 0) {
                    note.events = null;
                  }
                  updated = true;
                }
              }
            });
          }
        });
        
        if (updated) {
          chrome.storage.local.set({ analyses: analyses }, () => {
            console.log('Removed event references from notes');
          });
        }
      });
      
      renderEventSelector(document.getElementById('eventSearchInput')?.value || '');
    });
  }

  // Add custom event
  function addCustomEvent() {
    openCustomEventModal();
  }

  // Custom Event modal event listeners
  const customEventModal = document.getElementById('customEventModal');
  const closeCustomEventModalBtn = document.getElementById('closeCustomEventModal');
  const cancelCustomEventBtn = document.getElementById('cancelCustomEventBtn');
  const saveCustomEventBtn = document.getElementById('saveCustomEventBtn');
  const customEventNameInput = document.getElementById('customEventNameInput');
  
  if (closeCustomEventModalBtn) {
    closeCustomEventModalBtn.addEventListener('click', closeCustomEventModal);
  }
  
  if (cancelCustomEventBtn) {
    cancelCustomEventBtn.addEventListener('click', closeCustomEventModal);
  }
  
  if (saveCustomEventBtn) {
    saveCustomEventBtn.addEventListener('click', saveCustomEventFromModal);
  }
  
  if (customEventModal) {
    customEventModal.addEventListener('click', (e) => {
      if (e.target === customEventModal) {
        closeCustomEventModal();
      }
    });
    
    if (customEventNameInput) {
      customEventNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          saveCustomEventFromModal();
        }
      });
    }
  }

  // Player management functions
  function renderPlayerSelector(searchQuery = '') {
    if (!playerList) return;

    chrome.storage.local.get(['players', 'analyses', 'teams'], (result) => {
      const players = result.players || [];
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];

      // Get team names for attached teams
      const attachedTeamNames = new Set();
      globalTeams.forEach(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        const teamName = getTeamName(team);
        if (attachedTeamIds.includes(teamId)) {
          attachedTeamNames.add(teamName);
        }
      });

      // Filter players by attached teams first, then by search query
      const filteredPlayers = players.filter(player => {
        // Only include players from attached teams
        if (!attachedTeamNames.has(player.team)) {
          return false;
        }

        // Then filter by search query
        const searchLower = searchQuery.toLowerCase();
        const fullName = (player.fullName || '').toLowerCase();
        const number = (player.number || '').toString();
        const team = (player.team || '').toLowerCase();
        return fullName.includes(searchLower) ||
               number.includes(searchLower) ||
               team.includes(searchLower);
      });
      
      playerList.innerHTML = '';
      
      if (filteredPlayers.length === 0) {
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.style.textAlign = 'center';
        emptyMsg.textContent = searchQuery ? 'No players found' : 'No players created yet';
        playerList.appendChild(emptyMsg);
        return;
      }
      
      // Group by team
      const playersByTeam = {};
      filteredPlayers.forEach(player => {
        const team = player.team || 'No team';
        if (!playersByTeam[team]) {
          playersByTeam[team] = [];
        }
        playersByTeam[team].push(player);
      });
      
      // Sort teams
      const sortedTeams = Object.keys(playersByTeam).sort();
      
      sortedTeams.forEach(team => {
        const teamDiv = document.createElement('div');
        teamDiv.style.marginBottom = '8px';
        
        const teamLabel = document.createElement('div');
        teamLabel.style.fontSize = '11px';
        teamLabel.style.color = '#8b949e';
        teamLabel.style.marginBottom = '4px';
        teamLabel.textContent = team;
        teamDiv.appendChild(teamLabel);
        
        playersByTeam[team].sort((a, b) => {
          const numA = parseInt(a.number) || 0;
          const numB = parseInt(b.number) || 0;
          return numA - numB;
        }).forEach(player => {
          const playerItem = document.createElement('div');
          playerItem.style.display = 'flex';
          playerItem.style.alignItems = 'center';
          playerItem.style.padding = '4px 8px';
          playerItem.style.cursor = 'pointer';
          playerItem.style.borderRadius = '4px';
          
          playerItem.addEventListener('mouseenter', () => {
            playerItem.style.background = '#21262d';
          });
          playerItem.addEventListener('mouseleave', () => {
            playerItem.style.background = 'transparent';
          });
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = player.id;
          checkbox.checked = selectedPlayers.includes(player.id);
          checkbox.style.marginRight = '8px';
          checkbox.style.cursor = 'pointer';
          
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!selectedPlayers.includes(player.id)) {
                selectedPlayers.push(player.id);
              }
            } else {
              selectedPlayers = selectedPlayers.filter(id => id !== player.id);
            }
            updateSelectedPlayersDisplay();
          });
          
          const label = document.createElement('label');
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          
          const displayText = player.number ? 
            `#${player.number} ${player.fullName || ''}`.trim() : 
            (player.fullName || 'Unnamed');
          label.textContent = displayText;
          
          label.addEventListener('click', () => {
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
          });
          
          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit player';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editPlayer(player.id);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete player';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deletePlayer(player.id);
          });
          
          playerItem.appendChild(checkbox);
          playerItem.appendChild(label);
          playerItem.appendChild(editBtn);
          playerItem.appendChild(deleteBtn);
          teamDiv.appendChild(playerItem);
        });
        
        playerList.appendChild(teamDiv);
      });
    });
  }

  function updateSelectedPlayersDisplay() {
    if (!selectedPlayersDisplay) return;
    
    if (selectedPlayers.length === 0) {
      selectedPlayersDisplay.innerHTML = '';
      updateSelectedTeamDisplay();
      return;
    }
    
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const selectedPlayerObjects = players.filter(p => selectedPlayers.includes(p.id));
      
      selectedPlayersDisplay.innerHTML = '';
      
      const label = document.createElement('div');
      label.style.fontSize = '11px';
      label.style.color = '#8b949e';
      label.style.marginBottom = '4px';
      label.textContent = 'Selected players:';
      selectedPlayersDisplay.appendChild(label);
      
      selectedPlayerObjects.forEach(player => {
        const tag = document.createElement('span');
        tag.className = 'selected-player-tag';
        tag.style.display = 'inline-flex';
        tag.style.alignItems = 'center';
        tag.style.background = '#21262d';
        tag.style.color = '#c9d1d9';
        tag.style.padding = '4px 8px';
        tag.style.borderRadius = '12px';
        tag.style.fontSize = '12px';
        tag.style.marginRight = '0';
        tag.style.marginBottom = '0';
        
        const displayText = player.number ? 
          `#${player.number} ${player.fullName || ''}`.trim() : 
          (player.fullName || 'Unnamed');
        tag.textContent = displayText;
        
        const removeBtn = document.createElement('span');
        removeBtn.textContent = ' ×';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.marginLeft = '4px';
        removeBtn.style.color = '#8b949e';
        removeBtn.addEventListener('click', () => {
          selectedPlayers = selectedPlayers.filter(id => id !== player.id);
          updateSelectedPlayersDisplay();
          renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        });
        
        tag.appendChild(removeBtn);
        selectedPlayersDisplay.appendChild(tag);
      });
      
      // Update teams display based on selected players
      updateSelectedTeamDisplay();
    });
  }

  // Player modal management
  let currentEditingPlayerId = null;

  function openPlayerModal(playerId = null) {
    const playerModal = document.getElementById('playerModal');
    const playerModalTitle = document.getElementById('playerModalTitle');
    const playerNameInput = document.getElementById('playerNameInput');
    const playerNumberInput = document.getElementById('playerNumberInput');
    const playerTeamSelect = document.getElementById('playerTeamSelect');
    const playerPositionSelect = document.getElementById('playerPositionSelect');
    
    if (!playerModal || !playerNameInput || !playerNumberInput || !playerTeamSelect) {
      console.error('Player modal elements not found');
      return;
    }
    
    currentEditingPlayerId = playerId;
    
    if (playerId) {
      // Editing existing player
      playerModalTitle.textContent = 'Edit Player';
      chrome.storage.local.get(['players', 'analyses'], (result) => {
        const players = result.players || [];
        const player = players.find(p => p.id === playerId);
        if (player) {
          playerNameInput.value = player.fullName || '';
          playerNumberInput.value = player.number || '';
          if (playerPositionSelect) {
            playerPositionSelect.value = player.position || '';
          }
          loadTeamsForPlayerModal(player.team || '');
        }
      });
    } else {
      // Creating new player
      playerModalTitle.textContent = 'Add Player';
      playerNameInput.value = '';
      playerNumberInput.value = '';
      if (playerPositionSelect) {
        playerPositionSelect.value = '';
      }
      loadTeamsForPlayerModal('');
    }
    
    playerModal.classList.remove('hidden');
    playerNameInput.focus();
  }

  function closePlayerModal() {
    const playerModal = document.getElementById('playerModal');
    if (playerModal) {
      playerModal.classList.add('hidden');
      currentEditingPlayerId = null;
    }
  }

  function loadTeamsForPlayerModal(selectedTeam = '') {
    const playerTeamSelect = document.getElementById('playerTeamSelect');
    if (!playerTeamSelect) return;

    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];

      // Only show teams that are attached to this project
      const teams = globalTeams.filter(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        return attachedTeamIds.includes(teamId);
      });
      
      playerTeamSelect.innerHTML = '<option value="">Select team...</option>';
      
      if (teams.length === 0) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = 'No teams available - create a team first';
        option.disabled = true;
        playerTeamSelect.appendChild(option);
        return;
      }
      
      teams.forEach(team => {
        const option = document.createElement('option');
        const teamName = getTeamName(team);
        option.value = teamName;
        option.textContent = teamName;
        if (teamName === selectedTeam) {
          option.selected = true;
        }
        playerTeamSelect.appendChild(option);
      });
    });
  }

  function savePlayerFromModal() {
    const playerNameInput = document.getElementById('playerNameInput');
    const playerNumberInput = document.getElementById('playerNumberInput');
    const playerTeamSelect = document.getElementById('playerTeamSelect');
    const playerPositionSelect = document.getElementById('playerPositionSelect');
    
    if (!playerNameInput || !playerNumberInput || !playerTeamSelect) {
      return;
    }
    
    const fullName = playerNameInput.value.trim();
    const number = playerNumberInput.value.trim();
    const team = playerTeamSelect.value;
    const position = playerPositionSelect ? playerPositionSelect.value : '';
    
    if (!fullName) {
      alert('Please enter player name.');
      return;
    }
    
    if (!number) {
      alert('Please enter player number.');
      return;
    }
    
    if (!team) {
      alert('Please select a team.');
      return;
    }
    
    if (currentEditingPlayerId) {
      // Editing existing player
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const player = players.find(p => p.id === currentEditingPlayerId);
        if (player) {
          player.fullName = fullName;
          player.number = number;
          player.team = team;
          player.position = position;
          
          chrome.storage.local.set({ players: players }, () => {
            console.log('Player updated:', player);
            closePlayerModal();
            renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            updateSelectedPlayersDisplay();
            updateSelectedTeamDisplay();
            refreshMessages(); // Refresh messages to show updated data
          });
        }
      });
    } else {
      // Creating new player
      const newPlayer = {
        id: Date.now().toString(),
        fullName: fullName,
        number: number,
        team: team,
        position: position
      };
      
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          console.log('New player created:', newPlayer);
          
          // Automatically add player to selected players
          if (!selectedPlayers.includes(newPlayer.id)) {
            selectedPlayers.push(newPlayer.id);
          }
          
          closePlayerModal();
          renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
          updateSelectedPlayersDisplay();
            refreshMessages(); // Refresh messages to show updated data
        });
      });
    }
  }

  function createNewPlayer() {
    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];
      
      // Get teams that are attached to this project
      let availableTeams = [];
      
      if (attachedTeamIds.length > 0) {
        // Filter global teams by attached IDs
        availableTeams = globalTeams.filter(team => {
          const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
          return attachedTeamIds.includes(teamId);
        });
      }
      
      // Fallback: if no attached teams, check analysis.teams for backward compatibility
      if (availableTeams.length === 0 && analysis && analysis.teams && analysis.teams.length > 0) {
        availableTeams = analysis.teams;
      }
      
      if (availableTeams.length === 0) {
        alert('Please create at least one team before adding players.');
        return;
      }
      
      openPlayerModal();
    });
  }

  function editPlayer(playerId) {
    openPlayerModal(playerId);
  }

  // Player modal event listeners
  const playerModal = document.getElementById('playerModal');
  const closePlayerModalBtn = document.getElementById('closePlayerModal');
  const cancelPlayerBtn = document.getElementById('cancelPlayerBtn');
  const savePlayerBtn = document.getElementById('savePlayerBtn');
  
  if (closePlayerModalBtn) {
    closePlayerModalBtn.addEventListener('click', closePlayerModal);
  }
  
  if (cancelPlayerBtn) {
    cancelPlayerBtn.addEventListener('click', closePlayerModal);
  }
  
  if (savePlayerBtn) {
    savePlayerBtn.addEventListener('click', savePlayerFromModal);
  }
  
  if (playerModal) {
    playerModal.addEventListener('click', (e) => {
      if (e.target === playerModal) {
        closePlayerModal();
      }
    });
    
    // Allow Enter key to save
    const playerNameInput = document.getElementById('playerNameInput');
    const playerNumberInput = document.getElementById('playerNumberInput');
    const playerTeamSelect = document.getElementById('playerTeamSelect');
    
    if (playerNameInput) {
      playerNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          playerNumberInput.focus();
        }
      });
    }
    
    if (playerNumberInput) {
      playerNumberInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          playerTeamSelect.focus();
        }
      });
    }
    
    if (playerTeamSelect) {
      playerTeamSelect.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          savePlayerFromModal();
        }
      });
    }
  }

  // Bulk Import Players from CSV
  const toggleImportInstructions = document.getElementById('toggleImportInstructions');
  const importInstructions = document.getElementById('importInstructions');
  const playerImportFile = document.getElementById('playerImportFile');
  const selectImportFileBtn = document.getElementById('selectImportFileBtn');
  const importFileName = document.getElementById('importFileName');
  const importPlayersBtn = document.getElementById('importPlayersBtn');
  const importResultMessage = document.getElementById('importResultMessage');

  if (toggleImportInstructions && importInstructions) {
    toggleImportInstructions.addEventListener('click', () => {
      const isHidden = importInstructions.style.display === 'none';
      importInstructions.style.display = isHidden ? 'block' : 'none';
      toggleImportInstructions.textContent = isHidden ? '×' : '?';
    });
  }

  if (selectImportFileBtn && playerImportFile) {
    selectImportFileBtn.addEventListener('click', () => {
      playerImportFile.click();
    });
  }

  if (playerImportFile) {
    playerImportFile.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        importFileName.textContent = file.name;
        importPlayersBtn.style.display = 'inline-block';
        importResultMessage.style.display = 'none';
      } else {
        importFileName.textContent = '';
        importPlayersBtn.style.display = 'none';
      }
    });
  }

  if (importPlayersBtn) {
    importPlayersBtn.addEventListener('click', () => {
      const file = playerImportFile.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        const csvText = e.target.result;
        parseAndImportPlayers(csvText);
      };
      reader.onerror = () => {
        showImportResult('Error reading file.', 'error');
      };
      reader.readAsText(file);
    });
  }

  function parseAndImportPlayers(csvText) {
    const lines = csvText.split(/\r?\n/).filter(line => line.trim());
    if (lines.length < 2) {
      showImportResult('File must have a header row and at least one data row.', 'error');
      return;
    }

    // Parse header
    const header = parseCSVLine(lines[0]).map(h => h.toLowerCase().trim());
    const nameIdx = header.findIndex(h => h === 'name' || h === 'fullname' || h === 'full name' || h === 'player');
    const numberIdx = header.findIndex(h => h === 'number' || h === 'no' || h === 'num' || h === '#');
    const positionIdx = header.findIndex(h => h === 'position' || h === 'pos');
    const teamIdx = header.findIndex(h => h === 'team' || h === 'club');

    if (nameIdx === -1) {
      showImportResult('CSV must have a "name" column.', 'error');
      return;
    }

    const validPositions = ['GK', 'CB', 'LB', 'RB', 'LWB', 'RWB', 'CDM', 'CM', 'CAM', 'LM', 'RM', 'LW', 'RW', 'CF', 'ST'];

    chrome.storage.local.get(['players', 'teams', 'analyses'], (result) => {
      const existingPlayers = result.players || [];
      const globalTeams = result.teams || [];
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);

      // Build a map of team names (case-insensitive lookup)
      const teamNameMap = new Map();
      globalTeams.forEach(team => {
        const name = typeof team === 'string' ? team : (team.name || '');
        if (name) {
          teamNameMap.set(name.toLowerCase(), name);
        }
      });

      const newPlayers = [];
      const duplicatePlayers = [];
      const newTeams = [];
      const errors = [];

      for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        if (values.length === 0 || values.every(v => !v.trim())) continue;

        const name = nameIdx >= 0 && values[nameIdx] ? values[nameIdx].trim() : '';
        const number = numberIdx >= 0 && values[numberIdx] ? values[numberIdx].trim() : '';
        let position = positionIdx >= 0 && values[positionIdx] ? values[positionIdx].trim().toUpperCase() : '';
        const teamInput = teamIdx >= 0 && values[teamIdx] ? values[teamIdx].trim() : '';

        if (!name) {
          errors.push(`Row ${i + 1}: Missing name`);
          continue;
        }

        // Validate position
        if (position && !validPositions.includes(position)) {
          position = '';
        }

        // Handle team - create if doesn't exist
        let teamName = '';
        if (teamInput) {
          const matchedTeam = teamNameMap.get(teamInput.toLowerCase());
          if (matchedTeam) {
            teamName = matchedTeam;
          } else {
            // Team doesn't exist - create it
            teamName = teamInput;
            teamNameMap.set(teamInput.toLowerCase(), teamName);
            
            // Check if we already queued this team for creation
            const alreadyQueued = newTeams.some(t => t.name.toLowerCase() === teamInput.toLowerCase());
            if (!alreadyQueued) {
              newTeams.push({
                id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                name: teamName,
                homeColor: '#FFFFFF',
                awayColor: '#000000',
                homeDesign: 'solid',
                awayDesign: 'solid',
                homeSecondColor: '#000000',
                awaySecondColor: '#FFFFFF',
                createdAt: Date.now(),
                updatedAt: Date.now()
              });
            }
          }
        }

        const playerData = {
          fullName: name,
          number: number,
          position: position,
          team: teamName
        };

        // Check for potential duplicate (at least 2 of 3 fields match: name, number, team)
        const existingPlayer = existingPlayers.find(p => {
          const nameMatch = p.fullName.toLowerCase() === name.toLowerCase();
          const numberMatch = p.number === number && number !== '';
          const teamMatch = p.team === teamName && teamName !== '';
          
          const matches = [nameMatch, numberMatch, teamMatch].filter(Boolean).length;
          return matches >= 2;
        });

        if (existingPlayer) {
          // Determine what's different
          const changes = [];
          if (existingPlayer.fullName.toLowerCase() !== name.toLowerCase()) {
            changes.push({ field: 'name', from: existingPlayer.fullName, to: name });
          }
          if (existingPlayer.number !== number) {
            changes.push({ field: 'number', from: existingPlayer.number || '-', to: number || '-' });
          }
          if (existingPlayer.team !== teamName) {
            changes.push({ field: 'team', from: existingPlayer.team || '-', to: teamName || '-' });
          }
          if (existingPlayer.position !== position && position) {
            changes.push({ field: 'position', from: existingPlayer.position || '-', to: position });
          }
          
          duplicatePlayers.push({ existing: existingPlayer, newData: playerData, changes });
        } else {
          newPlayers.push({
            id: Date.now().toString() + '_' + Math.random().toString(36).substr(2, 9),
            ...playerData
          });
        }
      }

      // Function to complete the import
      const completeImport = (updateDuplicates) => {
        if (updateDuplicates && duplicatePlayers.length > 0) {
          duplicatePlayers.forEach(dup => {
            dup.existing.fullName = dup.newData.fullName;
            dup.existing.number = dup.newData.number;
            dup.existing.position = dup.newData.position;
            dup.existing.team = dup.newData.team;
          });
        }

        // Combine: existing (possibly updated) + new players
        const allPlayers = [...existingPlayers, ...newPlayers];
        // Combine: existing teams + new teams
        const allTeams = [...globalTeams, ...newTeams];
        
        // Attach new teams to current project
        if (newTeams.length > 0 && analysis) {
          if (!analysis.attachedTeamIds) {
            analysis.attachedTeamIds = [];
          }
          newTeams.forEach(team => {
            if (!analysis.attachedTeamIds.includes(team.id)) {
              analysis.attachedTeamIds.push(team.id);
            }
          });
        }
        
        if (newPlayers.length > 0 || (updateDuplicates && duplicatePlayers.length > 0) || newTeams.length > 0) {
          const saveData = { players: allPlayers, teams: allTeams };
          if (analysis) {
            const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
            if (analysisIndex !== -1) {
              analyses[analysisIndex] = analysis;
              saveData.analyses = analyses;
            }
          }
          
          chrome.storage.local.set(saveData, () => {
            let msg = '';
            if (newTeams.length > 0) {
              msg += `Created ${newTeams.length} new team(s). `;
            }
            if (newPlayers.length > 0) {
              msg += `Imported ${newPlayers.length} new player(s).`;
            }
            if (updateDuplicates && duplicatePlayers.length > 0) {
              msg += msg ? ' ' : '';
              msg += `Updated ${duplicatePlayers.length} existing player(s).`;
            } else if (!updateDuplicates && duplicatePlayers.length > 0) {
              msg += msg ? ' ' : '';
              msg += `Skipped ${duplicatePlayers.length} duplicate(s).`;
            }
            if (errors.length > 0) {
              msg += ` ${errors.length} error(s).`;
            }
            showImportResult(msg, 'success');
            
            // Refresh UI
            if (newTeams.length > 0) {
              renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            }
            renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            updateSelectedPlayersDisplay();
            
            // Clear file input
            playerImportFile.value = '';
            importFileName.textContent = '';
            importPlayersBtn.style.display = 'none';
          });
        } else if (newPlayers.length === 0 && duplicatePlayers.length > 0 && !updateDuplicates) {
          showImportResult(`Skipped ${duplicatePlayers.length} duplicate player(s). No new players imported.`, 'error');
          playerImportFile.value = '';
          importFileName.textContent = '';
          importPlayersBtn.style.display = 'none';
        } else {
          let msg = 'No players imported.';
          if (errors.length > 0) msg += ` Errors: ${errors.slice(0, 3).join('; ')}`;
          showImportResult(msg, 'error');
        }
      };

      // If there are duplicates, show custom modal
      if (duplicatePlayers.length > 0) {
        const duplicateModal = document.getElementById('duplicatePlayersModal');
        const duplicateCountEl = document.getElementById('duplicatePlayersCount');
        const duplicateListEl = document.getElementById('duplicatePlayersList');
        const updateBtn = document.getElementById('duplicatePlayersUpdateBtn');
        const skipBtn = document.getElementById('duplicatePlayersSkipBtn');
        const closeBtn = document.getElementById('closeDuplicatePlayersModal');
        
        // Set count text
        const countText = window.i18n && window.i18n.t 
          ? window.i18n.t('modals.duplicateCount', { count: duplicatePlayers.length })
          : `Found ${duplicatePlayers.length} existing player(s) to update:`;
        duplicateCountEl.textContent = countText;
        
        // Build list showing what will change
        const listItems = duplicatePlayers.slice(0, 8).map(d => {
          const changesHtml = d.changes && d.changes.length > 0 
            ? d.changes.map(c => 
                `<span style="display: inline-block; margin-right: 8px; font-size: 11px;">
                  <span style="color: #6e7681;">${c.field}:</span> 
                  <span style="color: #f85149; text-decoration: line-through;">${c.from}</span> 
                  <span style="color: #3fb950;">→ ${c.to}</span>
                </span>`
              ).join('')
            : '';
          
          return `<div style="padding: 6px 0; border-bottom: 1px solid #21262d;">
            <div style="display: flex; align-items: center; gap: 6px;">
              <span style="color: #c9d1d9; font-weight: 500;">${d.existing.fullName}</span>
              <span style="color: #6e7681;">#${d.existing.number || '-'}</span>
              ${d.existing.team ? `<span style="color: #6e7681; font-size: 12px;">(${d.existing.team})</span>` : ''}
            </div>
            ${changesHtml ? `<div style="margin-top: 4px;">${changesHtml}</div>` : ''}
          </div>`;
        }).join('');
        
        const moreText = duplicatePlayers.length > 8 
          ? `<div style="padding: 6px 0; color: #6e7681; font-style: italic;">...and ${duplicatePlayers.length - 8} more</div>` 
          : '';
        
        duplicateListEl.innerHTML = listItems + moreText;
        
        // Show modal
        duplicateModal.classList.remove('hidden');
        
        // Handle responses
        const handleUpdate = () => {
          cleanup();
          duplicateModal.classList.add('hidden');
          completeImport(true);
        };
        
        const handleSkip = () => {
          cleanup();
          duplicateModal.classList.add('hidden');
          completeImport(false);
        };
        
        const cleanup = () => {
          updateBtn.removeEventListener('click', handleUpdate);
          skipBtn.removeEventListener('click', handleSkip);
          closeBtn.removeEventListener('click', handleSkip);
        };
        
        updateBtn.addEventListener('click', handleUpdate);
        skipBtn.addEventListener('click', handleSkip);
        closeBtn.addEventListener('click', handleSkip);
      } else {
        // No duplicates, just complete the import
        completeImport(false);
      }
    });
  }

  function parseCSVLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if ((char === ',' || char === ';') && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  }

  function showImportResult(message, type) {
    if (!importResultMessage) return;
    importResultMessage.textContent = message;
    importResultMessage.style.display = 'block';
    importResultMessage.style.color = type === 'success' ? '#3fb950' : '#f85149';
  }

  function deletePlayer(playerId) {
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const playerToDelete = players.find(p => p.id === playerId);
      if (!playerToDelete) return;
      
      const displayText = playerToDelete.number ? 
        `#${playerToDelete.number} ${playerToDelete.fullName || ''}`.trim() : 
        (playerToDelete.fullName || 'Unnamed');
      
      if (!confirm(`Are you sure you want to delete player "${displayText}"?`)) {
        return;
      }
      
      const updatedPlayers = players.filter(p => p.id !== playerId);
      chrome.storage.local.set({ players: updatedPlayers }, () => {
        console.log('Player deleted:', playerId);
        selectedPlayers = selectedPlayers.filter(id => id !== playerId);
        renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        updateSelectedPlayersDisplay();
        updateSelectedTeamDisplay();
      });
    });
  }

  function removePlayerFromTeam(playerId) {
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const player = players.find(p => p.id === playerId);
      if (!player) return;
      
      player.team = '';
      chrome.storage.local.set({ players: players }, () => {
        console.log('Player removed from team:', playerId);
        renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
        updateSelectedPlayersDisplay();
        updateSelectedTeamDisplay();
      });
    });
  }

  // Team selector functions
  function renderTeamSelector(searchQuery = '') {
    if (!teamList) return;

    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];

      // Only show teams that are attached to this project
      const teams = globalTeams.filter(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        return attachedTeamIds.includes(teamId);
      });
      const currentSelectedTeam = analysis ? (analysis.selectedTeam || null) : null;
      
      // Filter teams by search query
      const filteredTeams = teams.filter(team => {
        const searchLower = searchQuery.toLowerCase();
        const teamName = getTeamName(team);
        return teamName.toLowerCase().includes(searchLower);
      });
      
      teamList.innerHTML = '';
      
      // Add "No team" option
      const noTeamItem = document.createElement('div');
      noTeamItem.style.display = 'flex';
      noTeamItem.style.alignItems = 'center';
      noTeamItem.style.padding = '4px 8px';
      noTeamItem.style.cursor = 'pointer';
      noTeamItem.style.borderRadius = '4px';
      
      noTeamItem.addEventListener('mouseenter', () => {
        noTeamItem.style.background = '#21262d';
      });
      noTeamItem.addEventListener('mouseleave', () => {
        noTeamItem.style.background = 'transparent';
      });
      
      const noTeamLabel = document.createElement('label');
      noTeamLabel.style.flex = '1';
      noTeamLabel.style.cursor = 'pointer';
      noTeamLabel.style.fontSize = '13px';
      noTeamLabel.style.color = '#c9d1d9';
      noTeamLabel.textContent = 'No team';
      
      if (!currentSelectedTeam || currentSelectedTeam === '') {
        noTeamLabel.style.color = '#1f6feb';
        noTeamLabel.style.fontWeight = '500';
      }
      
      noTeamLabel.addEventListener('click', () => {
        selectedTeam = null;
        selectedTeams = [];
        saveSelectedTeam(null);
        updateSelectedTeamDisplay();
        renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
      });
      
      noTeamItem.appendChild(noTeamLabel);
      teamList.appendChild(noTeamItem);
      
      if (filteredTeams.length === 0 && searchQuery) {
        const emptyMsg = document.createElement('div');
        emptyMsg.style.padding = '10px';
        emptyMsg.style.color = '#8b949e';
        emptyMsg.style.textAlign = 'center';
        emptyMsg.textContent = 'No teams found';
        teamList.appendChild(emptyMsg);
        return;
      }
      
      filteredTeams.forEach(team => {
        const teamName = getTeamName(team);
        const userTeam = analysis ? (analysis.userTeam || null) : null;
        const isUserTeam = userTeam === teamName;
        
        const teamItem = document.createElement('div');
        teamItem.style.display = 'flex';
        teamItem.style.alignItems = 'center';
        teamItem.style.padding = '4px 8px';
        teamItem.style.cursor = 'pointer';
        teamItem.style.borderRadius = '4px';
        
        teamItem.addEventListener('mouseenter', () => {
          teamItem.style.background = '#21262d';
        });
        teamItem.addEventListener('mouseleave', () => {
          teamItem.style.background = 'transparent';
        });
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.value = teamName;
        checkbox.checked = selectedTeams.includes(teamName) || currentSelectedTeam === teamName;
        checkbox.style.marginRight = '8px';
        checkbox.style.cursor = 'pointer';
        
        checkbox.addEventListener('change', (e) => {
          if (e.target.checked) {
            if (!selectedTeams.includes(teamName)) {
              selectedTeams.push(teamName);
            }
          } else {
            selectedTeams = selectedTeams.filter(t => t !== teamName);
          }
          updateSelectedTeamDisplay();
        });
        
        const label = document.createElement('label');
        label.style.flex = '1';
        label.style.cursor = 'pointer';
        label.style.fontSize = '13px';
        label.style.color = '#c9d1d9';
        label.style.display = 'flex';
        label.style.alignItems = 'center';
        label.style.gap = '6px';
        
        // Add star icon if this is the user's team
        if (isUserTeam) {
          const starIcon = document.createElement('span');
          starIcon.textContent = '★';
          starIcon.style.color = '#fbbf24';
          starIcon.style.fontSize = '14px';
          label.appendChild(starIcon);
        }
        
        const teamNameSpan = document.createElement('span');
        teamNameSpan.textContent = teamName;
        label.appendChild(teamNameSpan);
        
        if (selectedTeams.includes(teamName) || currentSelectedTeam === teamName) {
          teamNameSpan.style.color = '#1f6feb';
          teamNameSpan.style.fontWeight = '500';
        }
        
        label.addEventListener('click', () => {
          checkbox.checked = !checkbox.checked;
          checkbox.dispatchEvent(new Event('change'));
        });
        
        const myTeamBtn = document.createElement('button');
        myTeamBtn.textContent = isUserTeam ? '★' : '☆';
        myTeamBtn.style.background = 'transparent';
        myTeamBtn.style.border = 'none';
        myTeamBtn.style.color = isUserTeam ? '#fbbf24' : '#8b949e';
        myTeamBtn.style.cursor = 'pointer';
        myTeamBtn.style.padding = '2px 6px';
        myTeamBtn.style.marginLeft = '4px';
        myTeamBtn.style.fontSize = '14px';
        myTeamBtn.title = isUserTeam ? 'Remove as My Team' : 'Set as My Team';
        myTeamBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (isUserTeam) {
            saveUserTeam(null);
          } else {
            saveUserTeam(teamName);
          }
        });
        
        const editBtn = document.createElement('button');
        editBtn.textContent = '✎';
        editBtn.style.background = 'transparent';
        editBtn.style.border = 'none';
        editBtn.style.color = '#8b949e';
        editBtn.style.cursor = 'pointer';
        editBtn.style.padding = '2px 6px';
        editBtn.style.marginLeft = '4px';
        editBtn.style.fontSize = '12px';
        editBtn.title = 'Edit team';
        editBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          renameSelectedTeam(teamName);
        });
        
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.style.background = 'transparent';
        deleteBtn.style.border = 'none';
        deleteBtn.style.color = '#8b949e';
        deleteBtn.style.cursor = 'pointer';
        deleteBtn.style.padding = '2px 6px';
        deleteBtn.style.marginLeft = '2px';
        deleteBtn.style.fontSize = '16px';
        deleteBtn.title = 'Delete team';
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          deleteSelectedTeam(teamName);
        });
        
        teamItem.appendChild(checkbox);
        teamItem.appendChild(label);
        teamItem.appendChild(myTeamBtn);
        teamItem.appendChild(editBtn);
        teamItem.appendChild(deleteBtn);
        teamList.appendChild(teamItem);
      });
    });
  }

  function updateSelectedTeamDisplay() {
    if (!selectedTeamDisplay) return;
    
    chrome.storage.local.get(['analyses', 'players'], (result) => {
      const analyses = result.analyses || [];
      const players = result.players || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const currentSelectedTeam = analysis ? (analysis.selectedTeam || null) : null;
      
      selectedTeamDisplay.innerHTML = '';
      
      // Get all teams from selected players
      const selectedPlayerObjects = players.filter(p => selectedPlayers.includes(p.id));
      const teamsFromPlayers = [...new Set(selectedPlayerObjects.map(p => p.team).filter(t => t && t.trim() !== ''))];
      
      // Combine manually selected teams with teams from players
      const allTeams = new Set();
      if (currentSelectedTeam) {
        allTeams.add(currentSelectedTeam);
      }
      selectedTeams.forEach(team => allTeams.add(team));
      teamsFromPlayers.forEach(team => allTeams.add(team));
      
      if (allTeams.size > 0) {
        Array.from(allTeams).forEach(team => {
          const tag = document.createElement('span');
          tag.className = 'selected-team-tag';
          tag.style.display = 'inline-flex';
          tag.style.alignItems = 'center';
          tag.style.background = '#21262d';
          tag.style.color = '#c9d1d9';
          tag.style.padding = '4px 8px';
          tag.style.borderRadius = '12px';
          tag.style.fontSize = '12px';
          tag.style.marginRight = '0';
          tag.style.marginBottom = '0';
          tag.textContent = team;
          
          const removeBtn = document.createElement('span');
          removeBtn.textContent = ' ×';
          removeBtn.style.cursor = 'pointer';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.color = '#8b949e';
          removeBtn.addEventListener('click', () => {
            // If this is the manually selected team, clear it
            if (team === currentSelectedTeam) {
              selectedTeam = null;
              saveSelectedTeam(null);
            }
            // Remove from selectedTeams array
            selectedTeams = selectedTeams.filter(t => t !== team);
            // Remove all players from this team from selection
            const playersToRemove = selectedPlayerObjects.filter(p => p.team === team).map(p => p.id);
            selectedPlayers = selectedPlayers.filter(id => !playersToRemove.includes(id));
            updateSelectedPlayersDisplay();
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
          });
          
          tag.appendChild(removeBtn);
          selectedTeamDisplay.appendChild(tag);
        });
      } else if (currentSelectedTeam) {
        // Show manually selected team even if no players
        const tag = document.createElement('span');
        tag.className = 'selected-team-tag';
        tag.style.display = 'inline-block';
        tag.style.background = '#21262d';
        tag.style.color = '#c9d1d9';
        tag.style.padding = '4px 8px';
        tag.style.borderRadius = '12px';
        tag.style.fontSize = '12px';
        tag.style.marginBottom = '4px';
        tag.textContent = currentSelectedTeam;
        
        const removeBtn = document.createElement('span');
        removeBtn.textContent = ' ×';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.marginLeft = '4px';
        removeBtn.style.color = '#8b949e';
        removeBtn.addEventListener('click', () => {
          selectedTeam = null;
          saveSelectedTeam(null);
          updateSelectedTeamDisplay();
          renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
        });
        
        tag.appendChild(removeBtn);
        selectedTeamDisplay.appendChild(tag);
      }
    });
  }

  // Load teams dropdown for current analysis
  function loadTeamsDropdown() {
    // This function is now replaced by renderTeamSelector, but keeping for backward compatibility
    renderTeamSelector('');
    updateSelectedTeamDisplay();
    
    const teamSelect = document.getElementById('teamSelect');
    if (!teamSelect) return;

    if (!currentAnalysisId) {
      teamSelect.innerHTML = '<option value="">No team</option>';
      updateTeamButtonsState();
      return;
    }

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);

        if (analysis) {
          const teams = analysis.teams || [];
          const selectedTeam = analysis.selectedTeam || null;
          teamSelect.innerHTML = '<option value="">No team</option>';
          
          teams.forEach(team => {
            const option = document.createElement('option');
            const teamName = getTeamName(team);
            option.value = teamName;
            option.textContent = teamName;
            teamSelect.appendChild(option);
          });
          
          // Restore selected team
          if (selectedTeam && teams.some(t => getTeamName(t) === selectedTeam)) {
            teamSelect.value = selectedTeam;
          }
        } else {
          teamSelect.innerHTML = '<option value="">No team</option>';
        }
        
        updateTeamButtonsState();
      });
    } catch (e) {
      console.error('Error loading teams dropdown:', e);
    }
  }

  // Update team buttons state (enable/disable based on selection)
  function updateTeamButtonsState() {
    const teamSelect = document.getElementById('teamSelect');
    const renameBtn = document.getElementById('renameTeamBtn');
    const deleteBtn = document.getElementById('deleteTeamBtn');
    
    const hasSelection = teamSelect && teamSelect.value && teamSelect.value !== '';
    
    if (renameBtn) {
      renameBtn.disabled = !hasSelection;
    }
    if (deleteBtn) {
      deleteBtn.disabled = !hasSelection;
    }
  }

  // Save selected team to analysis
  function saveSelectedTeam(teamName) {
    if (!currentAnalysisId) return;

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          analyses[analysisIndex].selectedTeam = teamName || null;
          chrome.storage.local.set({ analyses: analyses }, () => {
            console.log('Selected team saved:', teamName);
            updateSelectedTeamDisplay();
          });
        }
      });
    } catch (e) {
      console.error('Error saving selected team:', e);
    }
  }

  function saveUserTeam(teamName) {
    if (!currentAnalysisId) return;

    try {
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          analyses[analysisIndex].userTeam = teamName || null;
          chrome.storage.local.set({ analyses: analyses }, () => {
            console.log('User team saved:', teamName);
            updateSelectedTeamDisplay();
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
          });
        }
      });
    } catch (e) {
      console.error('Error saving user team:', e);
    }
  }

  // Team modal management
  let currentEditingTeamName = null;
  let reopenManageTeamsAfterTeamCreate = false;

  // Helper functions for team data structure (backward compatible)
  function getTeamName(team) {
    return typeof team === 'string' ? team : (team?.name || '');
  }
  
  function getTeamObject(teamName, teams) {
    if (!teams || !Array.isArray(teams)) return null;
    const team = teams.find(t => getTeamName(t) === teamName);
    if (!team) return null;
    return typeof team === 'string' ? { name: team, homeColor: '#FFFFFF', awayColor: '#000000' } : team;
  }
  
  function ensureTeamObject(team) {
    if (typeof team === 'string') {
      return { name: team, homeColor: '#FFFFFF', awayColor: '#000000', formation: '', squad: {}, homeDesign: 'solid', awayDesign: 'solid', homeSecondColor: '#000000', awaySecondColor: '#FFFFFF' };
    }
    return {
      name: team.name || '',
      homeColor: team.homeColor || '#FFFFFF',
      awayColor: team.awayColor || '#000000',
      formation: team.formation || '',
      squad: team.squad || {},
      homeDesign: team.homeDesign || 'solid',
      awayDesign: team.awayDesign || 'solid',
      homeSecondColor: team.homeSecondColor || '#000000',
      awaySecondColor: team.awaySecondColor || '#FFFFFF'
    };
  }

  // Draw t-shirt preview on canvas
  function drawTshirtPreview(canvas, color, number = '10', design = 'solid', secondColor = '#000000') {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    const centerX = width / 2;
    const centerY = height / 2;
    const shirtWidth = width * 0.7;
    const shirtHeight = height * 0.8;
    const startX = centerX - shirtWidth / 2;
    const startY = centerY - shirtHeight / 2;
    const sleeveLength = shirtWidth * 0.15;
    
    ctx.save();
    
    const primaryColor = color || '#FFFFFF';
    
    // Helper function to create t-shirt path
    const createTshirtPath = () => {
      ctx.beginPath();
      const collarWidth = shirtWidth * 0.4;
      const shoulderWidth = (shirtWidth - collarWidth) / 2;
      
      ctx.moveTo(startX, startY + shirtHeight * 0.1);
      ctx.quadraticCurveTo(startX + shoulderWidth, startY, startX + shoulderWidth, startY + shirtHeight * 0.05);
      ctx.quadraticCurveTo(centerX, startY + shirtHeight * 0.2, startX + shirtWidth - shoulderWidth, startY + shirtHeight * 0.05);
      ctx.quadraticCurveTo(startX + shirtWidth - shoulderWidth, startY, startX + shirtWidth, startY + shirtHeight * 0.1);
      ctx.lineTo(startX + shirtWidth + sleeveLength, startY + shirtHeight * 0.3);
      ctx.lineTo(startX + shirtWidth, startY + shirtHeight * 0.4);
      ctx.lineTo(startX + shirtWidth, startY + shirtHeight);
      ctx.quadraticCurveTo(centerX, startY + shirtHeight + shirtHeight * 0.05, startX, startY + shirtHeight);
      ctx.lineTo(startX, startY + shirtHeight * 0.4);
      ctx.lineTo(startX - sleeveLength, startY + shirtHeight * 0.3);
      ctx.closePath();
    };
    
    // Draw base fill
    createTshirtPath();
    ctx.fillStyle = primaryColor;
    ctx.fill();
    
    // Apply design pattern
    ctx.save();
    createTshirtPath();
    ctx.clip();
    
    const extLeft = startX - sleeveLength;
    const extRight = startX + shirtWidth + sleeveLength;
    const extTop = startY;
    const extBottom = startY + shirtHeight;
    const extWidth = extRight - extLeft;
    const extHeight = extBottom - extTop;
    
    switch (design) {
      case 'sleeves':
        ctx.fillStyle = secondColor;
        ctx.fillRect(extLeft, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        ctx.fillRect(startX + shirtWidth - shirtWidth * 0.1, extTop, sleeveLength + shirtWidth * 0.1, extHeight);
        break;
        
      case 'horiz-stripes':
        const hStripeHeight = extHeight / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft, extTop + i * hStripeHeight, extWidth, hStripeHeight);
        }
        break;
        
      case 'vert-stripes':
        const vStripeWidth = extWidth / 5;
        ctx.fillStyle = secondColor;
        for (let i = 1; i < 5; i += 2) {
          ctx.fillRect(extLeft + i * vStripeWidth, extTop, vStripeWidth, extHeight);
        }
        break;
        
      case 'diagonal-sash':
        ctx.fillStyle = secondColor;
        ctx.beginPath();
        const sashWidth = extWidth * 0.25;
        ctx.moveTo(extLeft, extTop);
        ctx.lineTo(extLeft + sashWidth, extTop);
        ctx.lineTo(extRight, extBottom - sashWidth * 0.8);
        ctx.lineTo(extRight, extBottom);
        ctx.lineTo(extRight - sashWidth, extBottom);
        ctx.lineTo(extLeft, extTop + sashWidth * 0.8);
        ctx.closePath();
        ctx.fill();
        break;
        
      case 'vert-sash':
        ctx.fillStyle = secondColor;
        const vSashWidth = extWidth * 0.25;
        const vSashX = extLeft + (extWidth - vSashWidth) / 2;
        ctx.fillRect(vSashX, extTop, vSashWidth, extHeight);
        break;
        
      case 'horiz-sash':
        ctx.fillStyle = secondColor;
        const hSashHeight = extHeight * 0.25;
        const hSashY = extTop + (extHeight - hSashHeight) / 2;
        ctx.fillRect(extLeft, hSashY, extWidth, hSashHeight);
        break;
        
      case 'checkered':
        const squareSize = Math.min(extWidth, extHeight) / 4;
        ctx.fillStyle = secondColor;
        for (let row = 0; row < Math.ceil(extHeight / squareSize); row++) {
          for (let col = 0; col < Math.ceil(extWidth / squareSize); col++) {
            if ((row + col) % 2 === 1) {
              ctx.fillRect(extLeft + col * squareSize, extTop + row * squareSize, squareSize, squareSize);
            }
          }
        }
        break;
    }
    
    ctx.restore();
    
    // Draw outline
    createTshirtPath();
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    
    // Draw number
    const hex = primaryColor.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    const textColor = brightness > 128 ? '#000000' : '#FFFFFF';
    
    ctx.fillStyle = textColor;
    ctx.font = `bold ${shirtHeight * 0.4}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(number, centerX, centerY + shirtHeight * 0.1);
    
    ctx.restore();
  }

  // Update t-shirt previews
  function updateTshirtPreviews() {
    const homeColorInput = document.getElementById('teamHomeColorInput');
    const awayColorInput = document.getElementById('teamAwayColorInput');
    const homeDesignSelect = document.getElementById('teamHomeDesignSelect');
    const awayDesignSelect = document.getElementById('teamAwayDesignSelect');
    const homeSecondColorInput = document.getElementById('teamHomeSecondColorInput');
    const awaySecondColorInput = document.getElementById('teamAwaySecondColorInput');
    const homePreview = document.getElementById('teamHomeTshirtPreview');
    const awayPreview = document.getElementById('teamAwayTshirtPreview');
    
    const homeDesign = homeDesignSelect ? homeDesignSelect.value : 'solid';
    const awayDesign = awayDesignSelect ? awayDesignSelect.value : 'solid';
    const homeSecondColor = homeSecondColorInput ? homeSecondColorInput.value : '#000000';
    const awaySecondColor = awaySecondColorInput ? awaySecondColorInput.value : '#FFFFFF';
    
    if (homeColorInput && homePreview) {
      drawTshirtPreview(homePreview, homeColorInput.value, '10', homeDesign, homeSecondColor);
    }
    if (awayColorInput && awayPreview) {
      drawTshirtPreview(awayPreview, awayColorInput.value, '10', awayDesign, awaySecondColor);
    }
  }

  // Load and populate formation selector
  function loadFormationSelector() {
    const formationSelect = document.getElementById('teamFormationSelect');
    if (!formationSelect) return;

    // Clear all options and optgroups, keeping only the first option
    const firstOption = formationSelect.options[0];
    formationSelect.innerHTML = '';
    if (firstOption) {
      formationSelect.appendChild(firstOption);
    }

    // Built-in formations (same as in editor.js)
    const builtInFormations = [
      { value: '4-3-3', name: '4-3-3', group: 'Back-four systems' },
      { value: '4-2-3-1', name: '4-2-3-1', group: 'Back-four systems' },
      { value: '4-4-2', name: '4-4-2 (Flat)', group: 'Back-four systems' },
      { value: '4-1-2-1-2', name: '4-1-2-1-2', group: 'Back-four systems' },
      { value: '4-1-4-1', name: '4-1-4-1', group: 'Back-four systems' },
      { value: '4-5-1', name: '4-5-1', group: 'Back-four systems' },
      { value: '4-3-2-1', name: '4-3-2-1', group: 'Back-four systems' },
      { value: '4-1-2-3', name: '4-1-2-3', group: 'Back-four systems' },
      { value: '3-5-2', name: '3-5-2', group: 'Back-three systems' },
      { value: '3-4-3', name: '3-4-3', group: 'Back-three systems' },
      { value: '3-4-1-2', name: '3-4-1-2', group: 'Back-three systems' },
      { value: '3-3-3-1', name: '3-3-3-1', group: 'Back-three systems' },
      { value: '3-2-4-1', name: '3-2-4-1', group: 'Back-three systems' },
      { value: '5-3-2', name: '5-3-2', group: 'Back-five systems' },
      { value: '5-4-1', name: '5-4-1', group: 'Back-five systems' },
      { value: '5-2-3', name: '5-2-3', group: 'Back-five systems' },
      { value: '4-3-1-2', name: '4-3-1-2', group: 'Less common' },
      { value: '4-2-1-3', name: '4-2-1-3', group: 'Less common' },
      { value: '4-6-0', name: '4-6-0 (False 9)', group: 'Less common' },
      { value: '3-6-1', name: '3-6-1', group: 'Less common' }
    ];

    // Group formations by category
    const groups = {};
    builtInFormations.forEach(f => {
      if (!groups[f.group]) {
        groups[f.group] = [];
      }
      groups[f.group].push(f);
    });

    // Add built-in formations
    Object.keys(groups).forEach(groupName => {
      const optgroup = document.createElement('optgroup');
      optgroup.label = groupName;
      groups[groupName].forEach(f => {
        const option = document.createElement('option');
        option.value = f.value;
        option.textContent = f.name;
        optgroup.appendChild(option);
      });
      formationSelect.appendChild(optgroup);
    });

    // Load custom formations from storage
    chrome.storage.local.get(['customFormations'], (result) => {
      const customFormations = result.customFormations || {};
      const customKeys = Object.keys(customFormations);
      
      if (customKeys.length > 0) {
        const customGroup = document.createElement('optgroup');
        customGroup.label = 'Custom Formations';
        customKeys.sort().forEach(key => {
          const formation = customFormations[key];
          const option = document.createElement('option');
          option.value = key;
          option.textContent = formation.name || key;
          customGroup.appendChild(option);
        });
        formationSelect.appendChild(customGroup);
      }
    });
  }

  function openTeamModal(teamName = null) {
    const teamModal = document.getElementById('teamModal');
    const teamModalTitle = document.getElementById('teamModalTitle');
    const teamNameInput = document.getElementById('teamNameInput');
    const teamHomeColorInput = document.getElementById('teamHomeColorInput');
    const teamAwayColorInput = document.getElementById('teamAwayColorInput');
    const teamFormationSelect = document.getElementById('teamFormationSelect');
    const teamPlayersSection = document.getElementById('teamPlayersSection');
    const teamPlayersList = document.getElementById('teamPlayersList');
    const teamHomeDesignSelect = document.getElementById('teamHomeDesignSelect');
    const teamAwayDesignSelect = document.getElementById('teamAwayDesignSelect');
    const teamHomeSecondColorInput = document.getElementById('teamHomeSecondColorInput');
    const teamAwaySecondColorInput = document.getElementById('teamAwaySecondColorInput');
    
    if (!teamModal || !teamNameInput || !teamHomeColorInput || !teamAwayColorInput) {
      console.error('Team modal elements not found');
      return;
    }

    // Load formations into selector
    loadFormationSelector();

    currentEditingTeamName = teamName;
    
    // Reset squad assignments
    currentSquadAssignments = {};
    
    if (teamName) {
      // Editing existing team
      teamModalTitle.textContent = 'Edit Team';
      teamNameInput.value = teamName;
      
      // Load team colors and squad from both analysis and global storage
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        const analyses = result.analyses || [];
        const globalTeams = result.teams || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        
        let teamData = null;
        
        // First try to find team in analysis.teams
        if (analysis && analysis.teams) {
          const teamObj = getTeamObject(teamName, analysis.teams);
          if (teamObj) {
            teamData = ensureTeamObject(teamObj);
          }
        }
        
        // If not found in analysis, try global teams storage
        if (!teamData) {
          const globalTeamObj = globalTeams.find(t => {
            const tName = typeof t === 'string' ? t : (t.name || '');
            return tName === teamName;
          });
          if (globalTeamObj) {
            teamData = typeof globalTeamObj === 'string' ? { name: globalTeamObj } : ensureTeamObject(globalTeamObj);
          }
        }
        
        if (teamData) {
            teamHomeColorInput.value = teamData.homeColor || '#FFFFFF';
            teamAwayColorInput.value = teamData.awayColor || '#000000';
            if (teamHomeDesignSelect) teamHomeDesignSelect.value = teamData.homeDesign || 'solid';
            if (teamAwayDesignSelect) teamAwayDesignSelect.value = teamData.awayDesign || 'solid';
            if (teamHomeSecondColorInput) teamHomeSecondColorInput.value = teamData.homeSecondColor || '#000000';
            if (teamAwaySecondColorInput) teamAwaySecondColorInput.value = teamData.awaySecondColor || '#FFFFFF';
            if (teamFormationSelect && teamData.formation) {
              teamFormationSelect.value = teamData.formation;
            }
            // Load squad assignments
            if (teamData.squad) {
              currentSquadAssignments = { ...teamData.squad };
            }
            // Render squad formation
            setTimeout(() => {
              renderSquadFormation(teamData.formation || '', teamName, currentSquadAssignments);
            }, 50);
          } else {
            teamHomeColorInput.value = '#FFFFFF';
            teamAwayColorInput.value = '#000000';
            if (teamFormationSelect) {
              teamFormationSelect.value = '';
            }
            renderSquadFormation('', teamName, {});
        }
        updateTshirtPreviews();
      });
      
      // Show and populate players section
      if (teamPlayersSection && teamPlayersList) {
        teamPlayersSection.style.display = 'block';
        teamPlayersList.innerHTML = '';
        
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const teamPlayers = players.filter(p => p.team === teamName);
          
          if (teamPlayers.length > 0) {
            // Sort players by number
            teamPlayers.sort((a, b) => {
              const numA = parseInt(a.number) || 0;
              const numB = parseInt(b.number) || 0;
              return numA - numB;
            });
            
            teamPlayers.forEach(player => {
              const playerItem = document.createElement('div');
              playerItem.style.display = 'flex';
              playerItem.style.alignItems = 'center';
              playerItem.style.padding = '8px 12px';
              playerItem.style.marginBottom = '6px';
              playerItem.style.background = '#0d1117';
              playerItem.style.borderRadius = '4px';
              playerItem.style.border = '1px solid #21262d';
              
              const playerText = document.createElement('span');
              playerText.style.flex = '1';
              playerText.style.fontSize = '13px';
              playerText.style.color = '#c9d1d9';
              const displayText = player.number ? 
                `#${player.number} ${player.fullName || ''}`.trim() : 
                (player.fullName || 'Unnamed');
              playerText.textContent = displayText;
              playerItem.appendChild(playerText);
              
              const editBtn = document.createElement('button');
              editBtn.textContent = '✎';
              editBtn.style.background = 'transparent';
              editBtn.style.border = 'none';
              editBtn.style.color = '#8b949e';
              editBtn.style.cursor = 'pointer';
              editBtn.style.padding = '4px 8px';
              editBtn.style.marginLeft = '8px';
              editBtn.style.fontSize = '12px';
              editBtn.title = 'Edit player';
              editBtn.addEventListener('click', () => {
                closeTeamModal();
                editPlayer(player.id);
              });
              playerItem.appendChild(editBtn);
              
              const removeFromTeamBtn = document.createElement('button');
              removeFromTeamBtn.textContent = '×';
              removeFromTeamBtn.style.background = 'transparent';
              removeFromTeamBtn.style.border = 'none';
              removeFromTeamBtn.style.color = '#8b949e';
              removeFromTeamBtn.style.cursor = 'pointer';
              removeFromTeamBtn.style.padding = '4px 8px';
              removeFromTeamBtn.style.marginLeft = '4px';
              removeFromTeamBtn.style.fontSize = '16px';
              removeFromTeamBtn.title = 'Remove from team';
              removeFromTeamBtn.addEventListener('click', () => {
                removePlayerFromTeam(player.id);
                // Refresh the team modal
                setTimeout(() => {
                  openTeamModal(teamName);
                }, 100);
              });
              playerItem.appendChild(removeFromTeamBtn);
              
              teamPlayersList.appendChild(playerItem);
            });
          } else {
            const noPlayersMsg = document.createElement('div');
            noPlayersMsg.style.padding = '8px';
            noPlayersMsg.style.fontSize = '12px';
            noPlayersMsg.style.color = '#8b949e';
            noPlayersMsg.style.fontStyle = 'italic';
            noPlayersMsg.textContent = 'No players attached to this team';
            teamPlayersList.appendChild(noPlayersMsg);
          }
        });
      }
    } else {
      // Creating new team
      teamModalTitle.textContent = 'Add Team';
      teamNameInput.value = '';
      if (teamFormationSelect) {
        teamFormationSelect.value = '';
      }
      // Reset design options for new team
      if (teamHomeDesignSelect) teamHomeDesignSelect.value = 'solid';
      if (teamAwayDesignSelect) teamAwayDesignSelect.value = 'solid';
      if (teamHomeSecondColorInput) teamHomeSecondColorInput.value = '#000000';
      if (teamAwaySecondColorInput) teamAwaySecondColorInput.value = '#FFFFFF';
      teamHomeColorInput.value = '#FFFFFF';
      teamAwayColorInput.value = '#000000';
      
      // Hide players section and squad section for new teams
      if (teamPlayersSection) {
        teamPlayersSection.style.display = 'none';
      }
      const squadSection = document.getElementById('teamSquadSection');
      if (squadSection) {
        squadSection.style.display = 'none';
      }
    }
    
    // Update previews
    updateTshirtPreviews();
    
    // Set up color input listeners using direct property assignment (replaces any previous handler)
    const homeColorInput = document.getElementById('teamHomeColorInput');
    const awayColorInput = document.getElementById('teamAwayColorInput');
    const homeDesignSelect = document.getElementById('teamHomeDesignSelect');
    const awayDesignSelect = document.getElementById('teamAwayDesignSelect');
    const homeSecondColorInput = document.getElementById('teamHomeSecondColorInput');
    const awaySecondColorInput = document.getElementById('teamAwaySecondColorInput');
    
    if (homeColorInput) {
      homeColorInput.oninput = updateTshirtPreviews;
      homeColorInput.onchange = updateTshirtPreviews;
    }
    if (awayColorInput) {
      awayColorInput.oninput = updateTshirtPreviews;
      awayColorInput.onchange = updateTshirtPreviews;
    }
    if (homeDesignSelect) {
      homeDesignSelect.onchange = updateTshirtPreviews;
    }
    if (awayDesignSelect) {
      awayDesignSelect.onchange = updateTshirtPreviews;
    }
    if (homeSecondColorInput) {
      homeSecondColorInput.oninput = updateTshirtPreviews;
      homeSecondColorInput.onchange = updateTshirtPreviews;
    }
    if (awaySecondColorInput) {
      awaySecondColorInput.oninput = updateTshirtPreviews;
      awaySecondColorInput.onchange = updateTshirtPreviews;
    }
    
    // Set up container click handlers using direct property assignment
    const homeContainer = document.getElementById('teamHomeTshirtContainer');
    const awayContainer = document.getElementById('teamAwayTshirtContainer');
    
    if (homeContainer) {
      homeContainer.onclick = function() {
        const input = document.getElementById('teamHomeColorInput');
        if (input) input.click();
      };
      homeContainer.onmouseenter = function() {
        this.style.borderColor = '#30363d';
        this.style.background = '#161b22';
      };
      homeContainer.onmouseleave = function() {
        this.style.borderColor = '#21262d';
        this.style.background = '#0d1117';
      };
    }
    if (awayContainer) {
      awayContainer.onclick = function() {
        const input = document.getElementById('teamAwayColorInput');
        if (input) input.click();
      };
      awayContainer.onmouseenter = function() {
        this.style.borderColor = '#30363d';
        this.style.background = '#161b22';
      };
      awayContainer.onmouseleave = function() {
        this.style.borderColor = '#21262d';
        this.style.background = '#0d1117';
      };
    }
    
    // Update previews after setting up listeners
    setTimeout(() => {
      updateTshirtPreviews();
    }, 50);
    
    teamModal.classList.remove('hidden');
    teamNameInput.focus();
  }

  function closeTeamModal() {
    const teamModal = document.getElementById('teamModal');
    if (teamModal) {
      teamModal.classList.add('hidden');
      currentEditingTeamName = null;
    }
  }

  function saveTeamFromModal() {
    const teamNameInput = document.getElementById('teamNameInput');
    
    if (!teamNameInput) {
      return;
    }

    const teamName = teamNameInput.value.trim();
    
    if (!teamName) {
      showErrorModal('Please enter a team name.');
      return;
    }
    
    // Get current values from inputs
    const homeColorInput = document.getElementById('teamHomeColorInput');
    const awayColorInput = document.getElementById('teamAwayColorInput');
    const formationSelect = document.getElementById('teamFormationSelect');
    const homeDesignSelect = document.getElementById('teamHomeDesignSelect');
    const awayDesignSelect = document.getElementById('teamAwayDesignSelect');
    const homeSecondColorInput = document.getElementById('teamHomeSecondColorInput');
    const awaySecondColorInput = document.getElementById('teamAwaySecondColorInput');
    
    const homeColor = homeColorInput ? homeColorInput.value : '#FFFFFF';
    const awayColor = awayColorInput ? awayColorInput.value : '#000000';
    const formation = formationSelect ? formationSelect.value : '';
    const homeDesign = homeDesignSelect ? homeDesignSelect.value : 'solid';
    const awayDesign = awayDesignSelect ? awayDesignSelect.value : 'solid';
    const homeSecondColor = homeSecondColorInput ? homeSecondColorInput.value : '#000000';
    const awaySecondColor = awaySecondColorInput ? awaySecondColorInput.value : '#FFFFFF';
    
    console.log('Saving team:', { teamName, homeColor, awayColor, formation, homeDesign, awayDesign });
    
    if (currentEditingTeamName) {
      // Renaming existing team
      if (teamName === currentEditingTeamName) {
        // Just update colors and formation without renaming
        renameTeam(currentEditingTeamName, teamName, homeColor, awayColor, formation, homeDesign, awayDesign, homeSecondColor, awaySecondColor);
        return;
      }
      
      renameTeam(currentEditingTeamName, teamName, homeColor, awayColor, formation, homeDesign, awayDesign, homeSecondColor, awaySecondColor);
    } else {
      // Creating new team
      createTeam(teamName, homeColor, awayColor, formation, homeDesign, awayDesign, homeSecondColor, awaySecondColor);
    }
  }

  function renameTeam(oldTeamName, newTeamName, homeColor = '#FFFFFF', awayColor = '#000000', formation = '', homeDesign = 'solid', awayDesign = 'solid', homeSecondColor = '#000000', awaySecondColor = '#FFFFFF') {
    if (!currentAnalysisId) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'players', 'teams'], (result) => {
        const analyses = result.analyses || [];
        const players = result.players || [];
        const globalTeams = result.teams || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          
          if (!analysis.teams) {
            analysis.teams = [];
          }

          // Check if new name already exists (only if actually renaming, not just updating)
          if (oldTeamName !== newTeamName) {
            const teamExistsInAnalysis = analysis.teams.some(t => getTeamName(t) === newTeamName);
            const teamExistsInGlobal = globalTeams.some(t => {
              const teamName = typeof t === 'string' ? t : (t.name || '');
              return teamName === newTeamName;
            });
            if (teamExistsInAnalysis || teamExistsInGlobal) {
              showErrorModal('This team name already exists.');
              return;
            }
          }

          // Update team in analysis.teams array
          const teamIndex = analysis.teams.findIndex(t => getTeamName(t) === oldTeamName);
          if (teamIndex !== -1) {
            const oldTeam = analysis.teams[teamIndex];
            const oldTeamObj = ensureTeamObject(oldTeam);
            const teamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              homeDesign: homeDesign,
              awayDesign: awayDesign,
              homeSecondColor: homeSecondColor,
              awaySecondColor: awaySecondColor
            };
            if (formation) {
              teamData.formation = formation;
            }
            // Save squad assignments
            if (currentSquadAssignments && Object.keys(currentSquadAssignments).length > 0) {
              teamData.squad = { ...currentSquadAssignments };
            } else if (oldTeamObj.squad) {
              // Keep existing squad if not modified
              teamData.squad = oldTeamObj.squad;
            }
            analysis.teams[teamIndex] = teamData;
          }

          // Update team in global teams storage
          const globalTeamIndex = globalTeams.findIndex(t => {
            const teamName = typeof t === 'string' ? t : (t.name || '');
            return teamName === oldTeamName;
          });
          if (globalTeamIndex !== -1) {
            const oldGlobalTeam = globalTeams[globalTeamIndex];
            const oldGlobalTeamObj = typeof oldGlobalTeam === 'string' ? { name: oldGlobalTeam } : oldGlobalTeam;
            const globalTeamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              homeDesign: homeDesign,
              awayDesign: awayDesign,
              homeSecondColor: homeSecondColor,
              awaySecondColor: awaySecondColor
            };
            if (formation) {
              globalTeamData.formation = formation;
            }
            // Preserve squad if it exists
            if (oldGlobalTeamObj.squad) {
              globalTeamData.squad = oldGlobalTeamObj.squad;
            }
            globalTeams[globalTeamIndex] = globalTeamData;
          } else if (oldTeamName === newTeamName) {
            // If team doesn't exist in global storage but we're just updating colors, add it
            const teamData = {
              name: newTeamName,
              homeColor: homeColor,
              awayColor: awayColor,
              homeDesign: homeDesign,
              awayDesign: awayDesign,
              homeSecondColor: homeSecondColor,
              awaySecondColor: awaySecondColor
            };
            if (formation) {
              teamData.formation = formation;
            }
            globalTeams.push(teamData);
          }

          // Update selectedTeam if it was the renamed team
          if (analysis.selectedTeam === oldTeamName) {
            analysis.selectedTeam = newTeamName;
          }
          // Update userTeam if it was the renamed team
          if (analysis.userTeam === oldTeamName) {
            analysis.userTeam = newTeamName;
          }

          // Update all notes that reference this team across all analyses
          analyses.forEach(a => {
            if (a.notes) {
              a.notes.forEach(note => {
              if (note.team === oldTeamName) {
                note.team = newTeamName;
              }
            });
          }
          });

          analyses[analysisIndex] = analysis;

          // Update all players that belong to this team
          players.forEach(player => {
            if (player.team === oldTeamName) {
              player.team = newTeamName;
            }
          });

          chrome.storage.local.set({ analyses: analyses, players: players, teams: globalTeams }, () => {
            console.log('Team updated:', { oldTeamName, newTeamName, homeColor, awayColor, formation });
            closeTeamModal();
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            updateSelectedTeamDisplay();
            renderPlayerSelector(playerSearchInput ? playerSearchInput.value : '');
            refreshMessages(); // Refresh messages to show updated data
          });
        }
      });
    } catch (e) {
      console.error('Error renaming team:', e);
    }
  }

  function createTeam(teamName, homeColor = '#FFFFFF', awayColor = '#000000', formation = '', homeDesign = 'solid', awayDesign = 'solid', homeSecondColor = '#000000', awaySecondColor = '#FFFFFF') {
    if (!currentAnalysisId) {
      showErrorModal('Please select or create a project first.');
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        const analyses = result.analyses || [];
        const globalTeams = result.teams || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          
          // Check if team already exists in global storage
          const teamNameLower = teamName.toLowerCase().trim();
          const existsInGlobal = globalTeams.some(t => {
            const existingName = typeof t === 'string' ? t : (t.name || '');
            return existingName.toLowerCase() === teamNameLower;
          });
          
          if (existsInGlobal) {
            showErrorModal('This team already exists.');
            return;
          }

          // Add new team to global storage
          const teamData = {
            id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: teamName.trim(),
            homeColor: homeColor,
            awayColor: awayColor,
            homeDesign: homeDesign,
            awayDesign: awayDesign,
            homeSecondColor: homeSecondColor,
            awaySecondColor: awaySecondColor,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          if (formation) {
            teamData.formation = formation;
          }
          
          globalTeams.push(teamData);

          // Add team ID to project's attached teams
          if (!analysis.attachedTeamIds) {
            analysis.attachedTeamIds = [];
          }
          if (!analysis.attachedTeamIds.includes(teamData.id)) {
            analysis.attachedTeamIds.push(teamData.id);
          }

          // Set as selected team
          analysis.selectedTeam = teamName;
          analyses[analysisIndex] = analysis;

          chrome.storage.local.set({ analyses: analyses, teams: globalTeams }, () => {
            console.log('New team created in global storage:', teamName);
            selectedTeam = teamName;
            saveSelectedTeam(teamName);
            closeTeamModal();
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            updateSelectedTeamDisplay();
            refreshMessages(); // Refresh messages to show updated data
            if (reopenManageTeamsAfterTeamCreate) {
              reopenManageTeamsAfterTeamCreate = false;
              openManageTeamsModal();
            }
          });
        }
      });
    } catch (e) {
      console.error('Error creating team:', e);
    }
  }

  // Rename selected team
  function renameSelectedTeam(teamName = null) {
    if (!teamName) {
      showErrorModal('Please select a team to rename.');
      return;
    }
    openTeamModal(teamName);
  }

  // Delete selected team
  function deleteSelectedTeam(teamName = null) {
    const teamToDelete = teamName || (() => {
    const teamSelect = document.getElementById('teamSelect');
    if (!teamSelect || !teamSelect.value || teamSelect.value === '') {
      alert('Please select a team to delete.');
        return null;
    }
      return teamSelect.value;
    })();

    if (!teamToDelete) return;
    
    if (!confirm(`Are you sure you want to delete the team "${teamToDelete}"? This will remove the team from all notes.`)) {
      return;
    }

    if (!currentAnalysisId) {
      return;
    }

    try {
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
        const analyses = result.analyses || [];
        const globalTeams = result.teams || [];
        const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

        if (analysisIndex !== -1) {
          const analysis = analyses[analysisIndex];
          
          // Remove team from global teams storage
          const updatedGlobalTeams = globalTeams.filter(t => {
            const existingName = typeof t === 'string' ? t : (t.name || '');
            return existingName !== teamToDelete;
          });

          // Remove team from analysis.teams (for backward compatibility)
          if (analysis.teams) {
          analysis.teams = analysis.teams.filter(t => getTeamName(t) !== teamToDelete);
          }

          // Clear selectedTeam if it was the deleted team
          if (analysis.selectedTeam === teamToDelete) {
            analysis.selectedTeam = null;
          }
          // Clear userTeam if it was the deleted team
          if (analysis.userTeam === teamToDelete) {
            analysis.userTeam = null;
          }

          // Remove team from all notes in all analyses
          analyses.forEach(a => {
            if (a.notes) {
              a.notes.forEach(note => {
              if (note.team === teamToDelete) {
                note.team = null;
              }
                if (note.teams && Array.isArray(note.teams)) {
                  note.teams = note.teams.filter(t => t !== teamToDelete);
                }
            });
          }
          });

          analyses[analysisIndex] = analysis;

          chrome.storage.local.set({ analyses: analyses, teams: updatedGlobalTeams }, () => {
            console.log('Team deleted from global storage:', teamToDelete);
            // Clear selection if deleted team was selected
            if (selectedTeam === teamToDelete) {
              selectedTeam = null;
              saveSelectedTeam(null);
            }
            renderTeamSelector(teamSearchInput ? teamSearchInput.value : '');
            updateSelectedTeamDisplay();
          });
        }
      });
    } catch (e) {
      console.error('Error deleting team:', e);
    }
  }

  // Create new team
  function createNewTeam() {
    openTeamModal();
  }

  // Team modal event listeners
  const teamModal = document.getElementById('teamModal');
  const closeTeamModalBtn = document.getElementById('closeTeamModal');
  const cancelTeamBtn = document.getElementById('cancelTeamBtn');
  const saveTeamBtn = document.getElementById('saveTeamBtn');
  const teamNameInput = document.getElementById('teamNameInput');
  
  if (closeTeamModalBtn) {
    closeTeamModalBtn.addEventListener('click', closeTeamModal);
  }
  
  if (cancelTeamBtn) {
    cancelTeamBtn.addEventListener('click', closeTeamModal);
  }
  
  if (saveTeamBtn) {
    saveTeamBtn.addEventListener('click', saveTeamFromModal);
  }
  
  if (teamModal) {
    teamModal.addEventListener('click', (e) => {
      if (e.target === teamModal) {
        closeTeamModal();
      }
    });
    
    if (teamNameInput) {
      teamNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          saveTeamFromModal();
        }
      });
    }
  }

  // Manage Teams Modal Functions
  function openManageTeamsModal() {
    if (!currentAnalysisId) return;

    const manageTeamsModal = document.getElementById('manageTeamsModal');
    const availableTeamsList = document.getElementById('availableTeamsList');
    const attachedTeamsList = document.getElementById('attachedTeamsList');

    if (!manageTeamsModal || !availableTeamsList || !attachedTeamsList) return;

    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      const globalTeams = result.teams || [];
      const attachedTeamIds = analysis ? (analysis.attachedTeamIds || []) : [];

      // Clear lists
      availableTeamsList.innerHTML = '';
      attachedTeamsList.innerHTML = '';

      // Collect ALL teams from global storage and all projects (for backward compatibility)
      const allTeamsMap = new Map();

      // First add global teams
      globalTeams.forEach(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        if (teamId) allTeamsMap.set(teamId, team);
      });

      // Then add teams from all projects (for backward compatibility with old system)
      analyses.forEach(project => {
        const projectTeams = project.teams || [];
        projectTeams.forEach(team => {
          const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
          if (teamId) allTeamsMap.set(teamId, team);
        });
      });

      const allTeams = Array.from(allTeamsMap.values());

      // Separate teams into available and attached
      const availableTeams = allTeams.filter(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        return !attachedTeamIds.includes(teamId);
      });

      const attachedTeams = allTeams.filter(team => {
        const teamId = typeof team === 'string' ? team : (team.id || team.name || '');
        return attachedTeamIds.includes(teamId);
      });

      // Populate available teams
      if (availableTeams.length === 0) {
        availableTeamsList.innerHTML = '<div style="color: #8b949e; font-style: italic; text-align: center; padding: 20px;">No available teams</div>';
      } else {
        availableTeams.forEach(team => {
          const teamName = getTeamName(team);
          const teamId = typeof team === 'string' ? team : (team.id || team.name || '');

          const teamItem = document.createElement('div');
          teamItem.style.display = 'flex';
          teamItem.style.alignItems = 'center';
          teamItem.style.justifyContent = 'space-between';
          teamItem.style.padding = '8px 12px';
          teamItem.style.marginBottom = '4px';
          teamItem.style.background = '#21262d';
          teamItem.style.borderRadius = '4px';
          teamItem.style.cursor = 'pointer';

          const teamNameSpan = document.createElement('span');
          teamNameSpan.style.color = '#c9d1d9';
          teamNameSpan.style.fontSize = '13px';
          teamNameSpan.textContent = teamName;

          const attachButton = document.createElement('button');
          attachButton.className = 'modal-btn-primary';
          attachButton.setAttribute('data-team-id', teamId);
          attachButton.style.padding = '4px 10px';
          attachButton.style.fontSize = '11px';
          attachButton.textContent = 'Attach';
          attachButton.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log('Attach button clicked for team:', teamId);
            attachTeamToProject(teamId);
          });

          teamItem.appendChild(teamNameSpan);
          teamItem.appendChild(attachButton);
          availableTeamsList.appendChild(teamItem);
        });
      }

      // Populate attached teams
      if (attachedTeams.length === 0) {
        attachedTeamsList.innerHTML = '<div style="color: #8b949e; font-style: italic; text-align: center; padding: 20px;">No teams attached</div>';
      } else {
        attachedTeams.forEach(team => {
          const teamName = getTeamName(team);
          const teamId = typeof team === 'string' ? team : (team.id || team.name || '');

          const teamItem = document.createElement('div');
          teamItem.style.display = 'flex';
          teamItem.style.alignItems = 'center';
          teamItem.style.justifyContent = 'space-between';
          teamItem.style.padding = '8px 12px';
          teamItem.style.marginBottom = '4px';
          teamItem.style.background = '#21262d';
          teamItem.style.borderRadius = '4px';

          const teamNameSpan = document.createElement('span');
          teamNameSpan.style.color = '#c9d1d9';
          teamNameSpan.style.fontSize = '13px';
          teamNameSpan.textContent = teamName;

          const detachButton = document.createElement('button');
          detachButton.className = 'modal-btn-secondary';
          detachButton.setAttribute('data-team-id', teamId);
          detachButton.style.padding = '4px 10px';
          detachButton.style.fontSize = '11px';
          detachButton.textContent = 'Detach';
          detachButton.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log('Detach button clicked for team:', teamId);
            detachTeamFromProject(teamId);
          });

          teamItem.appendChild(teamNameSpan);
          teamItem.appendChild(detachButton);
          attachedTeamsList.appendChild(teamItem);
        });
      }

      // Show modal
      manageTeamsModal.classList.remove('hidden');
    });
  }

  function closeManageTeamsModal() {
    const manageTeamsModal = document.getElementById('manageTeamsModal');
    if (manageTeamsModal) {
      manageTeamsModal.classList.add('hidden');
    }
  }

  function attachTeamToProject(teamId) {
    if (!currentAnalysisId || !teamId) return;

    chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const globalTeams = result.teams || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];

        // Ensure the team exists in global storage
        let teamExistsInGlobal = false;
        for (const team of globalTeams) {
          const existingTeamId = typeof team === 'string' ? team : (team.id || team.name || '');
          if (existingTeamId === teamId) {
            teamExistsInGlobal = true;
            break;
          }
        }

        // If team doesn't exist in global storage, find it from project teams and add it
        if (!teamExistsInGlobal) {
          // Look for the team in all project teams arrays
          let teamToAdd = null;
          for (const project of analyses) {
            const projectTeams = project.teams || [];
            for (const team of projectTeams) {
              const teamIdCheck = typeof team === 'string' ? team : (team.id || team.name || '');
              if (teamIdCheck === teamId) {
                teamToAdd = team;
                break;
              }
            }
            if (teamToAdd) break;
          }

          if (teamToAdd) {
            // Ensure the team has an ID
            if (typeof teamToAdd === 'string') {
              teamToAdd = { id: teamId, name: teamId };
            } else if (!teamToAdd.id) {
              teamToAdd.id = teamId;
            }
            globalTeams.push(teamToAdd);
          }
        }

        // Add team to project's attached teams
        if (!analysis.attachedTeamIds) {
          analysis.attachedTeamIds = [];
        }

        if (!analysis.attachedTeamIds.includes(teamId)) {
          analysis.attachedTeamIds.push(teamId);
          chrome.storage.local.set({ analyses: analyses, teams: globalTeams }, () => {
            console.log('Team attached to project:', teamId);
            openManageTeamsModal(); // Refresh the modal
            renderTeamSelector(''); // Refresh team selector
          });
        }
      }
    });
  }

  function detachTeamFromProject(teamId) {
    if (!currentAnalysisId || !teamId) return;

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        if (analysis.attachedTeamIds) {
          analysis.attachedTeamIds = analysis.attachedTeamIds.filter(id => id !== teamId);
          chrome.storage.local.set({ analyses: analyses }, () => {
            console.log('Team detached from project:', teamId);
            openManageTeamsModal(); // Refresh the modal
            renderTeamSelector(''); // Refresh team selector
          });
        }
      }
    });
  }

  // Manage Teams Modal Event Listeners
  const manageTeamsModal = document.getElementById('manageTeamsModal');
  const closeManageTeamsModalBtn = document.getElementById('closeManageTeamsModal');
  const createNewTeamFromManageTeamsBtn = document.getElementById('createNewTeamFromManageTeamsBtn');

  if (closeManageTeamsModalBtn) {
    closeManageTeamsModalBtn.addEventListener('click', closeManageTeamsModal);
  }

  if (createNewTeamFromManageTeamsBtn) {
    createNewTeamFromManageTeamsBtn.addEventListener('click', () => {
      reopenManageTeamsAfterTeamCreate = true;
      closeManageTeamsModal();
      openTeamModal();
    });
  }

  if (manageTeamsModal) {
    manageTeamsModal.addEventListener('click', (e) => {
      if (e.target === manageTeamsModal) {
        closeManageTeamsModal();
      }
    });

  }

  // Error modal function
  function showErrorModal(message) {
    // Create a simple error modal if it doesn't exist
    let errorModal = document.getElementById('errorModal');
    if (!errorModal) {
      errorModal = document.createElement('div');
      errorModal.id = 'errorModal';
      errorModal.className = 'project-modal hidden';
      errorModal.innerHTML = `
        <div class="project-modal-content">
          <div class="project-modal-header">
            <h3>Error</h3>
            <button id="closeErrorModal" class="close-modal-btn">×</button>
          </div>
          <div class="project-modal-body">
            <p id="errorModalMessage" style="color: #c9d1d9; margin-bottom: 20px;"></p>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button id="okErrorBtn" class="create-new-project-btn">OK</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(errorModal);
      
      const closeErrorModalBtn = document.getElementById('closeErrorModal');
      const okErrorBtn = document.getElementById('okErrorBtn');
      
      if (closeErrorModalBtn) {
        closeErrorModalBtn.addEventListener('click', () => {
          errorModal.classList.add('hidden');
        });
      }
      
      if (okErrorBtn) {
        okErrorBtn.addEventListener('click', () => {
          errorModal.classList.add('hidden');
        });
      }
      
      errorModal.addEventListener('click', (e) => {
        if (e.target === errorModal) {
          errorModal.classList.add('hidden');
        }
      });
    }
    
    const errorMessage = document.getElementById('errorModalMessage');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
    errorModal.classList.remove('hidden');
  }

  // Refresh messages display for current analysis
  function refreshMessages() {
    if (!currentAnalysisId) return;
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (analysis) {
        // Clear and reload messages
        chatMessages.innerHTML = '';
        
        // Sort notes by timestamp (oldest first) to ensure consistent order
        const sortedNotes = [...(analysis.notes || [])].sort((a, b) => {
          const timeA = a.timestamp || 0;
          const timeB = b.timestamp || 0;
          return timeA - timeB;
        });
        
        // Get videos from the project to match notes to videos
        let videos = [];
        if (analysis.videos && analysis.videos.length > 0) {
          videos = analysis.videos;
        } else if (analysis.videoUrl) {
          // Migrate legacy structure
          videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
        }
        
        sortedNotes.forEach(note => {
          // Handle both 'text' (popup notes) and 'content' (sidebar notes) fields
          // If both exist and are the same, use only one to avoid duplication
          let noteText = '';
          if (note.text && note.content) {
            // Both exist - use text if they're different, otherwise use text (avoid duplication)
            noteText = note.text.trim();
            // If content is different and longer, it might be the updated version
            if (note.content.trim() !== note.text.trim() && note.content.trim().length > note.text.trim().length) {
              noteText = note.content.trim();
            }
          } else {
            noteText = (note.text || note.content || '').trim();
          }
          // Check if note has images
          const noteImages = note.images || (note.image ? [note.image] : null);
          const hasImages = noteImages && (Array.isArray(noteImages) ? noteImages.length > 0 : true);
          
          // Display note if it has text OR images
          if (noteText || hasImages) {
            // Find which video this note belongs to
            let noteVideo = null;
            
            // Strategy 1: Match by videoId and platform (most reliable)
            if (note.videoId && note.platform) {
              noteVideo = videos.find(v => v.videoId === note.videoId && v.platform === note.platform);
            }
            
            // Strategy 2: Match by videoUrl (exact match)
            if (!noteVideo && note.videoUrl) {
              noteVideo = videos.find(v => v.videoUrl === note.videoUrl);
            }
            
            // Strategy 3: Match by base URL (without query params and hash)
            if (!noteVideo && note.videoUrl) {
              try {
                const noteUrl = new URL(note.videoUrl);
                noteUrl.search = '';
                noteUrl.hash = '';
                const noteBaseUrl = noteUrl.toString();
                noteVideo = videos.find(v => {
                  if (!v.videoUrl) return false;
                  try {
                    const vUrl = new URL(v.videoUrl);
                    vUrl.search = '';
                    vUrl.hash = '';
                    return vUrl.toString() === noteBaseUrl;
                  } catch {
                    return false;
                  }
                });
              } catch (e) {
                // URL parsing failed, skip
                console.warn('Failed to parse note video URL:', note.videoUrl, e);
              }
            }
            
            // Strategy 4: If only one video exists, use it as fallback
            if (!noteVideo && videos.length === 1) {
              noteVideo = videos[0];
            }
            
            // Debug logging
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              console.log('Could not match note to video:', {
                noteVideoUrl: note.videoUrl,
                noteVideoId: note.videoId,
                notePlatform: note.platform,
                availableVideos: videos.map(v => ({ url: v.videoUrl, id: v.videoId, platform: v.platform, title: v.videoTitle }))
              });
            }
            
            // If we couldn't match but have video info in the note, try to get video title from videos array
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              // Try one more time with a more lenient match (just by videoId, ignoring platform)
              if (note.videoId) {
                const lenientMatch = videos.find(v => v.videoId === note.videoId);
                if (lenientMatch) {
                  noteVideo = lenientMatch;
                }
              }
              // If still no match, try to find by URL (even partial)
              if (!noteVideo && note.videoUrl) {
                try {
                  const noteBaseUrl = note.videoUrl.split('?')[0].split('#')[0];
                  const urlMatch = videos.find(v => {
                    if (!v.videoUrl) return false;
                    const vBaseUrl = v.videoUrl.split('?')[0].split('#')[0];
                    return vBaseUrl === noteBaseUrl;
                  });
                  if (urlMatch) {
                    noteVideo = urlMatch;
                  }
                } catch (e) {
                  // URL parsing failed
                }
              }
            }
            
            // If we still don't have noteVideo but the note has videoTitle stored directly, use it
            // This matches the sidebar behavior - use stored videoTitle as fallback
            if (!noteVideo && note.videoTitle) {
              noteVideo = {
                videoUrl: note.videoUrl,
                videoId: note.videoId,
                platform: note.platform,
                videoTitle: note.videoTitle
              };
            }
            
            // Debug logging
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              console.log('Could not match note to video:', {
                noteVideoUrl: note.videoUrl,
                noteVideoId: note.videoId,
                notePlatform: note.platform,
                noteVideoTitle: note.videoTitle,
                availableVideos: videos.map(v => ({ url: v.videoUrl, id: v.videoId, platform: v.platform, title: v.videoTitle }))
              });
            }
            
            // Pass noteVideo (which may now include videoTitle from note.videoTitle) to addMessage
            // noteImages is already defined above
            // Pass the full note object to preserve all attributes (team, events, zones)
            console.log('Loading note with attributes:', { 
              timestamp: note.timestamp, 
              hasTeam: !!note.team, 
              team: note.team,
              hasEvents: !!(note.events && note.events.length > 0), 
              events: note.events,
              hasZones: !!(note.zones && note.zones.length > 0),
              zones: note.zones,
              fullNote: JSON.stringify(note)
            });
            addMessage(noteText, noteVideo, videos.length, note, noteImages);
          }
        });
      }
    });
  }

  function switchToAnalysis(analysisId) {
    currentAnalysisId = analysisId;
    
    // Show/hide export buttons based on project selection
    const exportProjectDropdownItem = document.getElementById('exportProjectDropdownItem');
    if (exportProjectDropdownItem) {
      exportProjectDropdownItem.style.display = analysisId ? 'flex' : 'none';
    }
    const exportNotesDropdownItem = document.getElementById('exportNotesDropdownItem');
    if (exportNotesDropdownItem) {
      exportNotesDropdownItem.style.display = analysisId ? 'flex' : 'none';
    }
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === analysisId);
      
      // Update the project button text
      updateAnalysisSelect(analyses, analysisId);
      
      if (analysis) {
        // Clear and load messages
        chatMessages.innerHTML = '';
        
        // Initialize selected team from analysis
        selectedTeam = analysis.selectedTeam || null;
        
        // Load teams selector
        renderTeamSelector('');
        updateSelectedTeamDisplay();
        
        // Sort notes by timestamp (oldest first) to ensure consistent order
        const sortedNotes = [...(analysis.notes || [])].sort((a, b) => {
          const timeA = a.timestamp || 0;
          const timeB = b.timestamp || 0;
          return timeA - timeB;
        });
        
        // Get videos from the project to match notes to videos
        let videos = [];
        if (analysis.videos && analysis.videos.length > 0) {
          videos = analysis.videos;
        } else if (analysis.videoUrl) {
          // Migrate legacy structure
          videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
        }
        
        sortedNotes.forEach(note => {
          // Handle both 'text' (popup notes) and 'content' (sidebar notes) fields
          // If both exist and are the same, use only one to avoid duplication
          let noteText = '';
          if (note.text && note.content) {
            // Both exist - use text if they're different, otherwise use text (avoid duplication)
            noteText = note.text.trim();
            // If content is different and longer, it might be the updated version
            if (note.content.trim() !== note.text.trim() && note.content.trim().length > note.text.trim().length) {
              noteText = note.content.trim();
            }
          } else {
            noteText = (note.text || note.content || '').trim();
          }
          
          // Check for duplicate text within the message itself
          if (noteText.length > 0) {
            const messageLength = noteText.length;
            const halfLength = Math.floor(messageLength / 2);
            const firstHalf = noteText.substring(0, halfLength);
            const secondHalf = noteText.substring(halfLength);
            // Check if message is exactly duplicated (first half == second half)
            if (firstHalf === secondHalf && messageLength % 2 === 0) {
              console.warn('Detected duplicated message text when loading, using only first half');
              noteText = firstHalf;
            }
          }
          
          // Check if note has images
          const noteImages = note.images || (note.image ? [note.image] : null);
          const hasImages = noteImages && (Array.isArray(noteImages) ? noteImages.length > 0 : true);
          
          // Display note if it has text OR images
          if (noteText || hasImages) {
            // Find which video this note belongs to
            let noteVideo = null;
            
            // Strategy 1: Match by videoId and platform (most reliable)
            if (note.videoId && note.platform) {
              noteVideo = videos.find(v => v.videoId === note.videoId && v.platform === note.platform);
            }
            
            // Strategy 2: Match by videoUrl (exact match)
            if (!noteVideo && note.videoUrl) {
              noteVideo = videos.find(v => v.videoUrl === note.videoUrl);
            }
            
            // Strategy 3: Match by base URL (without query params and hash)
            if (!noteVideo && note.videoUrl) {
              try {
                const noteUrl = new URL(note.videoUrl);
                noteUrl.search = '';
                noteUrl.hash = '';
                const noteBaseUrl = noteUrl.toString();
                noteVideo = videos.find(v => {
                  if (!v.videoUrl) return false;
                  try {
                    const vUrl = new URL(v.videoUrl);
                    vUrl.search = '';
                    vUrl.hash = '';
                    return vUrl.toString() === noteBaseUrl;
                  } catch {
                    return false;
                  }
                });
              } catch (e) {
                // URL parsing failed, skip
                console.warn('Failed to parse note video URL:', note.videoUrl, e);
              }
            }
            
            // Strategy 4: If only one video exists, use it as fallback
            if (!noteVideo && videos.length === 1) {
              noteVideo = videos[0];
            }
            
            // Debug logging
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              console.log('Could not match note to video:', {
                noteVideoUrl: note.videoUrl,
                noteVideoId: note.videoId,
                notePlatform: note.platform,
                availableVideos: videos.map(v => ({ url: v.videoUrl, id: v.videoId, platform: v.platform, title: v.videoTitle }))
              });
            }
            
            // If we couldn't match but have video info in the note, try to get video title from videos array
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              // Try one more time with a more lenient match (just by videoId, ignoring platform)
              if (note.videoId) {
                const lenientMatch = videos.find(v => v.videoId === note.videoId);
                if (lenientMatch) {
                  noteVideo = lenientMatch;
                }
              }
              // If still no match, try to find by URL (even partial)
              if (!noteVideo && note.videoUrl) {
                try {
                  const noteBaseUrl = note.videoUrl.split('?')[0].split('#')[0];
                  const urlMatch = videos.find(v => {
                    if (!v.videoUrl) return false;
                    const vBaseUrl = v.videoUrl.split('?')[0].split('#')[0];
                    return vBaseUrl === noteBaseUrl;
                  });
                  if (urlMatch) {
                    noteVideo = urlMatch;
                  }
                } catch (e) {
                  // URL parsing failed
                }
              }
            }
            
            // If we still don't have noteVideo but the note has videoTitle stored directly, use it
            // This matches the sidebar behavior - use stored videoTitle as fallback
            if (!noteVideo && note.videoTitle) {
              noteVideo = {
                videoUrl: note.videoUrl,
                videoId: note.videoId,
                platform: note.platform,
                videoTitle: note.videoTitle
              };
            }
            
            // Debug logging
            if (!noteVideo && (note.videoUrl || note.videoId)) {
              console.log('Could not match note to video:', {
                noteVideoUrl: note.videoUrl,
                noteVideoId: note.videoId,
                notePlatform: note.platform,
                noteVideoTitle: note.videoTitle,
                availableVideos: videos.map(v => ({ url: v.videoUrl, id: v.videoId, platform: v.platform, title: v.videoTitle }))
              });
            }
            
            // Pass noteVideo (which may now include videoTitle from note.videoTitle) to addMessage
            // noteImages is already defined above
            // Pass the full note object to preserve all attributes (team, events, zones)
            console.log('Loading note with attributes:', { 
              timestamp: note.timestamp, 
              hasTeam: !!note.team, 
              team: note.team,
              hasEvents: !!(note.events && note.events.length > 0), 
              events: note.events,
              hasZones: !!(note.zones && note.zones.length > 0),
              zones: note.zones,
              fullNote: JSON.stringify(note)
            });
            addMessage(noteText, noteVideo, videos.length, note, noteImages);
          }
        });
        
        // Clear input
        chatInput.value = '';
        
        // Update video link display
        updateProjectVideos(analysis);
        
        // Update media gallery
        updateMediaGallery(analysis);
        
        // Save current analysis ID
        chrome.storage.local.set({ currentAnalysisId: analysisId });
        
        // Dropdown items are always enabled (handled by checking currentAnalysisId)
        const exportProjectDropdownItem = document.getElementById('exportProjectDropdownItem');
        if (exportProjectDropdownItem) {
          exportProjectDropdownItem.style.display = 'flex';
        }
        const exportNotesDropdownItem = document.getElementById('exportNotesDropdownItem');
        if (exportNotesDropdownItem) {
          exportNotesDropdownItem.style.display = 'flex';
        }
      }
    });
  }

  // Delete confirmation modal management
  let pendingDeleteAction = null;

  function showDeleteConfirmModal(message, onConfirm) {
    const deleteConfirmModal = document.getElementById('deleteConfirmModal');
    const deleteConfirmMessage = document.getElementById('deleteConfirmMessage');
    
    if (!deleteConfirmModal || !deleteConfirmMessage) {
      console.error('Delete confirmation modal elements not found');
      // Fallback to system confirm
      if (confirm(message)) {
        onConfirm();
      }
      return;
    }
    
    deleteConfirmMessage.textContent = message;
    pendingDeleteAction = onConfirm;
    deleteConfirmModal.classList.remove('hidden');
  }

  function closeDeleteConfirmModal() {
    const deleteConfirmModal = document.getElementById('deleteConfirmModal');
    if (deleteConfirmModal) {
      deleteConfirmModal.classList.add('hidden');
      pendingDeleteAction = null;
    }
  }

  function confirmDelete() {
    if (pendingDeleteAction) {
      pendingDeleteAction();
      closeDeleteConfirmModal();
    }
  }

  // Delete confirmation modal event listeners
  const deleteConfirmModal = document.getElementById('deleteConfirmModal');
  const closeDeleteConfirmModalBtn = document.getElementById('closeDeleteConfirmModal');
  const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
  const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
  
  if (closeDeleteConfirmModalBtn) {
    closeDeleteConfirmModalBtn.addEventListener('click', closeDeleteConfirmModal);
  }
  
  if (cancelDeleteBtn) {
    cancelDeleteBtn.addEventListener('click', closeDeleteConfirmModal);
  }
  
  if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener('click', confirmDelete);
  }
  
  if (deleteConfirmModal) {
    deleteConfirmModal.addEventListener('click', (e) => {
      if (e.target === deleteConfirmModal) {
        closeDeleteConfirmModal();
      }
    });
  }

  // Delete a message/note
  function deleteMessage(messageDiv, noteData) {
    if (!currentAnalysisId || !noteData || !noteData.timestamp) {
      console.warn('Cannot delete: missing analysis ID or note timestamp');
      return;
    }
    
    showDeleteConfirmModal('Are you sure you want to delete this message?', () => {
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
      
      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        // Find and remove the note by timestamp
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === noteData.timestamp);
        
        if (noteIndex !== -1) {
          analysis.notes.splice(noteIndex, 1);
          
          chrome.storage.local.set({ analyses: analyses }, () => {
            // Remove message from DOM
            messageDiv.remove();
            // Update media gallery (in case images were removed)
            updateMediaGallery(analysis);
          });
        }
      }
      });
    });
  }

  // Edit a message/note
  function editMessage(messageDiv, noteData) {
    if (!currentAnalysisId || !noteData || !noteData.timestamp) {
      console.warn('Cannot edit: missing analysis ID or note timestamp');
      return;
    }
    
    // Get the original text from noteData (most reliable source)
    // If both exist and are the same, use only one to avoid duplication
    let originalText = '';
    if (noteData.text && noteData.content) {
      // Both exist - use text if they're different, otherwise use text (avoid duplication)
      originalText = noteData.text.trim();
      // If content is different and longer, it might be the updated version
      if (noteData.content.trim() !== noteData.text.trim() && noteData.content.trim().length > noteData.text.trim().length) {
        originalText = noteData.content.trim();
      }
    } else if (noteData.text || noteData.content) {
      originalText = (noteData.text || noteData.content || '').trim();
    } else {
      // Fallback: try to extract from DOM
      const textContainer = messageDiv.querySelector('p') || 
                           Array.from(messageDiv.childNodes).find(node => 
                             node.nodeType === Node.ELEMENT_NODE && 
                             !node.classList.contains('message-actions') && 
                             !node.classList.contains('message-image-container') &&
                             !node.classList.contains('message-edit-actions') &&
                             !node.classList.contains('message-team') &&
                             !node.classList.contains('message-events') &&
                             !node.classList.contains('message-zones') &&
                             !node.classList.contains('message-intensity')
                           );
      if (textContainer) {
        originalText = textContainer.textContent || '';
      }
    }
    
    // Check for duplicate text within the message itself
    if (originalText.length > 0) {
      const messageLength = originalText.length;
      const halfLength = Math.floor(messageLength / 2);
      const firstHalf = originalText.substring(0, halfLength);
      const secondHalf = originalText.substring(halfLength);
      // Check if message is exactly duplicated (first half == second half)
      if (firstHalf === secondHalf && messageLength % 2 === 0) {
        console.warn('Detected duplicated message text when editing in popup, using only first half');
        originalText = firstHalf;
      }
    }
    
    // Remove timecode pattern [HH:MM:SS] or [MM:SS] from the beginning for editing
    // But keep the rest of the text intact
    const currentText = originalText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
    
    // Find the text content element to replace
    const textContainer = messageDiv.querySelector('p') || 
                         Array.from(messageDiv.childNodes).find(node => 
                           node.nodeType === Node.ELEMENT_NODE && 
                           !node.classList.contains('message-actions') && 
                           !node.classList.contains('message-image-container') &&
                           !node.classList.contains('message-edit-actions') &&
                           !node.classList.contains('message-team') &&
                           !node.classList.contains('message-events') &&
                           !node.classList.contains('message-zones') &&
                           !node.classList.contains('message-intensity') &&
                           !node.classList.contains('message-intensity')
                         );
    
    if (!textContainer) {
      // If no text element found, create one
      const newTextContainer = document.createElement('div');
      newTextContainer.className = 'message-text';
      const actions = messageDiv.querySelector('.message-actions');
      if (actions) {
        messageDiv.insertBefore(newTextContainer, actions);
      } else {
        messageDiv.appendChild(newTextContainer);
      }
      startEditing(newTextContainer, messageDiv, noteData, currentText);
      return;
    }
    
    startEditing(textContainer, messageDiv, noteData, currentText);
  }

  // Start editing mode
  function startEditing(textContainer, messageDiv, noteData, currentText) {
    isEditingAnyMessage = true;
    console.log('Edit mode started, setting isEditingAnyMessage = true');
    // Add editing class to highlight the message
    messageDiv.classList.add('editing');
    // Hide attribute displays while editing
    const teamElement = messageDiv.querySelector('.message-team');
    const eventsElement = messageDiv.querySelector('.message-events');
    const zonesElement = messageDiv.querySelector('.message-zones');
    const intensityElement = messageDiv.querySelector('.message-intensity');
    if (teamElement) teamElement.style.display = 'none';
    if (eventsElement) eventsElement.style.display = 'none';
    if (zonesElement) zonesElement.style.display = 'none';
    if (intensityElement) intensityElement.style.display = 'none';
    
    // Hide existing images while editing (we'll show them in edit mode with controls)
    const imageContainers = messageDiv.querySelectorAll('.message-image-container');
    imageContainers.forEach(container => {
      container.style.display = 'none';
    });
    
    // Create textarea for editing
    const textarea = document.createElement('textarea');
    textarea.className = 'message-edit-input';
    textarea.value = currentText;
    textarea.rows = Math.max(3, currentText.split('\n').length);
    
    // Replace text container with textarea
    const parent = textContainer.parentNode;
    parent.replaceChild(textarea, textContainer);
    textarea.focus();
    textarea.select();
    
    // Remove existing edit actions if any
    const existingEditActions = messageDiv.querySelector('.message-edit-actions');
    if (existingEditActions) {
      existingEditActions.remove();
    }
    
    // Get current images from noteData and normalize to object format
    const rawImages = noteData && noteData.images ? 
      (Array.isArray(noteData.images) ? [...noteData.images] : [noteData.images]) : 
      (noteData && noteData.image ? [noteData.image] : []);
    
    // Normalize images to consistent object format for editing
    const currentImages = rawImages.map(img => {
      if (typeof img === 'object' && img !== null) {
        // Already an object, ensure it has required fields
        return {
          imageData: img.imageData || img,
          slidesData: img.slidesData || null,
          originalSrc: img.originalSrc || null
        };
      } else {
        // String format, convert to object
        return {
          imageData: img,
          slidesData: null,
          originalSrc: null
        };
      }
    });
    
    // Store edited images in messageDiv for access during save
    messageDiv.dataset.editedImages = JSON.stringify(currentImages);
    
    // Create edit container for attributes
    const editContainer = document.createElement('div');
    editContainer.className = 'message-edit-container';
    editContainer.style.marginTop = '12px';
    editContainer.style.paddingTop = '12px';
    editContainer.style.borderTop = '1px solid #30363d';
    
    // Team selector for editing
    const editTeamContainer = document.createElement('div');
    editTeamContainer.className = 'message-edit-team';
    editTeamContainer.style.marginBottom = '4px';
    editTeamContainer.style.position = 'relative';
    
    const teamLabel = document.createElement('label');
    teamLabel.textContent = 'Team:';
    teamLabel.style.display = 'block';
    teamLabel.style.fontSize = '12px';
    teamLabel.style.color = '#8b949e';
    teamLabel.style.marginBottom = '4px';
    
    // Team selector header with search input and create button
    const teamSelectorHeader = document.createElement('div');
    teamSelectorHeader.style.display = 'flex';
    teamSelectorHeader.style.gap = '4px';
    teamSelectorHeader.style.marginBottom = '4px';
    
    const teamSearchInput = document.createElement('input');
    teamSearchInput.type = 'text';
    teamSearchInput.className = 'message-edit-team-search';
    teamSearchInput.placeholder = 'Search teams...';
    teamSearchInput.style.flex = '1';
    teamSearchInput.style.padding = '6px 10px';
    teamSearchInput.style.background = '#161b22';
    teamSearchInput.style.border = '1px solid #30363d';
    teamSearchInput.style.borderRadius = '6px';
    teamSearchInput.style.color = '#c9d1d9';
    teamSearchInput.style.fontSize = '13px';
    
    const addTeamBtn = document.createElement('button');
    addTeamBtn.className = 'add-team-btn';
    addTeamBtn.textContent = '+';
    addTeamBtn.title = 'Add new team';
    addTeamBtn.style.width = '32px';
    addTeamBtn.style.height = '32px';
    addTeamBtn.style.padding = '0';
    addTeamBtn.style.background = '#21262d';
    addTeamBtn.style.border = '1px solid #30363d';
    addTeamBtn.style.borderRadius = '6px';
    addTeamBtn.style.color = '#c9d1d9';
    addTeamBtn.style.cursor = 'pointer';
    addTeamBtn.style.fontSize = '16px';
    addTeamBtn.style.display = 'flex';
    addTeamBtn.style.alignItems = 'center';
    addTeamBtn.style.justifyContent = 'center';
    
    teamSelectorHeader.appendChild(teamSearchInput);
    teamSelectorHeader.appendChild(addTeamBtn);
    
    // Team dropdown
    const teamDropdown = document.createElement('div');
    teamDropdown.className = 'message-edit-team-dropdown';
    teamDropdown.style.display = 'none';
    teamDropdown.style.position = 'absolute';
    teamDropdown.style.top = '100%';
    teamDropdown.style.left = '0';
    teamDropdown.style.right = '0';
    teamDropdown.style.background = '#161b22';
    teamDropdown.style.border = '1px solid #30363d';
    teamDropdown.style.borderRadius = '6px';
    teamDropdown.style.maxHeight = '200px';
    teamDropdown.style.overflowY = 'auto';
    teamDropdown.style.zIndex = '1000';
    teamDropdown.style.marginTop = '4px';
    teamDropdown.style.boxShadow = '0 8px 24px rgba(0,0,0,0.3)';
    
    const teamList = document.createElement('div');
    teamList.className = 'message-edit-team-list';
    teamDropdown.appendChild(teamList);
    
    // Store selected team for this edit
    let editSelectedTeam = noteData && noteData.team ? noteData.team : null;
    
    // Display currently selected team
    const selectedTeamDisplay = document.createElement('div');
    selectedTeamDisplay.className = 'message-edit-selected-team';
    selectedTeamDisplay.style.marginTop = '4px';
    selectedTeamDisplay.style.fontSize = '12px';
    selectedTeamDisplay.style.color = '#8b949e';
    
    const updateSelectedTeamDisplay = () => {
      selectedTeamDisplay.innerHTML = '';
      if (editSelectedTeam) {
        const tag = document.createElement('span');
        tag.style.display = 'inline-flex';
        tag.style.alignItems = 'center';
        tag.style.gap = '4px';
        tag.style.background = '#21262d';
        tag.style.border = '1px solid #30363d';
        tag.style.borderRadius = '4px';
        tag.style.padding = '2px 6px';
        
        const teamNameSpan = document.createElement('span');
        teamNameSpan.textContent = editSelectedTeam;
        tag.appendChild(teamNameSpan);
        
        const removeBtn = document.createElement('span');
        removeBtn.textContent = '×';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.color = '#8b949e';
        removeBtn.style.fontSize = '14px';
        removeBtn.style.lineHeight = '1';
        removeBtn.style.marginLeft = '4px';
        removeBtn.title = 'Remove team';
        removeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          editSelectedTeam = null;
          updateTeamDataset();
          updateSelectedTeamDisplay();
        });
        
        tag.appendChild(removeBtn);
        selectedTeamDisplay.appendChild(tag);
      }
    };
    updateSelectedTeamDisplay();
    
    // Render team selector function
    const renderEditTeamSelector = (searchQuery = '') => {
      chrome.storage.local.get(['analyses', 'teams'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
        // Use global teams storage, fallback to analysis.teams for backward compatibility
        const globalTeams = result.teams || [];
        const analysisTeams = analysis ? (analysis.teams || []) : [];
        // Merge global teams with analysis teams (global takes precedence)
        const teamsMap = new Map();
        // First add analysis teams (for backward compatibility)
        analysisTeams.forEach(team => {
          const teamName = getTeamName(team);
          if (teamName) teamsMap.set(teamName.toLowerCase(), team);
        });
        // Then add global teams (overwrites duplicates)
        globalTeams.forEach(team => {
          const teamName = typeof team === 'string' ? team : (team.name || '');
          if (teamName) teamsMap.set(teamName.toLowerCase(), team);
        });
        const teams = Array.from(teamsMap.values());
        
        // Filter teams by search query
        const filteredTeams = teams.filter(team => {
          const searchLower = searchQuery.toLowerCase();
          const teamName = getTeamName(team);
          return teamName.toLowerCase().includes(searchLower);
        });
        
        teamList.innerHTML = '';
        
        // Add "No team" option
        const noTeamItem = document.createElement('div');
        noTeamItem.style.display = 'flex';
        noTeamItem.style.alignItems = 'center';
        noTeamItem.style.padding = '4px 8px';
        noTeamItem.style.cursor = 'pointer';
        noTeamItem.style.borderRadius = '4px';
        
        noTeamItem.addEventListener('mouseenter', () => {
          noTeamItem.style.background = '#21262d';
        });
        noTeamItem.addEventListener('mouseleave', () => {
          noTeamItem.style.background = 'transparent';
        });
        
        const noTeamLabel = document.createElement('label');
        noTeamLabel.style.flex = '1';
        noTeamLabel.style.cursor = 'pointer';
        noTeamLabel.style.fontSize = '13px';
        noTeamLabel.style.color = editSelectedTeam === null ? '#1f6feb' : '#c9d1d9';
        noTeamLabel.style.fontWeight = editSelectedTeam === null ? '500' : 'normal';
        noTeamLabel.textContent = 'No team';
        
        noTeamLabel.addEventListener('click', () => {
          editSelectedTeam = null;
          updateTeamDataset();
          updateSelectedTeamDisplay();
          renderEditTeamSelector(teamSearchInput.value);
        });
        
        noTeamItem.appendChild(noTeamLabel);
        teamList.appendChild(noTeamItem);
        
        if (filteredTeams.length === 0 && searchQuery) {
          const emptyMsg = document.createElement('div');
          emptyMsg.style.padding = '10px';
          emptyMsg.style.color = '#8b949e';
          emptyMsg.style.textAlign = 'center';
          emptyMsg.textContent = 'No teams found';
          teamList.appendChild(emptyMsg);
          return;
        }
        
        filteredTeams.forEach(team => {
          const teamName = getTeamName(team);
          
          const teamItem = document.createElement('div');
          teamItem.style.display = 'flex';
          teamItem.style.alignItems = 'center';
          teamItem.style.padding = '4px 8px';
          teamItem.style.cursor = 'pointer';
          teamItem.style.borderRadius = '4px';
          
          teamItem.addEventListener('mouseenter', () => {
            teamItem.style.background = '#21262d';
          });
          teamItem.addEventListener('mouseleave', () => {
            teamItem.style.background = 'transparent';
          });
          
          const label = document.createElement('label');
          label.style.flex = '1';
          label.style.cursor = 'pointer';
          label.style.fontSize = '13px';
          label.style.color = editSelectedTeam === teamName ? '#1f6feb' : '#c9d1d9';
          label.style.fontWeight = editSelectedTeam === teamName ? '500' : 'normal';
          label.textContent = teamName;
          
          label.addEventListener('click', () => {
            editSelectedTeam = teamName;
            updateTeamDataset();
            updateSelectedTeamDisplay();
            renderEditTeamSelector(teamSearchInput.value);
            teamDropdown.style.display = 'none';
          });
          
          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.style.background = 'transparent';
          editBtn.style.border = 'none';
          editBtn.style.color = '#8b949e';
          editBtn.style.cursor = 'pointer';
          editBtn.style.padding = '2px 6px';
          editBtn.style.marginLeft = '4px';
          editBtn.style.fontSize = '12px';
          editBtn.title = 'Edit team';
          editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            renameSelectedTeam(teamName);
            // Refresh the selector after editing
            setTimeout(() => {
              renderEditTeamSelector(teamSearchInput.value);
            }, 500);
          });
          
          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '×';
          deleteBtn.style.background = 'transparent';
          deleteBtn.style.border = 'none';
          deleteBtn.style.color = '#8b949e';
          deleteBtn.style.cursor = 'pointer';
          deleteBtn.style.padding = '2px 6px';
          deleteBtn.style.marginLeft = '2px';
          deleteBtn.style.fontSize = '16px';
          deleteBtn.title = 'Delete team';
          deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            if (confirm(`Are you sure you want to delete the team "${teamName}"? This will remove it from all projects and notes.`)) {
              deleteSelectedTeam(teamName);
              // Refresh the selector after deletion
              setTimeout(() => {
                renderEditTeamSelector(teamSearchInput.value);
                // Clear selection if deleted team was selected
                if (editSelectedTeam === teamName) {
                  editSelectedTeam = null;
                  updateTeamDataset();
                  updateSelectedTeamDisplay();
                }
                // Keep dropdown open
                teamDropdown.style.display = 'block';
              }, 500);
            }
          });
          
          teamItem.appendChild(label);
          teamItem.appendChild(editBtn);
          teamItem.appendChild(deleteBtn);
          teamList.appendChild(teamItem);
        });
      });
    };
    
    // Event listeners for team selector
    teamSearchInput.addEventListener('focus', () => {
      teamDropdown.style.display = 'block';
      renderEditTeamSelector(teamSearchInput.value);
    });
    
    teamSearchInput.addEventListener('input', (e) => {
      renderEditTeamSelector(e.target.value);
    });
    
    teamSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!teamDropdown.matches(':hover') && document.activeElement !== teamSearchInput) {
          teamDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    teamDropdown.addEventListener('mouseenter', () => {
      teamDropdown.style.display = 'block';
    });
    
    teamDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== teamSearchInput) {
        teamDropdown.style.display = 'none';
      }
    });
    
    // Create team button handler
    addTeamBtn.addEventListener('click', () => {
      // Store a reference to refresh function that can be called after team creation
      const originalCreateTeam = window.createTeam || createTeam;
      const refreshAfterCreate = () => {
        renderEditTeamSelector(teamSearchInput.value);
        teamDropdown.style.display = 'block';
      };
      
      // Temporarily override createTeam to refresh after creation
      const tempCreateTeam = function(...args) {
        const result = originalCreateTeam.apply(this, args);
        setTimeout(refreshAfterCreate, 100);
        return result;
      };
      
      // Call createNewTeam which will open the modal
      createNewTeam();
      
      // Listen for team creation completion (check periodically)
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['analyses'], (result) => {
          const analyses = result.analyses || [];
          const analysis = analyses.find(a => a.id === currentAnalysisId);
          const teams = analysis ? (analysis.teams || []) : [];
          // If teams count increased, refresh
          if (teams.length > (window.lastTeamCount || 0)) {
            window.lastTeamCount = teams.length;
            renderEditTeamSelector(teamSearchInput.value);
            teamDropdown.style.display = 'block';
          }
        });
      }, 500);
      
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    // Store editSelectedTeam in messageDiv for access during save
    messageDiv.dataset.editSelectedTeam = editSelectedTeam || '';
    
    // Helper function to update dataset when team changes
    const updateTeamDataset = () => {
      messageDiv.dataset.editSelectedTeam = editSelectedTeam || '';
    };
    
    editTeamContainer.appendChild(teamLabel);
    editTeamContainer.appendChild(teamSelectorHeader);
    editTeamContainer.appendChild(selectedTeamDisplay);
    editTeamContainer.appendChild(teamDropdown);
    editContainer.appendChild(editTeamContainer);
    
    // Initial render
    renderEditTeamSelector('');
    
    // Events selector for editing
    const editEventsContainer = document.createElement('div');
    editEventsContainer.className = 'message-edit-events';
    editEventsContainer.style.marginBottom = '4px';
    editEventsContainer.style.position = 'relative';
    
    const eventsLabel = document.createElement('label');
    eventsLabel.textContent = 'Events:';
    eventsLabel.style.display = 'block';
    eventsLabel.style.fontSize = '12px';
    eventsLabel.style.color = '#8b949e';
    eventsLabel.style.marginBottom = '4px';
    
    // Event selector header with search input and create button
    const eventSelectorHeader = document.createElement('div');
    eventSelectorHeader.style.display = 'flex';
    eventSelectorHeader.style.gap = '4px';
    eventSelectorHeader.style.marginBottom = '4px';
    
    const eventsSearchInput = document.createElement('input');
    eventsSearchInput.type = 'text';
    eventsSearchInput.className = 'message-edit-events-search';
    eventsSearchInput.placeholder = 'Search events...';
    eventsSearchInput.style.flex = '1';
    eventsSearchInput.style.padding = '6px 10px';
    eventsSearchInput.style.background = '#161b22';
    eventsSearchInput.style.border = '1px solid #30363d';
    eventsSearchInput.style.borderRadius = '6px';
    eventsSearchInput.style.color = '#c9d1d9';
    eventsSearchInput.style.fontSize = '13px';
    
    const addEventBtn = document.createElement('button');
    addEventBtn.className = 'add-custom-event-btn';
    addEventBtn.textContent = '+';
    addEventBtn.title = 'Add custom event';
    addEventBtn.style.width = '32px';
    addEventBtn.style.height = '32px';
    addEventBtn.style.padding = '0';
    addEventBtn.style.background = '#21262d';
    addEventBtn.style.border = '1px solid #30363d';
    addEventBtn.style.borderRadius = '6px';
    addEventBtn.style.color = '#c9d1d9';
    addEventBtn.style.cursor = 'pointer';
    addEventBtn.style.fontSize = '16px';
    addEventBtn.style.display = 'flex';
    addEventBtn.style.alignItems = 'center';
    addEventBtn.style.justifyContent = 'center';
    
    eventSelectorHeader.appendChild(eventsSearchInput);
    eventSelectorHeader.appendChild(addEventBtn);
    
    const eventsDropdown = document.createElement('div');
    eventsDropdown.className = 'message-edit-events-dropdown';
    eventsDropdown.style.display = 'none';
    eventsDropdown.style.maxHeight = '200px';
    eventsDropdown.style.overflowY = 'auto';
    eventsDropdown.style.background = '#161b22';
    eventsDropdown.style.border = '1px solid #30363d';
    eventsDropdown.style.borderRadius = '6px';
    eventsDropdown.style.padding = '8px';
    eventsDropdown.style.marginTop = '4px';
    
    // Store selected events for this edit
    let editSelectedEvents = noteData && noteData.events ? [...noteData.events] : [];
    
    // Display currently selected events
    const selectedEventsDisplay = document.createElement('div');
    selectedEventsDisplay.className = 'message-edit-selected-events';
    selectedEventsDisplay.style.marginTop = '4px';
    selectedEventsDisplay.style.marginBottom = '4px';
    selectedEventsDisplay.style.fontSize = '12px';
    selectedEventsDisplay.style.color = '#8b949e';
    
    const updateSelectedEventsDisplay = () => {
      selectedEventsDisplay.innerHTML = '';
      if (editSelectedEvents.length > 0) {
        const label = document.createElement('span');
        label.textContent = 'Selected: ';
        label.style.fontWeight = '500';
        selectedEventsDisplay.appendChild(label);
        editSelectedEvents.forEach(event => {
          const tag = document.createElement('span');
          tag.textContent = event;
          tag.style.background = '#21262d';
          tag.style.border = '1px solid #30363d';
          tag.style.borderRadius = '4px';
          tag.style.padding = '2px 6px';
          tag.style.marginLeft = '4px';
          tag.style.cursor = 'pointer';
          tag.style.display = 'inline-flex';
          tag.style.alignItems = 'center';
          tag.style.gap = '4px';
          tag.title = 'Click to remove';
          
          // Add remove button
          const removeBtn = document.createElement('span');
          removeBtn.textContent = '×';
          removeBtn.style.color = '#8b949e';
          removeBtn.style.fontSize = '14px';
          removeBtn.style.lineHeight = '1';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.cursor = 'pointer';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editSelectedEvents = editSelectedEvents.filter(e => e !== event);
            updateSelectedEventsDisplay();
            // Update checkboxes in dropdown
            renderEditEvents(eventsSearchInput.value);
          });
          
          tag.appendChild(removeBtn);
          selectedEventsDisplay.appendChild(tag);
        });
      }
    };
    updateSelectedEventsDisplay();
    
    const renderEditEvents = (searchTerm = '') => {
      eventsDropdown.innerHTML = '';
      const searchLower = searchTerm.toLowerCase().trim();
      
      EVENT_CATEGORIES.forEach(category => {
        const filteredEvents = searchTerm
          ? category.events.filter(event => event.toLowerCase().includes(searchLower))
          : category.events;
        
        if (searchTerm && filteredEvents.length === 0) return;
        
        const categoryDiv = document.createElement('div');
        categoryDiv.style.marginBottom = '12px';
        
        const categoryName = document.createElement('div');
        categoryName.textContent = category.name;
        categoryName.style.fontSize = '11px';
        categoryName.style.fontWeight = '600';
        categoryName.style.color = '#8b949e';
        categoryName.style.textTransform = 'uppercase';
        categoryName.style.marginBottom = '4px';
        categoryDiv.appendChild(categoryName);
        
        filteredEvents.forEach(event => {
          const eventItem = document.createElement('div');
          eventItem.style.display = 'flex';
          eventItem.style.alignItems = 'center';
          eventItem.style.gap = '8px';
          eventItem.style.padding = '4px 0';
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = event;
          checkbox.checked = editSelectedEvents.includes(event);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!editSelectedEvents.includes(event)) {
                editSelectedEvents.push(event);
              }
            } else {
              editSelectedEvents = editSelectedEvents.filter(e => e !== event);
            }
            updateSelectedEventsDisplay();
          });
          
          const label = document.createElement('label');
          label.textContent = translateEventName(event);
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          label.style.cursor = 'pointer';
          label.style.flex = '1';
          
          eventItem.appendChild(checkbox);
          eventItem.appendChild(label);
          categoryDiv.appendChild(eventItem);
        });
        
        eventsDropdown.appendChild(categoryDiv);
      });
    };
    
    eventsSearchInput.addEventListener('focus', () => {
      eventsDropdown.style.display = 'block';
      renderEditEvents(eventsSearchInput.value);
    });
    
    eventsSearchInput.addEventListener('input', (e) => {
      renderEditEvents(e.target.value);
    });
    
    eventsSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!eventsDropdown.matches(':hover') && document.activeElement !== eventsSearchInput) {
          eventsDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    eventsDropdown.addEventListener('mouseenter', () => {
      eventsDropdown.style.display = 'block';
    });
    
    eventsDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== eventsSearchInput) {
        eventsDropdown.style.display = 'none';
      }
    });
    
    // Create event button handler
    addEventBtn.addEventListener('click', () => {
      addCustomEvent();
      // Listen for event creation completion
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['customEvents'], (result) => {
          const customEvents = result.customEvents || [];
          // If events count increased, refresh
          if (customEvents.length > (window.lastEventCount || 0)) {
            window.lastEventCount = customEvents.length;
            renderEditEvents(eventsSearchInput.value);
            eventsDropdown.style.display = 'block';
          }
        });
      }, 500);
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    renderEditEvents();
    
    editEventsContainer.appendChild(eventsLabel);
    editEventsContainer.appendChild(eventSelectorHeader);
    editEventsContainer.appendChild(selectedEventsDisplay);
    editEventsContainer.appendChild(eventsDropdown);
    editContainer.appendChild(editEventsContainer);
    
    // Zones selector for editing
    const editZonesContainer = document.createElement('div');
    editZonesContainer.className = 'message-edit-zones';
    editZonesContainer.style.marginBottom = '4px';
    editZonesContainer.style.position = 'relative';
    
    const zonesLabel = document.createElement('label');
    zonesLabel.textContent = 'Zones:';
    zonesLabel.style.display = 'block';
    zonesLabel.style.fontSize = '12px';
    zonesLabel.style.color = '#8b949e';
    zonesLabel.style.marginBottom = '4px';
    
    const zonesSearchInput = document.createElement('input');
    zonesSearchInput.type = 'text';
    zonesSearchInput.className = 'message-edit-zones-search';
    zonesSearchInput.placeholder = 'Search zones...';
    zonesSearchInput.style.width = '100%';
    zonesSearchInput.style.padding = '6px 10px';
    zonesSearchInput.style.background = '#161b22';
    zonesSearchInput.style.border = '1px solid #30363d';
    zonesSearchInput.style.borderRadius = '6px';
    zonesSearchInput.style.color = '#c9d1d9';
    zonesSearchInput.style.fontSize = '13px';
    
    const zonesDropdown = document.createElement('div');
    zonesDropdown.className = 'message-edit-zones-dropdown';
    zonesDropdown.style.display = 'none';
    zonesDropdown.style.maxHeight = '200px';
    zonesDropdown.style.overflowY = 'auto';
    zonesDropdown.style.background = '#161b22';
    zonesDropdown.style.border = '1px solid #30363d';
    zonesDropdown.style.borderRadius = '6px';
    zonesDropdown.style.padding = '8px';
    zonesDropdown.style.marginTop = '4px';
    
    // Store selected zones for this edit
    let editSelectedZones = noteData && noteData.zones ? [...noteData.zones] : [];
    
    // Display currently selected zones
    const selectedZonesDisplay = document.createElement('div');
    selectedZonesDisplay.className = 'message-edit-selected-zones';
    selectedZonesDisplay.style.marginTop = '4px';
    selectedZonesDisplay.style.marginBottom = '4px';
    selectedZonesDisplay.style.fontSize = '12px';
    selectedZonesDisplay.style.color = '#8b949e';
    
    const updateSelectedZonesDisplay = () => {
      selectedZonesDisplay.innerHTML = '';
      if (editSelectedZones.length > 0) {
        const label = document.createElement('span');
        label.textContent = 'Selected: ';
        label.style.fontWeight = '500';
        selectedZonesDisplay.appendChild(label);
        const sortedZones = [...editSelectedZones].sort((a, b) => a - b);
        sortedZones.forEach(zone => {
          const tag = document.createElement('span');
          tag.textContent = `Zone ${zone}`;
          tag.style.background = '#21262d';
          tag.style.border = '1px solid #30363d';
          tag.style.borderRadius = '4px';
          tag.style.padding = '2px 6px';
          tag.style.marginLeft = '4px';
          tag.style.cursor = 'pointer';
          tag.style.display = 'inline-flex';
          tag.style.alignItems = 'center';
          tag.style.gap = '4px';
          tag.title = 'Click to remove';
          
          // Add remove button
          const removeBtn = document.createElement('span');
          removeBtn.textContent = '×';
          removeBtn.style.color = '#8b949e';
          removeBtn.style.fontSize = '14px';
          removeBtn.style.lineHeight = '1';
          removeBtn.style.marginLeft = '4px';
          removeBtn.style.cursor = 'pointer';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            editSelectedZones = editSelectedZones.filter(z => z !== zone);
            updateSelectedZonesDisplay();
            // Update checkboxes in dropdown
            renderEditZones(zonesSearchInput.value);
          });
          
          tag.appendChild(removeBtn);
          selectedZonesDisplay.appendChild(tag);
        });
      }
    };
    updateSelectedZonesDisplay();
    
    const renderEditZones = (searchTerm = '') => {
      zonesDropdown.innerHTML = '';
      const searchLower = searchTerm.toLowerCase().trim();
      
      ZONES_CATEGORIES.forEach(category => {
        const filteredZones = searchTerm
          ? category.zones.filter(zone => zone.toString().includes(searchLower) || category.name.toLowerCase().includes(searchLower))
          : category.zones;
        
        if (searchTerm && filteredZones.length === 0) return;
        
        const categoryDiv = document.createElement('div');
        categoryDiv.style.marginBottom = '12px';
        
        const categoryName = document.createElement('div');
        categoryName.textContent = category.name;
        categoryName.style.fontSize = '11px';
        categoryName.style.fontWeight = '600';
        categoryName.style.color = '#8b949e';
        categoryName.style.textTransform = 'uppercase';
        categoryName.style.marginBottom = '4px';
        categoryDiv.appendChild(categoryName);
        
        filteredZones.forEach(zoneNumber => {
          const zoneItem = document.createElement('div');
          zoneItem.style.display = 'flex';
          zoneItem.style.alignItems = 'center';
          zoneItem.style.gap = '8px';
          zoneItem.style.padding = '4px 0';
          
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = zoneNumber;
          checkbox.checked = editSelectedZones.includes(zoneNumber);
          checkbox.addEventListener('change', (e) => {
            if (e.target.checked) {
              if (!editSelectedZones.includes(zoneNumber)) {
                editSelectedZones.push(zoneNumber);
              }
            } else {
              editSelectedZones = editSelectedZones.filter(z => z !== zoneNumber);
            }
            updateSelectedZonesDisplay();
          });
          
          const label = document.createElement('label');
          label.textContent = `Zone ${zoneNumber}`;
          label.style.fontSize = '13px';
          label.style.color = '#c9d1d9';
          label.style.cursor = 'pointer';
          label.style.flex = '1';
          
          zoneItem.appendChild(checkbox);
          zoneItem.appendChild(label);
          categoryDiv.appendChild(zoneItem);
        });
        
        zonesDropdown.appendChild(categoryDiv);
      });
    };
    
    zonesSearchInput.addEventListener('focus', () => {
      zonesDropdown.style.display = 'block';
      renderEditZones(zonesSearchInput.value);
    });
    
    zonesSearchInput.addEventListener('input', (e) => {
      renderEditZones(e.target.value);
    });
    
    zonesSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!zonesDropdown.matches(':hover') && document.activeElement !== zonesSearchInput) {
          zonesDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    zonesDropdown.addEventListener('mouseenter', () => {
      zonesDropdown.style.display = 'block';
    });
    
    zonesDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== zonesSearchInput) {
        zonesDropdown.style.display = 'none';
      }
    });
    
    renderEditZones();
    
    editZonesContainer.appendChild(zonesLabel);
    editZonesContainer.appendChild(zonesSearchInput);
    editZonesContainer.appendChild(selectedZonesDisplay);
    editZonesContainer.appendChild(zonesDropdown);
    editContainer.appendChild(editZonesContainer);
    
    // Players selector for editing
    const editPlayersContainer = document.createElement('div');
    editPlayersContainer.className = 'message-edit-players';
    editPlayersContainer.style.marginBottom = '4px';
    editPlayersContainer.style.position = 'relative';
    
    const playersLabel = document.createElement('label');
    playersLabel.textContent = 'Players:';
    playersLabel.style.display = 'block';
    playersLabel.style.fontSize = '12px';
    playersLabel.style.color = '#8b949e';
    playersLabel.style.marginBottom = '4px';
    
    // Player selector header with search input and create button
    const playerSelectorHeader = document.createElement('div');
    playerSelectorHeader.style.display = 'flex';
    playerSelectorHeader.style.gap = '4px';
    playerSelectorHeader.style.marginBottom = '4px';
    
    // Initialize selected players - convert names to IDs if needed
    let editSelectedPlayers = noteData && noteData.players ? [...noteData.players] : [];
    
    // IMMEDIATE synchronous deduplication to remove any existing duplicates
    if (editSelectedPlayers.length > 0) {
      const immediateDeduped = [];
      const seenImmediate = new Set();
      editSelectedPlayers.forEach(ref => {
        if (!seenImmediate.has(ref)) {
          seenImmediate.add(ref);
          immediateDeduped.push(ref);
        }
      });
      editSelectedPlayers = immediateDeduped;
    }
    
    // Convert player names to IDs asynchronously and deduplicate
    if (editSelectedPlayers.length > 0) {
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const convertedPlayers = [];
        const seenIds = new Set();
        
        editSelectedPlayers.forEach(playerRef => {
          // Check if it's an ID (starts with 'player_')
          if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
            const player = players.find(p => p.id === playerRef);
            if (player && !seenIds.has(playerRef)) {
              convertedPlayers.push(playerRef);
              seenIds.add(playerRef);
            }
          } else if (typeof playerRef === 'string') {
            // It's a name string - try to find by name and convert to ID
            const playerNameLower = playerRef.toLowerCase().trim();
            // Skip if it looks like message text
            if (playerNameLower.length > 100 || playerNameLower.includes('!') || playerNameLower.includes('?') || playerNameLower.includes('.')) {
              return; // Skip invalid player names
            }
            const matched = players.find(p => {
              const fullName = (p.fullName || '').toLowerCase();
              const name = (p.name || '').toLowerCase();
              const surname = (p.surname || '').toLowerCase();
              return fullName === playerNameLower || 
                     name === playerNameLower || 
                     surname === playerNameLower ||
                     fullName.includes(playerNameLower) ||
                     playerNameLower.includes(fullName);
            });
            if (matched && !seenIds.has(matched.id)) {
              convertedPlayers.push(matched.id);
              seenIds.add(matched.id);
            } else if (!matched && !convertedPlayers.includes(playerRef)) {
              // Keep as-is if not found (will be filtered out in display)
              // Only add if not already in the array
              convertedPlayers.push(playerRef);
            }
          } else if (!convertedPlayers.includes(playerRef)) {
            convertedPlayers.push(playerRef);
          }
        });
        editSelectedPlayers = convertedPlayers;
        // Update display after converting
        updateSelectedPlayersDisplayEdit();
        renderEditPlayers(playersSearchInput.value);
      });
    }
    
    const playersSearchInput = document.createElement('input');
    playersSearchInput.type = 'text';
    playersSearchInput.className = 'message-edit-players-search';
    playersSearchInput.placeholder = 'Search players...';
    playersSearchInput.style.flex = '1';
    playersSearchInput.style.padding = '6px 10px';
    playersSearchInput.style.background = '#161b22';
    playersSearchInput.style.border = '1px solid #30363d';
    playersSearchInput.style.borderRadius = '6px';
    playersSearchInput.style.color = '#c9d1d9';
    playersSearchInput.style.fontSize = '13px';
    
    const addPlayerBtn = document.createElement('button');
    addPlayerBtn.className = 'add-player-btn';
    addPlayerBtn.textContent = '+';
    addPlayerBtn.title = 'Add new player';
    addPlayerBtn.style.width = '32px';
    addPlayerBtn.style.height = '32px';
    addPlayerBtn.style.padding = '0';
    addPlayerBtn.style.background = '#21262d';
    addPlayerBtn.style.border = '1px solid #30363d';
    addPlayerBtn.style.borderRadius = '6px';
    addPlayerBtn.style.color = '#c9d1d9';
    addPlayerBtn.style.cursor = 'pointer';
    addPlayerBtn.style.fontSize = '16px';
    addPlayerBtn.style.display = 'flex';
    addPlayerBtn.style.alignItems = 'center';
    addPlayerBtn.style.justifyContent = 'center';
    
    playerSelectorHeader.appendChild(playersSearchInput);
    playerSelectorHeader.appendChild(addPlayerBtn);
    
    const selectedPlayersDisplayEdit = document.createElement('div');
    selectedPlayersDisplayEdit.className = 'message-edit-selected-players';
    selectedPlayersDisplayEdit.style.marginTop = '4px';
    selectedPlayersDisplayEdit.style.marginBottom = '4px';
    selectedPlayersDisplayEdit.style.fontSize = '12px';
    selectedPlayersDisplayEdit.style.color = '#8b949e';
    
    let isUpdatingDisplay = false;
    const updateSelectedPlayersDisplayEdit = () => {
      // Prevent concurrent updates
      if (isUpdatingDisplay) {
        return;
      }
      isUpdatingDisplay = true;
      
      // Clear display completely
      selectedPlayersDisplayEdit.innerHTML = '';
      
      // First, deduplicate the array synchronously (simple reference-based deduplication)
      // This handles both IDs and names
      const uniqueRefs = [];
      const seenRefs = new Set();
      editSelectedPlayers.forEach(ref => {
        if (!seenRefs.has(ref)) {
          seenRefs.add(ref);
          uniqueRefs.push(ref);
        }
      });
      editSelectedPlayers = uniqueRefs;
      
      if (editSelectedPlayers.length > 0) {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const selectedPlayerObjects = [];
          const playerNames = [];
          
          // Handle both IDs and names, and deduplicate by player ID
          const seenPlayerIds = new Set();
          const processedRefs = [];
          
          editSelectedPlayers.forEach(playerRef => {
            if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
              const player = players.find(p => p.id === playerRef);
              if (player && !seenPlayerIds.has(player.id)) {
                selectedPlayerObjects.push(player);
                seenPlayerIds.add(player.id);
                processedRefs.push(player.id);
              } else if (!player) {
                // Invalid ID, skip it
              }
            } else if (typeof playerRef === 'string') {
              // It's a name string - try to find by name
              const playerNameLower = playerRef.toLowerCase().trim();
              const player = players.find(p => {
                const fullName = (p.fullName || '').toLowerCase();
                const name = (p.name || '').toLowerCase();
                const surname = (p.surname || '').toLowerCase();
                return fullName === playerNameLower || 
                       name === playerNameLower || 
                       surname === playerNameLower ||
                       fullName.includes(playerNameLower) ||
                       playerNameLower.includes(fullName);
              });
              if (player && !seenPlayerIds.has(player.id)) {
                selectedPlayerObjects.push(player);
                seenPlayerIds.add(player.id);
                processedRefs.push(player.id);
              } else if (player && seenPlayerIds.has(player.id)) {
                // Duplicate - skip
              } else if (playerRef.length < 100 && !playerRef.includes('!') && !playerRef.includes('?') && !playerRef.includes('.')) {
                // Valid name but not found - keep as fallback (only if not already seen)
                const nameLower = playerRef.toLowerCase().trim();
                if (!playerNames.some(n => n.toLowerCase().trim() === nameLower)) {
                  playerNames.push(playerRef);
                  processedRefs.push(playerRef);
                }
              }
            }
          });
          
          // Update editSelectedPlayers to remove duplicates
          editSelectedPlayers = processedRefs;
          
          // Final deduplication of selectedPlayerObjects by ID
          const uniquePlayerObjects = [];
          const uniquePlayerIds = new Set();
          selectedPlayerObjects.forEach(player => {
            if (!uniquePlayerIds.has(player.id)) {
              uniquePlayerIds.add(player.id);
              uniquePlayerObjects.push(player);
            }
          });
          
          // Clear display again before rendering (in case of race conditions)
          selectedPlayersDisplayEdit.innerHTML = '';
          
          if (uniquePlayerObjects.length > 0 || playerNames.length > 0) {
          const label = document.createElement('span');
          label.textContent = 'Selected: ';
          selectedPlayersDisplayEdit.appendChild(label);
          
            // Display matched players - ensure no duplicates by using a Set to track displayed IDs
            const displayedPlayerIds = new Set();
            uniquePlayerObjects.forEach(player => {
              // Skip if we've already displayed this player
              if (displayedPlayerIds.has(player.id)) {
                return;
              }
              displayedPlayerIds.add(player.id);
              
            const tag = document.createElement('span');
            tag.textContent = player.number ? 
              `#${player.number} ${player.fullName || ''}`.trim() : 
              (player.fullName || 'Unnamed');
            tag.style.background = '#21262d';
            tag.style.color = '#c9d1d9';
            tag.style.padding = '4px 8px';
            tag.style.borderRadius = '12px';
            tag.style.fontSize = '12px';
            tag.style.marginRight = '6px';
            tag.style.marginBottom = '4px';
            tag.style.display = 'inline-block';
            
            const removeBtn = document.createElement('span');
            removeBtn.textContent = ' ×';
            removeBtn.style.cursor = 'pointer';
            removeBtn.style.marginLeft = '4px';
            removeBtn.style.color = '#8b949e';
            removeBtn.addEventListener('click', () => {
              editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
              updateSelectedPlayersDisplayEdit();
              renderEditPlayers(playersSearchInput.value);
            });
            
            tag.appendChild(removeBtn);
            selectedPlayersDisplayEdit.appendChild(tag);
          });
            
            // Display unmatched player names (fallback) - also deduplicate
            const displayedNames = new Set();
            playerNames.forEach(playerName => {
              const nameLower = playerName.toLowerCase().trim();
              if (displayedNames.has(nameLower)) {
                return;
              }
              displayedNames.add(nameLower);
              
              const tag = document.createElement('span');
              tag.textContent = playerName;
              tag.style.background = '#21262d';
              tag.style.color = '#c9d1d9';
              tag.style.padding = '4px 8px';
              tag.style.borderRadius = '12px';
              tag.style.fontSize = '12px';
              tag.style.marginRight = '6px';
              tag.style.marginBottom = '4px';
              tag.style.display = 'inline-block';
              
              const removeBtn = document.createElement('span');
              removeBtn.textContent = ' ×';
              removeBtn.style.cursor = 'pointer';
              removeBtn.style.marginLeft = '4px';
              removeBtn.style.color = '#8b949e';
              removeBtn.addEventListener('click', () => {
                editSelectedPlayers = editSelectedPlayers.filter(ref => ref !== playerName);
                updateSelectedPlayersDisplayEdit();
                renderEditPlayers(playersSearchInput.value);
              });
              
              tag.appendChild(removeBtn);
              selectedPlayersDisplayEdit.appendChild(tag);
            });
          }
          
          isUpdatingDisplay = false;
        });
      } else {
        isUpdatingDisplay = false;
      }
    };
    
    const playersDropdown = document.createElement('div');
    playersDropdown.className = 'message-edit-players-dropdown';
    playersDropdown.style.display = 'none';
    playersDropdown.style.position = 'absolute';
    playersDropdown.style.background = '#161b22';
    playersDropdown.style.border = '1px solid #30363d';
    playersDropdown.style.borderRadius = '6px';
    playersDropdown.style.maxHeight = '200px';
    playersDropdown.style.overflowY = 'auto';
    playersDropdown.style.zIndex = '1000';
    playersDropdown.style.width = '100%';
    playersDropdown.style.marginTop = '4px';
    
    const renderEditPlayers = (searchQuery = '') => {
      chrome.storage.local.get(['players', 'analyses'], (result) => {
        const players = result.players || [];
        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === currentAnalysisId);
        const teams = analysis ? (analysis.teams || []) : [];
        
        const filteredPlayers = players.filter(player => {
          const searchLower = searchQuery.toLowerCase();
          const fullName = (player.fullName || '').toLowerCase();
          const number = (player.number || '').toString();
          const team = (player.team || '').toLowerCase();
          return fullName.includes(searchLower) || 
                 number.includes(searchLower) || 
                 team.includes(searchLower);
        });
        
        playersDropdown.innerHTML = '';
        
        if (filteredPlayers.length === 0) {
          const emptyMsg = document.createElement('div');
          emptyMsg.style.padding = '10px';
          emptyMsg.style.color = '#8b949e';
          emptyMsg.style.textAlign = 'center';
          emptyMsg.textContent = searchQuery ? 'No players found' : 'No players created yet';
          playersDropdown.appendChild(emptyMsg);
          return;
        }
        
        const playersByTeam = {};
        filteredPlayers.forEach(player => {
          const team = player.team || 'No team';
          if (!playersByTeam[team]) {
            playersByTeam[team] = [];
          }
          playersByTeam[team].push(player);
        });
        
        const sortedTeams = Object.keys(playersByTeam).sort();
        
        sortedTeams.forEach(team => {
          const teamDiv = document.createElement('div');
          teamDiv.style.marginBottom = '8px';
          
          const teamLabel = document.createElement('div');
          teamLabel.style.fontSize = '11px';
          teamLabel.style.color = '#8b949e';
          teamLabel.style.marginBottom = '4px';
          teamLabel.style.padding = '4px 8px';
          teamLabel.textContent = team;
          teamDiv.appendChild(teamLabel);
          
          playersByTeam[team].sort((a, b) => {
            const numA = parseInt(a.number) || 0;
            const numB = parseInt(b.number) || 0;
            return numA - numB;
          }).forEach(player => {
            const playerItem = document.createElement('div');
            playerItem.style.display = 'flex';
            playerItem.style.alignItems = 'center';
            playerItem.style.padding = '4px 8px';
            playerItem.style.cursor = 'pointer';
            
            playerItem.addEventListener('mouseenter', () => {
              playerItem.style.background = '#21262d';
            });
            playerItem.addEventListener('mouseleave', () => {
              playerItem.style.background = 'transparent';
            });
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = player.id;
            // Check if player is selected (by ID or by name match)
            const isSelected = editSelectedPlayers.includes(player.id) || 
                              editSelectedPlayers.some(ref => {
                                if (typeof ref === 'string' && !ref.startsWith('player_')) {
                                  // It's a name - check if it matches this player
                                  const refLower = ref.toLowerCase().trim();
                                  const fullName = (player.fullName || '').toLowerCase();
                                  const name = (player.name || '').toLowerCase();
                                  const surname = (player.surname || '').toLowerCase();
                                  return fullName === refLower || 
                                         name === refLower || 
                                         surname === refLower ||
                                         fullName.includes(refLower) ||
                                         refLower.includes(fullName);
                                }
                                return false;
                              });
            checkbox.checked = isSelected;
            checkbox.style.marginRight = '8px';
            checkbox.style.cursor = 'pointer';
            
            checkbox.addEventListener('change', (e) => {
              if (e.target.checked) {
                if (!editSelectedPlayers.includes(player.id)) {
                  // Remove any name-based references to this player
                  editSelectedPlayers = editSelectedPlayers.filter(ref => {
                    if (typeof ref === 'string' && !ref.startsWith('player_')) {
                      const refLower = ref.toLowerCase().trim();
                      const fullName = (player.fullName || '').toLowerCase();
                      const name = (player.name || '').toLowerCase();
                      const surname = (player.surname || '').toLowerCase();
                      const matches = fullName === refLower || 
                                     name === refLower || 
                                     surname === refLower ||
                                     fullName.includes(refLower) ||
                                     refLower.includes(fullName);
                      return !matches; // Remove matching name references
                    }
                    return ref !== player.id; // Remove old ID if present
                  });
                  editSelectedPlayers.push(player.id);
                }
              } else {
                editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
              }
              updateSelectedPlayersDisplayEdit();
            });
            
            const label = document.createElement('label');
            label.style.flex = '1';
            label.style.cursor = 'pointer';
            label.style.fontSize = '13px';
            label.style.color = '#c9d1d9';
            
            const displayText = player.number ? 
              `#${player.number} ${player.fullName || ''}`.trim() : 
              (player.fullName || 'Unnamed');
            label.textContent = displayText;
            
            label.addEventListener('click', () => {
              checkbox.checked = !checkbox.checked;
              checkbox.dispatchEvent(new Event('change'));
            });
            
            const editBtn = document.createElement('button');
            editBtn.textContent = '✎';
            editBtn.style.background = 'transparent';
            editBtn.style.border = 'none';
            editBtn.style.color = '#8b949e';
            editBtn.style.cursor = 'pointer';
            editBtn.style.padding = '2px 6px';
            editBtn.style.marginLeft = '4px';
            editBtn.style.fontSize = '12px';
            editBtn.title = 'Edit player';
            editBtn.addEventListener('click', (e) => {
              e.stopPropagation();
              editPlayer(player.id);
              // Refresh the dropdown after editing
              setTimeout(() => {
                renderEditPlayers(playersSearchInput.value);
                updateSelectedPlayersDisplayEdit();
              }, 500);
            });
            
            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = '×';
            deleteBtn.style.background = 'transparent';
            deleteBtn.style.border = 'none';
            deleteBtn.style.color = '#8b949e';
            deleteBtn.style.cursor = 'pointer';
            deleteBtn.style.padding = '2px 6px';
            deleteBtn.style.marginLeft = '2px';
            deleteBtn.style.fontSize = '16px';
            deleteBtn.title = 'Delete player';
            deleteBtn.addEventListener('click', (e) => {
              e.stopPropagation();
              if (confirm(`Are you sure you want to delete ${player.fullName || 'this player'}?`)) {
                deletePlayer(player.id);
                // Remove from selected if it was selected
                editSelectedPlayers = editSelectedPlayers.filter(id => id !== player.id);
                // Refresh the dropdown after deletion
                setTimeout(() => {
                  renderEditPlayers(playersSearchInput.value);
                  updateSelectedPlayersDisplayEdit();
                }, 500);
              }
            });
            
            playerItem.appendChild(checkbox);
            playerItem.appendChild(label);
            playerItem.appendChild(editBtn);
            playerItem.appendChild(deleteBtn);
            teamDiv.appendChild(playerItem);
          });
          
          playersDropdown.appendChild(teamDiv);
        });
      });
    };
    
    playersSearchInput.addEventListener('focus', () => {
      playersDropdown.style.display = 'block';
      renderEditPlayers(playersSearchInput.value);
    });
    
    playersSearchInput.addEventListener('input', (e) => {
      renderEditPlayers(e.target.value);
    });
    
    playersSearchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!playersDropdown.matches(':hover') && document.activeElement !== playersSearchInput) {
          playersDropdown.style.display = 'none';
        }
      }, 200);
    });
    
    playersDropdown.addEventListener('mouseenter', () => {
      playersDropdown.style.display = 'block';
    });
    
    playersDropdown.addEventListener('mouseleave', () => {
      if (document.activeElement !== playersSearchInput) {
        playersDropdown.style.display = 'none';
      }
    });
    
    // Create player button handler
    addPlayerBtn.addEventListener('click', () => {
      createNewPlayer();
      // Listen for player creation completion
      const checkInterval = setInterval(() => {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          // If players count increased, refresh
          if (players.length > (window.lastPlayerCount || 0)) {
            window.lastPlayerCount = players.length;
            renderEditPlayers(playersSearchInput.value);
            playersDropdown.style.display = 'block';
          }
        });
      }, 500);
      // Stop checking after 30 seconds
      setTimeout(() => clearInterval(checkInterval), 30000);
    });
    
    renderEditPlayers();
    updateSelectedPlayersDisplayEdit();
    
    editPlayersContainer.appendChild(playersLabel);
    editPlayersContainer.appendChild(playerSelectorHeader);
    editPlayersContainer.appendChild(selectedPlayersDisplayEdit);
    editPlayersContainer.appendChild(playersDropdown);
    editContainer.appendChild(editPlayersContainer);
    
    // Intensity selector for editing
    const editIntensityContainer = document.createElement('div');
    editIntensityContainer.className = 'message-edit-intensity';
    editIntensityContainer.style.marginBottom = '4px';
    
    const intensityLabel = document.createElement('label');
    intensityLabel.textContent = 'Intensity:';
    intensityLabel.style.display = 'block';
    intensityLabel.style.fontSize = '12px';
    intensityLabel.style.color = '#8b949e';
    intensityLabel.style.marginBottom = '4px';
    
    const intensityScale = document.createElement('div');
    intensityScale.className = 'message-edit-intensity-scale';
    intensityScale.style.position = 'relative';
    intensityScale.style.width = '100%';
    intensityScale.style.height = '60px';
    
    const intensityTrack = document.createElement('div');
    intensityTrack.className = 'message-edit-intensity-track';
    intensityTrack.style.position = 'relative';
    intensityTrack.style.width = '100%';
    intensityTrack.style.height = '8px';
    intensityTrack.style.background = 'linear-gradient(to right, #1f6feb 0%, #58a6ff 25%, #c9d1d9 50%, #f85149 75%, #da3633 100%)';
    intensityTrack.style.borderRadius = '4px';
    intensityTrack.style.cursor = 'pointer';
    
    const intensitySlider = document.createElement('div');
    intensitySlider.className = 'message-edit-intensity-slider';
    intensitySlider.style.position = 'absolute';
    intensitySlider.style.top = '-6px';
    intensitySlider.style.width = '20px';
    intensitySlider.style.height = '20px';
    intensitySlider.style.background = '#ffffff';
    intensitySlider.style.border = '2px solid #30363d';
    intensitySlider.style.borderRadius = '50%';
    intensitySlider.style.cursor = 'grab';
    intensitySlider.style.transform = 'translateX(-50%)';
    intensitySlider.style.transition = 'border-color 0.15s ease, box-shadow 0.15s ease';
    intensitySlider.style.zIndex = '10';
    intensitySlider.style.userSelect = 'none';
    intensitySlider.style.webkitUserSelect = 'none';
    
    const intensityLabels = document.createElement('div');
    intensityLabels.className = 'message-edit-intensity-labels';
    intensityLabels.style.display = 'flex';
    intensityLabels.style.justifyContent = 'space-between';
    intensityLabels.style.marginTop = '12px';
    
    const labelTexts = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
    labelTexts.forEach((text, index) => {
      const label = document.createElement('span');
      label.textContent = text;
      label.className = 'message-edit-intensity-label-point';
      label.dataset.value = index;
      label.style.fontSize = '11px';
      label.style.color = '#8b949e';
      label.style.cursor = 'pointer';
      label.style.userSelect = 'none';
      label.style.transition = 'color 0.15s ease';
      label.style.flex = '1';
      label.style.textAlign = 'center';
      intensityLabels.appendChild(label);
    });
    
    // Store selected intensity for this edit
    let editSelectedIntensity = noteData && noteData.intensity !== null && noteData.intensity !== undefined ? noteData.intensity : 2; // Default to Balance
    
    const updateIntensitySliderPosition = () => {
      const percentage = (editSelectedIntensity / 4) * 100;
      intensitySlider.style.left = `${percentage}%`;
      
      // Update active label
      intensityLabels.querySelectorAll('.message-edit-intensity-label-point').forEach((label, index) => {
        if (index === editSelectedIntensity) {
          label.style.color = '#ffffff';
          label.style.fontWeight = '600';
        } else {
          label.style.color = '#8b949e';
          label.style.fontWeight = 'normal';
        }
      });
    };
    
    updateIntensitySliderPosition();
    
    // Handle clicks on track
    intensityTrack.addEventListener('click', (e) => {
      // Don't handle click if it was on the slider itself
      if (e.target === intensitySlider || intensitySlider.contains(e.target)) {
        return;
      }
      const rect = intensityTrack.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      editSelectedIntensity = Math.round((percentage / 100) * 4);
      updateIntensitySliderPosition();
    });
    
    // Handle clicks on labels
    intensityLabels.querySelectorAll('.message-edit-intensity-label-point').forEach((label) => {
      label.addEventListener('click', () => {
        editSelectedIntensity = parseInt(label.dataset.value);
        updateIntensitySliderPosition();
      });
    });
    
    // Handle slider drag
    let isDragging = false;
    intensitySlider.addEventListener('mousedown', (e) => {
      isDragging = true;
      e.preventDefault();
      e.stopPropagation();
    });
    
    const handleMouseMove = (e) => {
      if (!isDragging) return;
      const rect = intensityTrack.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      editSelectedIntensity = Math.round((percentage / 100) * 4);
      updateIntensitySliderPosition();
    };
    
    const handleMouseUp = () => {
      isDragging = false;
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    intensityTrack.appendChild(intensitySlider);
    intensityScale.appendChild(intensityTrack);
    intensityScale.appendChild(intensityLabels);
    editIntensityContainer.appendChild(intensityLabel);
    editIntensityContainer.appendChild(intensityScale);
    editContainer.appendChild(editIntensityContainer);
    
    // Create image management section
    const editImagesContainer = document.createElement('div');
    editImagesContainer.className = 'message-edit-images';
    editImagesContainer.style.marginTop = '12px';
    editImagesContainer.style.paddingTop = '12px';
    editImagesContainer.style.borderTop = '1px solid #30363d';
    
    const editImagesHeader = document.createElement('div');
    editImagesHeader.style.display = 'flex';
    editImagesHeader.style.justifyContent = 'space-between';
    editImagesHeader.style.alignItems = 'center';
    editImagesHeader.style.marginBottom = '8px';
    
    const editImagesTitle = document.createElement('span');
    editImagesTitle.textContent = 'Attached Images:';
    editImagesTitle.style.color = '#c9d1d9';
    editImagesTitle.style.fontSize = '13px';
    editImagesTitle.style.fontWeight = '500';
    
    const editImagesActions = document.createElement('div');
    editImagesActions.style.display = 'flex';
    editImagesActions.style.gap = '8px';
    
    const addImageBtn = document.createElement('button');
    addImageBtn.className = 'input-icon-button';
    addImageBtn.title = 'Add image';
    addImageBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
        <circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
    `;
    addImageBtn.addEventListener('click', () => {
      const imageInput = document.getElementById('imageInput');
      if (imageInput) {
        imageInput.click();
        const originalOnChange = imageInput.onchange;
        imageInput.onchange = async (e) => {
          const files = Array.from(e.target.files);
          if (files.length > 0) {
            for (const file of files) {
              await processImageFile(file);
              const newImages = JSON.parse(messageDiv.dataset.editedImages || '[]');
              const lastPendingImage = pendingImages[pendingImages.length - 1];
              // Store image as object to preserve structure
              const imageObj = {
                imageData: lastPendingImage.imageData,
                slidesData: lastPendingImage.slidesData || null,
                originalSrc: lastPendingImage.originalSrc || null
              };
              newImages.push(imageObj);
              messageDiv.dataset.editedImages = JSON.stringify(newImages);
              updateEditImagesDisplay(editImagesList, messageDiv);
            }
            // Clear pending images after adding to edit
            pendingImages = [];
            updateImagePreview();
          }
          e.target.value = '';
          imageInput.onchange = originalOnChange;
        };
      }
    });
    
    const deleteAllImagesBtn = document.createElement('button');
    deleteAllImagesBtn.className = 'input-icon-button';
    deleteAllImagesBtn.title = 'Delete all images';
    deleteAllImagesBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="3 6 5 6 21 6"></polyline>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        <line x1="10" y1="11" x2="10" y2="17"></line>
        <line x1="14" y1="11" x2="14" y2="17"></line>
      </svg>
    `;
    deleteAllImagesBtn.addEventListener('click', () => {
      if (confirm('Delete all images?')) {
        messageDiv.dataset.editedImages = JSON.stringify([]);
        updateEditImagesDisplay(editImagesList, messageDiv);
      }
    });
    
    // Add Tactical Editor Dropdown
    const tacticalEditorDropdownContainer = document.createElement('div');
    tacticalEditorDropdownContainer.className = 'tactical-editor-dropdown-container';
    
    const addTacticalEditorBtn = document.createElement('button');
    addTacticalEditorBtn.className = 'input-icon-button';
    const tacticalEditorTitle = (window.i18n && typeof window.i18n.t === 'function')
      ? window.i18n.t('sidebar.tacticalEditor')
      : 'Tactical editor';
    addTacticalEditorBtn.title = tacticalEditorTitle;
    addTacticalEditorBtn.innerHTML = `
      <img src="icons/football-field 1.svg" width="16" height="16" alt="${tacticalEditorTitle}" style="display: block;">
    `;
    
    const editTacticalEditorDropdown = document.createElement('div');
    editTacticalEditorDropdown.className = 'tactical-editor-dropdown hidden';
    
    const createDropdownItem = (type, label, iconSvg) => {
      const item = document.createElement('button');
      item.className = 'tactical-editor-dropdown-item';
      item.dataset.type = type;
      item.innerHTML = `
        ${iconSvg}
        <span>${label}</span>
      `;
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        let imageUrl;
        switch(type) {
          case 'scheme':
            imageUrl = chrome.runtime.getURL('icons/soccer-145794.svg');
            break;
          case 'goal':
            imageUrl = chrome.runtime.getURL('icons/goal.svg');
            break;
          case 'half':
            imageUrl = chrome.runtime.getURL('icons/Half.svg');
            break;
        }
        if (imageUrl) {
          editTacticalEditorDropdown.classList.add('hidden');
          openImageEditor(imageUrl, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            const newImages = JSON.parse(messageDiv.dataset.editedImages || '[]');
            // Store image as object to preserve structure
            const imageObj = {
              imageData: modifiedImageData,
              slidesData: slidesData || null,
              originalSrc: savedOriginalImageSrc || imageUrl || null
            };
            newImages.push(imageObj);
            messageDiv.dataset.editedImages = JSON.stringify(newImages);
            updateEditImagesDisplay(editImagesList, messageDiv);
          });
        }
      });
      return item;
    };
    
    editTacticalEditorDropdown.appendChild(createDropdownItem('scheme', (window.i18n && typeof window.i18n.t === 'function') ? window.i18n.t('editor.fullField') : 'Full Field', `
      <svg width="16" height="16" viewBox="0 0 512 512" fill="none" stroke="currentColor" stroke-width="42">
        <path d="M496 96H16V416H496V96Z"/>
        <path d="M256 96V416"/>
        <path d="M256 320C291.346 320 320 291.346 320 256C320 220.654 291.346 192 256 192C220.654 192 192 220.654 192 256C192 291.346 220.654 320 256 320Z"/>
        <path d="M112 176H16V336H112V176Z"/>
        <path d="M496 176H400V336H496V176Z"/>
      </svg>
    `));
    editTacticalEditorDropdown.appendChild(createDropdownItem('goal', (window.i18n && typeof window.i18n.t === 'function') ? window.i18n.t('editor.goal') : 'Goal', `
      <svg width="16" height="16" viewBox="0 0 402 274" fill="none" stroke="currentColor" stroke-width="36" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 265V9H393V265"/>
        <path d="M105 9V233" stroke-width="20"/>
        <path d="M201 9V233" stroke-width="20"/>
        <path d="M297 9V233" stroke-width="20"/>
        <path d="M9 73L393 73" stroke-width="20"/>
        <path d="M9 124L393 120" stroke-width="20"/>
        <path d="M9 168L393 174" stroke-width="20"/>
        <path d="M9 217.5H393.001" stroke-width="20"/>
      </svg>
    `));
    editTacticalEditorDropdown.appendChild(createDropdownItem('half', (window.i18n && typeof window.i18n.t === 'function') ? window.i18n.t('editor.halfField') : 'Half Field', `
      <svg width="16" height="16" viewBox="0 0 2594 1930" fill="none" stroke="currentColor" stroke-width="120">
        <rect x="205" y="159" width="2172" height="1678"/>
        <path d="M1583.77 1836.62C1583.77 1759 1552.97 1684.68 1498.15 1629.84C1443.34 1575 1368.99 1544.19 1291.47 1544.19C1213.95 1544.19 1139.6 1575 1084.79 1629.84C1029.97 1684.68 999.174 1759.07 999.174 1836.62"/>
        <rect x="999" y="159" width="582" height="176"/>
        <rect x="647" y="159" width="1285" height="527"/>
        <path d="M1525 686C1497 722 1462 752 1422 772C1381 792 1337 803 1291 803C1246 803 1201 792 1161 772C1120 752 1085 722 1058 686"/>
      </svg>
    `));
    
    addTacticalEditorBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      editTacticalEditorDropdown.classList.toggle('hidden');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!tacticalEditorDropdownContainer.contains(e.target)) {
        editTacticalEditorDropdown.classList.add('hidden');
      }
    });
    
    tacticalEditorDropdownContainer.appendChild(addTacticalEditorBtn);
    tacticalEditorDropdownContainer.appendChild(editTacticalEditorDropdown);
    
    editImagesActions.appendChild(addImageBtn);
    editImagesActions.appendChild(tacticalEditorDropdownContainer);
    if (currentImages.length > 0) {
      editImagesActions.appendChild(deleteAllImagesBtn);
    }
    
    editImagesHeader.appendChild(editImagesTitle);
    editImagesHeader.appendChild(editImagesActions);
    
    const editImagesList = document.createElement('div');
    editImagesList.className = 'message-edit-images-list';
    editImagesList.style.display = 'flex';
    editImagesList.style.flexWrap = 'wrap';
    editImagesList.style.gap = '8px';
    
    // Function to update images display
    function updateEditImagesDisplay(container, msgDiv) {
      container.innerHTML = '';
      // Use getAttribute first, then fall back to dataset property
      const editedImagesRaw = msgDiv.getAttribute('data-edited-images') || msgDiv.dataset.editedImages || '[]';
      const editedImages = JSON.parse(editedImagesRaw);
      console.log('updateEditImagesDisplay: Reading', editedImages.length, 'images from dataset');
      
      if (editedImages.length === 0) {
        deleteAllImagesBtn.style.display = 'none';
      } else {
        deleteAllImagesBtn.style.display = 'block';
      }
      
      editedImages.forEach((imgData, index) => {
        // Extract actual image data - handle both string and object formats
        const actualImageData = typeof imgData === 'object' && imgData !== null ? (imgData.imageData || imgData) : imgData;
        const existingSlidesData = typeof imgData === 'object' && imgData !== null ? imgData.slidesData : null;
        const originalImageSrc = typeof imgData === 'object' && imgData !== null ? imgData.originalSrc : null;
        
        // Skip if no valid image data
        if (!actualImageData || (typeof actualImageData !== 'string')) {
          console.warn('Skipping invalid image data at index', index);
          return;
        }
        
        const imageItem = document.createElement('div');
        imageItem.style.position = 'relative';
        imageItem.style.display = 'inline-block';
        imageItem.style.marginBottom = '8px';
        
        const img = document.createElement('img');
        img.src = actualImageData;
        img.style.maxWidth = '150px';
        img.style.maxHeight = '150px';
        img.style.width = 'auto';
        img.style.height = 'auto';
        img.style.borderRadius = '6px';
        img.style.border = '1px solid #30363d';
        img.style.cursor = 'pointer';
        img.style.display = 'block';
        img.style.objectFit = 'contain';
        img.alt = `Attached image ${index + 1}`;
        
        // Add error handling for failed image loads
        img.onerror = function() {
          console.error('Failed to load image in edit mode:', index);
          this.style.display = 'none';
          const errorDiv = document.createElement('div');
          errorDiv.textContent = 'Failed to load image';
          errorDiv.style.color = '#8b949e';
          errorDiv.style.fontSize = '12px';
          errorDiv.style.padding = '8px';
          errorDiv.style.border = '1px solid #30363d';
          errorDiv.style.borderRadius = '6px';
          errorDiv.style.minWidth = '150px';
          errorDiv.style.minHeight = '150px';
          errorDiv.style.display = 'flex';
          errorDiv.style.alignItems = 'center';
          errorDiv.style.justifyContent = 'center';
          imageItem.appendChild(errorDiv);
        };
        
        // Edit image - use messageDiv from outer scope to ensure correct reference
        // Capture index in closure to ensure correct image is updated
        const imageIndex = index;
        // Capture messageDiv reference to ensure it's available in callback
        const messageDivRef = messageDiv;
        img.addEventListener('click', () => {
          console.log('=== EDIT MODE: Opening image editor for image at index:', imageIndex);
          console.log('messageDivRef:', messageDivRef);
          console.log('Current dataset before opening editor:', messageDivRef.getAttribute('data-edited-images') || messageDivRef.dataset.editedImages || '[]');
          openImageEditor(actualImageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            console.log('=== EDIT MODE: Image editor callback executed!');
            console.log('modifiedImageData length:', modifiedImageData ? modifiedImageData.length : 0);
            if (!modifiedImageData) {
              console.error('Modified image data is null or undefined');
              return;
            }
            // Ensure we're using the correct messageDiv reference
            // Re-read from dataset to get the latest value (in case it was updated elsewhere)
            const currentImagesRaw = messageDivRef.getAttribute('data-edited-images') || messageDivRef.dataset.editedImages || '[]';
            console.log('Reading current images from dataset, raw length:', currentImagesRaw.length);
            const currentImages = JSON.parse(currentImagesRaw);
            console.log('Current images array before update:', currentImages.length, 'items');
            console.log('Updating image at index:', imageIndex);
            console.log('Modified image data length:', modifiedImageData ? modifiedImageData.length : 0);
            if (imageIndex >= 0 && imageIndex < currentImages.length) {
              // Create a new array to ensure the reference is updated
              const updatedImages = [...currentImages];
              // Preserve image object structure if it exists, otherwise create new structure
              const originalImageObj = currentImages[imageIndex];
              if (typeof originalImageObj === 'object' && originalImageObj !== null) {
                // Preserve existing structure and update imageData
                updatedImages[imageIndex] = {
                  ...originalImageObj,
                  imageData: modifiedImageData,
                  slidesData: slidesData || originalImageObj.slidesData || null,
                  originalSrc: savedOriginalImageSrc || originalImageObj.originalSrc || null
                };
              } else {
                // Create new object structure
                updatedImages[imageIndex] = {
                  imageData: modifiedImageData,
                  slidesData: slidesData || null,
                  originalSrc: savedOriginalImageSrc || null
                };
              }
              // Update the dataset - use setAttribute to ensure it's properly set
              const updatedImagesJson = JSON.stringify(updatedImages);
              messageDivRef.setAttribute('data-edited-images', updatedImagesJson);
              // Also update dataset property for compatibility
              messageDivRef.dataset.editedImages = updatedImagesJson;
              console.log('✓ Image edited, updated dataset. New array length:', updatedImages.length);
              console.log('✓ Updated image data length:', updatedImages[imageIndex] ? updatedImages[imageIndex].length : 0);
              // Verify the update by reading back
              const verifyRaw = messageDivRef.getAttribute('data-edited-images') || '[]';
              const verifyImages = JSON.parse(verifyRaw);
              console.log('✓ Verification - dataset now contains:', verifyImages.length, 'images');
              if (verifyImages[imageIndex]) {
                console.log('✓ Verification - updated image length:', verifyImages[imageIndex].length);
                console.log('✓ Verification - images match:', verifyImages[imageIndex].length === modifiedImageData.length);
              }
              updateEditImagesDisplay(editImagesList, messageDivRef);
              
              // Force a visual update to show the change immediately
              console.log('✓ Dataset updated successfully. Current state:');
              console.log('  - Dataset attribute:', messageDivRef.getAttribute('data-edited-images') ? 'SET' : 'NOT SET');
              console.log('  - Dataset property:', messageDivRef.dataset.editedImages ? 'SET' : 'NOT SET');
            } else {
              console.error('✗ Image index out of bounds:', imageIndex, 'array length:', currentImages.length);
            }
          });
        });
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'message-delete-btn';
        deleteBtn.style.position = 'absolute';
        deleteBtn.style.top = '4px';
        deleteBtn.style.right = '4px';
        deleteBtn.innerHTML = '×';
        deleteBtn.title = 'Delete image';
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const imagesRaw = msgDiv.getAttribute('data-edited-images') || msgDiv.dataset.editedImages || '[]';
          const images = JSON.parse(imagesRaw);
          images.splice(index, 1);
          const updatedJson = JSON.stringify(images);
          msgDiv.setAttribute('data-edited-images', updatedJson);
          msgDiv.dataset.editedImages = updatedJson;
          updateEditImagesDisplay(container, msgDiv);
        });
        
        imageItem.appendChild(img);
        imageItem.appendChild(deleteBtn);
        container.appendChild(imageItem);
      });
    }
    
    updateEditImagesDisplay(editImagesList, messageDiv);
    editImagesContainer.appendChild(editImagesHeader);
    editImagesContainer.appendChild(editImagesList);
    editContainer.appendChild(editImagesContainer);
    
    // Create save/cancel buttons
    const editActions = document.createElement('div');
    editActions.className = 'message-edit-actions';
    
    const saveBtn = document.createElement('button');
    saveBtn.className = 'message-save-btn';
    saveBtn.textContent = window.i18n ? window.i18n.t('common.save') : 'Save';
    saveBtn.addEventListener('click', () => {
      const selectedTeam = messageDiv.dataset.editSelectedTeam && messageDiv.dataset.editSelectedTeam.trim() !== '' ? messageDiv.dataset.editSelectedTeam.trim() : null;
      const selectedEvents = editSelectedEvents.length > 0 ? [...editSelectedEvents] : null;
      const selectedZones = editSelectedZones.length > 0 ? [...editSelectedZones] : null;
      
      // Final deduplication of players before saving
      let selectedPlayers = null;
      if (editSelectedPlayers.length > 0) {
        const uniquePlayerRefs = [];
        const seenPlayerRefs = new Set();
        editSelectedPlayers.forEach(ref => {
          if (!seenPlayerRefs.has(ref)) {
            seenPlayerRefs.add(ref);
            uniquePlayerRefs.push(ref);
          }
        });
        selectedPlayers = uniquePlayerRefs;
      }
      
      const selectedIntensity = editSelectedIntensity !== null ? editSelectedIntensity : null;
      console.log('Saving edited message with attributes:', {
        team: selectedTeam,
        events: selectedEvents,
        zones: selectedZones,
        players: selectedPlayers,
        intensity: selectedIntensity,
        eventsCount: editSelectedEvents.length,
        zonesCount: editSelectedZones.length,
        playersCount: editSelectedPlayers.length
      });
      // Read the latest edited images from dataset right before saving
      // Use getAttribute to ensure we get the latest value
      // Try multiple methods to ensure we get the data
      let editedImagesRaw = messageDiv.getAttribute('data-edited-images');
      if (!editedImagesRaw) {
        editedImagesRaw = messageDiv.dataset.editedImages;
      }
      if (!editedImagesRaw) {
        editedImagesRaw = '[]';
      }
      let editedImages;
      try {
        editedImages = JSON.parse(editedImagesRaw);
      } catch (e) {
        console.error('ERROR parsing editedImages:', e);
        editedImages = [];
      }
      
      // Debug: log image count (empty is valid for messages without images)
      if (editedImages.length > 0) {
        console.log('Saving with', editedImages.length, 'images');
      }
      saveEditedMessage(messageDiv, noteData, textarea.value.trim(), textarea, textContainer, selectedTeam, selectedEvents, selectedZones, selectedPlayers, selectedIntensity, editedImages);
    });
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'message-cancel-btn';
    cancelBtn.textContent = window.i18n ? window.i18n.t('common.cancel') : 'Cancel';
    cancelBtn.addEventListener('click', () => {
      isEditingAnyMessage = false;
      console.log('Edit mode cancelled, setting isEditingAnyMessage = false');
      // Remove editing class
      messageDiv.classList.remove('editing');
      // Restore original text container
      parent.replaceChild(textContainer, textarea);
      editContainer.remove();
      editActions.remove();
      // Restore attribute displays
      if (teamElement) teamElement.style.display = '';
      if (eventsElement) eventsElement.style.display = '';
      if (zonesElement) zonesElement.style.display = '';
      if (intensityElement) intensityElement.style.display = '';
      // Restore image displays
      const imageContainers = messageDiv.querySelectorAll('.message-image-container');
      imageContainers.forEach(container => {
        container.style.display = '';
      });
    });
    
    editActions.appendChild(saveBtn);
    editActions.appendChild(cancelBtn);
    
    // Insert edit container and actions
    messageDiv.appendChild(editContainer);
    messageDiv.appendChild(editActions);
    
    // Save on Enter (Ctrl/Cmd+Enter)
    textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        const selectedTeam = messageDiv.dataset.editSelectedTeam && messageDiv.dataset.editSelectedTeam.trim() !== '' ? messageDiv.dataset.editSelectedTeam.trim() : null;
        const selectedEvents = editSelectedEvents.length > 0 ? [...editSelectedEvents] : null;
        const selectedZones = editSelectedZones.length > 0 ? [...editSelectedZones] : null;
        
        // Final deduplication of players before saving
        let selectedPlayers = null;
        if (editSelectedPlayers.length > 0) {
          const uniquePlayerRefs = [];
          const seenPlayerRefs = new Set();
          editSelectedPlayers.forEach(ref => {
            if (!seenPlayerRefs.has(ref)) {
              seenPlayerRefs.add(ref);
              uniquePlayerRefs.push(ref);
            }
          });
          selectedPlayers = uniquePlayerRefs;
        }
        
        const selectedIntensity = editSelectedIntensity !== null ? editSelectedIntensity : null;
        // Read the latest edited images from dataset right before saving
        const editedImagesRaw = messageDiv.dataset.editedImages || '[]';
        const editedImages = JSON.parse(editedImagesRaw);
        console.log('Saving via Enter key with editedImages:', editedImages.length, 'images');
        saveEditedMessage(messageDiv, noteData, textarea.value.trim(), textarea, textContainer, selectedTeam, selectedEvents, selectedZones, selectedPlayers, selectedIntensity, editedImages);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        isEditingAnyMessage = false;
        console.log('Edit mode cancelled (Escape), setting isEditingAnyMessage = false');
        // Remove editing class
        messageDiv.classList.remove('editing');
        parent.replaceChild(textContainer, textarea);
        editContainer.remove();
        editActions.remove();
        // Restore attribute displays
        if (teamElement) teamElement.style.display = '';
        if (eventsElement) eventsElement.style.display = '';
        if (zonesElement) zonesElement.style.display = '';
        if (intensityElement) intensityElement.style.display = '';
        // Restore image displays
        const imageContainers = messageDiv.querySelectorAll('.message-image-container');
        imageContainers.forEach(container => {
          container.style.display = '';
        });
      }
    });
  }

  // Save edited message
  function saveEditedMessage(messageDiv, noteData, newText, textarea, originalContainer, editedTeam = null, editedEvents = null, editedZones = null, editedPlayers = null, editedIntensity = null, editedImages = null) {
    if (!currentAnalysisId || !noteData || !noteData.timestamp) {
      return;
    }
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
      
      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === noteData.timestamp);
        
        if (noteIndex !== -1) {
          const note = analysis.notes[noteIndex];
          
          // Preserve timecode if it exists
          const timecodeMatch = (note.text || note.content || '').match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/);
          const timecode = timecodeMatch ? timecodeMatch[0] : '';
          
          // Check for duplicate text in newText before saving
          let cleanedNewText = newText.trim();
          if (cleanedNewText.length > 0) {
            const messageLength = cleanedNewText.length;
            const halfLength = Math.floor(messageLength / 2);
            const firstHalf = cleanedNewText.substring(0, halfLength);
            const secondHalf = cleanedNewText.substring(halfLength);
            // Check if message is exactly duplicated (first half == second half)
            if (firstHalf === secondHalf && messageLength % 2 === 0) {
              console.warn('Detected duplicated message text when saving in popup, using only first half');
              cleanedNewText = firstHalf;
            }
          }
          
          const updatedText = timecode ? `${timecode} ${cleanedNewText}` : cleanedNewText;
          
          // Update note text and attributes (set both to same value to avoid duplication)
          note.text = updatedText;
          note.content = updatedText;
          
          // Always update attributes when editing (they're always passed from the edit UI)
          if (editedTeam) {
            note.team = editedTeam;
          } else {
            delete note.team;
          }
          
          if (editedEvents && editedEvents.length > 0) {
            note.events = editedEvents;
          } else {
            delete note.events;
          }
          
          if (editedZones && editedZones.length > 0) {
            note.zones = editedZones;
          } else {
            delete note.zones;
          }
          
          // Update players - deduplicate before saving
          if (editedPlayers && editedPlayers.length > 0) {
            const uniquePlayerRefs = [];
            const seenPlayerRefs = new Set();
            editedPlayers.forEach(ref => {
              if (!seenPlayerRefs.has(ref)) {
                seenPlayerRefs.add(ref);
                uniquePlayerRefs.push(ref);
              }
            });
            note.players = uniquePlayerRefs;
          } else {
            delete note.players;
          }
          
          if (editedIntensity !== null && editedIntensity !== undefined) {
            note.intensity = editedIntensity;
          } else {
            delete note.intensity;
          }
          
          // Update images - always update if editedImages is provided (even if empty array)
          if (editedImages !== null) {
            console.log('Updating note images with:', editedImages.length, 'images');
            console.log('editedImages is array?', Array.isArray(editedImages));
            // Deep copy to ensure we're storing the actual data
            if (editedImages.length > 0) {
              note.images = JSON.parse(JSON.stringify(editedImages)); // Deep copy
              // Remove old image property if it exists
              delete note.image;
              console.log('Note images updated. New note.images length:', note.images ? note.images.length : 0);
              console.log('First saved image length:', note.images[0] ? note.images[0].length : 0);
            } else {
              delete note.images;
              delete note.image;
              console.log('All images deleted from note');
            }
          } else {
            console.log('editedImages is null, not updating images');
          }
          
          console.log('Saving edited note with attributes:', {
            timestamp: note.timestamp,
            team: note.team,
            events: note.events,
            zones: note.zones,
            intensity: note.intensity
          });
          
          // CRITICAL: Always preserve videos array before saving
          const videosBeforeSave = analysis.videos ? [...analysis.videos] : null;
          if (analysis && !analysis.videos && (analysis.videoId || analysis.videoUrl)) {
            // Only migrate if videos array doesn't exist - don't overwrite existing videos
            analysis.videos = [{
              videoId: analysis.videoId,
              videoUrl: analysis.videoUrl,
              videoTitle: analysis.videoTitle || 'Video',
              platform: analysis.platform || 'video',
              addedAt: analysis.createdAt || Date.now()
            }];
          } else if (analysis && analysis.videos) {
            // Ensure videos array is not lost - make a defensive copy
            analysis.videos = [...analysis.videos];
          }
          
          console.log('saveEditedMessage: Videos before save:', videosBeforeSave ? videosBeforeSave.length : 'null', 'Videos after preservation:', analysis.videos ? analysis.videos.length : 'null');
          
          chrome.storage.local.set({ analyses: analyses }, (setResult) => {
            if (chrome.runtime.lastError) {
              console.error('Error saving to storage:', chrome.runtime.lastError);
            } else {
              console.log('✓ Storage saved successfully');
              // Verify videos array is preserved
              if (analysis && analysis.videos) {
                console.log('✓ Videos array preserved with', analysis.videos.length, 'videos');
              }
            }
            console.log('Storage saved. Verifying note.images:', note.images ? note.images.length : 0);
            if (note.images && note.images.length > 0) {
              console.log('First image in saved note length:', note.images[0] ? note.images[0].length : 0);
              // Verify the data was actually saved by reading it back
              chrome.storage.local.get(['analyses'], (getResult) => {
                const savedAnalyses = getResult.analyses || [];
                const savedAnalysis = savedAnalyses.find(a => a.id === currentAnalysisId);
                if (savedAnalysis) {
                  const savedNote = savedAnalysis.notes.find(n => n.timestamp === noteData.timestamp);
                  if (savedNote) {
                    console.log('✓ Verification: Saved note has', savedNote.images ? savedNote.images.length : 0, 'images');
                    if (savedNote.images && savedNote.images.length > 0) {
                      console.log('✓ Verification: First saved image length:', savedNote.images[0] ? savedNote.images[0].length : 0);
                    }
                  }
                }
              });
            }
            // Get video info for parsing timecodes
            let videos = [];
            if (analysis.videos && analysis.videos.length > 0) {
              videos = analysis.videos;
            } else if (analysis.videoUrl) {
              videos = [{
                videoId: analysis.videoId,
                videoUrl: analysis.videoUrl,
                videoTitle: analysis.videoTitle || 'Video',
                platform: analysis.platform || 'video',
                addedAt: analysis.createdAt || Date.now()
              }];
            }
            
            // Find note video
            let noteVideo = null;
            if (note.videoId && note.platform) {
              noteVideo = videos.find(v => v.videoId === note.videoId && v.platform === note.platform);
            }
            if (!noteVideo && note.videoUrl) {
              noteVideo = videos.find(v => v.videoUrl === note.videoUrl);
            }
            if (!noteVideo && videos.length === 1) {
              noteVideo = videos[0];
            }
            
            // Remove edit container and actions first
            const editContainer = messageDiv.querySelector('.message-edit-container');
            const editActions = messageDiv.querySelector('.message-edit-actions');
            if (editContainer) editContainer.remove();
            if (editActions) editActions.remove();
            // Remove editing class
            messageDiv.classList.remove('editing');
            // Clear edit mode flag
            isEditingAnyMessage = false;
            console.log('Edit mode ended after save, setting isEditingAnyMessage = false');
            
            // Remove old images before re-rendering
            const oldImageContainers = messageDiv.querySelectorAll('.message-image-container');
            oldImageContainers.forEach(container => container.remove());
            
            // Update display - preserve attributes by re-rendering the entire message
            // Remove old content but keep the message div structure
            const oldTeam = messageDiv.querySelector('.message-team');
            const oldEvents = messageDiv.querySelector('.message-events');
            const oldZones = messageDiv.querySelector('.message-zones');
            
            const parent = textarea.parentNode;
            originalContainer.textContent = '';
            originalContainer.innerHTML = parseTimecodes(updatedText, noteVideo, videos.length, note);
            parent.replaceChild(originalContainer, textarea);
            
            // Re-render message with updated images
            // Use note.images (what was actually saved) instead of editedImages parameter
            const noteImages = note.images || (note.image ? [note.image] : null);
            console.log('Re-rendering with noteImages:', noteImages ? noteImages.length : 0);
            if (noteImages && noteImages.length > 0) {
              const imageArray = Array.isArray(noteImages) ? noteImages : [noteImages];
              imageArray.forEach((imgData, index) => {
                if (!imgData) return;
                
                // Extract image data from stored image object
                const actualImageData = typeof imgData === 'object' ? imgData.imageData : imgData;
                const existingSlidesData = typeof imgData === 'object' ? imgData.slidesData : null;
                const originalImageSrc = typeof imgData === 'object' ? imgData.originalSrc : null;
                
                const imageContainer = document.createElement('div');
                imageContainer.className = 'message-image-container';
                
                const img = document.createElement('img');
                img.src = actualImageData;
                img.alt = `Attached image ${index + 1}`;
                img.className = 'message-image';
                img.style.cursor = 'pointer';
                img.addEventListener('click', () => {
                  openImageEditor(actualImageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
                    const finalOriginalSrc = savedOriginalImageSrc || originalImageSrc;
                    updateImageInNote(note, actualImageData, modifiedImageData, slidesData, finalOriginalSrc);
                  }, existingSlidesData, originalImageSrc);
                });
                img.style.display = 'block';
                img.style.maxWidth = '100%';
                img.style.maxHeight = '300px';
                img.style.width = 'auto';
                img.style.height = 'auto';
                img.style.borderRadius = '8px';
                
                imageContainer.appendChild(img);
                messageDiv.insertBefore(imageContainer, originalContainer.nextSibling);
              });
            }
            
            // Re-add attributes if they exist in the note
            // Remove old attribute elements first
            if (oldTeam) oldTeam.remove();
            if (oldEvents) oldEvents.remove();
            if (oldZones) oldZones.remove();
            
            // Re-add team if present
            if (note.team && typeof note.team === 'string' && note.team.trim() !== '') {
              const teamElement = document.createElement('div');
              teamElement.className = 'message-team';
              teamElement.textContent = `Team: ${note.team}`;
              teamElement.style.color = '#8b949e';
              teamElement.style.fontSize = '12px';
              teamElement.style.marginTop = '4px';
              teamElement.style.marginBottom = '4px';
              originalContainer.parentNode.insertBefore(teamElement, originalContainer.nextSibling);
            }
            
            // Re-add events if present
            if (note.events && Array.isArray(note.events) && note.events.length > 0) {
              const eventsElement = document.createElement('div');
              eventsElement.className = 'message-events';
              eventsElement.style.color = '#8b949e';
              eventsElement.style.fontSize = '12px';
              eventsElement.style.marginTop = '4px';
              eventsElement.style.marginBottom = '4px';
              eventsElement.style.display = 'flex';
              eventsElement.style.flexWrap = 'wrap';
              eventsElement.style.gap = '6px';
              
              const eventsLabel = document.createElement('span');
              eventsLabel.textContent = 'Events: ';
              eventsLabel.style.fontWeight = '500';
              eventsElement.appendChild(eventsLabel);
              
              note.events.forEach((event) => {
                const eventTag = document.createElement('span');
                eventTag.textContent = event;
                eventTag.style.background = '#21262d';
                eventTag.style.border = '1px solid #30363d';
                eventTag.style.borderRadius = '4px';
                eventTag.style.padding = '2px 6px';
                eventsElement.appendChild(eventTag);
              });
              
              const insertAfter = messageDiv.querySelector('.message-team') || originalContainer;
              messageDiv.insertBefore(eventsElement, insertAfter.nextSibling);
            }
            
            // Re-add zones if present
            if (note.zones && Array.isArray(note.zones) && note.zones.length > 0) {
              const zonesElement = document.createElement('div');
              zonesElement.className = 'message-zones';
              zonesElement.style.color = '#8b949e';
              zonesElement.style.fontSize = '12px';
              zonesElement.style.marginTop = '4px';
              zonesElement.style.marginBottom = '4px';
              zonesElement.style.display = 'flex';
              zonesElement.style.flexWrap = 'wrap';
              zonesElement.style.gap = '6px';
              
              const zonesLabel = document.createElement('span');
              zonesLabel.textContent = 'Zones: ';
              zonesLabel.style.fontWeight = '500';
              zonesElement.appendChild(zonesLabel);
              
              const sortedZones = [...note.zones].sort((a, b) => a - b);
              sortedZones.forEach((zone) => {
                const zoneTag = document.createElement('span');
                zoneTag.textContent = `Zone ${zone}`;
                zoneTag.style.background = '#21262d';
                zoneTag.style.border = '1px solid #30363d';
                zoneTag.style.borderRadius = '4px';
                zoneTag.style.padding = '2px 6px';
                zonesElement.appendChild(zoneTag);
              });
              
              const insertAfter = messageDiv.querySelector('.message-events') || messageDiv.querySelector('.message-team') || originalContainer;
              messageDiv.insertBefore(zonesElement, insertAfter.nextSibling);
            }
            
            // Re-attach timecode click handlers
            const timecodeLinks = messageDiv.querySelectorAll('.timecode-link');
            timecodeLinks.forEach(link => {
              link.addEventListener('click', (e) => {
                e.preventDefault();
                const seconds = parseFloat(link.dataset.time);
                const videoUrl = link.dataset.videoUrl;
                const videoId = link.dataset.videoId;
                const videoPlatform = link.dataset.videoPlatform;
                if (videoUrl) {
                  openVideoOrSeek(videoUrl, seconds, null, videoId, videoPlatform);
                }
              });
            });
          });
        }
      }
    });
  }

  // Scroll to the message in chat that contains a specific image
  function scrollToImageInChat(analysis, imageData) {
    if (!analysis || !analysis.notes || !imageData) {
      console.log('Cannot scroll to image: missing analysis, notes, or imageData');
      return;
    }
    
    // Find the note that contains this image
    let targetNote = null;
    for (const note of analysis.notes) {
      // Check note.image
      if (note.image) {
        const noteImgData = typeof note.image === 'object' ? note.image.imageData : note.image;
        if (noteImgData === imageData) {
          targetNote = note;
          break;
        }
      }
      // Check note.images array
      if (note.images && Array.isArray(note.images)) {
        for (const img of note.images) {
          const imgDataStr = typeof img === 'object' ? img.imageData : img;
          if (imgDataStr === imageData) {
            targetNote = note;
            break;
          }
        }
        if (targetNote) break;
      }
    }
    
    if (!targetNote || !targetNote.timestamp) {
      console.log('Could not find note containing this image');
      return;
    }
    
    // Find the message element in chat with this timestamp
    const messageElement = chatMessages.querySelector(`[data-note-timestamp="${targetNote.timestamp}"]`);
    if (messageElement) {
      // Switch to chat tab if not already there
      const chatTab = document.querySelector('[data-tab="chat"]');
      const chatContent = document.getElementById('chatContent');
      if (chatTab && chatContent) {
        // Activate chat tab
        document.querySelectorAll('.tab-button').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        chatTab.classList.add('active');
        chatContent.classList.add('active');
      }
      
      // Scroll to the message
      messageElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      // Highlight the message briefly
      messageElement.style.transition = 'background-color 0.3s ease';
      messageElement.style.backgroundColor = 'rgba(88, 166, 255, 0.3)';
      setTimeout(() => {
        messageElement.style.backgroundColor = '';
        // Remove the transition after animation
        setTimeout(() => {
          messageElement.style.transition = '';
        }, 300);
      }, 1500);
      
      console.log('Scrolled to message with timestamp:', targetNote.timestamp);
    } else {
      console.log('Message element not found for timestamp:', targetNote.timestamp);
    }
  }

  // Update media gallery with images and videos from project
  function updateMediaGallery(analysis) {
    if (!mediaGalleryContent) {
      return;
    }

    mediaGalleryContent.innerHTML = '';

    if (!analysis) {
      mediaGalleryContent.classList.add('has-empty-state');
      const emptyState = document.createElement('div');
      emptyState.className = 'media-gallery-empty';
      emptyState.textContent = 'Select a project to view media';
      mediaGalleryContent.appendChild(emptyState);
      return;
    }

    // Collect all images from notes
    const allImages = [];
    const allVideos = [];

    // Get videos from the project
    if (analysis.videos && analysis.videos.length > 0) {
      allVideos.push(...analysis.videos);
    } else if (analysis.videoUrl) {
      allVideos.push({
        videoId: analysis.videoId,
        videoUrl: analysis.videoUrl,
        videoTitle: analysis.videoTitle || 'Video',
        platform: analysis.platform || 'video',
        addedAt: analysis.createdAt || Date.now()
      });
    }

    // Collect images from all notes
    if (analysis.notes && analysis.notes.length > 0) {
      analysis.notes.forEach(note => {
        const noteImages = note.images || (note.image ? [note.image] : null);
        if (noteImages) {
          const imageArray = Array.isArray(noteImages) ? noteImages : [noteImages];
          imageArray.forEach(imgData => {
            if (imgData) {
              // Handle both string and object formats
              if (typeof imgData === 'string' && 
                  (imgData.startsWith('data:image/') || imgData.startsWith('blob:'))) {
                allImages.push(imgData);
              } else if (typeof imgData === 'object' && imgData.imageData) {
                allImages.push(imgData);
              }
            }
          });
        }
      });
    }

    // If no media, show empty state
    if (allImages.length === 0 && allVideos.length === 0) {
      mediaGalleryContent.classList.add('has-empty-state');
      const emptyState = document.createElement('div');
      emptyState.className = 'media-gallery-empty';
      emptyState.textContent = 'No media in this project yet. Add images to notes or videos to see them here.';
      mediaGalleryContent.appendChild(emptyState);
      return;
    }
    
    // Remove empty state class if we have media
    mediaGalleryContent.classList.remove('has-empty-state');

    // Display videos first
    allVideos.forEach(video => {
      const videoItem = document.createElement('div');
      videoItem.className = 'media-gallery-item video-item';
      
      // Always try to show thumbnail (use fallback if not available)
      // For Twitch, the thumbnail URL might not work (404), so check if it's a Twitch URL
      // and use fallback immediately if it looks like it might fail
      let thumbnailUrl = video.videoThumbnail || getFallbackThumbnail();
      if (video.platform === 'twitch' && video.videoThumbnail && video.videoThumbnail.includes('static-cdn.jtvnw.net')) {
        // For Twitch, we'll try the URL but it might fail, so we're prepared to fallback
        // The error handler will catch it and switch to fallback
      }
      const thumbnailImg = document.createElement('img');
      thumbnailImg.alt = video.videoTitle || 'Video';
      thumbnailImg.className = 'video-thumbnail';
      let thumbnailFailed = false;
      let errorHandlerAttached = false;
      
      // Set up error handler before setting src to catch failures immediately
      thumbnailImg.onerror = function() {
        // Suppress repeated error calls
        if (errorHandlerAttached && thumbnailFailed) {
          return;
        }
        errorHandlerAttached = true;
        
        // If thumbnail fails to load, use fallback thumbnail
        if (!thumbnailFailed && video.videoThumbnail) {
          thumbnailFailed = true;
          // Switch to fallback thumbnail
          this.onerror = null; // Remove handler to prevent infinite loop
          this.src = getFallbackThumbnail();
          // Re-attach handler in case fallback also fails
          this.onerror = function() {
            this.style.display = 'none';
            const fallbackText = document.createElement('div');
            fallbackText.className = 'video-item-fallback';
            fallbackText.textContent = video.videoTitle || 'Video';
            if (!videoItem.querySelector('.video-item-fallback')) {
              videoItem.appendChild(fallbackText);
            }
          };
        } else {
          // Even fallback failed, show text fallback
          this.style.display = 'none';
          const fallbackText = document.createElement('div');
          fallbackText.className = 'video-item-fallback';
          fallbackText.textContent = video.videoTitle || 'Video';
          if (!videoItem.querySelector('.video-item-fallback')) {
            videoItem.appendChild(fallbackText);
          }
        }
      };
      
      // Now set the src (this will trigger loading)
      thumbnailImg.src = thumbnailUrl;
      
      videoItem.appendChild(thumbnailImg);
      
      // Add play icon overlay
      const playIcon = document.createElement('div');
      playIcon.className = 'video-play-icon';
      playIcon.innerHTML = '▶';
      videoItem.appendChild(playIcon);
      
      // Add title overlay
      const titleOverlay = document.createElement('div');
      titleOverlay.className = 'video-title-overlay';
      titleOverlay.textContent = video.videoTitle || 'Video';
      videoItem.appendChild(titleOverlay);
      
      videoItem.title = video.videoTitle || 'Video';
      videoItem.addEventListener('click', () => {
        if (video.videoUrl) {
          openTabAndActivate(video.videoUrl);
        }
      });
      mediaGalleryContent.appendChild(videoItem);
    });

    // Display images
    allImages.forEach((imgData, index) => {
      // Extract image data from stored image object
      const actualImageData = typeof imgData === 'object' ? imgData.imageData : imgData;
      const existingSlidesData = typeof imgData === 'object' ? imgData.slidesData : null;
      const originalImageSrc = typeof imgData === 'object' ? imgData.originalSrc : null;
      
      const imageItem = document.createElement('div');
      imageItem.className = 'media-gallery-item';
      imageItem.style.position = 'relative';
      
      const img = document.createElement('img');
      
      // Use actualImageData directly - it should already be merged with drawings for preview
      // The actualImageData is the merged image (with drawings), originalImageSrc is the clean background for editor
      img.src = actualImageData;
      
      img.style.cursor = 'pointer';
      // Click on image scrolls to the message in chat
      img.addEventListener('click', () => {
        scrollToImageInChat(analysis, actualImageData);
      });
      img.alt = `Image ${index + 1}`;
      img.loading = 'lazy';
      
      // Add error handling
      img.onerror = function() {
        console.error('Failed to load image in gallery:', index);
        this.style.display = 'none';
      };
      
      // Add edit button overlay
      const editBtn = document.createElement('button');
      editBtn.className = 'media-gallery-edit-btn';
      editBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>';
      editBtn.title = 'Edit in Tactical Editor';
      editBtn.style.cssText = 'position: absolute; top: 4px; right: 4px; background: rgba(0,0,0,0.7); border: none; border-radius: 4px; padding: 4px 6px; cursor: pointer; color: white; opacity: 0; transition: opacity 0.2s; z-index: 2;';
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openImageEditor(actualImageData, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
          const finalOriginalSrc = savedOriginalImageSrc || originalImageSrc;
          // Update the image in all notes that contain it
          updateImageInStorage(analysis, actualImageData, modifiedImageData, slidesData, finalOriginalSrc);
        }, existingSlidesData, originalImageSrc);
      });
      
      // Show edit button on hover
      imageItem.addEventListener('mouseenter', () => { editBtn.style.opacity = '1'; });
      imageItem.addEventListener('mouseleave', () => { editBtn.style.opacity = '0'; });
      
      imageItem.appendChild(img);
      imageItem.appendChild(editBtn);
      mediaGalleryContent.appendChild(imageItem);
    });
  }

  // Recover missing videos from notes
  function recoverVideosFromNotes(analysis) {
    if (!analysis || !analysis.notes || analysis.notes.length === 0) {
      return false;
    }

    if (!analysis.videos) {
      analysis.videos = [];
    }

    const existingVideoUrls = new Set(analysis.videos.map(v => v.videoUrl));
    const existingVideoIds = new Set(analysis.videos.map(v => `${v.videoId}_${v.platform}`));
    let recovered = false;

    // Scan notes for video references
    analysis.notes.forEach(note => {
      if (note.videoUrl && !existingVideoUrls.has(note.videoUrl)) {
        // Check if we already have this video by ID+platform
        const videoKey = `${note.videoId}_${note.platform}`;
        if (!existingVideoIds.has(videoKey) && note.videoId && note.platform) {
          // Recover this video
          const recoveredVideo = {
            videoId: note.videoId,
            videoUrl: note.videoUrl,
            videoTitle: note.videoTitle || 'Recovered Video',
            platform: note.platform,
            addedAt: note.timestamp || Date.now()
          };
          analysis.videos.push(recoveredVideo);
          existingVideoUrls.add(note.videoUrl);
          existingVideoIds.add(videoKey);
          recovered = true;
          console.log('Recovered missing video from notes:', recoveredVideo);
        }
      }
    });

    return recovered;
  }

  // Update project video link display
  function updateProjectVideos(analysis) {
    if (!projectVideosSection || !projectVideosList) {
      return;
    }

    if (!analysis) {
      projectVideosSection.style.display = 'none';
      return;
    }

    // Try to recover missing videos from notes
    const recovered = recoverVideosFromNotes(analysis);
    if (recovered) {
      console.log('updateProjectVideos: Recovered videos from notes, saving to storage...');
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const analysisIndex = analyses.findIndex(a => a.id === analysis.id);
        if (analysisIndex !== -1) {
          analyses[analysisIndex] = analysis;
          chrome.storage.local.set({ analyses: analyses }, () => {
            console.log('updateProjectVideos: Saved recovered videos');
          });
        }
      });
    }

    // Get videos from videos array or legacy structure
    let videos = [];
    if (analysis.videos && analysis.videos.length > 0) {
      videos = analysis.videos;
      console.log('updateProjectVideos: Found', videos.length, 'videos in analysis.videos array:');
      videos.forEach((v, idx) => {
        console.log(`  Video ${idx + 1}:`, {
          url: v.videoUrl,
          title: v.videoTitle,
          id: v.videoId,
          platform: v.platform,
          addedAt: v.addedAt
        });
      });
    } else if (analysis.videoUrl) {
      // Migrate legacy structure
      videos = [{
        videoId: analysis.videoId,
        videoUrl: analysis.videoUrl,
        videoTitle: analysis.videoTitle || 'Video',
        platform: analysis.platform || 'video',
        addedAt: analysis.createdAt || Date.now()
      }];
      console.log('updateProjectVideos: Migrated legacy video structure, found 1 video');
    } else {
      // No videos is a valid state (project might be created without videos initially)
      // Initialize empty videos array if it doesn't exist
      if (!analysis.videos) {
        analysis.videos = [];
      }
      // Only log debug info, not a warning
      console.debug('updateProjectVideos: No videos found in analysis', {
        analysisId: analysis?.id || 'unknown',
        hasVideosArray: Array.isArray(analysis.videos),
        videosLength: analysis.videos?.length || 0,
        hasLegacyVideoUrl: !!analysis.videoUrl
      });
    }

    // Always show the section when a project is selected (so user can add videos)
    // Display videos list
    projectVideosList.innerHTML = '';
    console.log('updateProjectVideos: Displaying', videos.length, 'videos');
    
    if (videos.length === 0) {
      // Show empty state but keep section visible so user can add videos
      const emptyState = document.createElement('div');
      emptyState.style.color = '#999';
      emptyState.style.fontStyle = 'italic';
      emptyState.style.padding = '8px';
      emptyState.style.fontSize = '12px';
      emptyState.textContent = 'No videos yet. Click + to add a video.';
      projectVideosList.appendChild(emptyState);
    } else {
      videos.forEach((video) => {
      const videoItem = document.createElement('div');
      videoItem.className = 'project-video-item';
      
      const videoLink = document.createElement('a');
      videoLink.href = video.videoUrl;
      videoLink.className = 'project-video-item-link';
      videoLink.title = video.videoUrl;
      videoLink.style.cursor = 'pointer';
      
      // Add click handler to open video and bring to front
      videoLink.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (video.videoUrl) {
          openTabAndActivate(video.videoUrl);
        }
      });
      
      const videoTitle = document.createElement('span');
      videoTitle.className = 'project-video-item-title';
      videoTitle.textContent = video.videoTitle || 'Video';
      
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'project-video-item-delete';
      deleteBtn.innerHTML = '×';
      deleteBtn.title = 'Remove video from project';
      deleteBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        removeVideoFromProject(video.videoUrl, video.videoId, video.platform);
      });
      
      videoLink.appendChild(videoTitle);
      videoItem.appendChild(videoLink);
      videoItem.appendChild(deleteBtn);
      projectVideosList.appendChild(videoItem);
      });
    }

    projectVideosSection.style.display = 'block';
  }

  // Remove video from project (popup)
  function removeVideoFromProject(videoUrl, videoId, videoPlatform) {
    if (!currentAnalysisId) {
      return;
    }

    const confirmRemove = confirm('Are you sure you want to remove this video from the project?');
    if (!confirmRemove) {
      return;
    }

    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);

      if (analysisIndex === -1) {
        return;
      }

      const analysis = analyses[analysisIndex];
      
      // Initialize videos array if needed
      if (!analysis.videos) {
        if (analysis.videoUrl) {
          analysis.videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
        } else {
          analysis.videos = [];
        }
      }

      // Remove the video
      analysis.videos = analysis.videos.filter(v => 
        !(v.videoUrl === videoUrl || (v.videoId === videoId && v.platform === videoPlatform))
      );

      // Update legacy fields if videos array is not empty
      if (analysis.videos.length > 0) {
        const firstVideo = analysis.videos[0];
        analysis.videoId = firstVideo.videoId;
        analysis.videoUrl = firstVideo.videoUrl;
        analysis.platform = firstVideo.platform;
        analysis.videoTitle = firstVideo.videoTitle;
      } else {
        // No videos left
        analysis.videoId = null;
        analysis.videoUrl = null;
        analysis.platform = null;
        analysis.videoTitle = null;
      }

      chrome.storage.local.set({ analyses: analyses }, () => {
        // Refresh displays
        updateProjectVideos(analysis);
        updateMediaGallery(analysis);
        switchToAnalysis(currentAnalysisId);
      });
    });
  }

  function renameCurrentAnalysis() {
    if (!currentAnalysisId) return;
    
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (analysis) {
        const newName = prompt('Enter new name:', analysis.name);
        
        if (newName && newName.trim() !== '' && newName.trim() !== analysis.name) {
          analysis.name = newName.trim();
          chrome.storage.local.set({ analyses: analyses }, () => {
            updateAnalysisSelect(analyses, currentAnalysisId);
          });
        }
      }
    });
  }

  function deleteCurrentAnalysis() {
    if (!currentAnalysisId) return;
    
    // Confirm deletion
    const confirmDelete = confirm('Are you sure you want to delete this project? This action cannot be undone.');
    if (!confirmDelete) {
      return;
    }
    
    chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
      const analyses = result.analyses || [];
      const projectToDelete = analyses.find(a => a.id === currentAnalysisId);
      
      if (!projectToDelete) {
        console.warn('Project not found:', currentAnalysisId);
        return;
      }
      
      // Remove the project from analyses
      const updatedAnalyses = analyses.filter(a => a.id !== currentAnalysisId);
      
      // Determine what to set as currentAnalysisId
      let newCurrentAnalysisId = null;
      
      // If there are other projects, use the most recent one
      if (updatedAnalyses.length > 0) {
        const sortedAnalyses = [...updatedAnalyses].sort((a, b) => 
          (b.createdAt || 0) - (a.createdAt || 0)
        );
        newCurrentAnalysisId = sortedAnalyses[0].id;
      }
      
      // Update storage
      chrome.storage.local.set({
        analyses: updatedAnalyses,
        currentAnalysisId: newCurrentAnalysisId
      }, () => {
        // Update local state
        currentAnalysisId = newCurrentAnalysisId;
        
        // Refresh displays
        if (newCurrentAnalysisId) {
          updateAnalysisSelect(updatedAnalyses, newCurrentAnalysisId);
          switchToAnalysis(newCurrentAnalysisId);
        } else {
          // No projects left
          currentAnalysisId = null;
          if (projectButtonText) {
            projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
          }
          const noProjectMsg = window.i18n ? window.i18n.t('project.clickToCreateFirst') : 'Click + to create your first analysis';
          chatMessages.innerHTML = `<div style="text-align: center; color: #999; padding: 40px;">${noProjectMsg}</div>`;
          if (projectVideosSection) {
            projectVideosSection.style.display = 'none';
          }
          const exportProjectDropdownItem = document.getElementById('exportProjectDropdownItem');
          if (exportProjectDropdownItem) {
            exportProjectDropdownItem.style.display = 'none';
          }
          const exportNotesDropdownItem = document.getElementById('exportNotesDropdownItem');
          if (exportNotesDropdownItem) {
            exportNotesDropdownItem.style.display = 'none';
          }
        }
        
        console.log('Project deleted:', projectToDelete.name);
      });
    });
  }

  function updateAnalysisSelect(analyses, selectedId) {
    if (!projectButtonText) return;
    
    // Update button text based on selected project
    if (!analyses || analyses.length === 0) {
      projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
      if (projectButton) {
        projectButton.style.display = '';
      }
      return;
    }
    
    // Find selected analysis
    const selectedAnalysis = analyses.find(a => a.id === selectedId);
    if (selectedAnalysis) {
      projectButtonText.textContent = selectedAnalysis.name;
    } else {
      projectButtonText.textContent = window.i18n ? window.i18n.t('project.selectProject') : 'Select project';
    }
    
    if (projectButton) {
      projectButton.style.display = '';
    }
  }

  function sendMessage() {
    let message = chatInput.value.trim();
    
    // Check if message contains HTML content marker
    let isHtmlContent = false;
    const htmlMatch = message.match(/\[HTML_CONTENT\](.*?)\[\/HTML_CONTENT\]/s);
    if (htmlMatch) {
      message = htmlMatch[1]; // Extract HTML content
      isHtmlContent = true;
    }
    
    if (message || pendingImages.length > 0) {
      const imagesToSave = pendingImages.length > 0 ? [...pendingImages] : null; // Copy array
      
      // Get selected events
      const eventsToSave = selectedEvents.length > 0 ? [...selectedEvents] : null;
      
      // Get selected zones
      const zonesToSave = selectedZones.length > 0 ? [...selectedZones] : null;
      
      // Get selected players
      const playersToSave = selectedPlayers.length > 0 ? [...selectedPlayers] : null;
      
      // Get selected intensity
      const intensityToSave = selectedIntensity !== null ? selectedIntensity : null;
      
      // Collect all teams: manually selected teams + teams from players
      const processMessage = () => {
        chrome.storage.local.get(['players'], (result) => {
          const players = result.players || [];
          const selectedPlayerObjects = playersToSave ? players.filter(p => playersToSave.includes(p.id)) : [];
          const teamsFromPlayers = [...new Set(selectedPlayerObjects.map(p => p.team).filter(t => t && t.trim() !== ''))];
          
          // Combine all teams
          const allTeams = new Set();
          if (selectedTeam) allTeams.add(selectedTeam);
          selectedTeams.forEach(team => allTeams.add(team));
          teamsFromPlayers.forEach(team => allTeams.add(team));
          
          const teamsToSave = allTeams.size > 0 ? Array.from(allTeams) : null;
          
          // Create timestamp once so it matches between display and save
          const messageTimestamp = Date.now();
          
          // Create temporary noteData with timestamp and attributes for immediate display
          // This ensures edit/delete buttons show immediately
          const tempNoteData = {
            timestamp: messageTimestamp, // Add timestamp so edit/delete buttons show
            isHtmlContent: isHtmlContent // Mark as HTML content
          };
          if (teamsToSave && teamsToSave.length > 0) tempNoteData.teams = teamsToSave;
          if (eventsToSave && eventsToSave.length > 0) tempNoteData.events = eventsToSave;
          if (zonesToSave && zonesToSave.length > 0) tempNoteData.zones = zonesToSave;
          if (playersToSave && playersToSave.length > 0) tempNoteData.players = playersToSave;
          if (intensityToSave !== null) tempNoteData.intensity = intensityToSave;
          
          addMessage(message, null, 1, tempNoteData, imagesToSave);
          chatInput.value = '';
          // Reset textarea height after clearing
          if (chatInput) {
            autoResizeTextarea(chatInput);
          }
          
          // Clear selected events, zones, players, teams, and intensity after getting values
          selectedEvents = [];
          selectedZones = [];
          selectedPlayers = [];
          selectedTeams = [];
          selectedIntensity = null;
          updateSelectedEventsDisplay();
          updateSelectedZonesDisplay();
          updateSelectedPlayersDisplay();
          updateIntensitySlider(2); // Reset to Balance (middle)
          if (zonesSearchInput) zonesSearchInput.value = '';
          if (zonesSelectorDropdown) zonesSelectorDropdown.style.display = 'none';
          if (eventSearchInput) eventSearchInput.value = '';
          if (eventSelectorDropdown) eventSelectorDropdown.style.display = 'none';
          
          // Save to storage with the same timestamp and attributes
          // Pass isHtmlContent flag through a closure or modify saveMessage signature
          // For now, we'll store it in a global or pass it differently
          // Actually, let's modify saveMessage to accept an optional parameter for HTML content
          const messageToSave = isHtmlContent ? `[HTML_CONTENT]${message}[/HTML_CONTENT]` : message;
          saveMessage(messageToSave, imagesToSave, messageTimestamp, teamsToSave, eventsToSave, zonesToSave, playersToSave, intensityToSave, () => {
            // After save completes, clear pending images and preview
            hideImagePreview();
          });
        });
      };
      
      processMessage();
    }
  }

  function addMessage(message, noteVideo = null, totalVideos = 1, noteData = null, imageData = null) {
    // Safety check: ensure message or image is valid
    const hasMessage = message && typeof message === 'string' && message.trim().length > 0;
    const images = imageData || (noteData && noteData.images) || (noteData && noteData.image ? [noteData.image] : null);
    const hasImages = images && (Array.isArray(images) ? images.length > 0 : (images ? true : false));
    
    console.log('addMessage called:', { hasMessage, hasImages, imageDataLength: imageData ? (Array.isArray(imageData) ? imageData.length : 1) : 0, imagesLength: images ? (Array.isArray(images) ? images.length : 1) : 0 });
    
    if (!hasMessage && !hasImages) {
      console.warn('addMessage called with no message or image');
      return;
    }
    
    // Check if message with this timestamp already exists to prevent duplicates
    if (noteData && noteData.timestamp) {
      const existingMessage = chatMessages.querySelector(`[data-note-timestamp="${noteData.timestamp}"]`);
      if (existingMessage) {
        console.log('Message with timestamp already exists, skipping duplicate:', noteData.timestamp);
        return;
      }
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message';
    
    // Store note timestamp for identification (for edit/delete)
    if (noteData && noteData.timestamp) {
      messageDiv.dataset.noteTimestamp = noteData.timestamp;
    }
    
    // Ensure messageDiv has display and visibility
    messageDiv.style.display = 'block';
    messageDiv.style.visibility = 'visible';
    
    let htmlContent = '';
    
    // Check if this is HTML content (from AI Analysis)
    const isHtmlContent = noteData && noteData.isHtmlContent;
    
    // Parse message and make timecodes clickable, passing video info and note data
    if (hasMessage) {
      if (isHtmlContent) {
        // For HTML content, render directly as HTML
        // Still need to escape any potential XSS, but trust the content since it's from our AI analysis
        htmlContent = message;
      } else {
        // Regular text message - check for duplicate text in the message itself
        // If message appears to be duplicated (same text twice), use only one copy
        const trimmedMessage = message.trim();
        const messageLength = trimmedMessage.length;
        if (messageLength > 0) {
          const halfLength = Math.floor(messageLength / 2);
          const firstHalf = trimmedMessage.substring(0, halfLength);
          const secondHalf = trimmedMessage.substring(halfLength);
          // Check if message is exactly duplicated (first half == second half)
          if (firstHalf === secondHalf && messageLength % 2 === 0) {
            console.warn('Detected duplicated message text, using only first half');
            message = firstHalf;
          }
        }
        
        // Parse timecodes
        const parsedMessage = parseTimecodes(message, noteVideo, totalVideos, noteData);
        htmlContent += parsedMessage;
      }
    }
    
    // Set innerHTML only if there's message content
    // If there's no message but there are images, we'll add images directly to messageDiv
    if (htmlContent) {
      messageDiv.innerHTML = htmlContent;
      
      // Re-attach citation link click handlers if this is HTML content with citations
      if (isHtmlContent) {
        messageDiv.querySelectorAll('.ai-citation-link').forEach(link => {
          link.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            const blockId = link.dataset.blockId;
            const items = JSON.parse(link.dataset.items);
            const blockElement = document.getElementById(blockId);
            
            if (blockElement) {
              await toggleCitationBlock(link, blockElement, items);
            } else {
              console.warn('Citation block not found:', blockId);
            }
          });
        });
      }
    } else if (!hasImages) {
      // If no message and no images, add empty content to ensure messageDiv is visible
      messageDiv.innerHTML = '<div></div>';
    }
    
    // Add images if present (after setting innerHTML to avoid issues with long base64 strings)
    if (hasImages) {
      const imageArray = Array.isArray(images) ? images : [images];
      console.log('Processing images:', imageArray.length, 'images');
      imageArray.forEach((imgData, index) => {
        if (!imgData) {
          console.warn('Skipping empty image at index', index);
          return; // Skip invalid image data
        }

        // Handle both legacy string format and new object format
        let actualImageData = imgData;
        let storedSlidesData = null;
        let originalImageSrc = null;
        if (typeof imgData === 'object' && imgData.imageData) {
          actualImageData = imgData.imageData;
          storedSlidesData = imgData.slidesData || null;
          originalImageSrc = imgData.originalSrc || null;
        }

        console.log('Processing image', index, 'of', imageArray.length, 'Type:', typeof actualImageData, 'Length:', actualImageData ? actualImageData.length : 0);

        // Validate image data format
        const isValidDataUrl = typeof actualImageData === 'string' &&
          (actualImageData.startsWith('data:image/') || actualImageData.startsWith('blob:'));
        
        if (!isValidDataUrl) {
          console.warn('Invalid image data format at index', index, 'Type:', typeof actualImageData, 'Length:', actualImageData ? actualImageData.length : 0);
          // Try to fix if it's a base64 string without data URL prefix
          if (typeof actualImageData === 'string' && actualImageData.length > 100) {
            // Assume it's a JPEG if no prefix
            actualImageData = 'data:image/jpeg;base64,' + actualImageData;
          } else {
            return; // Skip invalid data
          }
        }
        
        const imageContainer = document.createElement('div');
        imageContainer.className = 'message-image-container';
        
        const img = document.createElement('img');
        
        // Use actualImageData directly - it should already be merged with drawings for preview
        // The actualImageData is the merged image (with drawings), originalImageSrc is the clean background for editor
        img.src = actualImageData;
        
        console.log('addMessage: Using merged imageData for preview, length:', actualImageData ? actualImageData.length : 0);
        img.alt = `Attached image ${index + 1}`;
        img.className = 'message-image';
        img.style.cursor = 'pointer';

        img.addEventListener('click', () => {
          // Try to find existing slidesData and originalSrc for this image
          let existingSlidesData = storedSlidesData;
          let originalImageSrc = null;
          console.log('Opening editor for image:', {
            hasStoredSlidesData: !!storedSlidesData,
            storedSlidesDataLength: storedSlidesData ? storedSlidesData.length : 0,
            hasOriginalImageSrc: !!originalImageSrc,
            imageDataType: typeof actualImageData,
            imageDataLength: actualImageData ? actualImageData.length : 0
          });
          if (noteData && noteData.images) {
            const noteImageArray = Array.isArray(noteData.images) ? noteData.images : [noteData.images];
            const existingImage = noteImageArray.find(noteImg => {
              const noteImgData = typeof noteImg === 'object' ? noteImg.imageData : noteImg;
              const noteOriginalSrc = typeof noteImg === 'object' ? noteImg.originalSrc : null;
              return noteImgData === actualImageData || (noteOriginalSrc && noteOriginalSrc === actualImageData);
            });
            if (existingImage && typeof existingImage === 'object') {
              if (existingImage.slidesData) {
                existingSlidesData = existingImage.slidesData;
              }
              // Get originalSrc if available (the original background before any drawings were merged)
              if (existingImage.originalSrc) {
                originalImageSrc = existingImage.originalSrc;
              }
            }
          }

          // When opening editor with slidesData, use originalImageSrc if available (for clean background)
          // Otherwise use actualImageData (merged image) but editor will handle it
          const imageToOpen = (existingSlidesData && originalImageSrc) ? originalImageSrc : actualImageData;
          console.log('Opening editor with:', {
            usingOriginal: !!(existingSlidesData && originalImageSrc),
            hasSlidesData: !!existingSlidesData,
            slidesDataLength: existingSlidesData ? existingSlidesData.length : 0,
            hasOriginalSrc: !!originalImageSrc
          });
          
          openImageEditor(imageToOpen, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            // Use the originalImageSrc from the save if available, otherwise use the one we found
            const finalOriginalSrc = savedOriginalImageSrc || originalImageSrc;
            // Update the image in storage
            if (noteData) {
              updateImageInNote(noteData, actualImageData, modifiedImageData, slidesData, finalOriginalSrc);
            } else {
              // For new messages, update in current analysis
              chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
                const analyses = result.analyses || [];
                const currentAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
                if (currentAnalysis) {
                  // Find the original imgData to update
                  const originalImgData = typeof imgData === 'object' ? imgData.imageData : imgData;
                  updateImageInStorage(currentAnalysis, originalImgData, modifiedImageData, slidesData, finalOriginalSrc);
                }
              });
            }
          }, existingSlidesData, originalImageSrc);
        });
        img.style.display = 'block';
        img.style.maxWidth = '100%';
        img.style.maxHeight = '300px';
        img.style.width = 'auto';
        img.style.height = 'auto';
        img.style.borderRadius = '8px';
        img.style.cursor = 'pointer';
        
        // Add error handling
        img.onerror = function() {
          console.error('Failed to load image:', index, 'Data length:', imgData ? imgData.length : 0, 'Starts with:', imgData ? imgData.substring(0, 50) : 'null');
          this.style.display = 'none';
          const errorDiv = document.createElement('div');
          errorDiv.textContent = 'Failed to load image';
          errorDiv.style.color = '#999';
          errorDiv.style.fontSize = '12px';
          errorDiv.style.padding = '8px';
          imageContainer.appendChild(errorDiv);
        };
        
        // Add load handler for debugging
        img.onload = function() {
          console.log('Image loaded successfully:', index);
        };
        
        // Click handler removed - images now open in Tactical Editor via img click handler above
        
        imageContainer.appendChild(img);
        // Always append images to messageDiv (they'll appear before text if text exists)
        messageDiv.appendChild(imageContainer);
      });
      
      console.log('Added', imageArray.length, 'images to message');
      console.log('MessageDiv children after adding images:', messageDiv.children.length);
      console.log('MessageDiv innerHTML length:', messageDiv.innerHTML.length);
    }
    
    // Add click handlers to timecode links
    const timecodeLinks = messageDiv.querySelectorAll('.timecode-link');
    timecodeLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const seconds = parseFloat(link.dataset.time);
        const videoUrl = link.dataset.videoUrl;
        const videoId = link.dataset.videoId;
        const videoPlatform = link.dataset.videoPlatform;
        
        // Use the video from the link if available
        if (videoUrl) {
          // Check if tab exists and seek, or open new tab
          // Pass videoId and platform for more accurate matching
          openVideoOrSeek(videoUrl, seconds, null, videoId, videoPlatform);
        } else {
          // Fallback: try to get video from current analysis
          if (!currentAnalysisId) {
            console.warn('No current analysis ID, cannot open video');
            return;
          }
          
          chrome.storage.local.get(['analyses'], (result) => {
            const analyses = result.analyses || [];
            const analysis = analyses.find(a => a.id === currentAnalysisId);
            
            if (!analysis || !analysis.videoUrl) {
              console.warn('No video URL found for current analysis');
              return;
            }
            
            // Check if tab exists and seek, or open new tab
            const videoUrl = analysis.videoUrl;
            openVideoOrSeek(videoUrl, seconds, null, analysis.videoId, analysis.platform);
          });
        }
      });
    });
    
    // Add team information if present
    if (noteData && noteData.team && typeof noteData.team === 'string' && noteData.team.trim() !== '') {
      const teamElement = document.createElement('div');
      teamElement.className = 'message-team';
      teamElement.textContent = `Team: ${noteData.team}`;
      teamElement.style.color = '#8b949e';
      teamElement.style.fontSize = '12px';
      teamElement.style.marginTop = '4px';
      teamElement.style.marginBottom = '4px';
      messageDiv.appendChild(teamElement);
    }

    // Add video information if present
    if (noteVideo && noteVideo.videoTitle) {
      const videoElement = document.createElement('div');
      videoElement.className = 'message-video';
      const maxTitleLength = 40;
      const truncatedTitle = noteVideo.videoTitle.length > maxTitleLength 
        ? noteVideo.videoTitle.substring(0, maxTitleLength) + '...' 
        : noteVideo.videoTitle;
      videoElement.textContent = `Video: ${truncatedTitle}`;
      videoElement.style.color = '#6e7681';
      videoElement.style.fontSize = '11px';
      videoElement.style.marginTop = '4px';
      videoElement.style.marginBottom = '4px';
      videoElement.style.fontStyle = 'italic';
      messageDiv.appendChild(videoElement);
    } else if (noteData && noteData.videoTitle) {
      // Fallback: use videoTitle from note if available
      const videoElement = document.createElement('div');
      videoElement.className = 'message-video';
      const maxTitleLength = 40;
      const truncatedTitle = noteData.videoTitle.length > maxTitleLength 
        ? noteData.videoTitle.substring(0, maxTitleLength) + '...' 
        : noteData.videoTitle;
      videoElement.textContent = `Video: ${truncatedTitle}`;
      videoElement.style.color = '#6e7681';
      videoElement.style.fontSize = '11px';
      videoElement.style.marginTop = '4px';
      videoElement.style.marginBottom = '4px';
      videoElement.style.fontStyle = 'italic';
      messageDiv.appendChild(videoElement);
    }

    // Add players information if present
    if (noteData && noteData.players && Array.isArray(noteData.players) && noteData.players.length > 0) {
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const selectedPlayerObjects = [];
        const playerNames = [];
        
        // Handle both IDs and names (for backward compatibility and AI extraction)
        noteData.players.forEach(playerRef => {
          // Check if it's an ID (starts with 'player_')
          if (typeof playerRef === 'string' && playerRef.startsWith('player_')) {
            const player = players.find(p => p.id === playerRef);
            if (player) {
              selectedPlayerObjects.push(player);
            }
          } else if (typeof playerRef === 'string') {
            // It's a name string - try to find by name
            const playerNameLower = playerRef.toLowerCase().trim();
            const player = players.find(p => {
              const fullName = (p.fullName || '').toLowerCase();
              const name = (p.name || '').toLowerCase();
              const surname = (p.surname || '').toLowerCase();
              return fullName === playerNameLower || 
                     name === playerNameLower || 
                     surname === playerNameLower ||
                     fullName.includes(playerNameLower) ||
                     playerNameLower.includes(fullName);
            });
            if (player) {
              selectedPlayerObjects.push(player);
            } else {
              // If not found, use the name as-is (fallback)
              playerNames.push(playerRef);
            }
          }
        });
        
        if (selectedPlayerObjects.length > 0 || playerNames.length > 0) {
          const playersElement = document.createElement('div');
          playersElement.className = 'message-players';
          playersElement.style.color = '#8b949e';
          playersElement.style.fontSize = '12px';
          playersElement.style.marginTop = '4px';
          playersElement.style.marginBottom = '4px';
          playersElement.style.display = 'flex';
          playersElement.style.flexWrap = 'wrap';
          playersElement.style.gap = '6px';
          
          const playersLabel = document.createElement('span');
          playersLabel.textContent = 'Players: ';
          playersLabel.style.fontWeight = '500';
          playersElement.appendChild(playersLabel);
          
          // Display matched players
          selectedPlayerObjects.forEach((player, index) => {
            const playerTag = document.createElement('span');
            const displayText = player.number ? 
              `#${player.number} ${player.fullName || ''}`.trim() : 
              (player.fullName || 'Unnamed');
            playerTag.textContent = displayText;
            playerTag.style.background = '#21262d';
            playerTag.style.padding = '2px 6px';
            playerTag.style.borderRadius = '4px';
            playersElement.appendChild(playerTag);
          });
          
          // Display unmatched player names (fallback)
          playerNames.forEach((playerName, index) => {
            const playerTag = document.createElement('span');
            playerTag.textContent = playerName;
            playerTag.style.background = '#21262d';
            playerTag.style.padding = '2px 6px';
            playerTag.style.borderRadius = '4px';
            playersElement.appendChild(playerTag);
          });
          
          messageDiv.appendChild(playersElement);
        }
      });
    }

    // Add events information if present
    if (noteData && noteData.events && Array.isArray(noteData.events) && noteData.events.length > 0) {
      const eventsElement = document.createElement('div');
      eventsElement.className = 'message-events';
      eventsElement.style.color = '#8b949e';
      eventsElement.style.fontSize = '12px';
      eventsElement.style.marginTop = '4px';
      eventsElement.style.marginBottom = '4px';
      eventsElement.style.display = 'flex';
      eventsElement.style.flexWrap = 'wrap';
      eventsElement.style.gap = '6px';
      
      const eventsLabel = document.createElement('span');
      eventsLabel.textContent = 'Events: ';
      eventsLabel.style.fontWeight = '500';
      eventsElement.appendChild(eventsLabel);
      
      noteData.events.forEach((event, index) => {
        const eventTag = document.createElement('span');
        eventTag.textContent = event;
        eventTag.style.background = '#21262d';
        eventTag.style.border = '1px solid #30363d';
        eventTag.style.borderRadius = '4px';
        eventTag.style.padding = '2px 6px';
        eventsElement.appendChild(eventTag);
        
        if (index < noteData.events.length - 1) {
          // Add comma except for last item
        }
      });
      
      messageDiv.appendChild(eventsElement);
    }

    // Add zones information if present
    if (noteData && noteData.zones && Array.isArray(noteData.zones) && noteData.zones.length > 0) {
      const zonesElement = document.createElement('div');
      zonesElement.className = 'message-zones';
      zonesElement.style.color = '#8b949e';
      zonesElement.style.fontSize = '12px';
      zonesElement.style.marginTop = '4px';
      zonesElement.style.marginBottom = '4px';
      zonesElement.style.display = 'flex';
      zonesElement.style.flexWrap = 'wrap';
      zonesElement.style.gap = '6px';
      
      const zonesLabel = document.createElement('span');
      zonesLabel.textContent = 'Zones: ';
      zonesLabel.style.fontWeight = '500';
      zonesElement.appendChild(zonesLabel);
      
      // Sort zones numerically
      const sortedZones = [...noteData.zones].sort((a, b) => a - b);
      
      sortedZones.forEach((zone) => {
        const zoneTag = document.createElement('span');
        zoneTag.textContent = `Zone ${zone}`;
        zoneTag.style.background = '#21262d';
        zoneTag.style.border = '1px solid #30363d';
        zoneTag.style.borderRadius = '4px';
        zoneTag.style.padding = '2px 6px';
        zonesElement.appendChild(zoneTag);
      });
      
      messageDiv.appendChild(zonesElement);
    }

    // Add intensity information if present
    if (noteData && noteData.intensity !== null && noteData.intensity !== undefined) {
      const intensityElement = document.createElement('div');
      intensityElement.className = 'message-intensity';
      intensityElement.style.color = '#8b949e';
      intensityElement.style.fontSize = '12px';
      intensityElement.style.marginTop = '4px';
      intensityElement.style.marginBottom = '4px';
      intensityElement.style.display = 'flex';
      intensityElement.style.alignItems = 'center';
      intensityElement.style.gap = '8px';
      
      const intensityLabel = document.createElement('span');
      intensityLabel.textContent = 'Intensity: ';
      intensityLabel.style.fontWeight = '500';
      intensityElement.appendChild(intensityLabel);
      
      const intensityValue = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'][noteData.intensity] || 'Unknown';
      const intensityTag = document.createElement('span');
      intensityTag.textContent = intensityValue;
      
      // Color based on intensity value
      const colors = ['#1f6feb', '#58a6ff', '#c9d1d9', '#f85149', '#da3633'];
      intensityTag.style.background = colors[noteData.intensity] || '#21262d';
      intensityTag.style.border = '1px solid #30363d';
      intensityTag.style.borderRadius = '4px';
      intensityTag.style.padding = '2px 6px';
      intensityTag.style.color = '#ffffff';
      intensityElement.appendChild(intensityTag);
      
      messageDiv.appendChild(intensityElement);
    }
    
    // Add message actions (edit/delete buttons) - only if noteData exists (not for new messages being sent)
    if (noteData && noteData.timestamp) {
      const messageActions = document.createElement('div');
      messageActions.className = 'message-actions';
      
      // Mark checkbox for enhancement - always visible on the right side
      const markCheckboxContainer = document.createElement('div');
      markCheckboxContainer.className = 'message-mark-checkbox-container';
      
      const markCheckbox = document.createElement('input');
      markCheckbox.type = 'checkbox';
      markCheckbox.className = 'message-mark-checkbox';
      markCheckbox.dataset.noteTimestamp = noteData.timestamp;
      markCheckbox.title = 'Mark for enhancement';
      
      markCheckboxContainer.appendChild(markCheckbox);
      messageActions.appendChild(markCheckboxContainer);
      
      // Edit button
      const editBtn = document.createElement('button');
      editBtn.className = 'message-edit-btn';
      editBtn.innerHTML = '✎';
      editBtn.title = 'Edit message';
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        editMessage(messageDiv, noteData);
      });
      
      // Delete button
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'message-delete-btn';
      deleteBtn.innerHTML = '×';
      deleteBtn.title = 'Delete message';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteMessage(messageDiv, noteData);
      });
      
      messageActions.appendChild(editBtn);
      messageActions.appendChild(deleteBtn);
      messageDiv.appendChild(messageActions);
    }
    
    // Debug: Check messageDiv structure before appending
    console.log('Before appending - messageDiv children:', messageDiv.children.length);
    console.log('Before appending - messageDiv has images:', messageDiv.querySelectorAll('.message-image-container').length);
    console.log('Before appending - messageDiv innerHTML preview:', messageDiv.innerHTML.substring(0, 200));
    
    chatMessages.appendChild(messageDiv);
    
    // Debug: Check after appending
    const imageCount = messageDiv.querySelectorAll('.message-image-container').length;
    const allImages = messageDiv.querySelectorAll('.message-image');
    console.log('After appending - Image containers found:', imageCount);
    console.log('After appending - Image elements found:', allImages.length);
    allImages.forEach((img, idx) => {
      console.log(`Image ${idx}: src length=${img.src.length}, display=${window.getComputedStyle(img).display}, width=${img.width}, height=${img.height}`);
    });
    
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function formatTimecode(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    } else {
      return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
  }

  function parseTimecode(timecodeStr) {
    // Parse timecode format [HH:MM:SS] or [MM:SS]
    const match = timecodeStr.match(/\[(\d{1,2}):(\d{2}):(\d{2})\]|\[(\d{1,2}):(\d{2})\]/);
    if (match) {
      if (match[1]) {
        // HH:MM:SS format
        const hours = parseInt(match[1]);
        const minutes = parseInt(match[2]);
        const seconds = parseInt(match[3]);
        return hours * 3600 + minutes * 60 + seconds;
      } else if (match[4]) {
        // MM:SS format
        const minutes = parseInt(match[4]);
        const seconds = parseInt(match[5]);
        return minutes * 60 + seconds;
      }
    }
    return null;
  }

  function parseTimecodes(text, noteVideo = null, totalVideos = 1, noteData = null) {
    // Safety check: ensure text is a string
    if (!text || typeof text !== 'string') {
      return '';
    }
    
    // Replace [HH:MM:SS] or [MM:SS] patterns with clickable links
    const timecodeRegex = /\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/g;
    return text.replace(timecodeRegex, (match) => {
      const seconds = parseTimecode(match);
      if (seconds !== null) {
        // Show video title if note belongs to a specific video
        let timecodeDisplay = match;
        let dataAttributes = `data-time="${seconds}"`;
        
        // Use noteVideo if available and has title, otherwise try to get video info from noteData
        let videoToUse = noteVideo;
        
        // If noteVideo exists but doesn't have videoTitle, or if noteVideo is null, check noteData
        if (!videoToUse || !videoToUse.videoTitle) {
          if (noteData) {
            // If noteData has videoTitle stored directly, use it (this is the most reliable)
            if (noteData.videoTitle) {
              videoToUse = {
                videoUrl: noteData.videoUrl || (videoToUse && videoToUse.videoUrl),
                videoId: noteData.videoId || (videoToUse && videoToUse.videoId),
                platform: noteData.platform || (videoToUse && videoToUse.platform),
                videoTitle: noteData.videoTitle
              };
            } else if (noteData.videoId && noteData.platform) {
              // Fallback: construct minimal video object
              videoToUse = {
                videoUrl: noteData.videoUrl || (videoToUse && videoToUse.videoUrl),
                videoId: noteData.videoId,
                platform: noteData.platform,
                videoTitle: `Video ${noteData.videoId}` // Fallback title with ID
              };
            } else if (noteData.videoUrl || noteData.videoId) {
              videoToUse = {
                videoUrl: noteData.videoUrl || (videoToUse && videoToUse.videoUrl),
                videoId: noteData.videoId || (videoToUse && videoToUse.videoId),
                platform: noteData.platform || (videoToUse && videoToUse.platform),
                videoTitle: 'Video' // Fallback title
              };
            }
          }
        }
        
        // Add video information to data attributes (but don't show in timecode display)
        if (videoToUse) {
          if (videoToUse.videoUrl) {
            dataAttributes += ` data-video-url="${videoToUse.videoUrl}"`;
          }
          if (videoToUse.videoId) {
            dataAttributes += ` data-video-id="${videoToUse.videoId}"`;
          }
          if (videoToUse.platform) {
            dataAttributes += ` data-video-platform="${videoToUse.platform}"`;
          }
        } else if (noteData && (noteData.videoId || noteData.videoUrl)) {
          if (noteData.videoUrl) {
            dataAttributes += ` data-video-url="${noteData.videoUrl}"`;
          }
          if (noteData.videoId) {
            dataAttributes += ` data-video-id="${noteData.videoId}"`;
          }
          if (noteData.platform) {
            dataAttributes += ` data-video-platform="${noteData.platform}"`;
          }
        }
        
        return `<a href="#" class="timecode-link" ${dataAttributes} title="${videoToUse && videoToUse.videoTitle ? `Open ${videoToUse.videoTitle} at ${match}` : noteData && noteData.videoId ? `Jump to ${match} (Video: ${noteData.videoId})` : `Jump to ${match}`}">${timecodeDisplay}</a>`;
      }
      return match;
    });
  }

  function saveMessage(message, imageData = null, timestamp = null, teamsToSave = null, eventsToSave = null, zonesToSave = null, playersToSave = null, intensityToSave = null, callback = null) {
    if (!currentAnalysisId) {
      // If no analysis exists, create one
      createNewAnalysis();
      setTimeout(() => saveMessage(message, imageData, timestamp, teamsToSave, eventsToSave, zonesToSave, playersToSave, intensityToSave, callback), 100);
      return;
    }
    
    isSavingMessage = true; // Set flag to prevent focus event from clearing chat
    chrome.storage.local.get(['analyses'], (result) => {
      const analyses = result.analyses || [];
      const analysisIndex = analyses.findIndex(a => a.id === currentAnalysisId);
      
      if (analysisIndex !== -1) {
        const analysis = analyses[analysisIndex];
        
        // Try to determine which video this note belongs to
        // Get videos from the project
        let videos = [];
        if (analysis.videos && analysis.videos.length > 0) {
          videos = analysis.videos;
        } else if (analysis.videoUrl) {
          videos = [{
            videoId: analysis.videoId,
            videoUrl: analysis.videoUrl,
            videoTitle: analysis.videoTitle || 'Video',
            platform: analysis.platform || 'video',
            addedAt: analysis.createdAt || Date.now()
          }];
        }
        
        // Extract timecode from message to determine if it's a video note
        const timecodeMatch = message && message.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/);
        const hasTimecode = !!timecodeMatch;
        let noteVideo = null;
        
        // Function to continue with note saving once we know which video
        const continueNoteSaving = (selectedVideo) => {
          // Check if message contains HTML content marker
          let actualMessage = message || '';
          let isHtmlContent = false;
          const htmlMatch = actualMessage.match(/\[HTML_CONTENT\](.*?)\[\/HTML_CONTENT\]/s);
          if (htmlMatch) {
            actualMessage = htmlMatch[1]; // Extract HTML content
            isHtmlContent = true;
          }
          
          const noteData = {
            text: actualMessage || '',
            content: actualMessage || '',  // Also save as content for sidebar compatibility
            timestamp: timestamp || Date.now(), // Use provided timestamp or create new one
            isHtmlContent: isHtmlContent // Preserve HTML content flag
          };
          
          // Add attributes if they were provided (passed as parameters to saveMessage)
          if (teamsToSave && teamsToSave.length > 0) {
            noteData.teams = teamsToSave;
            // Keep single team for backward compatibility (use first team)
            noteData.team = teamsToSave[0];
          }
          if (eventsToSave && eventsToSave.length > 0) {
            noteData.events = eventsToSave;
          }
          if (zonesToSave && zonesToSave.length > 0) {
            noteData.zones = zonesToSave;
          }
          if (playersToSave && playersToSave.length > 0) {
            noteData.players = playersToSave;
          }
          if (intensityToSave !== null && intensityToSave !== undefined) {
            noteData.intensity = intensityToSave;
          }
          
          console.log('Saving note with attributes:', {
            timestamp: noteData.timestamp,
            teams: noteData.teams,
            team: noteData.team,
            events: noteData.events,
            zones: noteData.zones,
            intensity: noteData.intensity
          });
          
          // Associate note with video if we found one
          if (selectedVideo) {
            noteData.videoUrl = selectedVideo.videoUrl;
            noteData.videoId = selectedVideo.videoId;
            noteData.platform = selectedVideo.platform;
            noteData.videoTitle = selectedVideo.videoTitle || 'Video';
            console.log('Associating note with video:', selectedVideo.videoTitle);
          }
          
          // Add images if present (store as array)
          if (imageData) {
            if (Array.isArray(imageData)) {
            // Validate all images before storing
            const validImages = imageData.filter(img => {
              if (!img) return false;

              // Handle both legacy string format and new object format
              const imgString = typeof img === 'object' && img.imageData ? img.imageData : img;

              const isValid = typeof imgString === 'string' &&
                (imgString.startsWith('data:image/') || imgString.startsWith('blob:'));
              if (!isValid) {
                console.warn('Skipping invalid image data:', typeof imgString, imgString ? imgString.substring(0, 50) : 'null');
              }
              return isValid;
            });
            
            if (validImages.length > 0) {
              // Preserve full object structure (with slidesData) or use strings directly
              const imagesToStore = validImages.map(img => {
                if (typeof img === 'object' && img.imageData) {
                  // Preserve the full object with slidesData
                  return {
                    imageData: img.imageData,
                    slidesData: img.slidesData || null,
                    originalSrc: img.originalSrc || img.imageData
                  };
                }
                // String format - return as is
                return img;
              });
              noteData.images = imagesToStore;
              // Also keep single image for backward compatibility (extract imageData for legacy)
              noteData.image = typeof imagesToStore[0] === 'object' ? imagesToStore[0].imageData : imagesToStore[0];
            } else {
              console.error('No valid images to store');
            }
          } else {
            // Legacy single image format
            const isValid = typeof imageData === 'string' && 
              (imageData.startsWith('data:image/') || imageData.startsWith('blob:'));
            if (isValid) {
              noteData.image = imageData;
              noteData.images = [imageData];
            } else {
              console.error('Invalid single image data format');
            }
          }
        }
        
        console.log('Saving note with attributes:', { 
          timestamp: noteData.timestamp, 
          hasTeam: !!noteData.team, 
          team: noteData.team,
          hasEvents: !!(noteData.events && noteData.events.length > 0), 
          events: noteData.events,
          hasZones: !!(noteData.zones && noteData.zones.length > 0),
          zones: noteData.zones,
          fullNoteData: JSON.parse(JSON.stringify(noteData)) // Deep copy for logging
        });
        analyses[analysisIndex].notes.push(noteData);
        chrome.storage.local.set({ analyses: analyses }, () => {
          // Call callback if provided
          if (callback) {
            callback();
          }
          // Update media gallery if images were added
          if (imageData) {
            updateMediaGallery(analysis);
          }
          // Set flag to false after a delay to prevent storage.onChanged from reloading
          // This prevents duplicate messages when we save
          setTimeout(() => {
            isSavingMessage = false; // Clear flag after save completes
          }, 500); // Increased delay to ensure storage.onChanged doesn't trigger reload
          // Don't call switchToAnalysis here - it will clear the chat
          // The message is already displayed via addMessage, and storage.onChanged will sync
        });
        };
        
        // Determine which video this note belongs to
        // Only associate with video if note has a timecode (indicating it's from a video)
        if (!hasTimecode) {
          // No timecode - this is a general note from popup, not from a video page
          continueNoteSaving(null);
        } else if (videos.length === 1) {
          // Single video - associate note with it
          continueNoteSaving(videos[0]);
        } else if (videos.length > 1) {
          // Multiple videos - try to find which video tab is currently active
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs.length > 0) {
              const activeTab = tabs[0];
              const activeTabUrl = activeTab.url;
              
              // Normalize URL for comparison
              const normalizeUrl = (url) => {
                try {
                  const urlObj = new URL(url);
                  urlObj.hash = '';
                  urlObj.searchParams.delete('t');
                  urlObj.searchParams.delete('start');
                  return urlObj.toString();
                } catch {
                  return url.split('#')[0].split('?')[0];
                }
              };
              
              const normalizedActiveUrl = normalizeUrl(activeTabUrl);
              
              // Try to find matching video
              const matchingVideo = videos.find(v => {
                if (!v || !v.videoUrl) return false;
                const normalizedVideoUrl = normalizeUrl(v.videoUrl);
                return normalizedVideoUrl === normalizedActiveUrl || 
                       normalizedActiveUrl.includes(normalizedVideoUrl) ||
                       normalizedVideoUrl.includes(normalizedActiveUrl);
              });
              
              if (matchingVideo) {
                console.log('Found active video tab matching:', matchingVideo.videoTitle);
                continueNoteSaving(matchingVideo);
              } else {
                console.log('No matching video found for active tab:', activeTabUrl);
                // Fallback: use first video if no match found
                continueNoteSaving(videos[0]);
              }
            } else {
              // No active tab found, use first video as fallback
              continueNoteSaving(videos[0]);
            }
          });
        } else {
          // No videos in project, save note without video association
          continueNoteSaving(null);
        }
      }
    });
  }

  // Initialize - load analyses and current analysis
  chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
    const analyses = result.analyses || [];
    const currentId = result.currentAnalysisId;
    
    if (analyses.length > 0) {
      updateAnalysisSelect(analyses, currentId || analyses[0].id);
      switchToAnalysis(currentId || analyses[0].id);
    } else {
      // No analyses yet - user needs to create one
      if (projectButtonText) {
        projectButtonText.textContent = window.i18n ? window.i18n.t('project.noProject') : 'No project';
      }
      const noProjectMsg = window.i18n ? window.i18n.t('project.clickToCreateFirst') : 'Click + to create your first analysis';
      chatMessages.innerHTML = `<div style="text-align: center; color: #999; padding: 40px;">${noProjectMsg}</div>`;
      const exportProjectDropdownItem = document.getElementById('exportProjectDropdownItem');
      if (exportProjectDropdownItem) {
        exportProjectDropdownItem.style.display = 'none';
      }
      const exportNotesDropdownItem = document.getElementById('exportNotesDropdownItem');
      if (exportNotesDropdownItem) {
        exportNotesDropdownItem.style.display = 'none';
      }
    }
  });

  // Listen for storage changes to refresh notes when they're updated in sidebar
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      // Don't refresh if we're currently saving a message (prevents clearing chat)
      if (isSavingMessage) {
        console.log('Skipping storage.onChanged refresh - message save in progress');
        return;
      }
      // Don't refresh if we're currently creating an analysis (prevents blinking/looping)
      if (isCreatingAnalysis) {
        console.log('Skipping storage.onChanged refresh - analysis creation in progress');
        return;
      }
      // Refresh when analyses change (notes added/updated)
      if (changes.analyses && currentAnalysisId) {
        // Only refresh if the change came from another source (like sidebar)
        // If we just saved, the message is already displayed, so don't reload
        console.log('Storage changed - refreshing analysis. Changes:', changes.analyses);
        // Refresh the current analysis to show updated notes immediately
      switchToAnalysis(currentAnalysisId);
      // Also update the analysis select dropdown
      chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
        const analyses = result.analyses || [];
        const currentId = result.currentAnalysisId;
        updateAnalysisSelect(analyses, currentId || analyses[0]?.id);
      });
      }
      
      // Refresh when currentAnalysisId changes
      if (changes.currentAnalysisId && changes.currentAnalysisId.newValue) {
        // Don't refresh if we're currently saving a message or creating an analysis
        if (!isSavingMessage && !isCreatingAnalysis) {
          switchToAnalysis(changes.currentAnalysisId.newValue);
        }
      }
    }
  });

  // Track if any message is currently being edited
  let isEditingAnyMessage = false;
  
  // Refresh notes when popup window gets focus (user opens/clicks on popup)
  window.addEventListener('focus', () => {
    console.log('Popup window focused, refreshing notes');
    // Don't refresh if we're currently saving a message or editing a message
    if (isSavingMessage) {
      console.log('Skipping refresh - message save in progress');
      return;
    }
    if (isEditingAnyMessage) {
      console.log('Skipping refresh - message edit in progress');
      return;
    }
    if (currentAnalysisId) {
      switchToAnalysis(currentAnalysisId);
    } else {
      // Reload current analysis from storage
      chrome.storage.local.get(['currentAnalysisId', 'analyses'], (result) => {
        const currentId = result.currentAnalysisId;
        if (currentId) {
          currentAnalysisId = currentId;
          switchToAnalysis(currentId);
        }
      });
    }
  });

  // Also refresh when popup becomes visible (handles cases where focus doesn't fire)
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && currentAnalysisId) {
      console.log('Popup became visible, refreshing notes');
      switchToAnalysis(currentAnalysisId);
    }
  });

  // Image Editor Functions
  function openImageEditor(imageSrc, saveCallback, slidesData = null, originalImageSrc = null) {
    // Extract imageSrc string if it's an object
    let actualImageSrc = imageSrc;
    if (typeof imageSrc === 'object' && imageSrc !== null) {
      actualImageSrc = imageSrc.imageData || imageSrc;
    }
    // Ensure it's a string
    if (typeof actualImageSrc !== 'string') {
      console.error('openImageEditor: imageSrc must be a string, got:', typeof actualImageSrc);
      return;
    }
    
    // Store image data and callback in chrome.storage for reliable access
    const editorDataId = 'editor_' + Date.now();
    console.log('openImageEditor called with callbackId:', editorDataId, 'slidesData:', !!slidesData, 'originalImageSrc:', !!originalImageSrc);
    const storageData = {
      pendingEditorImageSrc: actualImageSrc, // Use the extracted string
      pendingEditorCallbackId: editorDataId,
      pendingEditorCallbackContext: 'popup', // Mark that callback is in popup
      pendingEditorSlidesData: slidesData, // Always set, even if null
      pendingEditorOriginalImageSrc: originalImageSrc || null // Store original image source if available
    };
    chrome.storage.local.set(storageData, () => {
      // Store callback reference (we'll retrieve it by ID)
      window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};
      window.pendingEditorCallbacks[editorDataId] = saveCallback;
      console.log('Callback stored. Total callbacks:', Object.keys(window.pendingEditorCallbacks).length);
      console.log('Callback IDs:', Object.keys(window.pendingEditorCallbacks));
      
      // Open editor in a new window
      const editorUrl = chrome.runtime.getURL('editor.html');
      chrome.windows.create({
        url: editorUrl,
        type: 'popup',
        width: 1200,
        height: 800,
        focused: true
      }, (createdWindow) => {
        if (chrome.runtime.lastError) {
          console.error('Error opening editor window:', chrome.runtime.lastError);
          // Fallback: try window.open
          const newWindow = window.open(editorUrl, 'tacticalEditor', 'width=1200,height=800');
          if (!newWindow) {
            alert('Please allow popups to open the editor');
          }
        } else {
          console.log('Editor window opened successfully');
        }
      });
    });
  }

  function updateImageInStorage(analysis, oldImageData, newImageData, newSlidesData = null, originalImageSrc = null) {
    if (!analysis || !analysis.notes) return;
    
    // Update all notes that contain this image
    let updated = false;
    analysis.notes.forEach(note => {
      const noteImages = note.images || (note.image ? [note.image] : null);
      if (noteImages) {
        const imageArray = Array.isArray(noteImages) ? noteImages : [noteImages];
        const updatedImages = imageArray.map(img => {
          // Handle both string images and object images
          const imgData = typeof img === 'object' ? img.imageData : img;
          if (imgData === oldImageData) {
            updated = true;
            // Use the provided originalImageSrc if available, otherwise preserve existing originalSrc, or use oldImageData as fallback
            const existingOriginalSrc = typeof img === 'object' ? img.originalSrc : null;
            // Return object with imageData, slidesData, and originalSrc
            return { imageData: newImageData, slidesData: newSlidesData, originalSrc: originalImageSrc || existingOriginalSrc || oldImageData };
          }
          return img;
        });
        
        if (updated) {
          if (Array.isArray(noteImages)) {
            note.images = updatedImages;
          } else {
            note.image = updatedImages[0];
          }
        }
      }
    });
    
    if (updated) {
      // Save updated analysis
      chrome.storage.local.get(['analyses'], (result) => {
        const analyses = result.analyses || [];
        const index = analyses.findIndex(a => a.id === analysis.id);
        if (index !== -1) {
          analyses[index] = analysis;
          chrome.storage.local.set({ analyses }, () => {
            // Refresh UI
            switchToAnalysis(analysis.id);
            // Notify sidebar to refresh
            chrome.runtime.sendMessage({ action: 'imageEditorSaved' }).catch(() => {
              // Ignore errors if no listeners
            });
          });
        }
      });
    }
  }

  function updateImageInNote(noteData, oldImageData, newImageData, newSlidesData = null, originalImageSrc = null) {
    if (!noteData || !noteData.timestamp) return;
    
    chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === result.currentAnalysisId);
      if (!analysis || !analysis.notes) return;
      
      const note = analysis.notes.find(n => n.timestamp === noteData.timestamp);
      if (!note) return;
      
      const noteImages = note.images || (note.image ? [note.image] : null);
      if (noteImages) {
        const imageArray = Array.isArray(noteImages) ? noteImages : [noteImages];
        const updatedImages = imageArray.map(img => {
          // Check if this is the image we're updating
          const imgData = typeof img === 'object' ? img.imageData : img;
          if (imgData === oldImageData) {
            // Use the provided originalImageSrc if available, otherwise preserve existing originalSrc, or use oldImageData as fallback
            const existingOriginalSrc = typeof img === 'object' ? img.originalSrc : null;
            // Return object with imageData, slidesData, and originalSrc
            return { imageData: newImageData, slidesData: newSlidesData, originalSrc: originalImageSrc || existingOriginalSrc || oldImageData };
          }
          return img;
        });
        
        if (Array.isArray(noteImages)) {
          note.images = updatedImages;
        } else {
          note.image = updatedImages[0];
        }
        
        // Save updated analysis
        const index = analyses.findIndex(a => a.id === analysis.id);
        if (index !== -1) {
          analyses[index] = analysis;
          chrome.storage.local.set({ analyses }, () => {
            // Refresh UI
            switchToAnalysis(analysis.id);
            // Notify sidebar to refresh
            chrome.runtime.sendMessage({ action: 'imageEditorSaved' }).catch(() => {
              // Ignore errors if no listeners
            });
          });
        }
      }
    });
  }

  console.log('Popup: Setting up message listeners');

  // Listen for editor open requests from sidebar
  function processEditorSavedPayload(payload) {
    if (!payload) return false;
    const { callbackContext, callbackId, imageData, originalImageSrc, slidesData } = payload;

    if (callbackContext === 'sidebar') {
      return false; // let sidebar handle it
    }

    window.pendingEditorCallbacks = window.pendingEditorCallbacks || {};

    if (callbackId && window.pendingEditorCallbacks[callbackId]) {
      const callback = window.pendingEditorCallbacks[callbackId];
      console.log('✓ Popup: Executing callback from storage payload:', callbackId);
      console.log('✓ Popup: Callback data:', {
        hasImageData: !!imageData,
        hasSlidesData: !!slidesData,
        slidesDataLength: slidesData ? slidesData.length : 0,
        firstSlideDrawings: slidesData && slidesData[0] ? (slidesData[0].drawings ? slidesData[0].drawings.length : 0) : 0,
        hasOriginalSrc: !!originalImageSrc
      });
      delete window.pendingEditorCallbacks[callbackId];
      try {
        callback(imageData, slidesData, originalImageSrc);
        console.log('✓ Popup: Callback executed successfully from storage payload');
      } catch (error) {
        console.error('✗ Popup: Error executing callback from storage payload:', error);
      }
    } else if (originalImageSrc) {
      // Callback not found (likely popup was closed/reopened), but we can still update via fallback
      console.log('ℹ Popup: Callback not found for ID (popup may have been reopened), using fallback update:', callbackId);
      chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
        const analyses = result.analyses || [];
        const currentAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
        if (currentAnalysis) {
          // Pass slidesData to preserve editable drawings
          updateImageInStorage(currentAnalysis, originalImageSrc, imageData, slidesData, originalImageSrc);
          console.log('✓ Popup: Image updated via fallback mechanism with slidesData:', slidesData ? slidesData.length : 0, 'slides');
        } else {
          console.warn('⚠ Popup: Could not find current analysis for fallback update');
        }
      });
    } else {
      // No callback and no originalImageSrc - orphaned save, likely from direct editor access
      console.log('ℹ Popup: Editor saved without context (orphaned save). Cleaning up storage.');
    }

    chrome.storage.local.remove(['editorSavedPayload', 'pendingEditorImageSrc', 'pendingEditorCallbackId', 'pendingEditorCallbackContext', 'pendingEditorSlidesData']);
    return true;
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes.editorSavedPayload && changes.editorSavedPayload.newValue) {
      processEditorSavedPayload(changes.editorSavedPayload.newValue);
    }
  });

  chrome.storage.local.get(['editorSavedPayload'], (result) => {
    if (result.editorSavedPayload) {
      processEditorSavedPayload(result.editorSavedPayload);
    }
  });

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request || !request.action) return false;

    if (request.action === 'openImageEditor') {
      // Find the note if timestamp is provided
      let noteData = null;
      if (request.noteTimestamp) {
        chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
          const analyses = result.analyses || [];
          const analysis = analyses.find(a => a.id === result.currentAnalysisId);
          if (analysis && analysis.notes) {
            noteData = analysis.notes.find(n => n.timestamp === request.noteTimestamp);
          }
          
          // Try to find existing slidesData for this image
          const imageSrcStr = typeof request.imageSrc === 'string' ? request.imageSrc : (request.imageSrc?.imageData || '');
          console.log('Popup: Looking for existing slidesData for image:', imageSrcStr ? (imageSrcStr.substring(0, 100) + '...') : 'no image src');
          // Prioritize slidesData from request (sent from sidebar), then try to find in stored note
          let existingSlidesData = request.slidesData || null;
          // Only look in note if slidesData wasn't provided in request
          if (!existingSlidesData && noteData && noteData.images) {
            const imageArray = Array.isArray(noteData.images) ? noteData.images : [noteData.images];
            const existingImage = imageArray.find(img => {
              // Check both current imageData and originalSrc
              const imgData = typeof img === 'object' ? img.imageData : img;
              const originalSrc = typeof img === 'object' ? img.originalSrc : null;
              const matches = imgData === imageSrcStr || (originalSrc && originalSrc === imageSrcStr);
              console.log('Popup: Comparing request.imageSrc with stored image:');
              console.log('  - request starts with:', typeof imageSrcStr === 'string' ? imageSrcStr.substring(0, 50) : 'not a string');
              console.log('  - stored imgData starts with:', typeof imgData === 'string' ? imgData.substring(0, 50) : 'not a string');
              console.log('  - stored originalSrc starts with:', typeof originalSrc === 'string' ? originalSrc.substring(0, 50) : 'not a string');
              console.log('  - matches:', matches);
              return matches;
            });
            if (existingImage && typeof existingImage === 'object' && existingImage.slidesData) {
              existingSlidesData = existingImage.slidesData;
              console.log('Popup: Found existing slidesData in note:', existingSlidesData);
            } else {
              console.log('Popup: No slidesData found in note for this image');
            }
          } else if (!existingSlidesData && result.analyses && result.currentAnalysisId) {
            const currentAnalysis = result.analyses.find(a => a.id === result.currentAnalysisId);
            if (currentAnalysis && currentAnalysis.notes) {
              for (const note of currentAnalysis.notes) {
                const imageArray = Array.isArray(note.images) ? note.images : [note.images];
                const existingImage = imageArray.find(img => {
                  // Check both current imageData and originalSrc
                  const imgData = typeof img === 'object' ? img.imageData : img;
                  const originalSrc = typeof img === 'object' ? img.originalSrc : null;
                  const matches = imgData === imageSrcStr || (originalSrc && originalSrc === imageSrcStr);
                  console.log('Popup: Comparing request.imageSrc with stored image (analysis):');
                  console.log('  - request starts with:', typeof imageSrcStr === 'string' ? imageSrcStr.substring(0, 50) : 'not a string');
                  console.log('  - stored imgData starts with:', typeof imgData === 'string' ? imgData.substring(0, 50) : 'not a string');
                  console.log('  - stored originalSrc starts with:', typeof originalSrc === 'string' ? originalSrc.substring(0, 50) : 'not a string');
                  console.log('  - matches:', matches);
                  return matches;
                });
                if (existingImage && typeof existingImage === 'object' && existingImage.slidesData) {
                  existingSlidesData = existingImage.slidesData;
                  break;
                }
              }
            }
          }

          // Extract originalSrc from existing image if available
          let originalImageSrc = request.originalImageSrc || null;
          if (noteData && noteData.images) {
            const imageArray = Array.isArray(noteData.images) ? noteData.images : [noteData.images];
            const existingImage = imageArray.find(img => {
              const imgData = typeof img === 'object' ? img.imageData : img;
              return imgData === imageSrcStr;
            });
            if (existingImage && typeof existingImage === 'object' && existingImage.originalSrc) {
              originalImageSrc = existingImage.originalSrc;
            }
          }

          openImageEditor(imageSrcStr, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            const finalOriginalSrc = savedOriginalImageSrc || originalImageSrc;
            if (noteData) {
              updateImageInNote(noteData, imageSrcStr, modifiedImageData, slidesData, finalOriginalSrc);
            } else {
              // Update in current analysis
              chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
                const analyses = result.analyses || [];
                const currentAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
                if (currentAnalysis) {
                  updateImageInStorage(currentAnalysis, imageSrcStr, modifiedImageData, slidesData, finalOriginalSrc);
                }
              });
            }
          }, existingSlidesData, originalImageSrc);
        });
      } else {
        // Try to find existing slidesData for this image
        chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
          const analyses = result.analyses || [];
          const currentAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
          let existingSlidesData = request.slidesData || null;
          const imageSrcStr = typeof request.imageSrc === 'string' ? request.imageSrc : (request.imageSrc?.imageData || '');

          // Only look in notes if slidesData wasn't provided in request
          if (!existingSlidesData && currentAnalysis && currentAnalysis.notes) {
            for (const note of currentAnalysis.notes) {
              const imageArray = Array.isArray(note.images) ? note.images : [note.images];
              const existingImage = imageArray.find(img => {
                // Check both current imageData and originalSrc
                const imgData = typeof img === 'object' ? img.imageData : img;
                const originalSrc = typeof img === 'object' ? img.originalSrc : null;
                const matches = imgData === imageSrcStr || (originalSrc && originalSrc === imageSrcStr);
                console.log('Popup: Comparing request.imageSrc with stored image (else branch):');
                console.log('  - request starts with:', typeof imageSrcStr === 'string' ? imageSrcStr.substring(0, 50) : 'not a string');
                console.log('  - stored imgData starts with:', typeof imgData === 'string' ? imgData.substring(0, 50) : 'not a string');
                console.log('  - stored originalSrc starts with:', typeof originalSrc === 'string' ? originalSrc.substring(0, 50) : 'not a string');
                console.log('  - matches:', matches);
                return matches;
              });
              if (existingImage && typeof existingImage === 'object' && existingImage.slidesData) {
                existingSlidesData = existingImage.slidesData;
                break;
              }
            }
          }

          // Extract originalSrc from existing image if available
          let originalImageSrc = request.originalImageSrc || null;
          if (currentAnalysis && currentAnalysis.notes) {
            for (const note of currentAnalysis.notes) {
              const imageArray = Array.isArray(note.images) ? note.images : [note.images];
              const existingImage = imageArray.find(img => {
                const imgData = typeof img === 'object' ? img.imageData : img;
                return imgData === imageSrcStr;
              });
              if (existingImage && typeof existingImage === 'object' && existingImage.originalSrc) {
                originalImageSrc = existingImage.originalSrc;
                break;
              }
            }
          }

          openImageEditor(imageSrcStr, (modifiedImageData, slidesData, savedOriginalImageSrc) => {
            const finalOriginalSrc = savedOriginalImageSrc || originalImageSrc;
            // Update in current analysis
            chrome.storage.local.get(['analyses', 'currentAnalysisId'], (result) => {
              const analyses = result.analyses || [];
              const currentAnalysis = analyses.find(a => a.id === result.currentAnalysisId);
              if (currentAnalysis) {
                updateImageInStorage(currentAnalysis, imageSrcStr, modifiedImageData, slidesData, finalOriginalSrc);
              }
            });
          }, existingSlidesData, originalImageSrc);
        });
      }
      sendResponse({ success: true });
    } else if (request.action === 'getEditorImage') {
      // Get image data from chrome.storage
      chrome.storage.local.get(['pendingEditorImageSrc', 'pendingEditorCallbackId'], (result) => {
        if (result.pendingEditorImageSrc) {
          sendResponse({ 
            imageSrc: result.pendingEditorImageSrc,
            callbackId: result.pendingEditorCallbackId
          });
        } else {
          sendResponse({ imageSrc: null });
        }
      });
      return true; // Keep channel open for async response
    }
    return true; // Keep channel open for async response
  });

  // ============================================================
  // SQUAD ASSIGNMENT FUNCTIONS
  // ============================================================
  
  // Formation positions data (same as in editor.js)
  const SQUAD_FORMATIONS = {
    '4-3-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 20, y: 80, role: 'FWD', label: 'LW'},
        {x: 50, y: 80, role: 'FWD', label: 'ST'},
        {x: 80, y: 80, role: 'FWD', label: 'RW'}
      ]
    },
    '4-2-3-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 40, y: 50, role: 'MID', label: 'CDM'},
        {x: 60, y: 50, role: 'MID', label: 'CDM'},
        {x: 30, y: 70, role: 'MID', label: 'LM'},
        {x: 50, y: 70, role: 'MID', label: 'CAM'},
        {x: 70, y: 70, role: 'MID', label: 'RM'},
        {x: 50, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-4-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 20, y: 55, role: 'MID', label: 'LM'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RM'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '4-1-2-1-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 50, y: 45, role: 'MID', label: 'CDM'},
        {x: 40, y: 60, role: 'MID', label: 'CM'},
        {x: 60, y: 60, role: 'MID', label: 'CM'},
        {x: 50, y: 70, role: 'MID', label: 'CAM'},
        {x: 40, y: 85, role: 'FWD', label: 'ST'},
        {x: 60, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-1-4-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 50, y: 48, role: 'MID', label: 'CDM'},
        {x: 20, y: 62, role: 'MID', label: 'LM'},
        {x: 40, y: 62, role: 'MID', label: 'CM'},
        {x: 60, y: 62, role: 'MID', label: 'CM'},
        {x: 80, y: 62, role: 'MID', label: 'RM'},
        {x: 50, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-5-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 20, y: 55, role: 'MID', label: 'LM'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RM'},
        {x: 50, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-3-2-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 40, y: 75, role: 'MID', label: 'AM'},
        {x: 60, y: 75, role: 'MID', label: 'AM'},
        {x: 50, y: 90, role: 'FWD', label: 'ST'}
      ]
    },
    '4-1-2-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 50, y: 48, role: 'MID', label: 'CDM'},
        {x: 40, y: 65, role: 'MID', label: 'CM'},
        {x: 60, y: 65, role: 'MID', label: 'CM'},
        {x: 20, y: 85, role: 'FWD', label: 'LW'},
        {x: 50, y: 85, role: 'FWD', label: 'ST'},
        {x: 80, y: 85, role: 'FWD', label: 'RW'}
      ]
    },
    '3-5-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 15, y: 55, role: 'MID', label: 'LWB'},
        {x: 35, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 65, y: 55, role: 'MID', label: 'CM'},
        {x: 85, y: 55, role: 'MID', label: 'RWB'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '3-4-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 20, y: 55, role: 'MID', label: 'LWB'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RWB'},
        {x: 20, y: 80, role: 'FWD', label: 'LW'},
        {x: 50, y: 80, role: 'FWD', label: 'ST'},
        {x: 80, y: 80, role: 'FWD', label: 'RW'}
      ]
    },
    '3-4-1-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 20, y: 55, role: 'MID', label: 'LWB'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RWB'},
        {x: 50, y: 70, role: 'MID', label: 'CAM'},
        {x: 40, y: 85, role: 'FWD', label: 'ST'},
        {x: 60, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '3-3-3-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 30, y: 50, role: 'MID', label: 'CM'},
        {x: 50, y: 50, role: 'MID', label: 'CM'},
        {x: 70, y: 50, role: 'MID', label: 'CM'},
        {x: 30, y: 70, role: 'MID', label: 'AM'},
        {x: 50, y: 70, role: 'MID', label: 'AM'},
        {x: 70, y: 70, role: 'MID', label: 'AM'},
        {x: 50, y: 90, role: 'FWD', label: 'ST'}
      ]
    },
    '3-2-4-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 40, y: 50, role: 'MID', label: 'CDM'},
        {x: 60, y: 50, role: 'MID', label: 'CDM'},
        {x: 20, y: 70, role: 'MID', label: 'LM'},
        {x: 40, y: 70, role: 'MID', label: 'CM'},
        {x: 60, y: 70, role: 'MID', label: 'CM'},
        {x: 80, y: 70, role: 'MID', label: 'RM'},
        {x: 50, y: 90, role: 'FWD', label: 'ST'}
      ]
    },
    '5-3-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 15, y: 30, role: 'DEF', label: 'LWB'},
        {x: 35, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 65, y: 30, role: 'DEF', label: 'CB'},
        {x: 85, y: 30, role: 'DEF', label: 'RWB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 40, y: 80, role: 'FWD', label: 'ST'},
        {x: 60, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '5-4-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 15, y: 30, role: 'DEF', label: 'LWB'},
        {x: 35, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 65, y: 30, role: 'DEF', label: 'CB'},
        {x: 85, y: 30, role: 'DEF', label: 'RWB'},
        {x: 20, y: 55, role: 'MID', label: 'LM'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RM'},
        {x: 50, y: 80, role: 'FWD', label: 'ST'}
      ]
    },
    '5-2-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 15, y: 30, role: 'DEF', label: 'LWB'},
        {x: 35, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 65, y: 30, role: 'DEF', label: 'CB'},
        {x: 85, y: 30, role: 'DEF', label: 'RWB'},
        {x: 40, y: 55, role: 'MID', label: 'CM'},
        {x: 60, y: 55, role: 'MID', label: 'CM'},
        {x: 20, y: 80, role: 'FWD', label: 'LW'},
        {x: 50, y: 80, role: 'FWD', label: 'ST'},
        {x: 80, y: 80, role: 'FWD', label: 'RW'}
      ]
    },
    '4-3-1-2': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 30, y: 50, role: 'MID', label: 'CM'},
        {x: 50, y: 50, role: 'MID', label: 'CM'},
        {x: 70, y: 50, role: 'MID', label: 'CM'},
        {x: 50, y: 68, role: 'MID', label: 'CAM'},
        {x: 40, y: 85, role: 'FWD', label: 'ST'},
        {x: 60, y: 85, role: 'FWD', label: 'ST'}
      ]
    },
    '4-2-1-3': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 40, y: 50, role: 'MID', label: 'CDM'},
        {x: 60, y: 50, role: 'MID', label: 'CDM'},
        {x: 50, y: 65, role: 'MID', label: 'CAM'},
        {x: 20, y: 82, role: 'FWD', label: 'LW'},
        {x: 50, y: 82, role: 'FWD', label: 'ST'},
        {x: 80, y: 82, role: 'FWD', label: 'RW'}
      ]
    },
    '4-6-0': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 20, y: 30, role: 'DEF', label: 'LB'},
        {x: 40, y: 30, role: 'DEF', label: 'CB'},
        {x: 60, y: 30, role: 'DEF', label: 'CB'},
        {x: 80, y: 30, role: 'DEF', label: 'RB'},
        {x: 20, y: 55, role: 'MID', label: 'LM'},
        {x: 35, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 65, y: 55, role: 'MID', label: 'CM'},
        {x: 80, y: 55, role: 'MID', label: 'RM'},
        {x: 50, y: 78, role: 'FWD', label: 'F9'}
      ]
    },
    '3-6-1': {
      positions: [
        {x: 50, y: 10, role: 'GK', label: 'GK'},
        {x: 30, y: 30, role: 'DEF', label: 'CB'},
        {x: 50, y: 30, role: 'DEF', label: 'CB'},
        {x: 70, y: 30, role: 'DEF', label: 'CB'},
        {x: 15, y: 55, role: 'MID', label: 'LWB'},
        {x: 30, y: 55, role: 'MID', label: 'CM'},
        {x: 50, y: 55, role: 'MID', label: 'CM'},
        {x: 70, y: 55, role: 'MID', label: 'CM'},
        {x: 85, y: 55, role: 'MID', label: 'RWB'},
        {x: 50, y: 70, role: 'MID', label: 'CAM'},
        {x: 50, y: 88, role: 'FWD', label: 'ST'}
      ]
    }
  };

  // Current squad assignments while editing
  let currentSquadAssignments = {};
  let currentSquadPositionIndex = null;

  function getFormationPositions(formationName) {
    // Try built-in formations first
    if (SQUAD_FORMATIONS[formationName]) {
      return SQUAD_FORMATIONS[formationName].positions;
    }
    // Generate generic 11 positions for unknown formations
    return [
      {x: 50, y: 10, role: 'GK', label: 'GK'},
      {x: 20, y: 30, role: 'DEF', label: 'DEF'},
      {x: 40, y: 30, role: 'DEF', label: 'DEF'},
      {x: 60, y: 30, role: 'DEF', label: 'DEF'},
      {x: 80, y: 30, role: 'DEF', label: 'DEF'},
      {x: 30, y: 55, role: 'MID', label: 'MID'},
      {x: 50, y: 55, role: 'MID', label: 'MID'},
      {x: 70, y: 55, role: 'MID', label: 'MID'},
      {x: 35, y: 80, role: 'FWD', label: 'FWD'},
      {x: 50, y: 80, role: 'FWD', label: 'FWD'},
      {x: 65, y: 80, role: 'FWD', label: 'FWD'}
    ];
  }

  function renderSquadFormation(formationName, teamName, squad = {}) {
    const container = document.getElementById('teamSquadFormation');
    const section = document.getElementById('teamSquadSection');
    
    if (!container || !section) return;
    
    if (!formationName) {
      section.style.display = 'none';
      return;
    }
    
    section.style.display = 'block';
    container.innerHTML = '';
    currentSquadAssignments = { ...squad };
    
    const positions = getFormationPositions(formationName);
    
    // Get team players
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const teamPlayers = players.filter(p => p.team === teamName);
      
      positions.forEach((pos, index) => {
        const assignedPlayerId = currentSquadAssignments[index];
        const assignedPlayer = assignedPlayerId ? teamPlayers.find(p => p.id === assignedPlayerId) : null;
        
        const slot = document.createElement('div');
        slot.className = 'squad-position-slot';
        slot.style.cssText = `
          position: absolute;
          left: ${pos.x}%;
          top: ${pos.y}%;
          transform: translate(-50%, -50%);
          width: 50px;
          text-align: center;
          cursor: pointer;
        `;
        slot.dataset.positionIndex = index;
        
        // T-shirt circle
        const circle = document.createElement('div');
        circle.style.cssText = `
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: ${assignedPlayer ? '#1f6feb' : 'rgba(255,255,255,0.2)'};
          border: 2px solid ${assignedPlayer ? '#58a6ff' : 'rgba(255,255,255,0.4)'};
          margin: 0 auto 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: bold;
          color: ${assignedPlayer ? '#fff' : 'rgba(255,255,255,0.7)'};
          transition: all 0.2s ease;
        `;
        circle.textContent = assignedPlayer ? (assignedPlayer.number || '?') : pos.label;
        
        // Player name label
        const label = document.createElement('div');
        label.style.cssText = `
          font-size: 10px;
          color: #fff;
          text-shadow: 0 1px 2px rgba(0,0,0,0.8);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 60px;
        `;
        label.textContent = assignedPlayer ? (assignedPlayer.fullName || 'Unknown').split(' ').pop() : pos.label;
        
        slot.appendChild(circle);
        slot.appendChild(label);
        
        // Hover effect
        slot.addEventListener('mouseenter', () => {
          circle.style.transform = 'scale(1.1)';
          circle.style.boxShadow = '0 0 10px rgba(88, 166, 255, 0.5)';
        });
        slot.addEventListener('mouseleave', () => {
          circle.style.transform = 'scale(1)';
          circle.style.boxShadow = 'none';
        });
        
        // Click to assign player
        slot.addEventListener('click', () => {
          openSquadPlayerPopup(index, pos.label, teamName);
        });
        
        container.appendChild(slot);
      });
    });
  }

  function openSquadPlayerPopup(positionIndex, positionLabel, teamName) {
    const popup = document.getElementById('squadPlayerPopup');
    const title = document.getElementById('squadPlayerPopupTitle');
    const positionInfo = document.getElementById('squadPlayerPopupPosition');
    const playerList = document.getElementById('squadPlayerList');
    
    if (!popup || !playerList) return;
    
    currentSquadPositionIndex = positionIndex;
    title.textContent = 'Assign Player';
    positionInfo.textContent = `Position: ${positionLabel}`;
    playerList.innerHTML = '';
    
    chrome.storage.local.get(['players'], (result) => {
      const players = result.players || [];
      const teamPlayers = players.filter(p => p.team === teamName);
      
      if (teamPlayers.length === 0) {
        playerList.innerHTML = '<div style="color: #8b949e; font-size: 12px; padding: 12px; text-align: center;">No players in this team</div>';
      } else {
        // Sort by number
        teamPlayers.sort((a, b) => (parseInt(a.number) || 0) - (parseInt(b.number) || 0));
        
        teamPlayers.forEach(player => {
          const isAssigned = Object.values(currentSquadAssignments).includes(player.id);
          const isCurrentPosition = currentSquadAssignments[positionIndex] === player.id;
          
          const playerItem = document.createElement('div');
          playerItem.style.cssText = `
            display: flex;
            align-items: center;
            padding: 10px 12px;
            margin-bottom: 4px;
            background: ${isCurrentPosition ? '#1f6feb' : '#0d1117'};
            border: 1px solid ${isCurrentPosition ? '#58a6ff' : '#21262d'};
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.15s ease;
            opacity: ${isAssigned && !isCurrentPosition ? '0.5' : '1'};
          `;
          
          const numberSpan = document.createElement('span');
          numberSpan.style.cssText = `
            width: 28px;
            height: 28px;
            background: ${isCurrentPosition ? 'rgba(255,255,255,0.2)' : '#21262d'};
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: bold;
            color: #c9d1d9;
            margin-right: 10px;
          `;
          numberSpan.textContent = player.number || '?';
          
          const nameSpan = document.createElement('span');
          nameSpan.style.cssText = 'flex: 1; font-size: 13px; color: #c9d1d9;';
          nameSpan.textContent = player.fullName || 'Unknown';
          
          const posSpan = document.createElement('span');
          posSpan.style.cssText = 'font-size: 11px; color: #8b949e;';
          posSpan.textContent = player.position || '';
          
          playerItem.appendChild(numberSpan);
          playerItem.appendChild(nameSpan);
          playerItem.appendChild(posSpan);
          
          playerItem.addEventListener('mouseenter', () => {
            if (!isCurrentPosition) {
              playerItem.style.borderColor = '#30363d';
              playerItem.style.background = '#161b22';
            }
          });
          playerItem.addEventListener('mouseleave', () => {
            if (!isCurrentPosition) {
              playerItem.style.borderColor = '#21262d';
              playerItem.style.background = '#0d1117';
            }
          });
          
          playerItem.addEventListener('click', () => {
            // Remove player from any other position
            Object.keys(currentSquadAssignments).forEach(key => {
              if (currentSquadAssignments[key] === player.id) {
                delete currentSquadAssignments[key];
              }
            });
            // Assign to this position
            currentSquadAssignments[positionIndex] = player.id;
            closeSquadPlayerPopup();
            // Re-render formation
            const formationSelect = document.getElementById('teamFormationSelect');
            renderSquadFormation(formationSelect?.value, teamName, currentSquadAssignments);
          });
          
          playerList.appendChild(playerItem);
        });
      }
      
      popup.classList.remove('hidden');
    });
  }

  function closeSquadPlayerPopup() {
    const popup = document.getElementById('squadPlayerPopup');
    if (popup) {
      popup.classList.add('hidden');
      currentSquadPositionIndex = null;
    }
  }

  // Squad popup event listeners
  const closeSquadPopupBtn = document.getElementById('closeSquadPlayerPopup');
  const clearSquadPositionBtn = document.getElementById('clearSquadPosition');
  const squadPlayerPopup = document.getElementById('squadPlayerPopup');
  
  if (closeSquadPopupBtn) {
    closeSquadPopupBtn.addEventListener('click', closeSquadPlayerPopup);
  }
  
  if (clearSquadPositionBtn) {
    clearSquadPositionBtn.addEventListener('click', () => {
      if (currentSquadPositionIndex !== null) {
        delete currentSquadAssignments[currentSquadPositionIndex];
        closeSquadPlayerPopup();
        const formationSelect = document.getElementById('teamFormationSelect');
        const teamNameInput = document.getElementById('teamNameInput');
        renderSquadFormation(formationSelect?.value, currentEditingTeamName || teamNameInput?.value, currentSquadAssignments);
      }
    });
  }
  
  if (squadPlayerPopup) {
    squadPlayerPopup.addEventListener('click', (e) => {
      if (e.target === squadPlayerPopup) {
        closeSquadPlayerPopup();
      }
    });
  }

  // Formation selector change handler for squad
  const teamFormationSelect = document.getElementById('teamFormationSelect');
  if (teamFormationSelect) {
    teamFormationSelect.addEventListener('change', (e) => {
      const teamName = currentEditingTeamName || document.getElementById('teamNameInput')?.value;
      // Reset squad assignments when formation changes (optional: could keep and remap)
      currentSquadAssignments = {};
      renderSquadFormation(e.target.value, teamName, currentSquadAssignments);
    });
  }

  // ==================== AI Analysis Feature ====================

  // API Key Management Functions
  function saveOpenAIKey(key) {
    return new Promise((resolve, reject) => {
      if (!validateAPIKey(key)) {
        reject(new Error('Invalid API key format'));
        return;
      }
      chrome.storage.local.set({ openai_api_key: key }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  function loadOpenAIKey() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['openai_api_key'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(result.openai_api_key || null);
        }
      });
    });
  }

  function deleteOpenAIKey() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.remove(['openai_api_key'], () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  function validateAPIKey(key) {
    if (!key || typeof key !== 'string') {
      return false;
    }
    // OpenAI API keys typically start with 'sk-' and are 51 characters long
    return key.trim().startsWith('sk-') && key.trim().length >= 20;
  }

  // Data Collection Function
  async function collectAnalysisData(analysisId) {
    return new Promise((resolve, reject) => {
      if (!analysisId) {
        reject(new Error('No analysis ID provided'));
        return;
      }

      chrome.storage.local.get(['analyses', `timelineMarkers_${analysisId}`], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const analysis = analyses.find(a => a.id === analysisId);

        if (!analysis) {
          reject(new Error('Analysis not found'));
          return;
        }

        const timelineMarkers = result[`timelineMarkers_${analysisId}`] || [];

        // Collect tactical editor schemes and regular images from notes
        const tacticalSchemes = [];
        const regularImages = [];
        if (analysis.notes) {
          analysis.notes.forEach(note => {
            if (note.images && Array.isArray(note.images)) {
              note.images.forEach(image => {
                // Check if image has slidesData (tactical editor)
                if (typeof image === 'object' && image.slidesData && Array.isArray(image.slidesData) && image.slidesData.length > 0) {
                  tacticalSchemes.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    slidesData: image.slidesData,
                    slides: image.slidesData || []
                  });
                } else if (typeof image === 'string' || (typeof image === 'object' && image.imageData)) {
                  // Regular image (not tactical editor)
                  regularImages.push({
                    timestamp: note.timestamp,
                    videoTime: note.videoTime,
                    timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                    imageData: typeof image === 'string' ? image : image.imageData
                  });
                }
              });
            } else if (note.image) {
              // Legacy single image format
              if (typeof note.image === 'string') {
                regularImages.push({
                  timestamp: note.timestamp,
                  videoTime: note.videoTime,
                  timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                  imageData: note.image
                });
              }
            }
          });
        }

        const data = {
          analysis: {
            id: analysis.id,
            name: analysis.name,
            date: analysis.date,
            createdAt: analysis.createdAt,
            videos: analysis.videos || []
          },
          notes: analysis.notes || [],
          timelineMarkers: timelineMarkers,
          tacticalSchemes: tacticalSchemes,
          regularImages: regularImages,
          userTeam: analysis.userTeam || null
        };

        resolve(data);
      });
    });
  }

  // Format data for AI prompt
  // Helper function to get zone number from field position (standard football zones)
  function getZoneNumber(x, y, canvasWidth = 1000, canvasHeight = 600) {
  const relX = (x / canvasWidth) * 100;
  const relY = (y / canvasHeight) * 100;
  
  // Standard 9-zone grid (3x3)
  let zoneX = 1; // left
  if (relX >= 33 && relX < 67) zoneX = 2; // center
  else if (relX >= 67) zoneX = 3; // right
  
  let zoneY = 1; // defensive
  if (relY >= 33 && relY < 67) zoneY = 2; // midfield
  else if (relY >= 67) zoneY = 3; // attacking
  
  return (zoneY - 1) * 3 + zoneX; // Zone 1-9
}

  // Helper function to check if a point is inside a shape (for zone analysis)
  function isPointInShape(px, py, shape) {
  if (!shape || !shape.type) return false;
  
  const minX = Math.min(shape.startX, shape.endX);
  const maxX = Math.max(shape.startX, shape.endX);
  const minY = Math.min(shape.startY, shape.endY);
  const maxY = Math.max(shape.startY, shape.endY);
  
  switch (shape.type) {
    case 'circle':
      const centerX = (shape.startX + shape.endX) / 2;
      const centerY = (shape.startY + shape.endY) / 2;
      const radius = Math.max(Math.abs(shape.endX - shape.startX), Math.abs(shape.endY - shape.startY)) / 2;
      const dist = Math.sqrt(Math.pow(px - centerX, 2) + Math.pow(py - centerY, 2));
      return dist <= radius;
      
    case 'oval':
    case 'rectangle':
    case 'triangle':
      return px >= minX && px <= maxX && py >= minY && py <= maxY;
      
    default:
      return false;
  }
}

  // Helper function to describe a drawing in tactical terms
  function describeDrawing(drawing, index, canvasWidth = 1000, canvasHeight = 600, allDrawings = []) {
  if (!drawing || !drawing.type) return null;
  
  const descriptions = [];
  const type = drawing.type;
  
  // Convert coordinates to relative field positions
  const getFieldPosition = (x, y) => {
    const relX = (x / canvasWidth) * 100;
    const relY = (y / canvasHeight) * 100;
    
    let xPos = '';
    if (relX < 30) xPos = 'left side';
    else if (relX > 70) xPos = 'right side';
    else xPos = 'center';
    
    let yPos = '';
    if (relY < 25) yPos = 'defensive third';
    else if (relY < 60) yPos = 'midfield';
    else yPos = 'attacking third';
    
    return `${xPos} of ${yPos}`;
  };
  
  const getZoneInfo = (x, y) => {
    const zoneNum = getZoneNumber(x, y, canvasWidth, canvasHeight);
    const zoneNames = {
      1: 'Zone 1 (left defensive)',
      2: 'Zone 2 (center defensive)',
      3: 'Zone 3 (right defensive)',
      4: 'Zone 4 (left midfield)',
      5: 'Zone 5 (center midfield)',
      6: 'Zone 6 (right midfield)',
      7: 'Zone 7 (left attacking)',
      8: 'Zone 8 (center attacking)',
      9: 'Zone 9 (right attacking)'
    };
    return zoneNames[zoneNum] || `Zone ${zoneNum}`;
  };
  
  const getDirection = (startX, startY, endX, endY) => {
    const dx = endX - startX;
    const dy = endY - startY;
    const angle = Math.atan2(dy, dx) * 180 / Math.PI;
    
    if (Math.abs(dx) < 10) {
      return dy < 0 ? 'upward' : 'downward';
    } else if (Math.abs(dy) < 10) {
      return dx > 0 ? 'rightward' : 'leftward';
    } else {
      if (angle > -45 && angle < 45) return 'rightward';
      if (angle > 45 && angle < 135) return 'downward';
      if (angle > 135 || angle < -135) return 'leftward';
      return 'upward';
    }
  };
  
  // Check which zones a movement passes through
  const getZonesForMovement = (startX, startY, endX, endY) => {
    const startZone = getZoneNumber(startX, startY, canvasWidth, canvasHeight);
    const endZone = getZoneNumber(endX, endY, canvasWidth, canvasHeight);
    const zones = new Set([startZone, endZone]);
    
    // Check intermediate zones (simplified - check midpoint)
    const midX = (startX + endX) / 2;
    const midY = (startY + endY) / 2;
    const midZone = getZoneNumber(midX, midY, canvasWidth, canvasHeight);
    zones.add(midZone);
    
    return Array.from(zones).sort((a, b) => a - b);
  };
  
  // Check which zones a shape covers
  const getZonesForShape = (shape) => {
    const zones = new Set();
    // Check corners and center
    const points = [
      {x: shape.startX, y: shape.startY},
      {x: shape.endX, y: shape.startY},
      {x: shape.startX, y: shape.endY},
      {x: shape.endX, y: shape.endY},
      {x: (shape.startX + shape.endX) / 2, y: (shape.startY + shape.endY) / 2}
    ];
    points.forEach(p => {
      zones.add(getZoneNumber(p.x, p.y, canvasWidth, canvasHeight));
    });
    return Array.from(zones).sort((a, b) => a - b);
  };
  
  // Describe based on type
  switch (type) {
    case 'arrow':
      const arrowStart = getFieldPosition(drawing.startX, drawing.startY);
      const arrowEnd = getFieldPosition(drawing.endX, drawing.endY);
      const arrowDir = getDirection(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      const arrowZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
      let arrowDesc = `Arrow from ${arrowStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${arrowEnd} (${getZoneInfo(drawing.endX, drawing.endY)}) - ${arrowDir} direction`;
      arrowDesc += ` - Passes through zones: ${arrowZones.map(z => `Zone ${z} (${zoneNames[z]})`).join(', ')}`;
      if (drawing.eventName) arrowDesc += ` - Event: ${drawing.eventName}`;
      // Check if arrow connects to or passes through any zone shapes
      const arrowThroughZones = allDrawings.filter(d => 
        d !== drawing && ['circle', 'oval', 'rectangle', 'triangle'].includes(d.type) && 
        (isPointInShape(drawing.startX, drawing.startY, d) || isPointInShape(drawing.endX, drawing.endY, d))
      );
      if (arrowThroughZones.length > 0) {
        arrowDesc += ` - Connects to zone marker(s)`;
      }
      return arrowDesc;
      
    case 'line':
      const lineStart = getFieldPosition(drawing.startX, drawing.startY);
      const lineEnd = getFieldPosition(drawing.endX, drawing.endY);
      const lineZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      let lineDesc = `Line connecting ${lineStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${lineEnd} (${getZoneInfo(drawing.endX, drawing.endY)})`;
      lineDesc += ` - Zones: ${lineZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.eventName) lineDesc += ` - Event: ${drawing.eventName}`;
      return lineDesc;
      
    case 'curve':
      const curveStart = getFieldPosition(drawing.startX, drawing.startY);
      const curveEnd = getFieldPosition(drawing.endX, drawing.endY);
      const curveZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      let curveDesc = `Curved line from ${curveStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${curveEnd} (${getZoneInfo(drawing.endX, drawing.endY)})`;
      curveDesc += ` - Zones: ${curveZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.eventName) curveDesc += ` - Event: ${drawing.eventName}`;
      return curveDesc;
      
    case 'animpath':
      const pathStart = getFieldPosition(drawing.startX, drawing.startY);
      const pathEnd = getFieldPosition(drawing.endX, drawing.endY);
      const pathDir = getDirection(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      const pathZones = getZonesForMovement(drawing.startX, drawing.startY, drawing.endX, drawing.endY);
      let pathDesc = `Player movement path from ${pathStart} (${getZoneInfo(drawing.startX, drawing.startY)}) to ${pathEnd} (${getZoneInfo(drawing.endX, drawing.endY)}) - ${pathDir}`;
      pathDesc += ` - Movement through zones: ${pathZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(' → ')}`;
      if (drawing.duration) pathDesc += ` - Duration: ${drawing.duration}s`;
      if (drawing.targetIndex !== undefined) pathDesc += ` - Linked to player ${drawing.targetIndex + 1}`;
      return pathDesc;
      
    case 'circle':
      const circleCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const circleRadius = Math.max(Math.abs(drawing.endX - drawing.startX), Math.abs(drawing.endY - drawing.startY)) / 2;
      const circleSize = circleRadius > 50 ? 'large' : circleRadius > 25 ? 'medium' : 'small';
      const circleZones = getZonesForShape(drawing);
      let circleDesc = `${circleSize} circle ZONE at ${circleCenter}`;
      circleDesc += ` - Covers zones: ${circleZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.fillOpacity > 0) circleDesc += ` (filled - active zone)`;
      if (drawing.eventName) circleDesc += ` - Event in this zone: ${drawing.eventName}`;
      return circleDesc;
      
    case 'oval':
      const ovalCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const ovalWidth = Math.abs(drawing.endX - drawing.startX);
      const ovalHeight = Math.abs(drawing.endY - drawing.startY);
      const ovalSize = (ovalWidth + ovalHeight) / 2 > 100 ? 'large' : (ovalWidth + ovalHeight) / 2 > 50 ? 'medium' : 'small';
      const ovalZones = getZonesForShape(drawing);
      let ovalDesc = `${ovalSize} oval/ellipse ZONE at ${ovalCenter}`;
      ovalDesc += ` - Covers zones: ${ovalZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.fillOpacity > 0) ovalDesc += ` (filled - active zone)`;
      if (drawing.eventName) ovalDesc += ` - Event in this zone: ${drawing.eventName}`;
      return ovalDesc;
      
    case 'rectangle':
      const rectCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const rectZones = getZonesForShape(drawing);
      let rectDesc = `Rectangle ZONE at ${rectCenter}`;
      rectDesc += ` - Covers zones: ${rectZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.fillOpacity > 0) rectDesc += ` (filled - active zone)`;
      if (drawing.eventName) rectDesc += ` - Event in this zone: ${drawing.eventName}`;
      return rectDesc;
      
    case 'triangle':
      const triCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const triZones = getZonesForShape(drawing);
      let triDesc = `Triangle ZONE at ${triCenter}`;
      triDesc += ` - Covers zones: ${triZones.map(z => {
        const zoneNames = {1:'left defensive',2:'center defensive',3:'right defensive',4:'left midfield',5:'center midfield',6:'right midfield',7:'left attacking',8:'center attacking',9:'right attacking'};
        return `Zone ${z} (${zoneNames[z]})`;
      }).join(', ')}`;
      if (drawing.fillOpacity > 0) triDesc += ` (filled - active zone)`;
      if (drawing.eventName) triDesc += ` - Event in this zone: ${drawing.eventName}`;
      return triDesc;
      
    case 'arc':
      const arcCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      let arcDesc = `Arc at ${arcCenter} (${getZoneInfo((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2)})`;
      if (drawing.eventName) arcDesc += ` - Event: ${drawing.eventName}`;
      return arcDesc;
      
    case 'tshirt':
      const tshirtPos = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const tshirtZone = getZoneInfo((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      let tshirtDesc = `Player at ${tshirtPos} (${tshirtZone})`;
      if (drawing.number) tshirtDesc += ` - Number: ${drawing.number}`;
      if (drawing.surname) tshirtDesc += ` - Name: ${drawing.surname}`;
      if (drawing.role) tshirtDesc += ` - Role: ${drawing.role}`;
      return tshirtDesc;
      
    case 'ball':
      const ballPos = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      const ballZone = getZoneInfo((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      return `Ball at ${ballPos} (${ballZone})`;
      
    case 'cross':
      const crossCenter = getFieldPosition((drawing.startX + drawing.endX) / 2, (drawing.startY + drawing.endY) / 2);
      return `Cross/X mark at ${crossCenter}`;
      
    case 'freehand':
      if (drawing.points && drawing.points.length > 0) {
        const firstPoint = getFieldPosition(drawing.points[0].x, drawing.points[0].y);
        const lastPoint = getFieldPosition(drawing.points[drawing.points.length - 1].x, drawing.points[drawing.points.length - 1].y);
        return `Freehand drawing from ${firstPoint} to ${lastPoint}`;
      }
      return 'Freehand drawing';
      
    default:
      return `${type} drawing`;
  }
}

  // Zone Analysis Functions
  // Analyze zone patterns from notes, markers, and tactical schemes
  function analyzeZonePatterns(data) {
    const zoneData = {
      byTeam: new Map(), // Map<teamName, teamZoneData>
      overall: {
        zones: new Map(), // Map<zoneNumber, zoneStats>
        transitions: [] // Array of {from: zone, to: zone, team, event}
      }
    };

    // Initialize zone stats structure
    const initZoneStats = () => ({
      totalEvents: 0,
      attackingEvents: 0,
      defensiveEvents: 0,
      errors: 0,
      goals: 0,
      shots: 0,
      dangerousAttacks: 0,
      recoveries: 0,
      pressingActions: 0,
      events: [],
      coverageScore: 0, // Defensive actions count
      productivityScore: 0 // Attacking success count
    });

    // Helper to categorize events
    const isAttackingEvent = (event) => {
      const attackingKeywords = ['attack', 'shot', 'goal', 'assist', 'cross', 'cutback', 'through ball', 'final third', 'penalty box', 'progressive pass', 'carry', 'dribble'];
      return attackingKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isDefensiveEvent = (event) => {
      const defensiveKeywords = ['defense', 'defensive', 'pressing', 'recovery', 'tackle', 'interception', 'block', 'clearance', 'transition defense'];
      return defensiveKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    const isErrorEvent = (event) => {
      const errorKeywords = ['error', 'poor', 'bad decision', 'miscommunication', 'failed'];
      return errorKeywords.some(keyword => event.toLowerCase().includes(keyword));
    };

    // Process notes
    if (data.notes && Array.isArray(data.notes)) {
      data.notes.forEach(note => {
        const teams = [];
        if (note.team) teams.push(note.team);
        if (note.teams && Array.isArray(note.teams)) teams.push(...note.teams);
        if (teams.length === 0) teams.push('Unknown');

        teams.forEach(team => {
          if (!zoneData.byTeam.has(team)) {
            zoneData.byTeam.set(team, {
              zones: new Map(),
              transitions: []
            });
          }
          const teamData = zoneData.byTeam.get(team);

          // Process zones from note
          if (note.zones && Array.isArray(note.zones)) {
            note.zones.forEach(zoneStr => {
              const zoneMatch = zoneStr.toString().match(/(\d+)/);
              if (zoneMatch) {
                const zoneNum = parseInt(zoneMatch[1]);
                if (zoneNum >= 1 && zoneNum <= 18) {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  zoneStats.events.push({
                    type: 'note',
                    event: note.events ? note.events.join(', ') : 'General note',
                    text: note.text || note.content || ''
                  });

                  // Categorize by events
                  const eventText = (note.events || []).join(' ').toLowerCase() + ' ' + (note.text || note.content || '').toLowerCase();
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    if (eventText.includes('goal')) zoneStats.goals++;
                    if (eventText.includes('shot')) zoneStats.shots++;
                    if (eventText.includes('dangerous') || eventText.includes('chance')) zoneStats.dangerousAttacks++;
                    zoneStats.productivityScore += 2;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    if (eventText.includes('recovery')) zoneStats.recoveries++;
                    if (eventText.includes('pressing')) zoneStats.pressingActions++;
                    zoneStats.coverageScore += 2;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                }
              }
            });
          }

          // Process events for transitions
          if (note.events && Array.isArray(note.events) && note.zones && note.zones.length >= 2) {
            const zones = note.zones.map(z => {
              const match = z.toString().match(/(\d+)/);
              return match ? parseInt(match[1]) : null;
            }).filter(z => z !== null && z >= 1 && z <= 9);
            
            if (zones.length >= 2) {
              for (let i = 0; i < zones.length - 1; i++) {
                teamData.transitions.push({
                  from: zones[i],
                  to: zones[i + 1],
                  event: note.events.join(', '),
                  type: 'note'
                });
              }
            }
          }
        });
      });
    }

    // Process timeline markers
    if (data.timelineMarkers && Array.isArray(data.timelineMarkers)) {
      data.timelineMarkers.forEach(marker => {
        const team = marker.team || 'Unknown';
        if (!zoneData.byTeam.has(team)) {
          zoneData.byTeam.set(team, {
            zones: new Map(),
            transitions: []
          });
        }
        const teamData = zoneData.byTeam.get(team);

        // Timeline markers don't have zones directly, but we can infer from event type
        const eventType = marker.eventType || '';
        const eventText = eventType.toLowerCase();
        
        // For markers, we'll add to overall stats but can't assign to specific zones
        // This is handled in the tactical schemes processing
      });
    }

    // Process tactical schemes
    if (data.tacticalSchemes && Array.isArray(data.tacticalSchemes)) {
      data.tacticalSchemes.forEach(scheme => {
        if (scheme.slidesData && Array.isArray(scheme.slidesData)) {
          scheme.slidesData.forEach(slide => {
            if (slide.drawings && Array.isArray(slide.drawings)) {
              const canvasWidth = 1000;
              const canvasHeight = 600;

              // Process zones (shapes)
              const zones = slide.drawings.filter(d => ['circle', 'oval', 'rectangle', 'triangle'].includes(d.type));
              zones.forEach(zone => {
                const zoneNums = getZonesForShape(zone, canvasWidth, canvasHeight);
                const team = zone.team || 'Unknown';
                
                if (!zoneData.byTeam.has(team)) {
                  zoneData.byTeam.set(team, {
                    zones: new Map(),
                    transitions: []
                  });
                }
                const teamData = zoneData.byTeam.get(team);

                // Convert 9-zone to 18-zone for tactical schemes
                const convert9to18Zones = (zones9) => {
                  return zones9.map(zone9 => {
                    if (zone9 < 1 || zone9 > 9) return null;
                    const row = Math.floor((zone9 - 1) / 3);
                    const col = ((zone9 - 1) % 3);
                    // Map to approximate 18-zone
                    return row * 6 + col * 2 + 1;
                  }).filter(z => z !== null);
                };
                const zoneNums18 = convert9to18Zones(zoneNums);
                
                zoneNums18.forEach(zoneNum => {
                  if (!teamData.zones.has(zoneNum)) {
                    teamData.zones.set(zoneNum, initZoneStats());
                  }
                  const zoneStats = teamData.zones.get(zoneNum);
                  zoneStats.totalEvents++;
                  
                  const eventName = zone.eventName || '';
                  const eventText = eventName.toLowerCase();
                  
                  if (isAttackingEvent(eventText)) {
                    zoneStats.attackingEvents++;
                    zoneStats.productivityScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isDefensiveEvent(eventText)) {
                    zoneStats.defensiveEvents++;
                    zoneStats.coverageScore += zone.fillOpacity > 0 ? 3 : 1;
                  }
                  if (isErrorEvent(eventText)) {
                    zoneStats.errors++;
                    zoneStats.coverageScore -= 1;
                  }
                  
                  zoneStats.events.push({
                    type: 'scheme',
                    event: eventName,
                    filled: zone.fillOpacity > 0
                  });
                });
              });

              // Process movements for transitions
              const movements = slide.drawings.filter(d => ['arrow', 'line', 'curve', 'animpath'].includes(d.type));
              movements.forEach(movement => {
                // For tactical schemes, convert 9-zone to 18-zone system
                const startZone9 = getZoneNumber(movement.startX, movement.startY, canvasWidth, canvasHeight);
                const endZone9 = getZoneNumber(movement.endX, movement.endY, canvasWidth, canvasHeight);
                // Convert 9-zone (1-9) to approximate 18-zone (1-18) mapping
                // Zone 1-9 maps to: 1->1, 2->4, 3->7, 4->10, 5->13, 6->16, 7->3, 8->6, 9->9
                // Then add row offset: row 1 (zones 1-3) -> zones 1-6, row 2 (zones 4-6) -> zones 7-12, row 3 (zones 7-9) -> zones 13-18
                const convert9to18 = (zone9) => {
                  if (zone9 < 1 || zone9 > 9) return null;
                  const row = Math.floor((zone9 - 1) / 3); // 0, 1, or 2
                  const col = ((zone9 - 1) % 3); // 0, 1, or 2
                  // Map to 18-zone: each 9-zone maps to 2 zones in 18-zone system
                  // Row 0 (defensive): zones 1-3 -> zones 1-6 (2 zones each)
                  // Row 1 (midfield): zones 4-6 -> zones 7-12 (2 zones each)
                  // Row 2 (attacking): zones 7-9 -> zones 13-18 (2 zones each)
                  return row * 6 + col * 2 + 1; // Approximate mapping
                };
                const startZone = convert9to18(startZone9);
                const endZone = convert9to18(endZone9);
                const team = movement.team || 'Unknown';
                
                if (startZone && endZone && startZone !== endZone && startZone >= 1 && startZone <= 18 && endZone >= 1 && endZone <= 18) {
                  if (!zoneData.byTeam.has(team)) {
                    zoneData.byTeam.set(team, {
                      zones: new Map(),
                      transitions: []
                    });
                  }
                  const teamData = zoneData.byTeam.get(team);
                  
                  teamData.transitions.push({
                    from: startZone,
                    to: endZone,
                    event: movement.eventName || 'Movement',
                    type: 'scheme'
                  });
                }
              });
            }
          });
        }
      });
    }

    // Aggregate overall stats
    zoneData.byTeam.forEach((teamData, team) => {
      teamData.zones.forEach((stats, zoneNum) => {
        if (!zoneData.overall.zones.has(zoneNum)) {
          zoneData.overall.zones.set(zoneNum, initZoneStats());
        }
        const overallStats = zoneData.overall.zones.get(zoneNum);
        overallStats.totalEvents += stats.totalEvents;
        overallStats.attackingEvents += stats.attackingEvents;
        overallStats.defensiveEvents += stats.defensiveEvents;
        overallStats.errors += stats.errors;
        overallStats.goals += stats.goals;
        overallStats.shots += stats.shots;
        overallStats.dangerousAttacks += stats.dangerousAttacks;
        overallStats.recoveries += stats.recoveries;
        overallStats.pressingActions += stats.pressingActions;
        overallStats.coverageScore += stats.coverageScore;
        overallStats.productivityScore += stats.productivityScore;
      });
      zoneData.overall.transitions.push(...teamData.transitions);
    });

    return zoneData;
  }

  // Helper to get zones for a shape
  function getZonesForShape(shape, canvasWidth = 1000, canvasHeight = 600) {
    const zones = new Set();
    const points = [
      {x: shape.startX, y: shape.startY},
      {x: shape.endX, y: shape.startY},
      {x: shape.startX, y: shape.endY},
      {x: shape.endX, y: shape.endY},
      {x: (shape.startX + shape.endX) / 2, y: (shape.startY + shape.endY) / 2}
    ];
    points.forEach(p => {
      zones.add(getZoneNumber(p.x, p.y, canvasWidth, canvasHeight));
    });
    return Array.from(zones).sort((a, b) => a - b);
  }

  // Calculate zone statistics
  function calculateZoneStatistics(zoneData) {
    const stats = {
      byTeam: new Map(),
      overall: {
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      }
    };

    // Process each team
    zoneData.byTeam.forEach((teamData, team) => {
      const teamStats = {
        zones: [],
        mostActiveZones: [],
        mostProductiveZones: [],
        mostCoveredZones: [],
        mostVulnerableZones: [],
        transitionPatterns: []
      };

      // Calculate zone rankings
      const zoneArray = Array.from(teamData.zones.entries()).map(([zoneNum, zoneStats]) => ({
        zone: zoneNum,
        ...zoneStats
      }));

      teamStats.zones = zoneArray;
      teamStats.mostActiveZones = [...zoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
      teamStats.mostProductiveZones = [...zoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
      teamStats.mostCoveredZones = [...zoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
      teamStats.mostVulnerableZones = [...zoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
        .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

      // Analyze transition patterns
      const transitionMap = new Map();
      teamData.transitions.forEach(trans => {
        const key = `${trans.from}->${trans.to}`;
        if (!transitionMap.has(key)) {
          transitionMap.set(key, { from: trans.from, to: trans.to, count: 0, events: [] });
        }
        transitionMap.get(key).count++;
        transitionMap.get(key).events.push(trans.event);
      });
      teamStats.transitionPatterns = Array.from(transitionMap.values())
        .sort((a, b) => b.count - a.count).slice(0, 5);

      stats.byTeam.set(team, teamStats);
    });

    // Calculate overall stats
    const overallZoneArray = Array.from(zoneData.overall.zones.entries()).map(([zoneNum, zoneStats]) => ({
      zone: zoneNum,
      ...zoneStats
    }));

    stats.overall.mostActiveZones = [...overallZoneArray].sort((a, b) => b.totalEvents - a.totalEvents).slice(0, 3);
    stats.overall.mostProductiveZones = [...overallZoneArray].sort((a, b) => b.productivityScore - a.productivityScore).slice(0, 3);
    stats.overall.mostCoveredZones = [...overallZoneArray].sort((a, b) => b.coverageScore - a.coverageScore).slice(0, 3);
    stats.overall.mostVulnerableZones = [...overallZoneArray].filter(z => z.errors > 0 || z.coverageScore < 0)
      .sort((a, b) => (a.coverageScore - a.errors) - (b.coverageScore - b.errors)).slice(0, 3);

    // Overall transition patterns
    const overallTransitionMap = new Map();
    zoneData.overall.transitions.forEach(trans => {
      const key = `${trans.from}->${trans.to}`;
      if (!overallTransitionMap.has(key)) {
        overallTransitionMap.set(key, { from: trans.from, to: trans.to, count: 0 });
      }
      overallTransitionMap.get(key).count++;
    });
    stats.overall.transitionPatterns = Array.from(overallTransitionMap.values())
      .sort((a, b) => b.count - a.count).slice(0, 5);

    return stats;
  }

  // Identify game plan from zone stats and events
  function identifyGamePlan(zoneStats, events) {
    const gamePlan = {
      primaryAttackZones: [],
      primaryDefenseZones: [],
      buildUpPattern: '',
      finishingPattern: '',
      transitionStyle: ''
    };

    // Identify primary attack zones (high productivity)
    gamePlan.primaryAttackZones = zoneStats.mostProductiveZones
      .filter(z => z.attackingEvents > 0)
      .map(z => z.zone);

    // Identify primary defense zones (high coverage)
    gamePlan.primaryDefenseZones = zoneStats.mostCoveredZones
      .filter(z => z.defensiveEvents > 0)
      .map(z => z.zone);

            // Analyze build-up pattern (zones 1-6 to 7-12)
            const defensiveZones = zoneStats.zones.filter(z => z.zone >= 1 && z.zone <= 6 && z.totalEvents > 0);
            const midfieldZones = zoneStats.zones.filter(z => z.zone >= 7 && z.zone <= 12 && z.totalEvents > 0);
            if (defensiveZones.length > 0 && midfieldZones.length > 0) {
              gamePlan.buildUpPattern = `Builds from defensive zones (${defensiveZones.map(z => z.zone).join(', ')}) through midfield (${midfieldZones.map(z => z.zone).join(', ')})`;
            }

            // Analyze finishing pattern (zones 13-18)
            const attackingZones = zoneStats.zones.filter(z => z.zone >= 13 && z.zone <= 18 && z.attackingEvents > 0);
    if (attackingZones.length > 0) {
      gamePlan.finishingPattern = `Finishes in attacking zones: ${attackingZones.map(z => z.zone).join(', ')}`;
    }

    // Analyze transition style
    const forwardTransitions = zoneStats.transitionPatterns.filter(t => t.from < t.to);
    const backwardTransitions = zoneStats.transitionPatterns.filter(t => t.from > t.to);
    if (forwardTransitions.length > backwardTransitions.length) {
      gamePlan.transitionStyle = 'Forward-pressing, counter-attacking style';
    } else if (backwardTransitions.length > forwardTransitions.length) {
      gamePlan.transitionStyle = 'Possession-based, build-up style';
    } else {
      gamePlan.transitionStyle = 'Balanced transition style';
    }

    return gamePlan;
  }

  // Compare two teams' data
  function compareTeams(team1Data, team2Data) {
    const comparisons = {
      attackComparison: [],
      defenseComparison: [],
      tacticalMatchups: [],
      exploitationOpportunities: []
    };

    // Compare attack zones
    const team1AttackZones = team1Data.mostProductiveZones.map(z => z.zone);
    const team2DefenseZones = team2Data.mostCoveredZones.map(z => z.zone);
    const team2VulnerableZones = team2Data.mostVulnerableZones.map(z => z.zone);

    team1AttackZones.forEach(zone => {
      if (team2VulnerableZones.includes(zone)) {
        comparisons.exploitationOpportunities.push({
          type: 'attack',
          team1Zone: zone,
          team2Vulnerability: zone,
          description: `Team 1's strength in zone ${zone} matches Team 2's vulnerability`
        });
      }
    });

    // Compare defense zones
    const team1DefenseZones = team1Data.mostCoveredZones.map(z => z.zone);
    const team2AttackZones = team2Data.mostProductiveZones.map(z => z.zone);

    team2AttackZones.forEach(zone => {
      if (team1DefenseZones.includes(zone)) {
        comparisons.tacticalMatchups.push({
          type: 'defense',
          zone: zone,
          description: `Team 1's defensive strength in zone ${zone} will face Team 2's attacking strength`
        });
      }
    });

    return comparisons;
  }

  // formatDataForAI is now in ai-analysis-utils.js - use window.aiAnalysisUtils.formatDataForAI
  // Removed local implementation to use unified version

  // OpenAI API Integration
  async function callOpenAIAnalysis(prompt, apiKey) {
    const model = 'gpt-4o-mini'; // Using gpt-4o-mini as fallback (user mentioned gpt-5-mini-2025-08-07 which may not exist)
    
    try {
      const proxyFetch = window.aiAnalysisUtils?.proxyFetch || fetch;
      const response = await proxyFetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model,
          messages: [
            {
              role: 'system',
              content: window.aiAnalysisUtils.getSystemPrompt()
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          throw new Error('Invalid API key. Please check your OpenAI API key.');
        } else if (response.status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        } else if (response.status === 500 || response.status === 503) {
          throw new Error('OpenAI service is temporarily unavailable. Please try again later.');
        } else {
          throw new Error(errorData.error?.message || `API error: ${response.status}`);
        }
      }

      const data = await response.json();
      if (data.choices && data.choices.length > 0 && data.choices[0].message) {
        return data.choices[0].message.content;
      } else {
        throw new Error('Unexpected response format from OpenAI API');
      }
    } catch (error) {
      if (error.message) {
        throw error;
      } else if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your internet connection.');
      } else {
        throw new Error('An unexpected error occurred while calling OpenAI API.');
      }
    }
  }

  // UI Functions
  function showAPISettingsModal() {
    const modal = document.getElementById('apiKeySettingsModal');
    const apiKeyInput = document.getElementById('apiKeyInput');
    const languageSelect = document.getElementById('apiKeyLanguageSelect');
    const interfaceLanguageSelect = document.getElementById('interfaceLanguageSelect');
    const errorDiv = document.getElementById('apiKeyError');
    const successDiv = document.getElementById('apiKeySuccess');
    const deleteBtn = document.getElementById('deleteApiKeyBtn');

    if (!modal || !apiKeyInput) return;

    errorDiv.style.display = 'none';
    successDiv.style.display = 'none';
    apiKeyInput.value = '';

    // Set interface language selector
    if (interfaceLanguageSelect && window.i18n) {
      interfaceLanguageSelect.value = window.i18n.getCurrentLanguage();
    }

    // Load both API key and language preference
    Promise.all([
      loadOpenAIKey(),
      new Promise((resolve) => {
        chrome.storage.local.get(['ai_analysis_language'], (result) => {
          resolve(result.ai_analysis_language || 'auto');
        });
      })
    ]).then(([key, language]) => {
      if (key) {
        // Show that key exists but don't display it
        apiKeyInput.placeholder = 'API key is set (enter new key to update)';
        deleteBtn.style.display = 'block';
      } else {
        apiKeyInput.placeholder = 'sk-...';
        deleteBtn.style.display = 'none';
      }
      
      // Set language preference
      if (languageSelect) {
        languageSelect.value = language;
      }
      
      modal.classList.remove('hidden');
      apiKeyInput.focus();
    }).catch(err => {
      console.error('Error loading settings:', err);
      if (languageSelect) {
        languageSelect.value = 'auto';
      }
      modal.classList.remove('hidden');
      apiKeyInput.focus();
    });
  }

  // Store current analysis data for citation previews
  let currentAnalysisDataForPreview = null;

  // Parse citations and convert to clickable links
  function parseCitations(text, analysisData) {
    if (!text || !analysisData) {
      console.warn('parseCitations: Missing text or analysisData', { hasText: !!text, hasData: !!analysisData });
      return text;
    }

    console.log('parseCitations: Starting with', {
      textLength: text.length,
      notesCount: analysisData.notes ? analysisData.notes.length : 0,
      schemesCount: analysisData.tacticalSchemes ? analysisData.tacticalSchemes.length : 0,
      markersCount: analysisData.timelineMarkers ? analysisData.timelineMarkers.length : 0,
      imagesCount: analysisData.regularImages ? analysisData.regularImages.length : 0
    });

    // Pattern to match citations like (Note 5), (Note 5, Note 6), (Scheme 1), (Timeline Marker 2), (Image 3)
    // Also handles variations like (Notes 5, 6) or (Note 5; Note 6)
    // Also handles translated terms like (Заметка 5), (Napomena 3), etc.
    const citationPattern = /\(([^)]+)\)/g;
    
    // Citation term patterns for different languages (case-insensitive)
    const citationPatterns = {
      note: /(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Note)\s+(\d+)/i,
      scheme: /(?:Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Schema|Esquema)\s+(\d+)/i,
      marker: /(?:Timeline\s+Marker|Маркер|Marker|Marcador|Marqueur|Marcatore|Marcador)\s+(\d+)|(?:Marker|Маркер|Marker|Marcador|Marqueur|Marcatore|Marcador)\s+(\d+)/i,
      image: /(?:Image|Изображение|Slika|Bild|Obraz|Imagen|Image|Immagine|Imagem)\s+(\d+)/i
    };
    
    return text.replace(citationPattern, (match, citationText) => {
      // Check if this looks like a citation (contains Note, Scheme, Marker, Image or their translations)
      if (!/(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Marker|Маркер|Marcador|Marqueur|Marcatore|Image|Изображение|Slika|Bild|Obraz|Imagen|Immagine|Imagem)/i.test(citationText)) {
        return match; // Not a citation, return as-is
      }
      
      console.log('parseCitations: Found potential citation:', citationText);
      
      // Normalize separators (handle both comma and semicolon)
      citationText = citationText.replace(/;/g, ',');

      // Parse individual items
      let items = citationText.split(',').map(item => item.trim());
      const citationItems = [];

      // Handle cases like "Notes 5, 6, 8" or "Заметки 5, 6, 8" - expand to individual notes
      const notesMatch = citationText.match(/(?:Notes?|Заметки?|Napomene?|Notizen?|Notatki?|Notas?)\s+(\d+(?:\s*,\s*\d+)*)/i);
      if (notesMatch) {
        const numbers = notesMatch[1].split(',').map(n => n.trim());
        // Keep original format but expand to individual items
        items = numbers.map(n => {
          // Try to detect the language from the original text
          if (/Заметк/i.test(citationText)) return `Заметка ${n}`;
          if (/Napomen/i.test(citationText)) return `Napomena ${n}`;
          if (/Notiz/i.test(citationText)) return `Notiz ${n}`;
          if (/Notatk/i.test(citationText)) return `Notatka ${n}`;
          return `Note ${n}`;
        });
      }

      items.forEach(item => {
        const noteMatch = item.match(citationPatterns.note);
        const schemeMatch = item.match(citationPatterns.scheme);
        const markerMatch = item.match(citationPatterns.marker);
        const imageMatch = item.match(citationPatterns.image);

        if (noteMatch) {
          const noteIndex = parseInt(noteMatch[1]) - 1; // Convert to 0-based index
          if (analysisData.notes && analysisData.notes[noteIndex]) {
            citationItems.push({ type: 'note', index: noteIndex, number: noteMatch[1] });
          }
        } else if (schemeMatch) {
          const schemeIndex = parseInt(schemeMatch[1]) - 1;
          if (analysisData.tacticalSchemes && analysisData.tacticalSchemes[schemeIndex]) {
            citationItems.push({ type: 'scheme', index: schemeIndex, number: schemeMatch[1] });
          }
        } else if (markerMatch) {
          const markerIndex = parseInt(markerMatch[1] || markerMatch[2]) - 1;
          if (analysisData.timelineMarkers && analysisData.timelineMarkers[markerIndex]) {
            citationItems.push({ type: 'marker', index: markerIndex, number: markerMatch[1] || markerMatch[2] });
          }
        } else if (imageMatch) {
          const imageIndex = parseInt(imageMatch[1]) - 1;
          if (analysisData.regularImages && analysisData.regularImages[imageIndex]) {
            citationItems.push({ type: 'image', index: imageIndex, number: imageMatch[1] });
          }
        }
      });

      if (citationItems.length === 0) {
        console.log('parseCitations: No valid citations found for:', citationText);
        return match; // No valid citations found, return as-is
      }

      console.log('parseCitations: Created citation link with items:', citationItems);
      
      // Create separate clickable links for each citation item with inline collapsible blocks
      if (citationItems.length === 1) {
        // Single citation - one link with one block after it
        const citationId = `citation-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const item = citationItems[0];
        // Preserve original citation text format
        const citationLabel = match.replace(/[()]/g, ''); // Remove parentheses
        const blockId = `citation-block-${citationId}`;
        return `<span class="ai-citation-link" data-citation-id="${citationId}" data-block-id="${blockId}" data-items='${JSON.stringify(citationItems)}' style="color: #58a6ff; text-decoration: underline; cursor: pointer; border-bottom: 1px dotted #58a6ff; margin: 0 2px;">(${citationLabel})</span><div id="${blockId}" class="ai-citation-block collapsed" data-items='${JSON.stringify(citationItems)}'></div>`;
      } else {
        // Multiple citations - separate links for each, blocks after closing parenthesis
        const baseId = Date.now();
        const links = citationItems.map((item, idx) => {
          const citationId = `${baseId}-${idx}-${Math.random().toString(36).substr(2, 9)}`;
          const blockId = `citation-block-${citationId}`;
          // Get the original text for this specific item from the citationText
          let itemText = '';
          const itemPattern = new RegExp(`(?:Note|Заметка|Napomena|Notiz|Notatka|Nota|Scheme|Схема|Šema|Schema|Schemat|Esquema|Schéma|Marker|Маркер|Marcador|Marqueur|Marcatore|Image|Изображение|Slika|Bild|Obraz|Imagen|Immagine|Imagem)\\s+${item.number}`, 'i');
          const itemMatch = citationText.match(itemPattern);
          if (itemMatch) {
            itemText = itemMatch[0];
          } else {
            // Fallback to English
            const typeLabels = { note: 'Note', scheme: 'Scheme', marker: 'Marker', image: 'Image' };
            itemText = `${typeLabels[item.type] || 'Note'} ${item.number}`;
          }
          return {
            link: `<span class="ai-citation-link" data-citation-id="${citationId}" data-block-id="${blockId}" data-items='${JSON.stringify([item])}' style="color: #58a6ff; text-decoration: underline; cursor: pointer; border-bottom: 1px dotted #58a6ff; margin: 0 2px;">${itemText}</span>`,
            block: `<div id="${blockId}" class="ai-citation-block collapsed" data-items='${JSON.stringify([item])}'></div>`
          };
        });
        // Combine links and place all blocks after closing parenthesis
        const linkTexts = links.map(l => l.link).join(', ');
        const blocks = links.map(l => l.block).join('');
        return `(${linkTexts})${blocks}`;
      }
    });
  }

  // Render scheme slides as images inline
  async function renderSchemeInline(scheme, container) {
    if (!scheme || !scheme.slidesData || scheme.slidesData.length === 0) {
      container.innerHTML = '<div style="color: #8b949e; padding: 12px; text-align: center;">No scheme data available</div>';
      return;
    }

    const timecode = scheme.timecode ? scheme.timecode[0] : (scheme.videoTime ? `[${Math.floor(scheme.videoTime / 60)}:${String(Math.floor(scheme.videoTime % 60)).padStart(2, '0')}]` : '');
    
    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 12px; font-size: 14px;">Tactical Scheme ${timecode}</div>`;

    // Use default football field background
    const defaultBackground = chrome.runtime.getURL('icons/soccer-145794.svg');
    
    // Render each slide
    for (let slideIndex = 0; slideIndex < scheme.slidesData.length; slideIndex++) {
      const slide = scheme.slidesData[slideIndex];
      const drawings = slide.drawings || [];
      
      if (drawings.length > 0) {
        try {
          const renderedImage = await renderImagePreviewWithDrawings(defaultBackground, drawings);
          html += `<div style="margin-bottom: 16px;">
            <div style="font-size: 12px; color: #8b949e; margin-bottom: 8px;">Slide ${slideIndex + 1}</div>
            <img src="${renderedImage}" style="max-width: 100%; border-radius: 6px; border: 1px solid #21262d; background: #0d1117;" alt="Scheme slide ${slideIndex + 1}">
          </div>`;
        } catch (error) {
          console.error('Error rendering scheme slide:', error);
          html += `<div style="color: #f85149; padding: 8px; margin-bottom: 8px;">Error rendering slide ${slideIndex + 1}</div>`;
        }
      }
    }
    
    html += `</div>`;
    container.innerHTML = html;
  }

  // Format note for inline display
  function formatNoteInline(note) {
    if (!note) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Note not found</div>';
    }

    const timecode = note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null;
    const timecodeStr = timecode ? timecode[0] : (note.videoTime ? `[${Math.floor(note.videoTime / 60)}:${String(Math.floor(note.videoTime % 60)).padStart(2, '0')}]` : '');
    const noteText = note.text || note.content || '';
    const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Note ${timecodeStr}</div>`;
    
    if (cleanText && cleanText.trim().length > 0) {
      html += `<div style="color: #c9d1d9; margin-bottom: 12px; white-space: pre-wrap; line-height: 1.6; font-size: 13px;">${escapeHtml(cleanText)}</div>`;
    } else {
      html += `<div style="color: #8b949e; font-style: italic; margin-bottom: 12px;">(No text content)</div>`;
    }
    
    // Add metadata
    const metadata = [];
    if (note.team || (note.teams && note.teams.length > 0)) {
      metadata.push(`Team: ${note.team || note.teams.join(', ')}`);
    }
    if (note.players && note.players.length > 0) {
      const playerNames = note.players.map(p => typeof p === 'string' ? p : (p.name || p.id)).join(', ');
      metadata.push(`Players: ${playerNames}`);
    }
    if (note.events && note.events.length > 0) {
      metadata.push(`Events: ${note.events.join(', ')}`);
    }
    if (note.zones && note.zones.length > 0) {
      metadata.push(`Zones: ${note.zones.join(', ')}`);
    }
    if (note.intensity !== null && note.intensity !== undefined) {
      const intensityLabels = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
      metadata.push(`Intensity: ${intensityLabels[note.intensity] || note.intensity}`);
    }
    
    if (metadata.length > 0) {
      html += `<div style="font-size: 12px; color: #8b949e; margin-top: 8px; padding-top: 8px; border-top: 1px solid #21262d;">${metadata.join(' • ')}</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Format marker for inline display
  function formatMarkerInline(marker) {
    if (!marker) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Marker not found</div>';
    }

    const minutes = Math.floor(marker.time / 60);
    const seconds = Math.floor(marker.time % 60);
    const timecodeStr = `[${minutes}:${String(seconds).padStart(2, '0')}]`;

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Timeline Marker ${timecodeStr}</div>`;
    
    const metadata = [];
    if (marker.team) {
      metadata.push(`Team: ${marker.team}`);
    }
    if (marker.eventType) {
      metadata.push(`Event: ${marker.eventType}`);
    }
    
    if (metadata.length > 0) {
      html += `<div style="color: #c9d1d9; margin-bottom: 8px; font-size: 13px;">${metadata.join(' • ')}</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Format image for inline display
  function formatImageInline(image) {
    if (!image) {
      return '<div style="color: #8b949e; padding: 12px; text-align: center;">Image not found</div>';
    }

    const timecode = image.timecode ? image.timecode[0] : (image.videoTime ? `[${Math.floor(image.videoTime / 60)}:${String(Math.floor(image.videoTime % 60)).padStart(2, '0')}]` : '');

    let html = `<div style="margin-bottom: 16px;">
      <div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px; font-size: 14px;">Image ${timecode}</div>`;
    
    if (image.imageData) {
      html += `<img src="${image.imageData}" style="max-width: 100%; border-radius: 6px; margin-top: 8px; border: 1px solid #21262d;" alt="Image">`;
    } else {
      html += `<div style="color: #8b949e; font-style: italic;">No image data available</div>`;
    }
    
    html += `</div>`;
    return html;
  }

  // Toggle citation block and populate content
  async function toggleCitationBlock(citationLink, blockElement, items) {
    if (!currentAnalysisDataForPreview) {
      console.warn('No analysis data available');
      return;
    }

    const isCollapsed = blockElement.classList.contains('collapsed');
    
    if (isCollapsed) {
      // Expand block
      blockElement.classList.remove('collapsed');
      
      // Populate content if empty
      if (!blockElement.dataset.populated) {
        let contentHTML = '';
        
        for (let idx = 0; idx < items.length; idx++) {
          const item = items[idx];
          
          if (idx > 0) {
            contentHTML += '<hr style="border: none; border-top: 1px solid #21262d; margin: 16px 0;">';
          }

          if (item.type === 'note') {
            const note = currentAnalysisDataForPreview.notes && currentAnalysisDataForPreview.notes[item.index];
            if (note) {
              contentHTML += formatNoteInline(note);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Note ${item.number} - Not Found</div>`;
            }
          } else if (item.type === 'scheme') {
            const scheme = currentAnalysisDataForPreview.tacticalSchemes && currentAnalysisDataForPreview.tacticalSchemes[item.index];
            if (scheme) {
              const schemeId = `scheme-${item.index}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
              contentHTML += `<div id="${schemeId}" class="scheme-render-container" data-scheme-index="${item.index}"></div>`;
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Scheme ${item.number} - Not Found</div>`;
            }
          } else if (item.type === 'marker') {
            const marker = currentAnalysisDataForPreview.timelineMarkers && currentAnalysisDataForPreview.timelineMarkers[item.index];
            if (marker) {
              contentHTML += formatMarkerInline(marker);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Marker ${item.number} - Not Found</div>`;
            }
          } else if (item.type === 'image') {
            const image = currentAnalysisDataForPreview.regularImages && currentAnalysisDataForPreview.regularImages[item.index];
            if (image) {
              contentHTML += formatImageInline(image);
            } else {
              contentHTML += `<div style="color: #f85149; padding: 12px;">Image ${item.number} - Not Found</div>`;
            }
          }
        }
        
        blockElement.innerHTML = contentHTML;
        blockElement.dataset.populated = 'true';
        
        // Render schemes after HTML is set
        const schemeContainers = blockElement.querySelectorAll('.scheme-render-container');
        for (const container of schemeContainers) {
          const schemeIndex = parseInt(container.dataset.schemeIndex);
          const scheme = currentAnalysisDataForPreview.tacticalSchemes && currentAnalysisDataForPreview.tacticalSchemes[schemeIndex];
          if (scheme) {
            await renderSchemeInline(scheme, container);
          }
        }
      }
    } else {
      // Collapse block
      blockElement.classList.add('collapsed');
    }
  }

  function showAIAnalysisResults(results, error = null) {
    const modal = document.getElementById('aiAnalysisResultsModal');
    const loadingDiv = document.getElementById('aiAnalysisLoading');
    const errorDiv = document.getElementById('aiAnalysisError');
    const contentDiv = document.getElementById('aiAnalysisContent');
    const resultsDiv = document.getElementById('aiAnalysisResults');
    const errorMessageDiv = document.getElementById('aiAnalysisErrorMessage');
    const saveBtn = document.getElementById('saveAiAnalysisBtn');

    if (!modal) return;

    loadingDiv.style.display = 'none';
    errorDiv.style.display = 'none';
    contentDiv.style.display = 'none';
    saveBtn.style.display = 'none';

    if (error) {
      errorMessageDiv.textContent = error;
      errorDiv.style.display = 'block';
    } else if (results) {
      // Store original text with markdown preserved for saving
      originalAIAnalysisText = results;
      
      // Strip any markdown formatting that might have slipped through for display
      let cleanedResults = results
        .replace(/\*\*(.*?)\*\*/g, '$1') // Remove **bold**
        .replace(/\*(.*?)\*/g, '$1') // Remove *italic* (but not in citations)
        .replace(/__(.*?)__/g, '$1') // Remove __underline__
        .replace(/_(.*?)_/g, '$1') // Remove _italic_
        .replace(/###\s*(.*?)$/gm, '$1') // Remove ### headers
        .replace(/##\s*(.*?)$/gm, '$1') // Remove ## headers
        .replace(/#\s*(.*?)$/gm, '$1'); // Remove # headers
      
      // Parse citations and convert to clickable links with inline blocks
      const parsedResults = parseCitations(cleanedResults, currentAnalysisDataForPreview);
      resultsDiv.innerHTML = parsedResults;
      
      // Add click handlers to citation links for inline expansion
      resultsDiv.querySelectorAll('.ai-citation-link').forEach(link => {
        link.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();
          const blockId = link.dataset.blockId;
          // Get items from the link, or from the block if link has single item
          let items = JSON.parse(link.dataset.items);
          const blockElement = document.getElementById(blockId);
          
          if (blockElement) {
            // If block has multiple items stored, use those instead
            if (blockElement.dataset.items) {
              items = JSON.parse(blockElement.dataset.items);
            }
            await toggleCitationBlock(link, blockElement, items);
          } else {
            console.warn('Citation block not found:', blockId);
          }
        });
      });
      
      contentDiv.style.display = 'block';
      saveBtn.style.display = 'block';
      
      // Show footer only if Save button is visible
      const footer = modal.querySelector('.project-modal-footer');
      if (footer) {
        footer.style.display = 'flex';
      }
    } else {
      // Hide footer when there's an error
      const footer = modal.querySelector('.project-modal-footer');
      if (footer) {
        footer.style.display = 'none';
      }
    }

    modal.classList.remove('hidden');
  }

  function showCitationPreview(citationItems) {
    console.log('showCitationPreview called with:', citationItems);
    console.log('currentAnalysisDataForPreview:', currentAnalysisDataForPreview);
    
    if (!citationItems || citationItems.length === 0) {
      console.warn('No citation items provided');
      return;
    }
    
    if (!currentAnalysisDataForPreview) {
      console.warn('No analysis data available for preview');
      alert('Analysis data not available. Please run the analysis again.');
      return;
    }

    const modal = document.getElementById('citationPreviewModal');
    const title = document.getElementById('citationPreviewTitle');
    const content = document.getElementById('citationPreviewContent');

    if (!modal || !content) {
      console.error('Citation preview modal elements not found');
      return;
    }

    let previewHTML = '';
    let foundItems = 0;

    for (let idx = 0; idx < citationItems.length; idx++) {
      const item = citationItems[idx];
      
      if (idx > 0) {
        previewHTML += '<hr style="border: none; border-top: 1px solid #21262d; margin: 20px 0;">';
      }

      if (item.type === 'note') {
        console.log(`Checking note ${item.number} at index ${item.index}`);
        console.log(`Total notes: ${currentAnalysisDataForPreview.notes ? currentAnalysisDataForPreview.notes.length : 0}`);
        
        if (!currentAnalysisDataForPreview.notes || !currentAnalysisDataForPreview.notes[item.index]) {
          previewHTML += `<div style="margin-bottom: 16px; color: #f85149;">`;
          previewHTML += `<div style="font-weight: 600; color: #f85149; margin-bottom: 8px;">Note ${item.number} - Not Found</div>`;
          previewHTML += `<div style="color: #8b949e; font-size: 12px;">This note reference could not be found in the analysis data.</div>`;
          previewHTML += `</div>`;
          continue; // Continue to next item instead of returning
        }
        
        const note = currentAnalysisDataForPreview.notes[item.index];
        foundItems++;
        console.log('Found note:', note);
        const timecode = note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null;
        const timecodeStr = timecode ? timecode[0] : (note.videoTime ? `[${Math.floor(note.videoTime / 60)}:${String(Math.floor(note.videoTime % 60)).padStart(2, '0')}]` : '');
        const noteText = note.text || note.content || '';
        const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');

        previewHTML += `<div style="margin-bottom: 16px;">`;
        previewHTML += `<div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px;">Note ${item.number} ${timecodeStr}</div>`;
        
        if (cleanText && cleanText.trim().length > 0) {
          previewHTML += `<div style="color: #c9d1d9; margin-bottom: 8px; white-space: pre-wrap; line-height: 1.6;">${escapeHtml(cleanText)}</div>`;
        } else {
          previewHTML += `<div style="color: #8b949e; font-style: italic; margin-bottom: 8px;">(No text content)</div>`;
        }
        
        if (note.team || (note.teams && note.teams.length > 0)) {
          previewHTML += `<div style="font-size: 12px; color: #8b949e; margin-top: 4px;">Team: ${note.team || note.teams.join(', ')}</div>`;
        }
        if (note.players && note.players.length > 0) {
          const playerNames = note.players.map(p => typeof p === 'string' ? p : (p.name || p.id)).join(', ');
          previewHTML += `<div style="font-size: 12px; color: #8b949e; margin-top: 4px;">Players: ${playerNames}</div>`;
        }
        if (note.events && note.events.length > 0) {
          previewHTML += `<div style="font-size: 12px; color: #8b949e; margin-top: 4px;">Events: ${note.events.join(', ')}</div>`;
        }
        if (note.zones && note.zones.length > 0) {
          previewHTML += `<div style="font-size: 12px; color: #8b949e; margin-top: 4px;">Zones: ${note.zones.join(', ')}</div>`;
        }
        if (note.intensity !== null && note.intensity !== undefined) {
          const intensityLabels = ['Full defense', 'Defense', 'Balance', 'Attack', 'Full attack'];
          previewHTML += `<div style="font-size: 12px; color: #8b949e; margin-top: 4px;">Intensity: ${intensityLabels[note.intensity] || note.intensity}</div>`;
        }
        previewHTML += `</div>`;
      } else if (item.type === 'scheme') {
        if (!currentAnalysisDataForPreview.tacticalSchemes || !currentAnalysisDataForPreview.tacticalSchemes[item.index]) {
          previewHTML += `<div style="margin-bottom: 16px; color: #f85149;">`;
          previewHTML += `<div style="font-weight: 600; color: #f85149; margin-bottom: 8px;">Scheme ${item.number} - Not Found</div>`;
          previewHTML += `<div style="color: #8b949e; font-size: 12px;">This scheme reference could not be found in the analysis data.</div>`;
          previewHTML += `</div>`;
          continue; // Continue to next item instead of returning
        }
        
        foundItems++;
        const scheme = currentAnalysisDataForPreview.tacticalSchemes[item.index];
        const timecode = scheme.timecode ? scheme.timecode[0] : (scheme.videoTime ? `[${Math.floor(scheme.videoTime / 60)}:${String(Math.floor(scheme.videoTime % 60)).padStart(2, '0')}]` : '');

        previewHTML += `<div style="margin-bottom: 16px;">`;
        previewHTML += `<div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px;">Tactical Scheme ${item.number} ${timecode}</div>`;
        previewHTML += `<div style="color: #c9d1d9; margin-bottom: 8px;">Contains ${scheme.slides.length} slide(s) with tactical drawings</div>`;
        
        // Render scheme slides with drawings (including movement lines)
        if (scheme.slidesData && scheme.slidesData.length > 0) {
          const schemeContainerId = `scheme-preview-${item.index}-${Date.now()}`;
          previewHTML += `<div id="${schemeContainerId}" style="margin-top: 12px;"></div>`;
          
          // Render asynchronously after HTML is inserted
          setTimeout(async () => {
            const container = document.getElementById(schemeContainerId);
            if (container) {
              await renderSchemeInline(scheme, container);
            }
          }, 100);
        }
        
        previewHTML += `</div>`;
      } else if (item.type === 'marker') {
        if (!currentAnalysisDataForPreview.timelineMarkers || !currentAnalysisDataForPreview.timelineMarkers[item.index]) {
          previewHTML += `<div style="margin-bottom: 16px; color: #f85149;">`;
          previewHTML += `<div style="font-weight: 600; color: #f85149; margin-bottom: 8px;">Timeline Marker ${item.number} - Not Found</div>`;
          previewHTML += `<div style="color: #8b949e; font-size: 12px;">This marker reference could not be found in the analysis data.</div>`;
          previewHTML += `</div>`;
          continue; // Continue to next item instead of returning
        }
        
        foundItems++;
        const marker = currentAnalysisDataForPreview.timelineMarkers[item.index];
        const minutes = Math.floor(marker.time / 60);
        const seconds = Math.floor(marker.time % 60);
        const timecodeStr = `[${minutes}:${String(seconds).padStart(2, '0')}]`;

        previewHTML += `<div style="margin-bottom: 16px;">`;
        previewHTML += `<div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px;">Timeline Marker ${item.number} ${timecodeStr}</div>`;
        if (marker.team) {
          previewHTML += `<div style="color: #c9d1d9; margin-bottom: 8px;">Team: ${marker.team}</div>`;
        }
        if (marker.eventType) {
          previewHTML += `<div style="color: #c9d1d9; margin-bottom: 8px;">Event: ${marker.eventType}</div>`;
        }
        previewHTML += `</div>`;
      } else if (item.type === 'image') {
        if (!currentAnalysisDataForPreview.regularImages || !currentAnalysisDataForPreview.regularImages[item.index]) {
          previewHTML += `<div style="margin-bottom: 16px; color: #f85149;">`;
          previewHTML += `<div style="font-weight: 600; color: #f85149; margin-bottom: 8px;">Image ${item.number} - Not Found</div>`;
          previewHTML += `<div style="color: #8b949e; font-size: 12px;">This image reference could not be found in the analysis data.</div>`;
          previewHTML += `</div>`;
          continue; // Continue to next item instead of returning
        }
        
        foundItems++;
        const image = currentAnalysisDataForPreview.regularImages[item.index];
        const timecode = image.timecode ? image.timecode[0] : (image.videoTime ? `[${Math.floor(image.videoTime / 60)}:${String(Math.floor(image.videoTime % 60)).padStart(2, '0')}]` : '');

        previewHTML += `<div style="margin-bottom: 16px;">`;
        previewHTML += `<div style="font-weight: 600; color: #58a6ff; margin-bottom: 8px;">Image ${item.number} ${timecode}</div>`;
        previewHTML += `<div style="color: #c9d1d9; margin-bottom: 8px;">Attached image (screenshot/photo)</div>`;
        if (image.imageData) {
          previewHTML += `<img src="${image.imageData}" style="max-width: 100%; border-radius: 6px; margin-top: 8px; border: 1px solid #21262d;" alt="Image ${item.number}">`;
        }
        previewHTML += `</div>`;
      }
    }

    if (previewHTML) {
      if (foundItems === 0) {
        previewHTML = `<div style="color: #f85149; text-align: center; padding: 20px;">No valid citations found. The referenced items may not exist in the analysis data.</div>`;
      }
      
      content.innerHTML = previewHTML;
      if (title) {
        title.textContent = `Citation Preview (${foundItems}/${citationItems.length} found)`;
      }
      modal.classList.remove('hidden');
    } else {
      content.innerHTML = `<div style="color: #f85149; text-align: center; padding: 20px;">Unable to display citation preview.</div>`;
      modal.classList.remove('hidden');
    }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ========== AI ENHANCEMENT FUNCTIONS ==========
  
  function openAiEnhancementModal() {
    const modal = document.getElementById('aiEnhancementModal');
    if (!modal) {
      console.error('aiEnhancementModal not found');
      return;
    }
    
    // Reset modal state
    const progressDiv = document.getElementById('enhancementProgress');
    const resultsDiv = document.getElementById('enhancementResults');
    const errorDiv = document.getElementById('enhancementError');
    const startBtn = document.getElementById('startAiEnhancementBtn');
    const okBtn = document.getElementById('okAiEnhancementBtn');
    const footer = modal.querySelector('.project-modal-footer');
    const scopeSelect = document.getElementById('enhancementScopeSelect');
    
    if (progressDiv) progressDiv.style.display = 'none';
    if (resultsDiv) resultsDiv.style.display = 'none';
    if (errorDiv) {
      errorDiv.style.display = 'none';
      errorDiv.textContent = '';
    }
    if (startBtn) {
      startBtn.disabled = false;
      startBtn.style.display = 'block';
    }
    if (okBtn) {
      okBtn.style.display = 'none';
    }
    if (footer) footer.style.display = 'flex';
    if (scopeSelect) {
      scopeSelect.value = 'all';
    }
    
    modal.classList.remove('hidden');
  }

  function closeAiEnhancementModal() {
    const modal = document.getElementById('aiEnhancementModal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  // Helper function to resolve an extracted team name to an existing team in the library
  // Returns the canonical team name if found, or null if no match
  function resolveToExistingTeam(teamName, teams) {
    if (!teamName || typeof teamName !== 'string') return null;
    const trimmedName = teamName.trim();
    if (trimmedName.length === 0) return null;
    
    const teamNameLower = trimmedName.toLowerCase();
    
    // First try exact match (case-insensitive)
    let exactMatch = teams.find(t => {
      const existingName = typeof t === 'string' ? t : (t.name || '');
      return existingName.toLowerCase() === teamNameLower;
    });
    
    if (exactMatch) {
      return typeof exactMatch === 'string' ? exactMatch : (exactMatch.name || null);
    }
    
    // Try fuzzy match: existing team name contains extracted name or vice versa
    let fuzzyMatches = teams.filter(t => {
      const existingName = typeof t === 'string' ? t : (t.name || '');
      const existingLower = existingName.toLowerCase();
      return existingLower.includes(teamNameLower) || teamNameLower.includes(existingLower);
    });
    
    if (fuzzyMatches.length > 0) {
      // Prefer the shortest match (more specific) or first match
      fuzzyMatches.sort((a, b) => {
        const nameA = typeof a === 'string' ? a : (a.name || '');
        const nameB = typeof b === 'string' ? b : (b.name || '');
        return nameA.length - nameB.length;
      });
      const bestMatch = fuzzyMatches[0];
      return typeof bestMatch === 'string' ? bestMatch : (bestMatch.name || null);
    }
    
    return null;
  }

  // Helper function to resolve an extracted player name to an existing player in the library
  // Returns the player object if found, or null if no match
  function resolveToExistingPlayer(playerName, players) {
    if (!playerName || typeof playerName !== 'string') return null;
    const trimmedName = playerName.trim();
    if (trimmedName.length === 0) return null;
    
    // Skip if it looks like message text (too long, contains sentence-ending punctuation)
    if (trimmedName.length > 100 || trimmedName.includes('!') || trimmedName.includes('?') || trimmedName.includes('.')) {
      return null;
    }
    
    const playerNameLower = trimmedName.toLowerCase();
    
    // Try to match by fullName, name, surname, or partial match
    const matched = players.find(p => {
      const fullName = (p.fullName || '').toLowerCase();
      const name = (p.name || '').toLowerCase();
      const surname = (p.surname || '').toLowerCase();
      return fullName === playerNameLower || 
             name === playerNameLower || 
             surname === playerNameLower ||
             fullName.includes(playerNameLower) ||
             playerNameLower.includes(fullName);
    });
    
    return matched || null;
  }

  // Helper function to create a team from unresolved list (always creates, doesn't check existence)
  async function createTeamFromUnresolved(teamName) {
    return new Promise((resolve) => {
      if (!teamName || typeof teamName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = teamName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['teams'], (result) => {
        const teams = result.teams || [];
        
        // Create new team
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: trimmedName,
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        chrome.storage.local.set({ teams: teams }, () => {
          console.log('Created team from unresolved:', trimmedName);
          resolve(newTeam);
        });
      });
    });
  }

  // Helper function to create a player from unresolved list (always creates, doesn't check existence)
  async function createPlayerFromUnresolved(playerName) {
    return new Promise((resolve) => {
      if (!playerName || typeof playerName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Create new player
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: '',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          console.log('Created player from unresolved:', trimmedName);
          resolve(newPlayer);
        });
      });
    });
  }

  // Helper function to create a team and attach it to specified comments
  async function createTeamAndAttachToComments(teamName, commentRefs) {
    return new Promise((resolve) => {
      if (!teamName || typeof teamName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = teamName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['teams', 'analyses'], (result) => {
        const teams = result.teams || [];
        const analyses = result.analyses || [];
        
        // Create new team
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: trimmedName,
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        
        // Attach team to all referenced comments
        if (commentRefs && commentRefs.length > 0) {
          commentRefs.forEach(ref => {
            const analysisIndex = analyses.findIndex(a => a.id === ref.analysisId);
            if (analysisIndex !== -1) {
              const noteIndex = analyses[analysisIndex].notes.findIndex(n => n.timestamp === ref.timestamp);
              if (noteIndex !== -1) {
                const note = analyses[analysisIndex].notes[noteIndex];
                // Add team to note.teams array
                if (!note.teams) {
                  note.teams = [];
                }
                if (!note.teams.includes(trimmedName)) {
                  note.teams.push(trimmedName);
                }
                // Update note.team for backward compatibility
                if (!note.team) {
                  note.team = trimmedName;
                }
              }
            }
          });
        }
        
        chrome.storage.local.set({ teams: teams, analyses: analyses }, () => {
          console.log('Created team and attached to comments:', trimmedName, commentRefs);
          resolve(newTeam);
        });
      });
    });
  }

  // Helper function to create a player and attach it to specified comments
  async function createPlayerAndAttachToComments(playerName, commentRefs) {
    return new Promise((resolve) => {
      if (!playerName || typeof playerName !== 'string') {
        resolve(null);
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve(null);
        return;
      }
      
      chrome.storage.local.get(['players', 'analyses'], (result) => {
        const players = result.players || [];
        const analyses = result.analyses || [];
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Create new player
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: '',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        
        // Attach player to all referenced comments
        if (commentRefs && commentRefs.length > 0) {
          commentRefs.forEach(ref => {
            const analysisIndex = analyses.findIndex(a => a.id === ref.analysisId);
            if (analysisIndex !== -1) {
              const noteIndex = analyses[analysisIndex].notes.findIndex(n => n.timestamp === ref.timestamp);
              if (noteIndex !== -1) {
                const note = analyses[analysisIndex].notes[noteIndex];
                // Add player ID to note.players array
                if (!note.players) {
                  note.players = [];
                }
                if (!note.players.includes(newPlayer.id)) {
                  note.players.push(newPlayer.id);
                }
              }
            }
          });
        }
        
        chrome.storage.local.set({ players: players, analyses: analyses }, () => {
          console.log('Created player and attached to comments:', trimmedName, commentRefs);
          resolve(newPlayer);
        });
      });
    });
  }

  // Helper function to add a team to global storage if it doesn't exist
  async function ensureTeamExists(teamName) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['teams'], (result) => {
        const teams = result.teams || [];
        const teamNameLower = teamName.toLowerCase().trim();
        
        // Check if team already exists
        const exists = teams.some(t => {
          const existingName = typeof t === 'string' ? t : (t.name || '');
          return existingName.toLowerCase() === teamNameLower;
        });
        
        if (exists) {
          resolve();
          return;
        }
        
        // Add new team to global storage
        const newTeam = {
          id: `team_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: teamName.trim(),
          homeColor: '#FFFFFF',
          awayColor: '#000000',
          homeDesign: 'solid',
          awayDesign: 'solid',
          homeSecondColor: '#000000',
          awaySecondColor: '#FFFFFF',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        teams.push(newTeam);
        chrome.storage.local.set({ teams: teams }, () => {
          console.log('Auto-added team to global storage:', teamName);
          resolve();
        });
      });
    });
  }
  
  // Helper function to add a player to global storage if it doesn't exist
  async function ensurePlayerExists(playerName) {
    return new Promise((resolve) => {
      // Validate player name - skip if it looks like message text
      if (!playerName || typeof playerName !== 'string') {
        resolve();
        return;
      }
      const trimmedName = playerName.trim();
      if (trimmedName.length === 0) {
        resolve();
        return;
      }
      // Skip if it looks like message text (too long, contains sentence-ending punctuation)
      if (trimmedName.length > 100 || trimmedName.includes('!') || trimmedName.includes('?') || trimmedName.includes('.')) {
        console.warn('Skipping invalid player name (looks like message text):', trimmedName);
        resolve();
        return;
      }
      
      chrome.storage.local.get(['players'], (result) => {
        const players = result.players || [];
        const playerNameLower = trimmedName.toLowerCase();
        
        // Check if player already exists (by full name or parts)
        const exists = players.some(p => {
          const fullName = (p.fullName || '').toLowerCase();
          const name = (p.name || '').toLowerCase();
          const surname = (p.surname || '').toLowerCase();
          return fullName === playerNameLower || 
                 name === playerNameLower || 
                 surname === playerNameLower ||
                 fullName.includes(playerNameLower) ||
                 playerNameLower.includes(fullName);
        });
        
        if (exists) {
          resolve();
          return;
        }
        
        // Parse player name (try to split into first and last name)
        const nameParts = trimmedName.split(/\s+/);
        const firstName = nameParts.length > 1 ? nameParts[0] : '';
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : nameParts[0];
        
        // Add new player to global storage
        const newPlayer = {
          id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fullName: trimmedName,
          name: firstName,
          surname: lastName,
          number: '',
          team: '',
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        
        players.push(newPlayer);
        chrome.storage.local.set({ players: players }, () => {
          console.log('Auto-added player to global storage:', trimmedName);
          resolve();
        });
      });
    });
  }

  async function updateCommentProperties(comment, extractedProperties, analysisId) {
    return new Promise(async (resolve, reject) => {
      chrome.storage.local.get(['analyses', 'teams', 'players'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        const teams = result.teams || [];
        const players = result.players || [];
        const analysisIndex = analyses.findIndex(a => a.id === analysisId);
        
        if (analysisIndex === -1) {
          reject(new Error('Analysis not found'));
          return;
        }

        const analysis = analyses[analysisIndex];
        const noteIndex = analysis.notes.findIndex(n => n.timestamp === comment.timestamp);
        
        if (noteIndex === -1) {
          reject(new Error('Comment not found'));
          return;
        }

        const note = analysis.notes[noteIndex];
        
        // Track unresolved items
        const unresolvedTeams = [];
        const unresolvedPlayers = [];
        
        // Process teams - resolve to existing teams only, do not create new ones
        const resolvedTeams = [];
        if (extractedProperties.teams && extractedProperties.teams.length > 0) {
          extractedProperties.teams.forEach(teamName => {
            const canonicalName = resolveToExistingTeam(teamName, teams);
            if (canonicalName) {
              // Only add if not already in resolved list
              if (!resolvedTeams.includes(canonicalName)) {
                resolvedTeams.push(canonicalName);
              }
            } else {
              // Team not found in library - add to unresolved
              const trimmedName = (teamName || '').trim();
              if (trimmedName && !unresolvedTeams.includes(trimmedName)) {
                unresolvedTeams.push(trimmedName);
              }
            }
          });
          
          // Only update note if we have resolved teams
          if (resolvedTeams.length > 0) {
            note.teams = resolvedTeams;
            note.team = resolvedTeams[0]; // Keep backward compatibility
          }
        }
        
        // Process players - resolve to existing players only, do not create new ones
        const resolvedPlayerIds = [];
        if (extractedProperties.players && extractedProperties.players.length > 0) {
          extractedProperties.players.forEach(playerName => {
            const matchedPlayer = resolveToExistingPlayer(playerName, players);
            if (matchedPlayer) {
              // Only add if not already in resolved list
              if (!resolvedPlayerIds.includes(matchedPlayer.id)) {
                resolvedPlayerIds.push(matchedPlayer.id);
              }
            } else {
              // Player not found in library - add to unresolved
              const trimmedName = (playerName || '').trim();
              // Skip if it looks like message text
              if (trimmedName && trimmedName.length <= 100 && 
                  !trimmedName.includes('!') && !trimmedName.includes('?') && !trimmedName.includes('.') &&
                  !unresolvedPlayers.includes(trimmedName)) {
                unresolvedPlayers.push(trimmedName);
              }
            }
          });
          
          // Only update note if we have resolved players
          if (resolvedPlayerIds.length > 0) {
            note.players = resolvedPlayerIds;
          }
        }
        
        // Update events
        if (extractedProperties.events && extractedProperties.events.length > 0) {
          note.events = extractedProperties.events;
        }
        
        // Update zones
        if (extractedProperties.zones && extractedProperties.zones.length > 0) {
          note.zones = extractedProperties.zones;
        }
        
        // Update intensity
        if (extractedProperties.intensity !== null && extractedProperties.intensity !== undefined) {
          note.intensity = extractedProperties.intensity;
        }
        
        // Save updated analysis
        chrome.storage.local.set({ analyses: analyses }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            // Resolve with unresolved items so caller can aggregate them
            resolve({ unresolvedTeams, unresolvedPlayers });
          }
        });
      });
    });
  }

  async function processCommentsEnhancement(comments, skipExisting, apiKey) {
    const progressDiv = document.getElementById('enhancementProgress');
    const progressText = document.getElementById('enhancementProgressText');
    const progressCount = document.getElementById('enhancementProgressCount');
    const progressBar = document.getElementById('enhancementProgressBar');
    const resultsDiv = document.getElementById('enhancementResults');
    const successCount = document.getElementById('enhancementSuccessCount');
    const errorCount = document.getElementById('enhancementErrorCount');
    const errorDetails = document.getElementById('enhancementErrorDetails');
    const startBtn = document.getElementById('startAiEnhancementBtn');
    
    let processed = 0;
    let succeeded = 0;
    let failed = 0;
    const errors = [];
    
    // Track unresolved items with their associated comments
    // Maps: itemName -> [{analysisId, timestamp}]
    const unresolvedTeamsMap = new Map();
    const unresolvedPlayersMap = new Map();
    
    // Filter comments
    const commentsToProcess = comments.filter(comment => {
      if (!comment.text && !comment.content) return false;
      if (skipExisting) {
        const hasProperties = (comment.teams && comment.teams.length > 0) ||
                             (comment.team) ||
                             (comment.players && comment.players.length > 0) ||
                             (comment.events && comment.events.length > 0) ||
                             (comment.zones && comment.zones.length > 0) ||
                             (comment.intensity !== null && comment.intensity !== undefined);
        return !hasProperties;
      }
      return true;
    });
    
    const total = commentsToProcess.length;
    
    if (total === 0) {
      if (resultsDiv) {
        resultsDiv.style.display = 'block';
        if (successCount) successCount.textContent = 'No comments to enhance.';
      }
      if (startBtn) {
        startBtn.disabled = false;
        startBtn.style.display = 'none';
      }
      return;
    }
    
    // Show progress
    if (progressDiv) progressDiv.style.display = 'block';
    if (startBtn) {
      startBtn.disabled = true;
      startBtn.style.display = 'none';
    }
    
    // Process each comment
    for (let i = 0; i < commentsToProcess.length; i++) {
      const comment = commentsToProcess[i];
      const commentText = (comment.text || comment.content || '').replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '');
      
      // Increment processed counter (for progress display)
      processed++;
      
      if (!commentText.trim()) {
        // Update progress even for empty comments
        if (progressCount) progressCount.textContent = `${processed} / ${total}`;
        if (progressBar) progressBar.style.width = `${(processed / total) * 100}%`;
        if (progressText) progressText.textContent = `Enhancing comment ${processed} of ${total}...`;
        continue;
      }
      
      try {
        // Update progress
        if (progressCount) progressCount.textContent = `${processed} / ${total}`;
        if (progressBar) progressBar.style.width = `${(processed / total) * 100}%`;
        if (progressText) progressText.textContent = `Enhancing comment ${processed} of ${total}...`;
        
        // Extract properties
        const extracted = await window.aiAnalysisUtils.extractCommentProperties(commentText, apiKey, 'auto');
        
        // Update comment and get unresolved items
        const result = await updateCommentProperties(comment, extracted, comment.analysisId || currentAnalysisId);
        
        // Aggregate unresolved items with comment references
        const commentRef = { 
          analysisId: comment.analysisId || currentAnalysisId, 
          timestamp: comment.timestamp 
        };
        if (result && result.unresolvedTeams) {
          result.unresolvedTeams.forEach(t => {
            if (!unresolvedTeamsMap.has(t)) {
              unresolvedTeamsMap.set(t, []);
            }
            unresolvedTeamsMap.get(t).push(commentRef);
          });
        }
        if (result && result.unresolvedPlayers) {
          result.unresolvedPlayers.forEach(p => {
            if (!unresolvedPlayersMap.has(p)) {
              unresolvedPlayersMap.set(p, []);
            }
            unresolvedPlayersMap.get(p).push(commentRef);
          });
        }
        
        succeeded++;
      } catch (error) {
        failed++;
        errors.push({
          comment: commentText.substring(0, 50) + (commentText.length > 50 ? '...' : ''),
          error: error.message
        });
        console.error('Error enhancing comment:', error);
      }
    }
    
    // Show results
    if (progressDiv) progressDiv.style.display = 'none';
    if (resultsDiv) {
      resultsDiv.style.display = 'block';
      if (successCount) {
        successCount.textContent = `Successfully enhanced ${succeeded} comment${succeeded !== 1 ? 's' : ''}.`;
      }
      if (failed > 0) {
        if (errorCount) {
          errorCount.style.display = 'block';
          errorCount.textContent = `Failed to enhance ${failed} comment${failed !== 1 ? 's' : ''}.`;
        }
        if (errorDetails) {
          errorDetails.innerHTML = errors.map(e => 
            `<div style="margin-bottom: 4px;"><strong>${e.comment}:</strong> ${e.error}</div>`
          ).join('');
        }
      }
      
      // Show unresolved teams and players with interactive create options
      const unresolvedSection = document.getElementById('enhancementUnresolvedSection');
      const unresolvedTeamsList = document.getElementById('enhancementUnresolvedTeamsList');
      const unresolvedTeamsItems = document.getElementById('enhancementUnresolvedTeamsItems');
      const unresolvedPlayersList = document.getElementById('enhancementUnresolvedPlayersList');
      const unresolvedPlayersItems = document.getElementById('enhancementUnresolvedPlayersItems');
      const createAllBtn = document.getElementById('createAllUnresolvedBtn');
      const skipBtn = document.getElementById('skipUnresolvedBtn');
      
      const hasUnresolvedTeams = unresolvedTeamsMap.size > 0;
      const hasUnresolvedPlayers = unresolvedPlayersMap.size > 0;
      
      if (unresolvedSection && (hasUnresolvedTeams || hasUnresolvedPlayers)) {
        unresolvedSection.style.display = 'block';
        
        // Render unresolved teams
        if (unresolvedTeamsList && unresolvedTeamsItems) {
          if (hasUnresolvedTeams) {
            unresolvedTeamsList.style.display = 'block';
            unresolvedTeamsItems.innerHTML = '';
            const teamsArray = Array.from(unresolvedTeamsMap.keys());
            teamsArray.forEach((teamName, index) => {
              const commentRefs = unresolvedTeamsMap.get(teamName);
              const itemDiv = document.createElement('div');
              itemDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; padding: 4px 8px; background: #161b22; border-radius: 4px;';
              itemDiv.innerHTML = `
                <input type="checkbox" id="unresolvedTeam_${index}" data-team-name="${teamName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' checked style="cursor: pointer; width: 14px; height: 14px;">
                <label for="unresolvedTeam_${index}" style="flex: 1; font-size: 12px; color: #c9d1d9; cursor: pointer;">${teamName} <span style="color: #6e7681; font-size: 10px;">(${commentRefs.length} comment${commentRefs.length > 1 ? 's' : ''})</span></label>
                <button class="create-single-team-btn" data-team-name="${teamName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' style="padding: 2px 8px; background: #238636; color: #fff; border: none; border-radius: 3px; font-size: 10px; cursor: pointer;">Create</button>
              `;
              unresolvedTeamsItems.appendChild(itemDiv);
            });
          } else {
            unresolvedTeamsList.style.display = 'none';
          }
        }
        
        // Render unresolved players
        if (unresolvedPlayersList && unresolvedPlayersItems) {
          if (hasUnresolvedPlayers) {
            unresolvedPlayersList.style.display = 'block';
            unresolvedPlayersItems.innerHTML = '';
            const playersArray = Array.from(unresolvedPlayersMap.keys());
            playersArray.forEach((playerName, index) => {
              const commentRefs = unresolvedPlayersMap.get(playerName);
              const itemDiv = document.createElement('div');
              itemDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; padding: 4px 8px; background: #161b22; border-radius: 4px;';
              itemDiv.innerHTML = `
                <input type="checkbox" id="unresolvedPlayer_${index}" data-player-name="${playerName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' checked style="cursor: pointer; width: 14px; height: 14px;">
                <label for="unresolvedPlayer_${index}" style="flex: 1; font-size: 12px; color: #c9d1d9; cursor: pointer;">${playerName} <span style="color: #6e7681; font-size: 10px;">(${commentRefs.length} comment${commentRefs.length > 1 ? 's' : ''})</span></label>
                <button class="create-single-player-btn" data-player-name="${playerName.replace(/"/g, '&quot;')}" data-comment-refs='${JSON.stringify(commentRefs)}' style="padding: 2px 8px; background: #238636; color: #fff; border: none; border-radius: 3px; font-size: 10px; cursor: pointer;">Create</button>
              `;
              unresolvedPlayersItems.appendChild(itemDiv);
            });
          } else {
            unresolvedPlayersList.style.display = 'none';
          }
        }
        
        // Add event listeners for individual create buttons
        document.querySelectorAll('.create-single-team-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const teamName = e.target.dataset.teamName;
            const commentRefs = JSON.parse(e.target.dataset.commentRefs || '[]');
            await createTeamAndAttachToComments(teamName, commentRefs);
            e.target.closest('div').remove();
            // Check if any teams left
            if (unresolvedTeamsItems.children.length === 0) {
              unresolvedTeamsList.style.display = 'none';
            }
            checkAndHideUnresolvedSection();
            refreshMessages();
          });
        });
        
        document.querySelectorAll('.create-single-player-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const playerName = e.target.dataset.playerName;
            const commentRefs = JSON.parse(e.target.dataset.commentRefs || '[]');
            await createPlayerAndAttachToComments(playerName, commentRefs);
            e.target.closest('div').remove();
            // Check if any players left
            if (unresolvedPlayersItems.children.length === 0) {
              unresolvedPlayersList.style.display = 'none';
            }
            checkAndHideUnresolvedSection();
            refreshMessages();
          });
        });
        
        // Create All Selected button handler
        if (createAllBtn) {
          createAllBtn.onclick = async () => {
            createAllBtn.disabled = true;
            createAllBtn.textContent = 'Creating...';
            
            // Create selected teams
            const teamCheckboxes = document.querySelectorAll('#enhancementUnresolvedTeamsItems input[type="checkbox"]:checked');
            for (const checkbox of teamCheckboxes) {
              const teamName = checkbox.dataset.teamName;
              const commentRefs = JSON.parse(checkbox.dataset.commentRefs || '[]');
              await createTeamAndAttachToComments(teamName, commentRefs);
              checkbox.closest('div').remove();
            }
            
            // Create selected players
            const playerCheckboxes = document.querySelectorAll('#enhancementUnresolvedPlayersItems input[type="checkbox"]:checked');
            for (const checkbox of playerCheckboxes) {
              const playerName = checkbox.dataset.playerName;
              const commentRefs = JSON.parse(checkbox.dataset.commentRefs || '[]');
              await createPlayerAndAttachToComments(playerName, commentRefs);
              checkbox.closest('div').remove();
            }
            
            createAllBtn.disabled = false;
            createAllBtn.textContent = 'Create All Selected';
            
            // Check if any items left
            if (unresolvedTeamsItems.children.length === 0) {
              unresolvedTeamsList.style.display = 'none';
            }
            if (unresolvedPlayersItems.children.length === 0) {
              unresolvedPlayersList.style.display = 'none';
            }
            checkAndHideUnresolvedSection();
            refreshMessages();
          };
        }
        
        // Skip button handler
        if (skipBtn) {
          skipBtn.onclick = () => {
            unresolvedSection.style.display = 'none';
          };
        }
        
        function checkAndHideUnresolvedSection() {
          const hasTeams = unresolvedTeamsList && unresolvedTeamsList.style.display !== 'none' && unresolvedTeamsItems.children.length > 0;
          const hasPlayers = unresolvedPlayersList && unresolvedPlayersList.style.display !== 'none' && unresolvedPlayersItems.children.length > 0;
          if (!hasTeams && !hasPlayers) {
            unresolvedSection.style.display = 'none';
          }
        }
      } else if (unresolvedSection) {
        unresolvedSection.style.display = 'none';
      }
    }
    
    // Hide start button and show OK button after completion
    if (startBtn) {
      startBtn.disabled = false;
      startBtn.style.display = 'none';
    }
    const okBtn = document.getElementById('okAiEnhancementBtn');
    if (okBtn) {
      okBtn.style.display = 'block';
    }
    
    // Refresh UI to show updated properties
    if (currentAnalysisId) {
      refreshMessages();
    }
  }

  async function startAiEnhancement() {
    const scopeSelect = document.getElementById('enhancementScopeSelect');
    const skipExisting = document.getElementById('enhancementSkipExisting');
    const errorDiv = document.getElementById('enhancementError');
    
    if (!currentAnalysisId) {
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Please select a project first.';
      }
      return;
    }
    
    // Get API key
    let apiKey;
    try {
      apiKey = await window.aiAnalysisUtils.loadOpenAIKey();
    } catch (error) {
      console.error('Error loading API key:', error);
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Error loading API key. Please check your AI Settings.';
      }
      return;
    }
    
    if (!apiKey) {
      if (errorDiv) {
        errorDiv.style.display = 'block';
        errorDiv.textContent = 'Please configure your OpenAI API key in AI Settings first.';
      }
      return;
    }
    
    // Get comments to enhance
    chrome.storage.local.get(['analyses'], (result) => {
      if (chrome.runtime.lastError) {
        if (errorDiv) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = 'Error loading comments: ' + chrome.runtime.lastError.message;
        }
        return;
      }
      
      const analyses = result.analyses || [];
      const analysis = analyses.find(a => a.id === currentAnalysisId);
      
      if (!analysis || !analysis.notes) {
        if (errorDiv) {
          errorDiv.style.display = 'block';
          errorDiv.textContent = 'No comments found in current project.';
        }
        return;
      }
      
      let comments = analysis.notes.map(note => ({
        ...note,
        analysisId: currentAnalysisId
      }));
      
      // Filter for marked comments if scope is "marked"
      const scope = scopeSelect ? scopeSelect.value : 'all';
      if (scope === 'marked') {
        // Get all marked comment timestamps
        const markedCheckboxes = document.querySelectorAll('.message-mark-checkbox:checked');
        const markedTimestamps = Array.from(markedCheckboxes).map(cb => cb.dataset.noteTimestamp);
        
        if (markedTimestamps.length === 0) {
          if (errorDiv) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = 'Please mark at least one comment to enhance.';
          }
          return;
        }
        
        // Filter comments to only include marked ones
        comments = comments.filter(comment => markedTimestamps.includes(String(comment.timestamp)));
      }
      
      const skipExistingValue = skipExisting && skipExisting.checked;
      
      processCommentsEnhancement(comments, skipExistingValue, apiKey);
    });
  }

  // AI Enhancement Modal handlers
  const aiEnhancementModal = document.getElementById('aiEnhancementModal');
  const closeAiEnhancementModalBtn = document.getElementById('closeAiEnhancementModal');
  const startAiEnhancementBtn = document.getElementById('startAiEnhancementBtn');

  if (closeAiEnhancementModalBtn) {
    closeAiEnhancementModalBtn.addEventListener('click', () => {
      closeAiEnhancementModal();
    });
  }

  if (aiEnhancementModal) {
    aiEnhancementModal.addEventListener('click', (e) => {
      if (e.target === aiEnhancementModal) {
        closeAiEnhancementModal();
      }
    });
  }

  if (startAiEnhancementBtn) {
    startAiEnhancementBtn.addEventListener('click', () => {
      startAiEnhancement();
    });
  }

  const okAiEnhancementBtn = document.getElementById('okAiEnhancementBtn');
  if (okAiEnhancementBtn) {
    okAiEnhancementBtn.addEventListener('click', () => {
      closeAiEnhancementModal();
    });
  }

  // Show AI Analysis Focus Modal - asks the coach what they want to analyze
  function showAIAnalysisFocusModal() {
    // Create or show modal
    let modal = document.getElementById('aiAnalysisFocusModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'aiAnalysisFocusModal';
      modal.className = 'project-modal hidden';
      modal.innerHTML = `
        <div class="project-modal-content" style="max-width: 500px;">
          <div class="project-modal-header">
            <h3 data-i18n="ai.analysisFocusTitle">What would you like to analyze?</h3>
            <button id="closeAIFocusModal" class="close-modal-btn">&times;</button>
          </div>
          <div class="project-modal-body">
            <p style="color: #8b949e; margin-bottom: 16px; font-size: 13px; line-height: 1.5;" data-i18n="ai.analysisFocusDescription">
              Describe what you want the AI to focus on. For example: "What are the defensive weaknesses of Team X?" or "How can we improve our attacking patterns in the final third?"
            </p>
            <textarea 
              id="aiFocusInput" 
              class="url-input-modal" 
              placeholder="Enter your analysis question or focus area... (optional)"
              data-i18n-placeholder="ai.analysisFocusPlaceholder"
              style="width: 100%; min-height: 100px; padding: 12px; font-size: 14px; resize: vertical; line-height: 1.5; background: #0d1117; border: 1px solid #30363d; border-radius: 6px; color: #c9d1d9;"
            ></textarea>
            <p style="color: #6e7681; margin-top: 12px; font-size: 12px; line-height: 1.4;" data-i18n="ai.analysisFocusHint">
              Leave empty for a general comprehensive analysis of all aspects.
            </p>
            <div style="display: flex; gap: 8px; justify-content: flex-end; margin-top: 20px;">
              <button id="skipFocusBtn" class="modal-btn-secondary" data-i18n="ai.skipAndAnalyze">Skip & General Analysis</button>
              <button id="startFocusedAnalysisBtn" class="modal-btn-primary" data-i18n="ai.startFocusedAnalysis">Start Analysis</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      
      // Apply translations
      if (window.applyTranslationsToElement) {
        window.applyTranslationsToElement(modal);
      }
      
      // Close button handler
      const closeBtn = document.getElementById('closeAIFocusModal');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          modal.classList.add('hidden');
        });
      }
      
      // Skip button handler - starts general analysis
      const skipBtn = document.getElementById('skipFocusBtn');
      if (skipBtn) {
        skipBtn.addEventListener('click', () => {
          modal.classList.add('hidden');
          triggerAIAnalysis(null); // No focus - general analysis
        });
      }
      
      // Start focused analysis button handler
      const startBtn = document.getElementById('startFocusedAnalysisBtn');
      if (startBtn) {
        startBtn.addEventListener('click', () => {
          const focusInput = document.getElementById('aiFocusInput');
          const focus = focusInput ? focusInput.value.trim() : null;
          modal.classList.add('hidden');
          triggerAIAnalysis(focus || null); // Pass focus or null if empty
        });
      }
      
      // Close on outside click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
        }
      });
      
      // Allow Ctrl+Enter to submit
      const focusInput = document.getElementById('aiFocusInput');
      if (focusInput) {
        focusInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            const focus = focusInput.value.trim();
            modal.classList.add('hidden');
            triggerAIAnalysis(focus || null);
          }
        });
      }
    }
    
    // Reset input and show modal
    const focusInput = document.getElementById('aiFocusInput');
    if (focusInput) {
      focusInput.value = '';
    }
    
    modal.classList.remove('hidden');
    
    // Focus on the input
    setTimeout(() => {
      const input = document.getElementById('aiFocusInput');
      if (input) {
        input.focus();
      }
    }, 100);
  }

  async function triggerAIAnalysis(analysisFocus = null) {
    if (!currentAnalysisId) {
      alert('Please select an analysis first.');
      return;
    }

    // Check for API key
    let apiKey;
    try {
      apiKey = await loadOpenAIKey();
    } catch (error) {
      console.error('Error loading API key:', error);
      showAPISettingsModal();
      return;
    }

    if (!apiKey) {
      showAPISettingsModal();
      return;
    }

    // Load saved language preference from settings
    let selectedLanguage = 'auto';
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['ai_analysis_language'], resolve);
      });
      selectedLanguage = result.ai_analysis_language || 'auto';
    } catch (error) {
      console.error('Error loading language preference:', error);
    }

    // Show modal with loading state (language is already set in settings)
    const modal = document.getElementById('aiAnalysisResultsModal');
    const loadingDiv = document.getElementById('aiAnalysisLoading');
    const errorDiv = document.getElementById('aiAnalysisError');
    const contentDiv = document.getElementById('aiAnalysisContent');
    const languageSelector = document.getElementById('aiAnalysisLanguageSelector');
    
    if (modal) {
      // Hide language selector in results modal (it's now in settings)
      if (languageSelector) languageSelector.style.display = 'none';
      
      // Show loading state immediately
      if (loadingDiv) loadingDiv.style.display = 'block';
      if (errorDiv) errorDiv.style.display = 'none';
      if (contentDiv) contentDiv.style.display = 'none';
      modal.classList.remove('hidden');
    }

    // Start analysis immediately with saved language preference
    try {
      // Collect data
      const analysisData = await collectAnalysisData(currentAnalysisId);
      
      // Store analysis data for citation previews
      currentAnalysisDataForPreview = analysisData;
      
      // Check if there's any data to analyze
      if (!analysisData.notes || analysisData.notes.length === 0) {
        if (analysisData.timelineMarkers.length === 0 && analysisData.tacticalSchemes.length === 0 && analysisData.regularImages.length === 0) {
          showAIAnalysisResults(null, 'No data to analyze. Please add some notes, timeline markers, tactical schemes, or images first.');
          return;
        }
      }

      // Retrieve relevant historical comments from comments database for RAG
      let historicalComments = [];
      try {
        if (window.aiAnalysisUtils && window.aiAnalysisUtils.retrieveRelevantComments) {
          historicalComments = await window.aiAnalysisUtils.retrieveRelevantComments(analysisData, 50);
          console.log('Retrieved historical comments for RAG:', historicalComments.length);
        }
      } catch (error) {
        console.warn('Error retrieving historical comments, proceeding without RAG:', error);
        // Continue without historical comments if retrieval fails
      }

      // Format prompt with selected language, historical comments, and analysis focus
      const prompt = window.aiAnalysisUtils.formatDataForAI(analysisData, selectedLanguage, historicalComments, analysisFocus);

      // Call OpenAI API
      const results = await callOpenAIAnalysis(prompt, apiKey);

      // Show results
      showAIAnalysisResults(results);
    } catch (error) {
      console.error('AI Analysis error:', error);
      showAIAnalysisResults(null, error.message || 'An error occurred during analysis.');
    }
  }

  // Event Handlers
  const aiAnalysisButton = document.getElementById('aiAnalysisButton');
  // AI Analysis button with dropdown
  const aiAnalysisDropdownArrow = document.getElementById('aiAnalysisDropdownArrow');
  const aiAnalysisDropdown = document.getElementById('aiAnalysisDropdown');
  const aiAnalysisDropdownItem = document.getElementById('aiAnalysisDropdownItem');
  const aiAnalysisSettingsDropdownItem = document.getElementById('aiAnalysisSettingsDropdownItem');
  const aiEnhanceWithAIDropdownItem = document.getElementById('aiEnhanceWithAIDropdownItem');
  
  // AI Analysis button now opens dropdown instead of triggering analysis directly
  if (aiAnalysisButton && aiAnalysisDropdown) {
    aiAnalysisButton.addEventListener('click', (e) => {
      e.stopPropagation();
      const isHidden = aiAnalysisDropdown.classList.contains('hidden') || aiAnalysisDropdown.style.display === 'none';
      if (isHidden) {
        closeAllDropdowns(aiAnalysisDropdown);
        setTimeout(() => {
          aiAnalysisDropdown.classList.remove('hidden');
          aiAnalysisDropdown.style.display = 'block';
          aiAnalysisDropdown.style.visibility = 'visible';
          aiAnalysisDropdown.style.opacity = '1';
          aiAnalysisDropdown.style.zIndex = '10001';
        }, 0);
      } else {
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
      }
    });
  }

  // Dropdown arrow click handler
  if (aiAnalysisDropdownArrow && aiAnalysisDropdown) {
    // Initialize dropdown as hidden
    aiAnalysisDropdown.style.display = 'none';
    
    // Make sure the button and SVG are clickable
    aiAnalysisDropdownArrow.style.pointerEvents = 'auto';
    aiAnalysisDropdownArrow.style.cursor = 'pointer';
    
    // Add click handler
    const handleDropdownClick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isHidden = aiAnalysisDropdown.classList.contains('hidden') || aiAnalysisDropdown.style.display === 'none';
      if (isHidden) {
        closeAllDropdowns(aiAnalysisDropdown);
        // Use setTimeout to ensure closeAllDropdowns completes first
        setTimeout(() => {
          aiAnalysisDropdown.classList.remove('hidden');
          aiAnalysisDropdown.style.display = 'block';
          aiAnalysisDropdown.style.visibility = 'visible';
          aiAnalysisDropdown.style.opacity = '1';
          aiAnalysisDropdown.style.zIndex = '10001';
          // Ensure it's positioned correctly
          const container = aiAnalysisDropdownArrow.closest('.ai-analysis-dropdown-container');
          if (container) {
            container.style.position = 'relative';
            container.style.zIndex = '10001';
            // Ensure parent containers don't clip the dropdown
            const chatHeaderRow = container.closest('.chat-header-row');
            if (chatHeaderRow) {
              chatHeaderRow.style.overflow = 'visible';
            }
            const chatHeader = container.closest('.chat-header');
            if (chatHeader) {
              chatHeader.style.overflow = 'visible';
            }
          }
        }, 0);
      } else {
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
      }
    };
    
    aiAnalysisDropdownArrow.addEventListener('click', (e) => {
      e.stopPropagation();
      closeAllDropdowns();
      handleDropdownClick(e);
    });
    
    // Also add to SVG if it exists
    const svg = aiAnalysisDropdownArrow.querySelector('svg');
    if (svg) {
      svg.style.pointerEvents = 'none'; // Let clicks pass through to button
    }
  }

  // AI Analysis item in dropdown
  if (aiAnalysisDropdownItem) {
    aiAnalysisDropdownItem.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      aiAnalysisDropdown.classList.add('hidden');
      aiAnalysisDropdown.style.display = 'none';
      showAIAnalysisFocusModal();
    });
  }

  // Settings item in dropdown
  if (aiAnalysisSettingsDropdownItem) {
    aiAnalysisSettingsDropdownItem.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      aiAnalysisDropdown.classList.add('hidden');
      aiAnalysisDropdown.style.display = 'none';
      showAPISettingsModal();
    });
  }

  // Enhance with AI item in dropdown
  if (aiEnhanceWithAIDropdownItem) {
    aiEnhanceWithAIDropdownItem.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      aiAnalysisDropdown.classList.add('hidden');
      aiAnalysisDropdown.style.display = 'none';
      openAiEnhancementModal();
    });
  }

  // Close dropdown when clicking outside
  if (aiAnalysisDropdown) {
    document.addEventListener('click', (e) => {
      if (!aiAnalysisDropdown.contains(e.target) && 
          e.target !== aiAnalysisDropdownArrow && 
          e.target !== aiAnalysisButton &&
          !aiAnalysisDropdownArrow.contains(e.target) &&
          !aiAnalysisButton.contains(e.target)) {
        aiAnalysisDropdown.classList.add('hidden');
        aiAnalysisDropdown.style.display = 'none';
      }
    });
  }

  // API Key Settings Modal handlers
  const apiKeySettingsModal = document.getElementById('apiKeySettingsModal');
  const closeApiKeySettingsModal = document.getElementById('closeApiKeySettingsModal');
  const saveApiKeyBtn = document.getElementById('saveApiKeyBtn');
  const deleteApiKeyBtn = document.getElementById('deleteApiKeyBtn');
  const apiKeyInput = document.getElementById('apiKeyInput');
  const apiKeyError = document.getElementById('apiKeyError');
  const apiKeySuccess = document.getElementById('apiKeySuccess');

  if (closeApiKeySettingsModal) {
    closeApiKeySettingsModal.addEventListener('click', () => {
      if (apiKeySettingsModal) {
        apiKeySettingsModal.classList.add('hidden');
      }
    });
  }

  if (apiKeySettingsModal) {
    apiKeySettingsModal.addEventListener('click', (e) => {
      if (e.target === apiKeySettingsModal) {
        apiKeySettingsModal.classList.add('hidden');
      }
    });
  }

  // Settings Modal
  const settingsModal = document.getElementById('settingsModal');
  const closeSettingsModal = document.getElementById('closeSettingsModal');
  const commentsDatabaseDropdownItem = document.getElementById('commentsDatabaseDropdownItem');
  if (commentsDatabaseDropdownItem) {
    commentsDatabaseDropdownItem.addEventListener('click', () => {
      if (savingOptionsDropdown) {
        savingOptionsDropdown.classList.add('hidden');
        savingOptionsDropdown.style.display = 'none';
      }
      openCommentsDatabase();
    });
  }

  const settingsDropdownItem = document.getElementById('settingsDropdownItem');
  const saveSettingsBtn = document.getElementById('saveSettingsBtn');

  // Open Settings modal from dropdown
  if (settingsDropdownItem) {
    settingsDropdownItem.addEventListener('click', () => {
      if (settingsModal) {
        // Close the dropdown first
        if (savingOptionsDropdown) {
          savingOptionsDropdown.classList.add('hidden');
        }
        // Load current language
        const interfaceLanguageSelect = document.getElementById('interfaceLanguageSelect');
        if (interfaceLanguageSelect && window.i18n) {
          const currentLang = window.i18n.getCurrentLanguage();
          interfaceLanguageSelect.value = currentLang;
        }
        settingsModal.classList.remove('hidden');
      }
    });
  }

  // Close Settings modal
  if (closeSettingsModal) {
    closeSettingsModal.addEventListener('click', () => {
      if (settingsModal) {
        settingsModal.classList.add('hidden');
      }
    });
  }

  if (settingsModal) {
    settingsModal.addEventListener('click', (e) => {
      if (e.target === settingsModal) {
        settingsModal.classList.add('hidden');
      }
    });
  }

  // Interface language selector (in Settings modal)
  const interfaceLanguageSelect = document.getElementById('interfaceLanguageSelect');
  if (interfaceLanguageSelect && window.i18n) {
    // Load current language when modal opens
    const loadLanguageInSettings = () => {
      const currentLang = window.i18n.getCurrentLanguage();
      interfaceLanguageSelect.value = currentLang;
    };
    
    // Load language when Settings modal is opened
    if (settingsModal) {
      const observer = new MutationObserver((mutations) => {
        if (!settingsModal.classList.contains('hidden')) {
          loadLanguageInSettings();
        }
      });
      observer.observe(settingsModal, { attributes: true, attributeFilter: ['class'] });
    }
    
    // Save language when Save button is clicked
    if (saveSettingsBtn) {
      saveSettingsBtn.addEventListener('click', async () => {
        const newLang = interfaceLanguageSelect.value;
        if (window.i18n && window.i18n.setLanguage) {
          await window.i18n.setLanguage(newLang);
          // Close modal after saving
          if (settingsModal) {
            settingsModal.classList.add('hidden');
          }
        }
      });
    }
  }

  if (saveApiKeyBtn && apiKeyInput) {
    saveApiKeyBtn.addEventListener('click', async () => {
      const key = apiKeyInput.value.trim();
      const languageSelect = document.getElementById('apiKeyLanguageSelect');
      const selectedLanguage = languageSelect ? languageSelect.value : 'auto';
      
      // Only validate API key if a new one is being entered
      if (key) {
        if (!validateAPIKey(key)) {
          apiKeyError.textContent = 'Invalid API key format. OpenAI keys typically start with "sk-"';
          apiKeyError.style.display = 'block';
          apiKeySuccess.style.display = 'none';
          return;
        }

        try {
          await saveOpenAIKey(key);
        } catch (error) {
          apiKeyError.textContent = error.message || 'Failed to save API key';
          apiKeyError.style.display = 'block';
          apiKeySuccess.style.display = 'none';
          return;
        }
      }

      // Save language preference
      try {
        chrome.storage.local.set({ ai_analysis_language: selectedLanguage }, () => {
          if (chrome.runtime.lastError) {
            console.error('Error saving language preference:', chrome.runtime.lastError);
          }
        });
      } catch (error) {
        console.error('Error saving language preference:', error);
      }

      // Show success message
      apiKeyError.style.display = 'none';
      if (key) {
        apiKeySuccess.textContent = 'Settings saved successfully!';
        apiKeyInput.value = '';
        deleteApiKeyBtn.style.display = 'block';
      } else {
        apiKeySuccess.textContent = 'Language preference saved!';
      }
      apiKeySuccess.style.display = 'block';
      
      setTimeout(() => {
        if (apiKeySettingsModal) {
          apiKeySettingsModal.classList.add('hidden');
        }
      }, 1500);
    });
  }

  if (deleteApiKeyBtn) {
    deleteApiKeyBtn.addEventListener('click', async () => {
      if (!confirm('Are you sure you want to delete your API key?')) {
        return;
      }

      try {
        await deleteOpenAIKey();
        apiKeyError.style.display = 'none';
        apiKeySuccess.textContent = 'API key deleted successfully';
        apiKeySuccess.style.display = 'block';
        apiKeyInput.value = '';
        apiKeyInput.placeholder = 'sk-...';
        deleteApiKeyBtn.style.display = 'none';
        
        setTimeout(() => {
          if (apiKeySettingsModal) {
            apiKeySettingsModal.classList.add('hidden');
          }
        }, 1500);
      } catch (error) {
        apiKeyError.textContent = error.message || 'Failed to delete API key';
        apiKeyError.style.display = 'block';
        apiKeySuccess.style.display = 'none';
      }
    });
  }

  // AI Analysis Results Modal handlers
  const aiAnalysisResultsModal = document.getElementById('aiAnalysisResultsModal');
  const closeAiAnalysisResultsModal = document.getElementById('closeAiAnalysisResultsModal');
  const retryAiAnalysisBtn = document.getElementById('retryAiAnalysisBtn');
  const saveAiAnalysisBtn = document.getElementById('saveAiAnalysisBtn');

  if (closeAiAnalysisResultsModal) {
    closeAiAnalysisResultsModal.addEventListener('click', () => {
      if (aiAnalysisResultsModal) {
        aiAnalysisResultsModal.classList.add('hidden');
      }
    });
  }

  // Prevent clicks on modal content from closing the modal
  if (aiAnalysisResultsModal) {
    const modalContent = aiAnalysisResultsModal.querySelector('.project-modal-content');
    if (modalContent) {
      modalContent.addEventListener('click', (e) => {
        e.stopPropagation();
      });
    }
  }

  if (retryAiAnalysisBtn) {
    retryAiAnalysisBtn.addEventListener('click', () => {
      if (aiAnalysisResultsModal) {
        aiAnalysisResultsModal.classList.add('hidden');
      }
      setTimeout(() => {
        // Show the focus modal again so user can adjust their question if needed
        showAIAnalysisFocusModal();
      }, 300);
    });
  }

  if (saveAiAnalysisBtn) {
    saveAiAnalysisBtn.addEventListener('click', () => {
      const resultsDiv = document.getElementById('aiAnalysisResults');
      if (!resultsDiv || !originalAIAnalysisText) {
        console.warn('No AI analysis results available');
        return;
      }

      // Get HTML from resultsDiv which already has clickable citation links and collapsible blocks
      // This preserves all the citation links with their data attributes
      let analysisHtml = resultsDiv.innerHTML;
      
      // Wrap content in a container div for proper styling
      analysisHtml = `<div style="color: #c9d1d9; line-height: 1.6; white-space: pre-wrap;">${analysisHtml}</div>`;
      
      // Add header with styling
      const headerHtml = '<div style="font-size: 12px; font-weight: 600; color: #58a6ff; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid #21262d;">AI Analysis</div>';
      
      const fullAnalysisText = headerHtml + analysisHtml;
      
      // Save directly without using the input field
      const messageToSave = `[HTML_CONTENT]${fullAnalysisText}[/HTML_CONTENT]`;
      const messageTimestamp = Date.now();
      
      // Create noteData with HTML content flag
      const tempNoteData = {
        timestamp: messageTimestamp,
        isHtmlContent: true
      };
      
      // Display the message immediately
      addMessage(fullAnalysisText, null, 1, tempNoteData, null);
      
      // Save to storage
      saveMessage(messageToSave, null, messageTimestamp, null, null, null, null, null, () => {
        // After save completes, close modal
        if (aiAnalysisResultsModal) {
          aiAnalysisResultsModal.classList.add('hidden');
        }
      });
    });
  }

  // Citation Preview Modal handlers
  const citationPreviewModal = document.getElementById('citationPreviewModal');
  const closeCitationPreviewModal = document.getElementById('closeCitationPreviewModal');
  const closeCitationPreviewBtn = document.getElementById('closeCitationPreviewBtn');

  if (closeCitationPreviewModal) {
    closeCitationPreviewModal.addEventListener('click', () => {
      if (citationPreviewModal) {
        citationPreviewModal.classList.add('hidden');
      }
    });
  }

  if (closeCitationPreviewBtn) {
    closeCitationPreviewBtn.addEventListener('click', () => {
      if (citationPreviewModal) {
        citationPreviewModal.classList.add('hidden');
      }
    });
  }

  if (citationPreviewModal) {
    citationPreviewModal.addEventListener('click', (e) => {
      if (e.target === citationPreviewModal) {
        citationPreviewModal.classList.add('hidden');
      }
    });
  }

  // Add API Settings option to saving options menu (optional enhancement)
  // This could be added to the menu-dots-button dropdown if needed

  // ========== COMMENTS DATABASE ==========
  
  // Global state for comments database
  let allCommentsData = [];
  let filteredComments = [];
  let currentPage = 1;
  const commentsPerPage = 50;
  let searchDebounceTimer = null;
  let playerNameToIdMap = new Map(); // Map player display name to player ID for filtering

  // Load all comments from all analyses
  async function loadAllComments() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['analyses'], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const analyses = result.analyses || [];
        allCommentsData = [];

        analyses.forEach(analysis => {
          if (analysis.notes && Array.isArray(analysis.notes)) {
            analysis.notes.forEach(note => {
              // Check if note has schemes
              const hasSchemes = note.images && Array.isArray(note.images) && 
                note.images.some(img => typeof img === 'object' && img.slidesData && Array.isArray(img.slidesData) && img.slidesData.length > 0);
              
              // Check if comment text is empty (after removing timecode)
              const noteText = note.text || note.content || '';
              const cleanText = noteText.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
              const isEmptyComment = !cleanText || cleanText.length === 0;
              
              // Skip empty comments that have schemes (scheme entry will be shown separately)
              if (isEmptyComment && hasSchemes) {
                // Only add scheme entries, skip the empty comment
              } else {
                // Add the comment entry
                const commentWithMetadata = {
                  ...note,
                  analysisId: analysis.id,
                  analysisName: analysis.name,
                  analysisDate: analysis.date
                };
                allCommentsData.push(commentWithMetadata);
              }
              
              // Extract schemes from note images
              if (note.images && Array.isArray(note.images)) {
                note.images.forEach(image => {
                  // Check if image has slidesData (tactical scheme)
                  if (typeof image === 'object' && image.slidesData && Array.isArray(image.slidesData) && image.slidesData.length > 0) {
                    const schemeEntry = {
                      type: 'scheme',
                      slidesData: image.slidesData,
                      timestamp: note.timestamp,
                      videoTime: note.videoTime,
                      timecode: note.text ? note.text.match(/^\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/) : null,
                      analysisId: analysis.id,
                      analysisName: analysis.name,
                      analysisDate: analysis.date,
                      teams: note.teams || (note.team ? [note.team] : []),
                      players: note.players || [],
                      events: note.events || [],
                      zones: note.zones || [],
                      intensity: note.intensity,
                      videoId: note.videoId,
                      videoTitle: note.videoTitle,
                      videoUrl: note.videoUrl
                    };
                    allCommentsData.push(schemeEntry);
                  }
                });
              }
            });
          }
        });

        resolve(allCommentsData);
      });
    });
  }

  // Search comments by text
  function searchComments(comments, query) {
    if (!query || query.trim() === '') {
      return comments;
    }

    const searchTerm = query.toLowerCase().trim();
    return comments.filter(comment => {
      const text = (comment.text || comment.content || '').toLowerCase();
      return text.includes(searchTerm);
    });
  }

  // Filter comments by various attributes
  function filterComments(comments, filters) {
    let filtered = comments;

    // Team filter
    if (filters.team && filters.team !== '') {
      filtered = filtered.filter(comment => {
        if (comment.teams && Array.isArray(comment.teams)) {
          return comment.teams.some(t => t === filters.team);
        }
        return comment.team === filters.team;
      });
    }

    // Player filter
    if (filters.player && filters.player !== '') {
      // Get player IDs that match the selected player name
      const matchingPlayerIds = playerNameToIdMap.get(filters.player);
      if (matchingPlayerIds && matchingPlayerIds.size > 0) {
        filtered = filtered.filter(comment => {
          if (comment.players && Array.isArray(comment.players)) {
            return comment.players.some(p => {
              const playerId = typeof p === 'string' ? p : (p.id || p.name || '');
              return matchingPlayerIds.has(playerId);
            });
          }
          return false;
        });
      } else {
        // Fallback: try direct match (for legacy data or names stored directly)
        filtered = filtered.filter(comment => {
          if (comment.players && Array.isArray(comment.players)) {
            return comment.players.some(p => {
              const playerName = typeof p === 'string' ? p : (p.name || p.id || '');
              return playerName === filters.player;
            });
          }
          return false;
        });
      }
    }

    // Event filter
    if (filters.event && filters.event !== '') {
      filtered = filtered.filter(comment => {
        if (comment.events && Array.isArray(comment.events)) {
          return comment.events.includes(filters.event);
        }
        return false;
      });
    }

    // Zone filter
    if (filters.zone && filters.zone !== '') {
      filtered = filtered.filter(comment => {
        if (comment.zones && Array.isArray(comment.zones)) {
          return comment.zones.some(z => {
            const zoneStr = z.toString();
            return zoneStr.includes(filters.zone) || zoneStr === filters.zone;
          });
        }
        return false;
      });
    }

    // Intensity filter
    if (filters.intensity !== null && filters.intensity !== undefined && filters.intensity !== '') {
      filtered = filtered.filter(comment => {
        return comment.intensity !== null && comment.intensity !== undefined && 
               comment.intensity.toString() === filters.intensity.toString();
      });
    }

    // Video filter
    if (filters.video && filters.video !== '') {
      filtered = filtered.filter(comment => {
        const videoId = filters.video;
        return comment.videoId === videoId || 
               (comment.videoUrl && comment.videoUrl.includes(videoId)) ||
               (comment.videoTitle && comment.videoTitle.includes(videoId));
      });
    }

    // Project filter
    if (filters.project && filters.project !== '') {
      filtered = filtered.filter(comment => {
        return comment.analysisId === filters.project;
      });
    }

    return filtered;
  }

  // Format comment text for display
  function formatCommentText(comment) {
    const text = comment.text || comment.content || '';
    // Remove timecode if present
    return text.replace(/^\[\d{1,2}:\d{2}(?::\d{2})?\]\s*/, '').trim();
  }

  // Format date for display
  function formatCommentDate(timestamp) {
    if (!timestamp) return 'N/A';
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // Display comments in table
  function displayComments(comments, page = 1) {
    const tableBody = document.getElementById('commentsDatabaseTableBody');
    const table = document.getElementById('commentsDatabaseTable');
    const emptyState = document.getElementById('commentsDatabaseEmpty');
    const loadingState = document.getElementById('commentsDatabaseLoading');
    const resultsCount = document.getElementById('commentsResultsCount');

    if (!tableBody) {
      console.error('commentsDatabaseTableBody not found');
      return;
    }

    // Hide loading
    if (loadingState) {
      loadingState.style.display = 'none';
    }

    // Update results count
    if (resultsCount) {
      const count = comments.length;
      let countText = window.i18n ? window.i18n.t('commentsDatabase.resultsCount', { count }) : `${count} comment(s)`;
      countText = countText.replace('{count}', count);
      resultsCount.textContent = countText;
    }

    if (comments.length === 0) {
      if (table) table.style.display = 'none';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (table) {
      table.style.display = 'table';
      table.style.visibility = 'visible';
    }

    // Pagination
    const startIndex = (page - 1) * commentsPerPage;
    const endIndex = startIndex + commentsPerPage;
    const pageComments = comments.slice(startIndex, endIndex);

    tableBody.innerHTML = '';
    
    if (pageComments.length === 0) {
      return;
    }

    pageComments.forEach(comment => {
      const row = document.createElement('tr');
      
      // Text column
      const textCell = document.createElement('td');
      const textContent = formatCommentText(comment);
      textCell.className = 'comment-text-cell';
      
      // Create container for text with expand/collapse functionality
      const textContainer = document.createElement('div');
      textContainer.className = 'comment-text-container';
      
      const textDisplay = document.createElement('div');
      textDisplay.className = 'comment-text-display';
      textDisplay.textContent = textContent || '(No text)';
      
      // Check if text is long (more than 100 characters)
      const isLongText = textContent && textContent.length > 100;
      
      if (isLongText) {
        // Add truncated view
        const truncatedText = textContent.substring(0, 100) + '...';
        textDisplay.textContent = truncatedText;
        textDisplay.dataset.fullText = textContent;
        textDisplay.dataset.isExpanded = 'false';
        
        // Add expand/collapse button
        const expandBtn = document.createElement('button');
        expandBtn.className = 'comment-expand-btn';
        expandBtn.textContent = 'Show more';
        expandBtn.type = 'button';
        
        expandBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const isExpanded = textDisplay.dataset.isExpanded === 'true';
          
          if (isExpanded) {
            // Collapse
            textDisplay.textContent = truncatedText;
            textDisplay.dataset.isExpanded = 'false';
            expandBtn.textContent = 'Show more';
            textDisplay.classList.remove('expanded');
          } else {
            // Expand
            textDisplay.textContent = textContent;
            textDisplay.dataset.isExpanded = 'true';
            expandBtn.textContent = 'Show less';
            textDisplay.classList.add('expanded');
          }
        });
        
        textContainer.appendChild(textDisplay);
        textContainer.appendChild(expandBtn);
      } else {
        // Short text - no expand button needed
        textContainer.appendChild(textDisplay);
      }
      
      textCell.appendChild(textContainer);
      textCell.title = textContent; // Keep title for tooltip
      row.appendChild(textCell);

      // Schemes column
      const schemesCell = document.createElement('td');
      schemesCell.className = 'comment-schemes-cell';
      
      // Only show schemes for scheme-type entries (not for regular comments that have schemes)
      // This prevents duplicates since we create separate scheme entries in loadAllComments()
      if (comment.type === 'scheme' && comment.slidesData) {
        // This is a scheme entry - show preview
        const schemePreview = document.createElement('div');
        schemePreview.className = 'scheme-preview-container';
        schemePreview.style.cursor = 'pointer';
        schemePreview.style.display = 'inline-block';
        
        // Create thumbnail placeholder
        const thumbnail = document.createElement('div');
        thumbnail.className = 'scheme-thumbnail';
        thumbnail.style.width = '60px';
        thumbnail.style.height = '40px';
        thumbnail.style.background = '#161b22';
        thumbnail.style.border = '1px solid #30363d';
        thumbnail.style.borderRadius = '4px';
        thumbnail.style.display = 'flex';
        thumbnail.style.alignItems = 'center';
        thumbnail.style.justifyContent = 'center';
        thumbnail.style.color = '#8b949e';
        thumbnail.style.fontSize = '10px';
        thumbnail.textContent = 'Scheme';
        
        schemePreview.appendChild(thumbnail);
        schemePreview.title = 'Click to view scheme';
        
        // Generate thumbnail preview asynchronously
        (async () => {
          try {
            const defaultBackground = chrome.runtime.getURL('icons/soccer-145794.svg');
            const firstSlide = comment.slidesData[0];
            if (firstSlide && firstSlide.drawings && firstSlide.drawings.length > 0) {
              const renderedImage = await renderImagePreviewWithDrawings(
                firstSlide.backgroundImage || defaultBackground,
                firstSlide.drawings
              );
              thumbnail.style.backgroundImage = `url(${renderedImage})`;
              thumbnail.style.backgroundSize = 'cover';
              thumbnail.style.backgroundPosition = 'center';
              thumbnail.textContent = '';
            }
          } catch (error) {
            console.error('Error generating scheme thumbnail:', error);
          }
        })();
        
        // Add click handler to open scheme viewer
        schemePreview.addEventListener('click', (e) => {
          e.stopPropagation();
          openSchemeViewer(comment);
        });
        
        schemesCell.appendChild(schemePreview);
      } else {
        // Regular comment - don't show schemes here to avoid duplicates
        // Schemes are shown as separate entries (type === 'scheme')
        schemesCell.textContent = '-';
      }
      row.appendChild(schemesCell);

      // Team column
      const teamCell = document.createElement('td');
      const teams = comment.teams || (comment.team ? [comment.team] : []);
      if (teams.length > 0) {
        teams.forEach(team => {
          const tag = document.createElement('span');
          tag.className = 'comment-attribute-tag';
          tag.textContent = team;
          teamCell.appendChild(tag);
        });
      } else {
        teamCell.textContent = '-';
      }
      row.appendChild(teamCell);

      // Players column
      const playersCell = document.createElement('td');
      if (comment.players && Array.isArray(comment.players) && comment.players.length > 0) {
        // Resolve player IDs to names
        const playerNames = [];
        comment.players.forEach(playerId => {
          // Try to find player name from the mapping
          let playerName = playerId;
          for (const [name, ids] of playerNameToIdMap.entries()) {
            if (ids.has(playerId)) {
              playerName = name;
              break;
            }
          }
          // If not found in mapping, try to get from storage (async, but we'll use what we have)
          if (playerName === playerId && typeof playerId === 'string') {
            // Keep as ID if we can't resolve it
            playerName = playerId;
          }
          playerNames.push(playerName);
        });
        playerNames.forEach(playerName => {
          const tag = document.createElement('span');
          tag.className = 'comment-attribute-tag';
          tag.textContent = playerName;
          playersCell.appendChild(tag);
        });
      } else {
        playersCell.textContent = '-';
      }
      row.appendChild(playersCell);

      // Events column
      const eventsCell = document.createElement('td');
      if (comment.events && Array.isArray(comment.events) && comment.events.length > 0) {
        comment.events.forEach(event => {
          const tag = document.createElement('span');
          tag.className = 'comment-attribute-tag';
          tag.textContent = event;
          eventsCell.appendChild(tag);
        });
      } else {
        eventsCell.textContent = '-';
      }
      row.appendChild(eventsCell);

      // Zones column
      const zonesCell = document.createElement('td');
      if (comment.zones && Array.isArray(comment.zones) && comment.zones.length > 0) {
        comment.zones.forEach(zone => {
          const tag = document.createElement('span');
          tag.className = 'comment-attribute-tag';
          tag.textContent = zone.toString();
          zonesCell.appendChild(tag);
        });
      } else {
        zonesCell.textContent = '-';
      }
      row.appendChild(zonesCell);

      // Video column
      const videoCell = document.createElement('td');
      videoCell.className = 'comment-video-cell';
      videoCell.textContent = comment.videoTitle || comment.videoUrl || '-';
      videoCell.title = comment.videoTitle || comment.videoUrl || '';
      row.appendChild(videoCell);

      // Date column
      const dateCell = document.createElement('td');
      dateCell.className = 'comment-date-cell';
      dateCell.textContent = formatCommentDate(comment.timestamp);
      row.appendChild(dateCell);

      // Project column
      const projectCell = document.createElement('td');
      projectCell.className = 'comment-project-cell';
      projectCell.textContent = comment.analysisName || 'Unknown';
      row.appendChild(projectCell);

      tableBody.appendChild(row);
    });

    // Update pagination
    updatePagination(comments.length, page);
  }

  // Update pagination controls
  function updatePagination(totalComments, page) {
    const prevBtn = document.getElementById('commentsDatabasePrevPage');
    const nextBtn = document.getElementById('commentsDatabaseNextPage');
    const pageInfo = document.getElementById('commentsDatabasePageInfo');

    const totalPages = Math.ceil(totalComments / commentsPerPage);
    currentPage = page;

    if (prevBtn) {
      prevBtn.disabled = page <= 1;
    }
    if (nextBtn) {
      nextBtn.disabled = page >= totalPages;
    }
    if (pageInfo) {
      const start = (page - 1) * commentsPerPage + 1;
      const end = Math.min(page * commentsPerPage, totalComments);
      pageInfo.textContent = `${start}-${end} of ${totalComments}`;
    }
  }

  // Populate filter dropdowns with unique values
  async function populateFilterDropdowns(comments) {
    const teams = new Set();
    const playerIds = new Set();
    const events = new Set();
    const zones = new Set();
    const videos = new Map();
    const projects = new Map();

    // First pass: collect all IDs and values
    comments.forEach(comment => {
      // Collect teams
      if (comment.teams && Array.isArray(comment.teams)) {
        comment.teams.forEach(t => {
          if (t && t.trim() !== '') teams.add(t);
        });
      } else if (comment.team && comment.team.trim() !== '') {
        teams.add(comment.team);
      }

      // Collect player IDs
      if (comment.players && Array.isArray(comment.players)) {
        comment.players.forEach(p => {
          if (typeof p === 'string') {
            playerIds.add(p);
          } else if (p && (p.id || p.name)) {
            playerIds.add(p.id || p.name);
          }
        });
      }

      // Collect events
      if (comment.events && Array.isArray(comment.events)) {
        comment.events.forEach(e => {
          if (e && e.trim() !== '') events.add(e);
        });
      }

      // Collect zones
      if (comment.zones && Array.isArray(comment.zones)) {
        comment.zones.forEach(z => {
          if (z !== null && z !== undefined) {
            const zoneStr = z.toString().trim();
            if (zoneStr !== '') zones.add(zoneStr);
          }
        });
      }

      // Collect videos
      if (comment.videoId || comment.videoTitle) {
        const videoKey = comment.videoId || comment.videoTitle;
        if (videoKey && !videos.has(videoKey)) {
          videos.set(videoKey, comment.videoTitle || comment.videoUrl || videoKey);
        }
      }

      // Collect projects
      if (comment.analysisId && comment.analysisName) {
        projects.set(comment.analysisId, comment.analysisName);
      }
    });

    // Load players from storage to resolve IDs to names
    const playersMap = new Map();
    try {
      const playerResult = await new Promise((resolve) => {
        chrome.storage.local.get(['players'], resolve);
      });
      const allPlayers = playerResult.players || [];
      allPlayers.forEach(player => {
        if (player && player.id) {
          const displayName = player.number ? 
            `#${player.number} ${player.fullName || player.name || ''}`.trim() : 
            (player.fullName || player.name || player.id);
          playersMap.set(player.id, displayName);
        }
      });
    } catch (error) {
      console.error('Error loading players:', error);
    }

    // Resolve player IDs to names and create reverse mapping
    const players = new Set();
    playerNameToIdMap.clear(); // Reset mapping
    playerIds.forEach(playerId => {
      const playerName = playersMap.get(playerId) || playerId;
      if (playerName) {
        players.add(playerName);
        // Create reverse mapping: name -> ID (handle multiple IDs with same name)
        if (!playerNameToIdMap.has(playerName)) {
          playerNameToIdMap.set(playerName, new Set());
        }
        playerNameToIdMap.get(playerName).add(playerId);
      }
    });

    // Populate team dropdown
    const teamSelect = document.getElementById('commentsFilterTeam');
    if (teamSelect) {
      const currentValue = teamSelect.value;
      teamSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allTeams">All Teams</option>';
      const sortedTeams = Array.from(teams).sort();
      console.log('Populating team dropdown with', sortedTeams.length, 'teams');
      sortedTeams.forEach(team => {
        const option = document.createElement('option');
        option.value = team;
        option.textContent = team;
        teamSelect.appendChild(option);
      });
      if (currentValue) teamSelect.value = currentValue;
      console.log('Team dropdown populated. Total options:', teamSelect.options.length);
    } else {
      console.error('commentsFilterTeam element not found');
    }

    // Populate player dropdown
    const playerSelect = document.getElementById('commentsFilterPlayer');
    if (playerSelect) {
      const currentValue = playerSelect.value;
      playerSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allPlayers">All Players</option>';
      const sortedPlayers = Array.from(players).sort();
      console.log('Populating player dropdown with', sortedPlayers.length, 'players');
      sortedPlayers.forEach(playerName => {
        const option = document.createElement('option');
        option.value = playerName; // Store display name as value
        option.textContent = playerName;
        playerSelect.appendChild(option);
      });
      if (currentValue) playerSelect.value = currentValue;
      console.log('Player dropdown populated. Total options:', playerSelect.options.length);
    } else {
      console.error('commentsFilterPlayer element not found');
    }

    // Populate event dropdown
    const eventSelect = document.getElementById('commentsFilterEvent');
    if (eventSelect) {
      const currentValue = eventSelect.value;
      eventSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allEvents">All Events</option>';
      const sortedEvents = Array.from(events).sort();
      console.log('Populating event dropdown with', sortedEvents.length, 'events');
      sortedEvents.forEach(event => {
        const option = document.createElement('option');
        option.value = event;
        option.textContent = event;
        eventSelect.appendChild(option);
      });
      if (currentValue) eventSelect.value = currentValue;
      console.log('Event dropdown populated. Total options:', eventSelect.options.length);
    } else {
      console.error('commentsFilterEvent element not found');
    }

    // Populate zone dropdown
    const zoneSelect = document.getElementById('commentsFilterZone');
    if (zoneSelect) {
      const currentValue = zoneSelect.value;
      zoneSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allZones">All Zones</option>';
      const sortedZones = Array.from(zones).sort((a, b) => {
        const numA = parseInt(a) || 0;
        const numB = parseInt(b) || 0;
        return numA - numB;
      });
      console.log('Populating zone dropdown with', sortedZones.length, 'zones');
      sortedZones.forEach(zone => {
        const option = document.createElement('option');
        option.value = zone;
        option.textContent = `Zone ${zone}`;
        zoneSelect.appendChild(option);
      });
      if (currentValue) zoneSelect.value = currentValue;
      console.log('Zone dropdown populated. Total options:', zoneSelect.options.length);
    } else {
      console.error('commentsFilterZone element not found');
    }

    // Populate video dropdown
    const videoSelect = document.getElementById('commentsFilterVideo');
    if (videoSelect) {
      const currentValue = videoSelect.value;
      videoSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allVideos">All Videos</option>';
      const sortedVideos = Array.from(videos.entries()).sort((a, b) => a[1].localeCompare(b[1]));
      console.log('Populating video dropdown with', sortedVideos.length, 'videos');
      sortedVideos.forEach(([key, title]) => {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = title;
        videoSelect.appendChild(option);
      });
      if (currentValue) videoSelect.value = currentValue;
      console.log('Video dropdown populated. Total options:', videoSelect.options.length);
    } else {
      console.error('commentsFilterVideo element not found');
    }

    // Populate project dropdown
    const projectSelect = document.getElementById('commentsFilterProject');
    if (projectSelect) {
      const currentValue = projectSelect.value;
      projectSelect.innerHTML = '<option value="" data-i18n="commentsDatabase.allProjects">All Projects</option>';
      const sortedProjects = Array.from(projects.entries()).sort((a, b) => a[1].localeCompare(b[1]));
      console.log('Populating project dropdown with', sortedProjects.length, 'projects');
      sortedProjects.forEach(([id, name]) => {
        const option = document.createElement('option');
        option.value = id;
        option.textContent = name;
        projectSelect.appendChild(option);
      });
      if (currentValue) projectSelect.value = currentValue;
      console.log('Project dropdown populated. Total options:', projectSelect.options.length);
    } else {
      console.error('commentsFilterProject element not found');
    }
    
    console.log('Filter dropdowns populated. Summary:', {
      teams: teams.size,
      players: players.size,
      events: events.size,
      zones: zones.size,
      videos: videos.size,
      projects: projects.size
    });
    
    // Apply translations to dynamically created elements
    if (window.i18n && window.i18n.updateI18nElements) {
      window.i18n.updateI18nElements();
    }
  }

  // Apply filters and search
  function applyFiltersAndSearch() {
    const searchQuery = document.getElementById('commentsDatabaseSearch')?.value || '';
    const filters = {
      team: document.getElementById('commentsFilterTeam')?.value || '',
      player: document.getElementById('commentsFilterPlayer')?.value || '',
      event: document.getElementById('commentsFilterEvent')?.value || '',
      zone: document.getElementById('commentsFilterZone')?.value || '',
      intensity: document.getElementById('commentsFilterIntensity')?.value || '',
      video: document.getElementById('commentsFilterVideo')?.value || '',
      project: document.getElementById('commentsFilterProject')?.value || ''
    };

    // First apply filters
    let results = filterComments(allCommentsData, filters);
    
    // Then apply search
    results = searchComments(results, searchQuery);

    filteredComments = results;
    currentPage = 1;
    displayComments(results, 1);
  }

  // Load players mapping for display (separate from populateFilterDropdowns)
  async function loadPlayersMappingForDisplay() {
    try {
      const playerResult = await new Promise((resolve) => {
        chrome.storage.local.get(['players'], resolve);
      });
      const allPlayers = playerResult.players || [];
      playerNameToIdMap.clear();
      allPlayers.forEach(player => {
        if (player && player.id) {
          const displayName = player.number ? 
            `#${player.number} ${player.fullName || player.name || ''}`.trim() : 
            (player.fullName || player.name || player.id);
          if (!playerNameToIdMap.has(displayName)) {
            playerNameToIdMap.set(displayName, new Set());
          }
          playerNameToIdMap.get(displayName).add(player.id);
        }
      });
    } catch (error) {
      console.error('Error loading players mapping:', error);
    }
  }

  // Open comments database modal
  async function openCommentsDatabase() {
    const modal = document.getElementById('commentsDatabaseModal');
    if (!modal) {
      console.error('commentsDatabaseModal not found');
      return;
    }

    modal.classList.remove('hidden');
    
    // Show loading
    const loadingState = document.getElementById('commentsDatabaseLoading');
    const table = document.getElementById('commentsDatabaseTable');
    const emptyState = document.getElementById('commentsDatabaseEmpty');
    if (loadingState) loadingState.style.display = 'block';
    if (table) table.style.display = 'none';
    if (emptyState) emptyState.style.display = 'none';

    try {
      // Load all comments
      await loadAllComments();
      console.log('Loaded comments:', allCommentsData.length);
      
      // Load players mapping for display
      await loadPlayersMappingForDisplay();
      
      // Populate filter dropdowns
      await populateFilterDropdowns(allCommentsData);
      
      // Apply initial filters (none)
      filteredComments = allCommentsData;
      currentPage = 1;
      displayComments(allCommentsData, 1);
    } catch (error) {
      console.error('Error loading comments:', error);
      if (loadingState) loadingState.style.display = 'none';
      if (emptyState) {
        emptyState.textContent = 'Error loading comments: ' + error.message;
        emptyState.style.display = 'block';
      }
    }
  }

  // Comments Database Modal handlers
  const commentsDatabaseModal = document.getElementById('commentsDatabaseModal');
  const closeCommentsDatabaseModal = document.getElementById('closeCommentsDatabaseModal');

  if (closeCommentsDatabaseModal) {
    closeCommentsDatabaseModal.addEventListener('click', () => {
      if (commentsDatabaseModal) {
        commentsDatabaseModal.classList.add('hidden');
      }
    });
  }

  if (commentsDatabaseModal) {
    commentsDatabaseModal.addEventListener('click', (e) => {
      if (e.target === commentsDatabaseModal) {
        commentsDatabaseModal.classList.add('hidden');
      }
    });
  }

  // Search input handler with debouncing
  const commentsDatabaseSearch = document.getElementById('commentsDatabaseSearch');
  if (commentsDatabaseSearch) {
    commentsDatabaseSearch.addEventListener('input', () => {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => {
        applyFiltersAndSearch();
      }, 300);
    });
  }

  // Filter change handlers
  ['commentsFilterTeam', 'commentsFilterPlayer', 'commentsFilterEvent', 
   'commentsFilterZone', 'commentsFilterIntensity', 'commentsFilterVideo', 
   'commentsFilterProject'].forEach(filterId => {
    const filterElement = document.getElementById(filterId);
    if (filterElement) {
      filterElement.addEventListener('change', () => {
        applyFiltersAndSearch();
      });
    }
  });

  // Clear filters button
  const clearCommentsFiltersBtn = document.getElementById('clearCommentsFiltersBtn');
  if (clearCommentsFiltersBtn) {
    clearCommentsFiltersBtn.addEventListener('click', () => {
      document.getElementById('commentsDatabaseSearch').value = '';
      document.getElementById('commentsFilterTeam').value = '';
      document.getElementById('commentsFilterPlayer').value = '';
      document.getElementById('commentsFilterEvent').value = '';
      document.getElementById('commentsFilterZone').value = '';
      document.getElementById('commentsFilterIntensity').value = '';
      document.getElementById('commentsFilterVideo').value = '';
      document.getElementById('commentsFilterProject').value = '';
      applyFiltersAndSearch();
    });
  }

  // Pagination handlers
  const commentsDatabasePrevPage = document.getElementById('commentsDatabasePrevPage');
  const commentsDatabaseNextPage = document.getElementById('commentsDatabaseNextPage');

  if (commentsDatabasePrevPage) {
    commentsDatabasePrevPage.addEventListener('click', () => {
      if (currentPage > 1) {
        displayComments(filteredComments, currentPage - 1);
      }
    });
  }

  if (commentsDatabaseNextPage) {
    commentsDatabaseNextPage.addEventListener('click', () => {
      const totalPages = Math.ceil(filteredComments.length / commentsPerPage);
      if (currentPage < totalPages) {
        displayComments(filteredComments, currentPage + 1);
      }
    });
  }

  // Scheme Viewer Modal
  let currentSchemeViewerData = null;
  let currentSchemeSlideIndex = 0;

  async function openSchemeViewer(scheme) {
    const modal = document.getElementById('schemeViewerModal');
    const title = document.getElementById('schemeViewerTitle');
    const content = document.getElementById('schemeViewerContent');
    const navigation = document.getElementById('schemeViewerNavigation');
    const prevBtn = document.getElementById('schemeViewerPrevSlide');
    const nextBtn = document.getElementById('schemeViewerNextSlide');
    const slideInfo = document.getElementById('schemeViewerSlideInfo');

    if (!modal || !content) {
      console.error('Scheme viewer modal elements not found');
      return;
    }

    currentSchemeViewerData = scheme;
    currentSchemeSlideIndex = 0;

    // Set title
    const timecode = scheme.timecode ? scheme.timecode[0] : (scheme.videoTime ? `[${Math.floor(scheme.videoTime / 60)}:${String(Math.floor(scheme.videoTime % 60)).padStart(2, '0')}]` : '');
    if (title) {
      title.textContent = `Tactical Scheme ${timecode}`;
    }

    // Show modal
    modal.classList.remove('hidden');

    // Render scheme slides
    await renderSchemeInModal(scheme, content, navigation, prevBtn, nextBtn, slideInfo);
  }

  async function renderSchemeInModal(scheme, content, navigation, prevBtn, nextBtn, slideInfo) {
    if (!scheme || !scheme.slidesData || scheme.slidesData.length === 0) {
      content.innerHTML = '<div style="color: #8b949e; padding: 12px; text-align: center;">No scheme data available</div>';
      if (navigation) navigation.style.display = 'none';
      return;
    }

    const defaultBackground = chrome.runtime.getURL('icons/soccer-145794.svg');
    const slides = scheme.slidesData;
    
    // Update navigation visibility
    if (navigation) {
      navigation.style.display = slides.length > 1 ? 'block' : 'none';
    }

    // Render all slides
    content.innerHTML = '';
    const slideContainers = [];

    for (let slideIndex = 0; slideIndex < slides.length; slideIndex++) {
      const slide = slides[slideIndex];
      const slideContainer = document.createElement('div');
      slideContainer.className = 'scheme-slide-container';
      slideContainer.style.display = slideIndex === 0 ? 'block' : 'none';
      slideContainer.style.marginBottom = '20px';
      slideContainer.style.textAlign = 'center';

      const slideLabel = document.createElement('div');
      slideLabel.style.fontSize = '14px';
      slideLabel.style.color = '#8b949e';
      slideLabel.style.marginBottom = '12px';
      slideLabel.textContent = `Slide ${slideIndex + 1} of ${slides.length}`;
      slideContainer.appendChild(slideLabel);

      const slideImage = document.createElement('img');
      slideImage.style.maxWidth = '100%';
      slideImage.style.height = 'auto';
      slideImage.style.borderRadius = '8px';
      slideImage.style.border = '1px solid #21262d';
      slideImage.style.background = '#0d1117';
      slideImage.alt = `Scheme slide ${slideIndex + 1}`;

      // Render slide
      try {
        const renderedImage = await renderImagePreviewWithDrawings(
          slide.backgroundImage || defaultBackground,
          slide.drawings || []
        );
        slideImage.src = renderedImage;
      } catch (error) {
        console.error('Error rendering scheme slide:', error);
        slideImage.src = '';
        slideImage.style.display = 'none';
        const errorDiv = document.createElement('div');
        errorDiv.style.color = '#f85149';
        errorDiv.textContent = `Error rendering slide ${slideIndex + 1}`;
        slideContainer.appendChild(errorDiv);
      }

      slideContainer.appendChild(slideImage);
      content.appendChild(slideContainer);
      slideContainers.push(slideContainer);
    }

    // Update slide info
    if (slideInfo) {
      slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
    }

    // Navigation handlers
    if (prevBtn) {
      prevBtn.onclick = () => {
        if (currentSchemeSlideIndex > 0) {
          slideContainers[currentSchemeSlideIndex].style.display = 'none';
          currentSchemeSlideIndex--;
          slideContainers[currentSchemeSlideIndex].style.display = 'block';
          if (slideInfo) {
            slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
          }
          prevBtn.disabled = currentSchemeSlideIndex === 0;
          if (nextBtn) nextBtn.disabled = false;
        }
      };
      prevBtn.disabled = currentSchemeSlideIndex === 0;
    }

    if (nextBtn) {
      nextBtn.onclick = () => {
        if (currentSchemeSlideIndex < slides.length - 1) {
          slideContainers[currentSchemeSlideIndex].style.display = 'none';
          currentSchemeSlideIndex++;
          slideContainers[currentSchemeSlideIndex].style.display = 'block';
          if (slideInfo) {
            slideInfo.textContent = `Slide ${currentSchemeSlideIndex + 1} of ${slides.length}`;
          }
          nextBtn.disabled = currentSchemeSlideIndex === slides.length - 1;
          if (prevBtn) prevBtn.disabled = false;
        }
      };
      nextBtn.disabled = currentSchemeSlideIndex === slides.length - 1;
    }
  }

  // Scheme Viewer Modal handlers
  const schemeViewerModal = document.getElementById('schemeViewerModal');
  const closeSchemeViewerModal = document.getElementById('closeSchemeViewerModal');

  if (closeSchemeViewerModal) {
    closeSchemeViewerModal.addEventListener('click', () => {
      if (schemeViewerModal) {
        schemeViewerModal.classList.add('hidden');
        currentSchemeViewerData = null;
        currentSchemeSlideIndex = 0;
      }
    });
  }

  if (schemeViewerModal) {
    schemeViewerModal.addEventListener('click', (e) => {
      if (e.target === schemeViewerModal) {
        schemeViewerModal.classList.add('hidden');
        currentSchemeViewerData = null;
        currentSchemeSlideIndex = 0;
      }
    });
  }

  // Make openCommentsDatabase available globally for menu integration
  window.openCommentsDatabase = openCommentsDatabase;
});