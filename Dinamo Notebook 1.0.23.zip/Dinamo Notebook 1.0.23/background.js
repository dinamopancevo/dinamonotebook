// Minimal background script - only handle popup and editor windows

// Open extension in new window when icon is clicked
try {
  if (typeof chrome !== 'undefined' && chrome.action && typeof chrome.action.onClicked !== 'undefined') {
    chrome.action.onClicked.addListener(() => {
      const popupUrl = chrome.runtime.getURL('popup.html');
      const editorUrl = chrome.runtime.getURL('editor.html');
      const extensionId = chrome.runtime.id;

      // Check if any extension windows are already open
      chrome.windows.getAll({ populate: true }, (windows) => {
        const extensionWindows = [];
        let existingPopup = null;

        // Find all windows created by this extension
        for (const window of windows) {
          if (window.type === 'popup' && window.tabs) {
            // Check if any tab in this window belongs to our extension
            for (const tab of window.tabs) {
              if (tab.url && tab.url.startsWith(`chrome-extension://${extensionId}/`)) {
                // Check if it's our popup or editor
                if (tab.url === popupUrl) {
                  existingPopup = window;
                  extensionWindows.push(window);
                } else if (tab.url === editorUrl) {
                  extensionWindows.push(window);
                }
                break; // Found extension window, no need to check other tabs
              }
            }
          }
        }

        // Bring all extension windows to the front
        if (extensionWindows.length > 0) {
          // Separate editor windows from popup window
          const editorWindows = extensionWindows.filter(w => w !== existingPopup);
          const windowsToFocus = [...editorWindows];
          if (existingPopup) {
            windowsToFocus.push(existingPopup); // Popup goes last so it's on top
          }

          // Focus all windows sequentially, restoring minimized ones first
          windowsToFocus.forEach((window, index) => {
            setTimeout(() => {
              // Restore if minimized, then focus
              const updateParams = { focused: true };
              if (window.state === 'minimized') {
                updateParams.state = 'normal';
              }
              
              chrome.windows.update(window.id, updateParams, () => {
                if (chrome.runtime.lastError) {
                  console.warn('Error focusing window:', chrome.runtime.lastError);
                }
              });
            }, index * 100); // Small delay to ensure proper focusing order
          });
        } else {
          // No extension windows exist, create new popup window
          chrome.windows.create({
            url: popupUrl,
            type: 'popup',
            width: 800,
            height: 600
          });
        }
      });
    });
  } else {
    console.warn('chrome.action.onClicked is not available. The extension icon click handler will not work.');
  }
} catch (error) {
  console.error('Error setting up action click listener:', error);
}

// Handle requests to open the tactical editor window from other contexts (e.g., content scripts)
try {
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (!request || !request.action) {
        return false;
      }

      if (request.action === 'openEditorWindow') {
        // If caller passed editor payload, write to storage HERE so editor always sees it (avoids race)
        const payload = request.editorPayload;
        const doOpen = () => {
          chrome.windows.create({
            url: chrome.runtime.getURL('editor.html'),
            type: 'popup',
            width: request.width || 1200,
            height: request.height || 800,
            focused: true
          }, () => {
            if (chrome.runtime.lastError) {
              console.error('Error opening editor window from background:', chrome.runtime.lastError);
              sendResponse && sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
              sendResponse && sendResponse({ success: true });
            }
          });
        };
        if (payload && typeof payload === 'object') {
          chrome.storage.local.set({
            pendingEditorImageSrc: payload.pendingEditorImageSrc ?? null,
            pendingEditorCallbackId: payload.pendingEditorCallbackId ?? null,
            pendingEditorCallbackContext: payload.pendingEditorCallbackContext ?? 'sidebar',
            pendingEditorSlidesData: payload.pendingEditorSlidesData ?? null,
            pendingEditorOriginalImageSrc: payload.pendingEditorOriginalImageSrc ?? null
          }, () => {
            doOpen();
          });
        } else {
          doOpen();
        }
        return true; // Keep the message channel open for async response
      }

      if (request.action === 'imageEditorSaved') {
        // Persist payload so all contexts (popup/sidebar) can read it reliably
        chrome.storage.local.get(['pendingEditorCallbackContext', 'pendingEditorCallbackId', 'pendingEditorAddToNote'], (result) => {
          const payload = {
            action: 'imageEditorSaved',
            imageData: request.imageData,
            originalImageSrc: request.originalImageSrc,
            slidesData: request.slidesData,
            canvasRotation: request.canvasRotation || 0,
            callbackId: request.callbackId || result.pendingEditorCallbackId || null,
            callbackContext: result.pendingEditorCallbackContext || 'popup',
            timestamp: Date.now()
          };

          chrome.storage.local.set({ editorSavedPayload: payload }, () => {
            if (chrome.runtime.lastError) {
              console.error('Error storing editorSavedPayload:', chrome.runtime.lastError);
              sendResponse && sendResponse({ success: false, error: chrome.runtime.lastError.message });
              return;
            }
            // If add-to-note context exists, directly add the scheme to the note in storage
            // (ensures scheme is saved even when popup/sidebar callback can't run, e.g. popup closed)
            const addToNote = result.pendingEditorAddToNote;
            if (addToNote && addToNote.analysisId && addToNote.noteTimestamp && request.imageData) {
              chrome.storage.local.get(['analyses'], (analysesResult) => {
                const analyses = analysesResult.analyses || [];
                const analysisIndex = analyses.findIndex(a => a.id === addToNote.analysisId);
                if (analysisIndex !== -1 && analyses[analysisIndex].notes) {
                  const noteIndex = analyses[analysisIndex].notes.findIndex(
                    n => n.timestamp === addToNote.noteTimestamp
                  );
                  if (noteIndex !== -1) {
                    const note = analyses[analysisIndex].notes[noteIndex];
                    const imageObj = {
                      imageData: request.imageData,
                      slidesData: request.slidesData || null,
                      originalSrc: request.originalImageSrc || null
                    };
                    const existingImages = note.images ? (Array.isArray(note.images) ? [...note.images] : [note.images]) : [];
                    note.images = [...existingImages, imageObj];
                    chrome.storage.local.set({ analyses });
                  }
                }
                chrome.storage.local.remove(['pendingEditorAddToNote']);
              });
            }
            sendResponse && sendResponse({ success: true });
          });
        });
        return true; // Async response
      }

      // Proxy OpenAI API calls through background script to avoid host_permissions
      if (request.action === 'openaiApiCall') {
        const { url, options, formData } = request;
        
        // Reconstruct FormData if it was sent as an array
        let body = options.body;
        if (formData && Array.isArray(formData)) {
          const fd = new FormData();
          for (const [key, value] of formData) {
            if (value && typeof value === 'object' && value.name && value.type && Array.isArray(value.data)) {
              // Reconstruct File from serialized data (Uint8Array)
              const uint8Array = new Uint8Array(value.data);
              const blob = new Blob([uint8Array], { type: value.type });
              const file = new File([blob], value.name, { type: value.type });
              fd.append(key, file);
            } else {
              fd.append(key, value);
            }
          }
          body = fd;
        }
        
        const fetchOptions = {
          ...options,
          body: body
        };
        
        fetch(url, fetchOptions)
          .then(async (response) => {
            const data = await response.text();
            sendResponse({
              success: true,
              ok: response.ok,
              status: response.status,
              statusText: response.statusText,
              headers: Object.fromEntries(response.headers.entries()),
              data: data
            });
          })
          .catch((error) => {
            sendResponse({
              success: false,
              error: error.message
            });
          });
        
        return true; // Keep channel open for async response
      }

      return false;
    });
  } else {
    console.warn('chrome.runtime.onMessage is not available in background.');
  }
} catch (error) {
  console.error('Error setting up runtime message listener in background:', error);
}

