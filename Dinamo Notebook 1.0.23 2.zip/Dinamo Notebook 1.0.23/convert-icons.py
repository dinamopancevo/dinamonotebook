#!/usr/bin/env python3
"""
Convert SVG icons to PNG for Chrome extension
Chrome Manifest V3 requires PNG format, not SVG
"""

import os
import sys

try:
    from cairosvg import svg2png
    HAS_CAIROSVG = True
except ImportError:
    HAS_CAIROSVG = False

try:
    from PIL import Image
    import cairosvg
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

def convert_svg_to_png(svg_path, png_path, size):
    """Convert SVG to PNG at specified size"""
    if HAS_CAIROSVG:
        cairosvg.svg2png(url=svg_path, write_to=png_path, output_width=size, output_height=size)
        return True
    elif HAS_PIL:
        # Alternative method
        from io import BytesIO
        png_data = cairosvg.svg2png(url=svg_path, output_width=size, output_height=size)
        img = Image.open(BytesIO(png_data))
        img.save(png_path, 'PNG')
        return True
    else:
        return False

def main():
    sizes = [16, 48, 128]
    icons_dir = 'icons'
    
    if not HAS_CAIROSVG and not HAS_PIL:
        print("Error: cairosvg is required for SVG to PNG conversion.")
        print("\nPlease install it with:")
        print("  pip install cairosvg")
        print("\nOr use the convert-icons.html file in a browser.")
        sys.exit(1)
    
    print("Converting SVG icons to PNG...\n")
    
    for size in sizes:
        svg_path = os.path.join(icons_dir, f'icon{size}.svg')
        png_path = os.path.join(icons_dir, f'icon{size}.png')
        
        if not os.path.exists(svg_path):
            print(f"⚠ Warning: {svg_path} not found")
            continue
        
        try:
            convert_svg_to_png(svg_path, png_path, size)
            if os.path.exists(png_path):
                print(f"✓ Created {png_path} ({size}x{size})")
            else:
                print(f"✗ Failed to create {png_path}")
        except Exception as e:
            print(f"✗ Error converting {svg_path}: {e}")
    
    print("\n✓ Done! PNG icons are now in the icons/ folder.")
    print("Please reload your extension in Chrome.")

if __name__ == '__main__':
    main()
